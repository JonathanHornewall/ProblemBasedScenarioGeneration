"""Audit and summarize the frozen broad cost-learning confirmation panel."""

from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any

from scipy.stats import t as student_t

from proximal_spo.artifacts import write_json

METHODS = {
    "anchored_proximal",
    "knn",
    "mse",
    "proximal",
    "sfge",
    "spo_plus",
    "wise",
}
COMPARISONS = (
    ("proximal", "spo_plus"),
    ("proximal", "mse"),
    ("anchored_proximal", "spo_plus"),
    ("anchored_proximal", "mse"),
    ("sfge", "spo_plus"),
)


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected a JSON object at {path}")
    return payload


def _mean(values: list[float]) -> float:
    if not values:
        raise ValueError("cannot average an empty collection")
    return sum(values) / len(values)


def _standard_error(values: list[float]) -> float:
    if len(values) <= 1:
        return 0.0
    center = _mean(values)
    variance = sum((value - center) ** 2 for value in values) / (len(values) - 1)
    return math.sqrt(variance / len(values))


def _interval(values: list[float]) -> list[float]:
    center = _mean(values)
    if len(values) <= 1:
        return [center, center]
    radius = float(student_t.ppf(0.975, len(values) - 1)) * _standard_error(
        values
    )
    return [center - radius, center + radius]


def _seed_key(row: dict[str, Any]) -> tuple[int, int, int, int, int]:
    seeds = row.get("seeds")
    if not isinstance(seeds, dict):
        raise ValueError("confirmation row lacks its seed receipt")
    fields = ("structural", "data", "initialization", "shuffle", "perturbation")
    values = tuple(seeds.get(field) for field in fields)
    if any(isinstance(value, bool) or not isinstance(value, int) for value in values):
        raise ValueError("confirmation row contains malformed seed values")
    return values  # type: ignore[return-value]


def build_report(
    selection_path: Path,
    campaign_path: Path,
    *,
    source_sha256: str,
) -> dict[str, Any]:
    """Return a paired report after checking the frozen campaign topology."""

    selection = _object(selection_path)
    campaign = _object(campaign_path)
    rows = selection.get("selected")
    variants = campaign.get("variants")
    if not isinstance(rows, list) or not isinstance(variants, list):
        raise ValueError("confirmation selection or campaign is malformed")
    planned_names = {str(variant.get("name")) for variant in variants}
    observed_names = {str(row.get("name")) for row in rows}
    if len(planned_names) != len(variants) or planned_names != observed_names:
        raise ValueError("completed confirmation rows do not match the frozen plan")
    if selection.get("source_sha256") != source_sha256:
        raise ValueError("confirmation selection has the wrong source digest")

    enriched: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict) or row.get("status") != "complete":
            raise ValueError("confirmation contains an incomplete selected row")
        if row.get("source_sha256") != source_sha256:
            raise ValueError("confirmation row has the wrong source digest")
        directory = Path(str(row["run_directory"]))
        status = _object(directory / "status.json")
        summary = _object(directory / "summary.json")
        if status.get("status") != "complete":
            raise ValueError(f"non-complete receipt below {directory}")
        test = summary.get("test")
        oracle = summary.get("whole_pipeline_training_oracle_stats")
        if not isinstance(test, dict) or not isinstance(oracle, dict):
            raise ValueError(f"malformed training summary below {directory}")
        regret = float(test["mean_regret"])
        if not math.isclose(
            regret, float(row["test_mean_regret"]), rel_tol=0.0, abs_tol=1e-12
        ):
            raise ValueError(f"test metric mismatch below {directory}")
        seeds = row["seeds"]
        assert isinstance(seeds, dict)
        enriched.append(
            {
                "benchmark_id": str(row["benchmark_id"]),
                "interface": str(row["interface"]),
                "method": str(row["method"]),
                "data_seed": int(seeds["data"]),
                "seed_key": list(_seed_key(row)),
                "run_directory": str(directory),
                "arm_sha256": str(row["arm_sha256"]),
                "parameter_sha256": str(summary["parameter_sha256"]),
                "best_epoch": int(summary["best_epoch"]),
                "test_mean_regret": regret,
                "test_normalized_mean_regret": float(
                    test["normalized_mean_regret"]
                ),
                "whole_pipeline_training_wall_seconds": float(
                    summary["whole_pipeline_training_wall_seconds"]
                ),
                "whole_pipeline_training_oracle_calls": int(oracle["calls"]),
            }
        )

    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in enriched:
        grouped[(str(row["benchmark_id"]), str(row["method"]))].append(row)
    benchmarks = sorted({benchmark for benchmark, _method in grouped})
    for benchmark in benchmarks:
        available = {method for candidate, method in grouped if candidate == benchmark}
        if available != METHODS:
            raise ValueError(f"method panel is incomplete for {benchmark}")
        seed_maps = []
        for method in sorted(METHODS):
            method_rows = grouped[(benchmark, method)]
            if len({str(row["arm_sha256"]) for row in method_rows}) != 1:
                raise ValueError(f"multiple frozen arms for {benchmark}/{method}")
            seed_maps.append(
                {
                    int(row["data_seed"]): tuple(row["seed_key"])
                    for row in method_rows
                }
            )
        if any(seed_map != seed_maps[0] for seed_map in seed_maps[1:]):
            raise ValueError(f"methods are not paired for {benchmark}")
        if len(seed_maps[0]) != 5:
            raise ValueError(f"expected five confirmation seeds for {benchmark}")

    by_key = {
        (str(row["benchmark_id"]), str(row["method"]), int(row["data_seed"])): row
        for row in enriched
    }
    for benchmark in benchmarks:
        seeds = sorted(
            int(row["data_seed"]) for row in grouped[(benchmark, "mse")]
        )
        for seed in seeds:
            anchored = by_key[(benchmark, "anchored_proximal", seed)]
            embedded_path = Path(str(anchored["run_directory"])) / (
                "embedded_mse_base.json"
            )
            embedded = _object(embedded_path)
            mse = by_key[(benchmark, "mse", seed)]
            if embedded.get("parameter_sha256") != mse["parameter_sha256"]:
                raise ValueError(
                    f"anchored base differs from standalone MSE for {benchmark}/{seed}"
                )
            embedded_test = embedded.get("test")
            if not isinstance(embedded_test, dict):
                raise ValueError(f"malformed embedded base below {embedded_path}")
            anchored["embedded_mse_base_test_regret"] = float(
                embedded_test["mean_regret"]
            )

    aggregates: list[dict[str, Any]] = []
    for benchmark in benchmarks:
        for method in sorted(METHODS):
            method_rows = sorted(
                grouped[(benchmark, method)], key=lambda row: int(row["data_seed"])
            )
            regrets = [float(row["test_mean_regret"]) for row in method_rows]
            aggregates.append(
                {
                    "benchmark_id": benchmark,
                    "interface": method_rows[0]["interface"],
                    "method": method,
                    "seed_count": len(method_rows),
                    "mean_test_regret": _mean(regrets),
                    "standard_error_test_regret": _standard_error(regrets),
                    "student_t_95_interval": _interval(regrets),
                    "mean_normalized_test_regret": _mean(
                        [
                            float(row["test_normalized_mean_regret"])
                            for row in method_rows
                        ]
                    ),
                    "mean_whole_pipeline_training_wall_seconds": _mean(
                        [
                            float(row["whole_pipeline_training_wall_seconds"])
                            for row in method_rows
                        ]
                    ),
                    "mean_whole_pipeline_training_oracle_calls": _mean(
                        [
                            float(row["whole_pipeline_training_oracle_calls"])
                            for row in method_rows
                        ]
                    ),
                    "zero_best_epoch_count": sum(
                        int(row["best_epoch"]) == 0 for row in method_rows
                    ),
                }
            )

    paired: list[dict[str, Any]] = []
    correction: list[dict[str, Any]] = []
    rankings: list[dict[str, Any]] = []
    for benchmark in benchmarks:
        seeds = sorted(
            int(row["data_seed"]) for row in grouped[(benchmark, "mse")]
        )
        rankings.append(
            {
                "benchmark_id": benchmark,
                "methods": [
                    method
                    for method, _value in sorted(
                        (
                            (
                                method,
                                _mean(
                                    [
                                        float(row["test_mean_regret"])
                                        for row in grouped[(benchmark, method)]
                                    ]
                                ),
                            )
                            for method in METHODS
                        ),
                        key=lambda item: (item[1], item[0]),
                    )
                ],
            }
        )
        for method, baseline in COMPARISONS:
            differences = [
                float(by_key[(benchmark, method, seed)]["test_mean_regret"])
                - float(by_key[(benchmark, baseline, seed)]["test_mean_regret"])
                for seed in seeds
            ]
            paired.append(
                {
                    "benchmark_id": benchmark,
                    "method": method,
                    "baseline": baseline,
                    "mean_paired_regret_difference": _mean(differences),
                    "standard_error_paired_difference": _standard_error(differences),
                    "student_t_95_interval": _interval(differences),
                    "wins": sum(value < 0.0 for value in differences),
                    "seed_count": len(differences),
                }
            )
        differences = []
        for seed in seeds:
            anchored = by_key[(benchmark, "anchored_proximal", seed)]
            differences.append(
                float(anchored["test_mean_regret"])
                - float(anchored["embedded_mse_base_test_regret"])
            )
        correction.append(
            {
                "benchmark_id": benchmark,
                "mean_correction_regret_difference": _mean(differences),
                "student_t_95_interval": _interval(differences),
                "wins": sum(value < 0.0 for value in differences),
                "seed_count": len(differences),
                "shared_mse_checkpoint_verified": True,
            }
        )

    return {
        "rule": (
            "single frozen arm per benchmark and method; no confirmation-time "
            "selection; paired Student-t intervals across unseen data seeds"
        ),
        "source_sha256": source_sha256,
        "campaign_path": str(campaign_path),
        "selection_path": str(selection_path),
        "planned_run_count": len(variants),
        "completed_run_count": len(enriched),
        "benchmark_count": len(benchmarks),
        "methods": sorted(METHODS),
        "aggregates": aggregates,
        "paired_comparisons": paired,
        "anchored_correction_vs_embedded_mse": correction,
        "rankings": rankings,
        "selected_arms": selection.get("selected_arms"),
        "rows": enriched,
    }


def render_markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Broad cost-learning DFL confirmation",
        "",
        f"Rule: {report['rule']}.",
        "",
        f"Completion: {report['completed_run_count']}/"
        f"{report['planned_run_count']} frozen runs.",
    ]
    aggregates = report["aggregates"]
    for benchmark in sorted({row["benchmark_id"] for row in aggregates}):
        lines.extend(
            [
                "",
                f"## {benchmark}",
                "",
                "| Method | Mean regret | 95% t interval | Wall s | "
                "Training calls |",
                "| --- | ---: | ---: | ---: | ---: |",
            ]
        )
        benchmark_rows = [
            row for row in aggregates if row["benchmark_id"] == benchmark
        ]
        for row in sorted(benchmark_rows, key=lambda item: item["mean_test_regret"]):
            lower, upper = row["student_t_95_interval"]
            lines.append(
                f"| {row['method']} | {row['mean_test_regret']:.8g} | "
                f"[{lower:.8g}, {upper:.8g}] | "
                f"{row['mean_whole_pipeline_training_wall_seconds']:.3f} | "
                f"{row['mean_whole_pipeline_training_oracle_calls']:.0f} |"
            )
    lines.extend(
        [
            "",
            "## Paired differences (method minus baseline)",
            "",
            "Negative values favor the method.",
            "",
            "| Benchmark | Method | Baseline | Difference | 95% t interval | Wins |",
            "| --- | --- | --- | ---: | ---: | ---: |",
        ]
    )
    for row in report["paired_comparisons"]:
        lower, upper = row["student_t_95_interval"]
        lines.append(
            f"| {row['benchmark_id']} | {row['method']} | {row['baseline']} | "
            f"{row['mean_paired_regret_difference']:.8g} | "
            f"[{lower:.8g}, {upper:.8g}] | "
            f"{row['wins']}/{row['seed_count']} |"
        )
    lines.extend(
        [
            "",
            "## Anchored correction versus its identical embedded MSE base",
            "",
            "| Benchmark | Difference | 95% t interval | Wins |",
            "| --- | ---: | ---: | ---: |",
        ]
    )
    for row in report["anchored_correction_vs_embedded_mse"]:
        lower, upper = row["student_t_95_interval"]
        lines.append(
            f"| {row['benchmark_id']} | "
            f"{row['mean_correction_regret_difference']:.8g} | "
            f"[{lower:.8g}, {upper:.8g}] | "
            f"{row['wins']}/{row['seed_count']} |"
        )
    lines.extend(
        [
            "",
            "Test metrics were not used for hyperparameter selection. Training "
            "calls exclude data-generation and test-evaluation solves.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("selection", type=Path)
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    arguments = parser.parse_args()
    report = build_report(
        arguments.selection,
        arguments.campaign,
        source_sha256=arguments.source_sha256,
    )
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, report)
    arguments.markdown_output.write_text(render_markdown(report), encoding="utf-8")


if __name__ == "__main__":
    main()
