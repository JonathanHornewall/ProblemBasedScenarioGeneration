#!/usr/bin/env python3
"""Retrieve cloud results and remove exactly the run's remaining resources."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

from run_atlanta_baseline_timing import write


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run-id", required=True)
    p.add_argument("--bucket", required=True)
    p.add_argument("--output-root", type=Path, required=True)
    p.add_argument("--deadline-unix", type=float, required=True)
    args = p.parse_args()
    if (args.output_root / "CLOUD_CLEANUP.json").exists():
        return
    base = ["gcloud", "--configuration=jonathan", "--project=hornewall-compute"]
    remote = args.output_root / "remote"
    remote.mkdir(parents=True, exist_ok=True)

    def run(*command, check=True):
        return subprocess.run([*base, *command], text=True, capture_output=True,
                              check=check, timeout=180)

    def sync():
        return run("storage", "rsync", f"gs://{args.bucket}/results", str(remote),
                   "--recursive", "--checksums-only", check=False)

    while True:
        sync_result = sync()
        instances = json.loads(run("compute", "instances", "list",
            f"--filter=labels.run_id={args.run_id}", "--format=json").stdout)
        write(args.output_root / "cloud_status.json", {
            "run_id": args.run_id, "instances": [
                {k: i.get(k) for k in ("name", "status", "zone", "scheduling")} for i in instances],
            "last_sync_returncode": sync_result.returncode,
            "last_update_unix": time.time(), "deadline_unix": args.deadline_unix,
        })
        for instance in instances:
            if instance["status"] == "TERMINATED" or time.time() >= args.deadline_unix:
                if not instance["name"].startswith(args.run_id + "-"):
                    raise RuntimeError("Unexpected instance matched run label")
                zone = instance["zone"].split("/")[-1]
                serial = run("compute", "instances", "get-serial-port-output", instance["name"],
                             f"--zone={zone}", check=False)
                (args.output_root / f"{instance['name']}.serial.log").write_text(serial.stdout)
                if sync_result.returncode == 0:
                    run("compute", "instances", "delete", instance["name"], f"--zone={zone}", "--quiet")
        if not instances:
            break
        time.sleep(30)
    synced = sync()
    if synced.returncode:
        raise RuntimeError("Final result download failed; bucket retained")
    verified = 0
    for inventory in remote.glob("*/VERIFIED_UPLOADS.json"):
        for name, expected in json.loads(inventory.read_text()).items():
            path = (inventory.parent / name).resolve()
            if not path.is_relative_to(inventory.parent.resolve()) or not path.is_file():
                raise RuntimeError("Artifact inventory references a missing or invalid path")
            if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                raise RuntimeError("Artifact checksum mismatch; bucket retained")
            verified += 1
    # Final checksum-only rsync validates every stored object; explicit SHA-256
    # inventories additionally validate all gracefully completed VM uploads.
    run("storage", "rm", f"gs://{args.bucket}", "--recursive", "--quiet")
    disks = json.loads(run("compute", "disks", "list", "--format=json").stdout)
    owned = [d for d in disks if d["name"].startswith(args.run_id + "-")]
    for disk in owned:
        if disk.get("users"):
            raise RuntimeError("A run disk remains attached; refusing disk deletion")
        run("compute", "disks", "delete", disk["name"],
            "--zone=" + disk["zone"].split("/")[-1], "--quiet")
    subprocess.run([sys.executable, str(Path(__file__).with_name("summarize_atlanta_baseline_timing.py")),
                    "--manifest", str(args.output_root / "manifest.json"),
                    "--results", str(remote), "--output", str(args.output_root / "summary")], check=True)
    write(args.output_root / "CLOUD_CLEANUP.json", {
        "run_id": args.run_id, "bucket_deleted": True, "run_instances_remaining": 0,
        "explicit_sha256_checks": verified, "finished_unix": time.time(),
        "result_directory": str(remote),
    })


if __name__ == "__main__":
    main()
