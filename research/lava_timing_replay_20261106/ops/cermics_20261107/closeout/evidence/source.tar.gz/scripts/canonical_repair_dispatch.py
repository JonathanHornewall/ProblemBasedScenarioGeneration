"""One-off, stopped-campaign repair of the 2026-09-23 SPO dispatch race.

Archive every affected artifact; retain only unambiguous single-attempt screen
successes on the authority. Rebuild all SPO derived selections without reading
test scores. No data, seed, hyperparameter or scientific implementation changes.
"""
import argparse
import collections
import hashlib
import json
import shutil
import sqlite3
import time
from pathlib import Path

from build_central_path_final import read, write

REPAIR = "spo_dispatch_race_20260923"


def protected(root):
    paths = []
    for folder in ("receipts", "selections"):
        for path in (root / "results" / folder).glob("*.json"):
            if "__mse" in path.name or "__wise" in path.name:
                paths.append(path)
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(paths)}


def repair(root, role):
    archive = root / "infrastructure_repairs" / REPAIR
    if archive.exists():
        raise RuntimeError("Repair archive already exists; inspect rather than repeat")
    archive.mkdir(parents=True)
    before = protected(root)
    write(archive / "protected_before.json", before)

    def move(path):
        if path.exists():
            target = archive / "original" / path.relative_to(root)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(path), str(target))

    current = read(root / "execution.json") if (root / "execution.json").exists() else None
    retained = set()
    if role == "authority":
        screen = read(root / "screen.json")
        for job in screen["jobs"]:
            if job["method"] != "spo_plus":
                continue
            path = root / "results/receipts" / (job["id"] + ".json")
            attempts = list((root / "results/attempts" / job["id"]).glob("*"))
            if not path.exists() or len(attempts) != 1:
                continue
            record = read(path)
            if (record["status"] == "complete" and record["job"] == job
                    and record.get("test_access") is False
                    and not record.get("smoke_only")
                    and record.get("summary", {}).get("test") is None
                    and attempts[0].name == Path(record["attempt_directory"]).name
                    and (attempts[0] / "model.pt").exists()):
                retained.add(job["id"])

    archived_counts = collections.Counter()
    for folder in ("receipts", "progress", "interruptions", "logs", "attempts",
                   "resource_retries", "fit_locks"):
        for path in list((root / "results" / folder).glob("*")):
            job_id = path.name if path.is_dir() else path.name.rsplit(".", 1)[0]
            if "__spo_plus__" in job_id and job_id not in retained:
                archived_counts[folder] += 1
                move(path)
    for path in list((root / "results/selections").glob("*__spo_plus.json")):
        move(path)
        archived_counts["selections"] += 1
    for name in ("execution.json", "refinement.json", "confirmation.json"):
        move(root / name)
    for name in ("queue_status.json", "burst_status.json", "dispatch_status.json"):
        move(root / "results" / name)

    if role == "authority":
        # These directories include the immutable final, hash-verified cloud
        # retrieval before repair. Old SPO receipts must never be reimported.
        move(root / "cloud_retrieved")
        move(root / "imports")
        db = sqlite3.connect(root / "burst.sqlite")
        snapshot = sqlite3.connect(archive / "original" / "burst.sqlite")
        db.backup(snapshot)
        snapshot.close()
        spo_ids = [row[0] for row in db.execute("SELECT id,payload FROM jobs")
                   if json.loads(row[1])["method"] == "spo_plus"]
        db.executemany("DELETE FROM jobs WHERE id=?", [(j,) for j in spo_ids])
        db.commit()
        db.close()
        for path in (root / "leases").glob("*.json"):
            manifest = read(path)
            move(path)
            write(path, {**manifest, "jobs": [j for j in manifest["jobs"]
                                             if j["method"] != "spo_plus"]})
        from canonical_cluster import setup, connect
        pipeline = setup(root)
        db = connect(root)
        db.executemany("UPDATE jobs SET idx=? WHERE id=?",
                       [(i, j["id"]) for i, j in enumerate(pipeline.execution["jobs"])])
        db.commit()
        db.close()
        state = read(root / "burst_state.json")
        write(archive / "original_burst_state.json", state)
        write(root / "burst_state.json", {**state, "status": "stopped_for_dispatch_repair"})
    elif role == "cloud" and current is not None:
        write(root / "execution.json", {**current, "jobs": [j for j in current["jobs"]
                                                           if j["method"] != "spo_plus"]})

    after = protected(root)
    if before != after:
        raise RuntimeError("MSE/WISE preservation certificate failed")
    report = {
        "repair": REPAIR, "role": role, "updated_unix": time.time(),
        "protected_receipt_and_selection_count": len(before),
        "protected_sha256_unchanged": True,
        "retained_spo_screen_ids": sorted(retained),
        "archived_counts": dict(archived_counts),
        "test_scores_read_for_repair": False,
        "reason": "Stale dispatch-gate writes overwrote exclusive job ownership; duplicated attempts collided on deterministic progress temporary filenames.",
        "policy": "Keep only single-attempt complete SPO screen records; rebuild every SPO refinement and confirmation selection from the verified screen. Preserve all superseded attempts.",
    }
    write(archive / "repair.json", report)
    write(root / "REPAIR_STATE.json", report)
    print(json.dumps({k: v for k, v in report.items() if k != "retained_spo_screen_ids"}, sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--role", choices=("authority", "cloud", "mirror"), required=True)
    args = parser.parse_args()
    repair(args.root, args.role)
