"""Targeted Slurm campaign with exclusive local and cloud fit ownership."""

from __future__ import annotations

import argparse
import collections
import contextlib
import datetime
import json
import os
import random
import signal
import socket
import sqlite3
import subprocess
import time
from pathlib import Path

import psutil
from build_central_path_final import read, write
from central_path_cloud import allocation, geometry_group
from canonical_dispatch import apply_burst_gate, dispatch_state
from central_path_pipeline import Pipeline
from central_path_slurm import LIMITS, environment


def reservation(job):
    if job.get('linear_scale_revision') and job['route'] in (
            'dys_shortest_path_50x50','dys_cfl_500x10','dys_knapsack_1000x2',
            'lava_random_lp_800x50_released_code') and job['method'] != 'lava':
        return 12.0 if job['method'].startswith('central_path_') else 6.0
    if job["method"] == "intopt_original":
        return 5.0
    if job["method"] == "lava":
        return 44.0 if allocation(job) == "heavy" else 8.0
    return 0.65 if job["method"] in ("mse", "wise", "spo_plus") else 1.5


def dispatch_priority(job):
    if job.get("physical128_revision"):
        return 1 if job["stage"] == "reevaluation" else 0
    if job.get("normal_validation_revision"):
        return 0
    if job.get("validation_experiment"):
        return {"central_path_barrier_validation": 0, "central_path_hard_validation": 0,
                "mse": 1, "wise": 2, "spo_plus": 3, "lava": 4,
                "pfyl": 5, "nce": 6}[job["method"]]
    return {"mse": 0, "wise": 0, "spo_plus": 1, "central_path_barrier_validation": 2}[job["method"]]


def connect(root):
    db = sqlite3.connect(root / "burst.sqlite", timeout=60)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA busy_timeout=60000")
    return db


def key(job):
    if job['method'] == 'intopt_original':
        return json.dumps(['no_shared_preparation', job['id']])
    return json.dumps(geometry_group(job))


def enqueue(root, pipeline, db):
    contract = read(root / "burst_contract.json")
    owned = {tuple(x) for x in contract["groups"]}
    borrowed = set(contract.get("job_ids", []))
    deferred = set(dispatch_state(root, pipeline.execution["jobs"])["deferred_methods"])
    existing = {row[0] for row in db.execute("SELECT id FROM jobs")}
    inserted = 0
    for i, job in enumerate(pipeline.execution["jobs"]):
        if job["id"] in existing:
            continue
        if (job["cell"], job["method"]) not in owned and job["id"] not in borrowed:
            continue
        terminal = (root / "results/receipts" / (job["id"] + ".json")).exists()
        db.execute(
            "INSERT OR IGNORE INTO jobs(id,idx,payload,priority,stage_order,"
            "geom,category,reserved,status) VALUES(?,?,?,?,?,?,?,?,?)",
            (
                job["id"],
                i,
                json.dumps(job),
                dispatch_priority(job),
                {"confirmation": 0, "reevaluation": 0, "refinement": 1, "screen": 2}[job["stage"]],
                key(job),
                allocation(job),
                reservation(job),
                "terminal"
                if terminal
                else "deferred"
                if job["method"] in deferred
                else "pending",
            ),
        )
        inserted += 1
        if inserted % 32 == 0:
            # A large additive screen must not hold the shared SQLite write
            # lock beyond the live workers' timeout.
            db.commit()
    db.commit()


def setup(root):
    contract = read(root / "burst_contract.json")
    owned = {tuple(x) for x in contract["groups"]}
    pipeline = Pipeline(root)
    pipeline.groups = {k: v for k, v in pipeline.groups.items() if k in owned}
    if not (root / "burst_state.json").exists():
        job_id = os.environ.get("SLURM_JOB_ID")
        start, deadline = time.time(), time.time() + contract["maximum_seconds"]
        if job_id:
            info = subprocess.check_output(
                ["scontrol", "show", "job", job_id, "-o"], text=True
            )
            values = dict(x.split("=", 1) for x in info.split() if "=" in x)
            start = datetime.datetime.fromisoformat(values["StartTime"]).timestamp()
            deadline = min(
                start + contract["maximum_seconds"],
                datetime.datetime.fromisoformat(values["EndTime"]).timestamp(),
            )
        write(
            root / "burst_state.json",
            {
                "slurm_job_id": job_id,
                "started_unix": start,
                "deadline_unix": deadline,
                "maximum_workers": contract["maximum_workers"],
                "status": "running",
                "run_id": contract["run_id"],
            },
        )
    db = connect(root)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS jobs(
            id TEXT PRIMARY KEY, idx INTEGER, payload TEXT, priority INTEGER,
            stage_order INTEGER, geom TEXT, category TEXT, reserved REAL, status TEXT,
            host TEXT, worker INTEGER, started REAL, heartbeat REAL,
            rss REAL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS geometry(geom TEXT PRIMARY KEY, metadata TEXT);
        CREATE INDEX IF NOT EXISTS ready ON jobs(status, priority, stage_order, idx);
        CREATE INDEX IF NOT EXISTS ready_compact ON jobs(status,priority,stage_order,idx,geom,category,reserved,id);
        CREATE INDEX IF NOT EXISTS active_compact ON jobs(status,host,geom,category,reserved,rss);
    """)
    pipeline.refresh()
    enqueue(root, pipeline, db)
    db.close()
    return pipeline


def pending_rows(db):
    """Read small covering-index pages, not every large scientific payload."""
    after=(-1,-1,-1)
    while True:
        rows=db.execute(
            "SELECT id,idx,geom,category,reserved,priority,stage_order FROM jobs "
            "WHERE status='pending' AND (priority,stage_order,idx)>(?,?,?) "
            "ORDER BY priority,stage_order,idx LIMIT 64",after).fetchall()
        if not rows:
            return
        for row in rows:
            yield row
        after=(rows[-1]['priority'],rows[-1]['stage_order'],rows[-1]['idx'])


def claim(db, root, host, *, light_only, memory_gib, now=None):
    now = time.time() if now is None else now
    cutoff = float(os.environ.get("CPS_WORKER_CUTOFF", "inf"))
    drain = float(os.environ.get('CPS_DRAIN_DEADLINE', 'inf'))
    # The burst stops accepting new fits early enough for their unchanged
    # maximum wall time to finish before the absolute resource reduction.
    if now + 9090 >= drain:
        return None
    if now >= min(read(root / "burst_state.json")["deadline_unix"] - 30, cutoff):
        return None
    db.execute("BEGIN IMMEDIATE")
    try:
        if time.time() >= read(root / "burst_state.json")["deadline_unix"] - 30:
            db.commit()
            return None
        active = list(db.execute("SELECT host,reserved,rss,geom,category FROM jobs WHERE status='running'"))
        used = sum(
            max(r["reserved"], r["rss"] or 0) for r in active if r["host"] == host
        )
        cached = {
            r["geom"]: json.loads(r["metadata"])
            for r in db.execute("SELECT * FROM geometry")
        }
        ready = {
            k
            for k, m in cached.items()
            if m.get("retained") or m.get("status") != "complete"
        }
        cold_groups = {
            r["geom"]
            for r in active
            if r["category"] != "light" and r["geom"] not in ready
        }
        for row in pending_rows(db):
            if light_only and row["category"] != "light":
                continue
            if row["geom"] in cold_groups:
                continue
            if row["category"] == "heavy" and sum(
                r["host"] == host and r["category"] == "heavy" for r in active
            ) >= 2:
                continue
            reserve = row["reserved"]
            meta = cached.get(row["geom"])
            if meta and row["geom"] in ready:
                reserve = (
                    1.5
                    if meta["status"] != "complete"
                    else max(2.0, 1.5 + 2 * meta.get("serialized_bytes", 0) / 2**30)
                )
            if used + reserve > memory_gib:
                continue
            receipt = root / "results/receipts" / (row["id"] + ".json")
            if receipt.exists():
                db.execute("UPDATE jobs SET status='terminal' WHERE id=?", (row["id"],))
                continue
            db.execute(
                "UPDATE jobs SET status='running',host=?,worker=?,started=?,"
                "heartbeat=?,reserved=? WHERE id=?",
                (host, os.getpid(), now, now, reserve, row["id"]),
            )
            result = dict(
                db.execute("SELECT * FROM jobs WHERE id=?", (row["id"],)).fetchone()
            )
            db.commit()
            return result
        db.commit()
        return None
    except BaseException:
        db.rollback()
        raise


def terminate(child):
    with contextlib.suppress(ProcessLookupError):
        os.killpg(child.pid, signal.SIGTERM)
    try:
        child.wait(timeout=8)
    except subprocess.TimeoutExpired:
        with contextlib.suppress(ProcessLookupError):
            os.killpg(child.pid, signal.SIGKILL)
        child.wait(timeout=5)


def reconcile_terminal_rows(root, db):
    """A durable receipt also repairs a worker's interrupted status write."""
    rows=db.execute("SELECT id,status FROM jobs WHERE status IN ('running','external')").fetchall()
    for row in rows:
        if (root/'results/receipts'/(row['id']+'.json')).exists():
            db.execute("UPDATE jobs SET status='terminal',rss=0 WHERE id=? AND status=?",(row['id'],row['status']))
    db.commit()


def mark_finished(db, job_id, status, deadline):
    while True:
        try:
            db.execute("UPDATE jobs SET status=?,heartbeat=?,rss=0 WHERE id=?",(status,time.time(),job_id))
            db.commit()
            return
        except sqlite3.OperationalError as exc:
            db.rollback()
            if 'locked' not in str(exc).lower() and 'busy' not in str(exc).lower():
                raise
            if time.time() >= deadline:
                return  # The durable receipt remains authoritative.
            time.sleep(random.uniform(0.1,0.5))


def fit(root, row, db, stopping):
    job = json.loads(row["payload"])
    output = root / "results"
    (output / "logs").mkdir(parents=True, exist_ok=True)
    receipt = output / "receipts" / (job["id"] + ".json")
    progress = output / "progress" / (job["id"] + ".json")
    deadline = read(root / "burst_state.json")["deadline_unix"]
    # Match the child driver's per-job overrides, including the public-method
    # 9,000-second wall cap. Python alarms may wait for a native solve to return.
    limits = {**read(root / "screen.json")["protocol"], **job.get("resource_limits", {})}
    command = [
        str(root / "venv/bin/python"),
        str(root / "code/scripts/run_central_path_final.py"),
        "--manifest",
        str(root / "execution.json"),
        "--job-index",
        str(row["idx"]),
        "--output-root",
        str(output),
    ]
    reason, record = None, {}
    started = time.time()
    last_telemetry = 0.0
    with (output / "logs" / (job["id"] + ".log")).open("a") as log:
        child = subprocess.Popen(
            command,
            env=environment(root),
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            while child.poll() is None:
                now = time.time()
                record = read(progress) if progress.exists() else {}
                try:
                    proc = psutil.Process(child.pid)
                    rss = (
                        sum(
                            p.memory_info().rss
                            for p in [proc, *proc.children(recursive=True)]
                        )
                        / 2**30
                    )
                except psutil.Error:
                    rss = 0
                try:
                    db.execute("PRAGMA busy_timeout=100")
                    if now-last_telemetry < 12:
                        raise sqlite3.OperationalError('skip optional telemetry')
                    last_telemetry=now
                    db.execute(
                        "UPDATE jobs SET heartbeat=?,rss=? WHERE id=?",
                        (now, rss, job["id"]),
                    )
                    cache_key = record.get("geometry_cache_key")
                    cache_path = root / "geometry_cache" / (str(cache_key) + ".json")
                    if cache_key and cache_path.exists():
                        meta = read(cache_path)
                        db.execute(
                            "INSERT OR REPLACE INTO geometry VALUES(?,?)",
                            (row["geom"], json.dumps(meta)),
                        )
                        if meta.get("retained") or meta.get("status") != "complete":
                            reserve = (
                                1.5
                                if meta["status"] != "complete"
                                else max(
                                    2.0,
                                    1.5 + 2 * meta.get("serialized_bytes", 0) / 2**30,
                                )
                            )
                            db.execute(
                                "UPDATE jobs SET reserved=? WHERE id=?",
                                (reserve, job["id"]),
                            )
                    db.commit()
                except sqlite3.OperationalError:
                    # Telemetry failure must not terminate a healthy fit.
                    with contextlib.suppress(sqlite3.Error):
                        db.rollback()
                finally:
                    with contextlib.suppress(sqlite3.OperationalError):
                        db.execute("PRAGMA busy_timeout=60000")
                if stopping() or now >= min(deadline - 15, float(os.environ.get("CPS_WORKER_CUTOFF", "inf"))):
                    reason = "burst_deadline_interrupted"
                elif rss > LIMITS[row["category"]][1] * 0.9:
                    reason = "memory_cap"
                elif (
                    record.get("phase") in (None, "imports", "preprocessing")
                    and now - started > limits["preprocessing_cap_seconds"] + 15
                ):
                    reason = "preprocessing_time_cap"
                elif now - started > limits["job_wall_cap_seconds"] + 15:
                    reason = "wall_time_cap"
                if reason:
                    terminate(child)
                    break
                time.sleep(3)
        finally:
            if child.poll() is None:
                terminate(child)
    if not receipt.exists():
        interrupted = reason == "burst_deadline_interrupted"
        record.update(
            job=job,
            status="interrupted" if interrupted else "censored",
            error=reason or "child_exit_without_receipt",
            returncode=child.returncode,
            total_wall_seconds=time.time() - started,
            finished_unix=time.time(),
        )
        write(
            (output / "interruptions" / receipt.name) if interrupted else receipt,
            record,
        )
        cache_key = record.get("geometry_cache_key")
        cache_path = root / "geometry_cache" / (str(cache_key) + ".json")
        if (
            not interrupted
            and cache_key
            and not cache_path.exists()
            and record.get("phase") == "preprocessing"
        ):
            meta = {
                "status": "censored",
                "resource_limited": True,
                "error": record["error"],
                "error_type": "ResourceLimit",
                "seconds": time.time() - started,
                "origin_job": job["id"],
            }
            write(cache_path, meta)
            try:
                db.execute("INSERT OR REPLACE INTO geometry VALUES(?,?)",(row['geom'],json.dumps(meta)))
                db.commit()
            except sqlite3.OperationalError:
                db.rollback()  # The immutable cache file is already durable.
    mark_finished(db,job['id'],'terminal' if receipt.exists() else 'interrupted',deadline)


def worker(root, light_only, memory_gib):
    stop = False

    def stopping(signum, frame):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, stopping)
    signal.signal(signal.SIGINT, stopping)
    db = connect(root)
    host = socket.gethostname()
    try:
        while (
            not stop
            and time.time() < min(read(root / "burst_state.json")["deadline_unix"] - 30, float(os.environ.get("CPS_WORKER_CUTOFF", "inf")))
        ):
            if psutil.virtual_memory().available < 4 * 2**30:
                time.sleep(3)
                continue
            try:
                row = claim(db, root, host, light_only=light_only, memory_gib=memory_gib)
            except sqlite3.OperationalError as exc:
                db.rollback()
                if 'locked' not in str(exc).lower() and 'busy' not in str(exc).lower():
                    raise
                time.sleep(random.uniform(0.1,0.5))
                continue
            if row is not None:
                fit(root, row, db, lambda: stop)
            else:
                if read(root / "burst_state.json").get("status") == "complete":
                    break
                time.sleep(3)
    finally:
        db.close()


def coordinate(root):
    import fcntl
    coordinator_guard=(root/'coordinator.lock').open('a')
    fcntl.flock(coordinator_guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
    pipeline = setup(root)
    db = connect(root)
    deadline = read(root / "burst_state.json")["deadline_unix"]
    try:
        while time.time() < deadline - 10:
            # Cloud receipts are published only after their artifacts are imported.
            reconcile_terminal_rows(root,db)
            db.execute("UPDATE jobs SET status='pending', host=NULL, worker=NULL WHERE status='interrupted'")
            db.commit()
            dispatch = dispatch_state(root, pipeline.execution["jobs"])
            apply_burst_gate(db, dispatch["deferred_methods"])
            pipeline.refresh()
            enqueue(root, pipeline, db)
            counts = dict(
                db.execute(
                    "SELECT status,COUNT(*) FROM jobs GROUP BY status"
                ).fetchall()
            )
            records = list(
                db.execute(
                    "SELECT payload,status,host,started,heartbeat,rss "
                    "FROM jobs WHERE status='running'"
                )
            )
            write(
                root / "results/burst_status.json",
                {
                    "updated_unix": time.time(),
                    "deadline_unix": deadline,
                    "counts": counts,
                    "running_by_method": dict(
                        collections.Counter(
                            json.loads(r["payload"])["method"] for r in records
                        )
                    ),
                    "running_by_host": dict(
                        collections.Counter(r["host"] for r in records)
                    ),
                    "rss_gib": sum(r["rss"] for r in records),
                    "selected_refinement_groups": len(pipeline.frozen["refinement"]),
                    "selected_confirmation_groups": len(
                        pipeline.frozen["confirmation"]
                    ),
                    "expected_groups": len(pipeline.groups),
                    "deferred_methods": dispatch["deferred_methods"],
                },
            )
            if (len(pipeline.frozen['confirmation']) == len(pipeline.groups)
                    and not any(counts.get(k) for k in ("pending", "running", "external", "deferred", "interrupted"))):
                state = read(root / "burst_state.json")
                state.update(
                    status="complete"
                    if not counts.get("interrupted")
                    else "incomplete",
                    finished_unix=time.time(),
                )
                write(root / "burst_state.json", state)
                return
            time.sleep(5)
    finally:
        db.close()


def lease(root, host, count):
    """Idempotent cloud refill. Leases never expire or get silently reissued."""
    from frozen_campaign_data import data_key
    from exact_validation_reference import needs_analytic_reference_file, analytic_reference_name
    prefetch=root/'lease_prefetch.json'
    if prefetch.exists():
        count=int(read(prefetch).get('unfinished_jobs_by_host',{}).get(host,count))
    db = connect(root)
    try:
        active = db.execute("SELECT COUNT(*) FROM jobs WHERE status='external' AND host=?", (host,)).fetchone()[0]
        candidates=[]
        available={}
        if active<count and time.time() < read(root / "burst_state.json")["deadline_unix"] - 300:
            # File delivery checks can involve network storage. Never perform
            # them while excluding every cluster worker from the write lock.
            for row in db.execute("SELECT id,payload FROM jobs WHERE status='pending' ORDER BY priority,stage_order,idx").fetchall():
                if len(candidates)>=2*(count-active):
                    break
                job = json.loads(row["payload"])
                # Keep geometry-heavy LAVA preprocessing on CERMICS, where the
                # original cached geometry and 44-GiB reservations are enforced.
                if job.get("method") == "lava" or job.get("execution_repair"):
                    continue
                if job.get('physical128_revision'):
                    from physical128_data import bank_key
                    bank = root/'frozen_data'/bank_key(job)
                    required = [bank/n for n in ('receipt.json','observations.npz','structure.npz','structure.json','test.npz')]
                else:
                    required=[root/'frozen_data'/(data_key(job)+'.npz')]
                if needs_analytic_reference_file(job):
                    required.append(root/'frozen_validation'/analytic_reference_name(job))
                for path in required:
                    if path not in available:available[path]=path.exists()
                if not all(available[path] for path in required):
                    continue
                candidates.append(row['id'])
        if candidates:
            db.execute('BEGIN IMMEDIATE')
            active=db.execute("SELECT COUNT(*) FROM jobs WHERE status='external' AND host=?",(host,)).fetchone()[0]
            for job_id in candidates:
                if active>=count:break
                changed=db.execute("UPDATE jobs SET status='external',host=?,started=?,heartbeat=? WHERE id=? AND status='pending'",(host,time.time(),time.time(),job_id)).rowcount
                active+=changed
            db.commit()
        path = root / "leases" / (host + ".json")
        manifest = read(path) if path.exists() else {**read(root / "screen.json"),"jobs":[]}
        known = {j["id"] for j in manifest["jobs"]}
        for row in db.execute("SELECT id,payload FROM jobs WHERE host=? ORDER BY started,idx",(host,)):
            if row["id"] not in known:
                manifest["jobs"].append(json.loads(row["payload"]))
        write(path,manifest)
        return {"manifest":str(path),"jobs":len(manifest["jobs"]),"unfinished":active}
    finally:
        db.close()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("action", choices=("init", "coordinate", "worker", "lease"))
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--light-only", action="store_true")
    p.add_argument("--memory-gib", type=float, default=175)
    p.add_argument("--host")
    p.add_argument("--count", type=int, default=128)
    args = p.parse_args()
    root = args.root.resolve()
    if args.action == "init":
        setup(root)
    elif args.action == "coordinate":
        while time.time()<read(root/'burst_state.json')['deadline_unix']-10:
            try:
                coordinate(root)
                break
            except sqlite3.OperationalError as exc:
                if 'locked' not in str(exc).lower() and 'busy' not in str(exc).lower():
                    raise
                print('Retrying coordinator after shared-database contention',flush=True)
                time.sleep(random.uniform(0.2,0.8))
    elif args.action == "lease":
        if args.host not in ("hornewall", "tito"):
            raise ValueError("unknown cloud owner")
        print(json.dumps(lease(root,args.host,args.count)))
    else:
        worker(root, args.light_only, args.memory_gib)


if __name__ == "__main__":
    main()
