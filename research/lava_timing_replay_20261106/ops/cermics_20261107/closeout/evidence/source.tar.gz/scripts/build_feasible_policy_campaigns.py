"""Build staged comparisons of solver-free and QP-projected direct policies."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from proximal_spo.artifacts import source_sha256, write_json
from proximal_spo.config import RunSpec

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPO_ROOT / "configs" / "feasible_policies"

DEVELOPMENT_SEEDS = (1, 2, 3)
CONFIRMATION_SEEDS = (31, 32, 33, 34, 35)
LEARNING_RATES = (1e-4, 3e-4, 1e-3, 3e-3, 1e-2)
WEIGHT_DECAYS = (0.0, 1e-6, 1e-5)
SOFT_MINIMUM_SCALES = (0.01, 0.05, 0.1, 0.3)
SOFT_EFFECTIVE_RATES = (1e-5, 3e-5, 1e-4)
LOG_LEARNING_RATES = (3e-4, 1e-3, 3e-3)
LOG_SCHEDULES = (
    (0.0001, 0.0001),
    (0.001, 0.001),
    (0.01, 0.01),
    (0.1, 0.1),
    (1.0, 1.0),
    (0.1, 0.001),
    (0.1, 0.0001),
    (1.0, 0.1),
    (1.0, 0.01),
    (1.0, 0.001),
    (1.0, 0.0001),
)


@dataclass(frozen=True)
class BenchmarkDesign:
    benchmark_id: str
    tag: str
    interface: str
    law: dict[str, Any]


DESIGNS = (
    BenchmarkDesign(
        "cost.topk20x5",
        "topk",
        "full",
        {
            "context_dimension": 8,
            "random_fraction": 1.0,
            "style": "positive",
            "noise": "pyepo_uniform",
            "noise_scale": 0.5,
            "signal_scale": 1.0,
            "polynomial_degree": 4,
        },
    ),
    BenchmarkDesign(
        "cost.grid5",
        "grid",
        "partial",
        {
            "context_dimension": 5,
            "random_fraction": 0.25,
            "style": "positive",
            "noise": "pyepo_uniform",
            "noise_scale": 0.5,
            "signal_scale": 1.0,
            "polynomial_degree": 6,
        },
    ),
    BenchmarkDesign(
        "cost.assignment10",
        "assignment",
        "full",
        {
            "context_dimension": 12,
            "random_fraction": 1.0,
            "style": "positive",
            "noise": "pyepo_uniform",
            "noise_scale": 0.5,
            "signal_scale": 1.0,
            "polynomial_degree": 4,
        },
    ),
    BenchmarkDesign(
        "cost.knapsack50x5",
        "knapsack",
        "partial",
        {
            "context_dimension": 10,
            "random_fraction": 0.3,
            "style": "negative",
            "noise": "lognormal",
            "noise_scale": 0.35,
            "signal_scale": 0.8,
            "polynomial_degree": 2,
        },
    ),
    BenchmarkDesign(
        "cost.facility30x5_relaxation",
        "facility",
        "partial",
        {
            "context_dimension": 12,
            "random_fraction": 0.25,
            "style": "positive",
            "noise": "lognormal",
            "noise_scale": 0.35,
            "signal_scale": 0.7,
            "polynomial_degree": 2,
        },
    ),
    BenchmarkDesign(
        "cost.random_lp100x50",
        "randomlp",
        "partial",
        {
            "context_dimension": 8,
            "random_fraction": 0.25,
            "style": "signed",
            "noise": "gaussian",
            "noise_scale": 0.25,
            "signal_scale": 0.8,
            "polynomial_degree": 2,
        },
    ),
)


def _tag(value: float) -> str:
    return f"{value:.0e}".replace("-", "m").replace("+", "p")


def _seeds(seed: int) -> dict[str, int]:
    return {
        "data": seed,
        "structural": 101,
        "initialization": 200 + seed,
        "shuffle": 300 + seed,
        "perturbation": 400 + seed,
    }


def _base(design: BenchmarkDesign, seed: int) -> dict[str, Any]:
    return {
        "name": "base",
        "benchmark_id": design.benchmark_id,
        "method": "rayen_policy",
        "interface": design.interface,
        "workers": 4,
        "sizes": {"train": 512, "validation": 256, "test": 512},
        "law": copy.deepcopy(design.law),
        "model": {
            "depth": 2,
            "width": 64,
            "activation": "silu",
            "layer_norm": False,
            "correction_depth": 2,
            "correction_width": 64,
        },
        "training": {
            "epochs": 120,
            "batch_size": 128,
            "learning_rate": 1e-3,
            "weight_decay": 0.0,
            "optimizer": "adamw",
            "gradient_clip": 10.0,
            "validation_interval": 5,
            "patience": 20,
            "minimum_delta": 1e-6,
            "evaluation_batch_size": 512,
            "torch_threads": 2,
            "selection_mode": "validation_regret",
        },
        "seeds": _seeds(seed),
        "method_parameters": {},
    }


def _variant(
    design: BenchmarkDesign,
    seed: int,
    *,
    method: str,
    suffix: str,
    learning_rate: float,
    method_parameters: dict[str, Any],
    weight_decay: float = 0.0,
) -> dict[str, Any]:
    result = _base(design, seed)
    result["name"] = f"{design.tag}_s{seed}_{suffix}"
    result["method"] = method
    result["training"]["learning_rate"] = learning_rate
    result["training"]["weight_decay"] = weight_decay
    result["method_parameters"] = method_parameters
    return result


def _smoke_variants() -> list[dict[str, Any]]:
    solver_free: list[dict[str, Any]] = []
    qp: list[dict[str, Any]] = []
    for design in DESIGNS:
        methods: tuple[tuple[str, str, dict[str, Any]], ...] = (
            ("rayen_policy", "rayen", {}),
            (
                "soft_radial_policy",
                "soft",
                {
                    "contraction": "rational",
                    "contraction_scale": 1.0,
                    "minimum_scale": 0.01,
                },
            ),
            (
                "log_energy_policy",
                "logenergy",
                {"mu_start": 0.3, "mu_end": 0.03},
            ),
        )
        for method, suffix, parameters in methods:
            row = _variant(
                design,
                DEVELOPMENT_SEEDS[0],
                method=method,
                suffix=f"smoke_{suffix}",
                learning_rate=1e-3,
                method_parameters=parameters,
            )
            row["workers"] = 1
            row["sizes"] = {"train": 64, "validation": 32, "test": 32}
            row["model"].update({"width": 16, "depth": 1})
            row["training"].update(
                {
                    "epochs": 2,
                    "batch_size": 32,
                    "validation_interval": 1,
                    "patience": 2,
                    "torch_threads": 1,
                }
            )
            solver_free.append(row)
        row = _variant(
            design,
            DEVELOPMENT_SEEDS[0],
            method="direct_projection",
            suffix="smoke_qp_projection",
            learning_rate=1e-3,
            method_parameters={},
        )
        row["workers"] = 1
        row["sizes"] = {"train": 64, "validation": 32, "test": 32}
        row["model"].update({"width": 16, "depth": 1})
        row["training"].update(
            {
                "epochs": 2,
                "batch_size": 32,
                "validation_interval": 1,
                "patience": 2,
                "torch_threads": 1,
            }
        )
        qp.append(row)
    return solver_free + qp


def _screen_variants() -> list[dict[str, Any]]:
    solver_free: list[dict[str, Any]] = []
    qp: list[dict[str, Any]] = []
    seed = DEVELOPMENT_SEEDS[0]
    for design in DESIGNS:
        for rate in LEARNING_RATES:
            for decay in WEIGHT_DECAYS:
                solver_free.append(
                    _variant(
                        design,
                        seed,
                        method="rayen_policy",
                        suffix=f"rayen_lr{_tag(rate)}_wd{_tag(decay)}",
                        learning_rate=rate,
                        weight_decay=decay,
                        method_parameters={},
                    )
                )

        soft_arms = {
            (scale, minimum, effective_rate, 0.0)
            for scale in (0.1, 1.0, 10.0)
            for minimum in SOFT_MINIMUM_SCALES
            for effective_rate in SOFT_EFFECTIVE_RATES
        }
        soft_arms.update(
            (1.0, 0.1, 1e-4, decay) for decay in WEIGHT_DECAYS[1:]
        )
        for scale, minimum, effective_rate, decay in sorted(soft_arms):
            # J(0)=minimum_scale*I, so tune the center-step scale jointly
            # rather than comparing the same raw Adam rate across epsilons.
            rate = effective_rate / minimum
            solver_free.append(
                _variant(
                    design,
                    seed,
                    method="soft_radial_policy",
                    suffix=(
                        f"soft_scale{_tag(scale)}_eps{_tag(minimum)}_"
                        f"elr{_tag(effective_rate)}_wd{_tag(decay)}"
                    ),
                    learning_rate=rate,
                    weight_decay=decay,
                    method_parameters={
                        "contraction": "rational",
                        "contraction_scale": scale,
                        "minimum_scale": minimum,
                    },
                )
            )

        log_arms = {
            (start, end, rate, 0.0)
            for start, end in LOG_SCHEDULES
            for rate in LOG_LEARNING_RATES
        }
        log_arms.update(
            (0.1, 0.001, 1e-3, decay) for decay in WEIGHT_DECAYS[1:]
        )
        for start, end, rate, decay in sorted(log_arms):
            solver_free.append(
                _variant(
                    design,
                    seed,
                    method="log_energy_policy",
                    suffix=(
                        f"logenergy_mu{_tag(start)}to{_tag(end)}_"
                        f"lr{_tag(rate)}_wd{_tag(decay)}"
                    ),
                    learning_rate=rate,
                    weight_decay=decay,
                    method_parameters={"mu_start": start, "mu_end": end},
                )
            )

        for rate in LEARNING_RATES:
            for decay in WEIGHT_DECAYS:
                qp.append(
                    _variant(
                        design,
                        seed,
                        method="direct_projection",
                        suffix=(
                            f"qp_projection_lr{_tag(rate)}_wd{_tag(decay)}"
                        ),
                        learning_rate=rate,
                        weight_decay=decay,
                        method_parameters={},
                    )
                )
    return solver_free + qp


def _load(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected an object in {path}")
    return payload


def _canonical_sha256(payload: Any) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _arm_identity(config: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    arm = {key: value for key, value in config.items() if key not in {"name", "seeds"}}
    return _canonical_sha256(arm), arm


def _resolve_receipt_path(value: str) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (REPO_ROOT / path).resolve()


def _verify_selection(
    selection: dict[str, Any], *, campaign_name: str
) -> dict[str, Any]:
    """Authenticate a validation summary against configs and run receipts."""

    campaign_path = CONFIG_ROOT / f"{campaign_name}.json"
    campaign = _load(campaign_path)
    variants = campaign.get("variants")
    if not isinstance(variants, list) or not all(
        isinstance(row, dict) for row in variants
    ):
        raise ValueError(f"malformed campaign {campaign_path}")
    current_source = source_sha256(REPO_ROOT)
    if selection.get("source_sha256") != current_source:
        raise ValueError("selection source hash does not match current executable")
    expected_root = (REPO_ROOT / str(campaign["run_root"])).resolve()
    raw_root = selection.get("run_root")
    if (
        not isinstance(raw_root, str)
        or _resolve_receipt_path(raw_root) != expected_root
    ):
        raise ValueError("selection run_root does not match its declared campaign")

    expected = {
        (str(row["name"]), _arm_identity(row)[0]) for row in variants
    }
    candidates = selection.get("candidate_rows")
    if not isinstance(candidates, list) or not all(
        isinstance(row, dict) for row in candidates
    ):
        raise ValueError("selection lacks candidate_rows")
    observed = {
        (str(row.get("name")), str(row.get("arm_sha256"))) for row in candidates
    }
    if observed != expected or len(candidates) != len(expected):
        raise ValueError("selection does not cover the exact declared campaign")

    grouped: dict[tuple[str, str, str], dict[str, list[float]]] = {}
    for candidate in candidates:
        if candidate.get("source_sha256") != current_source:
            raise ValueError("candidate source hash does not match selection")
        directory_value = candidate.get("run_directory")
        if not isinstance(directory_value, str):
            raise ValueError("candidate lacks run_directory")
        directory = _resolve_receipt_path(directory_value)
        if expected_root not in directory.parents:
            raise ValueError("candidate run lies outside the campaign root")
        status = _load(directory / "status.json")
        config = _load(directory / "config.json")
        environment = _load(directory / "environment.json")
        summary = _load(directory / "summary.json")
        if status.get("status") != "complete":
            raise ValueError("candidate run is not complete")
        arm_sha, arm = _arm_identity(config)
        if (
            config.get("name") != candidate.get("name")
            or arm_sha != candidate.get("arm_sha256")
            or arm != candidate.get("arm")
            or config.get("seeds") != candidate.get("seeds")
        ):
            raise ValueError("candidate receipt does not match its run config")
        if environment.get("source_sha256") != current_source:
            raise ValueError("candidate environment has the wrong source hash")
        validation = summary.get("best_validation")
        if not isinstance(validation, dict):
            raise ValueError("candidate run lacks validation metrics")
        regret = float(validation["mean_regret"])
        if abs(regret - float(candidate["validation_mean_regret"])) > 1e-12:
            raise ValueError("candidate validation metric does not match its run")
        study = (
            str(candidate["benchmark_id"]),
            str(candidate["interface"]),
            str(candidate["method"]),
        )
        grouped.setdefault(study, {}).setdefault(arm_sha, []).append(regret)

    selected_rows = selection.get("selected_arms")
    if not isinstance(selected_rows, list) or not all(
        isinstance(row, dict) for row in selected_rows
    ):
        raise ValueError("selection lacks selected_arms")
    selected_by_study = {
        (str(row["benchmark_id"]), str(row["interface"]), str(row["method"])): row
        for row in selected_rows
    }
    if set(selected_by_study) != set(grouped):
        raise ValueError("selection studies do not match candidate studies")
    for study, arms in grouped.items():
        winner = min(
            arms,
            key=lambda arm_sha: (sum(arms[arm_sha]) / len(arms[arm_sha]), arm_sha),
        )
        selected = selected_by_study[study]
        selected_sha, selected_arm = _arm_identity(
            {**selected["arm"], "name": "ignored", "seeds": {}}
        )
        if selected.get("arm_sha256") != winner or selected_sha != winner:
            raise ValueError("selected arm is not the validation winner")
        if selected_arm != selected["arm"]:
            raise ValueError("selected arm hash is malformed")
    return selection


def _selected_arm(
    selection: dict[str, Any], benchmark_id: str, method: str
) -> dict[str, Any]:
    rows = selection.get("selected_arms")
    if not isinstance(rows, list):
        raise ValueError("selection receipt lacks selected_arms")
    matches = [
        row
        for row in rows
        if row.get("benchmark_id") == benchmark_id and row.get("method") == method
    ]
    if len(matches) != 1 or not isinstance(matches[0].get("arm"), dict):
        raise ValueError(f"missing selected {benchmark_id}/{method} arm")
    return copy.deepcopy(matches[0]["arm"])


def _top_arms(
    selection: dict[str, Any], benchmark_id: str, method: str, *, count: int
) -> list[dict[str, Any]]:
    candidates = selection["candidate_rows"]
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in candidates:
        if row["benchmark_id"] == benchmark_id and row["method"] == method:
            grouped.setdefault(str(row["arm_sha256"]), []).append(row)
    ranked = sorted(
        grouped.values(),
        key=lambda rows: (
            sum(float(row["validation_mean_regret"]) for row in rows) / len(rows),
            str(rows[0]["arm_sha256"]),
        ),
    )
    if len(ranked) < count:
        raise ValueError(
            f"fewer than {count} candidate arms for {benchmark_id}/{method}"
        )
    return [copy.deepcopy(rows[0]["arm"]) for rows in ranked[:count]]


def _replace(arm: dict[str, Any], path: tuple[str, ...], value: Any) -> dict[str, Any]:
    result = copy.deepcopy(arm)
    cursor: dict[str, Any] = result
    for key in path[:-1]:
        child = cursor[key]
        if not isinstance(child, dict):
            raise ValueError(f"cannot refine non-object path {path}")
        cursor = child
    cursor[path[-1]] = value
    return result


def _nearest_grid_index(value: float, grid: tuple[float, ...]) -> int:
    distances = [abs(candidate - value) for candidate in grid]
    index = min(range(len(grid)), key=distances.__getitem__)
    if not np.isclose(value, grid[index], rtol=1e-12, atol=1e-15):
        raise ValueError(f"value {value} is not represented by grid {grid}")
    return index


def _local_and_boundary_expansions(
    arm: dict[str, Any], method: str
) -> list[dict[str, Any]]:
    """Add local neighbors and mandatory outward arms at selected boundaries."""

    result = [copy.deepcopy(arm)]
    training = arm["training"]
    parameters = arm["method_parameters"]
    rate = float(training["learning_rate"])
    decay = float(training["weight_decay"])
    if method == "soft_radial_policy":
        minimum = float(parameters["minimum_scale"])
        effective_rate = rate * minimum
        effective_grid = (3e-6, *SOFT_EFFECTIVE_RATES, 3e-4)
        index = _nearest_grid_index(effective_rate, effective_grid)
        for candidate in effective_grid[max(0, index - 1) : index + 2]:
            result.append(
                _replace(arm, ("training", "learning_rate"), candidate / minimum)
            )
        scale = float(parameters["contraction_scale"])
        scale_grid = (0.03, 0.1, 0.3, 1.0, 3.0, 10.0, 30.0)
        scale_index = _nearest_grid_index(scale, scale_grid)
        for candidate in scale_grid[max(0, scale_index - 1) : scale_index + 2]:
            result.append(
                _replace(arm, ("method_parameters", "contraction_scale"), candidate)
            )
        minimum_grid = (0.003, *SOFT_MINIMUM_SCALES, 0.5)
        minimum_index = _nearest_grid_index(minimum, minimum_grid)
        for candidate in minimum_grid[max(0, minimum_index - 1) : minimum_index + 2]:
            candidate_arm = _replace(
                arm, ("method_parameters", "minimum_scale"), candidate
            )
            candidate_arm["training"]["learning_rate"] = effective_rate / candidate
            result.append(candidate_arm)
    elif method == "log_energy_policy":
        log_rate_grid: tuple[float, ...] = (1e-4, *LOG_LEARNING_RATES, 1e-2)
        index = _nearest_grid_index(rate, log_rate_grid)
        for candidate_rate in log_rate_grid[max(0, index - 1) : index + 2]:
            result.append(
                _replace(arm, ("training", "learning_rate"), candidate_rate)
            )
        start = float(parameters["mu_start"])
        end = float(parameters["mu_end"])
        for candidate in (start / 3.0, start * 3.0):
            if candidate >= end:
                result.append(
                    _replace(arm, ("method_parameters", "mu_start"), candidate)
                )
        for candidate in (end / 3.0, end * 3.0):
            if candidate <= start:
                result.append(
                    _replace(arm, ("method_parameters", "mu_end"), candidate)
                )
    else:
        base_rate_grid: tuple[float, ...] = (3e-5, *LEARNING_RATES, 3e-2)
        index = _nearest_grid_index(rate, base_rate_grid)
        for candidate_rate in base_rate_grid[max(0, index - 1) : index + 2]:
            result.append(
                _replace(arm, ("training", "learning_rate"), candidate_rate)
            )
    decay_grid = (*WEIGHT_DECAYS, 1e-4)
    decay_index = _nearest_grid_index(decay, decay_grid)
    for candidate in decay_grid[max(0, decay_index - 1) : decay_index + 2]:
        result.append(_replace(arm, ("training", "weight_decay"), candidate))
    unique: dict[str, dict[str, Any]] = {}
    for candidate_arm in result:
        key = _arm_identity(
            {**candidate_arm, "name": "ignored", "seeds": {}}
        )[0]
        unique[key] = candidate_arm
    return list(unique.values())


def _instantiate(
    arm: dict[str, Any], *, design: BenchmarkDesign, seed: int, suffix: str
) -> dict[str, Any]:
    row = copy.deepcopy(arm)
    row["name"] = f"{design.tag}_s{seed}_{suffix}"
    row["seeds"] = _seeds(seed)
    return row


def _refinement(selection: dict[str, Any]) -> list[dict[str, Any]]:
    solver_free: list[dict[str, Any]] = []
    qp: list[dict[str, Any]] = []
    for design in DESIGNS:
        for method in (
            "rayen_policy",
            "soft_radial_policy",
            "log_energy_policy",
            "direct_projection",
        ):
            top = _top_arms(selection, design.benchmark_id, method, count=3)
            candidate_arms = top + _local_and_boundary_expansions(top[0], method)
            unique = {
                _arm_identity({**arm, "name": "ignored", "seeds": {}})[0]: arm
                for arm in candidate_arms
            }
            target = qp if method == "direct_projection" else solver_free
            for seed in DEVELOPMENT_SEEDS:
                for index, candidate_arm in enumerate(unique.values()):
                    target.append(
                        _instantiate(
                            candidate_arm,
                            design=design,
                            seed=seed,
                            suffix=f"{method}_refine_p{index}",
                        )
                    )
    return solver_free + qp


def _confirmation(selection: dict[str, Any]) -> list[dict[str, Any]]:
    solver_free: list[dict[str, Any]] = []
    qp: list[dict[str, Any]] = []
    for design in DESIGNS:
        for method in (
            "rayen_policy",
            "soft_radial_policy",
            "log_energy_policy",
            "direct_projection",
        ):
            selected = _selected_arm(selection, design.benchmark_id, method)
            target = qp if method == "direct_projection" else solver_free
            for seed in CONFIRMATION_SEEDS:
                target.append(
                    _instantiate(
                        selected,
                        design=design,
                        seed=seed,
                        suffix=f"confirm_{method}",
                    )
                )
    return solver_free + qp


def _write(
    path: Path,
    *,
    name: str,
    run_root: str,
    variants: list[dict[str, Any]],
    predecessor: dict[str, Any] | None = None,
) -> None:
    if not variants:
        raise ValueError("campaign has no variants")
    for row in variants:
        RunSpec.from_dict(row)
    payload: dict[str, Any] = {
        "name": name,
        "run_root": run_root,
        "base": _base(DESIGNS[0], DEVELOPMENT_SEEDS[0]),
        "variants": variants,
        "ordering": "all solver-free runs precede QP projection runs in the file",
        "source_sha256_at_generation": source_sha256(REPO_ROOT),
    }
    if predecessor is not None:
        payload["predecessor"] = {
            "selection_sha256": _canonical_sha256(predecessor),
            "source_sha256": predecessor["source_sha256"],
            "run_root": predecessor["run_root"],
        }
    write_json(path, payload)


def main() -> int:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="stage", required=True)
    subparsers.add_parser("smoke")
    subparsers.add_parser("screen")
    refinement = subparsers.add_parser("refine")
    refinement.add_argument("--selection", type=Path, required=True)
    confirmation = subparsers.add_parser("confirmation")
    confirmation.add_argument("--selection", type=Path, required=True)
    arguments = parser.parse_args()
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    if arguments.stage == "smoke":
        _write(
            CONFIG_ROOT / "smoke.json",
            name="feasible_policy_smoke",
            run_root="runs/feasible_policies/smoke",
            variants=_smoke_variants(),
        )
    elif arguments.stage == "screen":
        _write(
            CONFIG_ROOT / "development_screen.json",
            name="feasible_policy_development_screen",
            run_root="runs/feasible_policies/development_screen",
            variants=_screen_variants(),
        )
    elif arguments.stage == "refine":
        selection = _verify_selection(
            _load(arguments.selection), campaign_name="development_screen"
        )
        _write(
            CONFIG_ROOT / "development_refinement.json",
            name="feasible_policy_development_refinement",
            run_root="runs/feasible_policies/development_refinement",
            variants=_refinement(selection),
            predecessor=selection,
        )
    elif arguments.stage == "confirmation":
        selection = _verify_selection(
            _load(arguments.selection), campaign_name="development_refinement"
        )
        _write(
            CONFIG_ROOT / "confirmation.json",
            name="feasible_policy_confirmation",
            run_root="runs/feasible_policies/confirmation",
            variants=_confirmation(selection),
            predecessor=selection,
        )
    else:
        raise AssertionError(arguments.stage)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
