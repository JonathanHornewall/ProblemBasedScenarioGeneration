"""Upstream-only extension of observed banks, with unchanged held-out files."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import socket

import numpy as np

from physical128_data import array_hash, json_value
from pilot_common import read, sha, write
from scaled_data_neural_campaign import REVISION
from simplified_data import load_structure


def route_factory(route):
    """Use the actual archived physical factories and their fixed source seeds."""
    from dfl_extensions_lab.benchmarks.families.published_single_stage import (
        make_dys_capacitated_facility_location, make_dys_shortest_path,
        make_dys_two_dimensional_knapsack, make_lava_random_lp)
    if route.startswith('dys_shortest_path_'):
        a,b = map(int, route.removeprefix('dys_shortest_path_').split('x'))
        if a != b:
            raise ValueError('Unregistered rectangular route')
        return make_dys_shortest_path(grid_size=a)
    if route.startswith('dys_cfl_'):
        a,b = map(int, route.removeprefix('dys_cfl_').split('x'))
        return make_dys_capacitated_facility_location(customers=a,facilities=b)
    if route.startswith('dys_knapsack_'):
        a,b = map(int, route.removeprefix('dys_knapsack_').split('x'))
        if b != 2:
            raise ValueError('Unregistered knapsack route')
        return make_dys_two_dimensional_knapsack(items=a)
    if route.startswith('lava_random_lp_') and route.endswith('_released_code'):
        a,b = map(int,route.removeprefix('lava_random_lp_').removesuffix('_released_code').split('x'))
        return make_lava_random_lp(variables=a,constraints=b,source_mode='released_code')
    raise ValueError('No archived route factory: ' + route)


def extension_seed(data_seed, split):
    from proximal_spo.seeds import derive_seed
    if split not in ('train','validation'):
        raise ValueError('Only observed training/validation extension streams are registered')
    purpose='additional-observed-training-pairs' if split=='train' else 'additional-observed-validation-pairs'
    return derive_seed(data_seed,REVISION,purpose)


def _generate_extension(route, data_seed, count, split):
    from proximal_spo.external_benchmarks import _linear_problem, _physical_costs
    from dfl_extensions_lab.benchmarks import SplitSizes
    benchmark = route_factory(route)
    seed = extension_seed(data_seed,split)
    sizes = SplitSizes(count,1,1) if split=='train' else SplitSizes(1,count,1)
    sampled = getattr(benchmark.sample(sizes,seed=seed),split)
    coefficients = np.asarray(sampled.scenarios['cost'],dtype=np.float64)
    exposure = benchmark.cost_exposure if hasattr(benchmark,'cost_exposure') else np.eye(benchmark.feasible_model.variable_count)
    fixed = np.asarray(benchmark.feasible_model.c,dtype=np.float64)
    physical = _physical_costs(coefficients,exposure,fixed)
    dense = exposure.toarray() if hasattr(exposure,'toarray') else np.asarray(exposure)
    return {'contexts':np.asarray(sampled.contexts,dtype=np.float64),
        'physical_costs':physical,'coefficients':coefficients}, _linear_problem(benchmark), {
            'extension_seed':seed,'extension_sample_seed':sampled.seed,
            'benchmark_spec':json_value(benchmark.spec.summary()),
            'fixed_anchor':fixed,'cost_statistic':dense,
            'policy':'independent additional '+('training' if split=='train' else 'validation')+
                ' stream from unchanged archived route factory'}


def generate_extension(route, data_seed, count=900):
    return _generate_extension(route,data_seed,count,'train')


def generate_validation_extension(route, data_seed, count=288):
    return _generate_extension(route,data_seed,count,'validation')


def combine_observations(original, extension):
    if any('conditional' in k or k.startswith('test') for k in original):
        raise ValueError('Hidden information in supplied observed bank')
    combined={k:v.copy() for k,v in original.items()}
    for field in ('contexts','physical_costs','coefficients'):
        name='train__'+field
        if name not in original:
            continue
        if len(original[name]) != 100 or len(extension[field]) != 900:
            raise ValueError('Expected exact original100 plus additional900')
        if original[name].shape[1:] != extension[field].shape[1:]:
            raise ValueError('Extension changed actual context/physical coordinate contract')
        combined[name]=np.concatenate([original[name],extension[field]],axis=0)
    return combined


def prepare(item):
    root, base_data, key, maximum = item
    root,base_data=Path(root),Path(base_data)
    destination=root/'frozen_data'/key
    if (destination/'receipt.json').exists():
        return read(destination/'receipt.json')
    if destination.exists():
        raise RuntimeError('Incomplete preparation retained for review: '+key)
    source=base_data/key
    original=read(source/'receipt.json')
    if original['sizes'] != {'train':100,'validation':32,'test':100}:
        raise ValueError('Source must be the completed simplified test100 bank')
    for name in ('observations.npz','structure.npz','structure.json','test.npz'):
        if sha(source/name) != original['files_sha256'][name]:
            raise ValueError('Source bank changed: '+key+'/'+name)
    with np.load(source/'observations.npz',allow_pickle=False) as f:
        observations={k:f[k] for k in f.files}
    if any('conditional' in k or k.startswith('test') for k in observations):
        raise ValueError('Hidden information in fitting input')
    if len(observations['train__contexts'])!=100 or len(observations['validation__contexts'])!=32:
        raise ValueError('Source observation counts differ')
    route,data_seed=key.split('__data')
    problem=load_structure(source)
    provenance=None
    extended=observations
    if maximum==1000:
        extension,generated_problem,provenance=generate_extension(route,int(data_seed))
        from proximal_spo.feasible_policies import _geometry_cache_key
        if _geometry_cache_key(problem)!=_geometry_cache_key(generated_problem):
            raise ValueError('Additional observations changed the native physical instance')
        with np.load(source/'structure.npz',allow_pickle=False) as structure:
            if not np.array_equal(structure['fixed_anchor'],provenance.pop('fixed_anchor')):
                raise ValueError('Extension changed the unlearned fixed physical cost')
            exposure=provenance.pop('cost_statistic')
            if 'cost_statistic' not in structure or not np.array_equal(structure['cost_statistic'],exposure):
                raise ValueError('Extension changed physical cost exposure')
        extended=combine_observations(observations,extension)
    elif maximum!=100:
        raise ValueError('Bank maximum must be100 or1000')
    # Never overwrite partially generated files or any historical input.
    destination.mkdir(parents=True)
    shutil.copyfile(source/'observations.npz',destination/'observations_n100.npz')
    for name in ('structure.npz','structure.json','test.npz'):
        shutil.copyfile(source/name,destination/name)
    sizes=[100] if maximum==100 else [100,500,1000]
    for n in sizes[1:]:
        arrays={k:v[:n] if k.startswith('train__') else v for k,v in extended.items()}
        with (destination/f'observations_n{n}.npz').open('xb') as stream:
            np.savez_compressed(stream,**arrays)
    names=[f'observations_n{n}.npz' for n in sizes]+['structure.npz','structure.json','test.npz']
    receipt={'revision':REVISION,'key':key,'available_train_sizes':sizes,
        'sizes':{'train':maximum,'validation':32,'test':100},
        'source_observed_receipt_sha256':sha(source/'receipt.json'),
        'source_files_sha256':original['files_sha256'],
        'test_seed':original['test_seed'],'test_policy':'exact byte-identical simplified sealed test100',
        'observations_policy':'exact old train100 prefix; nested500/1000; original observed validation32',
        'validation_policy':'exact original observed32, selection only',
        'context_dimension':int(observations['train__contexts'].shape[1]),
        'native_integer_count':int(np.count_nonzero(problem.integrality)),
        'known_structure_unchanged':True,'extension_provenance':provenance,
        'original_observed_array_hashes':{k:array_hash(v) for k,v in observations.items()},
        'files_sha256':{name:sha(destination/name) for name in names}}
    write(destination/'receipt.json',receipt,immutable=True)
    return receipt


def load_job(job):
    from proximal_spo.data import DatasetBundle,PhysicalCostSplit
    from proximal_spo.external_benchmarks import ExternalBenchmarkLoad
    if job.get('scaled_data_neural_revision')!=REVISION:
        raise ValueError('Unregistered campaign data revision')
    sizes=job['config']['sizes'];n=sizes['train'];validation_n=sizes['validation']
    phase_id=job.get('campaign_phase','')
    retuning=phase_id.startswith(('linear_retune_','nonlinear_retune_'))
    expected_validation=32
    if retuning:
        from scaled_data_neural_campaign import RETUNING_VALIDATION_SAMPLES
        expected_validation=RETUNING_VALIDATION_SAMPLES.get(n)
    if n not in (100,300,500,1000) or validation_n!=expected_validation or sizes['test']!=100:
        raise ValueError('Unregistered supplied sample sizes')
    if n==300 and phase_id not in ('linear_retune_n300','nonlinear_retune_n300'):
        raise ValueError('Training300 is registered only for the amended retuning')
    if retuning and phase_id not in ('linear_retune_n'+str(n),'nonlinear_retune_n'+str(n)):
        raise ValueError('Retuning phase differs from supplied training count')
    key=job['required_data_key']
    expected=job['route']+'__data'+str(job['config']['seeds']['data'])
    if key!=expected:
        raise ValueError('Frozen data key differs from route/data seed')
    base=Path(os.environ['CENTRAL_PATH_FROZEN_DATA'])/key
    development_extension=(retuning and job['stage']=='screen')
    bank=base.parent/'retuning_development'/key if development_extension else base
    receipt=read(bank/'receipt.json')
    stored_n=500 if n==300 else n
    if receipt['revision']!=REVISION or stored_n not in receipt['available_train_sizes']:
        raise ValueError('Requested supplied training bank is unavailable')
    name=f'observations_n{stored_n}.npz'
    for file in (name,'structure.npz','structure.json'):
        location=bank if file==name else base
        hashes=receipt['source_files_sha256'] if development_extension and file!=name else receipt['files_sha256']
        if sha(location/file)!=hashes[file]:
            raise ValueError('Frozen supplied input changed: '+file)
    with np.load(bank/name,allow_pickle=False) as f:
        arrays={k:f[k] for k in f.files}
    if any('conditional' in k or k.startswith('test') for k in arrays):
        raise ValueError('Hidden information in supplied training/validation bank')
    if n==300:
        # Explicitly registered view: only the first300 reach preprocessing,
        # calibration or a learner. Existing final500 files stay immutable.
        arrays={k:v[:300] if k.startswith('train__') else v for k,v in arrays.items()}
    validation_receipt=None
    if retuning:
        validation_bank=base.parent/'retuning_validation'/key
        validation_receipt=read(validation_bank/'receipt.json')
        if validation_receipt.get('revision')!=REVISION or validation_receipt.get('key')!=key or \
                validation_n not in validation_receipt.get('available_validation_sizes',[]):
            raise ValueError('Requested observed validation supplement is unavailable')
        if validation_receipt['source_observed_receipt_sha256']!=sha(base/'receipt.json'):
            raise ValueError('Observed validation supplement references a different original bank')
        base_receipt=read(base/'receipt.json')
        for file,expected_hash in validation_receipt['source_files_sha256'].items():
            if base_receipt['files_sha256'].get(file)!=expected_hash:
                raise ValueError('Observed validation supplement input differs: '+file)
        name_validation='validation_n320.npz'
        if sha(validation_bank/name_validation)!=validation_receipt['files_sha256'][name_validation]:
            raise ValueError('Frozen observed validation supplement changed')
        with np.load(validation_bank/name_validation,allow_pickle=False) as f:
            if set(f.files)!={k for k in arrays if k.startswith('validation__')}:
                raise ValueError('Validation supplement changed supplied observed fields')
            arrays.update({k:f[k][:validation_n].copy() for k in f.files})
    if len(arrays['train__contexts'])!=n or len(arrays['validation__contexts'])!=validation_n:
        raise ValueError('Supplied data counts differ')
    splits={}
    for split in ('train','validation','test'):
        source='train' if split=='test' else split
        get=lambda field:arrays[source+'__'+field][:1] if split=='test' else arrays[source+'__'+field]
        costs=get('physical_costs');coeff=get('coefficients') if source+'__coefficients' in arrays else None
        splits[split]=PhysicalCostSplit(get('contexts'),costs,costs,split,
            job['config']['seeds']['data'],coeff,coeff)
    meta=read(base/'structure.json')
    with np.load(base/'structure.npz',allow_pickle=False) as a:
        dataset=DatasetBundle(**splits,fixed_anchor=a['fixed_anchor'],random_indices=a['random_indices'],
            benchmark_id=meta['benchmark_id'],master_seed=meta['master_seed'],law=meta['law'],
            cost_statistic=a['cost_statistic'] if 'cost_statistic' in a else None)
    fitting={k:receipt[k] for k in ('revision','key','source_observed_receipt_sha256',
        'observations_policy','context_dimension','native_integer_count','known_structure_unchanged')}
    fitting.update(sizes=sizes,supplied_training_count=n)
    if validation_receipt is not None:
        fitting['supplemental_validation']={'supplied_validation_count':validation_n,
            'stored_validation_count':320,'original_validation_prefix':32,
            'receipt_sha256':sha(validation_bank/'receipt.json'),
            'observation_sha256':validation_receipt['files_sha256'][name_validation],
            'selection_only':True}
    if n==300:
        fitting['training_prefix_view']={'stored_training_count':500,'supplied_training_count':300,
            'source_observation_sha256':receipt['files_sha256'][name]}
    return ExternalBenchmarkLoad(load_structure(base),dataset,{'simplified_data':fitting,
        'scaled_data_neural_revision':REVISION,'generator_called_by_fit':False,'test_bank_opened':False})


def test_split(job,directory,selection):
    if job.get('scaled_data_neural_revision')!=REVISION:
        raise ValueError('Unregistered sealed-test access revision')
    # Reuse the maintained freeze-before-open implementation and exact test100.
    from simplified_data import test_split as sealed_test
    return sealed_test(job,directory,selection)


def prepare_retuning_development(item):
    """Add only the four amended development extensions; originals are read-only."""
    root,key=item
    root=Path(root);source=root/'frozen_data'/key
    destination=root/'frozen_data/retuning_development'/key
    if (destination/'receipt.json').exists():
        return read(destination/'receipt.json')
    if destination.exists():
        raise RuntimeError('Incomplete retuning development extension retained for review: '+key)
    original=read(source/'receipt.json')
    for name in ('observations_n100.npz','structure.npz','structure.json'):
        if sha(source/name)!=original['files_sha256'][name]:
            raise ValueError('Original development input changed: '+key+'/'+name)
    with np.load(source/'observations_n100.npz',allow_pickle=False) as f:
        observations={k:f[k] for k in f.files}
    route,seed=key.split('__data')
    extension,problem,provenance=generate_extension(route,int(seed))
    from proximal_spo.feasible_policies import _geometry_cache_key
    if _geometry_cache_key(load_structure(source))!=_geometry_cache_key(problem):
        raise ValueError('Development extension changed native physical instance')
    with np.load(source/'structure.npz',allow_pickle=False) as structure:
        if not np.array_equal(structure['fixed_anchor'],provenance.pop('fixed_anchor')):
            raise ValueError('Development extension changed fixed cost')
        if not np.array_equal(structure['cost_statistic'],provenance.pop('cost_statistic')):
            raise ValueError('Development extension changed cost exposure')
    extended=combine_observations(observations,extension)
    destination.mkdir(parents=True)
    names=[]
    for n in (500,1000):
        name=f'observations_n{n}.npz';names.append(name)
        with (destination/name).open('xb') as stream:
            np.savez_compressed(stream,**{k:v[:n] if k.startswith('train__') else v for k,v in extended.items()})
    receipt={k:original[k] for k in ('context_dimension','native_integer_count','known_structure_unchanged','test_seed')}
    receipt.update(revision=REVISION,key=key,available_train_sizes=[300,500,1000],
        sizes={'train':1000,'validation':32,'test':100},
        development_extension_revision='linear_retune_development_20261021_v1',
        source_observed_receipt_sha256=sha(source/'receipt.json'),
        source_files_sha256=original['files_sha256'],extension_provenance=provenance,
        observations_policy='exact original100 prefix and validation32; nested300/500/1000; no test access',
        training_prefix_views={'300':500},
        files_sha256={name:sha(destination/name) for name in names})
    write(destination/'receipt.json',receipt,immutable=True)
    return receipt


def prepare_retuning_validation(item):
    """Add observed validation only; preserve all original train/structure/test files."""
    from scaled_data_neural_campaign import RETUNING_VALIDATION_SAMPLES
    root,key=item
    root=Path(root);source=root/'frozen_data'/key
    destination=root/'frozen_data/retuning_validation'/key
    if (destination/'receipt.json').exists():
        receipt=read(destination/'receipt.json')
        if receipt.get('available_validation_sizes')!=[32,96,160,320]:
            raise ValueError('Existing validation supplement has a different registered protocol')
        return receipt
    if destination.exists():
        raise RuntimeError('Incomplete validation supplement retained for review: '+key)
    original=read(source/'receipt.json')
    source_names=('observations_n100.npz','structure.npz','structure.json')
    for name in source_names:
        if sha(source/name)!=original['files_sha256'][name]:
            raise ValueError('Original validation input changed: '+key+'/'+name)
    with np.load(source/'observations_n100.npz',allow_pickle=False) as f:
        observed={k:f[k] for k in f.files if k.startswith('validation__')}
    fields={'validation__contexts','validation__physical_costs','validation__coefficients'}
    if not {'validation__contexts','validation__physical_costs'}<=set(observed)<=fields or \
            any(len(v)!=32 for v in observed.values()):
        raise ValueError('Expected exactly the original32 observed validation pairs')
    route,seed=key.split('__data')
    extension,problem,provenance=generate_validation_extension(route,int(seed))
    from proximal_spo.feasible_policies import _geometry_cache_key
    if _geometry_cache_key(load_structure(source))!=_geometry_cache_key(problem):
        raise ValueError('Validation extension changed native physical instance')
    with np.load(source/'structure.npz',allow_pickle=False) as structure:
        if not np.array_equal(structure['fixed_anchor'],provenance.pop('fixed_anchor')):
            raise ValueError('Validation extension changed fixed cost')
        if not np.array_equal(structure['cost_statistic'],provenance.pop('cost_statistic')):
            raise ValueError('Validation extension changed cost exposure')
    combined={}
    for name,value in observed.items():
        extra=extension[name.removeprefix('validation__')]
        if len(extra)!=288 or value.shape[1:]!=extra.shape[1:]:
            raise ValueError('Validation extension changed actual observed coordinate contract')
        combined[name]=np.concatenate([value,extra],axis=0)
    destination.mkdir(parents=True)
    name='validation_n320.npz'
    with (destination/name).open('xb') as stream:
        np.savez_compressed(stream,**combined)
    receipt={'revision':REVISION,'key':key,
        'validation_extension_revision':'linear_retune_observed_validation_20261021_v1',
        'available_validation_sizes':[32,96,160,320],
        'validation_samples_by_training_size':{str(n):v for n,v in RETUNING_VALIDATION_SAMPLES.items()},
        'source_observed_receipt_sha256':sha(source/'receipt.json'),
        'source_files_sha256':{name:original['files_sha256'][name] for name in source_names},
        'original_validation_array_hashes':{k:array_hash(v) for k,v in observed.items()},
        'observations_policy':'exact original32 prefix; nested96/160/320 observed validation; no train/test copy',
        'validation_policy':'configuration/checkpoint selection only; independent extension stream from training',
        'known_structure_unchanged':True,'extension_provenance':provenance,
        'files_sha256':{name:sha(destination/name)}}
    write(destination/'receipt.json',receipt,immutable=True)
    return receipt


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--base-data-root',type=Path)
    mode=parser.add_mutually_exclusive_group()
    mode.add_argument('--extend-retuning-development',action='store_true')
    mode.add_argument('--prepare-retuning-extensions',action='store_true',
        help='add four development training extensions and all observed validation supplements')
    parser.add_argument('--workers',type=int,default=4)
    args=parser.parse_args()
    if not 1<=args.workers<=8 or os.environ.get('SCALED_DATA_NEURAL_COMPUTE')!='1':
        raise RuntimeError('Upstream numerical preparation requires an authorized compute host and1..8 workers')
    if socket.gethostname().split('.')[0].startswith('master'):
        raise RuntimeError('Never perform numerical preparation on a CERMICS login node')
    if args.extend_retuning_development or args.prepare_retuning_extensions:
        from scaled_data_neural_campaign import RETUNING_VALIDATION_SAMPLES, effective_plan
        if not os.environ.get('SLURM_JOB_ID'):
            raise RuntimeError('Retuning development extension requires a Slurm compute allocation')
        plan=effective_plan(args.root)
        if not plan.get('effective_phase_extension'):
            raise RuntimeError('Missing explicit larger-data retuning amendment')
        items=[(str(args.root),route+'__data'+str(plan['cells'][route]['screen']['data']))
               for route in plan['smallest_routes'].values()]
        from concurrent.futures import ProcessPoolExecutor
        with ProcessPoolExecutor(args.workers) as pool:
            receipts=list(pool.map(prepare_retuning_development,items))
            validation_receipts=list(pool.map(prepare_retuning_validation,
                [(str(args.root),key) for key in plan['bank_keys']])) if args.prepare_retuning_extensions else []
        write(args.root/'RETUNING_DEVELOPMENT_DATA_READY.json',{'status':'complete',
            'banks':[r['key'] for r in receipts],'training_sizes':[300,500,1000],
            'source_amendment':plan['effective_phase_extension']},immutable=True)
        if args.prepare_retuning_extensions:
            write(args.root/'RETUNING_DATA_READY.json',{'status':'complete',
                'development_training_banks':[r['key'] for r in receipts],
                'validation_banks':[r['key'] for r in validation_receipts],
                'training_sizes':[300,500,1000],
                'validation_samples_by_training_size':{str(n):v for n,v in RETUNING_VALIDATION_SAMPLES.items()},
                'source_amendment':plan['effective_phase_extension']},immutable=True)
        return
    if args.base_data_root is None:
        parser.error('--base-data-root is required for the original full-bank preparation')
    plan=read(args.root/'PLAN.json')
    final_keys={route+'__data'+str(seed['data']) for route in plan['routes']
                for seed in plan['cells'][route]['confirmation']}
    items=[(str(args.root),str(args.base_data_root),key,1000 if key in final_keys else 100)
           for key in plan['bank_keys']]
    from concurrent.futures import ProcessPoolExecutor
    with ProcessPoolExecutor(args.workers) as pool:
        receipts=list(pool.map(prepare,items))
    write(args.root/'DATA_READY.json',{'status':'complete','revision':REVISION,
        'banks':len(receipts),'extended_final_banks':len(final_keys),
        'original_validation_and_test_reused':True},immutable=True)


if __name__=='__main__':
    main()
