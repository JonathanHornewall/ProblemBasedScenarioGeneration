"""Verify payloads, prepare held-out validation extensions and exercise all fit routes in Slurm."""
from __future__ import annotations
import argparse
import copy
import json
import os
import subprocess
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from pilot_common import *

def numerical_preflight(root):
    root=Path(root).resolve()
    if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Numerical preflight requires Slurm')
    os.environ.update(environment(root));os.environ.pop('CP_SPO_GEOMETRY_CACHE_READONLY',None)
    from pilot_driver import node_reservation
    os.environ['PILOT_NODE_MEMORY_GIB']='20'
    probe=root/'preflight/admission_probe';probe.mkdir(parents=True,exist_ok=True)
    assert node_reservation(probe,'first',12)
    assert not node_reservation(probe,'second',12)
    assert node_reservation(probe,'second',6)
    node_reservation(probe,'first');node_reservation(probe,'second')
    os.environ.pop('PILOT_NODE_MEMORY_GIB',None)
    for rel,info in read(root/'INPUT_INVENTORY.json').items():
        p=root/rel
        if p.stat().st_size!=info['bytes'] or sha(p)!=info['sha256']:raise ValueError('Input mismatch: '+rel)
    for rel,expected in read(root/'source_receipt.json')['source_sha256'].items():
        if sha(root/'code'/rel)!=expected:raise ValueError('Source mismatch: '+rel)
    import importlib.metadata
    import pyepo
    package=Path(pyepo.__file__).parent
    write(root/'RUNTIME_BASELINE_SOURCE.json',{'pyepo_version':importlib.metadata.version('pyepo'),
        'pyepo_source_sha256':{str(p.relative_to(package)):sha(p) for p in package.rglob('*.py')},
        'vendored_baselines_unchanged_from_base':True},immutable=True)
    plan=read(root/'PLAN.json')
    from pilot_data import prepare_extension,load_job
    entries=[(str(root),r['key']) for r in plan['banks']]
    with ProcessPoolExecutor(max_workers=4) as pool:extensions=list(pool.map(prepare_extension,entries))
    write(root/'VALIDATION_EXTENSION_VERIFICATION.json',{'status':'passed','banks':len(extensions),
        'observed_validation_pairs':100,'prefix_pairs_unchanged':32,'test_file_opened':False,
        'receipts_sha256':{d['key']:sha(root/'validation100'/d['key']/'receipt.json') for d in extensions}})
    from proximal_spo.feasible_policies import compile_policy_geometry
    centers=[]
    for route in sorted(plan['cells']):
        job=next(j for j in plan['step1_jobs'].values() if j['route']==route and j['method']==CPS)
        loaded=load_job(job);g=compile_policy_geometry(loaded.problem.continuous_relaxation())
        centers.append({'route':route,'receipt':g.receipt_dict()})
    write(root/'GEOMETRY_CACHE_VERIFICATION.json',{'status':'passed','instances':len(centers),'profiles':centers})
    os.environ['CP_SPO_GEOMETRY_CACHE_READONLY']='1'
    pre=root/'preflight';pre.mkdir(exist_ok=True);jobs=[]
    for route in sorted(plan['cells']):
        j=copy.deepcopy(next(j for j in plan['step1_jobs'].values() if j['route']==route and j['method']==CPS
            and j['config']['training']['gradient_clip'] is None and j['config']['training']['batch_size']==32))
        jobs.append(j)
    for method in METHODS[1:]:
        route='dys_knapsack_50x2' if method=='lava' else 'dys_shortest_path_10x10'
        jobs.append(copy.deepcopy(next(j for j in plan['step1_jobs'].values() if j['route']==route and j['method']==method)))
    # Paired one-epoch trajectories prove the additional validation view cannot affect fitting.
    template=plan['step2_family_grids']['sp'][0];seed=plan['cells'][SMALLEST['sp']]['screen']
    pair=make_job(template,seed,step=2,stage='screen',dual=True,route=SMALLEST['sp']);jobs.append(copy.deepcopy(pair))
    pair2=copy.deepcopy(pair);pair2['pilot_dual_validation']=False;jobs.append(pair2)
    diagnostic=[]
    for index,j in enumerate(jobs):
        j.update(stage='screen',diagnostic_only=True);j['config']['evaluate_test']=False
        j['config']['training'].update(epochs=1,validation_epochs=[1],schedule_reference_epochs=300)
        j.pop('pilot_test_validation_sizes',None)
        j['id']='diagnostic__'+digest({'index':index,'job':j})[:28];j['config']['name']=j['id']
        write(pre/'jobs'/(j['id']+'.json'),manifest(j),immutable=True);diagnostic.append(j)
    from pilot_driver import terminate
    import psutil
    active={};queue=list(diagnostic);failures=[]
    while queue or active:
        reserved=sum(provision(x[1]) for x in active.values())
        while queue and len(active)<8 and reserved+provision(queue[0])<=112:
            j=queue.pop(0);logpath=pre/'results/logs'/(j['id']+'.log');logpath.parent.mkdir(parents=True,exist_ok=True)
            log=logpath.open('a');child=subprocess.Popen([str(root/'venv/bin/python'),str(root/'code/scripts/run_central_path_final.py'),
                '--manifest',str(pre/'jobs'/(j['id']+'.json')),'--job-index','0','--output-root',str(pre/'results')],
                env=environment(root),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            active[j['id']]=(child,j,log,time.time());reserved+=provision(j)
        for jid,(child,j,log,started) in list(active.items()):
            try:rss=sum(p.memory_info().rss for p in [psutil.Process(child.pid),*psutil.Process(child.pid).children(recursive=True)])/2**30
            except psutil.Error:rss=0
            if rss>provision(j)*.9:terminate(child)
            if child.poll() is not None:
                log.close();path=pre/'results/receipts'/(jid+'.json')
                if not path.exists():failures.append({'id':jid,'reason':'diagnostic exited without receipt','returncode':child.returncode})
                else:
                    d=read(path)
                    if d['status']!='complete' or not d.get('smoke_only') or d.get('test_access') or d.get('test_bank_opened') or d['summary']['epochs_completed']!=1:
                        failures.append({'id':jid,'status':d['status'],'error':d.get('error')})
                    elif not (Path(d['attempt_directory'])/'predictor_architecture.json').exists():failures.append({'id':jid,'reason':'missing architecture proof'})
                del active[jid]
        write(pre/'STATUS.json',{'queued':len(queue),'active':len(active),'failures':failures,'updated_unix':time.time()})
        time.sleep(2)
    hashes=[];last_states=[]
    for j in diagnostic[-2:]:
        p=pre/'results/receipts'/(j['id']+'.json')
        if p.exists() and read(p)['status']=='complete':
            import torch
            d=read(p);hashes.append(d['summary']['parameter_sha256'])
            last_states.append(torch.load(Path(d['attempt_directory'])/'last_model.pt',map_location='cpu',weights_only=False)['model'])
    if len(hashes)!=2 or len(set(hashes))!=1:failures.append({'reason':'dual validation changed training trajectory','hashes':hashes})
    last_equal=(len(last_states)==2 and set(last_states[0])==set(last_states[1])
        and all(torch.equal(last_states[0][k],last_states[1][k]) for k in last_states[0]))
    if not last_equal:failures.append({'reason':'dual validation changed actual end-of-epoch parameters'})
    proof={'status':'failed' if failures else 'passed','diagnostics':len(diagnostic),'failures':failures,
        'dual_validation_training_parameter_parity':len(hashes)==2 and len(set(hashes))==1,
        'dual_validation_last_epoch_parameter_parity':last_equal,
        'test_access':False,'scientific_eligibility':False,'source_commit':read(root/'source_receipt.json')['git_commit'],
        'finished_unix':time.time()}
    write(pre/'VERIFICATION.json',proof,immutable=True)
    if failures:raise RuntimeError('Pilot preflight failed; scientific queue remains gated')
    print(json.dumps(proof),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args()
    try:numerical_preflight(a.root)
    except BaseException as error:
        import traceback
        out=a.root/'preflight/VERIFICATION.json'
        if not out.exists():write(out,{'status':'failed','error':str(error),'traceback':traceback.format_exc(),
            'scientific_eligibility':False,'finished_unix':time.time()},immutable=True)
        raise
