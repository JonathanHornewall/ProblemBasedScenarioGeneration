"""Isolated Mac timing of frozen final fits, after the remote campaign.

Three prespecified matched confirmation seed bundles per cell/method. Every fit
has a fresh model and optimizer, one Torch/BLAS thread and its frozen horizon.
Validation callbacks remain outside the measured optimizer loop; no testing or
hyperparameter/epoch selection is performed. Reference preparation is separate.
"""
import argparse
import copy
import fcntl
import hashlib
import json
import os
import platform
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

from build_central_path_final import read,write
from frozen_campaign_data import data_key
from exact_validation_reference import needs_analytic_reference_file, analytic_reference_name

ROOT=Path(__file__).resolve().parents[1]


def prepare(run):
    target=run/'timing_target.json'
    if target.exists() and read(target).get('target') == 'cermics':
        raise RuntimeError('Final timing moved to matched CERMICS nodes; Mac execution disabled')
    repair=run/'spo_memory_repair.json'
    if repair.exists() and read(repair).get('status') != 'complete':
        raise RuntimeError('SPO memory repair and unbiased reselection remain pending')
    if (run/'mac_timing/manifest.json').exists():
        return run/'mac_timing/manifest.json'
    retrieved=run/'cluster_retrieved'
    current=read(retrieved/'confirmation.json')
    if (run/'additional_screen.json').exists():
        expected={(j['cell'],j['method']) for name in ('screen.json','additional_screen.json')
                  for j in read(run/name)['jobs']}
        if current['pipeline']['expected_groups'] != len(expected):
            raise RuntimeError('Expanded validation study has not reached the local backup yet')
    if not current['pipeline']['selection_complete']:
        raise RuntimeError('Remote selection has not finished; timing remains deferred')
    for job in current['jobs']:
        if not (retrieved/'results/receipts'/(job['id']+'.json')).exists():
            raise RuntimeError('Remote confirmation/import is incomplete')
    archived=[ROOT.parent/'ProximalSPO-final-20260922/runs/central_path_final_20260922/hornewall/retrieved',
              ROOT.parent/'ProximalSPO-extension-20260923/runs/central_path_extension_20260923/hornewall/retrieved']
    # The validation-noise sensitivity study is separate from the primary
    # timing table; it must not multiply or replace the final primary fits.
    jobs=[j for j in current['jobs'] if j.get('validation_costs') != 'single_sample']
    exact_soft_cells={j.get('comparison_cell',j['cell']) for j in jobs
                      if j['method']=='central_path_barrier_validation' and j.get('analytic_validation')}
    jobs=[j for j in jobs if not (j['method']=='central_path_barrier_validation'
          and j['cell'] in exact_soft_cells and not j.get('analytic_validation'))]
    for archive in archived:
        jobs.extend(j for j in read(archive/'confirmation.json')['jobs'] if j['method']=='central_path_hard_validation')
    groups=defaultdict(list)
    for j in jobs:groups[j.get('comparison_cell',j['cell']),j['method']].append(j)
    queue=[]
    order={'mse':0,'wise':1,'spo_plus':2,'central_path_hard_validation':3,'central_path_barrier_validation':4}
    for cell,method in sorted(groups,key=lambda k:(order[k[1]],k[0])):
        # Original manifest order determines the first three; outcomes are unread.
        for original in groups[cell,method][:3]:
            job=copy.deepcopy(original)
            job['cell']=cell
            job['source_confirmation_id']=job['id'];job['id']='mac_timing__'+job['id']
            job['stage']='timing';job['config']['evaluate_test']=False
            job['protocol_revision']='physical_relaxed_spo_conditional_validation_v1'
            job['validation_costs']='conditional_mean'
            tr=job['config']['training'];tr['selection_mode']='last';tr['maximum_optimization_seconds']=None
            tr['validation_epochs']=[tr['epochs']];tr['patience']=tr['epochs']+1
            path=retrieved/'frozen_data'/(data_key(job)+'.npz')
            if not path.exists():raise RuntimeError('Frozen timing data not yet backed up: '+str(path))
            if needs_analytic_reference_file(job) and not (retrieved/'frozen_validation'/analytic_reference_name(job)).exists():
                raise RuntimeError('Analytic validation timing reference not yet backed up')
            queue.append(job)
    target=run/'mac_timing/manifest.json'
    manifest={'jobs':queue,'protocol':{'timing_repeats':3,'concurrent_fits':1,'threads_per_fit':1,
        'selection':'Frozen configuration and horizon; original first three confirmation bundles',
        'measurement':'optimizer-only wall and process CPU; preprocessing, validation, checkpointing and testing excluded',
        'test_evaluation':False,'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()}}
    if target.exists() and read(target)!=manifest:raise RuntimeError('Refusing to change a frozen timing manifest')
    write(target,manifest);return target


def fit(run,index):
    sys.path.insert(0,os.environ['DFL_EXTENSIONS_SRC'])
    import torch
    from run_central_path_final import load_job_data,core_fit
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    manifest=read(run/'mac_timing/manifest.json');job=manifest['jobs'][index]
    output=run/'mac_timing/results';receipt=output/'receipts'/(job['id']+'.json')
    if receipt.exists():return
    directory=output/'attempts'/job['id']/str(time.time_ns());directory.mkdir(parents=True)
    started=time.perf_counter();record={'job':job,'host':platform.node(),'platform':platform.platform(),
        'concurrent_fits':1,'threads':1,'test_evaluation':False,'status':'running','pid':os.getpid()}
    def update(phase,**values):
        record.update(phase=phase,**values);write(output/'progress'/(job['id']+'.json'),record)
    def training_started():record['preparation_wall_seconds']=time.perf_counter()-started
    try:
        loaded=load_job_data(job)
        record['frozen_data']=loaded.provenance['frozen_data']
        summary,_=core_fit(job,loaded,directory,update,training_started)
        expected=job['frozen_horizon']
        if summary['epochs_completed']!=expected:raise RuntimeError('Final fit did not complete its frozen horizon')
        record.update(status='complete',summary=summary,
            training_only_wall_seconds=summary['optimization_wall_seconds'],
            training_only_cpu_seconds=summary.get('optimization_cpu_seconds',0.0 if expected==0 else None))
    except Exception as e:
        import traceback
        record.update(status='failed',error=str(e),traceback=traceback.format_exc())
    record['total_process_wall_seconds']=time.perf_counter()-started
    write(receipt,record)


def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True)
    p.add_argument('--index',type=int);p.add_argument('--prepare-only',action='store_true');p.add_argument('--wait-until-ready',action='store_true');a=p.parse_args()
    os.environ['CENTRAL_PATH_FROZEN_DATA']=str(a.root/'cluster_retrieved/frozen_data')
    os.environ['CENTRAL_PATH_FROZEN_DATA_READONLY']='1'
    os.environ['DFL_EXTENSIONS_SRC']=str(ROOT.parent/'public-baseline-sources-20260905/dfl-extensions-lab-fixed/src')
    os.environ['SOLVER_FREE_DFL_REPO']=str(ROOT.parent/'public-baseline-sources-20260905/solver-free-dfl')
    if a.index is not None:return fit(a.root,a.index)
    while True:
        try:
            path=prepare(a.root)
            break
        except (FileNotFoundError,RuntimeError) as e:
            if not a.wait_until_ready:raise
            write(a.root/'mac_timing/status.json',{'updated_unix':time.time(),'status':'deferred','reason':str(e)})
            time.sleep(45)
    if a.prepare_only:return
    guard=(a.root/'mac_timing/worker.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for i,job in enumerate(read(path)['jobs']):
        subprocess.run([sys.executable,__file__,'--root',str(a.root),'--index',str(i)],check=True)
        write(a.root/'mac_timing/status.json',{'updated_unix':time.time(),'last_index':i,'last_job':job['id'],'status':'running'})
    from collections import Counter
    counts=Counter(read(p)['status'] for p in (a.root/'mac_timing/results/receipts').glob('*.json'))
    write(a.root/'mac_timing/status.json',{'updated_unix':time.time(),'status':'complete' if counts['failed']==0 else 'complete_with_failures','counts':dict(counts)})


if __name__=='__main__':main()
