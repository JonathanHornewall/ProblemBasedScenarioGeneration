"""Freeze the authorized pilot using archived tuples, banks and full seed bundles."""
from __future__ import annotations
import argparse
import collections
import copy
from pathlib import Path
from pilot_common import *

def build(archive, root):
    selected_path = archive/'reports/experimental_record_20260928/data/MAIN_SELECTED_FULL.json'
    screen_path = archive/'runs/linear_scale_20260928/screen.json'
    inventory_path = archive/'runs/linear_scale_20260928/ALL_FROZEN_BANK_INVENTORY.json'
    selected = [z for z in read(selected_path) if z['architecture_arm']=='linear']
    screen = read(screen_path); jobs = {}; groups = []; cells = {}
    for z in selected:
        template = z['full_job']; cell = screen['cells'][template['cell']]
        cells[z['route']] = {'screen': next(j['config']['seeds'] for j in screen['jobs'] if j['cell']==template['cell']),
            'refinement':cell['refinement_seeds'], 'confirmation':cell['confirmation_seeds']}
        variants = {}
        for arm in ARMS:
            ids = []
            for seeds in cell['confirmation_seeds']:
                j = make_job(template, seeds, step=1, arm=arm)
                ids.append(j['id']); jobs[j['id']] = j
            variants[arm] = ids
        groups.append({'route':z['route'], 'method':z['method'], 'origin_candidate':z['candidate'],
            'original_batch_size':z['batch_size'], 'original_horizon':z['horizon'], 'arms':variants})
    if len(groups)!=130 or len(jobs)!=5140: raise ValueError(('Unexpected Step 1 count',len(groups),len(jobs)))
    grids = collections.defaultdict(dict)
    for j in screen['jobs']:
        if j.get('architecture_arm') != 'linear' or j['method'] != CPS: continue
        q = make_job(j, j['config']['seeds'], step=2, stage='screen', dual=True)
        grids[family(j['route'])][q['candidate']] = q
    grids = {f:[v[k] for k in sorted(v)] for f,v in grids.items()}
    if set(grids)!=set(SMALLEST): raise ValueError('Incomplete CP family grids')
    bank_entries = read(inventory_path)
    plan = {'revision':REVISION, 'method_order':METHODS, 'validation_epochs':[0,*EPOCHS],
        'step1_groups':groups, 'step1_jobs':jobs, 'cells':cells, 'step2_family_grids':grids,
        'step2_grid_policy':'union of exact archived CP joint tuples within each family; no Cartesian parameter expansion',
        'step2_factors':{'scope':['per_instance','smallest_family'], 'validation_size':[32,100], 'refinement':[False,True]},
        'smallest_routes':SMALLEST, 'protocol':{'test_scores_used_for_selection':False,
            'maximum_cpu_cores':150, 'training_epochs':300, 'new_final_campaign_authorized':False,
            'non_lava_scientific_time_caps':None, 'lava_caps':{'preparation':3600,'optimization':3600,'whole_fit':9000}},
        'archive_sources':{str(p):sha(p) for p in (selected_path,screen_path,inventory_path)}, 'banks':bank_entries}
    write(root/'PLAN.json',plan,immutable=True)
    write(root/'BUILD_VERIFICATION.json',{'status':'passed','step1_logical_fits':5200,'step1_unique_fits':len(jobs),
        'step1_groups':130,'step2_family_candidate_counts':{k:len(v) for k,v in grids.items()},
        'step2_unique_screen_fits':sum(len(grids[family(route)]) for route in cells),
        'banks':len(bank_entries),'plan_sha256':sha(root/'PLAN.json'),'originals_changed':False},immutable=True)
    (root/'jobs').mkdir(exist_ok=True)
    for j in jobs.values(): write(root/'jobs'/(j['id']+'.json'),manifest(j),immutable=True)
    print(read(root/'BUILD_VERIFICATION.json'))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--archive',type=Path,required=True);p.add_argument('--root',type=Path,required=True)
    a=p.parse_args();build(a.archive.resolve(),a.root.resolve())
