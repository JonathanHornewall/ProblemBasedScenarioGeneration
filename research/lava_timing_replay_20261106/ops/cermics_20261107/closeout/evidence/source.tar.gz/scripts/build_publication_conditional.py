"""Build conditional validation tuning around broad-screen winners."""

from __future__ import annotations

import argparse
from pathlib import Path

from proximal_spo.artifacts import write_json
from proximal_spo.development_analysis import completed_validation_rows
from proximal_spo.publication_selection import build_conditional_tuning_campaign


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", action="append", type=Path, required=True)
    parser.add_argument("--source-sha256", action="append")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--campaign-run-root", required=True)
    arguments = parser.parse_args()
    rows = completed_validation_rows(
        arguments.run_root,
        required_source_sha256=arguments.source_sha256,
    )
    campaign = build_conditional_tuning_campaign(
        rows, run_root=arguments.campaign_run_root
    )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.output, campaign)
    print(
        f"wrote {len(campaign['variants'])} conditional tuning runs to "
        f"{arguments.output}"
    )


if __name__ == "__main__":
    main()
