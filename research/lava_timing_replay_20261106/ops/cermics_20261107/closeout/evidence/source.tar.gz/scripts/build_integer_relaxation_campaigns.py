"""Build staged campaigns for LP-relaxation training and hard-MIP deployment."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json
from proximal_spo.benchmarks.catalog import BENCHMARKS, build_benchmark

REPO_ROOT = Path(__file__).resolve().parents[1]
PREFLIGHT = REPO_ROOT / "results/integer_relaxation/preflight_all_routes.json"
CONFIG_ROOT = REPO_ROOT / "configs/integer_relaxation"


def _external_inventory() -> list[dict[str, Any]]:
    from dfl_extensions_lab.benchmarks import list_native_factory_routes

    rows: list[dict[str, Any]] = []
    for route in list_native_factory_routes():
        benchmark = route.build()
        model = benchmark.feasible_model
        if not model.integer_count:
            continue
        rows.append(
            {
                "benchmark_id": route.factory_id,
                "benchmark_source": "dfl_extensions_lab",
                "family": route.family,
                "data_seed": int(getattr(benchmark.generator, "source_seed", 17)),
                "variables": model.variable_count,
                "integer_variables": model.integer_count,
            }
        )
    return rows


def _local_inventory() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for benchmark_id in sorted(BENCHMARKS):
        problem = build_benchmark(benchmark_id, structural_seed=101)
        if problem.is_continuous:
            continue
        rows.append(
            {
                "benchmark_id": benchmark_id,
                "benchmark_source": "local",
                "family": "local_mip",
                "data_seed": 1,
                "variables": problem.variable_count,
                "integer_variables": int(problem.integrality.sum()),
            }
        )
    return rows


def _preflight_rows() -> dict[tuple[str, str], dict[str, Any]]:
    payload = json.loads(PREFLIGHT.read_text(encoding="utf-8"))
    return {
        (str(row["benchmark_source"]), str(row["benchmark_id"])): row
        for row in payload["rows"]
    }


def _route_design(
    route: dict[str, Any], profile: dict[str, Any]
) -> dict[str, int | float]:
    seconds = float(profile.get("hard_solve_seconds", 0.001))
    if seconds <= 0.03:
        return {
            "train": 128,
            "validation": 32,
            "test": 64,
            "epochs": 100,
            "validation_interval": 10,
        }
    if seconds <= 0.15:
        return {
            "train": 96,
            "validation": 24,
            "test": 48,
            "epochs": 80,
            "validation_interval": 10,
        }
    if seconds <= 0.75:
        return {
            "train": 48,
            "validation": 12,
            "test": 24,
            "epochs": 60,
            "validation_interval": 10,
        }
    if seconds <= 3.0:
        return {
            "train": 24,
            "validation": 6,
            "test": 12,
            "epochs": 40,
            "validation_interval": 10,
        }
    return {
        "train": 12,
        "validation": 3,
        "test": 6,
        "epochs": 30,
        "validation_interval": 10,
    }


def _base() -> dict[str, Any]:
    return {
        "name": "placeholder",
        "benchmark_id": "placeholder",
        "benchmark_source": "dfl_extensions_lab",
        "conditional_reference_samples": 64,
        "cost_coordinate_normalization": "standardize",
        "evaluate_test": True,
        "method": "mse",
        "interface": "full",
        "workers": 1,
        "sizes": {"train": 32, "validation": 8, "test": 16},
        "law": {
            "context_dimension": 5,
            "random_fraction": 1.0,
            "style": "positive",
            "noise": "gaussian",
            "noise_scale": 0.2,
            "signal_scale": 1.0,
            "polynomial_degree": 4,
        },
        "model": {
            "depth": 2,
            "width": 64,
            "activation": "silu",
            "layer_norm": False,
            "correction_depth": 1,
            "correction_width": 64,
            "dtype": "float32",
        },
        "training": {
            "epochs": 60,
            "batch_size": 32,
            "learning_rate": 0.001,
            "weight_decay": 1e-5,
            "optimizer": "adamw",
            "gradient_clip": 10.0,
            "validation_interval": 10,
            "patience": 100,
            "minimum_delta": 1e-8,
            "evaluation_batch_size": 128,
            "torch_threads": 1,
            "selection_mode": "validation_regret",
        },
        "seeds": {
            "data": 17,
            "structural": 101,
            "initialization": 201,
            "shuffle": 301,
            "perturbation": 401,
        },
        "method_parameters": {},
    }


def _slug(value: str) -> str:
    return value.replace(".", "_").replace("-", "_")


def _common_variant(route: dict[str, Any], profile: dict[str, Any]) -> dict[str, Any]:
    design = _route_design(route, profile)
    train = int(design["train"])
    variant: dict[str, Any] = {
        "benchmark_id": route["benchmark_id"],
        "benchmark_source": route["benchmark_source"],
        "sizes": {
            "train": train,
            "validation": int(design["validation"]),
            "test": int(design["test"]),
        },
        "seeds": {"data": int(route["data_seed"])},
        "training": {
            "epochs": int(design["epochs"]),
            "batch_size": min(64, train),
            "validation_interval": int(design["validation_interval"]),
            "patience": int(design["epochs"]) + 1,
        },
    }
    if route["benchmark_source"] == "local" and "knapsack" in str(
        route["benchmark_id"]
    ):
        variant["law"] = {"style": "negative"}
    return variant


def _routes() -> tuple[
    list[tuple[dict[str, Any], dict[str, Any]]],
    list[dict[str, Any]],
]:
    profiles = _preflight_rows()
    executable: list[tuple[dict[str, Any], dict[str, Any]]] = []
    excluded: list[dict[str, Any]] = []
    for route in [*_external_inventory(), *_local_inventory()]:
        key = (route["benchmark_source"], route["benchmark_id"])
        profile = profiles.get(key)
        if profile is None:
            # The only expected case is a route repaired after the incremental
            # preflight was written. It receives the cheapest tier and is still
            # represented explicitly in the generated campaign.
            profile = {"status": "complete", "hard_solve_seconds": 0.001}
        if profile.get("status") != "complete":
            excluded.append({**route, "preflight": profile})
            continue
        executable.append((route, profile))
    return executable, excluded


def _payload(stage: str) -> dict[str, Any]:
    executable, excluded = _routes()
    variants: list[dict[str, Any]] = []
    for route, profile in executable:
        common = _common_variant(route, profile)
        prefix = _slug(str(route["benchmark_id"]))
        if stage == "coverage":
            variants.extend(
                [
                    {"name": f"{prefix}_mse", **common, "method": "mse"},
                    {
                        "name": f"{prefix}_barrier",
                        **common,
                        "method": "soft_radial_log_barrier",
                        "method_parameters": {
                            "contraction": "rational",
                            "contraction_scale": 1.0,
                            "minimum_scale": 0.01,
                            "alpha_start": 0.1,
                            "alpha_end": 0.1,
                            "schedule": "fixed",
                            "deployment_mode": "hard_recovered",
                        },
                    },
                ]
            )
        elif stage == "comparators":
            variants.extend(
                [
                    {"name": f"{prefix}_wise", **common, "method": "wise"},
                    {
                        "name": f"{prefix}_spo_relax",
                        **common,
                        "method": "spo_plus_relaxation",
                    },
                    {
                        "name": f"{prefix}_knn",
                        **common,
                        "method": "knn",
                        "method_parameters": {
                            "neighbors": min(16, int(common["sizes"]["train"])),
                            "distance_weighted": True,
                        },
                    },
                ]
            )
        elif stage == "oracle_baselines":
            if float(profile.get("hard_solve_seconds", 999.0)) > 0.03:
                continue
            variants.extend(
                [
                    {
                        "name": f"{prefix}_spo_integer",
                        **common,
                        "method": "spo_plus",
                    },
                    {
                        "name": f"{prefix}_sfge",
                        **common,
                        "method": "sfge",
                        "method_parameters": {"sigma": 0.1, "samples": 1},
                    },
                ]
            )
        else:
            raise ValueError(f"unknown stage {stage}")
    return {
        "name": f"integer_relaxation_{stage}",
        "run_root": f"results/campaigns/integer_relaxation_{stage}",
        "design": {
            "status": "exploratory_development",
            "purpose": (
                "broad route coverage before family-specific tuning; no final "
                "comparative claim is licensed"
            ),
            "preflight_path": str(PREFLIGHT.relative_to(REPO_ROOT)),
            "implemented_integer_routes": len(executable) + len(excluded),
            "executable_routes": len(executable),
            "excluded_routes": excluded,
            "route_specific_sample_budget": True,
            "hard_deployment": True,
            "campaign_jobs_recommended": 3,
        },
        "base": _base(),
        "variants": variants,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "stage", choices=("coverage", "comparators", "oracle_baselines", "all")
    )
    arguments = parser.parse_args()
    stages = (
        ("coverage", "comparators", "oracle_baselines")
        if arguments.stage == "all"
        else (arguments.stage,)
    )
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    for stage in stages:
        path = CONFIG_ROOT / f"{stage}.json"
        payload = _payload(stage)
        write_json(path, payload)
        print(f"{path}: {len(payload['variants'])} variants")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
