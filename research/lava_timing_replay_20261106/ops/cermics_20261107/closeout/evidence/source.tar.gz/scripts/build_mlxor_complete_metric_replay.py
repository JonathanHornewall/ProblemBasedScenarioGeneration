#!/usr/bin/env python3
"""Build the retained-benchmark prediction and PyEPO timing replays.

The decision configurations are copied verbatim from the frozen publication
manifests.  The only addition to BCR is the paired-MSE physical-cost head and
the closed-form ray/gauge correction.  The timing replay replaces the frozen
SPO+ implementation by PyEPO's public SPO+ layer without changing its selected
network or training hyperparameters.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

RETAINED_BENCHMARKS = {
    "dys_shortest_path_25x25",
    "dys_cfl_50x5",
    "dys_cfl_100x10",
    "dys_cfl_200x10",
    "dys_cfl_250x10",
    "dys_knapsack_50x2",
    "dys_knapsack_100x2",
    "dys_knapsack_200x2",
    "dys_knapsack_400x2",
    "dys_knapsack_500x2",
    "lava_random_lp_150x50_paper_appendix",
    "predictiveco_cubic_topk",
    "sfge_kp50_values_seed_0",
    "pyepo_mdkp32x2_degree_6_noise_0_5_seed_0",
}
RETAINED_METHODS = {
    "soft_radial_log_barrier",
    "mse",
    "spo_plus",
    "spo_plus_relaxation",
}


def _prediction_variant(raw: dict[str, Any]) -> dict[str, Any]:
    variant = copy.deepcopy(raw)
    variant["name"] = f"mlxor_complete_metric_{variant['name']}"
    if variant["method"] == "soft_radial_log_barrier":
        parameters = dict(variant.get("method_parameters", {}))
        parameters.update(
            {
                "prediction_correction": True,
                # The paper uses only the fast closed-form ray/gauge map.
                "prediction_correction_cone": False,
                "prediction_correction_exact_only": True,
                "prediction_correction_include_projected_head": False,
                "prediction_correction_legacy": False,
                "prediction_correction_minimum_scale": 1e-6,
                "prediction_correction_mse_epochs": 180,
                "prediction_correction_mse_learning_rate": 3e-4,
                "prediction_correction_mu_normalize_directions": True,
                "prediction_correction_neural": True,
                "prediction_correction_neural_epochs": 1,
                "prediction_correction_neural_learning_rates": [1e-3],
                "prediction_correction_neural_patience": 1,
                "prediction_correction_replay_audit_size": 4,
                "prediction_correction_ridges": [1e-5],
            }
        )
        variant["method_parameters"] = parameters
    return variant


def _is_seed_one(raw: dict[str, Any]) -> bool:
    return str(raw.get("name", "")).endswith("_seed1")


def _pyepo_variant(raw: dict[str, Any]) -> dict[str, Any]:
    variant = copy.deepcopy(raw)
    source_method = str(variant["method"])
    if source_method == "spo_plus":
        variant["method"] = "pyepo_spo_plus"
    elif source_method == "spo_plus_relaxation":
        variant["method"] = "pyepo_spo_plus_relaxation"
    else:  # pragma: no cover - guarded by the builder
        raise ValueError(f"not an SPO+ variant: {source_method}")
    variant["name"] = f"mlxor_pyepo_retained_{variant['benchmark_id']}_seed1"
    variant["method_parameters"] = {"solver_backend": "ortools"}
    variant["workers"] = 1
    # Timing is training-only; deployment metrics come from the frozen replay.
    variant["evaluate_test"] = False
    return variant


def build(
    continuous: dict[str, Any], integer: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    source_variants = [*continuous["variants"], *integer["variants"]]
    prediction = [
        _prediction_variant(raw)
        for raw in source_variants
        if raw.get("benchmark_id") in RETAINED_BENCHMARKS
        and raw.get("method") in RETAINED_METHODS
    ]
    # Each route has BCR, MSE, and exactly one continuous/relaxation SPO+ arm.
    expected_prediction = len(RETAINED_BENCHMARKS) * 3 * 10
    if len(prediction) != expected_prediction:
        raise ValueError(
            f"expected {expected_prediction} prediction variants, found "
            f"{len(prediction)}"
        )
    prediction_identity = {
        (
            str(item["benchmark_id"]),
            str(item["method"]),
            str(item["name"]),
        )
        for item in prediction
    }
    if len(prediction_identity) != len(prediction):
        raise ValueError("duplicate prediction replay identity")

    pyepo = [
        _pyepo_variant(raw)
        for raw in source_variants
        if raw.get("benchmark_id") in RETAINED_BENCHMARKS
        and raw.get("method") in {"spo_plus", "spo_plus_relaxation"}
        and _is_seed_one(raw)
    ]
    if len(pyepo) != len(RETAINED_BENCHMARKS):
        raise ValueError(
            f"expected {len(RETAINED_BENCHMARKS)} PyEPO timing variants, "
            f"found {len(pyepo)}"
        )

    prediction_campaign = {
        "base": {},
        "design": {
            "purpose": "mlxor_all_retained_physical_cost_replay",
            "source_manifests": [
                "configs/publication/continuous_confirmation.json",
                "configs/publication/integer_confirmation.json",
            ],
            "decision_hyperparameters_changed": False,
            "test_already_opened_in_source_campaign": True,
            "selection_role": "post_hoc_reporting_not_decision_model_selection",
            "prediction_head": "paired_mse_exact_ray_gauge",
            "full_cone_projection_included": False,
            "benchmark_count": len(RETAINED_BENCHMARKS),
            "paired_seed_count": 10,
            "variant_count": len(prediction),
        },
        "name": "mlxor_complete_metric_replay",
        "run_root": "results/campaigns/mlxor_complete_metric_replay",
        "variants": prediction,
    }
    pyepo_campaign = {
        "base": {},
        "design": {
            "purpose": "official_pyepo_retained_final_configuration_timing",
            "source_manifests": [
                "configs/publication/continuous_confirmation.json",
                "configs/publication/integer_confirmation.json",
            ],
            "pyepo_version": "2.2.7",
            "test_evaluated": False,
            "selection_role": "implementation_replay_not_model_selection",
            "custom_solver_acceleration": False,
            "benchmark_count": len(RETAINED_BENCHMARKS),
            "variant_count": len(pyepo),
        },
        "name": "mlxor_pyepo_retained_timing",
        "run_root": "results/campaigns/mlxor_pyepo_retained_timing_ortools",
        "variants": pyepo,
    }

    matched_native_timing = [
        copy.deepcopy(item)
        for item in prediction
        if item["method"] in {"soft_radial_log_barrier", "mse"}
        and str(item["name"]).endswith("_seed1")
    ]
    if len(matched_native_timing) != 2 * len(RETAINED_BENCHMARKS):
        raise ValueError("incomplete seed-1 BCR/MSE timing campaign")
    for item in matched_native_timing:
        item["name"] = f"mlxor_matched_timing_{item['name']}"
    matched_native_campaign = {
        "base": {},
        "design": {
            "purpose": "matched_environment_bcr_mse_final_configuration_timing",
            "selection_role": "implementation_replay_not_model_selection",
            "test_already_opened_in_source_campaign": True,
            "benchmark_count": len(RETAINED_BENCHMARKS),
            "variant_count": len(matched_native_timing),
        },
        "name": "mlxor_matched_native_timing",
        "run_root": "results/campaigns/mlxor_matched_native_timing",
        "variants": matched_native_timing,
    }

    smoke_variant = next(
        copy.deepcopy(item)
        for item in prediction
        if item["method"] == "soft_radial_log_barrier"
    )
    smoke_variant["name"] = "mlxor_complete_metric_ray_smoke"
    smoke_variant["sizes"] = {"train": 32, "validation": 24, "test": 24}
    smoke_variant["training"].update(
        {
            "epochs": 2,
            "patience": 3,
            "schedule_reference_epochs": 2,
            "selection_mode": "last",
            "validation_epochs": [2],
            "validation_interval": 2,
        }
    )
    smoke_variant["method_parameters"].update(
        {
            "prediction_correction_mse_epochs": 2,
            "prediction_correction_replay_audit_size": 2,
        }
    )
    smoke_campaign = {
        "base": {},
        "design": {"purpose": "ray_only_prediction_correction_smoke"},
        "name": "mlxor_complete_metric_ray_smoke",
        "run_root": "results/campaigns/mlxor_complete_metric_ray_smoke",
        "variants": [smoke_variant],
    }
    return prediction_campaign, pyepo_campaign, matched_native_campaign, smoke_campaign


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    continuous = json.loads(
        (root / "configs/publication/continuous_confirmation.json").read_text()
    )
    integer = json.loads(
        (root / "configs/publication/integer_confirmation.json").read_text()
    )
    prediction, pyepo, matched_native, smoke = build(continuous, integer)
    outputs = {
        root / "configs/mlxor/complete_metric_replay.json": prediction,
        root / "configs/mlxor/pyepo_retained_timing.json": pyepo,
        root / "configs/mlxor/matched_native_timing.json": matched_native,
        root / "configs/mlxor/complete_metric_smoke.json": smoke,
    }
    for path, payload in outputs.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        print(f"wrote {len(payload['variants'])} variants to {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
