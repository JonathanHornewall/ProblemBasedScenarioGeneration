"""Build the staged, validation-gated PyEPO small-tau experiment program."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPO_ROOT / "configs" / "pyepo_small_tau"
SMALL_TAUS = (1.0, 0.3, 0.1, 0.03, 0.01, 0.003)
CONTROL_TAUS = (3.0, 10.0, 30.0, 100.0)
CORE_TAUS = SMALL_TAUS + CONTROL_TAUS
HEAD_TAUS = SMALL_TAUS + CONTROL_TAUS[:-1]
RIDGES = (1e-8, 1e-6, 1e-4)
CENTERED_RIDGES = (1e-3, 1e-2, 1e-1, 1.0)
DEVELOPMENT_SEEDS = (1, 2, 3)
CONFIRMATION_SEEDS = tuple(range(11, 21))
ANCHORED_EXPANSION_GRID = {
    30.0: (1e-3, 3e-3, 1e-2, 3e-2),
    100.0: (1e-3, 3e-3, 1e-2, 3e-2, 1e-1),
    300.0: (3e-3, 1e-2, 3e-2, 1e-1, 3e-1),
    1000.0: (1e-2, 3e-2, 1e-1, 3e-1),
    3000.0: (3e-2, 1e-1, 3e-1),
    10000.0: (1e-1, 3e-1, 1.0),
}


def _seeds(data_seed: int) -> dict[str, int]:
    return {
        "data": data_seed,
        "structural": 101,
        "initialization": 200 + data_seed,
        "shuffle": 300 + data_seed,
        "perturbation": 400 + data_seed,
    }


def _base(data_seed: int) -> dict[str, Any]:
    return {
        "name": "base",
        "benchmark_id": "cost.grid5",
        "method": "mse",
        "interface": "full",
        "workers": 4,
        "sizes": {"train": 1024, "validation": 256, "test": 512},
        "law": {
            "context_dimension": 5,
            "random_fraction": 1.0,
            "style": "positive",
            "noise": "pyepo_uniform",
            "noise_scale": 0.5,
            "signal_scale": 1.0,
            "polynomial_degree": 6,
        },
        "model": {
            "depth": 2,
            "width": 64,
            "activation": "silu",
            "layer_norm": False,
            "correction_depth": 2,
            "correction_width": 64,
        },
        "training": {
            "epochs": 200,
            "batch_size": 128,
            "learning_rate": 0.001,
            "weight_decay": 0.00001,
            "optimizer": "adamw",
            "gradient_clip": 10.0,
            "validation_interval": 5,
            "patience": 20,
            "minimum_delta": 0.00001,
            "evaluation_batch_size": 512,
            "torch_threads": 4,
            "selection_mode": "validation_regret",
        },
        "seeds": _seeds(data_seed),
        "method_parameters": {},
    }


def _tag(value: float) -> str:
    return f"{value:.0e}".replace("-", "m").replace("+", "p")


def _raw_grid() -> list[tuple[float, float]]:
    rates = {
        1.0: (1e-3, 3e-3, 1e-2, 3e-2, 1e-1),
        0.3: (3e-3, 1e-2, 3e-2, 1e-1, 3e-1),
        0.1: (3e-3, 1e-2, 3e-2, 1e-1, 3e-1),
        0.03: (3e-3, 1e-2, 3e-2, 1e-1, 3e-1),
        0.01: (3e-3, 1e-2, 3e-2, 1e-1, 3e-1),
        0.003: (3e-3, 1e-2, 3e-2, 1e-1, 3e-1),
        3.0: (3e-4, 1e-3, 3e-3, 1e-2, 3e-2),
        10.0: (1e-4, 3e-4, 1e-3, 3e-3, 1e-2),
        30.0: (1e-5, 3e-5, 1e-4, 3e-4, 1e-3),
        100.0: (1e-5, 3e-5, 1e-4, 3e-4, 1e-3),
    }
    return [(tau, rate) for tau in CORE_TAUS for rate in rates[tau]]


def _core_variants(seed: int) -> list[dict[str, Any]]:
    variants: list[dict[str, Any]] = []
    for method, rates in (
        ("mse", (3e-4, 1e-3, 3e-3, 1e-2)),
        ("wise", (3e-4, 1e-3, 3e-3, 1e-2)),
        ("spo_plus", (1e-4, 3e-4, 1e-3, 3e-3, 1e-2)),
    ):
        for rate in rates:
            variants.append(
                {
                    "name": f"dev_s{seed}_{method}_lr{_tag(rate)}",
                    "method": method,
                    "training": {"learning_rate": rate},
                    "method_parameters": {},
                }
            )
    for tau, rate in _raw_grid():
        variants.append(
            {
                "name": f"dev_s{seed}_prox_tau{_tag(tau)}_lr{_tag(rate)}",
                "method": "proximal",
                "training": {"learning_rate": rate},
                "method_parameters": {
                    "tau": tau,
                    "parameterization": "normalized",
                    "exact_head": False,
                },
            }
        )
    return variants


def _write_campaign(
    *,
    path: Path,
    name: str,
    run_root: str,
    seed: int,
    variants: list[dict[str, Any]],
) -> None:
    write_json(
        path,
        {
            "name": name,
            "run_root": run_root,
            "base": _base(seed),
            "variants": variants,
        },
    )


def _generate_development() -> None:
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    for seed in DEVELOPMENT_SEEDS:
        _write_campaign(
            path=CONFIG_ROOT / f"development_core_seed{seed}.json",
            name=f"pyepo_small_tau_development_core_seed{seed}",
            run_root="runs/pyepo_small_tau/development_core",
            seed=seed,
            variants=_core_variants(seed),
        )
        exact_variants = [
            {
                "name": (f"dev_s{seed}_exact_linear_tau{_tag(tau)}_ridge{_tag(ridge)}"),
                "method": "exact_proximal_linear",
                "method_parameters": {
                    "tau": tau,
                    "exact_head_ridge": ridge,
                },
            }
            for tau in SMALL_TAUS
            for ridge in RIDGES
        ]
        _write_campaign(
            path=CONFIG_ROOT / f"development_exact_linear_seed{seed}.json",
            name=f"pyepo_small_tau_development_exact_linear_seed{seed}",
            run_root="runs/pyepo_small_tau/development_exact_linear",
            seed=seed,
            variants=exact_variants,
        )


def _load(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected an object in {path}")
    return payload


def _selected_standard_arm(summary: dict[str, Any], method: str) -> dict[str, Any]:
    rows = summary.get("selected_arms")
    if not isinstance(rows, list):
        raise ValueError("selection summary lacks selected_arms")
    matches = [row for row in rows if row.get("method") == method]
    if len(matches) != 1 or not isinstance(matches[0].get("arm"), dict):
        raise ValueError(f"could not identify selected arm for {method}")
    return copy.deepcopy(matches[0]["arm"])


def _anchored_variant(
    *, seed: int, tau: float, rate: float, selected_mse_rate: float
) -> dict[str, Any]:
    return {
        "name": f"dev_s{seed}_anchored_tau{_tag(tau)}_lr{_tag(rate)}",
        "method": "anchored_proximal",
        "training": {"learning_rate": rate},
        "method_parameters": {
            "tau": tau,
            "alpha": 1.0,
            "base_method": "mse",
            "base_epochs": 200,
            "base_learning_rate": selected_mse_rate,
            "freeze_base": True,
            "center_on_base_decision": True,
        },
    }


def _generate_phase2(core_selection_path: Path) -> None:
    core = _load(core_selection_path)
    mse_arm = _selected_standard_arm(core, "mse")
    prox_arm = _selected_standard_arm(core, "proximal")
    selected_mse_rate = float(mse_arm["training"]["learning_rate"])
    selected_training_tau = float(prox_arm["method_parameters"]["tau"])
    selected_prox_rate = float(prox_arm["training"]["learning_rate"])
    for seed in DEVELOPMENT_SEEDS:
        post_variants: list[dict[str, Any]] = []
        mse_base_variants: list[dict[str, Any]] = []
        anchored_variants: list[dict[str, Any]] = []
        for tau in CORE_TAUS:
            for rate in (3e-5, 1e-4, 3e-4, 1e-3, 3e-3):
                anchored_variants.append(
                    _anchored_variant(
                        seed=seed,
                        tau=tau,
                        rate=rate,
                        selected_mse_rate=selected_mse_rate,
                    )
                )
        for tau in HEAD_TAUS:
            for ridge in RIDGES:
                post_variants.append(
                    {
                        "name": (
                            f"dev_s{seed}_post_adam_train_tau"
                            f"{_tag(selected_training_tau)}_head_tau{_tag(tau)}_"
                            f"ridge{_tag(ridge)}"
                        ),
                        "method": "proximal",
                        "training": {"learning_rate": selected_prox_rate},
                        "method_parameters": {
                            "tau": selected_training_tau,
                            "parameterization": "normalized",
                            "exact_head": True,
                            "exact_head_tau": tau,
                            "exact_head_ridge": ridge,
                        },
                    }
                )
                mse_base_variants.append(
                    {
                        "name": (
                            f"dev_s{seed}_exact_mse_base_tau{_tag(tau)}_"
                            f"ridge{_tag(ridge)}"
                        ),
                        "method": "exact_proximal_mse_base",
                        "model": {"correction_depth": 0},
                        "training": {"learning_rate": selected_mse_rate},
                        "method_parameters": {
                            "tau": tau,
                            "base_epochs": 200,
                            "base_learning_rate": selected_mse_rate,
                            "center_on_base_decision": True,
                            "exact_head_ridge": ridge,
                        },
                    }
                )
        _write_campaign(
            path=CONFIG_ROOT / f"development_anchored_seed{seed}.json",
            name=f"pyepo_small_tau_development_anchored_seed{seed}",
            run_root="runs/pyepo_small_tau/development_anchored",
            seed=seed,
            variants=anchored_variants,
        )
        _write_campaign(
            path=CONFIG_ROOT / f"development_post_adam_exact_seed{seed}.json",
            name=f"pyepo_small_tau_development_post_adam_exact_seed{seed}",
            run_root="runs/pyepo_small_tau/development_post_adam_exact",
            seed=seed,
            variants=post_variants,
        )
        _write_campaign(
            path=CONFIG_ROOT / f"development_mse_base_exact_seed{seed}.json",
            name=f"pyepo_small_tau_development_mse_base_exact_seed{seed}",
            run_root="runs/pyepo_small_tau/development_mse_base_exact",
            seed=seed,
            variants=mse_base_variants,
        )


def _generate_anchored_expansion(core_selection_path: Path) -> None:
    core = _load(core_selection_path)
    mse_arm = _selected_standard_arm(core, "mse")
    selected_mse_rate = float(mse_arm["training"]["learning_rate"])
    for seed in DEVELOPMENT_SEEDS:
        variants = [
            _anchored_variant(
                seed=seed,
                tau=tau,
                rate=rate,
                selected_mse_rate=selected_mse_rate,
            )
            for tau, rates in ANCHORED_EXPANSION_GRID.items()
            for rate in rates
        ]
        _write_campaign(
            path=CONFIG_ROOT / f"development_anchored_expansion_seed{seed}.json",
            name=f"pyepo_small_tau_anchored_expansion_seed{seed}",
            run_root="runs/pyepo_small_tau/development_anchored_expansion",
            seed=seed,
            variants=variants,
        )


def _generate_centered_post(core_selection_path: Path) -> None:
    core = _load(core_selection_path)
    prox_arm = _selected_standard_arm(core, "proximal")
    selected_training_tau = float(prox_arm["method_parameters"]["tau"])
    selected_prox_rate = float(prox_arm["training"]["learning_rate"])
    for seed in DEVELOPMENT_SEEDS:
        variants = [
            {
                "name": (
                    f"dev_s{seed}_post_adam_centered_train_tau"
                    f"{_tag(selected_training_tau)}_head_tau{_tag(tau)}_"
                    f"ridge{_tag(ridge)}"
                ),
                "method": "proximal",
                "training": {"learning_rate": selected_prox_rate},
                "method_parameters": {
                    "tau": selected_training_tau,
                    "parameterization": "normalized",
                    "exact_head": True,
                    "exact_head_tau": tau,
                    "exact_head_ridge": ridge,
                    "exact_head_center_on_adam": True,
                },
            }
            for tau in HEAD_TAUS
            for ridge in CENTERED_RIDGES
        ]
        _write_campaign(
            path=CONFIG_ROOT / f"development_post_adam_centered_exact_seed{seed}.json",
            name=f"pyepo_small_tau_development_post_adam_centered_exact_seed{seed}",
            run_root="runs/pyepo_small_tau/development_post_adam_centered_exact",
            seed=seed,
            variants=variants,
        )


def _selected_exact_arm(summary: dict[str, Any]) -> dict[str, Any]:
    row = summary.get("selected_arm")
    if not isinstance(row, dict) or not isinstance(row.get("arm"), dict):
        raise ValueError("exact-head selection lacks selected_arm.arm")
    return copy.deepcopy(row["arm"])


def _named_arm(arm: dict[str, Any], *, name: str, seed: int) -> dict[str, Any]:
    result = copy.deepcopy(arm)
    result["name"] = name
    result["seeds"] = _seeds(seed)
    return result


def _generate_confirmation(
    *,
    core_selection_path: Path,
    anchored_selection_path: Path,
    linear_selection_path: Path,
    mse_base_selection_path: Path,
    post_selection_path: Path,
    centered_post_selection_path: Path,
) -> None:
    core = _load(core_selection_path)
    anchored = _load(anchored_selection_path)
    linear = _load(linear_selection_path)
    mse_base = _load(mse_base_selection_path)
    post = _load(post_selection_path)
    centered_post = _load(centered_post_selection_path)
    chosen: list[tuple[str, dict[str, Any]]] = [
        (method, _selected_standard_arm(core, method))
        for method in ("mse", "wise", "spo_plus", "proximal")
    ]
    chosen.append(
        (
            "anchored_proximal",
            _selected_standard_arm(anchored, "anchored_proximal"),
        )
    )
    chosen.extend(
        [
            (
                "exact_proximal_linear",
                _selected_standard_arm(linear, "exact_proximal_linear"),
            ),
            (
                "exact_proximal_mse_base",
                _selected_standard_arm(mse_base, "exact_proximal_mse_base"),
            ),
            ("post_adam_exact_proximal", _selected_exact_arm(post)),
            (
                "post_adam_centered_exact_proximal",
                _selected_exact_arm(centered_post),
            ),
        ]
    )
    for seed in CONFIRMATION_SEEDS:
        variants = [
            _named_arm(arm, name=f"confirm_s{seed}_{label}", seed=seed)
            for label, arm in chosen
        ]
        _write_campaign(
            path=CONFIG_ROOT / f"confirmation_seed{seed}.json",
            name=f"pyepo_small_tau_confirmation_seed{seed}",
            run_root="runs/pyepo_small_tau/confirmation",
            seed=seed,
            variants=variants,
        )


def _generate_anchored_confirmation(anchored_selection_path: Path) -> None:
    anchored = _load(anchored_selection_path)
    selected = _selected_standard_arm(anchored, "anchored_proximal")
    for seed in CONFIRMATION_SEEDS:
        _write_campaign(
            path=CONFIG_ROOT / f"confirmation_anchored_expanded_seed{seed}.json",
            name=f"pyepo_small_tau_anchored_expanded_confirmation_seed{seed}",
            run_root="runs/pyepo_small_tau/confirmation",
            seed=seed,
            variants=[
                _named_arm(
                    selected,
                    name=f"confirm_s{seed}_anchored_proximal_expanded",
                    seed=seed,
                )
            ],
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="phase", required=True)
    subparsers.add_parser("development")
    phase2 = subparsers.add_parser("phase2")
    phase2.add_argument("--core-selection", type=Path, required=True)
    anchored_expansion = subparsers.add_parser("anchored-expansion")
    anchored_expansion.add_argument("--core-selection", type=Path, required=True)
    centered = subparsers.add_parser("centered-post")
    centered.add_argument("--core-selection", type=Path, required=True)
    confirmation = subparsers.add_parser("confirmation")
    confirmation.add_argument("--core-selection", type=Path, required=True)
    confirmation.add_argument("--anchored-selection", type=Path, required=True)
    confirmation.add_argument("--linear-selection", type=Path, required=True)
    confirmation.add_argument("--mse-base-selection", type=Path, required=True)
    confirmation.add_argument("--post-selection", type=Path, required=True)
    confirmation.add_argument("--centered-post-selection", type=Path, required=True)
    anchored_confirmation = subparsers.add_parser("anchored-confirmation")
    anchored_confirmation.add_argument("--anchored-selection", type=Path, required=True)
    arguments = parser.parse_args()
    if arguments.phase == "development":
        _generate_development()
    elif arguments.phase == "phase2":
        _generate_phase2(arguments.core_selection)
    elif arguments.phase == "anchored-expansion":
        _generate_anchored_expansion(arguments.core_selection)
    elif arguments.phase == "centered-post":
        _generate_centered_post(arguments.core_selection)
    elif arguments.phase == "confirmation":
        _generate_confirmation(
            core_selection_path=arguments.core_selection,
            anchored_selection_path=arguments.anchored_selection,
            linear_selection_path=arguments.linear_selection,
            mse_base_selection_path=arguments.mse_base_selection,
            post_selection_path=arguments.post_selection,
            centered_post_selection_path=arguments.centered_post_selection,
        )
    else:
        _generate_anchored_confirmation(arguments.anchored_selection)


if __name__ == "__main__":
    main()
