"""Freeze paired analytic-skew winners and emit sealed test runs."""

from __future__ import annotations

import argparse
from pathlib import Path

from proximal_spo.artifacts import write_json
from proximal_spo.frozen_skew_protocol import (
    build_frozen_skew_confirmation_campaign,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", action="append", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--campaign-run-root", required=True)
    parser.add_argument("--required-refinement-seeds", type=int, default=3)
    parser.add_argument("--test-size", type=int, default=16_384)
    arguments = parser.parse_args()
    campaign = build_frozen_skew_confirmation_campaign(
        arguments.run_root,
        run_root=arguments.campaign_run_root,
        required_refinement_seeds=arguments.required_refinement_seeds,
        test_size=arguments.test_size,
    )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.output, campaign)
    print(f"wrote {len(campaign['variants'])} frozen-skew confirmation runs")


if __name__ == "__main__":
    main()
