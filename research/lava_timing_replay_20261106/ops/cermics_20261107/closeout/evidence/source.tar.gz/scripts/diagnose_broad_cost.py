"""Generate a no-training contextual-richness receipt for the broad suite."""

from __future__ import annotations

import argparse
from pathlib import Path

from build_broad_cost_campaigns import DESIGNS, _base

from proximal_spo.artifacts import write_json
from proximal_spo.config import RunSpec
from proximal_spo.runner import diagnose_dataset


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for design in DESIGNS:
        spec = RunSpec.from_dict(_base(design, 1))
        rows.append(diagnose_dataset(spec))
    write_json(
        arguments.output,
        {
            "purpose": "pre-training contextual-decision richness gate",
            "training_runs": 0,
            "benchmarks": rows,
        },
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
