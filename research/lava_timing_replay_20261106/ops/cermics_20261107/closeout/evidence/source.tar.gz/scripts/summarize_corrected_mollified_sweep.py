"""Incrementally summarize the corrected mollified sigma--tau screen."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from proximal_spo.analysis import summarize_validation_selection
from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
RESULT_ROOT = REPO_ROOT / "results" / "mollified_corrected"


def _campaign_progress(campaign: Path, run_root: Path) -> tuple[Path, dict[str, Any]]:
    digest = hashlib.sha256(campaign.read_bytes()).hexdigest()[:10]
    candidates = sorted(
        run_root.glob(f"campaign_progress_{digest}_*.json"),
        key=lambda path: path.stat().st_mtime_ns,
    )
    if not candidates:
        raise FileNotFoundError("campaign has no progress receipt yet")
    path = candidates[-1]
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("campaign progress receipt must be an object")
    return path, payload


def _run_path(row: dict[str, Any]) -> Path:
    path = Path(str(row["run_directory"]))
    return path if path.is_absolute() else REPO_ROOT / path


def _enriched_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    enriched: list[dict[str, Any]] = []
    base_by_seed: dict[int, tuple[str, float]] = {}
    for row in rows:
        run_path = _run_path(row)
        base = json.loads(
            (run_path / "embedded_mse_base.json").read_text(encoding="utf-8")
        )
        diagnostic = json.loads(
            (run_path / "mollification_diagnostics.json").read_text(
                encoding="utf-8"
            )
        )
        if diagnostic.get("deployment_rule") != "hard_optimizer_at_recovered_cost":
            raise ValueError(f"run did not use corrected hard deployment: {run_path}")
        if diagnostic.get("shared_training_evaluation_bank") is not True:
            raise ValueError(
                f"run did not share its finite perturbation bank: {run_path}"
            )
        seed = int(row["seeds"]["data"])
        base_digest = str(base["parameter_sha256"])
        base_regret = float(base["validation"]["mean_regret"])
        previous = base_by_seed.setdefault(seed, (base_digest, base_regret))
        if previous != (base_digest, base_regret):
            raise ValueError(f"embedded MSE base changed within seed {seed}")
        arm = row["arm"]
        parameters = arm["method_parameters"]
        validation_regret = float(row["validation_mean_regret"])
        enriched.append(
            {
                "name": str(row["name"]),
                "data_seed": seed,
                "sigma": float(parameters["sigma"]),
                "tau": float(parameters["tau"]),
                "learning_rate": float(arm["training"]["learning_rate"]),
                "validation_regret": validation_regret,
                "mse_validation_regret": base_regret,
                "paired_delta": validation_regret - base_regret,
                "best_epoch": int(row["best_epoch"]),
                "training_wall_seconds": float(row["training_wall_seconds"]),
                "run_directory": str(row["run_directory"]),
            }
        )
    return sorted(
        enriched,
        key=lambda item: (item["sigma"], item["tau"], item["data_seed"]),
    )


def _aggregate(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[tuple[float, float], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[(row["sigma"], row["tau"])].append(row)
    result: list[dict[str, Any]] = []
    for (sigma, tau), group in groups.items():
        deltas = [float(row["paired_delta"]) for row in group]
        result.append(
            {
                "sigma": sigma,
                "tau": tau,
                "completed_seeds": sorted(int(row["data_seed"]) for row in group),
                "seed_count": len(group),
                "mean_validation_regret": sum(
                    float(row["validation_regret"]) for row in group
                )
                / len(group),
                "mean_mse_validation_regret": sum(
                    float(row["mse_validation_regret"]) for row in group
                )
                / len(group),
                "mean_paired_delta": sum(deltas) / len(deltas),
                "improved_seed_count": sum(delta < 0.0 for delta in deltas),
                "maximum_paired_delta": max(deltas),
                "mean_training_wall_seconds": sum(
                    float(row["training_wall_seconds"]) for row in group
                )
                / len(group),
            }
        )
    return sorted(
        result,
        key=lambda item: (
            item["seed_count"] != 3,
            item["mean_paired_delta"],
            item["sigma"],
            item["tau"],
        ),
    )


def _markdown(summary: dict[str, Any]) -> str:
    design = summary["design"]
    aggregates = summary["aggregates"]
    lookup = {(row["sigma"], row["tau"]): row for row in aggregates}
    lines = [
        "# Corrected mollified sigma--tau screen",
        "",
        f"Completed runs: **{summary['completed_runs']}/{summary['expected_runs']}**. ",
        "Complete three-seed cells: "
        f"**{summary['complete_cells']}/{summary['expected_cells']}**.",
        "",
        "Each cell is mean paired validation regret minus the embedded MSE base; "
        "negative is better. Parentheses show completed seeds.",
        "",
        "| sigma \\ tau | " + " | ".join(f"{tau:g}" for tau in design["taus"]) + " |",
        "|---|" + "---:|" * len(design["taus"]),
    ]
    for sigma in design["sigmas"]:
        cells = []
        for tau in design["taus"]:
            row = lookup.get((float(sigma), float(tau)))
            cells.append(
                "--"
                if row is None
                else f"{row['mean_paired_delta']:+.5f} ({row['seed_count']})"
            )
        lines.append(f"| {sigma:g} | " + " | ".join(cells) + " |")
    complete = [row for row in aggregates if row["seed_count"] == 3]
    lines.extend(["", "## Best complete cells", ""])
    if not complete:
        lines.append("No complete three-seed cell yet.")
    else:
        lines.extend(
            [
                "| rank | sigma | tau | paired delta | MSE wins | mean regret |",
                "|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for rank, row in enumerate(complete[:15], start=1):
            lines.append(
                f"| {rank} | {row['sigma']:g} | {row['tau']:g} | "
                f"{row['mean_paired_delta']:+.6f} | "
                f"{row['improved_seed_count']}/3 | "
                f"{row['mean_validation_regret']:.6f} |"
            )
    return "\n".join(lines) + "\n"


def summarize(campaign: Path) -> dict[str, Any]:
    campaign_payload = json.loads(campaign.read_text(encoding="utf-8"))
    run_root = REPO_ROOT / str(campaign_payload["run_root"])
    progress_path, progress = _campaign_progress(campaign, run_root)
    source = progress.get("source_sha256")
    if not isinstance(source, str):
        raise ValueError("campaign progress lacks source digest")
    live = summarize_validation_selection(run_root, source_sha256=source)
    rows = _enriched_rows(live["candidate_rows"])
    aggregates = _aggregate(rows)
    design = campaign_payload["design"]
    expected_cells = len(design["sigmas"]) * len(design["taus"])
    result = {
        "campaign": str(campaign.relative_to(REPO_ROOT)),
        "campaign_progress": str(progress_path.relative_to(REPO_ROOT)),
        "source_sha256": source,
        "design": design,
        "expected_runs": len(campaign_payload["variants"]),
        "completed_runs": len(rows),
        "expected_cells": expected_cells,
        "complete_cells": sum(row["seed_count"] == 3 for row in aggregates),
        "rows": rows,
        "aggregates": aggregates,
    }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--strict", action="store_true")
    arguments = parser.parse_args()
    campaign = arguments.campaign.resolve()
    summary = summarize(campaign)
    if arguments.strict and summary["completed_runs"] != summary["expected_runs"]:
        raise ValueError("strict summary requested before campaign completion")
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    write_json(RESULT_ROOT / "sigma_tau_progress.json", summary)
    (RESULT_ROOT / "sigma_tau_progress.md").write_text(
        _markdown(summary), encoding="utf-8"
    )
    buffer = io.StringIO()
    fieldnames = list(summary["rows"][0]) if summary["rows"] else ["name"]
    writer = csv.DictWriter(buffer, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(summary["rows"])
    (RESULT_ROOT / "sigma_tau_progress.csv").write_text(
        buffer.getvalue(), encoding="utf-8"
    )
    print(RESULT_ROOT / "sigma_tau_progress.md")


if __name__ == "__main__":
    main()
