"""Additive recovery of resource-censored SPO fits; archives stay immutable."""
import copy
from build_central_path_final import read, sha


class RecoveryPending(Exception):
    """An original owned fit must finish before a recovery selection freezes."""


def scientific_job(job):
    result = copy.deepcopy(job)
    for name in ("execution_repair", "recovery_of"):
        result.pop(name, None)
    return result


class MemoryRecovery:
    def __init__(self, root, screen):
        self.root = root
        path = root / "spo_memory_recovery.json"
        self.manifest = read(path) if path.exists() else None
        self.groups = set()
        self.jobs = []
        if self.manifest is None:
            return
        self.tag = self.manifest["repair_id"]
        if self.tag != "memory_repair_v1":
            raise ValueError("unknown memory recovery version")
        originals = {j["id"]: j for j in screen["jobs"]}
        replacements = {}
        for job in self.manifest["jobs"]:
            old_id = job["recovery_of"]
            old = originals[old_id]
            if old["method"] != "spo_plus" or old["stage"] != "screen":
                raise ValueError("recovery must replace only SPO screening fits")
            normalized = scientific_job(job)
            normalized["id"] = old_id
            normalized["config"]["name"] = old["config"]["name"]
            if normalized != old or job["id"] != old_id + "__" + self.tag:
                raise ValueError("memory recovery changed a scientific configuration")
            record = read(root / "results/receipts" / (old_id + ".json"))
            if record["status"] == "complete" or "memory" not in str(record.get("error", "")).lower():
                raise ValueError("recovery source was not memory-censored")
            if old_id in replacements:
                raise ValueError("duplicate recovery source")
            replacements[old_id] = job
            self.groups.add((job["cell"], job["method"]))
        self.jobs = list(replacements.values())
        screen["jobs"] = [replacements.get(j["id"], j) for j in screen["jobs"]]

    def attach(self, execution, known):
        if self.manifest is None:
            return False
        fingerprint = sha(self.manifest)
        if execution.get("memory_recovery_fingerprint", fingerprint) != fingerprint:
            raise ValueError("frozen recovery manifest changed")
        for job in self.jobs:
            previous = known.get(job["id"])
            if previous is not None and previous != job:
                raise ValueError("recovery job identity changed")
            if previous is None:
                execution["jobs"].append(job)
                known[job["id"]] = job
        execution["memory_recovery_fingerprint"] = fingerprint
        return True

    def suffix(self, key):
        return "__" + self.tag if key in self.groups else ""

    def selected_jobs(self, key, selected, known):
        if key not in self.groups:
            return
        resolved = []
        for generated in selected["jobs"]:
            job = scientific_job(generated)
            old = known.get(job["id"])
            if old is not None:
                receipt = self.root / "results/receipts" / (old["id"] + ".json")
                if not receipt.exists():
                    # Never duplicate a running fit or silently take its lease.
                    raise RecoveryPending(old["id"])
                record = read(receipt)
                if old == job and (record["status"] == "complete" or
                        "memory" not in str(record.get("error", "")).lower()):
                    resolved.append(old)
                    continue
            old_id = job["id"]
            job.update(id=old_id + "__" + self.tag, recovery_of=old_id,
                       execution_repair=self.tag)
            job["config"]["name"] = job["id"]
            resolved.append(job)
        selected["jobs"] = resolved
        selected["execution_repair"] = self.tag
