"""Run reviewed lifecycle triplets, each on one common Slurm CPU; no retuning."""
from __future__ import annotations

import argparse
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import signal
import socket
import subprocess
import sys
import time
import traceback

from pilot_common import read, write
from solver_reuse_ablation import MODES, REVISION, digest
from solver_reuse_ablation_scope import authorized_scope_outcome, mode_admission


def reviewed_contract(root):
    path = root / "MANIFEST.json"
    manifest = read(path)
    preparation = read(root / "PREPARATION.json")
    review = read(root / "REVIEW_READY.json")
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if (manifest["revision"] != REVISION or preparation["manifest_sha256"] != actual
            or review.get("manifest_sha256") != actual or review.get("status") != "approved"):
        raise RuntimeError("This exact ablation manifest has not passed parent review")
    source = read(root / "source_receipt.json")
    if not source.get("scientific_source_commit") or review.get("source_commit") != source["scientific_source_commit"]:
        raise RuntimeError("Reviewed source revision differs from the staged revision")
    launch = read(root / "ops/LAUNCH.json")
    if (root / "ops/TERMINAL.json").exists() or time.time() >= launch["deadline_unix"]:
        raise RuntimeError("This finite ablation attempt is terminal or expired")
    if not os.environ.get("SLURM_JOB_ID") or socket.gethostname().startswith("master"):
        raise RuntimeError("Numerical ablation work requires CERMICS Slurm")
    if len(os.sched_getaffinity(0)) != 1:
        raise RuntimeError("A mode triplet must be bound to one common CPU")
    if any(os.environ.get(k) != "1" for k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS",
             "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")):
        raise RuntimeError("All numerical libraries require one thread")
    return manifest


def hardware():
    cpu = next(iter(os.sched_getaffinity(0)))
    topology = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
    info = Path("/proc/cpuinfo").read_text().splitlines()
    return {"hostname": socket.gethostname(), "logical_cpu": cpu,
        "physical_package_id": (topology / "physical_package_id").read_text().strip(),
        "core_id": (topology / "core_id").read_text().strip(),
        "cpu_model": next(x.split(":", 1)[1].strip() for x in info if x.startswith("model name")),
        "platform": platform.platform(), "load_average": list(os.getloadavg()),
        "slurm_job_id": os.environ["SLURM_JOB_ID"], "observed_unix": time.time(),
        "timing_claim": "Per-fit CPU binding; triplet placement policy is recorded separately; shared-host contention can affect wall time"}


def reference_job(root, manifest, triplet):
    path = root / "REFERENCE_JOBS.json.gz"
    expected = read(root / "PREPARATION.json")["reference_jobs_sha256"]
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise RuntimeError("Frozen reference configurations changed")
    with gzip.open(path, "rt") as stream:
        job = json.load(stream)[triplet["reference_job_id"]]
    if digest(job) != triplet["reference_job_sha256"] or job["config"]["seeds"] != triplet["seeds"]:
        raise RuntimeError("Reference job or original full seed bundle changed")
    if (job["training_oracle"] != "continuous_relaxation" or job["wise_transform"]
            or job["method"] not in ("spo_plus", "pfyl", "nce")
            or job["config"]["training"]["epochs"] != 300):
        raise RuntimeError("Ablation entry is outside the frozen main-table protocol")
    return job


def validate_input_hashes(root, manifest, reference_id, observed):
    path = root / manifest["expected_input_hashes"]["path"]
    if hashlib.sha256(path.read_bytes()).hexdigest() != manifest["expected_input_hashes"]["sha256"]:
        raise RuntimeError("Expected original input hashes changed")
    with gzip.open(path, "rt") as stream:
        expected = json.load(stream)[reference_id]
    if observed != expected:
        raise RuntimeError("Supplied train/validation arrays differ from the original reference fit")


def finalize_record(record, session, started):
    """A cleanup/telemetry error must still leave a terminal fit receipt."""
    errors = []
    try:
        session.close()
    except BaseException as exc:
        errors.append({"operation": "native_cleanup", "error": repr(exc)})
    summary = record.get("summary", {})
    try:
        record["solver_lifecycle"] = session.receipt(summary.get("optimization_wall_seconds"),
                                                     summary.get("optimization_cpu_seconds"))
    except BaseException as exc:
        errors.append({"operation": "telemetry_receipt", "error": repr(exc)})
        record["solver_lifecycle"] = {"unavailable": repr(exc)}
    try:
        record["hardware_after"] = hardware()
    except BaseException as exc:
        errors.append({"operation": "hardware_receipt", "error": repr(exc)})
    try:
        usage = resource.getrusage(resource.RUSAGE_SELF)
        record["resource_usage"] = {"process_cpu_seconds": usage.ru_utime + usage.ru_stime,
            "peak_process_resident_bytes": usage.ru_maxrss * 1024}
    except BaseException as exc:
        errors.append({"operation": "resource_receipt", "error": repr(exc)})
    if errors:
        record["finalization_errors"] = errors
        if record.get("status") not in ("failed", "censored"):
            record.update(status="failed", error_type="LifecycleFinalizationError",
                          error="Fit metrics retained; native cleanup/receipt failed")
    record.update(finished_unix=time.time(), total_wall_seconds=time.perf_counter() - started)


def hold_dispatch(root, fit_id, reason):
    if authorized_scope_outcome(root, fit_id):
        return
    if (root / "PLACEMENT_AMENDMENT_20261024_PARALLEL.json").exists():
        from solver_reuse_ablation_parallel import failure
        failure(root, reason, fit_id=fit_id)
        return
    path = root / "ops/ADMISSION_HOLD.json"
    if not path.exists():
        try:
            write(path, {"reason": reason, "fit_id": fit_id, "unix": time.time(),
                "recovery": "Diagnose and concretely repair; preserve active fits and all attempt records"}, immutable=True)
        except RuntimeError:
            if not path.exists():
                raise


def run_fit(root, manifest, triplet, mode, parallel_owner=None):
    if not mode_admission(root, triplet, mode):
        return read(root / "results/receipts" / (triplet["fit_ids"][mode] + ".json"))
    job = reference_job(root, manifest, triplet)
    fit_id = triplet["fit_ids"][mode]
    result_path = root / "results/receipts" / (fit_id + ".json")
    lock_path = root / "ops/fit_locks" / (fit_id + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a") as guard:
        fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if result_path.exists():
            return read(result_path)  # Recovery requires explicit retained attempt reconciliation.
        before = hardware()
        placement = {"policy": "legacy_same_exact_cpu"}
        if (root / "PLACEMENT_AMENDMENT_20261024_PARALLEL.json").exists():
            from solver_reuse_ablation_parallel import validate_placement
            placement = validate_placement(root, triplet, mode, before, parallel_owner)
        else:
            paired = read(root / "ops/triplet_hardware" / (triplet["id"] + ".json"))
            if any(paired[k] != before[k] for k in ("hostname", "logical_cpu", "physical_package_id", "core_id")):
                raise RuntimeError("Mode hardware differs from its paired triplet")
        import importlib.metadata
        versions = {p: importlib.metadata.version(p) for p in ("highspy", "pyepo", "torch", "numpy", "scipy")}
        if versions["highspy"] != "1.12.0" or versions["pyepo"] != "1.0.2":
            raise RuntimeError("Require the original pinned HiGHS1.12.0 / PyEPO1.0.2 environment")
        import torch
        import run_central_path_final as maintained
        import run_public_solver_free_matched as matched
        from proximal_spo.solver_lifecycle import LifecycleSession
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        os.environ["CENTRAL_PATH_FROZEN_DATA"] = manifest["input_roots"][triplet["input_bank_group"]]
        attempt = root / "results/attempts" / fit_id / f"{time.time_ns()}-{os.getpid()}"
        attempt.mkdir(parents=True)
        record = {"fit_id": fit_id, "triplet_id": triplet["id"], "mode": mode,
            "reference_job_id": job["id"], "reference_job_sha256": digest(job), "job": job,
            "status": "running", "phase": "preprocessing", "attempt_directory": str(attempt),
            "pid": os.getpid(), "host": socket.gethostname(),
            "started_unix": time.time(), "test_access": False, "versions": versions,
            "hardware_before": before, "placement": placement, "source": read(root / "source_receipt.json")}
        progress = root / "results/progress" / (fit_id + ".json")
        update = maintained.ProgressUpdates(record, progress, time.perf_counter(), interval=60)
        session = LifecycleSession(job["method"], mode)
        started = time.perf_counter()

        def interrupted(*_):
            raise InterruptedError("Finite allocation stopped; preserve checkpoint and attempt")

        signal.signal(signal.SIGTERM, interrupted)
        signal.signal(signal.SIGINT, interrupted)
        try:
            loaded = maintained.load_job_data(job)
            if loaded.provenance.get("generator_called_by_fit") is not False:
                raise RuntimeError("Only existing supplied input banks are permitted")
            record["benchmark_provenance"] = loaded.provenance
            record["data_hashes"] = {split: {field: matched._hash_array(
                getattr(getattr(loaded.dataset, split), field)) for field in
                ("contexts", "physical_costs", "conditional_mean_costs")}
                for split in ("train", "validation")}
            validate_input_hashes(root, manifest, job["id"], record["data_hashes"])
            matched._seed(job["config"]["seeds"]["initialization"])

            def training_started():
                record["preprocessing_wall_seconds"] = time.perf_counter() - started
                update("training", _force_progress=True)

            summary, curve = maintained.baseline_fit(job, loaded, attempt, update,
                training_started, lifecycle=session)
            if summary["epochs_completed"] != 300 or summary["optimization_cap_reached"]:
                raise RuntimeError("Frozen300epoch horizon was not completed")
            record.update(status="complete", summary=summary, curve=curve, test_access=True)
        except BaseException as exc:
            record.update(status="censored" if isinstance(exc, (InterruptedError, KeyboardInterrupt)) else "failed",
                error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
        finally:
            finalize_record(record, session, started)
            try:
                if (attempt / "TEST_ACCESS.json").exists():
                    record["test_access"] = True
                    record["test_access_receipt_sha256"] = hashlib.sha256((attempt / "TEST_ACCESS.json").read_bytes()).hexdigest()
                write(attempt / "LIFECYCLE_TELEMETRY.json", record["solver_lifecycle"], immutable=True)
            except Exception as exc:
                record.setdefault("finalization_errors", []).append(
                    {"operation": "auxiliary_receipt", "error": repr(exc)})
                if record["status"] == "complete":
                    record.update(status="failed", error_type="LifecycleFinalizationError",
                                  error="Metrics retained; auxiliary receipt failed")
            write(result_path, record, immutable=True)
            write(progress, record)
            if record["status"] != "complete":
                hold_dispatch(root, fit_id, "failed_or_censored_fit")
        return record


def run_triplet(root, manifest, triplet):
    path = root / "ops/triplet_hardware" / (triplet["id"] + ".json")
    current = hardware()
    if path.exists():
        prior = read(path)
        if any(prior[k] != current[k] for k in ("hostname", "logical_cpu", "physical_package_id", "core_id")):
            raise RuntimeError("Partial triplet moved hardware; parent must reconcile an explicit matched recovery")
    else:
        write(path, current, immutable=True)
    for mode in triplet["mode_order"]:
        reviewed_contract(root)
        receipt = root / "results/receipts" / (triplet["fit_ids"][mode] + ".json")
        if receipt.exists():
            continue
        while (root / "ops/ADMISSION_HOLD.json").exists():
            # Retain a healthy triplet's exact CPU for concrete repair, while
            # new scientific starts remain held. The finite Slurm deadline wins.
            reviewed_contract(root)
            time.sleep(5)
        log_path = root / "logs" / (triplet["fit_ids"][mode] + ".log")
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("ab") as log:
            subprocess.run([sys.executable, "-B", str(Path(__file__).resolve()), "--root", str(root),
                "--triplet-id", triplet["id"], "--mode", mode], stdout=log, stderr=subprocess.STDOUT,
                check=False)
        if not receipt.exists():
            hold_dispatch(root, triplet["fit_ids"][mode], "fit_exit_without_receipt")
            raise RuntimeError("Fit exited without a receipt; preserve allocation log and diagnose")
        if read(receipt)["status"] != "complete":
            hold_dispatch(root, triplet["fit_ids"][mode], "failed_or_censored_fit")
            return


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--triplet-id", required=True)
    parser.add_argument("--mode", choices=MODES)
    parser.add_argument("--parallel-owner")
    args = parser.parse_args()
    # This fresh-process gate also enforces the amendment for supervisors that
    # loaded the original ten-seed module before the human reduced its scope.
    if args.mode:
        triplet = next(t for t in read(args.root / "MANIFEST.json")["triplets"] if t["id"] == args.triplet_id)
        if not mode_admission(args.root, triplet, args.mode):
            print(json.dumps({"fit_id": triplet["fit_ids"][args.mode], "status": "scope_excluded",
                              "numerical_fit_started": False}))
            sys.exit(0)
        if (args.root / "PLACEMENT_AMENDMENT_20261024_PARALLEL.json").exists() and not args.parallel_owner:
            receipt = args.root / "results/receipts" / (triplet["fit_ids"][args.mode] + ".json")
            if receipt.exists():
                result = read(receipt)
                print(json.dumps({"fit_id": result["fit_id"], "status": result["status"], "existing_receipt_reused": True}))
                sys.exit(0 if result["status"] == "complete" else 1)
            write(args.root / "ops/parallel_placement_20261024/legacy_deferred" / (triplet["fit_ids"][args.mode] + ".json"),
                  {"fit_id": triplet["fit_ids"][args.mode], "status": "deferred_before_numerical_start", "reason": "Per-fit parallel ownership supersedes legacy sequential dispatch", "unix": time.time()}, immutable=True)
            sys.exit(75)
    contract = reviewed_contract(args.root)
    triplet = next(t for t in contract["triplets"] if t["id"] == args.triplet_id)
    if args.mode:
        result = run_fit(args.root, contract, triplet, args.mode, args.parallel_owner)
        print(json.dumps({"fit_id": result["fit_id"], "status": result["status"]}))
        sys.exit(0 if result["status"] == "complete" else 1)
    run_triplet(args.root, contract, triplet)
