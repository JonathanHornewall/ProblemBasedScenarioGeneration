"""Separate full-dimension diagnostics; no test access or scientific eligibility."""
import argparse
import copy
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

from build_central_path_final import read, write
from central_path_slurm import environment


def lava_predictor_check(root,job):
    from physical128_data import load_job
    from run_public_solver_free_matched import _make_model
    from linear_scale_architecture import verify_predictor
    import torch
    torch.set_num_threads(1)
    data=load_job(job)
    assert data.provenance['test_bank_opened'] is False
    t=data.dataset.train
    model=_make_model(job['config'],t.contexts,t.physical_costs)
    proof=verify_predictor(job,model)
    x=torch.tensor(t.contexts[:2],dtype=torch.float32)
    out=model(x);out.square().mean().backward()
    assert torch.isfinite(out).all() and all(torch.isfinite(p.grad).all() for p in model.parameters())
    proof.update(test_bank_opened=False,scope='full-shape physical predictor only; LAVA preparation uses unchanged production caps',scientifically_eligible=False)
    write(root/'preflight/lava_predictors'/(job['id']+'.json'),proof)


def main(root):
    assert read(root/'NEW_BANK_VERIFICATION.json')['status']=='complete'
    screen=read(root/'screen.json'); selected={}
    for j in screen['jobs']:
        selected.setdefault((j['cell'],j['method']),j)
    jobs=[]
    for j in selected.values():
        d=copy.deepcopy(j);d['id']='diagnostic__'+j['cell']+'__'+j['method']
        d['config']['name']=d['id'];d['diagnostic_only']=True
        d['config']['evaluate_test']=False
        d['config']['training'].update(epochs=1,validation_epochs=[1],patience=2,maximum_optimization_seconds=300)
        d['resource_limits']={'preprocessing_cap_seconds':600,'job_wall_cap_seconds':900}
        jobs.append(d)
    path=root/'preflight/diagnostic.json';write(path,{**screen,'jobs':jobs})
    output=root/'preflight/results';(output/'logs').mkdir(parents=True,exist_ok=True)
    env=environment(root);env['CENTRAL_PATH_GEOMETRY_CACHE']=str(root/'preflight/geometry_cache')
    def run(index):
        j=jobs[index];label=j['id'];lava=j['method']=='lava'
        if lava:
            cmd=[str(root/'venv/bin/python'),str(root/'code/scripts/preflight_linear_scale_campaign.py'),
                 '--root',str(root),'--lava-index',str(index)]
        else:
            cmd=[str(root/'venv/bin/python'),str(root/'code/scripts/run_central_path_final.py'),
                '--manifest',str(path),'--job-index',str(index),'--output-root',str(output)]
        with (output/'logs'/(label+'.log')).open('w') as log:
            child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            try:code=child.wait(timeout=930)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
        recpath=(root/'preflight/lava_predictors'/(label+'.json') if lava else output/'receipts'/(label+'.json'))
        rec=read(recpath) if recpath.exists() else {}
        success=(code==0 and rec.get('status')==('verified' if lava else 'complete') and rec.get('test_bank_opened') is False)
        if not lava and success:
            arch=read(Path(rec['attempt_directory'])/'predictor_architecture.json')
            success=arch['status']=='verified'
        result={'id':label,'method':j['method'],'route':j['route'],'architecture_arm':j['architecture_arm'],
            'passed':success,'returncode':code,'status':rec.get('status'),
            'error':rec.get('error'),'scope':'predictor_only' if lava else 'full_shape_one_epoch'}
        print(json.dumps(result),flush=True);return result
    with ThreadPoolExecutor(max_workers=8) as pool:results=list(pool.map(run,range(len(jobs))))
    failures=[r for r in results if not r['passed']]
    proof={'status':'failed' if failures else 'complete','diagnostics':len(results),'results':results,
        'failures':failures,'scientifically_eligible':False,'completed_unix':time.time()}
    write(root/'preflight/VERIFICATION.json',proof)
    return bool(failures)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--lava-index',type=int)
    a=p.parse_args()
    if a.lava_index is not None:lava_predictor_check(a.root,read(a.root/'preflight/diagnostic.json')['jobs'][a.lava_index])
    else:raise SystemExit(main(a.root.resolve()))
