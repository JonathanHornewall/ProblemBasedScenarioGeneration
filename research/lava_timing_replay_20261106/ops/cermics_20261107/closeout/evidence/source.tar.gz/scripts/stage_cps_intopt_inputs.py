"""Transfer only immutable input banks in <=32 MiB checksum-verified batches."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import shlex
import subprocess
import tarfile
import time

from build_central_path_final import write

p=argparse.ArgumentParser();p.add_argument('--package',type=Path,required=True);p.add_argument('--root',type=Path,required=True);p.add_argument('--remote',required=True)
a=p.parse_args();inventory=json.loads((a.root/'FROZEN_BANK_INVENTORY.json').read_text())
entries=[]
for e in inventory:
    for name,digest in {**e['files_sha256'],'receipt.json':e['receipt_sha256']}.items():
        path=a.package/'frozen_data'/e['key']/name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
        entries.append((path,'frozen_data/'+e['key']+'/'+name,digest))
remote=shlex.quote(a.remote)
subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','shared_cluster','umask 077; mkdir -p '+remote],check=True)
batches=[];current=[];size=0
for e in entries:
    n=e[0].stat().st_size
    if current and (size+n>32*2**20 or len(current)>=120):batches.append(current);current=[];size=0
    current.append(e);size+=n
if current:batches.append(current)
completed=[]
for index,batch in enumerate(batches):
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w') as tar:
        for path,name,digest in batch:tar.add(path,arcname=name,recursive=False)
    subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','shared_cluster',f'tar -xf - -C {remote}'],input=buffer.getvalue(),check=True,timeout=300)
    checks=''.join(f'{d}  {n}\n' for _,n,d in batch)
    result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','shared_cluster',f'cd {remote} && sha256sum --quiet -c -'],input=checks,text=True,capture_output=True,timeout=180)
    if result.returncode:raise RuntimeError(result.stdout+result.stderr)
    completed.append({'batch':index,'files':len(batch),'bytes':sum(x[0].stat().st_size for x in batch),'verified':True})
    write(a.root/'INPUT_TRANSFER_STATUS.json',{'status':'running','completed':completed,'expected_batches':len(batches),'updated_unix':time.time()})
    print(json.dumps(completed[-1]),flush=True)
write(a.root/'INPUT_TRANSFER_VERIFICATION.json',{'status':'complete','files':len(entries),'bytes':sum(x[0].stat().st_size for x in entries),'batches':completed,'verified_unix':time.time()})
