"""Descriptive pilot outcomes and paired differences; never chooses a final protocol."""
from __future__ import annotations
import argparse
import csv
import itertools
import statistics
from pathlib import Path
from pilot_common import *

T95={1:12.706205,2:4.302653,3:3.182446,4:2.776445,5:2.570582,6:2.446912,7:2.364624,8:2.306004,9:2.262157}

def stats(values):
    if not values:return {'n':0,'mean':None,'sample_sd':None,'ci95':None}
    n=len(values);mean=statistics.mean(values);sd=statistics.stdev(values) if n>1 else None
    half=None if sd is None else T95[n-1]*sd/n**.5
    return {'n':n,'mean':mean,'sample_sd':sd,'ci95':None if half is None else [mean-half,mean+half]}

def score(record,n=None):
    if not successful(record):return None
    if not record.get('test_access') or not record.get('test_bank_opened'):raise ValueError('Final receipt missing test proof')
    s=record['summary'] if n is None else record['summary']['validation_variants'][str(n)]
    if not s.get('test'):return None
    value=s['test']['normalized_mean_regret']
    return None if value is None else 100*float(value)

def csv_file(path,rows):
    if not rows:return
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def method_summary(root,method):
    root=Path(root);plan=read(root/'PLAN.json');rows=[];contrasts=[]
    for group in plan['step1_groups']:
        if group['method']!=method:continue
        views={}
        for arm,ids in group['arms'].items():
            records=[read(root/'results/receipts'/(i+'.json')) for i in ids]
            values=[score(d) for d in records];views[arm]=values
            rows.append({'route':group['route'],'arm':arm,**stats([v for v in values if v is not None]),
                'prescribed':10,'conditional_on_success':any(v is None for v in values),'job_ids':ids})
        for arm in ARMS[1:]:
            paired=[a-b for a,b in zip(views[arm],views['control']) if a is not None and b is not None]
            contrasts.append({'route':group['route'],'arm_minus_control':arm,**stats(paired),
                'positive_means_worse':True,'conditional_on_paired_success':len(paired)<10})
    write(root/'reports'/('STEP1_'+method+'.json'),{'method':method,'outcomes':rows,'paired_differences':contrasts},immutable=True)

def summarize(root):
    root=Path(root);plan=read(root/'PLAN.json');report=root/'reports';report.mkdir(exist_ok=True)
    record=lambda jid:read(root/'results/receipts'/(jid+'.json'))
    step1=[];differences=[];md=['# Two-step linear pilot','',
        'Mean normalized test regret (%) and sample SD over full seed bundles. All selection uses observed validation.',
        'Pilot evidence informs a later protocol decision. No full campaign is launched by this report.','',
        '## Step 1','', '| Method | Instance | Arm | Mean | SD | Complete / 10 |', '|---|---|---|---:|---:|---:|']
    for g in plan['step1_groups']:
        values={}
        for arm,ids in g['arms'].items():
            outcomes=[record(i) for i in ids];v=[score(d) for d in outcomes];values[arm]=v
            s=stats([x for x in v if x is not None]);row={'method':g['method'],'route':g['route'],'arm':arm,**s,
                'prescribed':10,'terminal_statuses':dict(__import__('collections').Counter(d['status'] for d in outcomes)),
                'conditional_on_success':s['n']<10,'job_ids':ids}
            step1.append(row)
            fmt=lambda x:'—' if x is None else f'{x:.4f}'
            md.append(f"| {g['method']} | {g['route']} | {arm} | {fmt(s['mean'])} | {fmt(s['sample_sd'])} | {s['n']} / 10 |")
        for arm in ARMS[1:]:
            paired=[a-b for a,b in zip(values[arm],values['control']) if a is not None and b is not None]
            differences.append({'method':g['method'],'route':g['route'],'arm_minus_control':arm,**stats(paired),
                'positive_means_worse':True,'conditional_on_paired_success':len(paired)<10})
    choices=read(root/'STEP2_SELECTIONS.json')['choices'];assignments=read(root/'STEP2_ASSIGNMENTS.json');step2=[];series={}
    md+=['','## Step 2','', '| Instance | Scope | Validation n | Refinement | Mean | SD | Complete / 10 |', '|---|---|---:|---|---:|---:|---:|']
    for c in choices:
        key=(c['route'],c['scope'],c['validation_size'],c['refinement']);ids=assignments.get(c['route']+'|'+str(c['candidate']),[])
        values=[score(record(i),c['validation_size']) for i in ids];series[key]=values
        s=stats([v for v in values if v is not None]);step2.append({k:c[k] for k in ('route','scope','validation_size','refinement','candidate','selection_route')} | s |
            {'prescribed':10,'conditional_on_success':s['n']<10,'job_ids':ids})
        fmt=lambda x:'—' if x is None else f'{x:.4f}'
        md.append(f"| {c['route']} | {c['scope']} | {c['validation_size']} | {c['refinement']} | {fmt(s['mean'])} | {fmt(s['sample_sd'])} | {s['n']} / 10 |")
    contrasts=[]
    for route in plan['cells']:
        for scope,n,ref in itertools.product(('per_instance','smallest_family'),(32,100),(False,True)):
            key=(route,scope,n,ref)
            for factor,other in [('scope',(route,'smallest_family',n,ref)),('validation_size',(route,scope,100,ref)),('refinement',(route,scope,n,True))]:
                if other==key:continue
                left,right=series[other],series[key]
                paired=[a-b for a,b in zip(left,right) if a is not None and b is not None]
                contrasts.append({'route':route,'factor':factor,'from':str(key[1:]),'to':str(other[1:]),
                    **stats(paired),'positive_means_worse':True,'conditional_on_paired_success':len(paired)<10})
    write(report/'STEP1.json',step1);write(report/'STEP1_PAIRED_DIFFERENCES.json',differences)
    write(report/'STEP2.json',step2);write(report/'STEP2_PAIRED_DIFFERENCES.json',contrasts)
    (report/'PILOT_REPORT.md').write_text('\n'.join(md)+'\n')
    csv_file(report/'STEP1.csv',[{k:v for k,v in z.items() if k not in ('job_ids','terminal_statuses','ci95')} for z in step1])
    csv_file(report/'STEP2.csv',[{k:v for k,v in z.items() if k not in ('job_ids','ci95')} for z in step2])
    receipts=list((root/'results/receipts').glob('*.json'))
    write(report/'VERIFICATION.json',{'status':'complete','step1_groups':len(plan['step1_groups']),'step2_groups':len(choices),
        'step1_rows':len(step1),'step2_rows':len(step2),'terminal_receipts':len(receipts),
        'failure_denominators_explicit':True,'test_driven_selection':False,'full_campaign_started':False,
        'report_hashes':{p.name:sha(p) for p in report.iterdir() if p.is_file() and p.name!='VERIFICATION.json'}})

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args();summarize(a.root)
