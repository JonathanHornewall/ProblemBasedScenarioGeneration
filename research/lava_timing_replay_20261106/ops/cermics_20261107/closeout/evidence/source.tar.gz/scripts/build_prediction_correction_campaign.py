"""Build paired prediction-correction and uncorrected-baseline campaigns."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import source_sha256, write_json
from proximal_spo.config import RunSpec

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPO_ROOT / "configs" / "prediction_correction"
SOFT_SELECTION = (
    REPO_ROOT / "results" / "soft_radial_log_barrier" / "hard_boundary.json"
)
BASELINE_SELECTION = REPO_ROOT / "results" / "broad_cost" / "core_selection.json"
DEVELOPMENT_SEEDS = (1, 2, 3)
BASELINES = ("mse", "wise", "spo_plus")


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _seed_payload(seed: int) -> dict[str, int]:
    return {
        "data": seed,
        "structural": 101,
        "initialization": 200 + seed,
        "shuffle": 300 + seed,
        "perturbation": 400 + seed,
    }


def _tag(benchmark_id: str) -> str:
    return {
        "cost.assignment10": "assignment",
        "cost.facility30x5_relaxation": "facility",
        "cost.grid5": "grid",
        "cost.knapsack50x5": "knapsack",
        "cost.random_lp100x50": "randomlp",
        "cost.topk20x5": "topk",
    }[benchmark_id]


def _selected_soft_arms() -> dict[str, dict[str, Any]]:
    payload = json.loads(SOFT_SELECTION.read_text(encoding="utf-8"))
    selected: dict[str, dict[str, Any]] = {}
    for row in payload["selected_arms"]:
        if row.get("selection_deployment") != "hard_recovered":
            continue
        benchmark = str(row["benchmark_id"])
        selected[benchmark] = copy.deepcopy(row["arm"])
    if len(selected) != 6:
        raise ValueError("expected six hard-recovered Soft-Radial winners")
    return selected


def _selected_baseline_arms() -> dict[tuple[str, str], dict[str, Any]]:
    payload = json.loads(BASELINE_SELECTION.read_text(encoding="utf-8"))
    selected: dict[tuple[str, str], dict[str, Any]] = {}
    for row in payload["selected_arms"]:
        method = str(row.get("method"))
        if method not in BASELINES:
            continue
        benchmark = str(row["benchmark_id"])
        selected[(benchmark, method)] = copy.deepcopy(row["arm"])
    if len(selected) != 18:
        raise ValueError("expected three baselines on each of six benchmarks")
    return selected


def _development_rows() -> list[dict[str, Any]]:
    soft = _selected_soft_arms()
    baselines = _selected_baseline_arms()
    rows: list[dict[str, Any]] = []
    for benchmark in sorted(soft):
        for seed in DEVELOPMENT_SEEDS:
            correction = copy.deepcopy(soft[benchmark])
            correction["name"] = f"{_tag(benchmark)}_s{seed}_corrected_softbar"
            correction["seeds"] = _seed_payload(seed)
            correction["method_parameters"].update(
                {
                    "prediction_correction": True,
                    "prediction_correction_cone": True,
                    "prediction_correction_minimum_scale": 1e-6,
                    "prediction_correction_ridges": [1e-8, 1e-5, 1e-3, 1e-1],
                    "prediction_correction_replay_audit_size": 8,
                }
            )
            rows.append(correction)
            for method in BASELINES:
                baseline = copy.deepcopy(baselines[(benchmark, method)])
                baseline["name"] = f"{_tag(benchmark)}_s{seed}_{method}"
                baseline["seeds"] = _seed_payload(seed)
                rows.append(baseline)
    if len(rows) != 72:
        raise AssertionError("unexpected prediction-correction campaign size")
    return rows


def _smoke_rows() -> list[dict[str, Any]]:
    rows = _development_rows()
    smoke: list[dict[str, Any]] = []
    for row in rows:
        if row["seeds"]["data"] != DEVELOPMENT_SEEDS[0]:
            continue
        row = copy.deepcopy(row)
        row["name"] += "_smoke"
        row["workers"] = 1
        row["sizes"] = {"train": 64, "validation": 32, "test": 32}
        row["model"].update({"width": 16, "depth": 1})
        row["training"].update(
            {
                "epochs": 2,
                "batch_size": 32,
                "validation_interval": 1,
                "patience": 2,
                "torch_threads": 1,
            }
        )
        smoke.append(row)
    if len(smoke) != 24:
        raise AssertionError("unexpected prediction-correction smoke size")
    return smoke


def _write(stage: str, rows: list[dict[str, Any]]) -> Path:
    for row in rows:
        RunSpec.from_dict(row)
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    path = CONFIG_ROOT / f"{stage}.json"
    payload = {
        "name": f"prediction_correction_{stage}",
        "run_root": f"runs/prediction_correction/{stage}",
        "base": {},
        "variants": rows,
        "source_sha256_at_generation": source_sha256(REPO_ROOT),
        "selection_inputs": {
            "soft_radial_hard_winners": str(SOFT_SELECTION.relative_to(REPO_ROOT)),
            "soft_radial_selection_sha256": _sha256(SOFT_SELECTION),
            "baseline_winners": str(BASELINE_SELECTION.relative_to(REPO_ROOT)),
            "baseline_selection_sha256": _sha256(BASELINE_SELECTION),
        },
        "protocol": {
            "correction_supervision": "context-scenario pairs only",
            "correction_selection": "validation realized-scenario physical-cost MSE",
            "conditional_means": "evaluation only",
            "test_metrics_used_for_selection": False,
            "baselines": "uncorrected validation-selected MSE, WISE, and SPO+",
        },
    }
    write_json(path, payload)
    return path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("smoke", "development"))
    arguments = parser.parse_args()
    rows = _smoke_rows() if arguments.stage == "smoke" else _development_rows()
    print(_write(arguments.stage, rows))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
