"""Evaluation of archived fitted models; no optimizer, selection or training."""
import hashlib
import time
from pathlib import Path


def evaluate_frozen(job, loaded, directory, update, evaluation_started):
    import numpy as np
    import torch
    from proximal_spo.artifacts import model_sha256
    from proximal_spo.config import RunSpec
    from proximal_spo.evaluation import evaluate_outputs, predict_in_batches
    from proximal_spo.objectives import prepare_split
    from proximal_spo.oracles import make_lp_oracle
    from proximal_spo.problem import PartialCostInterface
    from proximal_spo.runner import _coefficient_transform, _objective, _standard_model
    from run_public_solver_free_matched import _hash_array

    original = job["original_job"]
    if original["method"] in ("pfyl", "nce", "lava"):
        raise ValueError("Withdrawn affine baseline models cannot be reused")
    spec = RunSpec.from_dict(original["config"])
    dataset, problem = loaded.dataset, loaded.problem
    for field in ("contexts", "physical_costs"):
        if _hash_array(getattr(dataset.train, field)) != job["original_training_hashes"][field]:
            raise ValueError("Frozen model training bank differs: " + field)
    physical = original.get("baseline_protocol") == "physical_cold_highs_v1"
    central = original["method"].startswith("central_path_")
    direct = original["method"] in ("rayen_policy", "soft_radial_policy", "direct_projection")
    interface, transform = _coefficient_transform(spec, dataset, dataset.interface(spec.interface, problem))
    if physical:
        interface = PartialCostInterface.full_cost(problem)
    relaxed = PartialCostInterface(problem.continuous_relaxation(), interface.fixed_cost,
                                    interface.statistic, name=interface.name + ".training")

    def prepare(split, geometry):
        costs, means = dataset.coefficients(split, spec.interface)
        if physical:
            from proximal_spo.canonical_baselines import ColdHighsBatch
            costs, means = split.physical_costs, split.conditional_mean_costs
            context = ColdHighsBatch(geometry)
        else:
            costs, means = transform.apply(costs), transform.apply(means)
            context = make_lp_oracle(geometry, workers=1, random_seed=spec.seeds.structural)
        with context as oracle:
            return prepare_split(contexts=split.contexts, coefficients=costs,
                conditional_mean_coefficients=means, physical_costs=split.physical_costs,
                conditional_mean_costs=split.conditional_mean_costs, split=split.split, oracle=oracle)

    # Only observed costs populate both training slots in the safe loader.
    assert np.array_equal(dataset.train.physical_costs, dataset.train.conditional_mean_costs)
    train = prepare(dataset.train, relaxed.problem if central or original["method"] == "spo_plus" else problem)
    objective_interface = relaxed if central or original["method"] == "spo_plus" else interface
    if physical:
        from proximal_spo.canonical_baselines import PhysicalMSEObjective, PhysicalWISEObjective, PhysicalSPOPlusObjective
        objective = {"mse": PhysicalMSEObjective, "wise": PhysicalWISEObjective,
                     "spo_plus": PhysicalSPOPlusObjective}[original["method"]](problem)
    else:
        objective = _objective(spec, objective_interface, train, deployment_problem=problem)
    try:
        if central:
            objective.set_deployment_mode("hard_recovered")
            objective.set_checkpoint_selection_deployment("hard_recovered")
            train = objective.prepare_training_split(train)
        elif direct and hasattr(objective, "prepare_training_split"):
            train = objective.prepare_training_split(train)
        torch.manual_seed(spec.seeds.initialization)
        model = _standard_model(spec, train, objective, train.coefficients.mean(axis=0), np.zeros(1))
        path = Path(job["original_checkpoint"])
        checkpoint_sha = hashlib.sha256(path.read_bytes()).hexdigest()
        state = torch.load(path, map_location="cpu", weights_only=False)
        model.load_state_dict(state["model"], strict=True)
        parameter_sha = model_sha256(model)
        if parameter_sha != job["original_parameter_sha256"]:
            raise ValueError("Original fitted model parameter hash mismatch")
        evaluation_started()
        update("test_evaluation")
        started = time.perf_counter()
        test = prepare(dataset.test, problem)
        outputs = predict_in_batches(model, test.contexts, batch_size=spec.training.evaluation_batch_size)
        captured = {}
        metrics = evaluate_outputs(objective, outputs, test,
            batch_size=spec.training.evaluation_batch_size, capture=captured)
        wall = time.perf_counter() - started
        np.savez_compressed(directory / "test_predictions.npz", **captured)
        if model_sha256(model) != parameter_sha:
            raise ValueError("Evaluation mutated a frozen model")
        return {"test": metrics.to_dict(), "test_evaluation_wall_seconds": wall,
            "parameter_sha256": parameter_sha, "original_checkpoint_sha256": checkpoint_sha,
            "original_checkpoint": str(path), "optimization_wall_seconds": 0.0,
            "optimization_cpu_seconds": 0.0, "epochs_completed": 0,
            "evaluation_only": True, "model_parameters_unchanged": True,
            "original_receipt_sha256": job["original_receipt_sha256"],
            "information_budget": "observed training only for decoder reconstruction"}, []
    finally:
        objective.close()
