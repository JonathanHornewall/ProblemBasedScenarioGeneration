"""CFL-only per-route tuning, retaining the maintained scientific fit identity."""
from __future__ import annotations

import collections
import copy
import os
from pathlib import Path
import time

from pilot_common import CPS, digest, read, sha, write
import simplified_campaign as linear
import scaled_data_neural_campaign as scaled

REVISION = 'cfl_n1000_per_size_retune_20261023_v1'
CAMPAIGN = 'cfl_n1000_per_size_retune_20261023'
METHODS = ['mse', CPS, 'wise', 'spo_plus', 'pfyl', 'nce']
ROUTES = ['dys_cfl_50x5', 'dys_cfl_100x10', 'dys_cfl_200x10',
          'dys_cfl_250x10', 'dys_cfl_500x10']
PHASES = ['linear_retune_n1000', 'nonlinear_retune_n1000']


def phase_for(plan, phase, method):
    p = {'id': phase, 'train': 1000, 'validation': 320, 'epochs': 300,
         'depth': 0, 'tune': True}
    if phase == PHASES[1]:
        choice = plan['frozen_depths'][method]
        p.update(depth=choice['selected_depth'],
                 frozen_depth_choice={'path': choice['path'], 'sha256': choice['sha256']},
                 runtime_source_commit=plan['legacy_nonlinear_identity_commit'])
    return p


def make_job(plan, phase, method, route, choices, seeds=None, stage='screen', template=None):
    return scaled.make_job(plan['templates'][linear.base_method(method)] if template is None else template, method, route,
        plan['cells'][route]['screen'] if seeds is None else seeds,
        choices, phase_for(plan, phase, method), stage=stage)


def selection_path(root, phase, method, route):
    return Path(root) / 'selections' / phase / (method + '__' + route + '.json')


def environment(root):
    env = scaled.environment(root)
    env['CFL_PER_SIZE_ROOT'] = str(root)
    return env


def memory_gib(job):
    # N1000 saved final maxima: CP500=3.222GiB, NCE500=2.822GiB;
    # all other route/method maxima <=1.212GiB. Rounded 1.7x peak+0.5GiB.
    return 6 if job['route'] == ROUTES[-1] and job['method'] in (CPS, 'nce') else 3


def validate_execution(job):
    """The job stays byte-identical to eligible old work; authorization is separate."""
    import socket
    root = Path(os.environ['CFL_PER_SIZE_ROOT'])
    plan = read(root / 'PLAN.json')
    phase, method, route, stage = (job[k] for k in ('campaign_phase', 'method', 'route', 'stage'))
    if plan['revision'] != REVISION or method not in METHODS or route not in ROUTES or phase not in PHASES:
        raise ValueError('Unregistered CFL per-size route/method/phase')
    if not os.environ.get('SLURM_JOB_ID') or socket.gethostname().startswith('master'):
        raise RuntimeError('CFL numerical execution requires Slurm')
    if len(os.sched_getaffinity(0)) != 1:
        raise RuntimeError('Each CFL fit requires one bound CPU')
    if stage == 'screen':
        seeds = plan['cells'][route]['screen']
        template = None
        if job['choices'] not in linear.grid(method):
            raise ValueError('Candidate outside the frozen full grid')
    elif stage == 'confirmation':
        seeds = job['config']['seeds']
        if seeds not in plan['cells'][route]['confirmation']:
            raise ValueError('Unregistered paired seed bundle')
        s = read(selection_path(root, phase, method, route))
        template = s['selected_template']
        if s['test_scores_read'] is not False or s['selected_template']['choices'] != job['choices']:
            raise ValueError('Final fit differs from frozen per-size selection')
    else:
        raise ValueError('Only screens and confirmations are authorized')
    expected = make_job(plan, phase, method, route, job['choices'], seeds, stage, template)
    if digest(expected) != digest(job):
        raise ValueError('CFL complete job contract differs')
    if phase == PHASES[1]:
        c = plan['frozen_depths'][method]
        if sha(root / c['path']) != c['sha256']:
            raise ValueError('Frozen N100 nonlinear depth source changed')
    return {'site': 'cermics', 'host': socket.gethostname(),
        'affinity': sorted(os.sched_getaffinity(0)), 'scientific_training_domain': 'continuous_relaxation',
        'training_mechanism': ('barrier_policy_gradient' if method == CPS else
            'supervised_regression_no_optimization_oracle' if method in ('mse', 'wise') else 'public_loss_with_LP_oracle'),
        'campaign_revision': REVISION, 'per_size_selection': True,
        'actual_source_commit': read(root / 'source_receipt.json')['scientific_source_commit'],
        'legacy_job_identity_commit_is_not_runtime_revision': True}


class Campaign:
    """Persistent metadata cache; no numerical work or test-based selection."""
    def __init__(self, root):
        self.root = Path(root)
        self.plan = read(self.root / 'PLAN.json')
        self.old = Path(self.plan['reuse_root'])
        self.jobs = {}
        self.records = {}
        self.reuse = {}
        self.groups = {}
        self.finals = {}
        self.selections = {}
        for method in METHODS:
            for phase in PHASES:
                for route in ROUTES:
                    key = (phase, method, route)
                    self.groups[key] = [self.require(make_job(self.plan, phase, method, route, c))
                                        for c in linear.grid(method)]

    def require(self, job):
        jid = job['id']
        if jid in self.jobs:
            return jid
        write(self.root / 'jobs' / (jid + '.json'), scaled.manifest(job), immutable=True)
        self.jobs[jid] = job
        target = self.root / 'results/receipts' / (jid + '.json')
        prior = self.old / 'results/receipts' / (jid + '.json')
        reuse_path = self.root / 'ops/reuse' / (jid + '.json')
        if reuse_path.exists():
            self.reuse[jid] = read(reuse_path)
        if target.exists():
            self.accept(jid, read(target))
        elif prior.exists():
            value = read(prior)
            if digest(value['job']) != digest(job):
                raise ValueError('Existing ID has a different full manifest: ' + jid)
            if value['status'] == 'complete':
                if not scaled.successful(value, job):
                    raise ValueError('Incomplete old completion cannot be reused: ' + jid)
                if job['stage'] == 'screen':
                    scaled.development_score(value, job)
                else:
                    attempt = Path(value['attempt_directory'])
                    access = read(attempt / 'TEST_ACCESS.json')
                    freeze = read(attempt / 'VALIDATION_SELECTION_FREEZE.json')
                    bank = read(self.root / 'frozen_data' / job['required_data_key'] / 'receipt.json')
                    if (access['test_scores_used_for_selection'] is not False
                            or access['test_bank_sha256'] != bank['files_sha256']['test.npz']
                            or access['validation_freeze_sha256'] != sha(attempt / 'VALIDATION_SELECTION_FREEZE.json')
                            or freeze['validation_size'] != 320 or freeze['selection_uses_test'] is not False
                            or sha(attempt / 'model.pt') != freeze['checkpoint_sha256']
                            or value['summary']['test']['sample_count'] != 100):
                        raise ValueError('Old final checkpoint/sealed-test contract differs: ' + jid)
            record = {'id': jid, 'source_receipt': str(prior), 'source_receipt_sha256': sha(prior),
                'full_job_digest': digest(job), 'status': value['status'],
                'kind': 'exact_completed_reuse' if value['status'] == 'complete' else 'prior_terminal_no_retry',
                'independent_new_fit': False}
            write(reuse_path, record, immutable=True)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.symlink_to(prior)
            self.reuse[jid] = record
            self.accept(jid, value)
        elif (self.old / 'results/attempts' / jid).exists():
            record = {'job': job, 'status': 'censored', 'error': 'prior_interrupted_attempt_no_retry',
                'test_access': None, 'prior_attempt_root': str(self.old / 'results/attempts' / jid)}
            write(target, record, immutable=True)
            self.accept(jid, record)
        return jid

    def accept(self, jid, value):
        if digest(value['job']) != digest(self.jobs[jid]) or value['status'] not in ('complete', 'failed', 'censored'):
            raise ValueError('Terminal receipt identity/status differs: ' + jid)
        self.records[jid] = value

    def data_ready(self, job):
        base = self.root / 'frozen_data'
        key = job['required_data_key']
        training = base / 'retuning_development' / key if job['stage'] == 'screen' else base / key
        t, v = training / 'receipt.json', base / 'retuning_validation' / key / 'receipt.json'
        return (t.exists() and v.exists() and 1000 in read(t).get('available_train_sizes', [])
                and 320 in read(v).get('available_validation_sizes', []))

    def advance(self):
        for p in (self.root / 'results/receipts').glob('*.json'):
            if p.stem in self.jobs and p.stem not in self.records:
                self.accept(p.stem, read(p))
        for key, ids in self.groups.items():
            if key in self.selections or not all(jid in self.records for jid in ids):
                continue
            phase, method, route = key
            ranked = [(scaled.development_score(self.records[jid], self.jobs[jid]), i, jid)
                      for i, jid in enumerate(ids)]
            eligible = sorted((r for r in ranked if r[0] is not None), key=lambda r: (r[0], r[1]))
            selected = {'revision': REVISION, 'phase': phase, 'method': method, 'family': 'cfl',
                'selection_route': route, 'screen_fits': len(ids), 'score': eligible[0][0] if eligible else None,
                'selected_template': self.jobs[eligible[0][2]] if eligible else None,
                'screen_ids': ids, 'test_scores_read': False,
                'unavailable': [{'id': jid, 'status': self.records[jid]['status'],
                                 'error': self.records[jid].get('error')} for jid in ids
                                if not scaled.successful(self.records[jid], self.jobs[jid])],
                'tie_rule': 'observed validation320 score then declared Cartesian candidate order',
                'final_checkpoint_rule': 'each refit selects on its own observed validation320'}
            write(selection_path(self.root, *key), selected, immutable=True)
            self.selections[key] = selected
            self.finals[key] = []
            if selected['selected_template'] is not None:
                for seed in self.plan['cells'][route]['confirmation']:
                    j = make_job(self.plan, phase, method, route,
                                 selected['selected_template']['choices'], seed, 'confirmation', selected['selected_template'])
                    self.finals[key].append(self.require(j))
        ready = []
        waiting = set()
        for jid, job in self.jobs.items():
            if jid in self.records:
                continue
            if not self.data_ready(job):
                waiting.add(job['required_data_key'])
                continue
            rank = (METHODS.index(job['method']) * 10**8 + (job['stage'] != 'confirmation') * 10**7
                    + PHASES.index(job['campaign_phase']) * 10**6 + ROUTES.index(job['route']) * 10**5)
            ready.append({'id': jid, 'phase': job['campaign_phase'], 'method': job['method'],
                'stage': job['stage'], 'manifest': 'jobs/' + jid + '.json',
                'memory_gib': memory_gib(job), 'required_data_key': job['required_data_key'],
                'dispatch_priority': rank})
        ready.sort(key=lambda r: (r['dispatch_priority'], r['id']))
        write(self.root / 'READY.json', {'science': ready, 'timing': [],
            'dispatch_method_order': METHODS, 'dispatch_phase_order': PHASES, 'updated_unix': time.time()})
        done = len(self.selections) == len(self.groups) and not ready and not waiting
        counts = collections.Counter(v['status'] for v in self.records.values())
        status = {'revision': REVISION, 'registered_jobs': len(self.jobs), 'terminal_counts': dict(counts),
            'registered_screens': sum(j['stage'] == 'screen' for j in self.jobs.values()),
            'registered_finals': sum(j['stage'] == 'confirmation' for j in self.jobs.values()),
            'frozen_selections': len(self.selections), 'expected_selections': len(self.groups),
            'pending_science': len(ready), 'waiting_data_banks': sorted(waiting), 'science_terminal': done,
            'reused_completed': sum(r['kind'] == 'exact_completed_reuse' for r in self.reuse.values()),
            'reuse_counts': dict(collections.Counter((self.jobs[j]['stage'], r['kind']) for j, r in self.reuse.items())),
            'new_terminal_counts': dict(collections.Counter(v['status'] for j, v in self.records.items() if j not in self.reuse)),
            'new_successful_fits': sum(v['status'] == 'complete' and j not in self.reuse for j,v in self.records.items()),
            'final_groups': {p + '/' + m + '/' + r: {'ids': ids,
                'terminal': sum(j in self.records for j in ids)} for (p,m,r),ids in self.finals.items()},
            'updated_unix': time.time()}
        status['reuse_counts'] = {str(k):v for k,v in status['reuse_counts'].items()}
        write(self.root / 'STATUS.json', status)
        return status, ready
