"""Build validation-only kNN coverage for continuous confirmation gaps."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json
from proximal_spo.config import RunSpec
from proximal_spo.experiment_identity import experimental_route_id


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected a JSON object at {path}")
    return payload


def build_continuous_knn_supplement(
    confirmation_manifest: dict[str, Any],
    *,
    run_root: str,
) -> dict[str, Any]:
    """Emit a full k/weight grid only where frozen kNN coverage is absent."""

    variants = confirmation_manifest.get("variants")
    if not isinstance(variants, list) or not variants:
        raise ValueError("confirmation manifest has no variants")
    bases: dict[str, dict[str, Any]] = {}
    knn_routes: set[str] = set()
    all_routes: set[str] = set()
    for candidate in variants:
        if not isinstance(candidate, dict):
            raise ValueError("confirmation variant must be an object")
        route = experimental_route_id(candidate)
        all_routes.add(route)
        if candidate.get("method") == "knn":
            knn_routes.add(route)
        if candidate.get("method") == "mse" and route not in bases:
            bases[route] = copy.deepcopy(candidate)
    missing_routes = sorted(all_routes - knn_routes)
    if not missing_routes:
        raise ValueError("continuous confirmation already has complete kNN coverage")
    if set(bases) != all_routes:
        raise ValueError("every route must have an MSE template")

    emitted: list[dict[str, Any]] = []
    for route in missing_routes:
        base = bases[route]
        train_size = int(base["sizes"]["train"])
        route_slug = route.replace(".", "p").replace("-", "_")
        route_digest = hashlib.sha256(route.encode()).hexdigest()[:8]
        for distance_weighted in (False, True):
            for neighbors in (5, 10, 25, 50, 100, 200):
                if neighbors > train_size:
                    continue
                config = copy.deepcopy(base)
                config["name"] = (
                    f"pubdev_knn_supplement_{route_slug}_{route_digest}_"
                    f"k{neighbors}_w{int(distance_weighted)}"
                )
                config["method"] = "knn"
                config["method_parameters"] = {
                    "neighbors": neighbors,
                    "distance_weighted": distance_weighted,
                }
                config["evaluate_test"] = False
                config["sizes"]["test"] = 1
                config["seeds"] = {
                    "data": 42_101,
                    "structural": int(base["seeds"]["structural"]),
                    "initialization": 42_201,
                    "shuffle": 42_301,
                    "perturbation": 42_401,
                }
                config["training"].update(
                    {
                        "epochs": 1,
                        "patience": 2,
                        "selection_mode": "validation_regret",
                        "validation_interval": 1,
                        "validation_epochs": [1],
                    }
                )
                RunSpec.from_dict(config)
                emitted.append(config)
    return {
        "name": "publication_continuous_knn_supplement_development",
        "run_root": run_root,
        "design": {
            "stage": "validation_only_missing_baseline_coverage",
            "test_blind": True,
            "source_manifest": confirmation_manifest.get("name"),
            "missing_route_count": len(missing_routes),
            "missing_route_ids": missing_routes,
            "neighbors": [5, 10, 25, 50, 100, 200],
            "distance_weighted": [False, True],
            "incremental_receipts": True,
        },
        "base": {},
        "variants": emitted,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--confirmation-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--campaign-run-root", required=True)
    arguments = parser.parse_args()
    campaign = build_continuous_knn_supplement(
        _object(arguments.confirmation_manifest),
        run_root=arguments.campaign_run_root,
    )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.output, campaign)
    print(f"wrote {len(campaign['variants'])} kNN supplement runs")


if __name__ == "__main__":
    main()
