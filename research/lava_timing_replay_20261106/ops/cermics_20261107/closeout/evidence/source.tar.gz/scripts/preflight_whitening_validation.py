"""Geometry once per instance, then full-shape diagnostic fits through production limits."""
from __future__ import annotations
import argparse, copy, json, os, subprocess, time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from build_whitening_validation_campaign import clean_job,digest,read,write,sha,CPS


def compile_instance(entry):
 root,name=entry;root=Path(root)
 import numpy as np
 from scipy.sparse import csc_matrix
 from proximal_spo.problem import LinearProblem
 from proximal_spo.feasible_policies import compile_policy_geometry,_GEOMETRY_CACHE
 bank=root/'frozen_data'/name
 with np.load(bank/'structure.npz') as a:
  p=LinearProblem(csc_matrix((a['matrix_data'],a['matrix_indices'],a['matrix_indptr']),shape=tuple(a['matrix_shape'])),
      a['row_lower'],a['row_upper'],a['variable_lower'],a['variable_upper'],a['integrality']).continuous_relaxation()
 os.environ['CP_SPO_GEOMETRY_CACHE']=str(root/'policy_geometry_cache')
 os.environ.pop('CP_SPO_GEOMETRY_CACHE_READONLY',None)
 rows=[]
 for white in (True,False):
  _GEOMETRY_CACHE.clear();g=compile_policy_geometry(p,hessian_whitening=white)
  row={'whitening':white,'receipt':g.receipt_dict(),'maximum_normalized_row_norm':float(np.linalg.norm(g.normalized_inequalities,axis=1).max()),
       'center_sha256':__import__('hashlib').sha256(g.center.tobytes()).hexdigest()}
  assert np.all(g.center_slacks>0)
  rows.append(row);del g
 assert rows[0]['center_sha256']==rows[1]['center_sha256']
 write(root/'geometry_preflight'/(name.split('__data')[0]+'.json'),{'bank':name,'charts':rows,'status':'passed'})
 return name


class Diagnostics:
 def __init__(self,root,jobs):
  self.root=root;self.jobs=jobs;self.plan={'protocol':{'job_wall_cap_seconds':9000,'preprocessing_cap_seconds':3600}}
  self.groups=jobs;self.completed={};self.known={};self.new_jobs={};self.records={}
 def record(self,j):
  p=self.root/'results/receipts'/(j['id']+'.json')
  if p.exists():
   d=read(p);self.records[j['id']]=d;return d
 def advance(self):
  self.known={}
  for j in self.jobs:
   if self.record(j) is not None:self.completed[j['id']]=True;continue
   if j['id'] not in self.new_jobs:
    write(self.root/'jobs'/(j['id']+'.json'),{'protocol':self.plan['protocol'],'jobs':[j]});self.new_jobs[j['id']]=j
   self.known[j['id']]=j
  return len(self.completed)==len(self.groups)


def main(root):
 from whitening_validation_driver import environment,execute
 root=root.resolve();env=environment(root);os.environ.update(env)
 # Fresh hashes before any numerical work; no generator or held-out file is evaluated.
 for rel,meta in read(root/'INPUT_INVENTORY.json').items():
  assert (root/rel).stat().st_size==meta['bytes'] and sha(root/rel)==meta['sha256'],rel
 source=read(root/'source_receipt.json')
 for rel,expected in source['source_sha256'].items():assert sha(root/'code'/rel)==expected,rel
 plan=read(root/'PLAN.json');names={}
 for p in sorted((root/'frozen_data').iterdir()):names.setdefault(p.name.split('__data')[0],p.name)
 assert len(names)==20
 with ProcessPoolExecutor(max_workers=4) as pool:
  completed=list(pool.map(compile_instance,[(str(root),n) for n in names.values()]))
 centers=list((root/'policy_geometry_cache/centers').glob('*/manifest.json'))
 charts=list((root/'policy_geometry_cache/charts').glob('*/manifest.json'))
 assert len(centers)==20 and len(charts)==40
 write(root/'GEOMETRY_CACHE_VERIFICATION.json',{'status':'passed','instances':20,'center_entries':len(centers),'chart_entries':len(charts),
  'each_center_has_one_atomic_producer':True,'manifest_sha256':{str(p.relative_to(root)):sha(p) for p in centers+charts},'verified_unix':time.time()})
 # All no-whitening architecture/instance pairs, large white guard settings, and largest baselines.
 jobs={};large={'dys_shortest_path_50x50','dys_cfl_500x10','dys_knapsack_1000x2','lava_random_lp_800x50_released_code'}
 for g in plan['groups']:
  if g['kind']=='fixed' and g['rho']==.9 and (not g['whitening'] or g['route'] in large):
   j=copy.deepcopy(g['jobs'][0])
  elif g['kind']=='validation' and g['variant']=='final_epoch' and g['method'] in ('mse','wise','spo_plus') and g['route'] in large:
   j=clean_job(plan['grids'][g['grid_key']][0],g['architecture'])
  else:continue
  j.update(stage='screen',diagnostic_only=True,repeat=0,dispatch_priority=0,dispatch_phase=1);j.pop('frozen_horizon',None)
  j['config']['seeds']=copy.deepcopy(plan['grids'][g['grid_key']][0]['config']['seeds'])
  j['config']['evaluate_test']=False
  j['config']['training'].update(epochs=1,validation_epochs=[1],schedule_reference_epochs=300,selection_mode='last')
  j['id']='diagnostic__'+digest(j)[:24];j['config']['name']=j['id'];jobs[j['id']]=j
 preflight=root/'preflight';preflight.mkdir(exist_ok=True)
 for name in ('code','venv','frozen_data','source_receipt.json','policy_geometry_cache','observed_preparation_cache'):
  if name=='observed_preparation_cache':(root/name).mkdir(exist_ok=True)
  if not (preflight/name).exists():(preflight/name).symlink_to(root/name)
 write(preflight/'manifest.json',{'jobs':list(jobs.values()),'scientific_eligibility':False,'full_shape':True})
 c=Diagnostics(preflight,list(jobs.values()));assert execute(preflight,c,workers=8,memory_gib=128,maximum_seconds=14400)
 failures=[]
 for j in jobs.values():
  d=c.record(j)
  if (d['status']!='complete' or not d.get('smoke_only') or d.get('test_access') or d.get('test_bank_opened') or
      d.get('summary',{}).get('epochs_completed')!=1):failures.append({'id':j['id'],'status':d['status'],'error':d.get('error')})
  if d['status']=='complete' and j['method']==CPS:
   r=d['summary']['objective_receipt'];assert r['geometry']['geometry_cache']['center_computations_this_call']==0
   assert r['guard_radius_policy']=='geometry_certified' and r['guard_safety_factor']==.9
 write(preflight/'VERIFICATION.json',{'status':'passed' if not failures else 'failed','diagnostics':len(jobs),'failures':failures,
     'production_admission_and_watchdog_used':True,'test_access':False,'scientific_eligibility':False,'verified_unix':time.time()})
 if failures:raise RuntimeError('Preflight failed; no production authorized by gate')


if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args();main(a.root)
