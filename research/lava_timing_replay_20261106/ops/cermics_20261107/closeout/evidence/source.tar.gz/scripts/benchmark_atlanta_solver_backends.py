#!/usr/bin/env python3
"""Matched local solver-throughput diagnostic; never a full training receipt."""

from __future__ import annotations

import argparse
import gc
import json
import platform
import time
from pathlib import Path

import gurobipy as gp
import highspy
import numpy as np
import run_public_solver_free_matched as matched
import torch
from dfl_extensions_lab.benchmarks import SplitSizes
from run_atlanta_baseline_timing import digest, write

from proximal_spo.external_benchmarks import load_external_benchmark


def new_model(problem, backend):
    model = matched._fixed_model(problem, integer=False, backend=backend)
    if backend == "gurobi":
        model._model.Params.FeasibilityTol = 1e-8
        model._model.Params.OptimalityTol = 1e-8
    return model


def timed_solves(problem, backend, costs):
    start = time.perf_counter()
    model = new_model(problem, backend)
    setup = time.perf_counter() - start
    records = []
    for cost in costs:
        wall = time.perf_counter()
        cpu = time.process_time()
        model.setObj(cost)
        solution, objective = model.solve()
        records.append(
            {
                "wall_seconds": time.perf_counter() - wall,
                "cpu_seconds": time.process_time() - cpu,
                "objective": objective,
                "iterations": (
                    model._model.getInfo().simplex_iteration_count
                    if backend == "highs"
                    else model._model.IterCount
                ),
            }
        )
    del model
    gc.collect()
    return {"model_setup_seconds": setup, "solves": records}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=32)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--binding-samples", type=int, default=8)
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    manifest = json.loads(args.manifest.read_text())
    entries = {}
    for job in manifest["jobs"]:
        entries.setdefault(job["entry"]["route_id"], job["entry"])
    report = {
        "kind": "local_matched_solver_throughput_diagnostic",
        "not_full_training": True,
        "not_remote_runtime_calibration": True,
        "host": platform.node(),
        "platform": platform.platform(),
        "highs_version": highspy.Highs().version(),
        "gurobi_version": list(gp.gurobi.version()),
        "manifest_sha256": digest(args.manifest),
        "script_sha256": digest(Path(__file__)),
        "highs_adapter_sha256": digest(
            matched.PROJECT_ROOT / "src/proximal_spo/public_highs.py"
        ),
        "threads_per_solver": 1,
        "primal_and_dual_feasibility_tolerance": 1e-8,
        "includes_objective_update_and_solution_extraction": True,
        "first_solve_cold_subsequent_solves_reuse_same_model": True,
        "samples_per_cost_family": args.samples,
        "repeats": args.repeats,
        "binding_samples": args.binding_samples,
        "cases": [],
    }
    for index, (route, entry) in enumerate(entries.items()):
        case = {"route": route, "status": "running", "solve_families": {}}
        report["cases"].append(case)
        write(args.output, report)
        try:
            matched._seed(int(entry["seeds"]["initialization"]))
            loaded = load_external_benchmark(
                entry["benchmark_id"],
                SplitSizes(**entry["sizes"]),
                data_seed=entry["seeds"]["data"],
                conditional_reference_samples=entry["conditional_reference_samples"],
            )
            problem = loaded.problem.continuous_relaxation()
            all_costs = loaded.dataset.train.physical_costs
            all_features = loaded.dataset.train.contexts
            network = matched._make_model(entry, all_features, all_costs)
            costs = np.asarray(all_costs[: args.samples], dtype=np.float64)
            features = all_features[: args.samples]
            with torch.no_grad():
                predictions = matched._physical_prediction(network, features).numpy()
            sigma = 0.1 if "random_lp" in route else 1.0
            rng = np.random.RandomState(entry["seeds"]["perturbation"])
            families = {
                "true_cost": costs,
                "initial_prediction": predictions.astype(np.float64),
                "spo_surrogate": 2 * predictions - costs,
                "pfyl_perturbation": predictions + sigma * rng.normal(size=costs.shape),
            }
            case.update(
                variables=problem.variable_count,
                constraints=problem.constraint_count,
                original_integer_variables=int(np.sum(loaded.problem.integrality)),
                training_size=len(all_costs),
                actual_cost_samples=len(costs),
                cost_hashes={k: matched._hash_array(v) for k, v in families.items()},
                feature_sha256=matched._hash_array(features),
            )
            unavailable = set()
            for family, vectors in families.items():
                measures = {"highs": [], "gurobi": []}
                for repeat in range(args.repeats):
                    order = (
                        ("highs", "gurobi")
                        if (index + repeat) % 2 == 0
                        else ("gurobi", "highs")
                    )
                    for backend in order:
                        if backend in unavailable:
                            continue
                        try:
                            measures[backend].append(
                                timed_solves(problem, backend, vectors)
                            )
                        except gp.GurobiError as error:
                            if error.errno != 10010:
                                raise
                            unavailable.add(backend)
                            case["gurobi_unavailable"] = {
                                "error_code": error.errno,
                                "error": str(error),
                            }
                if measures["highs"] and measures["gurobi"]:
                    for high, grb in zip(
                        measures["highs"], measures["gurobi"], strict=True
                    ):
                        h_obj = np.array([r["objective"] for r in high["solves"]])
                        g_obj = np.array([r["objective"] for r in grb["solves"]])
                        np.testing.assert_allclose(h_obj, g_obj, atol=1e-6, rtol=1e-7)
                    measures["optimal_objective_parity"] = True
                case["solve_families"][family] = measures
                write(args.output, report)
            case["binding_geometry"] = {}
            for backend in ("highs", "gurobi"):
                if backend in unavailable:
                    continue
                model = new_model(problem, backend)
                start, cpu = time.perf_counter(), time.process_time()
                dataset = matched.BindingOnlyDataset(
                    model,
                    features[: args.binding_samples],
                    costs[: args.binding_samples],
                )
                case["binding_geometry"][backend] = {
                    "wall_seconds": time.perf_counter() - start,
                    "cpu_seconds": time.process_time() - cpu,
                    "samples": len(dataset),
                    "binding_rows": [len(c) for c in dataset.ctrs],
                    "includes_model_copy_and_optimal_labels": True,
                    "includes_cave_training": False,
                }
                del dataset, model
                gc.collect()
            case["status"] = "passed"
        except Exception as error:
            case.update(
                status="failed", error_type=type(error).__name__, error=str(error)
            )
        write(args.output, report)
        print(
            json.dumps(
                {
                    k: v
                    for k, v in case.items()
                    if k not in ("solve_families", "binding_geometry")
                }
            ),
            flush=True,
        )
    if any(case["status"] != "passed" for case in report["cases"]):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
