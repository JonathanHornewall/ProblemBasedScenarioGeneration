#!/usr/bin/env python3
"""Summarize the frozen evidence used by the four-page MLxOR paper."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import defaultdict
from math import sqrt
from pathlib import Path
from statistics import mean, stdev
from typing import Any

TARGET = "soft_radial_log_barrier"
LP_BENCHMARKS = {
    "dys_shortest_path_25x25": "DYS shortest path",
    "lava_random_lp_150x50_paper_appendix": "LAVA random LP",
    "predictiveco_cubic_topk": "PredictiveCO top-k",
}
DYS_INTEGER_BENCHMARKS = {
    "dys_cfl_50x5": "CFL 50x5",
    "dys_cfl_100x10": "CFL 100x10",
    "dys_cfl_200x10": "CFL 200x10",
    "dys_cfl_250x10": "CFL 250x10",
    "dys_knapsack_50x2": "Knapsack 50x2",
    "dys_knapsack_100x2": "Knapsack 100x2",
    "dys_knapsack_200x2": "Knapsack 200x2",
    "dys_knapsack_400x2": "Knapsack 400x2",
    "dys_knapsack_500x2": "Knapsack 500x2",
}
ADDITIONAL_INTEGER_BENCHMARKS = {
    "sfge_kp50_values_seed_0": "SFGE knapsack",
    "pyepo_mdkp32x2_degree_6_noise_0_5_seed_0": (
        "PyEPO MDKP (degree 6, noise 0.5)"
    ),
}
DECISION_BENCHMARKS = {
    **LP_BENCHMARKS,
    **DYS_INTEGER_BENCHMARKS,
    **ADDITIONAL_INTEGER_BENCHMARKS,
}
PREDICTION_BENCHMARKS = DECISION_BENCHMARKS
# The workshop's complete D/T/P table and aggregate speed claim use these
# three routes.  The broader replay is retained for subsequent reporting.
COMPLETE_METRIC_BENCHMARKS = LP_BENCHMARKS
METHOD_ALIASES = {
    TARGET: "bcr",
    "mse": "mse",
    "spo_plus": "spo_plus",
    "spo_plus_relaxation": "spo_plus",
}
TEX_PREFIX = {
    "dys_shortest_path_25x25": "Dys",
    "lava_random_lp_150x50_paper_appendix": "Lava",
    "predictiveco_cubic_topk": "Topk",
    "dys_cfl_50x5": "DysCflFifty",
    "dys_cfl_100x10": "DysCflHundred",
    "dys_cfl_200x10": "DysCflTwoHundred",
    "dys_cfl_250x10": "DysCflTwoFifty",
    "dys_knapsack_50x2": "DysKpFifty",
    "dys_knapsack_100x2": "DysKpHundred",
    "dys_knapsack_200x2": "DysKpTwoHundred",
    "dys_knapsack_400x2": "DysKpFourHundred",
    "dys_knapsack_500x2": "DysKpFiveHundred",
    "sfge_kp50_values_seed_0": "SfgeKp",
    "pyepo_mdkp32x2_degree_6_noise_0_5_seed_0": "PyepoMdkp",
}
TEX_METHOD = {"bcr": "BCR", "mse": "MSE", "spo_plus": "SPO"}


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _completed_run_directories(root: Path) -> list[Path]:
    directories: list[Path] = []
    for status_path in root.glob("*/status.json"):
        status = json.loads(status_path.read_text())
        if status.get("status") == "complete":
            directories.append(status_path.parent)
    return directories


def _prediction_record(directory: Path) -> dict[str, Any] | None:
    config_path = directory / "config.json"
    config = json.loads(config_path.read_text())
    benchmark = str(config["benchmark_id"])
    method = str(config["method"])
    if benchmark not in PREDICTION_BENCHMARKS or method not in METHOD_ALIASES:
        return None
    summary = json.loads((directory / "summary.json").read_text())
    diagnostics = json.loads((directory / "prediction_diagnostics.json").read_text())
    physical_prediction = diagnostics.get("physical_cost_prediction")
    # Legacy SPO+ receipts predate physical-cost reporting.  They are retained
    # as provenance, while the frozen diagnostic replay supplies the missing
    # cost reports.  Skipping them here prevents double-counting the same seed.
    if physical_prediction is None:
        return None
    raw_mse = float(physical_prediction["conditional_mse_per_coordinate"])
    corrected_mse: float | None = None
    uncorrected_sidecar_mse: float | None = None
    sidecar_fit_wall_seconds: float | None = None
    correction_training_wall_seconds: float | None = None
    ray_reporting_wall_seconds: float | None = None
    decision_match_rate: float | None = None
    decision_audit_sample_size: int | None = None
    if method == TARGET:
        correction = json.loads((directory / "prediction_correction.json").read_text())
        corrected = correction["methods"]["paired_mse_exact_ray_gauge"]
        uncorrected_sidecar = correction["methods"]["paired_mse_raw"]
        corrected_mse = float(
            corrected["prediction"]["conditional_mse_per_coordinate"]
        )
        uncorrected_sidecar_mse = float(
            uncorrected_sidecar["prediction"]["conditional_mse_per_coordinate"]
        )
        decision_match_rate = float(
            corrected["decision_invariance_audit"]["base_decision_match_rate"]
        )
        decision_audit_sample_size = int(
            corrected["decision_invariance_audit"]["sample_size"]
        )
        sidecar_fit_wall_seconds = float(
            correction["fit_receipt"]["paired_mse_network"][
                "training_wall_seconds"
            ]
        )
        correction_training_wall_seconds = float(
            correction["timing"]["incremental_pair_only_training_wall_seconds"]
        )
        ray_reporting_wall_seconds = float(
            corrected["selected_candidate_fit_and_prediction_wall_seconds"]
        )
    seed_match = re.search(r"_seed(\d+)_", directory.name)
    if seed_match is None:
        raise ValueError(f"cannot recover paired-seed index from {directory.name}")
    return {
        "benchmark_id": benchmark,
        "method": METHOD_ALIASES[method],
        "source_method": method,
        "seed": int(seed_match.group(1)),
        "normalized_regret": float(summary["test"]["normalized_mean_regret"]),
        "training_wall_seconds": float(summary["training_wall_seconds"]),
        "raw_conditional_mse_per_coordinate": raw_mse,
        "reported_conditional_mse_per_coordinate": (
            corrected_mse if corrected_mse is not None else raw_mse
        ),
        "uncorrected_sidecar_mse_per_coordinate": uncorrected_sidecar_mse,
        "sidecar_fit_wall_seconds": sidecar_fit_wall_seconds,
        "correction_training_wall_seconds": correction_training_wall_seconds,
        "ray_reporting_wall_seconds": ray_reporting_wall_seconds,
        "decision_match_rate": decision_match_rate,
        "decision_audit_sample_size": decision_audit_sample_size,
        "config_sha256": _sha256(config_path),
        "run_directory": str(directory.resolve()),
    }


def _method_summary(records: list[dict[str, Any]]) -> dict[str, Any]:
    summary = {
        "seed_count": len(records),
        "mean_normalized_regret": mean(item["normalized_regret"] for item in records),
        "mean_raw_conditional_mse_per_coordinate": mean(
            item["raw_conditional_mse_per_coordinate"] for item in records
        ),
        "mean_reported_conditional_mse_per_coordinate": mean(
            item["reported_conditional_mse_per_coordinate"] for item in records
        ),
        "mean_decision_match_rate": (
            mean(item["decision_match_rate"] for item in records)
            if all(item["decision_match_rate"] is not None for item in records)
            else None
        ),
        "run_directories": [item["run_directory"] for item in records],
        "per_seed_diagnostics": [
            {
                "seed": item["seed"],
                "diagnostic_replay_normalized_regret": item["normalized_regret"],
                "raw_conditional_mse_per_coordinate": item[
                    "raw_conditional_mse_per_coordinate"
                ],
                "reported_conditional_mse_per_coordinate": item[
                    "reported_conditional_mse_per_coordinate"
                ],
                "uncorrected_sidecar_mse_per_coordinate": item[
                    "uncorrected_sidecar_mse_per_coordinate"
                ],
                "training_wall_seconds": item["training_wall_seconds"],
                "sidecar_fit_wall_seconds": item["sidecar_fit_wall_seconds"],
                "correction_training_wall_seconds": item[
                    "correction_training_wall_seconds"
                ],
                "ray_reporting_wall_seconds": item["ray_reporting_wall_seconds"],
                "config_sha256": item["config_sha256"],
            }
            for item in sorted(records, key=lambda value: int(value["seed"]))
        ],
    }
    if all(
        item["uncorrected_sidecar_mse_per_coordinate"] is not None
        for item in records
    ):
        summary["mean_uncorrected_sidecar_mse_per_coordinate"] = mean(
            float(item["uncorrected_sidecar_mse_per_coordinate"])
            for item in records
        )
        summary["mean_sidecar_fit_wall_seconds"] = mean(
            float(item["sidecar_fit_wall_seconds"]) for item in records
        )
        summary["mean_ray_reporting_wall_seconds"] = mean(
            float(item["ray_reporting_wall_seconds"]) for item in records
        )
        summary["decision_audit_sample_count"] = sum(
            int(item["decision_audit_sample_size"]) for item in records
        )
    return summary


def _frozen_decision_results(
    paths: tuple[Path, ...],
) -> tuple[
    dict[tuple[str, str], float],
    dict[tuple[str, str], dict[int, float]],
    dict[tuple[str, str], list[dict[str, Any]]],
]:
    values: dict[tuple[str, str], float] = {}
    seeded: dict[tuple[str, str], dict[int, float]] = {}
    provenance: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for path in paths:
        payload = json.loads(path.read_text())
        for benchmark in payload["benchmarks"]:
            benchmark_id = str(benchmark["benchmark_id"])
            if benchmark_id not in DECISION_BENCHMARKS:
                continue
            for item in benchmark["methods"]:
                source_method = str(item["method"])
                if source_method not in METHOD_ALIASES:
                    continue
                key = (benchmark_id, METHOD_ALIASES[source_method])
                values[key] = float(item["normalized_regret"]["mean"])
                method_seeds: dict[int, float] = {}
                method_provenance: list[dict[str, Any]] = []
                for run_directory in item["run_directories"]:
                    directory = Path(run_directory)
                    seed_match = re.search(r"_seed(\d+)_", directory.name)
                    if seed_match is None:
                        raise ValueError(f"cannot recover paired seed from {directory}")
                    seed = int(seed_match.group(1))
                    summary = json.loads((directory / "summary.json").read_text())
                    normalized_regret = float(
                        summary["test"]["normalized_mean_regret"]
                    )
                    method_seeds[seed] = normalized_regret
                    method_provenance.append(
                        {
                            "seed": seed,
                            "normalized_regret": normalized_regret,
                            "config_sha256": _sha256(directory / "config.json"),
                            "run_directory": str(directory.resolve()),
                        }
                    )
                seeded[key] = method_seeds
                provenance[key] = sorted(
                    method_provenance, key=lambda value: int(value["seed"])
                )
    return values, seeded, provenance


def _paired_check(left: dict[int, float], right: dict[int, float]) -> dict[str, Any]:
    seeds = sorted(set(left) & set(right))
    if len(seeds) != 10:
        raise ValueError(f"expected ten paired seeds, found {seeds}")
    differences = [left[seed] - right[seed] for seed in seeds]
    center = mean(differences)
    half_width = 2.2621571627409915 * stdev(differences) / sqrt(len(differences))
    return {
        "count": len(differences),
        "target_wins": sum(value < 0 for value in differences),
        "mean_target_minus_baseline": center,
        "ci95_lower": center - half_width,
        "ci95_upper": center + half_width,
    }


def _first_seed_method_times(
    summary_path: Path,
    method_by_benchmark: dict[str, str],
) -> tuple[dict[str, float], dict[str, str]]:
    payload = json.loads(summary_path.read_text())
    values: dict[str, float] = {}
    sources: dict[str, str] = {}
    for benchmark in payload["benchmarks"]:
        benchmark_id = benchmark["benchmark_id"]
        if benchmark_id not in method_by_benchmark:
            continue
        method = next(
            item
            for item in benchmark["methods"]
            if item["method"] == method_by_benchmark[benchmark_id]
        )
        run = Path(method["run_directories"][0])
        values[benchmark_id] = float(
            json.loads((run / "summary.json").read_text())["training_wall_seconds"]
        )
        sources[benchmark_id] = str(run.resolve())
    return values, sources


def _mixed_integer_summary(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text())
    comparisons = {
        "mse": {"wins": 0, "ties": 0, "losses": 0},
        "spo_plus_relaxation": {"wins": 0, "ties": 0, "losses": 0},
    }
    retained: list[str] = []
    families: set[str] = set()
    for benchmark in payload["benchmarks"]:
        benchmark_id = str(benchmark["benchmark_id"])
        if benchmark_id == "predictiveco_cubic_topk":
            continue
        retained.append(benchmark_id)
        families.add(str(benchmark["family_id"]))
        method_values = {
            str(item["method"]): float(item["normalized_regret"]["mean"])
            for item in benchmark["methods"]
        }
        target = method_values[TARGET]
        for baseline, counts in comparisons.items():
            difference = target - method_values[baseline]
            if abs(difference) <= 1e-12:
                counts["ties"] += 1
            elif difference < 0:
                counts["wins"] += 1
            else:
                counts["losses"] += 1
    return {
        "route_count": len(retained),
        "family_count": len(families),
        "route_ids": retained,
        "comparisons": comparisons,
        "excluded_zero_integrality_gap_route": "predictiveco_cubic_topk",
        "source": str(path.resolve()),
    }


def _pyepo_time(root: Path, benchmark_id: str) -> tuple[float, str]:
    matches = list(root.glob(f"pyepo_canonical_{benchmark_id}_seed1_*/summary.json"))
    if len(matches) != 1:
        raise ValueError(f"expected one PyEPO run for {benchmark_id}: {matches}")
    return float(json.loads(matches[0].read_text())["training_wall_seconds"]), str(
        matches[0].parent.resolve()
    )


def _topk_pyepo_time(root: Path) -> tuple[float, str]:
    matches = list(
        root.glob("mlxor_pyepo_canonical_predictiveco_topk_seed1_*/summary.json")
    )
    if len(matches) != 1:
        raise ValueError(f"expected one PyEPO top-k run: {matches}")
    return float(json.loads(matches[0].read_text())["training_wall_seconds"]), str(
        matches[0].parent.resolve()
    )


def _retained_pyepo_times(root: Path) -> tuple[dict[str, float], dict[str, str]]:
    values: dict[str, float] = {}
    sources: dict[str, str] = {}
    for benchmark_id in PREDICTION_BENCHMARKS:
        matches = list(
            root.glob(
                f"mlxor_pyepo_retained_{benchmark_id}_seed1_*/summary.json"
            )
        )
        if len(matches) != 1:
            raise ValueError(
                f"expected one retained PyEPO run for {benchmark_id}: {matches}"
            )
        values[benchmark_id] = float(
            json.loads(matches[0].read_text())["training_wall_seconds"]
        )
        sources[benchmark_id] = str(matches[0].parent.resolve())
    return values, sources


def _seed_record(records: list[dict[str, Any]], seed: int) -> dict[str, Any]:
    matches = [item for item in records if int(item["seed"]) == seed]
    if len(matches) != 1:
        raise ValueError(f"expected one seed-{seed} record, found {len(matches)}")
    return matches[0]


def _format(value: float, digits: int = 3) -> str:
    return f"{value:.{digits}g}"


def _tex_metric(value: float, *, best: bool) -> str:
    rendered = _format(value, 3)
    return f"\\textbf{{{rendered}}}" if best else rendered


def _tex(payload: dict[str, Any]) -> str:
    lines = ["% Generated by scripts/summarize_mlxor_evidence.py."]
    for benchmark_id, benchmark in payload["benchmarks"].items():
        prefix = TEX_PREFIX[benchmark_id]
        minimum_regret = min(
            item["mean_normalized_regret"]
            for item in benchmark["methods"].values()
        )
        minimum_time = min(
            item["final_configuration_training_wall_seconds"]
            for item in benchmark["methods"].values()
        )
        minimum_prediction = min(
            item["prediction_mse_ratio_to_mse"]
            for item in benchmark["methods"].values()
        )
        for method, item in benchmark["methods"].items():
            method_tex = TEX_METHOD[method]
            lines.append(
                f"\\newcommand{{\\{prefix}{method_tex}}}"
                f"{{{_format(item['mean_normalized_regret'], 3)}}}"
            )
            regret = float(item["mean_normalized_regret"])
            training = float(item["final_configuration_training_wall_seconds"])
            prediction = float(item["prediction_mse_ratio_to_mse"])
            cell = "/".join(
                (
                    _tex_metric(regret, best=regret <= minimum_regret + 1e-12),
                    _tex_metric(training, best=training <= minimum_time + 1e-12),
                    _tex_metric(
                        prediction,
                        best=prediction <= minimum_prediction + 1e-12,
                    ),
                )
            )
            lines.append(
                f"\\newcommand{{\\{prefix}{method_tex}Cell}}{{{cell}}}"
            )
    timing = payload["training_timing"]
    lines.extend(
        [
            f"\\newcommand{{\\BCRTrainSeconds}}{{{timing['bcr_seconds']:.2f}}}",
            f"\\newcommand{{\\PyEPOTrainSeconds}}{{{timing['pyepo_seconds']:.2f}}}",
            f"\\newcommand{{\\TrainingSpeedup}}{{{timing['speedup']:.1f}}}",
            f"\\newcommand{{\\BCRCorrectionSeconds}}{{{timing['bcr_correction_seconds']:.2f}}}",
            f"\\newcommand{{\\BCRCombinedSeconds}}{{{timing['bcr_combined_seconds']:.2f}}}",
            f"\\newcommand{{\\CombinedTrainingSpeedup}}{{{timing['combined_speedup']:.1f}}}",
        ]
    )
    for benchmark_id in PREDICTION_BENCHMARKS:
        prefix = TEX_PREFIX[benchmark_id]
        lines.extend(
            [
                f"\\newcommand{{\\{prefix}BCRSeconds}}{{{timing['bcr_by_benchmark'][benchmark_id]:.2f}}}",
                f"\\newcommand{{\\{prefix}PyEPOSeconds}}{{{timing['pyepo_by_benchmark'][benchmark_id]:.2f}}}",
            ]
        )
    return "\n".join(lines) + "\n"


def _markdown(payload: dict[str, Any]) -> str:
    lines = ["# MLxOR decision evidence"]
    for panel_name, panel in payload["decision_panels"].items():
        lines.extend(["", f"## {panel_name.replace('_', ' ').title()}", ""])
        for benchmark in panel.values():
            methods = benchmark["methods"]
            cells = []
            for method in ("bcr", "mse", "spo_plus"):
                item = methods[method]
                cells.append(
                    f"{method}: D={item['mean_normalized_regret']:.8g}, "
                    f"T={item['final_configuration_training_wall_seconds']:.8g}s, "
                    f"P={item['prediction_mse_ratio_to_mse']:.8g}"
                )
            lines.append(f"- {benchmark['label']}: " + "; ".join(cells) + ".")
    timing = payload["training_timing"]
    lines.extend(
        [
            "",
            f"BCR training: {timing['bcr_seconds']:.6g} s.",
            f"MSE training: {timing['mse_seconds']:.6g} s.",
            f"PyEPO SPO+ training: {timing['pyepo_seconds']:.6g} s.",
            f"Speedup: {timing['speedup']:.5g}x.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--prediction-root", action="append", type=Path, required=True)
    parser.add_argument("--continuous-summary", type=Path, required=True)
    parser.add_argument("--integer-summary", type=Path, required=True)
    parser.add_argument("--pyepo-root", type=Path, required=True)
    parser.add_argument("--native-timing-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    arguments = parser.parse_args()

    records: list[dict[str, Any]] = []
    for root in arguments.prediction_root:
        for directory in _completed_run_directories(root):
            record = _prediction_record(directory)
            if record is not None:
                records.append(record)
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        grouped[(record["benchmark_id"], record["method"])].append(record)
    prediction_expected = {
        (benchmark, method)
        for benchmark in PREDICTION_BENCHMARKS
        for method in TEX_METHOD
    }
    if set(grouped) != prediction_expected:
        missing = sorted(prediction_expected - set(grouped))
        extra = sorted(set(grouped) - prediction_expected)
        raise ValueError(
            f"prediction coverage mismatch; missing={missing}, extra={extra}"
        )

    native_timing_grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(
        list
    )
    for directory in _completed_run_directories(arguments.native_timing_root):
        record = _prediction_record(directory)
        if record is not None:
            native_timing_grouped[(record["benchmark_id"], record["method"])].append(
                record
            )
    native_timing_expected = {
        (benchmark, method)
        for benchmark in PREDICTION_BENCHMARKS
        for method in ("bcr", "mse")
    }
    if set(native_timing_grouped) != native_timing_expected:
        missing = sorted(native_timing_expected - set(native_timing_grouped))
        extra = sorted(set(native_timing_grouped) - native_timing_expected)
        raise ValueError(
            f"native timing coverage mismatch; missing={missing}, extra={extra}"
        )

    frozen_regrets, frozen_seeded_regrets, frozen_provenance = _frozen_decision_results(
        (arguments.continuous_summary, arguments.integer_summary)
    )
    decision_expected = {
        (benchmark, method)
        for benchmark in DECISION_BENCHMARKS
        for method in TEX_METHOD
    }
    if set(frozen_regrets) != decision_expected:
        missing = sorted(decision_expected - set(frozen_regrets))
        extra = sorted(set(frozen_regrets) - decision_expected)
        raise ValueError(
            f"frozen regret coverage mismatch; missing={missing}, extra={extra}"
        )

    benchmarks: dict[str, Any] = {}
    correction_folds: list[float] = []
    for benchmark_id in PREDICTION_BENCHMARKS:
        methods = {
            method: _method_summary(grouped[(benchmark_id, method)])
            for method in TEX_METHOD
        }
        if any(item["seed_count"] != 10 for item in methods.values()):
            raise ValueError(f"expected ten paired seeds on {benchmark_id}")
        for method, item in methods.items():
            item["diagnostic_replay_mean_normalized_regret"] = item[
                "mean_normalized_regret"
            ]
            item["mean_normalized_regret"] = frozen_regrets[(benchmark_id, method)]
            item["frozen_decision_regret_by_seed"] = frozen_provenance[
                (benchmark_id, method)
            ]
        mse = methods["mse"]["mean_reported_conditional_mse_per_coordinate"]
        for item in methods.values():
            item["prediction_mse_ratio_to_mse"] = (
                item["mean_reported_conditional_mse_per_coordinate"] / mse
            )
        bcr = methods["bcr"]
        bcr["sidecar_mse_ratio_to_mse"] = (
            bcr["mean_uncorrected_sidecar_mse_per_coordinate"] / mse
        )
        bcr["ray_projection_mse_reduction_percent"] = 100.0 * (
            bcr["mean_uncorrected_sidecar_mse_per_coordinate"]
            - bcr["mean_reported_conditional_mse_per_coordinate"]
        ) / bcr["mean_uncorrected_sidecar_mse_per_coordinate"]
        correction_folds.append(
            bcr["mean_raw_conditional_mse_per_coordinate"]
            / bcr["mean_reported_conditional_mse_per_coordinate"]
        )
        if bcr["mean_decision_match_rate"] != 1.0:
            raise ValueError(f"decision correction failed replay on {benchmark_id}")
        benchmarks[benchmark_id] = {
            "label": PREDICTION_BENCHMARKS[benchmark_id],
            "methods": methods,
        }

    panel_specs = {
        "dys_benchmark_family": {
            "dys_shortest_path_25x25": PREDICTION_BENCHMARKS[
                "dys_shortest_path_25x25"
            ],
            **DYS_INTEGER_BENCHMARKS,
        },
        "lp_benchmarks": {
            benchmark_id: PREDICTION_BENCHMARKS[benchmark_id]
            for benchmark_id in (
                "lava_random_lp_150x50_paper_appendix",
                "predictiveco_cubic_topk",
            )
        },
        "additional_integer_benchmarks": ADDITIONAL_INTEGER_BENCHMARKS,
    }
    pyepo_times, pyepo_sources = _retained_pyepo_times(arguments.pyepo_root)
    bcr_times: dict[str, float] = {}
    mse_times: dict[str, float] = {}
    bcr_sources: dict[str, str] = {}
    mse_sources: dict[str, str] = {}
    bcr_correction_times: dict[str, float] = {}
    bcr_combined_times: dict[str, float] = {}
    ray_reporting_times: dict[str, float] = {}
    for benchmark_id in PREDICTION_BENCHMARKS:
        bcr_seed_one = _seed_record(native_timing_grouped[(benchmark_id, "bcr")], 1)
        mse_seed_one = _seed_record(native_timing_grouped[(benchmark_id, "mse")], 1)
        sidecar_seconds = float(bcr_seed_one["correction_training_wall_seconds"])
        # Main-table timing follows the paper's policy-training contract.  The
        # optional physical-cost head and the combined total are retained as
        # separate supplementary quantities.
        bcr_times[benchmark_id] = float(bcr_seed_one["training_wall_seconds"])
        bcr_correction_times[benchmark_id] = sidecar_seconds
        bcr_combined_times[benchmark_id] = (
            bcr_times[benchmark_id] + sidecar_seconds
        )
        mse_times[benchmark_id] = float(mse_seed_one["training_wall_seconds"])
        bcr_sources[benchmark_id] = str(bcr_seed_one["run_directory"])
        mse_sources[benchmark_id] = str(mse_seed_one["run_directory"])
        ray_reporting_times[benchmark_id] = float(
            bcr_seed_one["ray_reporting_wall_seconds"]
        )
        benchmarks[benchmark_id]["methods"]["bcr"][
            "final_configuration_training_wall_seconds"
        ] = bcr_times[benchmark_id]
        benchmarks[benchmark_id]["methods"]["mse"][
            "final_configuration_training_wall_seconds"
        ] = mse_times[benchmark_id]
        benchmarks[benchmark_id]["methods"]["spo_plus"][
            "final_configuration_training_wall_seconds"
        ] = pyepo_times[benchmark_id]

    decision_panels: dict[str, Any] = {}
    for panel_name, panel in panel_specs.items():
        decision_panels[panel_name] = {
            benchmark_id: benchmarks[benchmark_id] for benchmark_id in panel
        }

    bcr_seconds = sum(bcr_times[key] for key in COMPLETE_METRIC_BENCHMARKS)
    bcr_correction_seconds = sum(
        bcr_correction_times[key] for key in COMPLETE_METRIC_BENCHMARKS
    )
    bcr_combined_seconds = sum(
        bcr_combined_times[key] for key in COMPLETE_METRIC_BENCHMARKS
    )
    mse_seconds = sum(mse_times[key] for key in COMPLETE_METRIC_BENCHMARKS)
    pyepo_seconds = sum(pyepo_times[key] for key in COMPLETE_METRIC_BENCHMARKS)

    paired_claims: dict[str, Any] = {}
    for benchmark_id in PREDICTION_BENCHMARKS:
        prediction_by_method = {
            method: {
                int(record["seed"]): float(
                    record["reported_conditional_mse_per_coordinate"]
                )
                for record in grouped[(benchmark_id, method)]
            }
            for method in TEX_METHOD
        }
        paired_claims[benchmark_id] = {
            "prediction": {
                baseline: _paired_check(
                    prediction_by_method["bcr"], prediction_by_method[baseline]
                )
                for baseline in ("mse", "spo_plus")
            },
            "decision_regret": {
                baseline: _paired_check(
                    frozen_seeded_regrets[(benchmark_id, "bcr")],
                    frozen_seeded_regrets[(benchmark_id, baseline)],
                )
                for baseline in ("mse", "spo_plus")
            },
        }

    payload = {
        "schema": "mlxor-complete-evidence-v4",
        "benchmarks": benchmarks,
        "decision_panels": decision_panels,
        "mixed_integer_summary": _mixed_integer_summary(arguments.integer_summary),
        "training_timing": {
            "bcr_seconds": bcr_seconds,
            "mse_seconds": mse_seconds,
            "pyepo_seconds": pyepo_seconds,
            "speedup": pyepo_seconds / bcr_seconds,
            "bcr_correction_seconds": bcr_correction_seconds,
            "bcr_combined_seconds": bcr_combined_seconds,
            "combined_speedup": pyepo_seconds / bcr_combined_seconds,
            "bcr_by_benchmark": bcr_times,
            "bcr_correction_by_benchmark": bcr_correction_times,
            "bcr_combined_by_benchmark": bcr_combined_times,
            "mse_by_benchmark": mse_times,
            "bcr_source_runs": bcr_sources,
            "mse_source_runs": mse_sources,
            "pyepo_by_benchmark": pyepo_times,
            "pyepo_source_runs": pyepo_sources,
            "ray_reporting_seed_one_by_benchmark": ray_reporting_times,
            "timing_scope": (
                "One-seed final-configuration policy-training wall time. The "
                "optional BCR physical-cost head and combined total are reported "
                "separately; the closed-form ray conversion is inference. SPO+ "
                "uses PyEPO 2.2.7."
            ),
            "correction_min_fold": min(correction_folds),
            "correction_max_fold": max(correction_folds),
        },
        "prediction_roots": [str(path.resolve()) for path in arguments.prediction_root],
        "native_timing_root": str(arguments.native_timing_root.resolve()),
        "paired_claims": paired_claims,
        "decision_summary_sources": [
            str(arguments.continuous_summary.resolve()),
            str(arguments.integer_summary.resolve()),
        ],
    }
    output_root = arguments.output_root
    output_root.mkdir(parents=True, exist_ok=True)
    (output_root / "MLXOR_RESULTS.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n"
    )
    (output_root / "MLXOR_RESULTS.md").write_text(_markdown(payload))
    (output_root.parent / "results_macros.tex").write_text(_tex(payload))
    print(json.dumps(payload["training_timing"], indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
