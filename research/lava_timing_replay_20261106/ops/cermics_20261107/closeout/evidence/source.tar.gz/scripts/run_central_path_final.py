#!/usr/bin/env python3
"""One replayable fit from the frozen final-campaign manifest."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import platform
import resource
import signal
import time
import traceback
from dataclasses import replace
from pathlib import Path

from build_central_path_extension import DIRECT_METHODS
from build_central_path_final import read, write

ROOT = Path(__file__).resolve().parents[1]


class ProgressUpdates:
    """Coalesce operational snapshots while always retaining latest memory state."""
    POLICY = "scaled_data_neural_buffered_io_v1"

    def __init__(self, record, path, started, *, interval=None, writer=None, clock=None):
        self.record, self.path, self.started = record, path, started
        self.interval = interval
        self.writer = writer or write
        self.clock = clock or time.perf_counter
        self.last_write, self.last_phase = None, None
        self.calls = self.writes = 0
        self.write_seconds = self.callback_seconds = self.checkpoint_seconds = 0.0
        self.callback_calls = self.checkpoint_calls = 0
        self.recorders = []
        self.emergency_finalize_seconds = 0.0

    def __call__(self, phase, **values):
        force = values.pop("_force_progress", False)
        now = self.clock()
        self.record.update(values, phase=phase, elapsed_seconds=now - self.started)
        self.calls += 1
        if (self.interval is not None and self.last_write is not None
            and phase == self.last_phase and not force
            and now - self.last_write < self.interval):
            return
        started = self.clock() if self.interval is not None else None
        self.writer(self.path, self.record)
        self.writes += 1
        self.last_write, self.last_phase = now, phase
        if started is not None:
            self.write_seconds += self.clock() - started

    def close_recorders(self):
        started = self.clock()
        try:
            for recorder in self.recorders:
                recorder.flush_curve(close=True)
        finally:
            self.emergency_finalize_seconds += self.clock() - started

    def receipt(self):
        return {"policy": self.POLICY, "maximum_interval_seconds": self.interval,
            "progress_update_calls": self.calls, "progress_file_writes": self.writes,
            "progress_write_wall_seconds": self.write_seconds,
            "core_callback_calls": self.callback_calls,
            "core_callback_total_wall_seconds": self.callback_seconds,
            "checkpoint_calls_within_core_callback": self.checkpoint_calls,
            "checkpoint_wall_seconds_within_core_callback": self.checkpoint_seconds,
            "recorder_emergency_finalize_wall_seconds": self.emergency_finalize_seconds,
            "recorders": [r.io_accounting() for r in self.recorders],
            "timing_hierarchy": "recorder append/terminal totals include fsync; core callback total includes checkpoint and its progress writes; progress writes also include calls outside core callback; overlapping values must not be summed",
            "scope": "operational callbacks/recording only; final receipt/progress serialization, epoch setup, selection state copies and objective.state remain outside these counters"}


def finalize_operational_io(record, updates):
    """A persistence failure must not prevent the terminal receipt attempt."""
    errors = []
    try:
        updates.close_recorders()
    except Exception as error:
        errors.append({"operation": "recorder_finalization",
            "error_type": type(error).__name__, "error": str(error)})
    for recorder in updates.recorders:
        errors.extend(getattr(recorder, "curve_persistence_errors", []))
    if errors:
        record["operational_io_persistence_errors"] = errors
        if record.get("status") not in ("failed", "censored"):
            record.update(status="failed", error_type="OperationalPersistenceError",
                error="Buffered recorder persistence failed; see operational_io_persistence_errors")
    record["operational_io"] = updates.receipt()


def core_progress_callback(job, model, spec, directory, update, operational_io=None):
    """Retain the exact checkpoint trigger and payload; measure only operations."""
    def progress(row):
        import torch
        started = time.perf_counter() if operational_io is not None else None
        try:
            checkpoint = row["epoch"] % 25 == 0 or "selection_score" in row
            if checkpoint:
                checkpoint_started = time.perf_counter() if operational_io is not None else None
                temporary = directory / "last_model.pt.tmp"
                torch.save({"model": model.state_dict(), "epoch": row["epoch"],
                            "job": job, "config": spec.to_dict()}, temporary)
                temporary.replace(directory / "last_model.pt")
                if checkpoint_started is not None:
                    operational_io.checkpoint_seconds += time.perf_counter() - checkpoint_started
                    operational_io.checkpoint_calls += 1
            fields = {"epochs_completed": row["epoch"],
                "optimization_seconds": row.get("optimization_wall_seconds")}
            if operational_io is not None:
                fields["_force_progress"] = checkpoint or row["epoch"] == spec.training.epochs
            update("training", **fields)
        finally:
            if started is not None:
                operational_io.callback_seconds += time.perf_counter() - started
                operational_io.callback_calls += 1
    return progress


def record_predictor_architecture(job, model, directory):
    """Fail closed if an affine-only campaign constructs a hidden predictor."""
    if job.get('scaled_data_neural_revision'):
        from scaled_data_neural_campaign import verify_predictor
        write(directory / 'predictor_architecture.json', verify_predictor(job, model))
        return
    if not job.get('linear_scale_revision'):
        return
    from linear_scale_architecture import verify_predictor
    write(directory / 'predictor_architecture.json', verify_predictor(job, model))


def training_prefix(dataset, size):
    if not 0 < size <= dataset.train.size:
        raise ValueError("training prefix must be within the original training split")
    fields = (
        "contexts",
        "physical_costs",
        "conditional_mean_costs",
        "coefficients",
        "conditional_mean_coefficients",
    )
    changes = {
        k: getattr(dataset.train, k)[:size]
        for k in fields
        if getattr(dataset.train, k) is not None
    }
    return replace(dataset, train=replace(dataset.train, **changes))


def load_job_data(job):
    """Resize training without changing either held-out split's random stream."""
    if job.get("scaled_data_neural_revision"):
        from scaled_data_neural_data import load_job
        return load_job(job)
    if job.get("simplified_revision"):
        from simplified_data import load_job
        return load_job(job)
    if job.get("pilot_revision"):
        from pilot_data import load_job
        return load_job(job)
    if job.get("physical128_revision"):
        from physical128_data import load_job
        return load_job(job)
    from proximal_spo.data import SplitSizes
    from proximal_spo.external_benchmarks import load_external_benchmark

    config = job["config"]
    original = job["original_sizes"]
    size = config["sizes"]["train"]
    normal32 = job.get("normal_validation_revision") == "observed_validation32_20260925_v1"
    if normal32:
        if (config["sizes"]["validation"] != 32 or config["sizes"]["train"] != 100
                or config["sizes"]["test"] != original["test"]
                or job.get("validation_costs") != "single_sample"
                or job.get("analytic_validation")):
            raise ValueError("Invalid frozen ordinary-validation correction")
    elif any(config["sizes"][key] != original[key] for key in ("validation", "test")):
        raise ValueError("held-out split sizes must match the Atlanta archive")
    generated = {**original, "train": max(original["train"], size)}
    # The pinned DYS generator derives independent train/validation/test seeds.
    # Growing 96 to 100 regenerates costs from that same training seed; it does
    # not promise that the old 96 noisy costs remain a prefix.
    loaded = load_external_benchmark(
        job["route"],
        SplitSizes(**generated),
        data_seed=config["seeds"]["data"],
        conditional_reference_samples=config["conditional_reference_samples"],
    )
    result = replace(
        loaded,
        dataset=training_prefix(loaded.dataset, size),
        provenance={
            **loaded.provenance,
            "campaign_training_resize": {
                "original_sizes": original,
                "generated_sizes": generated,
                "retained_train_size": size,
                "policy": "same_seed_training_regeneration"
                if size > original["train"]
                else "original_training_prefix",
                "data_seed": config["seeds"]["data"],
                "held_out_streams_unchanged": True,
            },
        },
    )
    if normal32:
        from normal_validation_data import restore_ready_dataset
        result = restore_ready_dataset(job, result)
    elif job.get("protocol_revision") == "physical_relaxed_spo_conditional_validation_v1":
        from frozen_campaign_data import freeze_or_restore
        result = freeze_or_restore(job, result)
    if job.get("analytic_validation"):
        from exact_validation_reference import analytic_validation_view
        result = analytic_validation_view(job, result)
    return result


def barrier_validation(model, objective, split, *, conditional_mean=False):
    import numpy as np

    from proximal_spo.evaluation import predict_in_batches

    outputs = predict_in_batches(model, split.contexts, batch_size=256)
    mapped, _, _ = objective._map(outputs.astype(np.float64))
    energy, _ = objective.geometry.centered_barrier_value_and_reduced_gradient(mapped)
    costs = split.conditional_mean_costs if conditional_mean else split.physical_costs
    physical = np.sum(costs * mapped.decisions, axis=1)
    mu = float(objective.alpha_end * objective.cost_scale / objective.inequality_count)
    value = float(np.mean(physical + mu * energy))
    return value, {
        "metric": "conditional_mean_cost_plus_centered_barrier" if conditional_mean else "observed_cost_plus_centered_barrier",
        "mu": mu,
        "mean_physical_cost": float(physical.mean()),
        "mean_barrier_energy": float(energy.mean()),
        "samples": split.contexts.shape[0],
    }


def selection_validation_split(split, job):
    """Use a fixed observed cost per context only in the explicit ablation.

    Evaluators use the conditional_* slots as their scoring target. This
    independent view changes those slots for validation only; the frozen data,
    training labels and expected-cost test reference remain untouched.
    """
    mode = job.get("validation_costs", "conditional_mean")
    if mode == "single_sample":
        return replace(split, conditional_mean_costs=split.physical_costs,
                       conditional_mean_coefficients=split.coefficients)
    if mode != "conditional_mean":
        raise ValueError("Unknown validation cost regime: " + str(mode))
    return split


def core_fit(job, loaded, directory, update, training_started, *, timing_only=False, operational_io=None):
    import numpy as np
    import torch

    from proximal_spo.artifacts import RunRecorder, model_sha256
    from proximal_spo.config import RunSpec
    from proximal_spo.evaluation import evaluate_model
    from proximal_spo.objectives import prepare_split
    from proximal_spo.oracles import make_lp_oracle
    from proximal_spo.problem import PartialCostInterface
    from proximal_spo.runner import _coefficient_transform, _objective, _standard_model
    from proximal_spo.training import train_model

    config = copy.deepcopy(job["config"])
    if timing_only:
        validate_timing_job(job)
    physical_baseline = job.get("baseline_protocol") == "physical_cold_highs_v1"
    central = job["method"].startswith("central_path_")
    direct = job["method"] in DIRECT_METHODS
    if direct:
        if not loaded.problem.is_continuous:
            raise ValueError("direct-policy ablation requires a pure continuous LP")
        config["method"] = job["method"]
    if job["method"] == "wise":
        config["method"] = "wise"
    spec = RunSpec.from_dict(config)
    dataset, problem = loaded.dataset, loaded.problem
    interface, transform = _coefficient_transform(
        spec, dataset, dataset.interface(spec.interface, problem)
    )
    if physical_baseline:
        interface = PartialCostInterface.full_cost(problem)
    relaxed = PartialCostInterface(
        problem.continuous_relaxation(),
        interface.fixed_cost,
        interface.statistic,
        name=interface.name + ".training",
    )

    def prepare(split, geometry):
        coefficients, means = dataset.coefficients(split, spec.interface)
        if physical_baseline:
            from proximal_spo.canonical_baselines import ColdHighsBatch
            coefficients, means = split.physical_costs, split.conditional_mean_costs
            oracle_factory = lambda: ColdHighsBatch(geometry)
            oracle_kind = "canonical_baselines.ColdHighsBatch"
        else:
            coefficients, means = transform.apply(coefficients), transform.apply(means)
            oracle_factory = lambda: make_lp_oracle(geometry, workers=1, random_seed=spec.seeds.structural)
            oracle_kind = "oracles.make_lp_oracle(workers=1)"
        inputs = dict(contexts=split.contexts, coefficients=coefficients,
            conditional_mean_coefficients=means, physical_costs=split.physical_costs,
            conditional_mean_costs=split.conditional_mean_costs, split=split.split)
        def compute():
            with oracle_factory() as oracle:
                return prepare_split(**inputs, oracle=oracle)
        from cached_preparation import prepare_cached
        return prepare_cached(geometry, oracle_kind,
                              spec.seeds.structural, inputs, compute, update)

    train = prepare(
        dataset.train,
        relaxed.problem if central or job["method"] in ("spo_plus", "intopt_original") else problem,
    )
    validation = None if timing_only else prepare(selection_validation_split(dataset.validation, job), problem)
    objective_interface = (
        relaxed if central or job["method"] in ("spo_plus", "intopt_original") else interface
    )
    if physical_baseline:
        from proximal_spo.canonical_baselines import PhysicalMSEObjective, PhysicalWISEObjective, PhysicalSPOPlusObjective
        if job["method"] == "intopt_original":
            from proximal_spo.intopt_original import OriginalIntOptObjective
            objective = OriginalIntOptObjective(problem, mu_cutoff=job["parameters"]["mu_cutoff"])
        else:
            objective = {"mse": PhysicalMSEObjective, "wise": PhysicalWISEObjective,
                         "spo_plus": PhysicalSPOPlusObjective}[job["method"]](problem)
    elif job["method"] == "direct_projection":
        from proximal_spo.extension_projection import ChunkedDirectProjectionObjective

        update("preprocessing", projection_chunk_size=32)
        objective = ChunkedDirectProjectionObjective(objective_interface, workers=1)
    elif job.get("simplified_revision") and job.get("wise_transform"):
        from simplified_losses import wise_cp_objective
        objective = wise_cp_objective(spec, objective_interface, train, problem)
    else:
        objective = _objective(
            spec, objective_interface, train, deployment_problem=problem
        )
    try:
        if central:
            objective.set_deployment_mode("hard_recovered")
            objective.set_checkpoint_selection_deployment("hard_recovered")
            train = objective.prepare_training_split(train)
        elif direct and hasattr(objective, "prepare_training_split"):
            train = objective.prepare_training_split(train)
        if direct and hasattr(objective, "mu") and objective.mu != 0:
            raise ValueError("direct-policy ablation must have zero barrier weight")
        torch.manual_seed(spec.seeds.initialization)
        model = _standard_model(
            spec, train, objective, train.coefficients.mean(axis=0), np.zeros(1)
        )
        record_predictor_architecture(job, model, directory)
        recorder = RunRecorder(
            directory / "training", config=spec.to_dict(), repo_root=ROOT,
            **({"curve_fsync_policy": "validation", "curve_fsync_interval_seconds": 60.0,
                "record_io_timing": True} if job.get("scaled_data_neural_revision") else {}),
        )
        if operational_io is not None:
            operational_io.recorders.append(recorder)
        if job.get("pilot_dual_validation"):
            from pilot_validation import DualRecorder
            recorder = DualRecorder(recorder, model, objective, validation, job, directory,
                spec.training.evaluation_batch_size, spec.training.minimum_delta)
        scorer = (
            barrier_validation
            if job["method"] == "central_path_barrier_validation"
            else None
        )
        if timing_only:
            scorer = None
        if scorer and job.get("validation_costs") == "conditional_mean":
            from functools import partial
            scorer = partial(barrier_validation, conditional_mean=True)
        if not timing_only:
            training_started()

        progress = core_progress_callback(job, model, spec, directory, update, operational_io)

        if job.get("frozen_horizon") == 0:
            if timing_only:
                training_started()
                metrics, score = None, None
            else:
                metrics = evaluate_model(
                    model,
                    objective,
                    validation,
                    batch_size=spec.training.evaluation_batch_size,
                )
                score = (
                    scorer(model, objective, validation)[0]
                    if scorer
                    else metrics.mean_regret
                )
            summary = {
                "best_epoch": 0,
                "epochs_completed": 0,
                "best_validation": None if metrics is None else metrics.to_dict(),
                "test": None,
                "best_selection_score": score,
                "optimization_cap_reached": False,
                "optimization_wall_seconds": 0.0,
                "optimization_cpu_seconds": 0.0,
                "validation_wall_seconds": 0.0 if timing_only else None,
                "test_evaluation_wall_seconds": 0.0,
                "parameter_sha256": model_sha256(model),
            }
            recorder.append_curve(
                {"epoch": 0, "selection_score": score, "validation": None if metrics is None else metrics.to_dict()}
            )
            recorder.finish(summary)
        else:
            result = train_model(
                model=model,
                objective=objective,
                train=train,
                validation=validation,
                test=None,
                spec=spec.training,
                shuffle_seed=spec.seeds.shuffle,
                recorder=recorder,
                epoch_callback=progress,
                validation_scorer=scorer,
                selection_metric="barrier_cost" if scorer else "unsmoothed_regret",
                timing_only=timing_only,
                on_optimizer_ready=training_started if timing_only else None,
            )
            summary = result.to_dict()
        if job.get("pilot_dual_validation"):
            summary["validation_variants"] = recorder.summaries()
            summary["extra_validation32_wall_seconds"] = recorder.extra_wall_seconds
        torch.save({"model": model.state_dict(), "job": job, "config": spec.to_dict()}, directory / "model.pt")
        if hasattr(objective, "receipt"):
            summary["objective_receipt"] = objective.receipt()
        # Test reference solves occur only after every selection decision is frozen.
        if job["stage"] == "confirmation":
            update("test_evaluation")
            started = time.perf_counter()
            test_data = dataset.test
            if job.get("simplified_revision"):
                if job.get("scaled_data_neural_revision"):
                    from scaled_data_neural_data import test_split
                else:
                    from simplified_data import test_split
                from pilot_validation import freeze_single
                test_data = test_split(job, directory, freeze_single(model, directory,
                    summary["best_epoch"], summary["best_selection_score"], job))
            if job.get("pilot_revision"):
                from pilot_data import test_split
                from pilot_validation import freeze_single
                selection = ({"selection_uses_test":False,
                    "validation_variants":summary["validation_variants"],
                    "selected_test_views":job["pilot_test_validation_sizes"]}
                    if job.get("pilot_dual_validation") else freeze_single(model,directory,
                        summary["best_epoch"],summary["best_selection_score"],job))
                test_data = test_split(job,directory,selection)
            test = prepare(test_data, problem)
            from proximal_spo.evaluation import predict_in_batches, evaluate_outputs
            if job.get("pilot_dual_validation"):
                original_state = copy.deepcopy(model.state_dict())
                for n in job["pilot_test_validation_sizes"]:
                    view=summary["validation_variants"][str(n)]
                    if hashlib.sha256(Path(view["checkpoint"]).read_bytes()).hexdigest()!=view["checkpoint_sha256"]:
                        raise ValueError("Selected checkpoint changed before test")
                    state=torch.load(view["checkpoint"],map_location="cpu",weights_only=False)
                    model.load_state_dict(state["model"])
                    if model_sha256(model)!=view["parameter_sha256"]:raise ValueError("Checkpoint parameter hash differs")
                    capture={};predictions=predict_in_batches(model,test.contexts,batch_size=spec.training.evaluation_batch_size)
                    view["test"]=evaluate_outputs(objective,predictions,test,batch_size=spec.training.evaluation_batch_size,capture=capture).to_dict()
                    np.savez_compressed(directory/f"test_predictions_validation{n}.npz",**capture)
                model.load_state_dict(original_state)
            else:
                capture = {}
                predictions = predict_in_batches(model, test.contexts, batch_size=spec.training.evaluation_batch_size)
                summary["test"] = evaluate_outputs(objective, predictions, test,
                    batch_size=spec.training.evaluation_batch_size, capture=capture).to_dict()
                np.savez_compressed(directory / "test_predictions.npz", **capture)
            summary["test_evaluation_wall_seconds"] = time.perf_counter() - started
        if central:
            summary["mu_end"] = float(
                objective.alpha_end * objective.cost_scale / objective.inequality_count
            )
        summary["validation_costs"] = job.get("validation_costs", "archived_protocol")
        if physical_baseline:
            summary["baseline_protocol"] = job["baseline_protocol"]
            summary["spo_training_domain"] = "continuous_relaxation" if job["method"] == "spo_plus" else None
            summary["cold_generic_highs"] = True
        torch.save({"model": model.state_dict(), "job": job, "config": spec.to_dict()}, directory / "model.pt")
        if direct:
            summary["direct_policy"] = {
                "barrier_weight": 0.0,
                "training_costs": "observed physical costs",
                "deployment": "mapped feasible policy without hard recovery",
            }
        return summary, [
            json.loads(line)
            for line in recorder.curve_path.read_text().splitlines()
            if "selection_score" in json.loads(line)
        ]
    finally:
        objective.close()


def validate_timing_job(job):
    """A timing replay cannot make a selection or evaluate held-out costs."""
    training = job["config"]["training"]
    if (job["stage"] != "timing" or job["config"].get("evaluate_test", True)
        or job.get("frozen_horizon") is None
        or training["selection_mode"] != "last"
        or training.get("maximum_optimization_seconds") is not None
        or training["epochs"] != max(1, job["frozen_horizon"])):
        raise ValueError("Invalid frozen timing-only job")


def baseline_fit(job, loaded, directory, update, training_started, *, timing_only=False,
                 lifecycle=None):
    from types import SimpleNamespace

    import numpy as np
    import run_public_solver_free_matched as matched
    import torch
    from extension_losses import create_loss
    from pyepo.data.dataset import optDataset
    from torch.utils.data import default_collate

    from proximal_spo.artifacts import model_sha256
    from proximal_spo.models import ModelSpec, StandardizedMLP, input_statistics
    from proximal_spo.objectives import WISEObjective
    from proximal_spo.oracles import PersistentLPSolver
    from proximal_spo.problem import PartialCostInterface
    from proximal_spo.seeds import derive_seed
    from proximal_spo.training import (
        TrainingSpec,
        _learning_rate_at_epoch,
        _should_validate,
    )

    entry, method = job["config"], job.get("base_method", job["method"])
    simplified = bool(job.get("simplified_revision"))
    weighted = simplified and bool(job.get("wise_transform"))
    if timing_only:
        validate_timing_job(job)
    spec = TrainingSpec(**entry["training"])
    dataset, problem = loaded.dataset, loaded.problem
    contexts, costs = dataset.train.contexts, dataset.train.physical_costs
    if weighted:
        from simplified_losses import normalize_costs
        labels, norms = normalize_costs(costs)
    else:
        labels, norms = costs, None
    public_model, train, wise = None, None, None
    geometry_receipt = None
    if method not in ("mse", "wise"):
        if lifecycle is not None:
            if (not simplified or weighted or method not in ("spo_plus", "pfyl", "nce")
                    or job.get("training_oracle") != "continuous_relaxation"):
                raise ValueError("Lifecycle ablation requires an ordinary public LP loss")
            public_model = lifecycle.preprocessing_model(problem.continuous_relaxation())
        elif simplified:
            from proximal_spo.public_highs import HighsOptModel
            native = problem if job.get("training_oracle") == "native_integer" else problem.continuous_relaxation()
            if method == "spo_plus":
                from proximal_spo.canonical_baselines import ColdHighsOptModel
                public_model = ColdHighsOptModel(native)
            else:
                public_model = HighsOptModel(native)
        else:
            public_model = matched._fixed_model(problem.continuous_relaxation(), integer=False)
        if method == "nce" and lifecycle is None:
            from proximal_spo.robust_public_highs import RobustHighsOptModel

            public_model = RobustHighsOptModel(native if simplified else problem.continuous_relaxation())
        if method in ("cave", "lava") and os.environ.get("CENTRAL_PATH_GEOMETRY_CACHE"):
            from final_geometry_cache import get_geometry

            geometry_job = {**job, "method": method}
            train = get_geometry(geometry_job, public_model, contexts, labels, update)
            geometry_receipt = train.geometry_cache_receipt
        elif method == "cave":
            train = matched.BindingOnlyDataset(public_model, contexts, costs)
        elif method == "lava":
            from proximal_spo.public_highs import HighsLAVADataset

            train = HighsLAVADataset(
                public_model,
                contexts,
                costs,
                public_repo=matched.PUBLIC_REPO,
                vertex_tolerance=job["parameters"]["vertex_tolerance"],
                progress=lambda n, d: update(
                    "preprocessing", geometry_samples_processed=n
                ),
            )
            geometry_receipt = {
                "public_source_sha256": train.public.source_sha256,
                "vertex_counts": [len(x) for x in train.adjacent_verts],
                "basis_completions": train.basis_completion_count,
                "anchor_reselections": train.anchor_reselection_count,
                "tnp_retries": train.adjacency_tnp_retry_count,
                "vertex_tolerance": train.vertex_tolerance,
                "basis_enumeration_cap": 250,
                "completeness_certified": False,
            }
        else:
            train = optDataset(public_model, contexts, labels)
        if lifecycle is not None:
            public_model = lifecycle.training_model(public_model, train)
    # Reset after all preprocessing to isolate initialization from solver setup.
    matched._seed(entry["seeds"]["initialization"])
    initialization_costs = (costs / max(float(norms.sum()), 1e-12) * len(costs)) if weighted else costs
    model = matched._make_model(entry, contexts, initialization_costs)
    record_predictor_architecture(job, model, directory)
    physical_head = bool(entry.get("physical_cost_output"))
    if physical_head:
        if method not in ("pfyl", "nce", "lava") and not simplified:
            raise ValueError("Unregistered physical public baseline")
        mean, scale, beta = np.zeros(costs.shape[1]), np.ones(costs.shape[1]), costs
    else:
        mean = model.cost_mean.numpy().astype(np.float64)
        scale = model.cost_scale.numpy().astype(np.float64)
        beta = (costs - mean) / scale
    if method == "wise" and not simplified:
        interface = PartialCostInterface(
            problem, mean, np.diag(scale), name="final.standardized"
        )
        wise = WISEObjective(
            interface, workers=1, random_seed=entry["seeds"]["structural"]
        )
        labels = wise.labels(beta)
        bias = labels.sum(axis=0) / max(
            float(np.linalg.norm(labels, axis=1).sum()), 1e-12
        )
        im, isc = input_statistics(contexts)
        torch.manual_seed(entry["seeds"]["initialization"])
        model = StandardizedMLP(
            contexts.shape[1],
            wise.output_dimension,
            ModelSpec(**entry["model"]),
            input_mean=im,
            input_scale=isc,
            output_bias=bias,
        )
        loss = None
    elif simplified and method in ("mse", "wise"):
        loss = None
    elif simplified:
        from simplified_losses import public_loss
        loss = public_loss(method, public_model, job["parameters"], train,
                           entry["seeds"]["perturbation"], weighted=weighted)
    else:
        loss = create_loss(method, public_model, job["parameters"], train)
        if method == "pfyl":
            loss.rnd = np.random.RandomState(entry["seeds"]["perturbation"])
    if lifecycle is not None:
        lifecycle.instrument_loss(loss)
        lifecycle.record_pretraining(model, train, loss)
    if method in ("cave", "lava"):
        from proximal_spo.public_highs import public_geometry

        collate = public_geometry(str(matched.PUBLIC_REPO)).collate_fn_2
    else:
        collate = default_collate
    solver_type = PersistentLPSolver
    if method == "nce":
        from proximal_spo.robust_public_highs import RobustEvaluationSolver

        solver_type = RobustEvaluationSolver
    if simplified and method in ("mse", "wise", "spo_plus") and not timing_only:
        from proximal_spo.canonical_baselines import ColdHighsBatch
        solver = ColdHighsBatch(problem)
    else:
        solver = None if timing_only else solver_type(problem, random_seed=entry["seeds"]["structural"])
    try:
        val = reference = None
        if not timing_only:
            val = selection_validation_split(dataset.validation, job)
            reference = solver.solve_many(val.conditional_mean_costs).objectives

        def evaluate(split, ref, *, capture=False):
            if timing_only:
                raise RuntimeError("Evaluation is forbidden in timing-only fits")
            started = time.perf_counter()
            model.eval()
            with torch.no_grad():
                if wise is not None:
                    output = model(
                        torch.as_tensor(split.contexts, dtype=torch.float32)
                    ).numpy()
                    pred = wise.predicted_physical_costs(output)
                else:
                    pred = matched._physical_prediction(model, split.contexts).numpy()
            deployed = solver.solve_many(pred)
            regret = (
                np.sum(split.conditional_mean_costs * deployed.decisions, axis=1) - ref
            )
            tolerance = 5e-7 * (
                1 + np.abs(ref) + np.abs(split.conditional_mean_costs).sum(axis=1)
            )
            if np.any(regret < -tolerance):
                raise RuntimeError("materially negative evaluated regret")
            regret = np.maximum(regret, 0.0)
            denominator = float(np.abs(ref).mean())
            if capture:
                np.savez_compressed(directory / "test_predictions.npz",
                    contexts=split.contexts, predicted_physical_costs=pred,
                    decisions=deployed.decisions, reference_objectives=ref,
                    regrets=regret, conditional_mean_costs=split.conditional_mean_costs,
                    physical_costs=split.physical_costs)
            return {
                "sample_count": len(regret),
                "mean_regret": float(regret.mean()),
                "standard_error_regret": float(
                    regret.std(ddof=1) / np.sqrt(len(regret))
                )
                if len(regret) > 1
                else 0.0,
                "normalized_mean_regret": float(regret.mean() / denominator)
                if denominator > 1e-8
                else None,
                "mean_realized_cost": float(
                    np.sum(split.physical_costs * deployed.decisions, axis=1).mean()
                ),
                "wall_seconds": time.perf_counter() - started,
            }

        optimizer_class = (
            torch.optim.AdamW if spec.optimizer == "adamw" else torch.optim.Adam
        )
        optimizer = optimizer_class(
            model.parameters(), lr=spec.learning_rate, weight_decay=spec.weight_decay
        )
        if simplified:
            from simplified_campaign import assert_adam
            assert_adam(optimizer, spec)
        training_started()
        if lifecycle is not None:
            lifecycle.start_optimization()
        if timing_only:
            best_score, best_epoch, best_metrics, best_state = None, 0, None, None
            curve, validation_seconds = [], 0.0
        else:
            initial = evaluate(val, reference)
            best_score, best_epoch, best_metrics = initial["mean_regret"], 0, initial
            best_state = copy.deepcopy(model.state_dict())
            curve = [{"epoch": 0, "selection_score": best_score, "validation": initial}]
            validation_seconds = initial["wall_seconds"]
        optimization, optimization_cpu, stale = 0.0, 0.0, 0
        cap = False
        epoch = 0
        for epoch in range(
            1, min(spec.epochs, job.get("frozen_horizon", spec.epochs)) + 1
        ):
            started = time.perf_counter()
            cpu_started = time.process_time()
            model.train()
            lr = _learning_rate_at_epoch(spec, epoch)
            for group in optimizer.param_groups:
                group["lr"] = lr
            order = np.random.default_rng(
                derive_seed(entry["seeds"]["shuffle"], "epoch", epoch)
            ).permutation(len(contexts))
            losses = []
            for start in range(0, len(order), spec.batch_size):
                indices = order[start : start + spec.batch_size]
                if job.get("training_oracle") == "native_integer":
                    from simplified_campaign import save_training_clock
                    elapsed = optimization + time.perf_counter() - started
                    outside_timer = time.perf_counter()
                    save_training_clock(directory, job, elapsed, epoch - 1, start, update, active=True)
                    started += time.perf_counter() - outside_timer
                x = torch.as_tensor(contexts[indices], dtype=torch.float32)
                optimizer.zero_grad(set_to_none=True)
                if simplified and method in ("mse", "wise"):
                    pred = model(x)
                    target = torch.as_tensor(labels[indices], dtype=pred.dtype)
                    if weighted:
                        from simplified_losses import wise_mse
                        value = wise_mse(pred, target, torch.as_tensor(norms[indices], dtype=pred.dtype))
                    else:
                        value = (pred - target).square().mean()
                    if not torch.isfinite(value):
                        raise RuntimeError("nonfinite physical regression loss")
                    value.backward()
                    value = float(value.detach())
                elif wise is not None:
                    output = model(x)
                    result = wise.signal(
                        output.detach().numpy(),
                        SimpleNamespace(coefficients=beta[indices]),
                    )
                    output.backward(
                        torch.as_tensor(
                            result.output_gradient / len(indices), dtype=output.dtype
                        )
                    )
                    value = float(result.values.mean())
                else:
                    if method == "mse":
                        value = loss(
                            model(x),
                            torch.as_tensor(beta[indices], dtype=torch.float32),
                        )
                    else:
                        batch = collate([train[int(i)] for i in indices])
                        pred = matched._physical_prediction(model, x)
                        if simplified:
                            from simplified_losses import batch_loss
                            weights = None if norms is None else torch.as_tensor(norms[indices], dtype=pred.dtype)
                            value = batch_loss(method, loss, pred, batch, weights=weights)
                        elif method == "spo_plus":
                            value = loss(pred, batch[1], batch[2], batch[3])
                        elif method in ("pfyl", "nce"):
                            value = loss(pred, batch[2])
                        elif method == "cave":
                            value = loss(pred, batch[6])
                        else:
                            value = loss(pred, batch[7], batch[4], -1.0)
                    if not torch.isfinite(value):
                        raise RuntimeError("nonfinite public loss")
                    value.backward()
                    value = float(value.detach())
                if not all(
                    p.grad is None or torch.isfinite(p.grad).all()
                    for p in model.parameters()
                ):
                    raise RuntimeError("nonfinite baseline gradient")
                if spec.gradient_clip is not None:
                    torch.nn.utils.clip_grad_norm_(
                        model.parameters(), spec.gradient_clip
                    )
                optimizer.step()
                losses.append((value, len(indices)))
                if job.get("training_oracle") == "native_integer":
                    elapsed = optimization + time.perf_counter() - started
                    from simplified_campaign import save_training_clock
                    outside_timer = time.perf_counter()
                    save_training_clock(directory, job, elapsed, epoch - 1,
                                         start + len(indices), update)
                    started += time.perf_counter() - outside_timer
            optimization += time.perf_counter() - started
            optimization_cpu += time.process_time() - cpu_started
            cap = cap or (
                spec.maximum_optimization_seconds is not None
                and optimization >= spec.maximum_optimization_seconds
            )
            row = {
                "epoch": epoch,
                "optimization_seconds": optimization,
                "mean_loss": sum(x * n for x, n in losses) / sum(n for _, n in losses),
                "learning_rate": lr,
            }
            if not timing_only and (_should_validate(spec, epoch) or cap):
                metrics = evaluate(val, reference)
                validation_seconds += metrics["wall_seconds"]
                score = metrics["mean_regret"]
                row.update(validation=metrics, selection_score=score)
                if (
                    spec.selection_mode == "last"
                    or score < best_score - spec.minimum_delta
                ):
                    best_score, best_epoch, best_metrics = score, epoch, metrics
                    best_state = copy.deepcopy(model.state_dict())
                    if physical_head:
                        temporary = directory / "best_model.pt.tmp"
                        torch.save({"model": best_state, "epoch": best_epoch,
                                    "job": job, "config": entry}, temporary)
                        temporary.replace(directory / "best_model.pt")
                    stale = 0
                else:
                    stale += 1
                curve.append(row)
            if timing_only and (epoch % 25 == 0 or epoch == job["frozen_horizon"]):
                temporary = directory / "last_model.pt.tmp"
                torch.save({"model": model.state_dict(), "epoch": epoch, "job": job}, temporary)
                temporary.replace(directory / "last_model.pt")
            if (job.get("pilot_revision") or simplified) and (epoch % 25 == 0 or "selection_score" in row):
                temporary = directory / "last_model.pt.tmp"
                torch.save({"model":model.state_dict(),"epoch":epoch,"job":job},temporary)
                temporary.replace(directory / "last_model.pt")
            with (directory / "learning_curve.jsonl").open("a") as f:
                f.write(json.dumps(row) + "\n")
            update(
                "training", epochs_completed=epoch, optimization_seconds=optimization,
                **({"_force_progress": epoch % 25 == 0 or "selection_score" in row
                    or epoch == spec.epochs} if job.get("scaled_data_neural_revision") else {}),
            )
            if cap or (spec.selection_mode != "last" and stale >= spec.patience):
                break
        if timing_only:
            best_epoch = epoch
        else:
            model.load_state_dict(best_state)
        if physical_head:
            temporary = directory / "model.pt.tmp"
            torch.save({"model": model.state_dict(), "epoch": best_epoch,
                        "job": job, "config": entry,
                        "parameter_sha256": model_sha256(model)}, temporary)
            temporary.replace(directory / "model.pt")
        test = None
        if job["stage"] == "confirmation" and not cap:
            update("test_evaluation")
            if simplified:
                if job.get("scaled_data_neural_revision"):
                    from scaled_data_neural_data import test_split
                else:
                    from simplified_data import test_split
                from pilot_validation import freeze_single
                selected_test = test_split(job, directory, freeze_single(model, directory, best_epoch, best_score, job))
            elif job.get("pilot_revision"):
                from pilot_data import test_split
                from pilot_validation import freeze_single
                selected_test=test_split(job,directory,freeze_single(model,directory,best_epoch,best_score,job))
            else:
                selected_test=dataset.test
            test_reference = solver.solve_many(
                selected_test.conditional_mean_costs
            ).objectives
            test = evaluate(selected_test, test_reference, capture=physical_head and (
                lifecycle is None or lifecycle.capture_test_predictions))
        return {
            "output_coordinates": "physical_costs_no_fixed_affine_decoder" if physical_head else "archived_affine_standardization",
            "information_budget": "observed_training_only" if physical_head else "archived_protocol",
            "best_epoch": best_epoch,
            "best_validation": best_metrics,
            "test": test,
            "best_selection_score": best_score,
            "selection_metric": "frozen_horizon_no_evaluation" if timing_only else "unsmoothed_regret",
            "epochs_completed": epoch,
            "optimization_wall_seconds": optimization,
            "optimization_cpu_seconds": optimization_cpu,
            "validation_wall_seconds": validation_seconds,
            "test_evaluation_wall_seconds": 0.0 if test is None else test["wall_seconds"],
            "optimization_cap_reached": cap,
            "parameter_sha256": model_sha256(model),
            "geometry": geometry_receipt,
            "wise_transform": weighted,
            "training_oracle": job.get("training_oracle", "continuous_relaxation"),
            "training_oracle_class": None if public_model is None else type(public_model).__name__,
            "evaluation_oracle_class": None if solver is None else type(solver).__name__,
            "label_costs": "normalized_full_physical_training_costs" if weighted else "full_physical_training_costs",
            "optimizer": type(optimizer).__name__,
            "optimizer_defaults": {k: optimizer.defaults[k] for k in ('betas', 'eps', 'amsgrad', 'weight_decay')},
            "loss_class": "WISEObjective" if wise is not None else type(loss).__name__,
            "oracle_recoveries": getattr(public_model, "recovery_counts", None),
            "evaluation_oracle_recoveries": getattr(solver, "recovery_counts", None),
            "validation_costs": job.get("validation_costs", "conditional_mean"),
        }, curve
    finally:
        # PersistentLPSolver owns a native HiGHS object, without a close API.
        if wise is not None:
            wise.close()


def run(args):
    started = time.perf_counter()
    manifest = read(args.manifest)
    job = copy.deepcopy(manifest["jobs"][args.job_index])
    resource_limits = {**manifest["protocol"], **job.get("resource_limits", {})}
    out = args.output_root / "receipts" / (job["id"] + ".json")
    # Defense in depth: even a faulty or restarted dispatcher cannot execute
    # the same fit concurrently or overwrite another attempt's progress.
    import fcntl
    locks=args.output_root / "fit_locks"
    locks.mkdir(parents=True,exist_ok=True)
    fit_guard=(locks / (job["id"]+".lock")).open("a")
    fcntl.flock(fit_guard,fcntl.LOCK_EX)
    if out.exists():
        print(json.dumps({"already_recorded": job["id"]}))
        return
    attempt = (
        args.output_root / "attempts" / job["id"] / f"{time.time_ns()}-{os.getpid()}"
    )
    attempt.mkdir(parents=True)
    if job.get("whitening_validation_revision") or job.get("pilot_revision") or job.get("simplified_revision"):
        os.environ["CP_SPO_PREPARATION_LOG"] = str(attempt / "preparation_cache.jsonl")
    progress = args.output_root / "progress" / (job["id"] + ".json")
    record = {
        "job": job,
        "status": "running",
        "phase": "imports",
        "host": platform.node(),
        "pid": os.getpid(),
        "attempt_directory": str(attempt),
        "test_access": False,
        "smoke_only": bool(job.get("diagnostic_only", False)),
        "manifest_sha256": hashlib.sha256(args.manifest.read_bytes()).hexdigest(),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "smoke_only": bool(job.get("diagnostic_only")),
    }
    history = args.output_root / "resource_retries" / job["id"]
    record["prior_resource_attempts"] = [
        {
            "path": str(path),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "status": read(path)["status"],
            "error": read(path).get("error"),
            "total_wall_seconds": read(path).get("total_wall_seconds"),
        }
        for path in sorted(history.glob("*.json"))
    ]

    scoped_io = bool(job.get("scaled_data_neural_revision"))
    update = ProgressUpdates(record, progress, started, interval=60.0 if scoped_io else None)
    if scoped_io:
        record["operational_io_policy"] = ProgressUpdates.POLICY

    def timeout(signum, frame):
        raise TimeoutError(f"time cap reached during {record['phase']}")

    def training_started():
        record["preprocessing_wall_seconds"] = time.perf_counter() - started
        if resource_limits.get("job_wall_cap_seconds") is None:
            signal.setitimer(signal.ITIMER_REAL, 0)
            return
        signal.setitimer(
            signal.ITIMER_REAL,
            max(
                1.0,
                resource_limits["job_wall_cap_seconds"]
                - (time.perf_counter() - started),
            ),
        )
        update("training")

    try:
        signal.signal(signal.SIGALRM, timeout)
        signal.setitimer(
            signal.ITIMER_REAL, resource_limits.get("preprocessing_cap_seconds") or 0
        )
        import run_public_solver_free_matched as matched
        import torch

        from proximal_spo.artifacts import environment_receipt

        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        if args.smoke:
            # Smoke artifacts are isolated from scientific results and selectors.
            job["original_sizes"] = {"train": 8, "validation": 3, "test": 3}
            job["config"]["sizes"] = {"train": 4, "validation": 3, "test": 3}
            job["config"]["training"].update(
                epochs=2, validation_epochs=[1, 2], batch_size=4
            )
            record["smoke_only"] = True
        record["environment"] = environment_receipt(ROOT)
        record["public_commit"] = matched._public_commit(matched.PUBLIC_REPO)
        record["external_commit"] = matched._public_commit(matched.EXTERNAL_SRC.parent)
        if os.environ.get("ATLANTA_SOURCE_MANIFEST"):
            record["packaged_source"] = read(os.environ["ATLANTA_SOURCE_MANIFEST"])
        if job.get("scaled_data_neural_revision"):
            from scaled_data_neural_campaign import validate_execution
            record["execution_resources"] = validate_execution(job)
        update("preprocessing")
        config = job["config"]
        loaded = load_job_data(job)
        record["data_hashes"] = {
            split: {
                field: matched._hash_array(
                    getattr(getattr(loaded.dataset, split), field)
                )
                for field in ("contexts", "physical_costs", "conditional_mean_costs")
            }
            for split in ("train", "validation", "test")
        }
        if job.get("physical128_revision"):
            record["data_hashes"] = loaded.provenance["physical128"]["array_hashes"]
            record["test_bank_opened"] = loaded.provenance["test_bank_opened"]
        record["benchmark_provenance"] = loaded.provenance
        val = selection_validation_split(loaded.dataset.validation, job)
        record["validation_protocol"] = {
            "costs": job.get("validation_costs", "conditional_mean"),
            "contexts_sha256": matched._hash_array(val.contexts),
            "selection_costs_sha256": matched._hash_array(val.conditional_mean_costs),
            "one_fixed_observed_cost_per_context": job.get("validation_costs") == "single_sample",
            "analytic_validation_requested": bool(job.get("analytic_validation")),
            "test_costs": "conditional_mean",
        }
        matched._seed(config["seeds"]["initialization"])
        fit = (
            core_fit
            if job["method"].startswith("central_path_")
            or job["method"] in ("mse", "spo_plus", "wise", "intopt_original")
            or job["method"] in DIRECT_METHODS
            else baseline_fit
        )
        if job.get("simplified_revision"):
            fit = core_fit if job.get("base_method") == "central_path_hard_validation" else baseline_fit
        if job.get("stage") == "reevaluation":
            from physical128_evaluation import evaluate_frozen
            summary, curve = evaluate_frozen(job, loaded, attempt, update, training_started)
        else:
            summary, curve = fit(job, loaded, attempt, update, training_started,
                timing_only=job.get("stage") == "timing",
                **({"operational_io": update} if scoped_io and fit is core_fit else {}))
        record.update(
            status="complete",
            summary=summary,
            curve=curve,
            test_access=job["stage"] in ("confirmation", "reevaluation"),
        )
        if job.get("simplified_revision") and summary.get("optimization_cap_reached"):
            record.update(status="censored", error="measured_training_budget_exhausted",
                          test_access=False, training_time_lower_bound_seconds=summary['optimization_wall_seconds'])
        if job.get("pilot_revision"):
            record["test_bank_opened"] = job["stage"] == "confirmation"
    except Exception as exc:
        record.update(
            status="censored" if isinstance(exc, TimeoutError) else "failed",
            error_type=type(exc).__name__,
            error=str(exc),
            traceback=traceback.format_exc(),
        )
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        if scoped_io:
            finalize_operational_io(record, update)
        if (job.get("pilot_revision") or job.get("simplified_revision")) and (attempt / "TEST_ACCESS.json").exists():
            record["test_access"] = True
            record["test_bank_opened"] = True
            record["test_access_receipt_sha256"] = hashlib.sha256((attempt / "TEST_ACCESS.json").read_bytes()).hexdigest()
        usage = resource.getrusage(resource.RUSAGE_SELF)
        children = resource.getrusage(resource.RUSAGE_CHILDREN)
        record["resource_usage"] = {
            "process_cpu_seconds": usage.ru_utime + usage.ru_stime,
            "child_cpu_seconds": children.ru_utime + children.ru_stime,
            "peak_process_resident_bytes": int(
                usage.ru_maxrss * (1 if platform.system() == "Darwin" else 1024)
            ),
        }
        record["total_wall_seconds"] = time.perf_counter() - started
        record["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        write(out, record)
        write(progress, record)
    print(
        json.dumps(
            {
                "job": job["id"],
                "status": record["status"],
                "seconds": record["total_wall_seconds"],
            }
        )
    )
    if record["status"] != "complete":
        raise SystemExit(2)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--job-index", type=int, required=True)
    p.add_argument("--output-root", type=Path, required=True)
    p.add_argument("--smoke", action="store_true")
    run(p.parse_args())
