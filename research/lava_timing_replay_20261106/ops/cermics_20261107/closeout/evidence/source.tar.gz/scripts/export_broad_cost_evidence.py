"""Freeze selected broad-cost receipts and curves in a compact archive."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import tarfile
from pathlib import Path
from typing import Any, BinaryIO

from proximal_spo.artifacts import write_json

REQUIRED_FILES = {
    "config.json",
    "data_diagnostics.json",
    "environment.json",
    "learning_curve.jsonl",
    "prediction_diagnostics.json",
    "status.json",
    "summary.json",
}
OPTIONAL_FILES = {"embedded_mse_base.json"}
BASE_PRETRAIN_FILES = {
    "config.json",
    "environment.json",
    "learning_curve.jsonl",
    "status.json",
    "summary.json",
}


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected a JSON object at {path}")
    return payload


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _normalized_info(path: Path, archive_name: str) -> tarfile.TarInfo:
    info = tarfile.TarInfo(archive_name)
    info.size = path.stat().st_size
    info.mode = 0o644
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    info.mtime = 0
    return info


def _add_file(
    archive: tarfile.TarFile,
    path: Path,
    archive_name: str,
) -> None:
    info = _normalized_info(path, archive_name)
    with path.open("rb") as stream:
        archive.addfile(info, stream)


def _selection_rows(path: Path) -> list[dict[str, Any]]:
    payload = _object(path)
    rows = payload.get("selected")
    if not isinstance(rows, list) or not all(isinstance(row, dict) for row in rows):
        raise ValueError(f"selection lacks selected rows: {path}")
    return rows


def _safe_files(directory: Path) -> list[Path]:
    files = sorted(path for path in directory.iterdir() if path.is_file())
    names = {path.name for path in files}
    missing = REQUIRED_FILES - names
    unexpected = names - REQUIRED_FILES - OPTIONAL_FILES
    if missing or unexpected:
        raise ValueError(
            f"unsafe receipt set below {directory}: "
            f"missing={sorted(missing)}, unexpected={sorted(unexpected)}"
        )
    subdirectories = sorted(path for path in directory.iterdir() if path.is_dir())
    if {path.name for path in subdirectories} - {"base_pretrain"}:
        raise ValueError(f"unexpected receipt subtree below {directory}")
    base_directory = directory / "base_pretrain"
    if base_directory.is_dir():
        base_files = sorted(path for path in base_directory.iterdir() if path.is_file())
        base_names = {path.name for path in base_files}
        nested_directories = [
            path for path in base_directory.iterdir() if path.is_dir()
        ]
        if base_names != BASE_PRETRAIN_FILES or nested_directories:
            raise ValueError(f"unsafe base-pretrain receipts below {base_directory}")
        files.extend(base_files)
    return files


def _open_deterministic_tar(archive_path: Path) -> tuple[BinaryIO, gzip.GzipFile]:
    raw = archive_path.open("wb")
    compressed = gzip.GzipFile(
        filename="",
        mode="wb",
        compresslevel=9,
        fileobj=raw,
        mtime=0,
    )
    return raw, compressed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("confirmation_report", type=Path)
    parser.add_argument("confirmation_campaign", type=Path)
    parser.add_argument(
        "--development-selection",
        type=Path,
        action="append",
        default=[],
    )
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    arguments = parser.parse_args()
    if arguments.archive.exists() or arguments.manifest.exists():
        raise FileExistsError("archive and manifest destinations must be new")

    confirmation = _object(arguments.confirmation_report)
    campaign = _object(arguments.confirmation_campaign)
    confirmation_rows = confirmation.get("rows")
    variants = campaign.get("variants")
    if not isinstance(confirmation_rows, list) or not isinstance(variants, list):
        raise ValueError("confirmation report or campaign is malformed")
    planned_names = {str(variant.get("name")) for variant in variants}
    # Directory names append hashes, so exact plan matching is verified through
    # the archived config files below rather than through this prefix receipt.
    if len(confirmation_rows) != len(variants) or len(planned_names) != len(variants):
        raise ValueError("confirmation row count differs from the frozen campaign")
    if confirmation.get("source_sha256") != arguments.source_sha256:
        raise ValueError("confirmation report has the wrong source digest")

    rows = [row for row in confirmation_rows if isinstance(row, dict)]
    for selection_path in arguments.development_selection:
        selection = _object(selection_path)
        if selection.get("source_sha256") != arguments.source_sha256:
            raise ValueError(f"development source mismatch: {selection_path}")
        rows.extend(_selection_rows(selection_path))

    project_root = Path.cwd().resolve()
    run_directories: dict[Path, dict[str, Any]] = {}
    confirmation_config_names: set[str] = set()
    for row in rows:
        directory = Path(str(row["run_directory"])).resolve()
        if not directory.is_relative_to(project_root / "runs" / "broad_cost"):
            raise ValueError(f"receipt escapes broad-cost run root: {directory}")
        environment = _object(directory / "environment.json")
        status = _object(directory / "status.json")
        config = _object(directory / "config.json")
        if environment.get("source_sha256") != arguments.source_sha256:
            raise ValueError(f"source mismatch below {directory}")
        if status.get("status") != "complete":
            raise ValueError(f"non-complete run below {directory}")
        if directory.parent.name == "confirmation":
            confirmation_config_names.add(str(config.get("name")))
        run_directories[directory] = row
    if confirmation_config_names != planned_names:
        raise ValueError("confirmation configs do not match the frozen plan")

    records: list[dict[str, Any]] = []
    arguments.archive.parent.mkdir(parents=True, exist_ok=True)
    arguments.manifest.parent.mkdir(parents=True, exist_ok=True)
    raw, compressed = _open_deterministic_tar(arguments.archive)
    try:
        with tarfile.open(
            fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT
        ) as tar:
            for directory in sorted(run_directories):
                relative_directory = directory.relative_to(project_root)
                for path in _safe_files(directory):
                    relative = relative_directory / path.relative_to(directory)
                    archive_name = str(relative)
                    _add_file(tar, path, archive_name)
                    records.append(
                        {
                            "path": archive_name,
                            "bytes": path.stat().st_size,
                            "sha256": _sha256(path),
                        }
                    )
    finally:
        compressed.close()
        raw.close()

    write_json(
        arguments.manifest,
        {
            "kind": "broad_cost_compact_evidence_snapshot",
            "source_sha256": arguments.source_sha256,
            "confirmation_campaign": str(arguments.confirmation_campaign),
            "confirmation_campaign_sha256": _sha256(
                arguments.confirmation_campaign
            ),
            "confirmation_report": str(arguments.confirmation_report),
            "confirmation_report_sha256": _sha256(arguments.confirmation_report),
            "development_selections": [
                {
                    "path": str(path),
                    "sha256": _sha256(path),
                }
                for path in arguments.development_selection
            ],
            "run_directory_count": len(run_directories),
            "file_count": len(records),
            "uncompressed_bytes": sum(int(record["bytes"]) for record in records),
            "archive": str(arguments.archive),
            "archive_bytes": arguments.archive.stat().st_size,
            "archive_sha256": _sha256(arguments.archive),
            "raw_data_or_model_weights_included": False,
            "included_file_names": sorted(REQUIRED_FILES | OPTIONAL_FILES),
            "included_base_pretrain_file_names": sorted(BASE_PRETRAIN_FILES),
            "files": records,
        },
    )
    print(
        f"archived {len(run_directories)} runs and {len(records)} files "
        f"into {arguments.archive} ({arguments.archive.stat().st_size} bytes)"
    )


if __name__ == "__main__":
    main()
