"""Build the pair-only neural cost-correction campaign."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import source_sha256, write_json
from proximal_spo.config import RunSpec

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPO_ROOT / "configs" / "prediction_correction"
SOFT_SELECTION = (
    REPO_ROOT / "results" / "soft_radial_log_barrier" / "hard_boundary.json"
)
BASELINE_SELECTION = REPO_ROOT / "results" / "broad_cost" / "core_selection.json"
SEEDS = (1, 2, 3)


def _tag(benchmark_id: str) -> str:
    return benchmark_id.split(".", 1)[1].replace("_relaxation", "").replace(".", "_")


def _seed_payload(seed: int) -> dict[str, int]:
    return {
        "data": seed,
        "structural": 101,
        "initialization": 200 + seed,
        "shuffle": 300 + seed,
        "perturbation": 400 + seed,
    }


def _inputs() -> tuple[dict[str, dict[str, Any]], dict[str, float]]:
    soft_payload = json.loads(SOFT_SELECTION.read_text(encoding="utf-8"))
    soft: dict[str, dict[str, Any]] = {}
    for row in soft_payload["selected_arms"]:
        if row.get("selection_deployment") == "hard_recovered":
            soft[str(row["benchmark_id"])] = copy.deepcopy(row["arm"])
    baseline_payload = json.loads(BASELINE_SELECTION.read_text(encoding="utf-8"))
    mse_learning_rates: dict[str, float] = {}
    for row in baseline_payload["selected_arms"]:
        if row.get("method") == "mse":
            mse_learning_rates[str(row["benchmark_id"])] = float(
                row["arm"]["training"]["learning_rate"]
            )
    if len(soft) != 6 or set(soft) != set(mse_learning_rates):
        raise ValueError("expected matching six-benchmark Soft-Radial/MSE selections")
    return soft, mse_learning_rates


def _rows(*, smoke: bool) -> list[dict[str, Any]]:
    soft, mse_learning_rates = _inputs()
    seeds = (SEEDS[0],) if smoke else SEEDS
    rows: list[dict[str, Any]] = []
    for benchmark in sorted(soft):
        for seed in seeds:
            row = copy.deepcopy(soft[benchmark])
            row["name"] = f"{_tag(benchmark)}_s{seed}_neural_cost_correction"
            row["seeds"] = _seed_payload(seed)
            row["method_parameters"].update(
                {
                    "prediction_correction": True,
                    "prediction_correction_cone": True,
                    "prediction_correction_legacy": False,
                    "prediction_correction_neural": True,
                    "prediction_correction_minimum_scale": 1e-6,
                    "prediction_correction_ridges": [1e-5],
                    "prediction_correction_replay_audit_size": 8,
                    "prediction_correction_mse_learning_rate": (
                        mse_learning_rates[benchmark]
                    ),
                    "prediction_correction_mse_epochs": 120,
                    "prediction_correction_neural_learning_rates": [3e-4, 1e-3],
                    "prediction_correction_neural_epochs": 80,
                    "prediction_correction_neural_patience": 4,
                    "prediction_correction_neural_width": 64,
                    "prediction_correction_neural_depth": 2,
                }
            )
            if smoke:
                row["name"] += "_smoke"
                row["workers"] = 1
                row["sizes"] = {"train": 48, "validation": 24, "test": 24}
                row["model"].update({"width": 16, "depth": 1})
                row["training"].update(
                    {
                        "epochs": 2,
                        "batch_size": 24,
                        "patience": 2,
                        "validation_interval": 1,
                        "torch_threads": 1,
                    }
                )
                row["method_parameters"].update(
                    {
                        "prediction_correction_mse_epochs": 2,
                        "prediction_correction_neural_learning_rates": [1e-3],
                        "prediction_correction_neural_epochs": 2,
                        "prediction_correction_neural_patience": 1,
                        "prediction_correction_neural_width": 16,
                        "prediction_correction_neural_depth": 1,
                        "prediction_correction_replay_audit_size": 2,
                    }
                )
            RunSpec.from_dict(row)
            rows.append(row)
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "stage",
        choices=(
            "neural_smoke",
            "neural_development",
            "mu_normalized_development",
        ),
    )
    arguments = parser.parse_args()
    smoke = arguments.stage == "neural_smoke"
    rows = _rows(smoke=smoke)
    if arguments.stage == "mu_normalized_development":
        for row in rows:
            row["name"] = row["name"].replace(
                "neural_cost_correction", "mu_normalized_cost_correction"
            )
            row["method_parameters"].update(
                {
                    "prediction_correction_mu_normalize_directions": True,
                    "prediction_correction_include_projected_head": False,
                }
            )
            RunSpec.from_dict(row)
    path = CONFIG_ROOT / f"{arguments.stage}.json"
    write_json(
        path,
        {
            "name": arguments.stage,
            "run_root": f"runs/prediction_correction/{arguments.stage}",
            "base": {},
            "variants": rows,
            "source_sha256_at_generation": source_sha256(REPO_ROOT),
            "protocol": {
                "supervision": "context-scenario pairs only",
                "selection": "validation scenario MSE only",
                "excluded": "regression on projected scenario labels",
                "deployment": "uncorrected DFL cost; corrected cost is a sidecar",
                "conditional_means": "test diagnostics only",
            },
        },
    )
    print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
