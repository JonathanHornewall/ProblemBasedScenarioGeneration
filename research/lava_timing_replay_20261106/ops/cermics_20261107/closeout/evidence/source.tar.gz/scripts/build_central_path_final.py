"""Freeze the September 22 rerun inputs from the original Atlanta receipts.

Only configurations and seed bundles are read; historical scores never select
an arm. The continuous conditional-neighbourhood stage is deliberately absent.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import tempfile
from collections import defaultdict
from pathlib import Path

PATHS = tuple(f"dys_shortest_path_{n}x{n}" for n in (5, 10, 15, 20, 25))
LAVA = (
    "lava_random_lp_50x50_released_code",
    "lava_random_lp_100x25_released_code",
    "lava_random_lp_100x50_released_code",
    "lava_random_lp_100x100_released_code",
    "lava_random_lp_100x200_released_code",
    "lava_random_lp_150x50_paper_appendix",
    "lava_random_lp_200x50_released_code",
    "lava_random_lp_400x50_released_code",
)
INTEGER = tuple(f"dys_cfl_{n}" for n in ("50x5", "100x10", "200x10", "250x10")) + tuple(
    f"dys_knapsack_{n}x2" for n in (50, 100, 200, 500)
)
ROUTES = PATHS + LAVA + INTEGER
BASELINES = ("mse", "spo_plus", "wise")
DEFERRED_METHODS = ("pfyl", "nce", "cave", "lava")
METHODS = BASELINES + (
    "central_path_barrier_validation",
    "central_path_hard_validation",
)
SCREEN_STAGES = (
    "publication_continuous_sentinels",
    "publication_continuous_remaining",
    "publication_integer_practical",
)


def read(path):
    return json.loads(Path(path).read_text())


def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w",dir=path.parent,
            prefix="."+path.name+".",suffix=".tmp",delete=False) as stream:
        tmp=Path(stream.name)
        try:
            stream.write(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+"\n")
        except BaseException:
            tmp.unlink(missing_ok=True)
            raise
    try:
        tmp.replace(path)
    finally:
        tmp.unlink(missing_ok=True)


def setting(config):
    c = copy.deepcopy(config)
    for key in ("name", "workers", "evaluate_test", "seeds"):
        c.pop(key, None)
    t = c["training"]
    for key, default in (
        ("learning_rate_schedule", "constant"),
        ("minimum_learning_rate_ratio", 0.1),
        ("warmup_fraction", 0.0),
    ):
        t.setdefault(key, default)
    return sha(c)


def baseline_parameters(route, method):
    if method == "cave":
        return {
            "loss_type": "inner_cave" if "knapsack" in route else "exact_cave",
            "solver": "nnls" if "shortest_path" in route else "clarabel",
        }
    if method == "lava":
        return {"threshold": -0.1, "vertex_tolerance": 0.0}
    if method == "pfyl":
        return {"sigma": 0.1 if "random_lp" in route else 1.0, "n_samples": 1}
    if method == "nce":
        return {"solve_ratio": 0.05}
    return {}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--archive", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--training-cap-seconds", type=float, default=3600.0)
    a = p.parse_args()
    old = defaultdict(dict)
    sources = {}
    for stage in SCREEN_STAGES:
        for path in sorted((a.archive / stage).glob("*/config.json")):
            c = read(path)
            if c["benchmark_id"] not in ROUTES:
                continue
            if c["method"] not in (
                "mse",
                "spo_plus",
                "spo_plus_relaxation",
                "soft_radial_log_barrier",
            ):
                continue
            if c["evaluate_test"]:
                raise ValueError(f"screen unexpectedly enables test: {path}")
            key = (
                c["benchmark_id"],
                c["method"].replace("spo_plus_relaxation", "spo_plus"),
            )
            old[key].setdefault(setting(c), c)
            sources[str(path.resolve())] = hashlib.sha256(path.read_bytes()).hexdigest()
    confirmation = defaultdict(dict)
    for name in ("continuous_confirmation.json", "integer_confirmation.json"):
        path = a.archive / "configs" / name
        manifest = read(path)
        sources[str(path.resolve())] = hashlib.sha256(path.read_bytes()).hexdigest()
        for c in manifest["variants"]:
            if c["benchmark_id"] in ROUTES:
                confirmation[c["benchmark_id"]][c["seeds"]["data"]] = {
                    "seeds": c["seeds"],
                    "sizes": c["sizes"],
                }
    refinement = defaultdict(dict)
    for stage in (
        "publication_continuous_refinement",
        "publication_integer_refinement_original",
    ):
        for path in sorted((a.archive / stage).glob("*/config.json")):
            c = read(path)
            if c["benchmark_id"] in ROUTES:
                refinement[c["benchmark_id"]][c["seeds"]["data"]] = c["seeds"]
    cells, jobs = {}, []
    for route in ROUTES:
        conf = [confirmation[route][k] for k in sorted(confirmation[route])]
        seeds = [refinement[route][k] for k in sorted(refinement[route])]
        if len(conf) != 10 or len(seeds) != 3:
            raise ValueError(
                f"missing original seeds: {route}: {len(conf)}/{len(seeds)}"
            )
        sizes = conf[0]["sizes"]
        if any(x["sizes"] != sizes for x in conf):
            raise ValueError(f"inconsistent original split sizes: {route}")
        for n in (sizes["train"], 100) if route in PATHS + LAVA else (100,):
            cell = f"{route}__train{n}"
            cells[cell] = {
                "route": route,
                "train_size": n,
                "original_sizes": sizes,
                "confirmation_seeds": [x["seeds"] for x in conf],
                "refinement_seeds": seeds,
            }
            for method in METHODS:
                source_method = (
                    "soft_radial_log_barrier"
                    if method.startswith("central_path_")
                    else (method if method in ("mse", "spo_plus") else "mse")
                )
                configs = list(old[(route, source_method)].values())
                if not configs:
                    raise ValueError(f"no original screen: {route}/{source_method}")
                parameters = baseline_parameters(route, method)
                proposals = [(c, parameters) for c in configs]
                # New losses retain their released parameters and receive the
                # archived common optimizer/capacity search. No extra LP search.
                seen = set()
                for original, params in proposals:
                    c = copy.deepcopy(original)
                    c["workers"] = 1
                    c["evaluate_test"] = False
                    c["sizes"] = {**sizes, "train": n}
                    # Preserve held-out streams; shrink by prefix or regenerate
                    # an expanded training stream with the original data seed.
                    c["training"]["batch_size"] = min(n, c["training"]["batch_size"])
                    c["training"]["torch_threads"] = 1
                    c["training"]["maximum_optimization_seconds"] = (
                        a.training_cap_seconds
                    )
                    c["training"]["selection_mode"] = "validation_regret"
                    c["method_parameters"] = {
                        k: v
                        for k, v in c["method_parameters"].items()
                        if not k.startswith("prediction_correction")
                    }
                    identity = sha(
                        {"config": setting(c), "parameters": params, "method": method}
                    )[:16]
                    if identity in seen:
                        continue
                    seen.add(identity)
                    jobs.append(
                        {
                            "id": f"screen__{cell}__{method}__{identity}",
                            "stage": "screen",
                            "cell": cell,
                            "route": route,
                            "method": method,
                            "candidate": identity,
                            "repeat": 0,
                            "config": c,
                            "parameters": params,
                            "original_sizes": sizes,
                            "source_screen_name": original["name"],
                        }
                    )
    # Interleave cells and methods, so geometry-heavy families cannot block
    # all of the inexpensive fits at the head of a Slurm array.
    counts = defaultdict(int)
    for job in jobs:
        key = (job["cell"], job["method"])
        job["arm_order"] = counts[key]
        counts[key] += 1
    jobs.sort(key=lambda j: (j["arm_order"], j["cell"], j["method"]))
    payload = {
        "schema": "central_path_final_v2",
        "cells": cells,
        "methods": METHODS,
        "jobs": jobs,
        "source_sha256": sources,
        "protocol": {
            "extra_continuous_conditional_tuning": False,
            "original_seed_bundles_preserved": True,
            "revision": "core_methods_train100_20260922",
            "per_cell_method_pipeline": True,
            "deferred_methods": DEFERRED_METHODS,
            "integer_training_examples": 100,
            "training_resize": (
                "original-size prefix when shrinking; "
                "same-seed training regeneration when expanding"
            ),
            "original_validation_test_streams_preserved": True,
            "screen": "archived broad candidates without conditional neighbourhoods",
            "new_baselines": "WISE with archived MSE optimizer/capacity grid",
            "refinement": (
                "top three eligible candidates, original three paired seed bundles"
            ),
            "confirmation": (
                "frozen candidate/horizon, original ten paired seed bundles"
            ),
            "barrier_selection": (
                "fixed endpoint mu; within-mu barrier cost, cross-mu hard regret"
            ),
            "hard_selection": "original conditional-mean LP/MIP regret",
            "training_cap_seconds": a.training_cap_seconds,
            "preprocessing_cap_seconds": 3600,
            "job_wall_cap_seconds": 9000,
            "test_access": "confirmation only",
        },
    }
    if len(cells) != 34:
        raise ValueError(f"expected 34 benchmark/data cells; got {len(cells)}")
    write(a.output, payload)
    print(
        json.dumps(
            {
                "cells": len(cells),
                "screen_fits": len(jobs),
                "methods": len(METHODS),
                "manifest": str(a.output),
            }
        )
    )


if __name__ == "__main__":
    main()
