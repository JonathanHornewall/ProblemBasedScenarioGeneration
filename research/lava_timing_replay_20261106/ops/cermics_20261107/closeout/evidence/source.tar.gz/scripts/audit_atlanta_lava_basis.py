#!/usr/bin/env python3
"""Measure public LAVA's sensitivity to the solver's starting simplex basis."""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import gurobipy as gp
import highspy
import numpy as np
import run_public_solver_free_matched as matched
import torch
from dfl_extensions_lab.benchmarks import SplitSizes
from run_atlanta_baseline_timing import digest, write

from proximal_spo.external_benchmarks import load_external_benchmark
from proximal_spo.public_highs import HighsLAVADataset, coalesce_vertices


def vertex_keys(vertices):
    # Integer quantization also normalizes signed zero. Diagnostic only: never
    # replace or deduplicate the vertices actually supplied to the public loss.
    return {v.tobytes() for v in np.rint(vertices * 1e7).astype(np.int64)}


def loss_gradient(model, vertices, anchor, cost):
    from methods.lava import LAVA

    prediction = torch.tensor(-cost[None], requires_grad=True)
    loss = LAVA(model, threshold=-0.1)(
        prediction,
        torch.tensor(vertices[None]),
        torch.tensor(anchor[None]),
        -1.0,
    )
    loss.backward()
    return float(loss.detach()), prediction.grad.numpy()[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--route-index", type=int, default=1)
    parser.add_argument("--trace-cap", action="store_true")
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    entries = {}
    for job in json.loads(args.manifest.read_text())["jobs"]:
        entries.setdefault(job["entry"]["route_id"], job["entry"])
    entry = list(entries.values())[args.route_index]
    loaded = load_external_benchmark(
        entry["benchmark_id"],
        SplitSizes(1, 1, 1),
        data_seed=entry["seeds"]["data"],
        conditional_reference_samples=entry["conditional_reference_samples"],
    )
    problem = loaded.problem.continuous_relaxation()
    cost = loaded.dataset.train.physical_costs[0]
    features = loaded.dataset.train.contexts
    report = {
        "kind": "public_lava_native_basis_diagnostic",
        "route": entry["route_id"],
        "one_generated_sample_full_model_dimensions": True,
        "not_full_training": True,
        "highs_version": highspy.Highs().version(),
        "gurobi_version": list(gp.gurobi.version()),
        "threads": 1,
        "cost_sha256": matched._hash_array(cost),
        "script_sha256": digest(Path(__file__)),
        "highs_adapter_sha256": digest(
            matched.PROJECT_ROOT / "src/proximal_spo/public_highs.py"
        ),
        "timings_include_python_profile_overhead": args.trace_cap,
        "results": {},
    }
    write(args.output, report)
    # The public constructor creates a second model with unrestricted threads.
    # Apply the same single-thread resource convention to that reference model.
    import data.dataset_augmented as public_dataset

    original_slack = public_dataset.convert_to_slack_form

    def threaded_slack(model):
        slack = original_slack(model)
        slack.Params.Threads = 1
        return slack

    public_dataset.convert_to_slack_form = threaded_slack
    datasets, gradients, arrays = {}, {}, {}
    for backend in ("gurobi", "highs"):
        calls = []

        def profile(frame, event, _arg, calls=calls):
            if (
                event == "return"
                and frame.f_code.co_name == "get_adjacent_vertices_degenerate_case"
            ):
                local = frame.f_locals
                calls.append(
                    {
                        "iteration": local.get("iteration"),
                        "remaining_queue": len(local.get("queue", [])),
                        "visited_bases": len(local.get("visited_bases", [])),
                        "tnp": local.get("use_tnp_rule"),
                    }
                )

        model = matched._fixed_model(problem, integer=False, backend=backend)
        start = time.perf_counter()
        if args.trace_cap:
            sys.setprofile(profile)
        try:
            if backend == "highs":
                dataset = HighsLAVADataset(
                    model, features, cost[None], public_repo=matched.PUBLIC_REPO
                )
            else:
                dataset = matched._make_robust_dataset_class(backend="gurobi")(
                    model, features, cost[None]
                )
        finally:
            sys.setprofile(None)
        seconds = time.perf_counter() - start
        vertices, anchor = dataset.adjacent_verts[0], dataset.relaxed_sols[0]
        value, gradient = loss_gradient(model, vertices, anchor, cost)
        report["results"][backend] = {
            "dataset_wall_seconds": seconds,
            "includes_public_half_second_sleep": backend == "gurobi",
            "raw_neighbour_rows": len(vertices),
            "unique_at_1e7_grid": len(vertex_keys(vertices)),
            "float64_vertex_storage_bytes": vertices.nbytes,
            "loss_at_negative_true_cost": value,
            "tnp_assertion_retries": dataset.adjacency_tnp_retry_count,
            "enumeration_return_states": calls,
        }
        datasets[backend], gradients[backend] = dataset, gradient
        arrays[backend + "_vertices"] = vertices
        arrays[backend + "_anchor"] = anchor
        arrays[backend + "_gradient"] = gradient
        write(args.output, report)
    high, grb = datasets["highs"], datasets["gurobi"]
    report.update(
        maximum_anchor_difference=float(np.max(np.abs(high.sols - grb.sols))),
        shared_quantized_vertices=len(
            vertex_keys(high.adjacent_verts[0]) & vertex_keys(grb.adjacent_verts[0])
        ),
        maximum_gradient_difference=float(
            np.max(np.abs(gradients["highs"] - gradients["gurobi"]))
        ),
        native_backend_loss_parity=bool(
            np.allclose(gradients["highs"], gradients["gurobi"], atol=1e-7, rtol=1e-7)
        ),
    )
    report["numerical_duplicate_repair_diagnostics"] = []
    for tolerance in (1e-6, 1e-7, 1e-8):
        outcomes = []
        diagnostic = {"tolerance": tolerance}
        for backend, dataset in datasets.items():
            vertices = coalesce_vertices(
                dataset.adjacent_verts[0], dataset.relaxed_sols[0], tolerance
            )
            value, gradient = loss_gradient(
                dataset.model, vertices, dataset.relaxed_sols[0], cost
            )
            diagnostic[backend] = {"neighbours": len(vertices), "loss": value}
            outcomes.append((value, gradient))
        diagnostic["maximum_gradient_difference"] = float(
            np.max(np.abs(outcomes[0][1] - outcomes[1][1]))
        )
        report["numerical_duplicate_repair_diagnostics"].append(diagnostic)
    # An independent solver verifies that HiGHS's structural basis represents
    # the same feasible vertex. A zero objective makes every feasible basis
    # optimal, so this checks basis validity without another pivot selection.
    slack_solution = np.array(high.slack_model._model.getSolution().col_value)
    matrix, basic, _ = high._basis(slack_solution)
    if matrix.shape[0] == high.slack_problem.constraint_count:
        control = matched._fixed_model(
            high.slack_problem, integer=False, backend="gurobi"
        )
        control._model.Params.Presolve = 0
        control._model.Params.Method = 0
        control.setObj(np.zeros(high.slack_problem.variable_count))
        control._model.update()
        statuses = np.full(high.slack_problem.variable_count, -1)
        statuses[basic] = 0
        control._model.setAttr("VBasis", control._model.getVars(), statuses.tolist())
        control._model.setAttr(
            "CBasis", control._model.getConstrs(), [-1] * matrix.shape[0]
        )
        solution, _ = control.solve()
        report["structural_basis_control"] = {
            "gurobi_pivots": control._model.IterCount,
            "maximum_solution_difference": float(
                np.max(np.abs(solution - slack_solution))
            ),
            "basis_retained": bool(
                np.array_equal(control._model.getAttr("VBasis"), statuses)
            ),
        }
    np.savez_compressed(args.output.with_suffix(".npz"), cost=cost, **arrays)
    report["arrays_sha256"] = digest(args.output.with_suffix(".npz"))
    write(args.output, report)
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
