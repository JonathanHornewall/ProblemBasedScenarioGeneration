"""Profile persistent LP/QP batches without launching neural training."""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np
from scipy.sparse import csc_matrix

from proximal_spo.artifacts import environment_receipt, write_json
from proximal_spo.benchmarks import build_benchmark
from proximal_spo.oracles import make_lp_oracle, make_qp_oracle
from proximal_spo.seeds import rng


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=512)
    arguments = parser.parse_args()
    if arguments.samples <= 0:
        raise ValueError("samples must be positive")
    repo_root = Path(__file__).resolve().parents[1]
    rows: list[dict[str, object]] = []
    for benchmark_id in (
        "cost.grid5",
        "cost.knapsack20x5",
        "cost.random_lp60x30",
    ):
        problem = build_benchmark(benchmark_id, structural_seed=101)
        random = rng(991, "oracle_profile", benchmark_id)
        objectives = random.normal(size=(arguments.samples, problem.variable_count))
        selected = max(1, problem.variable_count // 4)
        diagonal = np.zeros(problem.variable_count)
        diagonal[:selected] = 0.1
        quadratic = csc_matrix(np.diag(diagonal))
        for workers in (1, 2, 4, 8):
            for oracle_name in ("lp", "low_rank_qp"):
                started = time.perf_counter()
                if oracle_name == "lp":
                    lp_oracle = make_lp_oracle(
                        problem, workers=workers, random_seed=101
                    )
                    with lp_oracle:
                        solutions = lp_oracle.solve_many(objectives)
                else:
                    qp_oracle = make_qp_oracle(problem, quadratic, workers=workers)
                    with qp_oracle:
                        solutions = qp_oracle.solve_many(objectives)
                outer_wall = time.perf_counter() - started
                rows.append(
                    {
                        "benchmark_id": benchmark_id,
                        "variables": problem.variable_count,
                        "constraints": problem.constraint_count,
                        "oracle": oracle_name,
                        "workers": workers,
                        "samples": arguments.samples,
                        "outer_wall_seconds": outer_wall,
                        "solves_per_second": arguments.samples / outer_wall,
                        "stats": solutions.stats,
                    }
                )
                print(
                    f"{benchmark_id:24s} {oracle_name:12s} workers={workers} "
                    f"rate={arguments.samples / outer_wall:8.1f}/s "
                    f"retries={solutions.stats.retries}",
                    flush=True,
                )
    write_json(
        arguments.output,
        {
            "kind": "oracle_profile",
            "raw_objectives_persisted": False,
            "environment": environment_receipt(repo_root),
            "rows": rows,
        },
    )


if __name__ == "__main__":
    main()
