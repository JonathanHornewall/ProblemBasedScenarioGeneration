"""Single source of truth for the mollified PyEPO campaign design."""

from __future__ import annotations

from typing import Any

DEVELOPMENT_SEEDS = (1, 2, 3)
CONFIRMATION_SEEDS = tuple(range(11, 21))
SCREEN_SIGMAS = (0.0, 0.05, 0.1, 0.25, 0.5, 1.0)
INITIAL_TAU = 3.0
REFINEMENT_TAUS = (0.1, 0.3, 1.0, INITIAL_TAU, 10.0)
REFINEMENT_RATES = (0.0003, 0.001, 0.003, 0.01)


def _tag(value: float) -> str:
    if value == 0.0:
        return "0"
    return f"{value:.0e}".replace("-", "m").replace("+", "p")


def _seeds(data_seed: int) -> dict[str, int]:
    return {
        "data": data_seed,
        "structural": 101,
        "initialization": 200 + data_seed,
        "shuffle": 300 + data_seed,
        "perturbation": 400 + data_seed,
    }


def _base(data_seed: int) -> dict[str, Any]:
    return {
        "name": "base",
        "benchmark_id": "cost.grid5",
        "method": "mollified_anchored_proximal",
        "interface": "full",
        "workers": 4,
        "sizes": {"train": 1024, "validation": 256, "test": 512},
        "law": {
            "context_dimension": 5,
            "random_fraction": 1.0,
            "style": "positive",
            "noise": "pyepo_uniform",
            "noise_scale": 0.5,
            "signal_scale": 1.0,
            "polynomial_degree": 6,
        },
        "model": {
            "depth": 2,
            "width": 64,
            "activation": "silu",
            "layer_norm": False,
            "correction_depth": 2,
            "correction_width": 64,
        },
        "training": {
            "epochs": 200,
            "batch_size": 128,
            "learning_rate": 0.003,
            "weight_decay": 0.00001,
            "optimizer": "adamw",
            "gradient_clip": 10.0,
            "validation_interval": 5,
            "patience": 20,
            "minimum_delta": 0.00001,
            "evaluation_batch_size": 512,
            "torch_threads": 4,
            "selection_mode": "validation_regret",
        },
        "seeds": _seeds(data_seed),
        "method_parameters": {
            "tau": INITIAL_TAU,
            "sigma": 0.0,
            "training_samples": 8,
            "evaluation_samples": 64,
            "base_epochs": 200,
            "base_learning_rate": 0.001,
            "base_batch_size": 128,
        },
    }


def _variant(
    *,
    seed: int,
    sigma: float,
    tau: float,
    learning_rate: float,
    training_samples: int = 8,
    batch_size: int = 128,
    epochs: int = 200,
    validation_interval: int = 5,
    prefix: str,
) -> dict[str, Any]:
    return {
        "name": (
            f"{prefix}_s{seed}_sig{_tag(sigma)}_tau{_tag(tau)}_"
            f"lr{_tag(learning_rate)}_k{training_samples}_b{batch_size}"
        ),
        "seeds": _seeds(seed),
        "training": {
            "epochs": epochs,
            "batch_size": batch_size,
            "learning_rate": learning_rate,
            "validation_interval": validation_interval,
        },
        "method_parameters": {
            "tau": tau,
            "sigma": sigma,
            "training_samples": training_samples,
            "evaluation_samples": 64,
            "base_epochs": 200,
            "base_learning_rate": 0.001,
            "base_batch_size": 128,
        },
    }


def _neighbor_sigmas(best: float) -> tuple[float, ...]:
    positive = list(SCREEN_SIGMAS[1:])
    if best not in positive:
        raise ValueError("best positive sigma is outside the declared screen")
    index = positive.index(best)
    start = max(0, index - 1)
    stop = min(len(positive), index + 2)
    return tuple(positive[start:stop])
