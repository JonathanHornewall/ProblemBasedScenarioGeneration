"""Durable 30-core base plus 70-core burst, with an absolute 12-hour cutoff."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from build_central_path_final import read, write
from central_path_slurm import environment


def main(root):
    from canonical_cluster import setup
    assert int(os.environ['SLURM_CPUS_PER_TASK'])==30
    assert read(root/'preflight/VERIFICATION.json')['status']=='complete'
    assert read(root/'INPUT_TRANSFER_VERIFICATION.json')['status']=='complete'
    setup(root)
    state=read(root/'burst_state.json')
    cutoff=state['started_unix']+12*3600
    schedule={'base_job':os.environ['SLURM_JOB_ID'],'base_cpus':30,'burst_cpus':70,
              'start_unix':state['started_unix'],'downscale_unix':cutoff,
              'maximum_before':100,'maximum_after':30,'status':'starting'}
    write(root/'RESOURCE_SCHEDULE.json',schedule)
    submitted=subprocess.run(['sbatch','--parsable',str(root/'launch_burst.sbatch')],text=True,capture_output=True,check=True)
    burst_id=submitted.stdout.strip().split(';')[0]
    assert burst_id.isdigit()
    schedule.update(burst_job=burst_id,status='running')
    write(root/'RESOURCE_SCHEDULE.json',schedule)
    env=environment(root);py=str(root/'venv/bin/python');code=root/'code/scripts'
    coordinator=None;pool=None;cancelled=False;stopping=False
    def stop(*unused):
        nonlocal stopping
        stopping=True
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        with (root/'logs/coordinator.log').open('a') as log:
            coordinator=subprocess.Popen([py,str(code/'canonical_cluster.py'),'coordinate','--root',str(root)],env=env,stdout=log,stderr=subprocess.STDOUT)
            pool=subprocess.Popen([py,str(code/'canonical_worker_pool.py'),'--root',str(root),'--workers','30','--memory-gib','160'],env=env)
            while not stopping and time.time()<state['deadline_unix']-90:
                now=time.time()
                if now>=cutoff and not cancelled:
                    subprocess.run(['scancel',burst_id],check=False)
                    cancelled=True
                    schedule.update(status='downscaled_to_30',cancellation_requested_unix=now)
                    write(root/'RESOURCE_SCHEDULE.json',schedule)
                if coordinator.poll() is not None:
                    if coordinator.returncode:
                        raise RuntimeError('coordinator exited nonzero; see durable logs')
                    break
                if pool.poll() is not None:
                    raise RuntimeError('base worker supervisor exited before coordinator')
                time.sleep(1)
    finally:
        subprocess.run(['scancel',burst_id],check=False)
        for child in (pool,coordinator):
            if child and child.poll() is None:child.terminate()
        for child in (pool,coordinator):
            if child:
                try:child.wait(timeout=30)
                except subprocess.TimeoutExpired:child.kill();child.wait()
        schedule.update(base_driver_finished_unix=time.time(),burst_cancellation_requested=True)
        write(root/'RESOURCE_SCHEDULE.json',schedule)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True)
    main(p.parse_args().root.resolve())
