"""Isolated smoke fits for every loss setting, restored MDKP, and largest LP maps."""

import argparse
import concurrent.futures
import json
import os
import subprocess
import sys
from pathlib import Path

from build_central_path_extension import DIRECT_METHODS, DIRECT_ROUTES, MDKP
from build_central_path_final import read, write


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--output-root", type=Path, required=True)
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--cloud", action="store_true", help="small LP loss checks only")
    a = p.parse_args()
    jobs = read(a.manifest)["jobs"]
    selected = {}
    for i, job in enumerate(jobs):
        if job["route"] == "dys_shortest_path_5x5":
            selected.setdefault(
                (job["method"], json.dumps(job["parameters"], sort_keys=True)), i
            )
        elif not a.cloud and job["route"] == MDKP:
            selected.setdefault((MDKP, job["method"]), i)
        elif (
            not a.cloud
            and job["route"] in DIRECT_ROUTES
            and job["method"] in DIRECT_METHODS
        ):
            selected.setdefault((job["route"], job["method"]), i)
    a.output_root.mkdir(parents=True, exist_ok=True)

    def fit(index):
        job = jobs[index]
        with (a.output_root / (job["id"] + ".log")).open("w") as log:
            result = subprocess.run(
                [
                    sys.executable,
                    str(Path(__file__).with_name("run_central_path_final.py")),
                    "--manifest",
                    str(a.manifest),
                    "--job-index",
                    str(index),
                    "--output-root",
                    str(a.output_root),
                    "--smoke",
                ],
                env=os.environ,
                stdout=log,
                stderr=subprocess.STDOUT,
            )
        row = {"job": job["id"], "returncode": result.returncode}
        print(json.dumps(row), flush=True)
        return row

    with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as executor:
        results = list(executor.map(fit, selected.values()))
    write(
        a.output_root / "preflight.json",
        {
            "smoke_only": True,
            "fits": results,
            "passed": all(r["returncode"] == 0 for r in results),
        },
    )
    if any(r["returncode"] for r in results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
