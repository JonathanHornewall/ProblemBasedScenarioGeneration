#!/usr/bin/env python3
"""Launch the Atlanta SFGE/CaVE/LAVA campaign as an unattended pipeline.

The pipeline has three explicit, resumable stages:

* development: broad arm screens on three paired validation seeds;
* refinement: route/method-specific neighborhoods on three fresh paired
  validation seeds;
* confirmation: one frozen arm per route/method on all ten paired seeds, with
  exact test evaluation opened only in this final stage.

Every child writes an immutable JSON receipt.  A positive timeout is an
explicit ``runtime_gated`` receipt, never a fabricated score.  By default
children run until their requested arms finish; arm-level progress can be
harvested if a public process lingers only during interpreter cleanup.  The
public method code is loaded by ``run_atlanta_public_external_arm.py`` from
pinned source checkouts.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MANIFEST = ROOT / "configs/public_baselines/paper_solver_free_matched.json"
DEFAULT_OUTPUT = ROOT / "runs/atlanta_public_baselines_20260905_r1"
EXTERNAL_SRC = Path(
    os.environ.get("DFL_EXTENSIONS_SRC", "/private/tmp/dfl-gefcom57-campaign/src")
).resolve()
SOLVER_FREE_REPO = Path(
    os.environ.get("SOLVER_FREE_DFL_REPO", "/private/tmp/dfl-public-solver-free")
).resolve()
SFGE_REPO = Path(
    os.environ.get(
        "SFGE_PUBLIC_REPO",
        "/private/tmp/atlanta-public-baseline-sources/sfge-c62241ad8",
    )
).resolve()

ROUTES = (
    "dys_shortest_path_25x25",
    "dys_cfl_50x5",
    "dys_cfl_100x10",
    "dys_cfl_200x10",
    "dys_cfl_250x10",
    "dys_knapsack_50x2",
    "dys_knapsack_100x2",
    "dys_knapsack_200x2",
    "dys_knapsack_400x2",
    "dys_knapsack_500x2",
    "lava_random_lp_150x50_paper_appendix",
    "predictiveco_cubic_topk",
    "sfge_kp50_values_seed_0",
    "pyepo_mdkp32x2_degree_6_noise_0_5_seed_0",
)

# The matched manifest stores ten entries consecutively for each route.  The
# positions, rather than an assumption about the numerical seed itself, are
# recorded in every stage receipt and keep all methods paired.
DEV_POSITIONS = (0, 1, 2)
REFINE_POSITIONS = (3, 4, 5)
CONFIRM_POSITIONS = tuple(range(10))

# Public SFGE is a one-sample-per-observation score-function estimator and is
# materially more expensive than the solver-free losses.  A shorter screen and
# a longer refinement preserve a publication-sized final horizon without
# making the broad factorized screen needlessly dominant.  The final arm is
# always trained for the full matched horizon.
DEVELOPMENT_EPOCHS = 60
REFINEMENT_EPOCHS = 150
CONFIRMATION_EPOCHS = 300

ROUTE_PRIORITY = {route: index for index, route in enumerate(ROUTES)}
ROUTE_PRIORITY["dys_shortest_path_25x25"] = 99


def _load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _safe(value: str) -> str:
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in value)


def _canonical_arm(arm: dict[str, Any]) -> dict[str, Any]:
    """Drop run-dependent fields before using an arm as a selection key."""

    keep = {
        "name",
        "kind",
        "solver",
        "threshold",
        "sigma",
        "lr",
        "standardize_batch_values",
        "sce_loss",
        "learning_rate",
        "batch_size",
        "epochs",
        "weight_decay",
        "model",
    }
    return {key: arm[key] for key in sorted(arm) if key in keep}


def _arm_key(arm: dict[str, Any]) -> str:
    return json.dumps(_canonical_arm(arm), sort_keys=True, separators=(",", ":"))


def _entry_index_by_route_position(manifest: dict[str, Any]) -> dict[tuple[str, int], int]:
    positions: dict[str, int] = {route: 0 for route in ROUTES}
    result: dict[tuple[str, int], int] = {}
    for index, entry in enumerate(manifest["entries"]):
        route = str(entry["route_id"])
        if route not in positions:
            continue
        position = positions[route]
        result[(route, position)] = index
        positions[route] = position + 1
    missing = [
        (route, position)
        for route in ROUTES
        for position in CONFIRM_POSITIONS
        if (route, position) not in result
    ]
    if missing:
        raise RuntimeError(f"matched manifest is missing route/position entries: {missing[:5]}")
    return result


def _development_arms(method: str) -> list[dict[str, Any]]:
    if method == "cave":
        return [
            {
                "name": f"CaVE_{solver}_lr{rate:g}",
                "solver": solver,
                "learning_rate": rate,
                "epochs": DEVELOPMENT_EPOCHS,
                "validation_interval": 10,
            }
            for solver in ("nnls", "clarabel")
            for rate in (3e-4, 1e-3, 3e-3, 1e-2)
        ]
    if method == "lava":
        return [
            {
                "name": f"LAVA_t{threshold:g}_lr{rate:g}",
                "threshold": threshold,
                "learning_rate": rate,
                "epochs": DEVELOPMENT_EPOCHS,
                "validation_interval": 10,
            }
            for threshold in (-1.0, -0.3, -0.1, -0.03, 0.0, 0.03)
            for rate in (3e-4, 1e-3, 3e-3)
        ]
    if method == "sfge":
        # A factorized but deliberately broad screen: sigma and rate are
        # crossed, while the released standardization/SCE switches are probed
        # at a central point.  The refinement stage crosses those switches
        # around the selected neighborhood.
        arms = [
            {
                "name": f"SFGE_s{sigma:g}_lr{rate:g}_std1_sce0",
                "sigma": sigma,
                "lr": rate,
                "standardize_batch_values": True,
                "sce_loss": False,
                "epochs": DEVELOPMENT_EPOCHS,
            }
            for sigma in (0.03, 0.1, 0.3, 1.0, 3.0)
            for rate in (3e-4, 1e-3, 3e-3, 1e-2)
        ]
        arms.extend(
            {
                "name": f"SFGE_s{sigma:g}_lr0.001_std{int(std)}_sce{int(sce)}",
                "sigma": sigma,
                "lr": 1e-3,
                "standardize_batch_values": std,
                "sce_loss": sce,
                "epochs": DEVELOPMENT_EPOCHS,
            }
            for sigma in (0.1, 0.3, 1.0)
            for std in (False, True)
            for sce in (False, True)
        )
        return arms
    raise ValueError(method)


def _refinement_arms(method: str, selected: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Construct a bounded neighborhood around the development top three."""

    if not selected:
        return []
    if method == "cave":
        solvers = {str(arm.get("solver", "nnls")) for arm in selected}
        rates = {float(arm.get("learning_rate", 1e-3)) for arm in selected}
        ladder = (1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2)
        for rate in tuple(rates):
            if rate in ladder:
                index = ladder.index(rate)
                rates.update(ladder[max(0, index - 1) : min(len(ladder), index + 2)])
        return [
            {
                "name": f"CaVE_{solver}_lr{rate:g}",
                "solver": solver,
                "learning_rate": rate,
                "epochs": REFINEMENT_EPOCHS,
                "validation_interval": 10,
            }
            for solver in sorted(solvers)
            for rate in sorted(rates)
        ]
    if method == "lava":
        thresholds = {-1.0, -0.3, -0.1, -0.03, 0.0, 0.03}
        rates = {float(arm.get("learning_rate", 1e-3)) for arm in selected}
        rate_ladder = (3e-4, 1e-3, 3e-3, 1e-2, 3e-2)
        for rate in tuple(rates):
            if rate in rate_ladder:
                index = rate_ladder.index(rate)
                rates.update(
                    rate_ladder[max(0, index - 1) : min(len(rate_ladder), index + 2)]
                )
        # Include the full public threshold ladder; threshold is the central
        # LAVA hyperparameter and this is still only 30 arms per route.
        return [
            {
                "name": f"LAVA_t{threshold:g}_lr{rate:g}",
                "threshold": threshold,
                "learning_rate": rate,
                "epochs": REFINEMENT_EPOCHS,
                "validation_interval": 10,
            }
            for threshold in sorted(thresholds)
            for rate in sorted(rates)
        ]
    if method == "sfge":
        sigmas = {float(arm.get("sigma", 0.3)) for arm in selected}
        rates = {float(arm.get("lr", 1e-3)) for arm in selected}
        sigma_ladder = (0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0)
        rate_ladder = (1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2)
        for value in tuple(sigmas):
            if value in sigma_ladder:
                index = sigma_ladder.index(value)
                sigmas.update(
                    sigma_ladder[max(0, index - 1) : min(len(sigma_ladder), index + 2)]
                )
        for value in tuple(rates):
            if value in rate_ladder:
                index = rate_ladder.index(value)
                rates.update(
                    rate_ladder[max(0, index - 1) : min(len(rate_ladder), index + 2)]
                )
        # A complete switch cross at the selected sigma/rate neighborhood is
        # important because the public SCE and batch-standardization switches
        # change the estimator rather than merely its scale.
        return [
            {
                "name": f"SFGE_s{sigma:g}_lr{rate:g}_std{int(std)}_sce{int(sce)}",
                "sigma": sigma,
                "lr": rate,
                "standardize_batch_values": std,
                "sce_loss": sce,
                "epochs": REFINEMENT_EPOCHS,
            }
            for sigma in sorted(sigmas)
            for rate in sorted(rates)
            for std in (False, True)
            for sce in (False, True)
        ]
    raise ValueError(method)


def _confirmation_arm(method: str, arm: dict[str, Any]) -> dict[str, Any]:
    result = _canonical_arm(arm)
    # Keep a stable human-readable name even when the chosen row came from a
    # public receipt whose status fields have been removed.
    result["name"] = str(arm.get("name", f"{method}_selected"))
    result["epochs"] = CONFIRMATION_EPOCHS
    if method in {"cave", "lava"}:
        result["validation_interval"] = 30
    return result


def _terminal_receipt(path: Path) -> bool:
    try:
        value = _load(path)
    except (OSError, json.JSONDecodeError):
        return False
    status = str(value.get("status", ""))
    if status in {"complete", "runtime_gated"}:
        return True
    # A public hyperparameter arm can fail (for example, Clarabel can hit a
    # solver/runtime issue) while sibling arms in the same child are valid.
    # Keep the child terminal and preserve the successful rows instead of
    # repeatedly rerunning an already-audited failure.
    if status == "partial_failure" and any(
        isinstance(arm, dict) and arm.get("status") in {"complete", "trained"}
        for arm in value.get("arms", [])
    ):
        return True
    return False


def _selection_receipt_usable(receipt: dict[str, Any]) -> bool:
    status = str(receipt.get("status", ""))
    if receipt.get("test_access") is not False:
        return False
    if status == "complete":
        return True
    return status == "partial_failure" and any(
        isinstance(arm, dict) and arm.get("status") in {"complete", "trained"}
        for arm in receipt.get("arms", [])
    )


def _next_output(base: Path, *, progress: Path | None = None) -> Path:
    # A prior controller may have left only an arm-level progress receipt.
    # Treat that path as occupied so a restart cannot overwrite the partial
    # receipt; the retry receives its own output/progress pair.
    if not base.exists() and (progress is None or not progress.exists()):
        return base
    if _terminal_receipt(base):
        return base
    retry = 1
    while True:
        candidate = base.with_name(f"{base.stem}_retry{retry}{base.suffix}")
        if not candidate.exists():
            return candidate
        if _terminal_receipt(candidate):
            return candidate
        retry += 1


def _child_env(method: str) -> dict[str, str]:
    env = dict(os.environ)
    env["DFL_EXTENSIONS_SRC"] = str(EXTERNAL_SRC)
    env["SOLVER_FREE_DFL_REPO"] = str(SOLVER_FREE_REPO)
    env["SFGE_PUBLIC_REPO"] = str(SFGE_REPO)
    paths = [str(ROOT / "scripts"), str(ROOT / "src"), str(EXTERNAL_SRC)]
    # Keep the public top-level package namespaces isolated.  The two public
    # repositories both expose packages named ``data``/``methods``; putting
    # both on one child PYTHONPATH makes import resolution depend on order and
    # can silently load the wrong implementation.
    paths.append(str(SOLVER_FREE_REPO if method in {"cave", "lava"} else SFGE_REPO))
    env["PYTHONPATH"] = os.pathsep.join(paths)
    for key in (
        "OMP_NUM_THREADS",
        "MKL_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
    ):
        env[key] = "1"
    env.setdefault("MPLCONFIGDIR", str(ROOT / ".mplconfig-atlanta-public"))
    return env


def _runtime_receipt(
    *,
    entry: dict[str, Any],
    stage: str,
    method: str,
    manifest: Path,
    arms: list[dict[str, Any]],
    timeout: float | None,
    log: Path,
) -> dict[str, Any]:
    return {
        "kind": "atlanta_public_external_runtime_gate",
        "version": 1,
        "status": "runtime_gated",
        "stage": stage,
        "method": method,
        "route_id": entry["route_id"],
        "benchmark_id": entry["benchmark_id"],
        "seeds": entry["seeds"],
        "sizes": entry["sizes"],
        "manifest": str(manifest.resolve()),
        "manifest_sha256": _sha256(manifest),
        "arms_requested": arms,
        "test_access": False,
        "timeout_seconds": timeout,
        "error": "public implementation exceeded the declared child wall-time gate",
        "log": str(log),
        "source": {
            "external_benchmark_source": str(EXTERNAL_SRC),
            "solver_free_repository": str(SOLVER_FREE_REPO),
            "sfge_repository": str(SFGE_REPO),
        },
    }


def _run_task(
    *,
    stage: str,
    method: str,
    route: str,
    position: int,
    entry_index: int,
    entry: dict[str, Any],
    manifest: Path,
    arms_file: Path,
    output_root: Path,
    python_executable: Path,
    timeout: float | None,
    validation_only: bool,
) -> dict[str, Any]:
    leaf = output_root / stage / method
    base = leaf / f"{_safe(route)}_position{position:02d}.json"
    progress = base.with_name(f"{base.stem}.progress.json")
    output = _next_output(base, progress=progress)
    if output == base and _terminal_receipt(output):
        return {
            "stage": stage,
            "method": method,
            "route": route,
            "position": position,
            "status": "existing",
            "output": str(output),
        }
    log = output.with_suffix(".log")
    progress = output.with_name(f"{output.stem}.progress.json")
    command = [
        str(python_executable),
        str(ROOT / "scripts/run_atlanta_public_external_arm.py"),
        "--manifest",
        str(manifest.resolve()),
        "--entry-index",
        str(entry_index),
        "--arms",
        str(arms_file.resolve()),
        "--method",
        method,
        "--stage",
        stage,
        "--output",
        str(output),
        "--progress",
        str(progress),
    ]
    if validation_only:
        command.append("--validation-only")
    leaf.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    try:
        with log.open("w", encoding="utf-8") as stream:
            process = subprocess.Popen(
                command,
                cwd=ROOT,
                env=_child_env(method),
                stdout=stream,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            progress_harvested = False
            while process.poll() is None:
                if _progress_is_terminal(progress):
                    # Some public solver-free runs finish every requested arm
                    # but linger in multiprocessing cleanup.  Give normal
                    # cleanup a grace period, then harvest the complete arm
                    # receipt and terminate only that child process group.
                    time.sleep(30.0)
                    if process.poll() is None:
                        try:
                            os.killpg(process.pid, signal.SIGTERM)
                        except ProcessLookupError:
                            pass
                        try:
                            process.wait(timeout=10.0)
                        except subprocess.TimeoutExpired:
                            try:
                                os.killpg(process.pid, signal.SIGKILL)
                            except ProcessLookupError:
                                pass
                            process.wait()
                        harvested = _load(progress)
                        harvested["completion_source"] = "arm_progress_harvest_after_cleanup_grace"
                        harvested["position"] = position
                        harvested["entry_index"] = entry_index
                        _write(output, harvested)
                        progress_harvested = True
                        break
                if timeout is not None and time.perf_counter() - started >= timeout:
                    try:
                        os.killpg(process.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    process.wait()
                    raise subprocess.TimeoutExpired(command, timeout)
                time.sleep(2.0)
            completed_returncode = process.returncode
        if progress_harvested:
            return {
                "stage": stage,
                "method": method,
                "route": route,
                "position": position,
                "status": "complete_progress_harvest",
                "returncode": completed_returncode,
                "output": str(output),
                "seconds": time.perf_counter() - started,
            }
        # Add campaign coordinates in the parent, so public-method receipts
        # remain source-faithful while stage selection can verify paired
        # positions without reverse-engineering filenames.
        if output.is_file():
            try:
                child_receipt = _load(output)
                if isinstance(child_receipt, dict):
                    child_receipt["position"] = position
                    child_receipt["entry_index"] = entry_index
                    _write(output, child_receipt)
            except (OSError, json.JSONDecodeError):
                pass
        return {
            "stage": stage,
            "method": method,
            "route": route,
            "position": position,
            "status": "complete_process" if completed_returncode == 0 else "nonzero_process",
            "returncode": completed_returncode,
            "output": str(output),
            "seconds": time.perf_counter() - started,
        }
    except subprocess.TimeoutExpired:
        receipt = _runtime_receipt(
            entry=entry,
            stage=stage,
            method=method,
            manifest=manifest,
            arms=list(_load(arms_file)),
            timeout=float(timeout or 0.0),
            log=log,
        )
        receipt["position"] = position
        receipt["entry_index"] = entry_index
        _write(output, receipt)
        return {
            "stage": stage,
            "method": method,
            "route": route,
            "position": position,
            "status": "runtime_gated",
            "output": str(output),
            "seconds": time.perf_counter() - started,
        }


def _iter_receipts(root: Path, stage: str, method: str) -> Iterable[tuple[Path, dict[str, Any]]]:
    for path in sorted((root / stage / method).glob("*.json")):
        if path.name in {"status.json", "selection.json"} or path.name.endswith(".progress.json"):
            continue
        try:
            value = _load(path)
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(value, dict):
            # A controller can be reaped after a child exits but before the
            # parent adds campaign coordinates.  Recover the position from
            # the immutable filename so those valid receipts remain eligible
            # for paired validation selection on resume.
            if value.get("position") is None and "_position" in path.stem:
                suffix = path.stem.rsplit("_position", 1)[1]
                suffix = suffix.split("_retry", 1)[0]
                try:
                    value["position"] = int(suffix)
                except ValueError:
                    pass
            yield path, value


def _progress_is_terminal(path: Path) -> bool:
    try:
        value = _load(path)
    except (OSError, json.JSONDecodeError):
        return False
    if str(value.get("status", "")) not in {"complete", "partial_failure", "failed"}:
        return False
    progress = value.get("progress")
    if not isinstance(progress, dict) or not progress.get("arms_complete"):
        return False
    # Confirmation children must finish their post-selection test evaluation
    # before they can be harvested.
    if value.get("test_access") and not progress.get("final_receipt_written"):
        return False
    return True


def _update_status(path: Path, payload: dict[str, Any]) -> None:
    payload["last_update_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    _write(path, payload)


def _run_stage(
    *,
    stage: str,
    methods: tuple[str, ...],
    positions: tuple[int, ...],
    manifest: dict[str, Any],
    manifest_path: Path,
    entry_indices: dict[tuple[str, int], int],
    arms_files: dict[tuple[str, str], Path],
    output_root: Path,
    python_executable: Path,
    workers: int,
    timeout: float | None,
    validation_only: bool,
) -> list[dict[str, Any]]:
    tasks = [
        (route, position, method)
        for route in ROUTES
        for position in positions
        for method in methods
    ]
    method_priority = {"cave": 0, "sfge": 1, "lava": 2}
    tasks.sort(key=lambda item: (method_priority[item[2]], ROUTE_PRIORITY[item[0]], item[1]))
    status_path = output_root / stage / "status.json"
    status: dict[str, Any] = {
        "kind": "atlanta_public_external_stage",
        "stage": stage,
        "methods": list(methods),
        "expected_tasks": len(tasks),
        "workers": workers,
        "timeout_seconds": timeout,
        "validation_only": validation_only,
        "manifest": str(manifest_path.resolve()),
        "manifest_sha256": _sha256(manifest_path),
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "receipts": [],
    }
    _update_status(status_path, status)
    lock = threading.Lock()

    def invoke(task: tuple[str, int, str]) -> dict[str, Any]:
        route, position, method = task
        entry_index = entry_indices[(route, position)]
        return _run_task(
            stage=stage,
            method=method,
            route=route,
            position=position,
            entry_index=entry_index,
            entry=manifest["entries"][entry_index],
            manifest=manifest_path,
            arms_file=arms_files[(method, route)],
            output_root=output_root,
            python_executable=python_executable,
            timeout=timeout,
            validation_only=validation_only,
        )

    pending: list[tuple[str, int, str]] = []
    for task in tasks:
        route, position, method = task
        base = output_root / stage / method / f"{_safe(route)}_position{position:02d}.json"
        if not _terminal_receipt(base):
            pending.append(task)
    status["pending_at_launch"] = len(pending)
    status["completed_tasks"] = len(tasks) - len(pending)
    _update_status(status_path, status)
    if not pending:
        status["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        status["completed_tasks"] = len(tasks)
        _update_status(status_path, status)
        return [
            value for _, value in _iter_receipts(output_root, stage, methods[0])
        ]

    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        futures = [pool.submit(invoke, task) for task in pending]
        for future in as_completed(futures):
            result = future.result()
            with lock:
                status["receipts"].append(result)
                status["completed_tasks"] = int(status.get("completed_tasks", 0)) + 1
                _update_status(status_path, status)
            print(json.dumps(result), flush=True)
    status["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    _update_status(status_path, status)
    return status["receipts"]


def _select_from_stage(
    *,
    output_root: Path,
    stage: str,
    method: str,
    allowed_routes: set[str],
) -> tuple[dict[str, list[dict[str, Any]]], dict[str, Any]]:
    # Keep one score per (route, position, arm).  Retries are retained on disk
    # for provenance, but must not count twice in a validation mean.
    grouped: dict[tuple[str, str], dict[str, dict[int, float]]] = {}
    provenance: dict[str, Any] = {
        "stage": stage,
        "method": method,
        "metric": "mean validation conditional-mean normalized decision regret",
        "routes": {},
    }
    expected_positions = set(DEV_POSITIONS if stage == "development" else REFINE_POSITIONS)
    observed_positions: dict[str, set[int]] = {route: set() for route in allowed_routes}
    for _, receipt in _iter_receipts(output_root, stage, method):
        route = str(receipt.get("route_id", ""))
        if route not in allowed_routes:
            continue
        # A receipt is eligible only when it is a clean, validation-only
        # child for the requested stage.  The position is encoded in the
        # filename because the public adapter receipt intentionally contains
        # only the paired seed payload.
        if not _selection_receipt_usable(receipt):
            continue
        path_position = None
        # Recover position from the receipt's explicit campaign annotation;
        # old receipts without it are conservatively excluded.
        try:
            path_position = int(receipt.get("position"))
        except (TypeError, ValueError):
            path_position = None
        if path_position is None:
            continue
        if path_position not in expected_positions:
            continue
        observed_positions.setdefault(route, set()).add(path_position)
        key = (route, method)
        bucket = grouped.setdefault(key, {})
        for arm in receipt.get("arms", []):
            if not isinstance(arm, dict):
                continue
            value = arm.get("validation_regret")
            try:
                score = float(value)
            except (TypeError, ValueError):
                continue
            if not (score == score) or score in {float("inf"), float("-inf")}:
                continue
            signature = _arm_key(arm)
            bucket.setdefault(signature, {})[path_position] = score
    selections: dict[str, list[dict[str, Any]]] = {}
    for route in sorted(allowed_routes, key=lambda value: ROUTE_PRIORITY[value]):
        bucket = grouped.get((route, method), {})
        ranked_rows = []
        for signature, values_by_position in bucket.items():
            if set(values_by_position) != expected_positions:
                continue
            values = [values_by_position[pos] for pos in sorted(expected_positions)]
            ranked_rows.append(
                {
                    "arm": json.loads(signature),
                    "mean_validation_regret": sum(values) / len(values),
                    "validation_seed_count": len(values),
                    "validation_regrets": values,
                }
            )
        ranked = sorted(
            ranked_rows,
            key=lambda row: (float(row["mean_validation_regret"]), _arm_key(row["arm"])),
        )
        complete_seed_count = len(observed_positions.get(route, set()))
        top = [row["arm"] for row in ranked[:3]] if complete_seed_count == len(expected_positions) else []
        selections[route] = top
        provenance["routes"][route] = {
            "candidate_count": len(ranked),
            "top_three": ranked[:3],
            "observed_positions": sorted(observed_positions.get(route, set())),
            "required_positions": sorted(expected_positions),
            "status": "selected" if top else "selection_blocked",
            "reason": None if top else "incomplete_or_failed_validation_receipts",
        }
    return selections, provenance


def _build_stage_arm_files(
    *,
    output_root: Path,
    stage: str,
    methods: tuple[str, ...],
    selected: dict[str, dict[str, dict[str, list[dict[str, Any]]]]] | None = None,
) -> dict[tuple[str, str], Path]:
    files: dict[tuple[str, str], Path] = {}
    for method in methods:
        for route in ROUTES:
            if selected is None:
                arms = _development_arms(method)
            else:
                if stage == "refinement":
                    arms = _refinement_arms(
                        method, selected["development"].get(method, {}).get(route, [])
                    )
                else:
                    arms = [
                        _confirmation_arm(
                            method,
                            selected["refinement"].get(method, {}).get(route, [])[0],
                        )
                    ]
            path = output_root / "configs" / stage / f"{method}_{_safe(route)}.json"
            _write(path, arms)
            files[(method, route)] = path
    return files


def _write_selection_summary(output_root: Path, selection: dict[str, Any], name: str) -> Path:
    path = output_root / "selections" / f"{name}.json"
    _write(path, selection)
    return path


def _validate_sources() -> dict[str, Any]:
    required = {
        "external_benchmark_source": EXTERNAL_SRC / "dfl_extensions_lab/benchmarks/native_factory_registry.py",
        "solver_free_source": SOLVER_FREE_REPO / "methods/cave.py",
        "sfge_source": SFGE_REPO / "methods/sfge.py",
    }
    missing = [name for name, path in required.items() if not path.is_file()]
    if missing:
        raise RuntimeError(
            "missing pinned source files: "
            + ", ".join(f"{name}={required[name]}" for name in missing)
        )
    def commit(path: Path) -> str | None:
        try:
            return subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=path, text=True
            ).strip()
        except (OSError, subprocess.CalledProcessError):
            return None
    return {
        "external_benchmark_source": str(EXTERNAL_SRC),
        "external_benchmark_commit": commit(EXTERNAL_SRC.parent),
        "solver_free_repository": str(SOLVER_FREE_REPO),
        "solver_free_commit": commit(SOLVER_FREE_REPO),
        "sfge_repository": str(SFGE_REPO),
        "sfge_commit": commit(SFGE_REPO),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--workers", type=int, default=5)
    parser.add_argument(
        "--timeout-seconds",
        type=float,
        default=0.0,
        help="positive per-child gate; zero (default) runs until all requested arms finish",
    )
    parser.add_argument("--python", dest="python_executable", type=Path, default=ROOT / ".venv/bin/python")
    parser.add_argument(
        "--stage",
        choices=("all", "development", "refinement", "confirmation"),
        default="all",
        help="resume at a specific stage; all is the unattended publication pipeline",
    )
    args = parser.parse_args()
    manifest_path = args.manifest.resolve()
    manifest = _load(manifest_path)
    if not isinstance(manifest, dict) or not isinstance(manifest.get("entries"), list):
        raise ValueError("manifest must contain an entries list")
    entry_indices = _entry_index_by_route_position(manifest)
    source = _validate_sources()
    output_root = args.output_root.resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    _write(
        output_root / "campaign.json",
        {
            "kind": "atlanta_public_external_campaign",
            "version": 1,
            "manifest": str(manifest_path),
            "manifest_sha256": _sha256(manifest_path),
            "routes": list(ROUTES),
            "methods": ["sfge", "cave", "lava"],
            "training_contract": "continuous LP relaxation; exact original integer evaluation",
            "development_positions": list(DEV_POSITIONS),
            "refinement_positions": list(REFINE_POSITIONS),
            "confirmation_positions": list(CONFIRM_POSITIONS),
            "workers": args.workers,
            "timeout_seconds": args.timeout_seconds if args.timeout_seconds > 0 else None,
            "test_blind_until_confirmation": True,
            "source": source,
            "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        },
    )

    methods = ("cave", "lava", "sfge")
    # Keep selections method-specific.  Mixing CaVE/LAVA/SFGE rows at the
    # route level would silently allow one method's arm to be deployed by a
    # different method during confirmation.
    selected: dict[str, dict[str, dict[str, list[dict[str, Any]]]]] = {
        level: {method: {route: [] for route in ROUTES} for method in methods}
        for level in ("development", "refinement")
    }

    if args.stage in {"all", "development"}:
        files = _build_stage_arm_files(output_root=output_root, stage="development", methods=methods)
        _run_stage(
            stage="development",
            methods=methods,
            positions=DEV_POSITIONS,
            manifest=manifest,
            manifest_path=manifest_path,
            entry_indices=entry_indices,
            arms_files=files,
            output_root=output_root,
            python_executable=args.python_executable,
            workers=args.workers,
            timeout=args.timeout_seconds if args.timeout_seconds > 0 else None,
            validation_only=True,
        )
        for method in methods:
            chosen, details = _select_from_stage(
                output_root=output_root,
                stage="development",
                method=method,
                allowed_routes=set(ROUTES),
            )
            for route in ROUTES:
                selected["development"][method][route] = chosen.get(route, [])
            _write_selection_summary(
                output_root,
                {"method": method, "source": source, "selection": details},
                f"development_{method}",
            )

    if args.stage in {"all", "refinement"}:
        # If resuming at refinement, rebuild development selections from the
        # receipts rather than trusting mutable in-memory state.
        if args.stage == "refinement":
            for method in methods:
                chosen, details = _select_from_stage(
                    output_root=output_root,
                    stage="development",
                    method=method,
                    allowed_routes=set(ROUTES),
                )
                for route in ROUTES:
                    selected["development"][method][route] = chosen.get(route, [])
                _write_selection_summary(
                    output_root,
                    {"method": method, "source": source, "selection": details},
                    f"development_{method}_resume",
                )
        # A route-specific refinement file is required.  A missing screen
        # selection remains visibly blocked; it is not replaced by a score.
        files: dict[tuple[str, str], Path] = {}
        for method in methods:
            for route in ROUTES:
                arms = _refinement_arms(method, selected["development"][method][route])
                path = output_root / "configs" / "refinement" / f"{method}_{_safe(route)}.json"
                _write(path, arms)
                files[(method, route)] = path
        _run_stage(
            stage="refinement",
            methods=methods,
            positions=REFINE_POSITIONS,
            manifest=manifest,
            manifest_path=manifest_path,
            entry_indices=entry_indices,
            arms_files=files,
            output_root=output_root,
            python_executable=args.python_executable,
            workers=args.workers,
            timeout=args.timeout_seconds if args.timeout_seconds > 0 else None,
            validation_only=True,
        )
        for method in methods:
            chosen, details = _select_from_stage(
                output_root=output_root,
                stage="refinement",
                method=method,
                allowed_routes=set(ROUTES),
            )
            for route in ROUTES:
                selected["refinement"][method][route] = chosen.get(route, [])
            _write_selection_summary(
                output_root,
                {"method": method, "source": source, "selection": details},
                f"refinement_{method}",
            )

    if args.stage in {"all", "confirmation"}:
        # Reconstruct both selection levels when the process is resumed at the
        # final stage.  The confirmation config is written before any child is
        # allowed to open the test oracle.
        if args.stage == "confirmation":
            for level, stage_name in (("development", "development"), ("refinement", "refinement")):
                for method in methods:
                    chosen, _ = _select_from_stage(
                        output_root=output_root,
                        stage=stage_name,
                        method=method,
                        allowed_routes=set(ROUTES),
                    )
                    for route in ROUTES:
                        selected[level][method][route] = chosen.get(route, [])
        frozen: dict[str, Any] = {
            "kind": "atlanta_public_external_frozen_confirmation",
            "version": 1,
            "manifest": str(manifest_path),
            "manifest_sha256": _sha256(manifest_path),
            "source": source,
            "selection_metric": "mean validation conditional-mean normalized decision regret",
            "test_access_before_manifest": False,
            "routes": {},
        }
        files: dict[tuple[str, str], Path] = {}
        for route in ROUTES:
            frozen["routes"][route] = {}
            for method in methods:
                candidates = selected["refinement"][method][route]
                if not candidates:
                    frozen["routes"][route][method] = {
                        "status": "selection_blocked",
                        "reason": "no clean refinement arm with a validation score",
                    }
                    arm = []
                else:
                    arm = [_confirmation_arm(method, candidates[0])]
                    frozen["routes"][route][method] = {
                        "status": "frozen",
                        "arm": arm[0],
                        "validation_seed_positions": list(REFINE_POSITIONS),
                    }
                path = output_root / "configs" / "confirmation" / f"{method}_{_safe(route)}.json"
                _write(path, arm)
                files[(method, route)] = path
        frozen_path = output_root / "configs" / "confirmation" / "frozen_confirmation.json"
        _write(frozen_path, frozen)
        # An explicit identity check prevents accidental test access with a
        # mutable development config or a route whose selection was blocked.
        frozen_check = _load(frozen_path)
        if frozen_check.get("test_access_before_manifest") is not False:
            raise RuntimeError("confirmation config is not test-blind")
        for method in methods:
            for route in ROUTES:
                if frozen_check["routes"][route][method]["status"] != "frozen":
                    continue
                arm_payload = _load(files[(method, route)])
                if len(arm_payload) != 1:
                    raise RuntimeError(f"frozen arm missing for {method}/{route}")
        _write_selection_summary(output_root, frozen, "frozen_confirmation")
        _run_stage(
            stage="confirmation",
            methods=methods,
            positions=CONFIRM_POSITIONS,
            manifest=manifest,
            manifest_path=manifest_path,
            entry_indices=entry_indices,
            arms_files=files,
            output_root=output_root,
            python_executable=args.python_executable,
            workers=args.workers,
            timeout=args.timeout_seconds if args.timeout_seconds > 0 else None,
            validation_only=False,
        )

    _write(
        output_root / "finished.json",
        {
            "kind": "atlanta_public_external_campaign_finished",
            "stage_requested": args.stage,
            "finished_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "test_access_isolated_to_confirmation": True,
        },
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
