"""Build validation-gated PyEPO campaigns for mollified proximal learning."""

from __future__ import annotations

import argparse
import hashlib
import itertools
from pathlib import Path
from typing import Any

from mollified_pyepo_design import (
    CONFIRMATION_SEEDS,
    DEVELOPMENT_SEEDS,
    INITIAL_TAU,
    REFINEMENT_RATES,
    REFINEMENT_TAUS,
    SCREEN_SIGMAS,
    _base,
    _neighbor_sigmas,
    _variant,
)
from summarize_mollified_development import _arm_sha256 as _arm_sha256
from summarize_mollified_development import _verify_static_selection_receipt
from summarize_mollified_k_sensitivity import (
    _verify_final_selection,
    _verify_provisional,
)

from proximal_spo.artifacts import source_sha256 as source_sha256
from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPO_ROOT / "configs" / "mollified_pyepo"


def _file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _campaign(
    name: str, run_root: str, variants: list[dict[str, Any]]
) -> dict[str, Any]:
    return {
        "name": name,
        "run_root": run_root,
        "base": _base(DEVELOPMENT_SEEDS[0]),
        "variants": variants,
    }


def _arm_parameters(arm: dict[str, Any]) -> tuple[float, float, float, int]:
    parameters = arm.get("method_parameters")
    training = arm.get("training")
    if not isinstance(parameters, dict) or not isinstance(training, dict):
        raise ValueError("selected arm is malformed")
    return (
        float(parameters["sigma"]),
        float(parameters["tau"]),
        float(training["learning_rate"]),
        int(parameters["training_samples"]),
    )


def _write_screen() -> Path:
    variants = [
        _variant(
            seed=seed,
            sigma=sigma,
            tau=INITIAL_TAU,
            learning_rate=0.003,
            prefix="moll_screen",
        )
        for sigma in SCREEN_SIGMAS
        for seed in DEVELOPMENT_SEEDS
    ]
    path = CONFIG_ROOT / "development_screen.json"
    write_json(
        path,
        _campaign(
            "mollified_pyepo_development_screen",
            "runs/mollified_pyepo/development_screen",
            variants,
        ),
    )
    return path


def _write_refinement(screen_selection: Path) -> Path:
    selection, _ = _verify_static_selection_receipt(
        screen_selection, required_stage="screen"
    )
    best_positive = selection.get("best_positive_arm")
    if not isinstance(best_positive, dict):
        raise ValueError("screen receipt lacks best_positive_arm")
    best_sigma, _, _, _ = _arm_parameters(best_positive)
    sigmas = _neighbor_sigmas(best_sigma)
    variants = [
        _variant(
            seed=seed,
            sigma=sigma,
            tau=tau,
            learning_rate=rate,
            prefix="moll_refine",
        )
        for sigma, tau, rate in itertools.product(
            sigmas, REFINEMENT_TAUS, REFINEMENT_RATES
        )
        for seed in DEVELOPMENT_SEEDS
    ]
    path = CONFIG_ROOT / "development_refinement.json"
    payload = _campaign(
        "mollified_pyepo_local_refinement",
        "runs/mollified_pyepo/development_refinement",
        variants,
    )
    payload["design_receipt"] = {
        "screen_selection": str(screen_selection),
        "screen_selection_sha256": _file_sha256(screen_selection),
        "screen_source_sha256": selection.get("source_sha256"),
        "best_positive_sigma": best_sigma,
        "refinement_sigmas": list(sigmas),
        "refinement_taus": list(REFINEMENT_TAUS),
        "refinement_learning_rates": list(REFINEMENT_RATES),
    }
    write_json(path, payload)
    return path


def _outward_value(axis: str, value: float, side: str) -> float:
    if axis == "sigma":
        result = value / 2.0 if side == "lower" else value * 2.0
    elif axis == "learning_rate":
        result = value / 3.0 if side == "lower" else value * 3.0
    elif axis == "tau":
        raise ValueError(
            "tau boundary expansion is forbidden; use exactly "
            f"{REFINEMENT_TAUS}"
        )
    else:
        raise ValueError(axis)
    return float(f"{result:.12g}")


def _write_boundary(refinement_selection: Path) -> Path:
    selection, _ = _verify_static_selection_receipt(
        refinement_selection, required_stage="refinement"
    )
    selected = selection.get("selected_arm")
    axes = selection.get("boundary_axes")
    if not isinstance(selected, dict) or not isinstance(axes, list):
        raise ValueError("refinement receipt lacks selected arm or boundary axes")
    if not axes:
        raise ValueError("selected refinement arm is interior; no expansion is needed")
    sigma, tau, rate, training_samples = _arm_parameters(selected)
    base_values = {"sigma": sigma, "tau": tau, "learning_rate": rate}
    outward: dict[str, float] = {}
    for item in axes:
        if not isinstance(item, dict):
            raise ValueError("boundary axis entry must be an object")
        axis = str(item["axis"])
        side = str(item["side"])
        outward[axis] = _outward_value(axis, base_values[axis], side)
    settings: list[tuple[float, float, float]] = []
    names = sorted(outward)
    for count in range(1, len(names) + 1):
        for subset in itertools.combinations(names, count):
            values = dict(base_values)
            for axis in subset:
                values[axis] = outward[axis]
            settings.append(
                (values["sigma"], values["tau"], values["learning_rate"])
            )
    variants = [
        _variant(
            seed=seed,
            sigma=candidate_sigma,
            tau=candidate_tau,
            learning_rate=candidate_rate,
            training_samples=training_samples,
            prefix="moll_boundary",
        )
        for candidate_sigma, candidate_tau, candidate_rate in settings
        for seed in DEVELOPMENT_SEEDS
    ]
    path = CONFIG_ROOT / "development_boundary_expansion.json"
    payload = _campaign(
        "mollified_pyepo_boundary_expansion",
        # Deliberately shared with the refinement campaign: the final selector
        # must compare the original grid and its predeclared outward cells.
        "runs/mollified_pyepo/development_refinement",
        variants,
    )
    payload["design_receipt"] = {
        "refinement_selection": str(refinement_selection),
        "refinement_selection_sha256": _file_sha256(refinement_selection),
        "refinement_source_sha256": selection.get("source_sha256"),
        "expanded_axes": axes,
        "outward_values": outward,
        "joint_boundary_combinations_included": True,
    }
    write_json(path, payload)
    return path


def _selected_arm(final_selection: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    selection = _verify_final_selection(final_selection)
    arm = selection.get("selected_arm")
    if not isinstance(arm, dict):
        raise ValueError("final receipt lacks selected_arm")
    return selection, arm


def _write_confirmation(final_selection: Path) -> Path:
    selection, arm = _selected_arm(final_selection)
    sigma, tau, rate, training_samples = _arm_parameters(arm)
    variants = [
        _variant(
            seed=seed,
            sigma=sigma,
            tau=tau,
            learning_rate=rate,
            training_samples=training_samples,
            prefix="moll_confirm",
        )
        for seed in CONFIRMATION_SEEDS
    ]
    path = CONFIG_ROOT / "confirmation.json"
    payload = _campaign(
        "mollified_pyepo_confirmation",
        "runs/mollified_pyepo/confirmation",
        variants,
    )
    payload["frozen_selection_receipt"] = {
        "path": str(final_selection),
        "final_selection_sha256": _file_sha256(final_selection),
        "source_sha256": selection.get("source_sha256"),
        "selected_arm_sha256": selection.get("selected_arm_sha256"),
        "baseline_configs_modified": False,
    }
    write_json(path, payload)
    return path


def _write_k_sensitivity(provisional_selection: Path) -> Path:
    selection = _verify_provisional(provisional_selection)
    arm = selection["selected_arm"]
    assert isinstance(arm, dict)
    sigma, tau, rate, training_samples = _arm_parameters(arm)
    if training_samples != 8:
        raise ValueError("the provisional method must use K=8")
    variants = [
        _variant(
            seed=seed,
            sigma=sigma,
            tau=tau,
            learning_rate=rate,
            training_samples=16,
            prefix="moll_kcheck",
        )
        for seed in DEVELOPMENT_SEEDS
    ]
    path = CONFIG_ROOT / "development_k16_sensitivity.json"
    payload = _campaign(
        "mollified_pyepo_k16_sensitivity",
        "runs/mollified_pyepo/development_k_sensitivity",
        variants,
    )
    payload["diagnostic_only"] = True
    payload["confirmation_gate"] = True
    payload["frozen_selection_receipt"] = {
        "path": str(provisional_selection),
        "source_sha256": selection.get("source_sha256"),
        "selected_arm_sha256": selection.get("selected_arm_sha256"),
    }
    write_json(path, payload)
    return path


def _write_batch_sensitivity(final_selection: Path) -> Path:
    selection, arm = _selected_arm(final_selection)
    sigma, tau, rate, training_samples = _arm_parameters(arm)
    updates = 1600
    variants: list[dict[str, Any]] = []
    for batch_size in (64, 128, 256):
        batches_per_epoch = 1024 // batch_size
        epochs = updates // batches_per_epoch
        validation_interval = max(1, round(40 / batches_per_epoch))
        for seed in DEVELOPMENT_SEEDS:
            variants.append(
                _variant(
                    seed=seed,
                    sigma=sigma,
                    tau=tau,
                    learning_rate=rate,
                    training_samples=training_samples,
                    batch_size=batch_size,
                    epochs=epochs,
                    validation_interval=validation_interval,
                    prefix="moll_bcheck",
                )
            )
    path = CONFIG_ROOT / "optional_batch_sensitivity.json"
    payload = _campaign(
        "mollified_pyepo_optional_batch_sensitivity",
        "runs/mollified_pyepo/optional_batch_sensitivity",
        variants,
    )
    payload["diagnostic_only"] = True
    payload["launch_condition"] = "materially noisy provisional training curves"
    payload["optimizer_updates_per_arm"] = updates
    payload["frozen_selection_receipt"] = {
        "path": str(final_selection),
        "source_sha256": selection.get("source_sha256"),
    }
    write_json(path, payload)
    return path


def main() -> None:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="stage", required=True)
    subparsers.add_parser("screen")
    refinement = subparsers.add_parser("refinement")
    refinement.add_argument("--screen-selection", type=Path, required=True)
    boundary = subparsers.add_parser("boundary")
    boundary.add_argument("--refinement-selection", type=Path, required=True)
    for stage in ("confirmation", "batch-sensitivity"):
        item = subparsers.add_parser(stage)
        item.add_argument("--final-selection", type=Path, required=True)
    k_sensitivity = subparsers.add_parser("k-sensitivity")
    k_sensitivity.add_argument(
        "--provisional-selection", type=Path, required=True
    )
    arguments = parser.parse_args()
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    if arguments.stage == "screen":
        path = _write_screen()
    elif arguments.stage == "refinement":
        path = _write_refinement(arguments.screen_selection)
    elif arguments.stage == "boundary":
        path = _write_boundary(arguments.refinement_selection)
    elif arguments.stage == "confirmation":
        path = _write_confirmation(arguments.final_selection)
    elif arguments.stage == "k-sensitivity":
        path = _write_k_sensitivity(arguments.provisional_selection)
    elif arguments.stage == "batch-sensitivity":
        path = _write_batch_sensitivity(arguments.final_selection)
    else:
        raise AssertionError(arguments.stage)
    print(path.relative_to(REPO_ROOT))


if __name__ == "__main__":
    main()
