"""Summarize the frozen paired 2x2 barrier/deployment confirmation."""

from __future__ import annotations

import argparse
from pathlib import Path

from proximal_spo.artifacts import write_json
from proximal_spo.barrier_mechanism_analysis import (
    render_barrier_mechanism_markdown,
    summarize_barrier_mechanism_confirmation,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", action="append", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    parser.add_argument("--required-seeds", type=int, default=10)
    parser.add_argument("--fixed-maximum-epoch", type=int, default=2400)
    arguments = parser.parse_args()
    summary = summarize_barrier_mechanism_confirmation(
        arguments.run_root,
        manifest_path=arguments.manifest,
        required_seed_count=arguments.required_seeds,
        fixed_maximum_epoch=arguments.fixed_maximum_epoch,
    )
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, summary)
    arguments.markdown_output.write_text(
        render_barrier_mechanism_markdown(summary), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
