"""Build staged, paired campaigns over diverse cost-learning LP families."""

from __future__ import annotations

import argparse
import copy
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPO_ROOT / "configs" / "broad_cost"

DEVELOPMENT_SEEDS = (1, 2, 3)
CONFIRMATION_SEEDS = (21, 22, 23, 24, 25)
TAUS = (0.1, 0.3, 1.0, 3.0, 10.0)
PROXIMAL_RATES = (3e-4, 1e-3, 3e-3, 1e-2, 3e-2)
SFGE_SIGMAS = (0.03, 0.1, 0.3, 1.0, 3.0)
SFGE_RATES = (3e-5, 1e-4, 3e-4, 1e-3, 3e-3)


@dataclass(frozen=True)
class BenchmarkDesign:
    benchmark_id: str
    tag: str
    interface: str
    law: dict[str, Any]


DESIGNS = (
    BenchmarkDesign(
        "cost.topk20x5",
        "topk",
        "full",
        {
            "context_dimension": 8,
            "random_fraction": 1.0,
            "style": "positive",
            "noise": "pyepo_uniform",
            "noise_scale": 0.5,
            "signal_scale": 1.0,
            "polynomial_degree": 4,
        },
    ),
    BenchmarkDesign(
        "cost.grid5",
        "grid",
        "partial",
        {
            "context_dimension": 5,
            "random_fraction": 0.25,
            "style": "positive",
            "noise": "pyepo_uniform",
            "noise_scale": 0.5,
            "signal_scale": 1.0,
            "polynomial_degree": 6,
        },
    ),
    BenchmarkDesign(
        "cost.assignment10",
        "assignment",
        "full",
        {
            "context_dimension": 12,
            "random_fraction": 1.0,
            "style": "positive",
            "noise": "pyepo_uniform",
            "noise_scale": 0.5,
            "signal_scale": 1.0,
            "polynomial_degree": 4,
        },
    ),
    BenchmarkDesign(
        "cost.knapsack50x5",
        "knapsack",
        "partial",
        {
            "context_dimension": 10,
            "random_fraction": 0.3,
            "style": "negative",
            "noise": "lognormal",
            "noise_scale": 0.35,
            "signal_scale": 0.8,
            "polynomial_degree": 2,
        },
    ),
    BenchmarkDesign(
        "cost.facility30x5_relaxation",
        "facility",
        "partial",
        {
            "context_dimension": 12,
            "random_fraction": 0.25,
            "style": "positive",
            "noise": "lognormal",
            "noise_scale": 0.35,
            "signal_scale": 0.7,
            "polynomial_degree": 2,
        },
    ),
    BenchmarkDesign(
        "cost.random_lp100x50",
        "randomlp",
        "partial",
        {
            "context_dimension": 8,
            "random_fraction": 0.25,
            "style": "signed",
            "noise": "gaussian",
            "noise_scale": 0.25,
            "signal_scale": 0.8,
            "polynomial_degree": 2,
        },
    ),
)


def _seeds(seed: int) -> dict[str, int]:
    return {
        "data": seed,
        "structural": 101,
        "initialization": 200 + seed,
        "shuffle": 300 + seed,
        "perturbation": 400 + seed,
    }


def _base(design: BenchmarkDesign, seed: int) -> dict[str, Any]:
    return {
        "name": "base",
        "benchmark_id": design.benchmark_id,
        "method": "mse",
        "interface": design.interface,
        "workers": 4,
        "sizes": {"train": 512, "validation": 256, "test": 512},
        "law": copy.deepcopy(design.law),
        "model": {
            "depth": 2,
            "width": 64,
            "activation": "silu",
            "layer_norm": False,
            "correction_depth": 2,
            "correction_width": 64,
        },
        "training": {
            "epochs": 120,
            "batch_size": 128,
            "learning_rate": 1e-3,
            "weight_decay": 1e-5,
            "optimizer": "adamw",
            "gradient_clip": 10.0,
            "validation_interval": 5,
            "patience": 20,
            "minimum_delta": 1e-6,
            "evaluation_batch_size": 512,
            "torch_threads": 2,
            "selection_mode": "validation_regret",
        },
        "seeds": _seeds(seed),
        "method_parameters": {},
    }


def _tag(value: float) -> str:
    return f"{value:.0e}".replace("-", "m").replace("+", "p")


def _full_variant(
    design: BenchmarkDesign,
    seed: int,
    *,
    name: str,
    method: str,
    training: dict[str, Any] | None = None,
    method_parameters: dict[str, Any] | None = None,
) -> dict[str, Any]:
    result = _base(design, seed)
    result["name"] = name
    result["method"] = method
    if training:
        result["training"].update(training)
    result["method_parameters"] = method_parameters or {}
    return result


def _core_variants() -> list[dict[str, Any]]:
    variants: list[dict[str, Any]] = []
    for design in DESIGNS:
        seed = DEVELOPMENT_SEEDS[0]
        for method, rates in (
            ("mse", (3e-4, 1e-3, 3e-3, 1e-2)),
            ("wise", (3e-4, 1e-3, 3e-3, 1e-2)),
            ("spo_plus", (1e-4, 3e-4, 1e-3, 3e-3, 1e-2)),
        ):
            for rate in rates:
                variants.append(
                    _full_variant(
                        design,
                        seed,
                        name=f"{design.tag}_s{seed}_{method}_lr{_tag(rate)}",
                        method=method,
                        training={"learning_rate": rate},
                    )
                )
        for neighbors in (5, 10, 20, 50):
            for weighted in (False, True):
                variants.append(
                    _full_variant(
                        design,
                        seed,
                        name=(
                            f"{design.tag}_s{seed}_knn_k{neighbors}_"
                            f"{'weighted' if weighted else 'uniform'}"
                        ),
                        method="knn",
                        method_parameters={
                            "neighbors": neighbors,
                            "distance_weighted": weighted,
                        },
                    )
                )

        # Coordinate screen: tau at a central LR, then LR at a central tau.
        proximal_pairs = {(tau, 3e-3) for tau in TAUS}
        proximal_pairs.update((3.0, rate) for rate in PROXIMAL_RATES)
        for tau, rate in sorted(proximal_pairs):
            variants.append(
                _full_variant(
                    design,
                    seed,
                    name=(
                        f"{design.tag}_s{seed}_prox_tau{_tag(tau)}_"
                        f"lr{_tag(rate)}"
                    ),
                    method="proximal",
                    training={"learning_rate": rate},
                    method_parameters={
                        "tau": tau,
                        "parameterization": "normalized",
                        "exact_head": False,
                    },
                )
            )

        # SFGE uses antithetic pairs. The initial coordinate screen uses two
        # base Gaussian draws (four optimizer calls) per training example.
        sfge_pairs = {(sigma, 3e-4) for sigma in SFGE_SIGMAS}
        sfge_pairs.update((0.1, rate) for rate in SFGE_RATES)
        for sigma, rate in sorted(sfge_pairs):
            variants.append(
                _full_variant(
                    design,
                    seed,
                    name=(
                        f"{design.tag}_s{seed}_sfge_sigma{_tag(sigma)}_"
                        f"lr{_tag(rate)}_m2"
                    ),
                    method="sfge",
                    training={"learning_rate": rate},
                    method_parameters={"sigma": sigma, "samples": 2},
                )
            )
    return variants


def _smoke_variants() -> list[dict[str, Any]]:
    variants: list[dict[str, Any]] = []
    for design in DESIGNS:
        for method, parameters in (
            ("mse", {}),
            (
                "proximal",
                {"tau": 3.0, "parameterization": "normalized", "exact_head": False},
            ),
            ("sfge", {"sigma": 0.1, "samples": 2}),
        ):
            variant = _full_variant(
                design,
                DEVELOPMENT_SEEDS[0],
                name=f"{design.tag}_smoke_{method}",
                method=method,
                training={
                    "epochs": 2,
                    "batch_size": 32,
                    "validation_interval": 1,
                    "patience": 2,
                    "torch_threads": 1,
                },
                method_parameters=parameters,
            )
            variant["workers"] = 1
            variant["sizes"] = {"train": 64, "validation": 32, "test": 32}
            variant["model"].update({"width": 16, "depth": 1})
            variants.append(variant)
    return variants


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected an object in {path}")
    return value


def _selected_arm(
    selection: dict[str, Any], benchmark_id: str, method: str
) -> dict[str, Any]:
    rows = selection.get("selected_arms")
    if not isinstance(rows, list):
        raise ValueError("selection receipt lacks selected_arms")
    matches = [
        row
        for row in rows
        if row.get("benchmark_id") == benchmark_id and row.get("method") == method
    ]
    if len(matches) != 1 or not isinstance(matches[0].get("arm"), dict):
        raise ValueError(f"missing selected {benchmark_id}/{method} arm")
    return copy.deepcopy(matches[0]["arm"])


def _neighbors(value: float, grid: tuple[float, ...]) -> tuple[float, ...]:
    index = grid.index(value)
    return grid[max(0, index - 1) : min(len(grid), index + 2)]


def _development_refinement(core_selection: dict[str, Any]) -> list[dict[str, Any]]:
    variants: list[dict[str, Any]] = []
    for design in DESIGNS:
        # Refit selected cheap comparators on all three development seeds.
        for method in ("mse", "wise", "spo_plus", "knn"):
            arm = _selected_arm(core_selection, design.benchmark_id, method)
            for seed in DEVELOPMENT_SEEDS:
                arm = copy.deepcopy(arm)
                arm["name"] = f"{design.tag}_s{seed}_{method}_selected"
                arm["seeds"] = _seeds(seed)
                variants.append(arm)

        proximal = _selected_arm(core_selection, design.benchmark_id, "proximal")
        selected_tau = float(proximal["method_parameters"]["tau"])
        selected_rate = float(proximal["training"]["learning_rate"])
        for seed in DEVELOPMENT_SEEDS:
            for tau in _neighbors(selected_tau, TAUS):
                for rate in _neighbors(selected_rate, PROXIMAL_RATES):
                    variants.append(
                        _full_variant(
                            design,
                            seed,
                            name=(
                                f"{design.tag}_s{seed}_prox_refine_tau{_tag(tau)}_"
                                f"lr{_tag(rate)}"
                            ),
                            method="proximal",
                            training={"learning_rate": rate},
                            method_parameters={
                                "tau": tau,
                                "parameterization": "normalized",
                                "exact_head": False,
                            },
                        )
                    )

        sfge = _selected_arm(core_selection, design.benchmark_id, "sfge")
        selected_sigma = float(sfge["method_parameters"]["sigma"])
        selected_rate = float(sfge["training"]["learning_rate"])
        for seed in DEVELOPMENT_SEEDS:
            for sigma in _neighbors(selected_sigma, SFGE_SIGMAS):
                for rate in _neighbors(selected_rate, SFGE_RATES):
                    variants.append(
                        _full_variant(
                            design,
                            seed,
                            name=(
                                f"{design.tag}_s{seed}_sfge_refine_sigma"
                                f"{_tag(sigma)}_lr{_tag(rate)}_m2"
                            ),
                            method="sfge",
                            training={"learning_rate": rate},
                            method_parameters={"sigma": sigma, "samples": 2},
                        )
                    )
    return variants


def _anchored_screen(core_selection: dict[str, Any]) -> list[dict[str, Any]]:
    variants: list[dict[str, Any]] = []
    for design in DESIGNS:
        mse = _selected_arm(core_selection, design.benchmark_id, "mse")
        base_rate = float(mse["training"]["learning_rate"])
        pairs = {(tau, 3e-3) for tau in TAUS}
        pairs.update((3.0, rate) for rate in PROXIMAL_RATES)
        for tau, rate in sorted(pairs):
            variants.append(
                _full_variant(
                    design,
                    DEVELOPMENT_SEEDS[0],
                    name=(
                        f"{design.tag}_s1_anchored_tau{_tag(tau)}_"
                        f"lr{_tag(rate)}"
                    ),
                    method="anchored_proximal",
                    training={"learning_rate": rate},
                    method_parameters={
                        "tau": tau,
                        "alpha": 1.0,
                        "base_method": "mse",
                        "base_epochs": 120,
                        "base_learning_rate": base_rate,
                        "base_batch_size": 128,
                        "freeze_base": True,
                        "center_on_base_decision": True,
                    },
                )
            )
    return variants


def _anchored_refinement(
    core_selection: dict[str, Any], anchored_selection: dict[str, Any]
) -> list[dict[str, Any]]:
    variants: list[dict[str, Any]] = []
    for design in DESIGNS:
        mse = _selected_arm(core_selection, design.benchmark_id, "mse")
        base_rate = float(mse["training"]["learning_rate"])
        anchored = _selected_arm(
            anchored_selection, design.benchmark_id, "anchored_proximal"
        )
        selected_tau = float(anchored["method_parameters"]["tau"])
        selected_rate = float(anchored["training"]["learning_rate"])
        for seed in DEVELOPMENT_SEEDS:
            for tau in _neighbors(selected_tau, TAUS):
                for rate in _neighbors(selected_rate, PROXIMAL_RATES):
                    variants.append(
                        _full_variant(
                            design,
                            seed,
                            name=(
                                f"{design.tag}_s{seed}_anchored_refine_tau"
                                f"{_tag(tau)}_lr{_tag(rate)}"
                            ),
                            method="anchored_proximal",
                            training={"learning_rate": rate},
                            method_parameters={
                                "tau": tau,
                                "alpha": 1.0,
                                "base_method": "mse",
                                "base_epochs": 120,
                                "base_learning_rate": base_rate,
                                "base_batch_size": 128,
                                "freeze_base": True,
                                "center_on_base_decision": True,
                            },
                        )
                    )
    return variants


def _sfge_sample_refinement(
    sfge_selection: dict[str, Any]
) -> list[dict[str, Any]]:
    variants: list[dict[str, Any]] = []
    for design in DESIGNS:
        sfge = _selected_arm(sfge_selection, design.benchmark_id, "sfge")
        sigma = float(sfge["method_parameters"]["sigma"])
        rate = float(sfge["training"]["learning_rate"])
        for seed in DEVELOPMENT_SEEDS:
            for samples in (2, 4, 8):
                variants.append(
                    _full_variant(
                        design,
                        seed,
                        name=(
                            f"{design.tag}_s{seed}_sfge_samples{samples}_"
                            f"sigma{_tag(sigma)}_lr{_tag(rate)}"
                        ),
                        method="sfge",
                        training={"learning_rate": rate},
                        method_parameters={"sigma": sigma, "samples": samples},
                    )
                )
    return variants


def _confirmation(
    standard_selection: dict[str, Any],
    anchored_selection: dict[str, Any],
    sfge_selection: dict[str, Any],
) -> list[dict[str, Any]]:
    variants: list[dict[str, Any]] = []
    for design in DESIGNS:
        selections = {
            method: _selected_arm(standard_selection, design.benchmark_id, method)
            for method in ("mse", "wise", "spo_plus", "knn", "proximal")
        }
        selections["anchored_proximal"] = _selected_arm(
            anchored_selection, design.benchmark_id, "anchored_proximal"
        )
        selections["sfge"] = _selected_arm(
            sfge_selection, design.benchmark_id, "sfge"
        )
        for method, arm in selections.items():
            for seed in CONFIRMATION_SEEDS:
                variant = copy.deepcopy(arm)
                variant["name"] = f"{design.tag}_confirm_s{seed}_{method}"
                variant["seeds"] = _seeds(seed)
                variants.append(variant)
    return variants


def _write(
    path: Path, name: str, run_root: str, variants: list[dict[str, Any]]
) -> None:
    if not variants:
        raise ValueError("campaign has no variants")
    write_json(
        path,
        {
            "name": name,
            "run_root": run_root,
            "base": _base(DESIGNS[0], DEVELOPMENT_SEEDS[0]),
            "variants": variants,
        },
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="stage", required=True)
    subparsers.add_parser("smoke")
    subparsers.add_parser("core")
    refine = subparsers.add_parser("refine")
    refine.add_argument("--core-selection", type=Path, required=True)
    anchored = subparsers.add_parser("anchored")
    anchored.add_argument("--core-selection", type=Path, required=True)
    anchored_refine = subparsers.add_parser("anchored-refine")
    anchored_refine.add_argument("--core-selection", type=Path, required=True)
    anchored_refine.add_argument("--anchored-selection", type=Path, required=True)
    sfge_samples = subparsers.add_parser("sfge-samples")
    sfge_samples.add_argument("--sfge-selection", type=Path, required=True)
    confirmation = subparsers.add_parser("confirmation")
    confirmation.add_argument("--standard-selection", type=Path, required=True)
    confirmation.add_argument("--anchored-selection", type=Path, required=True)
    confirmation.add_argument("--sfge-selection", type=Path, required=True)
    arguments = parser.parse_args()
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)

    if arguments.stage == "smoke":
        _write(
            CONFIG_ROOT / "smoke.json",
            "broad_cost_smoke",
            "runs/broad_cost/smoke",
            _smoke_variants(),
        )
    elif arguments.stage == "core":
        _write(
            CONFIG_ROOT / "development_core.json",
            "broad_cost_development_core",
            "runs/broad_cost/development_core",
            _core_variants(),
        )
    elif arguments.stage == "refine":
        _write(
            CONFIG_ROOT / "development_refinement.json",
            "broad_cost_development_refinement",
            "runs/broad_cost/development_refinement",
            _development_refinement(_load(arguments.core_selection)),
        )
    elif arguments.stage == "anchored":
        _write(
            CONFIG_ROOT / "development_anchored.json",
            "broad_cost_development_anchored",
            "runs/broad_cost/development_anchored",
            _anchored_screen(_load(arguments.core_selection)),
        )
    elif arguments.stage == "anchored-refine":
        _write(
            CONFIG_ROOT / "development_anchored_refinement.json",
            "broad_cost_development_anchored_refinement",
            "runs/broad_cost/development_anchored_refinement",
            _anchored_refinement(
                _load(arguments.core_selection),
                _load(arguments.anchored_selection),
            ),
        )
    elif arguments.stage == "sfge-samples":
        _write(
            CONFIG_ROOT / "development_sfge_samples.json",
            "broad_cost_development_sfge_samples",
            "runs/broad_cost/development_sfge_samples",
            _sfge_sample_refinement(_load(arguments.sfge_selection)),
        )
    elif arguments.stage == "confirmation":
        _write(
            CONFIG_ROOT / "confirmation.json",
            "broad_cost_confirmation",
            "runs/broad_cost/confirmation",
            _confirmation(
                _load(arguments.standard_selection),
                _load(arguments.anchored_selection),
                _load(arguments.sfge_selection),
            ),
        )
    else:  # pragma: no cover
        raise AssertionError(arguments.stage)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
