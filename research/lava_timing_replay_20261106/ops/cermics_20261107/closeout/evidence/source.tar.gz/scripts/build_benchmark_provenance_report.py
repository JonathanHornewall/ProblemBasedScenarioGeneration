"""Build benchmark/source-fidelity reporting from sealed confirmations."""

from __future__ import annotations

import argparse
from collections import defaultdict
from pathlib import Path

from proximal_spo.artifacts import write_json
from proximal_spo.benchmark_provenance_analysis import (
    collect_benchmark_provenance,
    render_benchmark_provenance_markdown,
)


def _panel(argument: str) -> tuple[str, Path]:
    name, separator, raw_path = argument.partition("=")
    if not separator or not name or not raw_path:
        raise argparse.ArgumentTypeError("panel must be NAME=PATH")
    return name, Path(raw_path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--panel", action="append", type=_panel, required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    arguments = parser.parse_args()
    panel_roots: dict[str, list[Path]] = defaultdict(list)
    for name, path in arguments.panel:
        panel_roots[name].append(path)
    summary = collect_benchmark_provenance(panel_roots)
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, summary)
    arguments.markdown_output.write_text(
        render_benchmark_provenance_markdown(summary), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
