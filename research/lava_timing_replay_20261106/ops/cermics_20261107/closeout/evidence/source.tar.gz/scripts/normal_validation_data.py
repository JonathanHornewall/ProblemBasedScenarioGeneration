"""Precompute one byte-frozen corrected bank per original data seed on CERMICS."""
import argparse
import copy
import hashlib
import os
from dataclasses import replace
from pathlib import Path

import numpy as np

from build_central_path_final import read, write
from frozen_campaign_data import FIELDS, data_key

REVISION = "observed_validation32_20260925_v1"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def original_job(job):
    result = copy.deepcopy(job)
    result["config"]["sizes"]["validation"] = result["original_sizes"]["validation"]
    result.pop("normal_validation_revision", None)
    return result


def prepare_bank(job, archive_banks, destination):
    from proximal_spo.data import SplitSizes
    from proximal_spo.external_benchmarks import load_external_benchmark
    from run_public_solver_free_matched import _hash_array
    old = original_job(job)
    source = archive_banks / (data_key(old) + ".npz")
    source_sha = digest(source)
    path = destination / (data_key(job) + ".npz")
    receipt = path.with_suffix(".json")
    if path.exists() or receipt.exists():
        raise RuntimeError("A prepared bank is immutable; refuse overwrite: " + str(path))
    with np.load(source, allow_pickle=False) as saved:
        arrays = {k: saved[k].copy() for k in saved.files}
    old_size = old["config"]["sizes"]["validation"]
    if old_size >= 32:
        for field in FIELDS:
            key = "validation__" + field
            if key in arrays:
                arrays[key] = arrays[key][:32].copy()
        policy = "first_32_archived_pairs"
    elif old_size == 24:
        sizes = {**job["original_sizes"], "train": max(job["original_sizes"]["train"], 100), "validation": 32}
        loaded = load_external_benchmark(job["route"], SplitSizes(**sizes),
            data_seed=job["config"]["seeds"]["data"],
            conditional_reference_samples=job["config"]["conditional_reference_samples"])
        for field in FIELDS:
            value = getattr(loaded.dataset.validation, field)
            if value is not None:
                arrays["validation__" + field] = value.copy()
        policy = "validation_only_regenerated_at_32_original_seed"
    else:
        raise ValueError("Unregistered validation-size correction")
    hashes = {s: {f: _hash_array(arrays[s + "__" + f]) for f in FIELDS if s + "__" + f in arrays}
              for s in ("train", "validation", "test")}
    with np.load(source, allow_pickle=False) as saved:
        for s in ("train", "test"):
            for f in FIELDS:
                k = s + "__" + f
                if k in arrays:
                    if _hash_array(saved[k]) != hashes[s][f]:
                        raise ValueError("Correction changed archived " + k)
    for s, count in job["config"]["sizes"].items():
        assert arrays[s + "__contexts"].shape[0] == count
    destination.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".partial")
    with temporary.open("xb") as stream:
        np.savez_compressed(stream, **arrays)
    temporary.replace(path)
    if digest(source) != source_sha:
        raise ValueError("Original bank changed during preparation")
    result = {"revision": REVISION, "key": data_key(job), "bank_sha256": digest(path),
        "source_bank": str(source), "source_bank_sha256": source_sha,
        "route": job["route"], "data_seed": job["config"]["seeds"]["data"],
        "sizes": job["config"]["sizes"], "source_validation_size": old_size, "policy": policy,
        "train_test_bytes_unchanged": True, "array_hashes": hashes,
        "selection_validation_target": "physical_costs", "test_scores_read": False}
    write(receipt, result)
    return result


def restore_ready_dataset(job, loaded):
    location = os.environ.get("CENTRAL_PATH_FROZEN_DATA")
    if not location:
        raise RuntimeError("Corrected runs require preverified frozen banks")
    path = Path(location) / (data_key(job) + ".npz")
    receipt = read(path.with_suffix(".json"))
    if (receipt["revision"] != REVISION or not receipt["train_test_bytes_unchanged"]
            or receipt["sizes"] != job["config"]["sizes"] or digest(path) != receipt["bank_sha256"]):
        raise RuntimeError("Corrected input identity failed")
    with np.load(path, allow_pickle=False) as saved:
        splits = {s: replace(getattr(loaded.dataset, s), **{
            f: saved[s + "__" + f] for f in FIELDS if s + "__" + f in saved.files})
                  for s in ("train", "validation", "test")}
    if any(split.size != job["config"]["sizes"][s] for s, split in splits.items()):
        raise RuntimeError("Corrected bank split sizes differ from frozen protocol")
    return replace(loaded, dataset=replace(loaded.dataset, **splits), provenance={
        **loaded.provenance, "normal_validation32": receipt,
        "frozen_data": {"key": data_key(job), "sha256": receipt["bank_sha256"]}})


def bank_jobs(manifest):
    unique = {}
    for j in manifest["jobs"]:
        info = manifest["cells"][j["cell"]]
        for seeds in [j["config"]["seeds"], *info["refinement_seeds"], *info["confirmation_seeds"]]:
            job = copy.deepcopy(j)
            job["config"]["seeds"] = seeds
            unique.setdefault(data_key(job), job)
    return [unique[k] for k in sorted(unique)]


if __name__ == "__main__":
    from concurrent.futures import ProcessPoolExecutor
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--archive-banks", type=Path, required=True)
    p.add_argument("--workers", type=int, default=1)
    a = p.parse_args()
    jobs = bank_jobs(read(a.root / "screen.json"))
    if not 1 <= a.workers <= 8:
        raise ValueError("Input preparation is limited to eight workers")
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        futures = [pool.submit(prepare_bank, j, a.archive_banks, a.root / "frozen_data") for j in jobs]
        results = [f.result() for f in futures]
    write(a.root / "input_preparation_verification.json", {"status": "complete", "banks": results,
        "count": len(results), "train_test_bytes_unchanged": True, "validation_size": 32})
    print({"prepared_banks": len(results), "status": "complete"})
