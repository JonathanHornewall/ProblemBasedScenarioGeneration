"""Restore memory-censored screening comparisons with additive job identities."""
import argparse
import copy
import hashlib
import time
from pathlib import Path
from build_central_path_final import read, write, sha


def activate(root):
    target=root/'spo_memory_recovery.json'
    if target.exists():
        return read(target)
    probes=[]
    for route in ['lava_random_lp_100x200_released_code','lava_random_lp_400x50_released_code']:
        rows={v:read(root/'spo_memory_preflight'/(route+'_'+v+'.json')) for v in ['legacy','fixed']}
        for key in ['loss_gradient_sha256','weights_sha256','frozen_data']:
            if rows['legacy'][key]!=rows['fixed'][key]:raise RuntimeError('Memory parity check failed: '+key)
        if rows['fixed']['late_rss_growth_mib']>8:raise RuntimeError('Memory still grows')
        probes.append({'route':route,'records':rows})
    preserved=read(root/'validation_expansion.json')['preserved_files']
    changed=[name for name,h in preserved.items() if hashlib.sha256((root/name).read_bytes()).hexdigest()!=h]
    if changed:raise RuntimeError('Archived activation files changed: '+str(changed[:5]))
    originals=read(root/'screen.json')['jobs']+read(root/'additional_screen.json')['jobs']
    replacements=[];source_hashes={}
    for job in originals:
        if job['method']!='spo_plus' or job['config']['sizes']['train']!=800 or job['route'] not in [p['route'] for p in probes]:continue
        path=root/'results/receipts'/(job['id']+'.json')
        record=read(path)
        if record['status']=='complete':continue
        if record.get('error')!='memory_cap':raise RuntimeError('Non-memory failure needs separate review: '+job['id'])
        new=copy.deepcopy(job)
        new.update(id=job['id']+'__memory_repair_v1',execution_repair='memory_repair_v1',recovery_of=job['id'])
        new['config']['name']=new['id'];replacements.append(new)
        source_hashes[str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
    if len({(j['cell'],j['method']) for j in replacements})!=4:raise RuntimeError('Unexpected affected groups')
    execution=read(root/'execution.json')
    archive=root/'spo_memory_preflight'
    for name in ['refinement.json','confirmation.json']:
        write(archive/(name.removesuffix('.json')+'_before.json'),read(root/name))
    result={'repair_id':'memory_repair_v1','created_unix':time.time(),'jobs':replacements,
        'reason':'Break fresh HiGHS callback cycles; restore the original candidate comparison after memory censorship',
        'scientific_settings_unchanged':True,'cloud_limits_unchanged':True,'cermics_only':True,
        'execution_prefix_length':len(execution['jobs']),'execution_prefix_sha256':sha(execution['jobs']),
        'preserved_activation_files':len(preserved),'original_failed_receipt_sha256':source_hashes,
        'diagnostic_records':probes,'prior_selections_preserved':True}
    write(target,result)
    write(root/'spo_memory_repair.json',{'status':'recovering','updated_unix':time.time(),
        'repair_id':result['repair_id'],'screen_recovery_count':len(replacements),'affected_groups':4,
        'cloud_limits_unchanged':True,'scientific_limits_unchanged':True,
        'mac_timing_hold':'Await complete restored selections and confirmations, with local frozen data'})
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args()
    m=activate(a.root);print({'repair_id':m['repair_id'],'screen_recoveries':len(m['jobs']),'preserved_files':m['preserved_activation_files']})
