"""Run independent configs with parent-owned campaign checkpointing."""

from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing
import os
import sys
import traceback
from collections import deque
from concurrent.futures import FIRST_COMPLETED, Future, ProcessPoolExecutor, wait
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import source_sha256, write_json
from proximal_spo.config import RunSpec
from proximal_spo.runner import run_experiment


def _deep_merge(
    base: dict[str, object], override: dict[str, object]
) -> dict[str, object]:
    merged = dict(base)
    for key, value in override.items():
        current = merged.get(key)
        if isinstance(current, dict) and isinstance(value, dict):
            merged[key] = _deep_merge(current, value)
        else:
            merged[key] = value
    return merged


def _campaign_specs(
    payload: dict[str, object], repo_root: Path
) -> list[tuple[str, RunSpec, str]]:
    has_configs = "configs" in payload
    has_variants = "variants" in payload or "base" in payload
    if has_configs == has_variants:
        raise ValueError(
            "campaign must contain exactly one of configs or base plus variants"
        )
    result: list[tuple[str, RunSpec, str]] = []
    if has_configs:
        configs = payload["configs"]
        if not isinstance(configs, list) or not all(
            isinstance(item, str) for item in configs
        ):
            raise ValueError("configs must be a list of paths")
        for relative in configs:
            config_path = (repo_root / relative).resolve()
            spec = RunSpec.load(config_path)
            digest = hashlib.sha256(config_path.read_bytes()).hexdigest()[:12]
            result.append((relative, spec, digest))
        return result
    base = payload.get("base")
    variants = payload.get("variants")
    if not isinstance(base, dict) or not isinstance(variants, list):
        raise ValueError("templated campaign requires object base and list variants")
    for index, variant in enumerate(variants):
        if not isinstance(variant, dict):
            raise ValueError("each campaign variant must be an object")
        expanded = _deep_merge(base, variant)
        spec = RunSpec.from_dict(expanded)
        canonical = json.dumps(
            spec.to_dict(), sort_keys=True, separators=(",", ":")
        ).encode()
        digest = hashlib.sha256(canonical).hexdigest()[:12]
        result.append((f"variant:{index}:{spec.name}", spec, digest))
    return result


def _execute_run(
    spec_payload: dict[str, Any], run_directory: str, repo_root: str
) -> dict[str, object]:
    """Run one isolated experiment and return only compact parent metadata."""

    started = datetime.now(UTC).isoformat()
    spec = RunSpec.from_dict(spec_payload)
    result = run_experiment(
        spec,
        run_directory=Path(run_directory),
        repo_root=Path(repo_root),
        # Parallel epoch logs interleave and add substantial terminal overhead.
        # Per-epoch learning curves remain durably recorded by the child.
        progress=False,
    )
    return {
        "worker_pid": os.getpid(),
        "worker_started_at_utc": started,
        "worker_finished_at_utc": datetime.now(UTC).isoformat(),
        "test_mean_regret": (
            None if result.test is None else result.test.mean_regret
        ),
    }


def _append_receipt(
    *,
    progress: dict[str, object],
    progress_path: Path,
    receipt: dict[str, object],
    name: str,
) -> None:
    receipt["finished_at_utc"] = datetime.now(UTC).isoformat()
    runs = progress.get("runs")
    if not isinstance(runs, list):
        raise ValueError(f"malformed campaign runs in {progress_path}")
    runs.append(receipt)
    write_json(progress_path, progress)
    print(f"END {name}: {receipt['status']}", flush=True)


def _prepare_receipt(
    *,
    source: str,
    spec: RunSpec,
    digest: str,
    code_digest: str,
    run_root: Path,
    repo_root: Path,
) -> tuple[Path, dict[str, object]]:
    run_directory = run_root / f"{spec.name}_{digest}_{code_digest[:8]}"
    return run_directory, {
        "config": source,
        "expanded_config": spec.to_dict(),
        "source_sha256": code_digest,
        "run_directory": str(run_directory.relative_to(repo_root)),
        "started_at_utc": datetime.now(UTC).isoformat(),
    }


def _complete_existing_run(
    run_directory: Path, receipt: dict[str, object]
) -> bool:
    status_path = run_directory / "status.json"
    if not status_path.exists():
        return False
    status = json.loads(status_path.read_text(encoding="utf-8"))
    if status.get("status") != "complete":
        raise FileExistsError(
            f"incomplete run directory already exists: {run_directory}"
        )
    receipt["status"] = "skipped_complete"
    return True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--continue-on-failure", action="store_true")
    parser.add_argument(
        "--jobs",
        type=int,
        default=1,
        help="independent experiment processes; use 3 on the 14-core host",
    )
    parser.add_argument(
        "--only",
        action="append",
        default=[],
        help="run only the named expanded variant; may be repeated",
    )
    arguments = parser.parse_args()
    if arguments.jobs <= 0:
        parser.error("--jobs must be positive")
    campaign_path = arguments.campaign.resolve()
    payload = json.loads(campaign_path.read_text(encoding="utf-8"))
    repo_root = Path(__file__).resolve().parents[1]
    run_root = (repo_root / payload["run_root"]).resolve()
    run_root.mkdir(parents=True, exist_ok=True)
    code_digest = source_sha256(repo_root)
    campaign_digest = hashlib.sha256(campaign_path.read_bytes()).hexdigest()[:10]
    progress_path = run_root / (
        f"campaign_progress_{campaign_digest}_{code_digest[:12]}.json"
    )
    invocation_started = datetime.now(UTC).isoformat()
    if progress_path.exists():
        loaded = json.loads(progress_path.read_text(encoding="utf-8"))
        if not isinstance(loaded, dict) or loaded.get("source_sha256") != code_digest:
            raise ValueError(f"invalid campaign progress receipt: {progress_path}")
        progress: dict[str, object] = loaded
    else:
        progress = {
            "campaign": payload.get("name", campaign_path.stem),
            "source_sha256": code_digest,
            "started_at_utc": invocation_started,
            "invocations": [],
            "runs": [],
        }
    invocations = progress.get("invocations")
    if not isinstance(invocations, list):
        raise ValueError(f"malformed campaign invocations in {progress_path}")
    invocation: dict[str, object] = {
        "started_at_utc": invocation_started,
        "requested_variants": list(arguments.only),
        "jobs": arguments.jobs,
        "execution_mode": "sequential" if arguments.jobs == 1 else "process_pool",
    }
    invocations.append(invocation)
    write_json(progress_path, progress)
    expanded_specs = _campaign_specs(payload, repo_root)
    if arguments.only:
        requested = set(arguments.only)
        expanded_specs = [item for item in expanded_specs if item[1].name in requested]
        found = {item[1].name for item in expanded_specs}
        if found != requested:
            raise ValueError(f"unknown --only variants: {sorted(requested - found)}")
    prepared: list[
        tuple[str, RunSpec, Path, dict[str, object]]
    ] = []
    directories: set[Path] = set()
    for source, spec, digest in expanded_specs:
        run_directory, receipt = _prepare_receipt(
            source=source,
            spec=spec,
            digest=digest,
            code_digest=code_digest,
            run_root=run_root,
            repo_root=repo_root,
        )
        if run_directory in directories:
            raise ValueError(f"duplicate campaign run directory: {run_directory}")
        directories.add(run_directory)
        prepared.append((spec.name, spec, run_directory, receipt))

    failures = 0
    if arguments.jobs == 1:
        for name, spec, run_directory, receipt in prepared:
            print(f"BEGIN {name}", flush=True)
            try:
                if not _complete_existing_run(run_directory, receipt):
                    result = run_experiment(
                        spec,
                        run_directory=run_directory,
                        repo_root=repo_root,
                        progress=True,
                    )
                    receipt["status"] = "complete"
                    receipt["test_mean_regret"] = (
                        None if result.test is None else result.test.mean_regret
                    )
            except BaseException as error:
                failures += 1
                receipt["status"] = "failed"
                receipt["error_type"] = type(error).__name__
                receipt["error"] = str(error)
                traceback.print_exc()
            _append_receipt(
                progress=progress,
                progress_path=progress_path,
                receipt=receipt,
                name=name,
            )
            if failures and not arguments.continue_on_failure:
                break
    else:
        context = multiprocessing.get_context("spawn")
        futures: dict[
            Future[dict[str, object]], tuple[str, dict[str, object]]
        ] = {}
        queue = deque(prepared)
        abort = False
        cancelled = 0
        with ProcessPoolExecutor(
            max_workers=min(arguments.jobs, max(1, len(prepared))),
            mp_context=context,
        ) as executor:
            while queue or futures:
                while queue and len(futures) < arguments.jobs and not abort:
                    name, spec, run_directory, receipt = queue.popleft()
                    print(f"BEGIN {name}", flush=True)
                    try:
                        if _complete_existing_run(run_directory, receipt):
                            _append_receipt(
                                progress=progress,
                                progress_path=progress_path,
                                receipt=receipt,
                                name=name,
                            )
                            continue
                    except BaseException as error:
                        failures += 1
                        receipt["status"] = "failed"
                        receipt["error_type"] = type(error).__name__
                        receipt["error"] = str(error)
                        traceback.print_exc()
                        _append_receipt(
                            progress=progress,
                            progress_path=progress_path,
                            receipt=receipt,
                            name=name,
                        )
                        if not arguments.continue_on_failure:
                            abort = True
                        continue
                    future = executor.submit(
                        _execute_run,
                        spec.to_dict(),
                        str(run_directory),
                        str(repo_root),
                    )
                    futures[future] = (name, receipt)
                if not futures:
                    break
                done, _ = wait(tuple(futures), return_when=FIRST_COMPLETED)
                failed_now = False
                for future in done:
                    name, receipt = futures.pop(future)
                    try:
                        worker = future.result()
                        receipt.update(worker)
                        receipt["status"] = "complete"
                    except BaseException as error:
                        failures += 1
                        failed_now = True
                        receipt["status"] = "failed"
                        receipt["error_type"] = type(error).__name__
                        receipt["error"] = str(error)
                        traceback.print_exception(error)
                    _append_receipt(
                        progress=progress,
                        progress_path=progress_path,
                        receipt=receipt,
                        name=name,
                    )
                if failed_now and not arguments.continue_on_failure:
                    abort = True
                    for future in list(futures):
                        if not future.cancel():
                            continue
                        name, receipt = futures.pop(future)
                        cancelled += 1
                        receipt["status"] = "cancelled_after_failure"
                        _append_receipt(
                            progress=progress,
                            progress_path=progress_path,
                            receipt=receipt,
                            name=name,
                        )
        invocation["cancelled_count"] = cancelled
        invocation["unstarted_count"] = len(queue)
    invocation["finished_at_utc"] = datetime.now(UTC).isoformat()
    invocation["status"] = (
        "complete_with_failures"
        if failures and arguments.continue_on_failure
        else "failed" if failures else "complete"
    )
    invocation["failure_count"] = failures
    progress["last_finished_at_utc"] = invocation["finished_at_utc"]
    write_json(progress_path, progress)
    return 1 if failures and not arguments.continue_on_failure else 0


if __name__ == "__main__":
    sys.exit(main())
