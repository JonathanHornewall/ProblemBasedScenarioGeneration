"""Separately labeled two-epoch production-interface checks, never science."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from importlib.metadata import version
import os
from pathlib import Path
import subprocess
import time

from simplified_campaign import (CPS, WCP, METHODS, SMALLEST, applicable, base_method,
    digest, environment, grid, make_job, manifest, read, write)


def check(root, job):
    path = root/'preflight/jobs'/(job['id']+'.json')
    write(path, manifest(job), immutable=True)
    log = root/'preflight/logs'/(job['id']+'.log'); log.parent.mkdir(parents=True, exist_ok=True)
    with log.open('w') as f:
        result = subprocess.run([str(root/'venv/bin/python'), str(root/'code/scripts/run_central_path_final.py'),
            '--manifest', str(path), '--job-index', '0', '--output-root', str(root/'preflight/results')],
            env=environment(root), stdout=f, stderr=subprocess.STDOUT, timeout=1200)
    receipt = read(root/'preflight/results/receipts'/(job['id']+'.json'))
    if result.returncode or receipt['status'] != 'complete' or not receipt['smoke_only']:
        raise RuntimeError('Interface preflight failed: ' + job['id'] + ' ' + str(receipt.get('error')))
    summary = receipt['summary']
    if summary['epochs_completed'] != 2: raise RuntimeError('Preflight epoch count differs')
    if job['stage'] == 'timing':
        if summary['test'] is not None or summary['best_validation'] is not None:
            raise RuntimeError('Timing path accessed held-out evaluation')
    else:
        best = receipt['curve'][0]
        for row in receipt['curve'][1:]:
            if row['selection_score'] < best['selection_score'] - 1e-8:
                best = row
        if summary['best_epoch'] != best['epoch']:
            raise RuntimeError('Per-fit validation checkpoint selection differs')
    if job['stage'] != 'confirmation' and receipt.get('test_access'):
        raise RuntimeError('Development/timing preflight opened a test bank')
    if job['method'] == WCP and not summary['objective_receipt']['whole_surrogate_weighted']:
        raise RuntimeError('WiSE CP-SPO routed to an unweighted objective')
    if job.get('interface_correction') and job['base_method'] in ('mse', 'spo_plus'):
        if job['stage'] != 'timing' and summary['evaluation_oracle_class'] != 'ColdHighsBatch':
            raise RuntimeError('Historical physical-head deployment oracle changed')
        if job['base_method'] == 'spo_plus' and summary['training_oracle_class'] != 'ColdHighsOptModel':
            raise RuntimeError('Historical cold SPO+ training oracle changed')
    return {'id': job['id'], 'method': job['method'], 'route': job['route'],
        'stage': job['stage'], 'status': receipt['status'], 'test_access': receipt['test_access']}


def run(root, workers, methods=None):
    if not os.environ.get('SLURM_JOB_ID') or not 1 <= workers <= 4:
        raise RuntimeError('Interface preflight requires bounded Slurm execution')
    if version('pyepo') != '1.0.2': raise RuntimeError('Pinned PyEPO runtime differs')
    plan = read(root/'PLAN.json')
    jobs = []
    for method in METHODS:
        if methods and method not in methods: continue
        for route in SMALLEST.values():
            if not applicable(method, route): continue
            choices = next((q for q in grid(method) if q['learning_rate'] == .001 and
                           (q.get('alpha', .3) == .3) and q.get('rho', .5) == .5 and
                           q.get('kappa', 1.) == 1. and q.get('contraction', 'rational') == 'rational'), grid(method)[0])
            jobs.append(make_job(plan['templates'][base_method(method)], method, route,
                plan['cells'][route]['screen'], choices, stage='preflight', preflight=True))
    # Check both maintained fitting engines' sealed-test access and timing path.
    for method in (WCP, 'wise_spo_plus'):
        if methods and method not in methods: continue
        source = next(j for j in jobs if j['method'] == method)
        for stage in ('confirmation', 'timing'):
            jobs.append(make_job(source, method, source['route'], source['config']['seeds'],
                source['choices'], stage=stage, preflight=True))
    if methods:
        for j in jobs:
            j['interface_correction'] = 'cold_physical_heads_20261020_v2'
            j['config'].pop('name')
            j['id'] = 'simplified_preflight_fix__' + digest(j)[:32]
            j['config']['name'] = j['id']
    started = time.time()
    with ThreadPoolExecutor(workers) as pool:
        checks = list(pool.map(lambda j: check(root, j), jobs))
    filename = 'COLD_HEAD_CORRECTION_VERIFICATION.json' if methods else 'VERIFICATION.json'
    write(root/'preflight'/filename, {'status': 'passed', 'pyepo_version': version('pyepo'),
        'fit_checks': len(checks), 'checks': checks, 'diagnostic_only': True,
        'wall_seconds': time.time()-started, 'source_commit': read(root/'source_receipt.json')['git_commit']}, immutable=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--root', type=Path, required=True)
    p.add_argument('--workers', type=int, default=4)
    p.add_argument('--methods', nargs='+', choices=METHODS)
    a = p.parse_args(); run(a.root.resolve(), a.workers, a.methods)
