#!/usr/bin/env python3
"""Reproducible, single-fit timing jobs for the seven Atlanta baselines.

The source losses are imported, not reimplemented. WISE calls the existing
WISEObjective's signal directly. Each fit has its own preprocessing and reports
training separately from final validation. No test oracle is opened.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.metadata
import json
import math
import os
import platform
import resource
import sys
import time
import traceback
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
METHODS = ("mse", "spo_plus", "pfyl", "nce", "cave", "lava", "wise")


def write(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parameters(route: str, method: str) -> dict:
    knapsack = any(s in route for s in ("knapsack", "kp50", "mdkp"))
    if method == "cave":
        if knapsack:
            return {"loss_type": "inner_cave", "solver": "clarabel"}
        return {
            "loss_type": "exact_cave",
            "solver": "nnls" if "shortest_path" in route or "topk" in route else "clarabel",
        }
    if method == "lava":
        return {"threshold": -0.1}
    if method == "pfyl":
        return {"sigma": 0.1 if "random_lp" in route else 1.0, "n_samples": 1}
    if method == "nce":
        return {"solve_ratio": 0.05}
    return {}


def build(args: argparse.Namespace) -> None:
    if not math.isfinite(args.lava_vertex_tolerance) or args.lava_vertex_tolerance < 0:
        raise ValueError("LAVA vertex tolerance must be finite and nonnegative")
    original = json.loads(args.source_manifest.read_text())
    routes: dict[str, list[dict]] = {}
    for entry in original["entries"]:
        routes.setdefault(entry["route_id"], []).append(entry)
    jobs = []
    # Interleave methods and routes so slow geometry cannot starve all others.
    for repeat in range(3):
        for route, entries in routes.items():
            for method in METHODS:
                entry = copy.deepcopy(entries[0])
                for seed in ("initialization", "shuffle", "perturbation"):
                    entry["seeds"][seed] = entries[repeat]["seeds"][seed]
                entry["training"].update(
                    epochs=300, learning_rate=0.001, validation_interval=300,
                    validation_epochs=[300], selection_mode="last", torch_threads=1,
                )
                jobs.append({
                    "id": f"{route}__{method}__r{repeat + 1}",
                    "method": method, "repeat": repeat + 1, "entry": entry,
                    "parameters": parameters(route, method),
                })
                if method == "lava" and args.lava_vertex_tolerance:
                    jobs[-1]["parameters"]["vertex_tolerance"] = args.lava_vertex_tolerance
    write(args.output, {
        "kind": "atlanta_full_training_timing", "version": 2,
        "source_manifest_sha256": digest(args.source_manifest),
        "epochs": 300, "repeats": 3, "methods": list(METHODS),
        "routes": list(routes), "expected_jobs": len(jobs),
        "protocol": {
            "purpose": "runtime measurement; no hyperparameter or model selection",
            "fixed_data_across_methods_and_restarts": True,
            "restart_seeds": "first three manifest initialization/shuffle/perturbation seeds",
            "data_seed": "first manifest entry per route",
            "training_samples": "full manifest training split",
            "train_on_continuous_relaxation_for_mips": True,
            "validation": "one final sweep with original integrality",
            "test_oracle_access": False,
            "learning_rate": 0.001, "optimizer": "AdamW",
            "cost_coordinates": "existing Atlanta train-split standardization",
            "cave_variants": "released LAVA LP/SP/knapsack choices; CFL uses LP Clarabel; top-k uses NNLS",
            "optimization_backend": "HiGHS",
            "geometry": "HiGHS simplex basis adapter with unchanged upstream LAVA enumeration and disclosed row/basis/TNP recovery",
            "upstream_lava_degenerate_enumeration_cap": 250,
            "lava_vertex_coalescing_tolerance": args.lava_vertex_tolerance,
            "lava_source_exact_float_duplicate_removal_preserved": args.lava_vertex_tolerance == 0,
        },
        "jobs": jobs,
    })
    print(json.dumps({"manifest": str(args.output), "jobs": len(jobs), "epochs": 300}))


def run(args: argparse.Namespace) -> None:
    started = time.perf_counter()
    manifest = json.loads(args.manifest.read_text())
    job = manifest["jobs"][args.job_index]
    out = args.output_root / "receipts" / f"{job['id']}.json"
    progress = args.output_root / "progress" / f"{job['id']}.json"
    if out.exists():
        raise RuntimeError(f"Refusing to overwrite existing receipt: {out}")
    record = {
        "kind": "atlanta_baseline_timing_fit", "job_id": job["id"],
        "job_index": args.job_index, "method": job["method"],
        "route": job["entry"]["route_id"], "repeat": job["repeat"],
        "entry": job["entry"], "parameters": job["parameters"],
        "manifest_sha256": digest(args.manifest), "runner_sha256": digest(Path(__file__)),
        "host": platform.node(), "platform": platform.platform(), "python": platform.python_version(), "pid": os.getpid(),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "cpu_threads": 1, "epochs_requested": args.epochs or 300,
        "epochs_completed": 0, "timing_seconds": {}, "epochs": [],
        "status": "running", "phase": "imports", "test_oracle_access": False,
        "smoke_only": bool(args.smoke),
    }

    def update(phase: str) -> None:
        record["phase"] = phase
        record["elapsed_seconds"] = time.perf_counter() - started
        record["updated_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        write(progress, record)

    def measure(name: str, func):
        update(name)
        t = time.perf_counter()
        value = func()
        record["timing_seconds"][name] = time.perf_counter() - t
        update(name + "_complete")
        return value

    solver = None
    wise = None
    try:
        update("imports")
        import numpy as np
        import torch
        from torch.utils.data import DataLoader, TensorDataset
        import run_public_solver_free_matched as matched
        from dfl_extensions_lab.benchmarks import SplitSizes
        from proximal_spo.external_benchmarks import load_external_benchmark
        from proximal_spo.models import ModelSpec, StandardizedMLP, input_statistics
        from pyepo.data.dataset import optDataset
        from utils.create_loss_func import create_loss_func

        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        record["versions"] = {
            package: importlib.metadata.version(package)
            for package in ("torch", "pyepo", "numpy", "scipy", "cvxpy", "clarabel", "highspy")
        }
        record["optimization_backend"] = "HiGHS"
        record["source"] = {
            "public_repository": str(matched.PUBLIC_REPO),
            "public_commit": matched._public_commit(matched.PUBLIC_REPO),
            "public_tree_sha256": matched._tree_hash(matched.PUBLIC_REPO),
            "adapter_sha256": digest(Path(matched.__file__)),
            "highs_adapter_sha256": digest(ROOT / "src/proximal_spo/public_highs.py"),
            "external_commit": matched._public_commit(matched.EXTERNAL_SRC.parent)
            if (matched.EXTERNAL_SRC.parent / ".git").exists() else None,
        }
        if os.environ.get("ATLANTA_SOURCE_MANIFEST"):
            source_file = Path(os.environ["ATLANTA_SOURCE_MANIFEST"])
            packaged = json.loads(source_file.read_text())
            record["source"].update(
                external_commit=packaged["external_commit"],
                project_commit=packaged["project_commit"],
                verified_source_manifest_sha256=digest(source_file),
            )
        record["timing_seconds"]["imports_and_provenance"] = time.perf_counter() - started
        entry = copy.deepcopy(job["entry"])
        method = job["method"]
        if args.smoke:
            entry["sizes"] = {"train": 4, "validation": 2, "test": 1}
            record["smoke_only"] = True
        sizes = entry["sizes"]
        matched._seed(int(entry["seeds"]["initialization"]))
        loaded = measure("data_loading", lambda: load_external_benchmark(
            entry["benchmark_id"], SplitSizes(**sizes),
            data_seed=entry["seeds"]["data"],
            conditional_reference_samples=entry["conditional_reference_samples"],
        ))
        problem = loaded.problem
        costs = np.asarray(loaded.dataset.train.physical_costs, dtype=np.float64)
        contexts = np.asarray(loaded.dataset.train.contexts, dtype=np.float64)
        record["dataset"] = {
            "sizes": sizes, "variables": problem.variable_count,
            "constraints": problem.constraint_count,
            "integer_variables": int(np.sum(problem.integrality)),
            "train_context_sha256": matched._hash_array(contexts),
            "train_cost_sha256": matched._hash_array(costs),
            "validation_context_sha256": matched._hash_array(loaded.dataset.validation.contexts),
        }

        # MSE/WISE need no optimization labels during fitting.
        public_model = None
        train = None
        if method not in ("mse", "wise"):
            relaxed = problem.continuous_relaxation(name=problem.name + ".timing_training")
            public_model = measure("optimization_model_setup", lambda: matched._fixed_model(relaxed, integer=False))
            if method == "cave":
                train = measure("binding_geometry", lambda: matched.BindingOnlyDataset(public_model, contexts, costs))
            elif method == "lava":
                from proximal_spo.public_highs import HighsLAVADataset
                def geometry_progress(count, dataset):
                    record["geometry_samples_processed"] = count
                    record["adjacency_tnp_retry_count"] = dataset.adjacency_tnp_retry_count
                    update("adjacent_geometry")
                train = measure("adjacent_geometry", lambda: HighsLAVADataset(
                    public_model, contexts, costs, public_repo=matched.PUBLIC_REPO,
                    progress=geometry_progress,
                    vertex_tolerance=float(job["parameters"].get("vertex_tolerance", 0.0))))
                record["geometry"] = {
                    "solver_backend": "HiGHS",
                    "public_geometry_source_sha256": train.public.source_sha256,
                    "structural_basis_completions": train.basis_completion_count,
                    "tied_optimum_anchor_reselections": train.anchor_reselection_count,
                    "tnp_assertion_retries": train.adjacency_tnp_retry_count,
                    "redundant_row_reduction": bool(train.geometry_row_reduction),
                    "upstream_degenerate_basis_iteration_cap": 250,
                    "adjacent_vertex_counts": [int(len(v)) for v in train.adjacent_verts],
                    "source_exact_vertex_counts": train.exact_vertex_counts,
                    "numerical_vertex_coalescing_tolerance": train.vertex_tolerance,
                    "source_exact_float_duplicate_removal_preserved": train.vertex_tolerance == 0,
                    "completeness_certified": False,
                }
            else:
                train = measure("training_optimal_labels", lambda: optDataset(public_model, contexts, costs))

        update("model_and_loss_setup")
        t = time.perf_counter()
        model = matched._make_model(entry, contexts, costs)
        mean = model.cost_mean.detach().cpu().numpy().astype(np.float64)
        scale = model.cost_scale.detach().cpu().numpy().astype(np.float64)
        beta = (costs - mean) / scale
        if method == "wise":
            from proximal_spo.objectives import WISEObjective
            from proximal_spo.problem import PartialCostInterface
            interface = PartialCostInterface(problem, mean, np.diag(scale), name="timing.standardized")
            wise = WISEObjective(interface, workers=1, random_seed=entry["seeds"]["structural"])
            labels = wise.labels(beta)
            bias = labels.sum(axis=0) / max(float(np.linalg.norm(labels, axis=1).sum()), 1e-12)
            im, isc = input_statistics(contexts)
            spec = ModelSpec(**entry["model"])
            model = StandardizedMLP(contexts.shape[1], wise.output_dimension, spec,
                                    input_mean=im, input_scale=isc, output_bias=bias)
            record["wise_source_sha256"] = digest(ROOT / "src/proximal_spo/objectives.py")
            record["wise_augmented_label"] = wise.augmented
            loss = None
        else:
            params = dict(job["parameters"])
            params.pop("vertex_tolerance", None)
            loss = create_loss_func(params.pop("loss_type", method), public_model, params, train)
            if method == "pfyl":
                loss.rnd = np.random.RandomState(entry["seeds"]["perturbation"])
        record["loss_class"] = "proximal_spo.objectives.WISEObjective" if wise else f"{type(loss).__module__}.{type(loss).__name__}"
        record["model_parameters"] = sum(p.numel() for p in model.parameters())

        batch_size = min(int(entry["training"]["batch_size"]), len(contexts))
        generator = torch.Generator().manual_seed(entry["seeds"]["shuffle"])
        if method in ("cave", "lava"):
            from proximal_spo.public_highs import public_geometry
            collate_fn_2 = public_geometry(str(matched.PUBLIC_REPO)).collate_fn_2
            loader = DataLoader(train, batch_size=batch_size, shuffle=True,
                                generator=generator, collate_fn=collate_fn_2)
        elif method in ("mse", "wise"):
            dataset = TensorDataset(torch.as_tensor(contexts, dtype=torch.float32),
                                    torch.as_tensor(beta, dtype=torch.float64))
            loader = DataLoader(dataset, batch_size=batch_size, shuffle=True, generator=generator)
        else:
            loader = DataLoader(train, batch_size=batch_size, shuffle=True, generator=generator)
        optimizer = torch.optim.AdamW(model.parameters(), lr=entry["training"]["learning_rate"],
                                     weight_decay=entry["training"].get("weight_decay", 1e-5))
        record["timing_seconds"]["model_and_loss_setup"] = time.perf_counter() - t
        update("training")
        train_started = time.perf_counter()
        train_seconds = 0.0
        for epoch in range(1, record["epochs_requested"] + 1):
            t = time.perf_counter()
            model.train()
            total_loss = 0.0
            count = 0
            for batch in loader:
                x = batch[0]
                optimizer.zero_grad(set_to_none=True)
                if method == "wise":
                    output = model(x)
                    signal = wise.signal(output.detach().cpu().numpy(), SimpleNamespace(coefficients=batch[1].numpy()))
                    value = float(np.mean(signal.values))
                    gradient = torch.as_tensor(signal.output_gradient / len(x), dtype=output.dtype)
                    if not np.isfinite(value) or not torch.isfinite(gradient).all():
                        raise RuntimeError(f"non-finite WISE signal at epoch {epoch}")
                    output.backward(gradient)
                else:
                    if method == "mse":
                        value = loss(model(x), batch[1].to(dtype=torch.float32))
                    else:
                        pred = matched._physical_prediction(model, x)
                        if method == "spo_plus":
                            _, c, w, z = batch
                            value = loss(pred, c, w, z)
                        elif method in ("pfyl", "nce"):
                            value = loss(pred, batch[2])
                        elif method == "cave":
                            value = loss(pred, batch[6])
                        else:
                            value = loss(pred, batch[7], batch[4], -1.0)
                    if not torch.isfinite(value):
                        raise RuntimeError(f"non-finite {method} loss at epoch {epoch}")
                    value.backward()
                    value = float(value.detach())
                torch.nn.utils.clip_grad_norm_(model.parameters(), entry["training"].get("gradient_clip", 10.0))
                optimizer.step()
                total_loss += value * len(x)
                count += len(x)
            seconds = time.perf_counter() - t
            train_seconds += seconds
            record["epochs_completed"] = epoch
            record["epochs"].append({"epoch": epoch, "seconds": seconds, "mean_loss": total_loss / count})
            record["timing_seconds"]["training"] = train_seconds
            update("training")
        record["timing_seconds"]["training_including_receipt_io"] = time.perf_counter() - train_started

        from proximal_spo.oracles import PersistentLPSolver
        solver = measure("validation_solver_setup", lambda: PersistentLPSolver(
            problem, random_seed=entry["seeds"]["structural"]))
        val = loaded.dataset.validation
        reference = measure("validation_reference", lambda: solver.solve_many(val.conditional_mean_costs).objectives)

        def evaluate():
            model.eval()
            with torch.no_grad():
                if method == "wise":
                    outputs = model(torch.as_tensor(val.contexts, dtype=torch.float32)).numpy()
                    pred = wise.predicted_physical_costs(outputs)
                else:
                    pred = matched._physical_prediction(model, val.contexts).numpy()
            deployed = solver.solve_many(pred)
            regret = np.sum(val.conditional_mean_costs * deployed.decisions, axis=1) - reference
            tolerance = 5e-7 * (1 + np.abs(reference) + np.abs(val.conditional_mean_costs).sum(axis=1))
            if np.any(regret < -tolerance):
                raise RuntimeError("materially negative validation regret")
            return {"mean_regret": float(np.maximum(regret, 0).mean()),
                    "samples": len(regret), "solver_seconds": deployed.stats.solver_seconds,
                    "oracle_calls": deployed.stats.calls}

        record["validation"] = measure("validation_deployment", evaluate)
        record["status"] = "complete"
    except Exception as exc:
        record["status"] = "failed"
        record["failed_phase"] = record["phase"]
        record["error_type"] = type(exc).__name__
        record["error"] = str(exc)
        record["traceback"] = traceback.format_exc()
        if "size-limited" in str(exc):
            record["failure_category"] = "gurobi_license_limit"
    finally:
        for obj in (solver, wise):
            if obj is not None:
                try:
                    obj.close()
                except Exception:
                    pass
        record["total_wall_seconds"] = time.perf_counter() - started
        record["peak_rss_kib"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (1024 if sys.platform == "darwin" else 1)
        record["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        write(out, record)
        write(progress, record)
    print(json.dumps({"job_id": job["id"], "status": record["status"], "epochs": record["epochs_completed"], "seconds": record["total_wall_seconds"]}))
    if record["status"] != "complete":
        raise SystemExit(2)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    p = commands.add_parser("build")
    p.add_argument("--source-manifest", type=Path, default=ROOT / "configs/public_baselines/paper_solver_free_matched.json")
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--lava-vertex-tolerance", type=float, default=0.0,
                   help="Explicit numerical duplicate repair; zero preserves public behavior")
    p.set_defaults(func=build)
    p = commands.add_parser("run")
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--job-index", type=int, required=True)
    p.add_argument("--output-root", type=Path, required=True)
    p.add_argument("--smoke", action="store_true")
    p.add_argument("--epochs", type=int, help="override only for preflight")
    p.set_defaults(func=run)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
