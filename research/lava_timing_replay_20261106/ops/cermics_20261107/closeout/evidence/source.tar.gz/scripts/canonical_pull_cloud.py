"""Retrieve and verify cloud artifacts on CERMICS before publishing receipts."""
import argparse
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path
from build_central_path_final import read,write


def verify_snapshot(local, hashes, repair):
    """Repair rsync's same-size, same-second quick-check misses by checksum."""
    def mismatches():
        return [name for name,digest in hashes.items()
                if not (local/name).is_file()
                or hashlib.sha256((local/name).read_bytes()).hexdigest()!=digest]
    for name in hashes:
        if Path(name).is_absolute() or '..' in Path(name).parts or not name.startswith('results/'):
            raise ValueError('Snapshot path is outside results: '+name)
    stale=mismatches()
    if stale:
        repair(stale)
    remaining=mismatches()
    if remaining:
        raise RuntimeError('Cloud retrieval checksum mismatch: '+', '.join(remaining))
    return stale


def stage_verified_receipts(local, incoming, hashes):
    """A receipt created after the snapshot waits until the next verified pull."""
    incoming.mkdir(parents=True,exist_ok=True)
    count=0
    for name,digest in hashes.items():
        path=Path(name)
        if path.parent != Path('results/receipts') or path.suffix!='.json':
            continue
        source=local/path
        if hashlib.sha256(source.read_bytes()).hexdigest()!=digest:
            raise RuntimeError('Receipt changed after verification: '+name)
        target=incoming/path.name
        temporary=target.with_name(target.name+f'.{os.getpid()}.tmp')
        shutil.copyfile(source,temporary)
        temporary.replace(target)
        count+=1
    return count


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True)
    p.add_argument('--host',choices=('hornewall','tito'),required=True);p.add_argument('--final',action='store_true')
    a=p.parse_args();r=a.root;h=read(r/'cloud_transfer.json')[a.host]
    local=r/'cloud_retrieved'/a.host;local.mkdir(parents=True,exist_ok=True)
    ssh=['ssh','-i',str(r/'cloud_ssh_key'),'-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+str(r/'cloud_known_hosts')]
    subprocess.run([*ssh,h['ssh_target'],shlex.join([h['root']+'/venv/bin/python',h['root']+'/code/scripts/canonical_snapshot.py','--root',h['root'],*(['--final'] if a.final else [])])],check=True,stdout=subprocess.DEVNULL)
    subprocess.run(['rsync','-az','--timeout=60','-e',shlex.join(ssh),h['ssh_target']+':'+h['root']+'/results/',str(local/'results')+'/'],check=True)
    subprocess.run(['rsync','-az','--timeout=60','-e',shlex.join(ssh),h['ssh_target']+':'+h['root']+'/retrieval_hashes.json',str(local/'retrieval_hashes.json')],check=True)
    hashes=read(local/'retrieval_hashes.json')
    def repair(names):
        subprocess.run(['rsync','-azc','--timeout=60','--files-from=-','-e',shlex.join(ssh),
                        h['ssh_target']+':'+h['root']+'/',str(local)+'/'],
                       input='\n'.join(names)+'\n',text=True,check=True)
    repaired=verify_snapshot(local,hashes,repair)
    subprocess.run(['rsync','-a','--exclude=receipts/','--exclude=progress/','--exclude=queue_status.json',str(local/'results')+'/',str(r/'results')+'/'],check=True)
    incoming=r/'imports'/a.host;incoming.mkdir(parents=True,exist_ok=True)
    receipt_count=stage_verified_receipts(local,incoming,hashes)
    if receipt_count:
        subprocess.run([sys.executable,str(r/'code/scripts/canonical_import.py'),'--root',str(r),'--host',a.host],check=True,stdout=subprocess.DEVNULL)
    report={'verified_files':len(hashes),'receipts':receipt_count,'checksum_repaired_files':repaired,'storage':str(local)}
    write(local/'verification.json',report);print(json.dumps(report))
