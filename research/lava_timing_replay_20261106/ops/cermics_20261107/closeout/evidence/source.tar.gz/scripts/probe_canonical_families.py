#!/usr/bin/env python3
"""One training minibatch per method on a requested archived benchmark cell.

Preflight only: no hyperparameter selection, held-out evaluation or campaign
launch. Use an external process timeout because native MIP solves can be long.
"""
from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
EXTERNAL = BASE / "public-baseline-sources-20260905/dfl-extensions-lab-fixed/src"
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "scripts"), str(EXTERNAL)]
os.environ["DFL_EXTENSIONS_SRC"] = str(EXTERNAL)

import numpy as np
import torch
from proximal_spo.artifacts import model_sha256
from proximal_spo.canonical_baselines import (
    ColdHighsBatch, PhysicalMSELoss, PhysicalWISELoss, cold_pyepo_spo_plus,
)
from proximal_spo.models import ModelSpec, StandardizedMLP
from run_central_path_final import load_job_data


def main(cell):
    target = ROOT / "runs/canonical_readiness_20260923/family_probes" / (cell + ".json")
    target.parent.mkdir(parents=True, exist_ok=True)
    record = {"cell": cell, "preflight_only": True, "test_evaluations": 0,
              "training_minibatches_per_method": 1, "methods": {}}
    def update(phase):
        record["phase"] = phase
        temp = target.with_suffix(".tmp")
        temp.write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")
        temp.replace(target)
    roots = [
        BASE / "ProximalSPO-final-20260922/runs/central_path_final_20260922/hornewall/retrieved",
        BASE / "ProximalSPO-extension-20260923/runs/central_path_extension_20260923/hornewall/retrieved",
    ]
    job = next(copy.deepcopy(j) for root in roots
               for j in json.loads((root / "screen.json").read_text())["jobs"]
               if j["cell"] == cell and j["method"] == "mse")
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    update("loading_frozen_data")
    loaded = load_job_data(job)
    train = loaded.dataset.train
    costs = torch.as_tensor(train.physical_costs[:2], dtype=torch.float32)
    contexts = torch.as_tensor(train.contexts[:2], dtype=torch.float32)
    record.update(physical_cost_dimension=loaded.problem.variable_count,
                  integer_variables=int(loaded.problem.integrality.sum()),
                  sizes=job["config"]["sizes"], seeds=job["config"]["seeds"],
                  original_feasible_set=True)
    for method in ("mse", "wise", "spo_plus"):
        update(method + "_preparation")
        torch.manual_seed(job["config"]["seeds"]["initialization"])
        bias = (train.physical_costs.sum(0) / np.linalg.norm(train.physical_costs, axis=1).sum()
                if method == "wise" else train.physical_costs.mean(0))
        model = StandardizedMLP(train.contexts.shape[1], loaded.problem.variable_count,
            ModelSpec(**job["config"]["model"]), input_mean=train.contexts.mean(0),
            input_scale=np.maximum(train.contexts.std(0), 1e-12), output_bias=bias)
        optimizer = torch.optim.AdamW(model.parameters(), lr=job["config"]["training"]["learning_rate"])
        loss = {"mse": PhysicalMSELoss, "wise": PhysicalWISELoss}.get(method)
        if method == "spo_plus":
            started = time.perf_counter()
            oracle = ColdHighsBatch(loaded.problem)
            reference = oracle.solve_many(train.physical_costs[:2])
            reference_seconds = time.perf_counter() - started
            loss = cold_pyepo_spo_plus(loaded.problem)
        else:
            reference_seconds = 0.
            loss = loss()
        initial = model_sha256(model)
        update(method + "_one_minibatch")
        started = time.perf_counter()
        prediction = model(contexts)
        if method == "spo_plus":
            value = loss(prediction, costs,
                         torch.as_tensor(reference.decisions, dtype=prediction.dtype),
                         torch.as_tensor(reference.objectives[:, None], dtype=prediction.dtype))
        else:
            value = loss(prediction, costs)
        value.backward()
        assert torch.isfinite(value) and all(
            torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
        optimizer.step()
        elapsed = time.perf_counter() - started
        changed = initial != model_sha256(model)
        assert changed and prediction.shape == costs.shape
        record["methods"][method] = {"status": "passed", "loss": value.item(),
            "training_wall_seconds": elapsed, "reference_preparation_seconds": reference_seconds,
            "parameters_changed": changed,
            "optimization_calls_in_minibatch": loss.optmodel.fresh_solve_count if method == "spo_plus" else 0}
    record["status"] = "passed"
    update("complete")
    print(json.dumps(record))


if __name__ == "__main__":
    main(sys.argv[1])
