"""Build compact cross-panel accounting from sealed confirmation receipts."""

from __future__ import annotations

import argparse
from pathlib import Path

from proximal_spo.artifacts import write_json
from proximal_spo.publication_program_analysis import (
    build_program_summary,
    load_object,
    render_program_markdown,
)


def _panel(argument: str) -> tuple[str, Path]:
    name, separator, raw_path = argument.partition("=")
    if not separator or not name or not raw_path:
        raise argparse.ArgumentTypeError("panel must be NAME=PATH")
    return name, Path(raw_path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--panel", action="append", type=_panel, required=True)
    parser.add_argument("--skew", type=Path)
    parser.add_argument("--mechanism", type=Path)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    arguments = parser.parse_args()
    panels: dict[str, dict[str, object]] = {}
    for name, path in arguments.panel:
        if name in panels:
            raise ValueError(f"duplicate panel name: {name}")
        panels[name] = load_object(path)
    skew = None if arguments.skew is None else load_object(arguments.skew)
    mechanism = (
        None if arguments.mechanism is None else load_object(arguments.mechanism)
    )
    summary = build_program_summary(panels, skew=skew, mechanism=mechanism)
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, summary)
    arguments.markdown_output.write_text(
        render_program_markdown(summary), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
