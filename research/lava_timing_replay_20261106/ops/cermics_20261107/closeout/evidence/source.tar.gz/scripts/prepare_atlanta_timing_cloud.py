#!/usr/bin/env python3
"""Prepare immutable inputs and a VM startup script, without provisioning."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

from run_atlanta_baseline_timing import write

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run-id", required=True)
    p.add_argument("--bucket", required=True)
    p.add_argument("--external-source", required=True, type=Path)
    p.add_argument("--run-root", required=True, type=Path)
    p.add_argument("--deadline-unix", required=True, type=int)
    args = p.parse_args()
    dest = args.run_root / "cloud"
    stage = dest / "payload"
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((args.run_root / "manifest.json").read_text())
    if manifest["protocol"].get("optimization_backend") != "HiGHS":
        raise ValueError("Cloud pilot requires the verified HiGHS manifest")
    eligible, blocked = list(range(len(manifest["jobs"]))), []
    hashes = {}

    def copy(source: Path, target: Path) -> None:
        if source.is_dir():
            for child in sorted(source.rglob("*")):
                if child.is_file() and "__pycache__" not in child.parts:
                    copy(child, target / child.relative_to(source))
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            hashes[target.relative_to(stage).as_posix()] = hashlib.sha256(target.read_bytes()).hexdigest()

    copy(ROOT / "src", stage / "project/src")
    for name in ("run_public_solver_free_matched.py", "run_atlanta_baseline_timing.py",
                 "run_atlanta_timing_queue.py", "atlanta_timing_vm.py"):
        copy(ROOT / "scripts" / name, stage / "project/scripts" / name)
    copy(args.external_source / "src", stage / "benchmark_source/src")
    copy(args.external_source / "contracts", stage / "benchmark_source/contracts")
    copy(args.run_root / "manifest.json", stage / "manifest.json")
    copy(args.run_root / "requirements.lock", stage / "requirements.lock")
    for shard in range(8):
        f = stage / f"shards/{shard}.json"
        write(f, eligible[shard::8])
        hashes[f.relative_to(stage).as_posix()] = hashlib.sha256(f.read_bytes()).hexdigest()
    write(stage / "SOURCE_MANIFEST.json", {
        "project_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "external_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=args.external_source, text=True).strip(),
        "public_lava_commit": "3a18424fc35c525731e52c4742417059b8a77eac", "sha256": hashes,
    })
    archive = dest / "source.tar.gz"
    with tarfile.open(archive, "w:gz") as tar:
        for child in sorted(stage.iterdir()):
            tar.add(child, arcname=child.name)
    archive_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
    vm_code = (ROOT / "scripts/atlanta_timing_vm.py").read_text()
    supervisor_args = f"--root /opt/atlanta --bucket {args.bucket} --run-id {args.run_id} --deadline-unix {args.deadline_unix}"
    bootstrap = f'''#!/bin/bash
set -eu
mkdir -p /opt/atlanta/results
exec > >(tee -a /opt/atlanta/results/bootstrap.log) 2>&1
cat > /opt/atlanta_vm.py <<'ATLANTA_VM_PYTHON'
{vm_code}
ATLANTA_VM_PYTHON
cleanup_failure() {{
    python3 /opt/atlanta_vm.py {supervisor_args} --failure-only
}}
trap cleanup_failure ERR
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3 curl git ca-certificates
python3 - <<'DOWNLOAD_PYTHON'
import hashlib,json,tarfile,urllib.request
from pathlib import Path
req=urllib.request.Request('http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token',headers={{'Metadata-Flavor':'Google'}})
token=json.loads(urllib.request.urlopen(req,timeout=15).read())['access_token']
req=urllib.request.Request('https://storage.googleapis.com/{args.bucket}/source.tar.gz',headers={{'Authorization':'Bearer '+token}})
data=urllib.request.urlopen(req,timeout=120).read()
assert hashlib.sha256(data).hexdigest()=='{archive_hash}', 'source archive checksum mismatch'
path=Path('/opt/atlanta-source.tar.gz'); path.write_bytes(data)
with tarfile.open(path) as tar: tar.extractall('/opt/atlanta',filter='data')
root=Path('/opt/atlanta')
for name,sha in json.loads((root/'SOURCE_MANIFEST.json').read_text())['sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha, name
DOWNLOAD_PYTHON
export PATH="$HOME/.local/bin:$PATH"
curl -LsSf https://astral.sh/uv/install.sh | sh
uv python install 3.13
uv venv --python 3.13 /opt/atlanta/.venv
uv pip sync --python /opt/atlanta/.venv/bin/python /opt/atlanta/requirements.lock --extra-index-url https://download.pytorch.org/whl/cpu --index-strategy unsafe-best-match
git clone --quiet https://github.com/ML-KULeuven/Solver-Free-DFL.git /opt/atlanta/solver-free-dfl
git -C /opt/atlanta/solver-free-dfl checkout --quiet --detach 3a18424fc35c525731e52c4742417059b8a77eac
export SOLVER_FREE_DFL_REPO=/opt/atlanta/solver-free-dfl
export DFL_EXTENSIONS_SRC=/opt/atlanta/benchmark_source/src
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONUNBUFFERED=1
export ATLANTA_SOURCE_MANIFEST=/opt/atlanta/SOURCE_MANIFEST.json
cd /opt/atlanta/project
for i in 77 78 79 80 81 82 83; do
    /opt/atlanta/.venv/bin/python scripts/run_atlanta_baseline_timing.py run --manifest /opt/atlanta/manifest.json --job-index "$i" --output-root /opt/atlanta/results/preflight --smoke --epochs 2
done
trap - ERR
exec /opt/atlanta/.venv/bin/python /opt/atlanta_vm.py {supervisor_args}
'''
    (dest / "startup.sh").write_text(bootstrap)
    write(dest / "dispatch.json", {
        "run_id": args.run_id, "bucket": args.bucket, "deadline_unix": args.deadline_unix,
        "vm_count": 8, "machine_type": "n2-highmem-8", "vcpu_total": 64,
        "source_archive_sha256": archive_hash, "source_archive_bytes": archive.stat().st_size,
        "eligible_jobs": len(eligible), "license_blocked_jobs": len(blocked),
        "optimization_backend": "HiGHS",
        "blocked_indices": blocked, "blocked_ids": [manifest["jobs"][i]["id"] for i in blocked],
        "shard_sizes": [len(eligible[i::8]) for i in range(8)], "resources_created": False,
    })
    print(json.dumps({"eligible": len(eligible), "license_blocked": len(blocked), "archive_bytes": archive.stat().st_size}))


if __name__ == "__main__":
    main()
