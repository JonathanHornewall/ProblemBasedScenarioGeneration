"""Refuse a production launch unless frozen inputs and diagnostics agree."""
import argparse
import hashlib
import json
import os
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def verify(root):
    ready = read(root / "READY_FOR_PRODUCTION.json")
    for name, expected in ready["file_sha256"].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
    source = read(root / "source_receipt.json")
    for name, expected in source["source_sha256"].items():
        assert hashlib.sha256((root / "code" / name).read_bytes()).hexdigest() == expected, name
    diagnostics = read(root / "preflight/diagnostic_verification.json")
    assert diagnostics["status"] == "complete" and diagnostics["jobs"] == 46
    assert not diagnostics["issues"] and not diagnostics["scientific_selection_eligible"]
    compatibility = read(root / "preflight/frozen_model_input_verification.json")
    assert compatibility["checked_models"] == 2600 and not compatibility["issues"]
    prepared = read(root / "input_preparation_verification.json")
    assert prepared["status"] == "complete" and prepared["count"] == 224
    tests = read(root / "local_test_verification.json")
    assert tests["status"] == "complete" and tests["passed"] == 30
    initial = read(root / "initial_execution.json")
    live = read(root / "execution.json")
    assert live["jobs"][:len(initial["jobs"])] == initial["jobs"]
    assert live["screen_fingerprint"] == initial["screen_fingerprint"]
    for job in initial["jobs"]:
        assert job["config"]["sizes"] == {"train": 100, "validation": 32, "test": 128}
        if job["stage"] == "screen":
            assert job["method"] in ("pfyl", "nce", "lava")
            assert job["config"]["physical_cost_output"] is True
            assert job["validation_costs"] == "single_sample"
    assert int(os.environ["SLURM_JOB_NUM_NODES"]) == 3
    assert int(os.environ["SLURM_CPUS_PER_TASK"]) == 50
    print(json.dumps({"status": "verified", "source_commit": source["git_commit"],
                      "initial_jobs": len(initial["jobs"]), "maximum_workers": 150}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    verify(parser.parse_args().root.resolve())
