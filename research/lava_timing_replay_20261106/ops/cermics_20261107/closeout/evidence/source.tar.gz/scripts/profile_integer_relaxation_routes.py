"""Bounded preflight of every implemented integer objective-learning route.

Each route runs in its own subprocess.  A difficult MILP can therefore time
out without blocking the remaining inventory.  The output is an incremental
engineering receipt, not comparative learning evidence.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np

from proximal_spo.artifacts import environment_receipt, source_sha256, write_json
from proximal_spo.benchmarks.catalog import BENCHMARKS, build_benchmark
from proximal_spo.config import SeedSpec
from proximal_spo.data import CostLawSpec, SplitSizes, generate_dataset
from proximal_spo.external_benchmarks import load_external_benchmark
from proximal_spo.feasible_policies import compile_policy_geometry
from proximal_spo.oracles import make_lp_oracle

LOCAL_INTEGER_ROUTES = tuple(
    benchmark_id
    for benchmark_id in sorted(BENCHMARKS)
    if not build_benchmark(benchmark_id, structural_seed=101).is_continuous
)


def _external_routes() -> tuple[str, ...]:
    from dfl_extensions_lab.benchmarks import list_native_factory_routes

    rows: list[tuple[int, str, str]] = []
    for route in list_native_factory_routes():
        benchmark = route.build()
        model = benchmark.feasible_model
        if model.integer_count:
            # Cheap models first. CVRP, whose exact oracle may be very slow,
            # is deliberately last even when its variable count is smaller.
            family_penalty = 1 if route.family == "cave_cvrp" else 0
            rows.append((family_penalty, model.variable_count, route.factory_id))
    return tuple(row[2] for row in sorted(rows))


def _profile_external(benchmark_id: str) -> dict[str, Any]:
    from dfl_extensions_lab.benchmarks import get_native_factory_route

    route = get_native_factory_route(benchmark_id)
    benchmark = route.build()
    seed = int(getattr(benchmark.generator, "source_seed", 17))
    loaded = load_external_benchmark(
        benchmark_id,
        SplitSizes(2, 1, 1),
        data_seed=seed,
        conditional_reference_samples=2,
    )
    problem = loaded.problem
    cost = loaded.dataset.validation.conditional_mean_costs
    return _profile_problem(
        benchmark_id,
        problem,
        cost,
        provenance=loaded.provenance,
        source="dfl_extensions_lab",
    )


def _profile_local(benchmark_id: str) -> dict[str, Any]:
    seeds = SeedSpec()
    problem = build_benchmark(benchmark_id, structural_seed=seeds.structural)
    dataset = generate_dataset(
        problem,
        benchmark_id,
        SplitSizes(2, 1, 1),
        data_seed=seeds.data,
        structural_seed=seeds.structural,
        law=CostLawSpec(
            context_dimension=3,
            random_fraction=1.0,
            style="positive",
            noise="gaussian",
            noise_scale=0.1,
            signal_scale=0.5,
            polynomial_degree=2,
        ),
    )
    return _profile_problem(
        benchmark_id,
        problem,
        dataset.validation.conditional_mean_costs,
        provenance={"benchmark_source": "local"},
        source="local",
    )


def _profile_problem(
    benchmark_id: str,
    problem: Any,
    objectives: np.ndarray,
    *,
    provenance: dict[str, Any],
    source: str,
) -> dict[str, Any]:
    relaxation = problem.continuous_relaxation()
    geometry_started = time.perf_counter()
    geometry = compile_policy_geometry(relaxation)
    geometry_seconds = time.perf_counter() - geometry_started

    hard_started = time.perf_counter()
    with make_lp_oracle(problem, workers=1, random_seed=101) as hard:
        hard_solution = hard.solve_many(objectives[:1], np.array([1], dtype=np.int64))
    hard_seconds = time.perf_counter() - hard_started

    relaxed_started = time.perf_counter()
    with make_lp_oracle(relaxation, workers=1, random_seed=101) as oracle:
        relaxed_solution = oracle.solve_many(
            objectives[:1], np.array([1], dtype=np.int64)
        )
    relaxed_seconds = time.perf_counter() - relaxed_started
    gap = float(hard_solution.objectives[0] - relaxed_solution.objectives[0])
    tolerance = 5e-7 * (
        1.0
        + abs(float(hard_solution.objectives[0]))
        + abs(float(relaxed_solution.objectives[0]))
    )
    if gap < -tolerance:
        raise RuntimeError("continuous relaxation is worse than hard problem")
    return {
        "benchmark_id": benchmark_id,
        "benchmark_source": source,
        "status": "complete",
        "variables": problem.variable_count,
        "integer_variables": int(np.sum(problem.integrality)),
        "constraints": problem.constraint_count,
        "geometry_seconds": geometry_seconds,
        "geometry": asdict(geometry.receipt),
        "hard_solve_seconds": hard_seconds,
        "hard_oracle_stats": asdict(hard_solution.stats),
        "relaxation_solve_seconds": relaxed_seconds,
        "relaxation_oracle_stats": asdict(relaxed_solution.stats),
        "absolute_integrality_gap": max(gap, 0.0),
        "provenance": provenance,
    }


def _worker(benchmark_id: str, source: str) -> int:
    row = (
        _profile_external(benchmark_id)
        if source == "dfl_extensions_lab"
        else _profile_local(benchmark_id)
    )
    print(json.dumps(row, sort_keys=True))
    return 0


def _run_parent(arguments: argparse.Namespace) -> int:
    root = Path(__file__).resolve().parents[1]
    output = arguments.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    routes = [
        *(("dfl_extensions_lab", item) for item in _external_routes()),
        *(("local", item) for item in LOCAL_INTEGER_ROUTES),
    ]
    receipt: dict[str, Any] = {
        "kind": "integer_relaxation_route_preflight",
        "scope": (
            "one geometry compile, one hard solve, and one relaxation solve per "
            "implemented route; not learning evidence"
        ),
        "timeout_seconds_per_route": arguments.timeout,
        "source_sha256": source_sha256(root),
        "environment": environment_receipt(root),
        "route_count": len(routes),
        "rows": [],
    }
    write_json(output, receipt)
    for source, benchmark_id in routes:
        print(f"BEGIN {benchmark_id}", flush=True)
        started = time.perf_counter()
        command = [
            sys.executable,
            str(Path(__file__).resolve()),
            "--worker",
            benchmark_id,
            "--source",
            source,
        ]
        try:
            completed = subprocess.run(
                command,
                check=True,
                capture_output=True,
                text=True,
                timeout=arguments.timeout,
            )
            lines = [line for line in completed.stdout.splitlines() if line.strip()]
            row = json.loads(lines[-1])
        except subprocess.TimeoutExpired:
            row = {
                "benchmark_id": benchmark_id,
                "benchmark_source": source,
                "status": "timeout",
                "timeout_seconds": arguments.timeout,
            }
        except (subprocess.CalledProcessError, json.JSONDecodeError) as error:
            row = {
                "benchmark_id": benchmark_id,
                "benchmark_source": source,
                "status": "failed",
                "error_type": type(error).__name__,
                "error": str(error),
                "stderr": getattr(error, "stderr", ""),
            }
        row["outer_wall_seconds"] = time.perf_counter() - started
        receipt["rows"].append(row)
        write_json(output, receipt)
        print(
            f"END {benchmark_id}: {row['status']} ({row['outer_wall_seconds']:.2f}s)",
            flush=True,
        )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--worker")
    parser.add_argument("--source", choices=("local", "dfl_extensions_lab"))
    arguments = parser.parse_args()
    if arguments.worker:
        if arguments.source is None:
            parser.error("--worker requires --source")
        return _worker(arguments.worker, arguments.source)
    if arguments.output is None:
        parser.error("--output is required")
    if arguments.timeout <= 0.0:
        parser.error("--timeout must be positive")
    return _run_parent(arguments)


if __name__ == "__main__":
    raise SystemExit(main())
