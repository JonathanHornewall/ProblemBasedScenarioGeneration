"""Validation-only selection for post-Adam exact-head candidates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from proximal_spo.analysis import summarize_exact_head_selection
from proximal_spo.artifacts import write_json


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", type=Path)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument(
        "--source-sha256",
        help="select one executable source hash when a run root contains reruns",
    )
    arguments = parser.parse_args()
    summary = summarize_exact_head_selection(
        arguments.run_root,
        source_sha256=arguments.source_sha256,
    )
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, summary)
    print(json.dumps(summary["selected_arm"], indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
