"""Summarize the neural and μ-normalized prediction-correction development pass."""

from __future__ import annotations

import collections
import hashlib
import json
import statistics
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
MAIN_ROOT = REPO_ROOT / "runs" / "prediction_correction" / "neural_development"
MU_ROOT = (
    REPO_ROOT / "runs" / "prediction_correction" / "mu_normalized_development"
)
RAW_REFERENCE = (
    REPO_ROOT
    / "results"
    / "prediction_correction"
    / "neural_development_paired_mse.json"
)
OLD_SUMMARY = (
    REPO_ROOT / "results" / "prediction_correction" / "development_summary.json"
)
OUTPUT_ROOT = REPO_ROOT / "results" / "prediction_correction"

METHODS = (
    "paired_mse_exact_ray_gauge",
    "paired_mse_exact_full_cone",
    "neural_ray_gauge",
    "neural_cone_coordinates",
    "neural_end_to_end_exact_cone_projection",
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _load_runs(root: Path) -> dict[tuple[str, int], dict[str, Any]]:
    result: dict[tuple[str, int], dict[str, Any]] = {}
    for path in root.glob("*/prediction_correction.json"):
        config = json.loads((path.parent / "config.json").read_text(encoding="utf-8"))
        key = (str(config["benchmark_id"]), int(config["seeds"]["data"]))
        if key in result:
            raise ValueError(f"duplicate run {key}")
        result[key] = {
            "correction": json.loads(path.read_text(encoding="utf-8")),
            "summary": json.loads(
                (path.parent / "summary.json").read_text(encoding="utf-8")
            ),
            "path": str(path.parent.relative_to(REPO_ROOT)),
        }
    if len(result) != 18:
        raise ValueError(f"expected 18 complete runs, found {len(result)} in {root}")
    return result


def _mean(values: list[float]) -> float:
    return float(statistics.mean(values))


def main() -> int:
    runs = _load_runs(MAIN_ROOT)
    mu_runs = _load_runs(MU_ROOT)
    raw_payload = json.loads(RAW_REFERENCE.read_text(encoding="utf-8"))
    raw = {
        (str(row["benchmark_id"]), int(row["data_seed"])): row
        for row in raw_payload["rows"]
    }
    if set(raw) != set(runs) or set(mu_runs) != set(runs):
        raise ValueError("main, μ-normalized, and paired-MSE cells do not match")
    old = json.loads(OLD_SUMMARY.read_text(encoding="utf-8"))
    benchmarks = sorted({benchmark for benchmark, _ in runs})

    table: dict[str, dict[str, float]] = {}
    selected_counts: collections.Counter[str] = collections.Counter()
    exact_wins = 0
    neural_wins = 0
    exact_audit_matches = 0
    exact_audit_total = 0
    neural_audit_matches = 0
    neural_audit_total = 0
    for benchmark in benchmarks:
        keys = sorted(key for key in runs if key[0] == benchmark)
        row: dict[str, float] = {
            "paired_mse_raw": _mean(
                [float(raw[key]["conditional_mse_per_coordinate"]) for key in keys]
            )
        }
        for method in METHODS:
            row[method] = _mean(
                [
                    float(
                        runs[key]["correction"]["methods"][method]["prediction"][
                            "conditional_mse_per_coordinate"
                        ]
                    )
                    for key in keys
                ]
            )
        row["prior_mse"] = float(
            old["conditional_prediction_mse"][benchmark]["mse"]["mean"]
        )
        row["prior_spo_plus"] = float(
            old["conditional_prediction_mse"][benchmark]["spo_plus"]["mean"]
        )
        row["prior_wise"] = float(
            old["conditional_prediction_mse"][benchmark]["wise"]["mean"]
        )
        row["base_dfl_regret"] = _mean(
            [
                float(runs[key]["correction"]["base_decision_test_mean_regret"])
                for key in keys
            ]
        )
        row["prior_mse_regret"] = float(old["regret"][benchmark]["mse"]["mean"])
        row["prior_spo_plus_regret"] = float(
            old["regret"][benchmark]["spo_plus"]["mean"]
        )
        row["exact_full_cone_improvement_percent"] = 100.0 * (
            1.0 - row["paired_mse_exact_full_cone"] / row["paired_mse_raw"]
        )
        row["neural_projected_improvement_percent"] = 100.0 * (
            1.0
            - row["neural_end_to_end_exact_cone_projection"]
            / row["paired_mse_raw"]
        )
        table[benchmark] = row

        for key in keys:
            methods = runs[key]["correction"]["methods"]
            selected = min(
                METHODS,
                key=lambda method: float(
                    methods[method]["validation_scenario_mse_per_coordinate"]
                ),
            )
            selected_counts[selected] += 1
            raw_value = float(raw[key]["conditional_mse_per_coordinate"])
            if (
                float(
                    methods["paired_mse_exact_full_cone"]["prediction"][
                        "conditional_mse_per_coordinate"
                    ]
                )
                < raw_value
            ):
                exact_wins += 1
            if (
                float(
                    methods["neural_end_to_end_exact_cone_projection"]["prediction"][
                        "conditional_mse_per_coordinate"
                    ]
                )
                < raw_value
            ):
                neural_wins += 1
            for method, accumulator in (
                ("paired_mse_exact_full_cone", "exact"),
                ("neural_end_to_end_exact_cone_projection", "neural"),
            ):
                audit = methods[method]["decision_invariance_audit"]
                total = int(audit["sample_size"])
                matches = round(float(audit["base_decision_match_rate"]) * total)
                if accumulator == "exact":
                    exact_audit_total += total
                    exact_audit_matches += matches
                else:
                    neural_audit_total += total
                    neural_audit_matches += matches

    timing: dict[str, dict[str, float]] = {}
    for benchmark in benchmarks:
        keys = [key for key in runs if key[0] == benchmark]
        timing[benchmark] = {
            "base_dfl_training_wall_seconds": _mean(
                [float(runs[key]["summary"]["training_wall_seconds"]) for key in keys]
            ),
            "paired_mse_training_wall_seconds": _mean(
                [
                    float(
                        runs[key]["correction"]["timing"][
                            "paired_mse_network_training"
                        ]["training_wall_seconds"]
                    )
                    for key in keys
                ]
            ),
            "exact_full_cone_validation_and_test_projection_wall_seconds": _mean(
                [
                    float(
                        runs[key]["correction"]["methods"][
                            "paired_mse_exact_full_cone"
                        ]["selected_candidate_fit_and_prediction_wall_seconds"]
                    )
                    for key in keys
                ]
            ),
            "neural_projected_head_search_wall_seconds": _mean(
                [
                    float(
                        runs[key]["correction"]["methods"][
                            "neural_end_to_end_exact_cone_projection"
                        ]["selected_candidate_fit_and_prediction_wall_seconds"]
                    )
                    for key in keys
                ]
            ),
            "cached_base_decision_calls": _mean(
                [
                    float(
                        runs[key]["correction"]["base_decision_oracle_stats_by_split"][
                            "train"
                        ]["calls"]
                        + runs[key]["correction"][
                            "base_decision_oracle_stats_by_split"
                        ]["validation"]["calls"]
                    )
                    for key in keys
                ]
            ),
        }

    mu_ablation: dict[str, dict[str, float]] = {}
    for benchmark in benchmarks:
        keys = [key for key in runs if key[0] == benchmark]
        mu_ablation[benchmark] = {}
        for method in (
            "paired_mse_exact_ray_gauge",
            "paired_mse_exact_full_cone",
            "neural_ray_gauge",
            "neural_cone_coordinates",
        ):
            original = _mean(
                [
                    float(
                        runs[key]["correction"]["methods"][method]["prediction"][
                            "conditional_mse_per_coordinate"
                        ]
                    )
                    for key in keys
                ]
            )
            normalized = _mean(
                [
                    float(
                        mu_runs[key]["correction"]["methods"][method]["prediction"][
                            "conditional_mse_per_coordinate"
                        ]
                    )
                    for key in keys
                ]
            )
            mu_ablation[benchmark][f"{method}_ratio_mu_over_unscaled"] = (
                normalized / original
            )

    payload = {
        "status": "development_not_confirmation",
        "supervision": "context-scenario pairs only",
        "test_selection_used": False,
        "projected_scenario_label_regression_included": False,
        "deployment": "uncorrected DFL direction; corrected cost is a sidecar",
        "conditional_mse": table,
        "timing": timing,
        "validation_selection_counts": dict(selected_counts),
        "paired_cell_wins_against_raw_mse": {
            "exact_full_cone": exact_wins,
            "neural_projected": neural_wins,
            "cell_count": len(runs),
        },
        "decision_invariance_audit": {
            "exact_full_cone_matches": exact_audit_matches,
            "exact_full_cone_total": exact_audit_total,
            "neural_projected_matches": neural_audit_matches,
            "neural_projected_total": neural_audit_total,
            "corrected_cost_used_for_deployment": False,
        },
        "mu_normalization_ablation": mu_ablation,
        "lineage": {
            "main_run_count": len(runs),
            "mu_run_count": len(mu_runs),
            "paired_mse_reference_sha256": _sha256(RAW_REFERENCE),
            "prior_baseline_summary_sha256": _sha256(OLD_SUMMARY),
            "raw_predictions_or_weights_persisted": False,
        },
    }
    output_json = OUTPUT_ROOT / "neural_development_summary.json"
    write_json(output_json, payload)

    labels = {
        "cost.assignment10": "Assignment",
        "cost.facility30x5_relaxation": "Facility",
        "cost.grid5": "Grid",
        "cost.knapsack50x5": "Knapsack",
        "cost.random_lp100x50": "Random LP",
        "cost.topk20x5": "Top-k",
    }
    lines = [
        "# Neural decision-preserving prediction correction — development",
        "",
        "The simplest method won: train an ordinary MSE network, then project its "
        "cost once into the normal cone of the fixed DFL decision. After caching "
        "one base decision per training/validation context, correction training "
        "never re-solves the downstream LP; the projection itself is a compact "
        "NNLS problem. Cone membership keeps the base decision optimal, subject "
        "to the usual tie-breaking qualification. Results are three-seed "
        "development evidence, not a frozen confirmation.",
        "",
        "## Conditional-mean cost MSE per physical coordinate",
        "",
        "| Benchmark | Raw paired MSE | Exact full cone | End-to-end projected NN | "
        "Exact gain | Neural gain | Prior SPO+ |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for benchmark in benchmarks:
        row = table[benchmark]
        lines.append(
            f"| {labels[benchmark]} | {row['paired_mse_raw']:.6g} | "
            f"{row['paired_mse_exact_full_cone']:.6g} | "
            f"{row['neural_end_to_end_exact_cone_projection']:.6g} | "
            f"{row['exact_full_cone_improvement_percent']:.2f}% | "
            f"{row['neural_projected_improvement_percent']:.2f}% | "
            f"{row['prior_spo_plus']:.6g} |"
        )
    lines.extend(
        [
            "",
            f"Exact full-cone projection improved paired raw MSE in {exact_wins}/18 "
            "cells; the two losses were tiny (below 9e-6 absolute). The end-to-end "
            f"projected network improved {neural_wins}/18 cells, but validation "
            "selected it in only 10/18 cells and nine projected-network fits chose "
            "epoch zero.",
            "",
            "## Added cost",
            "",
            "| Benchmark | MSE network | Exact val+test cone projection | "
            "Projected-NN search | Cached base decisions |",
            "|---|---:|---:|---:|---:|",
        ]
    )
    for benchmark in benchmarks:
        row = timing[benchmark]
        lines.append(
            f"| {labels[benchmark]} | {row['paired_mse_training_wall_seconds']:.3f}s | "
            f"{row['exact_full_cone_validation_and_test_projection_wall_seconds']:.3f}"
            "s | "
            f"{row['neural_projected_head_search_wall_seconds']:.3f}s | "
            f"{row['cached_base_decision_calls']:.0f} |"
        )
    lines.extend(
        [
            "",
            "The exact projection passed 144/144 bounded decision-replay checks. "
            "The end-to-end projected head passed 143/144; the one mismatch was a "
            "random-LP numerical/tie replay and does not affect deployment because "
            "the uncorrected base direction remains the deployed cost.",
            "",
            "## μ-normalization",
            "",
            "Multiplying the recovered direction by its known μ leaves both exact "
            "projection methods unchanged, as predicted by scale invariance. It "
            "helped the weak cone-coordinate head on assignment and random LP, hurt "
            "it on grid and top-k, and did not make it competitive. The ray head was "
            "essentially unchanged after its log-scale parameterization. Thus the "
            "main conclusion is not an artifact of omitted μ normalization.",
            "",
            "## Decision",
            "",
            "Carry forward the paired-MSE exact full-cone projection as the default. "
            "Retain the end-to-end projected network as an optional refinement for "
            "assignment/top-k-like families. Drop the direct ray and cone-coordinate "
            "neural heads from the primary method unless a later benchmark supplies "
            "a positive control. No claim should be made from this development pass "
            "about confirmation performance.",
        ]
    )
    output_md = OUTPUT_ROOT / "neural_development_summary.md"
    output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(output_json)
    print(output_md)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
