"""Promote validation-only development arms to paired-seed refinement."""

from __future__ import annotations

import argparse
from pathlib import Path

from proximal_spo.artifacts import write_json
from proximal_spo.development_analysis import completed_validation_rows
from proximal_spo.publication_selection import build_refinement_campaign


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", action="append", type=Path, required=True)
    parser.add_argument("--source-sha256", action="append")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--campaign-run-root", required=True)
    parser.add_argument("--top-k", type=int, default=3)
    parser.add_argument(
        "--benchmark-id",
        action="append",
        help="restrict promotion to the named benchmark id; may be repeated",
    )
    parser.add_argument(
        "--preserve-data-seed-benchmark",
        action="append",
        default=[],
        help=(
            "retain the development data seed for a fixed released dataset; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--workers",
        type=int,
        help="override per-run oracle workers in the emitted refinement campaign",
    )
    arguments = parser.parse_args()
    rows = completed_validation_rows(
        arguments.run_root,
        required_source_sha256=arguments.source_sha256,
    )
    if arguments.benchmark_id:
        requested = frozenset(arguments.benchmark_id)
        rows = [
            row
            for row in rows
            if row.get("config", {}).get("benchmark_id") in requested
        ]
        found = {
            str(row["config"]["benchmark_id"])
            for row in rows
            if isinstance(row.get("config"), dict)
        }
        missing = requested - found
        if missing:
            raise ValueError(
                "requested benchmarks were not present: "
                + ", ".join(sorted(missing))
            )
    campaign = build_refinement_campaign(
        rows,
        run_root=arguments.campaign_run_root,
        top_k=arguments.top_k,
        workers_override=arguments.workers,
        preserve_data_seed_benchmarks=arguments.preserve_data_seed_benchmark,
    )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.output, campaign)
    print(
        f"wrote {len(campaign['variants'])} paired refinement runs to "
        f"{arguments.output}"
    )


if __name__ == "__main__":
    main()
