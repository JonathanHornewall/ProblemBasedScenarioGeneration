#!/usr/bin/env python3
"""Run the released SFGE implementation on a maintained benchmark route.

This adapter deliberately keeps the public ``SFGEModule.training_step`` and
Gaussian model unchanged.  The maintained benchmark catalogue supplies the
context--cost stream and the source model.  Training uses a continuous LP
relaxation; validation and test solve the original source model, including its
integer variables.  Only validation is used for checkpoint selection.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import os
import random
import subprocess
import sys
import time
from copy import deepcopy
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

PROJECT_ROOT = Path(__file__).resolve().parents[1]
_DEFAULT_SFGE_REPO = Path("/private/tmp/sfge-audit")
if not (_DEFAULT_SFGE_REPO / "methods" / "sfge.py").is_file():
    # Keep using the same pinned public checkout when a scratch directory has
    # only orphaned bytecode files.
    _DEFAULT_SFGE_REPO = Path("/private/tmp/dfl_source_audit_20260830/sfge")
PUBLIC_REPO = Path(
    os.environ.get("SFGE_PUBLIC_REPO", str(_DEFAULT_SFGE_REPO))
).resolve()
EXTERNAL_SRC = Path(
    os.environ.get(
        "DFL_EXTENSIONS_SRC", "/private/tmp/dfl-review-a139bd0.hS3CNv/repo/src"
    )
).resolve()


def _tree_hash(root: Path) -> str:
    digest = hashlib.sha256()
    tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=root).split(b"\0")
    for raw in sorted(item for item in tracked if item):
        digest.update(raw)
        digest.update((root / os.fsdecode(raw)).read_bytes())
    return digest.hexdigest()


def _parse_seeds(value: str) -> list[int]:
    values = [int(item.strip()) for item in value.split(",") if item.strip()]
    if not values:
        raise argparse.ArgumentTypeError("at least one seed is required")
    return values


def _seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


class _PublicLinearProblem:
    """Public-SFGE OptimizationProblem facade over a persistent HiGHS model."""

    def __init__(self, problem: Any, solver: Any) -> None:
        sys.path.insert(0, str(PUBLIC_REPO))
        from optimization_problems import LINEAR_OBJ

        self._problem = problem
        self._solver = solver
        self._obj_type = LINEAR_OBJ
        self._is_minimization_problem = True

    @property
    def obj_type(self) -> str:
        return self._obj_type

    @property
    def is_minimization_problem(self) -> bool:
        return self._is_minimization_problem

    def solve(self, y: np.ndarray, opt_prob_params: dict[str, Any], **kwargs: Any):
        del opt_prob_params
        started = time.perf_counter()
        decision, _, _ = self._solver.solve(np.asarray(y, dtype=np.float64))
        runtime = time.perf_counter() - started
        return decision.astype(np.float32), runtime

    def solve_from_torch(
        self,
        y_torch: torch.Tensor,
        opt_prob_params: dict[str, Any],
        return_runtime: bool = False,
        **kwargs: Any,
    ):
        del kwargs
        decision, runtime = self.solve(y_torch.detach().cpu().numpy(), opt_prob_params)
        tensor = torch.from_numpy(np.asarray(decision, dtype=np.float32))
        return (tensor, runtime) if return_runtime else tensor

    def get_objective_values(
        self,
        y: torch.Tensor,
        sols: torch.Tensor,
        opt_prob_params: dict[str, Any],
    ) -> tuple[dict[str, torch.Tensor], bool]:
        del opt_prob_params
        sys.path.insert(0, str(PUBLIC_REPO))
        from optimization_problems import PENALTY_COST, SUBOPTIMALITY_COST, TOTAL_COST

        # The public model emits float32 decisions while the maintained
        # benchmark facade may provide float64 physical costs.  The released
        # training step is unchanged; normalize only this adapter objective
        # contract so SCE arms cannot fail on a mixed-dtype dot product.
        dtype = sols.dtype if sols.is_floating_point() else y.dtype
        y = y.to(dtype=dtype, device=sols.device)
        sols = sols.to(dtype=dtype)
        values = torch.matmul(sols, y)
        return {
            TOTAL_COST: values,
            SUBOPTIMALITY_COST: values,
            PENALTY_COST: torch.zeros_like(values),
        }, True


class _ArrayDataset(Dataset):
    """Minimal public DFL tuple contract without instance-specific parameters.

    ``scaled_costs`` is optional for backwards compatibility with the small
    standalone harness.  The matched paper adapter supplies the train-split
    standardized coordinates required by the released SFGE Gaussian module.
    """

    def __init__(
        self,
        contexts: np.ndarray,
        costs: np.ndarray,
        solutions: np.ndarray,
        scaled_costs: np.ndarray | None = None,
    ):
        self.x = torch.as_tensor(np.asarray(contexts), dtype=torch.float32)
        self.y = torch.as_tensor(np.asarray(costs), dtype=torch.float32)
        if scaled_costs is None:
            scaled_costs = costs
        self.scaled_y = torch.as_tensor(np.asarray(scaled_costs), dtype=torch.float32)
        self.solutions = torch.as_tensor(np.asarray(solutions), dtype=torch.float32)
        self.feats = np.asarray(contexts)
        self.costs = np.asarray(costs)
        self.scaled_costs = np.asarray(scaled_costs)

    def __len__(self) -> int:
        return len(self.x)

    def __getitem__(self, index: int):
        # The public DFLModule collates the empty dictionaries to a stable
        # per-observation parameter list.  Geometry is fixed by the facade.
        return (
            self.x[index],
            self.y[index],
            self.scaled_y[index],
            self.solutions[index],
            {},
            {},
        )


def _build_public_problem(problem: Any) -> tuple[Any, Any]:
    from proximal_spo.oracles import PersistentLPSolver

    solver = PersistentLPSolver(problem, random_seed=0)
    return _PublicLinearProblem(problem, solver), solver


def _solve_targets(problem: Any, costs: np.ndarray) -> np.ndarray:
    _, solver = _build_public_problem(problem)
    # PersistentLPSolver owns a small in-process HiGHS object and (unlike the
    # parallel wrapper) intentionally has no close method.  Let Python release
    # it after this bounded precomputation.
    return solver.solve_many(np.asarray(costs, dtype=np.float64)).decisions.astype(
        np.float32
    )


def _regret(module: Any, evaluation_problem: Any, split: _ArrayDataset) -> float:
    # Keep public SFGE's greedy (unscaled) output; the external benchmark uses
    # a minimization cost convention, so the objective gap is cost(predicted)
    # minus cost(optimal) under the realized source cost.
    with torch.no_grad():
        output = module.net(x=split.x, sample=False, return_scaled=True)
        prediction = output[1] if isinstance(output, tuple) else output
    gaps: list[float] = []
    optimum: list[float] = []
    for pred, cost, truth in zip(prediction, split.y, split.solutions, strict=True):
        solved = evaluation_problem.solve_from_torch(pred, {})
        pred_solution = solved[0] if isinstance(solved, tuple) else solved
        cost = cost.to(dtype=pred_solution.dtype, device=pred_solution.device)
        truth = truth.to(dtype=pred_solution.dtype, device=pred_solution.device)
        pred_value = float(torch.dot(cost, pred_solution))
        true_value = float(torch.dot(cost, truth))
        gaps.append(true_value * 0.0 + pred_value - true_value)
        optimum.append(abs(true_value))
    return float(np.sum(gaps) / (np.sum(optimum) + 1e-7))


def _arms() -> list[dict[str, Any]]:
    return [
        {
            "name": f"SFGE{'_SCE' if sce else ''}_sigma{sigma:g}_lr{lr:g}_std{int(std)}",
            "sigma": sigma,
            "lr": lr,
            "standardize_batch_values": std,
            "sce_loss": sce,
        }
        for sigma in (0.03, 0.1, 0.3, 1.0)
        for lr in (0.003, 0.01, 0.03)
        for std in (True, False)
        for sce in (False, True)
    ]


def _train_arm(
    training_problem: Any,
    evaluation_problem: Any,
    train: _ArrayDataset,
    validation: _ArrayDataset,
    test: _ArrayDataset,
    arm: dict[str, Any],
    *,
    seed: int,
    epochs: int,
    batch_size: int,
) -> dict[str, Any]:
    sys.path.insert(0, str(PUBLIC_REPO))
    from data.generation_scripts.utility import set_seeds
    from methods.sfge import SFGEModule
    from utils.probabilistic_models import MultivariateGaussianModule
    from utils.scale_layer import MockScaleLayer

    set_seeds(seed)
    torch.set_num_threads(2)
    net = nn.Linear(train.x.shape[1], train.y.shape[1])
    gaussian = MultivariateGaussianModule(
        net=net,
        scale_layer=MockScaleLayer(),
        input_shape=int(train.x.shape[1]),
        output_shape=int(train.y.shape[1]),
        init_std_dev_val=math.log(float(arm["sigma"])),
        covariance_type="static",
    )
    module = SFGEModule(
        net=gaussian,
        optimization_problem=training_problem,
        annealer=None,
        lr=float(arm["lr"]),
        sce_loss=bool(arm["sce_loss"]),
        std_batch_vals=bool(arm["standardize_batch_values"]),
    )
    loader = DataLoader(train, batch_size=min(batch_size, len(train)), shuffle=True)
    optimizer = torch.optim.Adam(module.parameters(), lr=float(arm["lr"]))
    best_state: dict[str, torch.Tensor] | None = None
    best_val = float("inf")
    curves: list[dict[str, float]] = []
    started = time.perf_counter()
    for epoch in range(epochs):
        module.train()
        for batch_index, batch in enumerate(loader):
            loss = module.training_step(batch, batch_index)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        val = _regret(module, evaluation_problem, validation)
        curves.append({"epoch": float(epoch), "validation_regret": val})
        if val < best_val:
            best_val = val
            best_state = deepcopy(module.state_dict())
    if best_state is not None:
        module.load_state_dict(best_state)
    test_value = _regret(module, evaluation_problem, test)
    return {
        **arm,
        "seed": seed,
        "public_samples_per_observation": 1,
        "validation_regret": best_val,
        "test_regret": test_value,
        "train_seconds": time.perf_counter() - started,
        "curves": curves,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--factory-id", default="sfge_kp50_values_seed_0")
    parser.add_argument("--num-data", type=int, default=128)
    parser.add_argument("--validation-data", type=int, default=80)
    parser.add_argument("--test-data", type=int, default=50)
    parser.add_argument("--conditional-reference-samples", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--seeds", type=_parse_seeds, default=[0])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if min(args.num_data, args.validation_data, args.test_data, args.epochs) <= 0:
        parser.error("split sizes and epochs must be positive")

    sys.path.insert(0, str(PROJECT_ROOT / "src"))
    sys.path.insert(0, str(EXTERNAL_SRC))
    from dfl_extensions_lab.benchmarks import SplitSizes

    from proximal_spo.external_benchmarks import load_external_benchmark

    started = time.perf_counter()
    all_results: list[dict[str, Any]] = []
    provenance: list[dict[str, Any]] = []
    for seed in args.seeds:
        # The released SFGE stream is intentionally fixed at source seed 0.
        # Repeat the public training protocol with paired network seeds rather
        # than silently regenerating a different benchmark (which the source
        # provider explicitly forbids).
        data_seed = 0 if args.factory_id.startswith("sfge_kp50_values_seed_") else seed
        loaded = load_external_benchmark(
            args.factory_id,
            SplitSizes(args.num_data, args.validation_data, args.test_data),
            data_seed=data_seed,
            conditional_reference_samples=args.conditional_reference_samples,
        )
        relaxed = loaded.problem.continuous_relaxation(
            name=f"{loaded.problem.name}.continuous_training"
        )
        training_problem, _ = _build_public_problem(relaxed)
        evaluation_problem, _ = _build_public_problem(loaded.problem)
        try:
            train = _ArrayDataset(
                loaded.dataset.train.contexts,
                loaded.dataset.train.physical_costs,
                _solve_targets(relaxed, loaded.dataset.train.physical_costs),
            )
            validation = _ArrayDataset(
                loaded.dataset.validation.contexts,
                loaded.dataset.validation.physical_costs,
                _solve_targets(
                    loaded.problem, loaded.dataset.validation.physical_costs
                ),
            )
            test = _ArrayDataset(
                loaded.dataset.test.contexts,
                loaded.dataset.test.physical_costs,
                _solve_targets(loaded.problem, loaded.dataset.test.physical_costs),
            )
            provenance.append(loaded.provenance)
            for arm in _arms():
                try:
                    row = _train_arm(
                        training_problem,
                        evaluation_problem,
                        train,
                        validation,
                        test,
                        arm,
                        seed=seed,
                        epochs=args.epochs,
                        batch_size=args.batch_size,
                    )
                    all_results.append(row)
                    print(
                        json.dumps(
                            {
                                "seed": seed,
                                "arm": arm["name"],
                                "status": "complete",
                                "val": row["validation_regret"],
                                "test": row["test_regret"],
                            }
                        ),
                        flush=True,
                    )
                except BaseException as error:
                    row = {
                        "name": arm["name"],
                        "kind": "sfge",
                        "seed": seed,
                        "status": "failed",
                        "error_type": type(error).__name__,
                        "error": str(error),
                    }
                    all_results.append(row)
                    print(json.dumps(row), flush=True)
        finally:
            # The persistent solver facade owns its HiGHS instance.
            # PersistentLPSolver has no explicit close operation; its HiGHS
            # handle is released when the short-lived facade is collected.
            del training_problem, evaluation_problem

    receipt = {
        "kind": "public_sfge_external_benchmark",
        "factory_id": args.factory_id,
        "source": {
            "repository": "https://github.com/matsilv/sfge-dfl",
            "checkout": str(PUBLIC_REPO),
            "commit": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=PUBLIC_REPO, text=True
            ).strip(),
            "tree_sha256": _tree_hash(PUBLIC_REPO),
            "external_source": str(EXTERNAL_SRC),
            "pyepo_version": importlib.metadata.version("pyepo"),
            "provenance_by_seed": provenance,
        },
        "dataset": {
            "train": args.num_data,
            "validation": args.validation_data,
            "test": args.test_data,
            "conditional_reference_samples": args.conditional_reference_samples,
            "lp_relaxation_for_training": True,
            "evaluation_semantics": "source model with original integrality",
            "raw_data_persisted": False,
            "raw_weights_persisted": False,
        },
        "arms": _arms(),
        "results": all_results,
        "execution": {
            "epochs": args.epochs,
            "batch_size": args.batch_size,
            "seeds": args.seeds,
            "validation_used_for_checkpoint_selection": True,
            "test_access_during_selection": False,
            "public_training_step": "methods.sfge.SFGEModule.training_step",
            "public_gaussian_model": "utils.probabilistic_models.MultivariateGaussianModule",
            "wall_seconds": time.perf_counter() - started,
        },
    }
    args.output.write_text(json.dumps(receipt, indent=2) + "\n")
    return 0 if not any(row.get("status") == "failed" for row in all_results) else 2


if __name__ == "__main__":
    raise SystemExit(main())
