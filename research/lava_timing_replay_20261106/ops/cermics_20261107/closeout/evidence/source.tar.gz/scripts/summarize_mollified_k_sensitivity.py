"""Resolve the predeclared K=8 versus K=16 confirmation gate."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from summarize_mollified_development import (
    _arm_sha256,
    _embedded_base_digests,
    _file_sha256,
    _rank_arms,
    _resolve_receipt_path,
    _validate_expected_cells,
    _verified_campaign_paths,
    _verify_static_selection_receipt,
)

from proximal_spo.analysis import summarize_validation_selection
from proximal_spo.artifacts import source_sha256, write_json

REPO_ROOT = Path(__file__).resolve().parents[1]


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected an object at {path}")
    return payload


def _verify_provisional(path: Path) -> dict[str, Any]:
    payload, _ = _verify_static_selection_receipt(
        path, required_stage="provisional"
    )
    return payload


def _verify_final_selection(path: Path) -> dict[str, Any]:
    payload = _object(path)
    if payload.get("selection_stage") != "final" or payload.get(
        "confirmation_ready"
    ) is not True:
        raise ValueError("confirmation requires a completed final selection")
    source = payload.get("source_sha256")
    if not isinstance(source, str) or source != source_sha256(REPO_ROOT):
        raise ValueError("final selection source is not the current source")
    selected = payload.get("selected_arm")
    selected_digest = payload.get("selected_arm_sha256")
    if (
        not isinstance(selected, dict)
        or not isinstance(selected_digest, str)
        or _arm_sha256(selected) != selected_digest
    ):
        raise ValueError("final selected arm hash is invalid")
    all_campaigns = _verified_campaign_paths(payload)

    provisional_raw = payload.get("provisional_selection")
    provisional_digest = payload.get("provisional_selection_sha256")
    if not isinstance(provisional_raw, str) or not isinstance(
        provisional_digest, str
    ):
        raise ValueError("final receipt lacks its provisional predecessor")
    provisional_path = _resolve_receipt_path(provisional_raw)
    if (
        not provisional_path.is_file()
        or _file_sha256(provisional_path) != provisional_digest
    ):
        raise ValueError("provisional receipt changed after the K selection")
    provisional = _verify_provisional(provisional_path)

    campaign_raw = payload.get("k_sensitivity_campaign")
    campaign_digest = payload.get("k_sensitivity_campaign_sha256")
    if not isinstance(campaign_raw, str) or not isinstance(campaign_digest, str):
        raise ValueError("final receipt lacks its K-sensitivity campaign")
    campaign_path = _resolve_receipt_path(campaign_raw)
    if not campaign_path.is_file() or _file_sha256(campaign_path) != campaign_digest:
        raise ValueError("K-sensitivity campaign changed after final selection")
    provisional_campaigns = _verified_campaign_paths(provisional)
    if set(all_campaigns) != {*provisional_campaigns, campaign_path}:
        raise ValueError("final receipt campaign chain is incomplete")

    campaign = _object(campaign_path)
    run_root_raw = campaign.get("run_root")
    if not isinstance(run_root_raw, str):
        raise ValueError("K-sensitivity campaign lacks its run root")
    run_root = _resolve_receipt_path(run_root_raw)
    summary = summarize_validation_selection(run_root, source_sha256=source)
    _validate_expected_cells(summary, [campaign_path])
    bases = _embedded_base_digests(summary)
    if bases != provisional.get("embedded_mse_base_digests"):
        raise ValueError("K-sensitivity base receipts differ from the provisional run")
    ranked = _rank_arms(summary)
    if len(ranked) != 1 or int(ranked[0]["training_samples"]) != 16:
        raise ValueError("final K gate must contain exactly one K=16 arm")
    provisional_arm = provisional.get("selected_arm")
    if not isinstance(provisional_arm, dict):
        raise ValueError("provisional receipt lacks its selected arm")
    k16_arm = ranked[0]["arm"]
    if _without_k(provisional_arm) != _without_k(k16_arm):
        raise ValueError("K gate changed settings other than K")
    k8_regret = float(provisional["selected_mean_validation_regret"])
    k16_regret = float(ranked[0]["mean_validation_regret"])
    expected_selected = k16_arm if k16_regret < k8_regret else provisional_arm
    expected_k = int(expected_selected["method_parameters"]["training_samples"])
    if (
        selected != expected_selected
        or payload.get("k8_mean_validation_regret") != k8_regret
        or payload.get("k16_mean_validation_regret") != k16_regret
        or payload.get("selected_training_samples") != expected_k
        or payload.get("k8_adequate") is not (expected_k == 8)
        or payload.get("embedded_mse_base_digests") != bases
    ):
        raise ValueError("final selection does not reproduce from the K gate")
    return payload


def _without_k(arm: dict[str, Any]) -> dict[str, Any]:
    result = json.loads(json.dumps(arm))
    parameters = result.get("method_parameters")
    if not isinstance(parameters, dict):
        raise ValueError("arm lacks method parameters")
    parameters.pop("training_samples", None)
    return result


def _render(payload: dict[str, Any]) -> str:
    return "\n".join(
        [
            "# Mollified PyEPO K-sensitivity gate",
            "",
            "Selection uses mean validation regret across the same three "
            "development seeds.",
            "The K=16 bank is a prefix extension of the K=8 bank.",
            "",
            "- K=8 mean validation regret: "
            f"`{payload['k8_mean_validation_regret']:.9g}`",
            "- K=16 mean validation regret: "
            f"`{payload['k16_mean_validation_regret']:.9g}`",
            f"- Selected training K: `{payload['selected_training_samples']}`",
            f"- Confirmation ready: `{payload['confirmation_ready']}`",
            "",
        ]
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", type=Path)
    parser.add_argument("--expected-campaign", type=Path, required=True)
    parser.add_argument("--provisional-selection", type=Path, required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    arguments = parser.parse_args()
    provisional = _verify_provisional(arguments.provisional_selection)
    source = str(provisional["source_sha256"])
    summary = summarize_validation_selection(
        arguments.run_root, source_sha256=source
    )
    _validate_expected_cells(summary, [arguments.expected_campaign])
    k16_bases = _embedded_base_digests(summary)
    if k16_bases != provisional.get("embedded_mse_base_digests"):
        raise ValueError("K sensitivity did not reuse the frozen MSE base")
    ranked = _rank_arms(summary)
    if len(ranked) != 1 or int(ranked[0]["training_samples"]) != 16:
        raise ValueError("K sensitivity must contain one K=16 arm")
    provisional_arm = provisional["selected_arm"]
    assert isinstance(provisional_arm, dict)
    k16_arm = ranked[0]["arm"]
    if _without_k(provisional_arm) != _without_k(k16_arm):
        raise ValueError("K sensitivity changed settings other than K")
    k8_regret = float(provisional["selected_mean_validation_regret"])
    k16_regret = float(ranked[0]["mean_validation_regret"])
    selected = k16_arm if k16_regret < k8_regret else provisional_arm
    selected_k = int(selected["method_parameters"]["training_samples"])
    inherited = provisional["expected_campaign_receipts"]
    output: dict[str, Any] = {
        "selection_stage": "final",
        "selection_rule": "lower mean validation regret across paired seeds 1, 2, 3",
        "source_sha256": source,
        "provisional_selection": str(arguments.provisional_selection),
        "provisional_selection_sha256": hashlib.sha256(
            arguments.provisional_selection.read_bytes()
        ).hexdigest(),
        "k_sensitivity_campaign": str(arguments.expected_campaign),
        "k_sensitivity_campaign_sha256": _file_sha256(
            arguments.expected_campaign
        ),
        "expected_campaign_receipts": [
            *inherited,
            {
                "path": str(arguments.expected_campaign),
                "sha256": _file_sha256(arguments.expected_campaign),
            },
        ],
        "k8_mean_validation_regret": k8_regret,
        "k16_mean_validation_regret": k16_regret,
        "selected_training_samples": selected_k,
        "k8_adequate": selected_k == 8,
        "selected_arm": selected,
        "selected_arm_sha256": _arm_sha256(selected),
        "embedded_mse_base_digests": k16_bases,
        "confirmation_ready": True,
    }
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, output)
    arguments.markdown_output.write_text(_render(output), encoding="utf-8")


if __name__ == "__main__":
    main()
