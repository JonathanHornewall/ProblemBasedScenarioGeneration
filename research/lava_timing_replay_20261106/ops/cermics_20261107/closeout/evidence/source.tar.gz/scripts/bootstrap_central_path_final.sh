#!/bin/bash
# Environment setup only. Run on a Slurm compute node, never the login node.
set -euo pipefail
RUN_ROOT="${1:?isolated run root required}"
case "$(hostname)" in master*) echo 'Refusing compute on login node' >&2; exit 2;; esac
mkdir -p "$RUN_ROOT/tools" "$RUN_ROOT/runtime"
export UV_INSTALL_DIR="$RUN_ROOT/tools" UV_NO_MODIFY_PATH=1
export UV_PYTHON_INSTALL_DIR="$RUN_ROOT/runtime"
export UV_CACHE_DIR="$RUN_ROOT/uv-cache"
curl -LsSf https://astral.sh/uv/install.sh -o "$RUN_ROOT/uv-installer.sh"
sh "$RUN_ROOT/uv-installer.sh"
"$RUN_ROOT/tools/uv" python install 3.13.5
"$RUN_ROOT/tools/uv" venv "$RUN_ROOT/venv" --python 3.13.5
"$RUN_ROOT/tools/uv" pip sync --python "$RUN_ROOT/venv/bin/python" \
  --extra-index-url https://download.pytorch.org/whl/cpu --index-strategy unsafe-best-match \
  "$RUN_ROOT/requirements.lock"
"$RUN_ROOT/venv/bin/python" -c 'import numpy, torch, pyepo, highspy, cvxpy; print("ENVIRONMENT_READY", numpy.__version__, torch.__version__, highspy.Highs().version())'
touch "$RUN_ROOT/ENVIRONMENT_READY"
