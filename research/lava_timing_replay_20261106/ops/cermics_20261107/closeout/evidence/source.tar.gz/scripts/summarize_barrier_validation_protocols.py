"""Select and compare the four barrier-validation protocols."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from statistics import mean, stdev
from typing import Any

from proximal_spo.artifacts import source_sha256, write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
PROTOCOLS: dict[str, tuple[str, str]] = {
    "terminal": ("terminal", "terminal"),
    "hard_checkpoint": ("hard_checkpoint", "hard_checkpoint"),
    "winner_only_hold": ("hard_checkpoint", "selected_mu_continuation"),
    "all_arm_hold": (
        "selected_mu_continuation",
        "selected_mu_continuation",
    ),
}
SELECTORS = ("soft", "hard_recovered")
DEPLOYMENTS = ("soft", "hard_recovered")


@dataclass(frozen=True)
class RunRow:
    arm_sha256: str
    arm: dict[str, Any]
    benchmark_id: str
    method: str
    seed: int
    run_directory: str
    source_sha256: str
    states: dict[str, Any]
    continuation: dict[str, Any]


def _canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def _arm(config: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(config)
    result.pop("name", None)
    result.pop("seeds", None)
    return result


def _load_runs(root: Path) -> list[RunRow]:
    rows: list[RunRow] = []
    for directory in sorted(path for path in root.iterdir() if path.is_dir()):
        required = (
            directory / "status.json",
            directory / "config.json",
            directory / "environment.json",
            directory / "validation_protocols.json",
        )
        if not all(path.is_file() for path in required):
            continue
        status = json.loads(required[0].read_text())
        if status.get("status") != "complete":
            continue
        config = json.loads(required[1].read_text())
        environment = json.loads(required[2].read_text())
        receipt = json.loads(required[3].read_text())
        if receipt.get("checkpoint_selection_deployment") != "hard_recovered":
            raise ValueError(f"non-hard checkpoint selector in {directory}")
        if receipt.get("soft_validation_selects_epochs") is not False:
            raise ValueError(f"soft validation selected an epoch in {directory}")
        arm = _arm(config)
        rows.append(
            RunRow(
                arm_sha256=hashlib.sha256(_canonical_json(arm)).hexdigest(),
                arm=arm,
                benchmark_id=str(config["benchmark_id"]),
                method=str(config["method"]),
                seed=int(config["seeds"]["data"]),
                run_directory=str(directory.relative_to(REPO_ROOT)),
                source_sha256=str(environment["source_sha256"]),
                states=receipt["states"],
                continuation=receipt["continuation"],
            )
        )
    if not rows:
        raise ValueError(f"no complete protocol runs found under {root}")
    return rows


def _metric(row: RunRow, state: str, split: str, deployment: str) -> float:
    return float(row.states[state][split][deployment]["mean_regret"])


def _standard_error(values: list[float]) -> float:
    return 0.0 if len(values) < 2 else stdev(values) / len(values) ** 0.5


def _select(
    rows: list[RunRow],
    *,
    expected_seeds: frozenset[int],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    grouped: dict[tuple[str, str, str], list[RunRow]] = {}
    for row in rows:
        grouped.setdefault(
            (row.benchmark_id, row.method, row.arm_sha256), []
        ).append(row)
    eligible: dict[tuple[str, str], list[list[RunRow]]] = {}
    incomplete: list[dict[str, Any]] = []
    for (benchmark, method, arm_sha256), arm_rows in grouped.items():
        observed = [row.seed for row in arm_rows]
        if len(observed) != len(set(observed)):
            raise ValueError(f"duplicate protocol seed for arm {arm_sha256}")
        if frozenset(observed) != expected_seeds:
            incomplete.append(
                {
                    "benchmark_id": benchmark,
                    "method": method,
                    "arm_sha256": arm_sha256,
                    "available_seeds": sorted(observed),
                    "missing_seeds": sorted(expected_seeds - set(observed)),
                }
            )
            continue
        arm_rows.sort(key=lambda row: row.seed)
        eligible.setdefault((benchmark, method), []).append(arm_rows)
    selected: list[dict[str, Any]] = []
    for key, candidates in sorted(eligible.items()):
        benchmark, method = key
        for protocol, (ranking_state, outcome_state) in PROTOCOLS.items():
            for selector in SELECTORS:
                ranked = sorted(
                    candidates,
                    key=lambda arm_rows: (
                        mean(
                            _metric(
                                row,
                                ranking_state,
                                "validation",
                                selector,
                            )
                            for row in arm_rows
                        ),
                        arm_rows[0].arm_sha256,
                    ),
                )
                winner = ranked[0]
                validation = {
                    deployment: mean(
                        _metric(row, outcome_state, "validation", deployment)
                        for row in winner
                    )
                    for deployment in DEPLOYMENTS
                }
                test = {
                    deployment: {
                        "mean_regret": mean(
                            _metric(row, outcome_state, "test", deployment)
                            for row in winner
                        ),
                        "standard_error_across_seeds": _standard_error(
                            [
                                _metric(row, outcome_state, "test", deployment)
                                for row in winner
                            ]
                        ),
                    }
                    for deployment in DEPLOYMENTS
                }
                checkpoint_hard = mean(
                    _metric(
                        row,
                        "hard_checkpoint",
                        "validation",
                        "hard_recovered",
                    )
                    for row in winner
                )
                continuation_hard = mean(
                    _metric(
                        row,
                        "selected_mu_continuation",
                        "validation",
                        "hard_recovered",
                    )
                    for row in winner
                )
                selected.append(
                    {
                        "benchmark_id": benchmark,
                        "method": method,
                        "protocol": protocol,
                        "validation_selector": selector,
                        "ranking_state": ranking_state,
                        "outcome_state": outcome_state,
                        "candidate_arm_count": len(candidates),
                        "arm_sha256": winner[0].arm_sha256,
                        "arm": winner[0].arm,
                        "seeds": [row.seed for row in winner],
                        "run_directories": [
                            row.run_directory for row in winner
                        ],
                        "validation": validation,
                        "test": test,
                        "selected_base_epochs": [
                            int(row.states["hard_checkpoint"]["base_epoch"])
                            for row in winner
                        ],
                        "selected_temperatures": [
                            float(row.continuation["selected_temperature"])
                            for row in winner
                        ],
                        "continuation_executed_epochs": [
                            int(row.continuation["executed_epochs"])
                            for row in winner
                        ],
                        "same_arm_validation_hard_continuation_gain": (
                            checkpoint_hard - continuation_hard
                        ),
                        "test_metrics_used_for_selection": False,
                    }
                )
    return selected, incomplete


def _markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Barrier validation protocol comparison",
        "",
        "Every within-run checkpoint was selected by hard recovered-cost "
        "validation regret. Soft validation only ranks arms at that state.",
        "",
        "| Benchmark | Map | Protocol | Selector | Val soft | Val hard | "
        "Test soft | Test hard | Hold gain |",
        "|---|---|---|---|---:|---:|---:|---:|---:|",
    ]
    for row in payload["selected"]:
        lines.append(
            "| {benchmark_id} | {method} | {protocol} | "
            "{validation_selector} | {validation[soft]:.6g} | "
            "{validation[hard_recovered]:.6g} | {soft:.6g} | {hard:.6g} | "
            "{gain:.6g} |".format(
                **row,
                soft=row["test"]["soft"]["mean_regret"],
                hard=row["test"]["hard_recovered"]["mean_regret"],
                gain=row["same_arm_validation_hard_continuation_gain"],
            )
        )
    lines.extend(
        [
            "",
            f"Eligible selected rows: {len(payload['selected'])}.",
            f"Incomplete candidate arms: {len(payload['incomplete_arms'])}.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", type=Path)
    parser.add_argument("--expected-seeds", default="1,2,3")
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    arguments = parser.parse_args()
    expected_seeds = frozenset(
        int(value) for value in arguments.expected_seeds.split(",") if value
    )
    if not expected_seeds:
        raise ValueError("expected seeds cannot be empty")
    run_root = arguments.run_root.resolve()
    rows = _load_runs(run_root)
    observed_sources = sorted({row.source_sha256 for row in rows})
    if len(observed_sources) != 1:
        raise ValueError(f"mixed executable sources: {observed_sources}")
    selected, incomplete = _select(rows, expected_seeds=expected_seeds)
    payload = {
        "status": "development_protocol_comparison",
        "run_root": str(run_root.relative_to(REPO_ROOT)),
        "source_sha256": observed_sources[0],
        "current_source_sha256": source_sha256(REPO_ROOT),
        "expected_seeds": sorted(expected_seeds),
        "checkpoint_selection_deployment": "hard_recovered",
        "soft_validation_selects_epochs": False,
        "test_metrics_used_for_selection": False,
        "selected": selected,
        "incomplete_arms": incomplete,
        "raw_weights_or_data_persisted": False,
    }
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, payload)
    arguments.markdown_output.write_text(_markdown(payload), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
