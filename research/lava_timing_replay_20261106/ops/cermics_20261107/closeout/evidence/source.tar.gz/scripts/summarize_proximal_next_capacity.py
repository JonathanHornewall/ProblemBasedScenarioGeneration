"""Summarize the paired proximal capacity development campaign."""

from __future__ import annotations

import json
import math
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
RUN_ROOT = REPO_ROOT / "runs" / "proximal_next" / "capacity"
RESULT_ROOT = REPO_ROOT / "results" / "proximal_next"
CAPACITIES = ("small", "medium", "large")


def _capacity(name: str) -> str:
    matches = [label for label in CAPACITIES if f"_{label}_s" in name]
    if len(matches) != 1:
        raise ValueError(f"cannot identify capacity in {name}")
    return matches[0]


def _paired_interval(values: list[float]) -> list[float]:
    if len(values) != 3:
        raise ValueError("the development interval requires exactly three seeds")
    mean = statistics.mean(values)
    standard_error = statistics.stdev(values) / math.sqrt(len(values))
    critical = 4.302652729911275
    return [mean - critical * standard_error, mean + critical * standard_error]


def summarize() -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for summary_path in sorted(RUN_ROOT.glob("*/summary.json")):
        run = summary_path.parent
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        config = json.loads((run / "config.json").read_text(encoding="utf-8"))
        method = str(config["method"])
        base = None
        base_path = run / "embedded_mse_base.json"
        if base_path.exists():
            base = json.loads(base_path.read_text(encoding="utf-8"))
        rows.append(
            {
                "method": method,
                "capacity": _capacity(str(config["name"])),
                "data_seed": int(config["seeds"]["data"]),
                "validation_regret": float(
                    summary["best_validation"]["mean_regret"]
                ),
                "test_regret": float(summary["test"]["mean_regret"]),
                "embedded_mse_validation_regret": (
                    None
                    if base is None
                    else float(base["validation"]["mean_regret"])
                ),
                "embedded_mse_test_regret": (
                    None if base is None else float(base["test"]["mean_regret"])
                ),
                "best_epoch": int(summary["best_epoch"]),
                "wall_seconds": float(
                    summary["whole_pipeline_training_wall_seconds"]
                ),
                "run_directory": str(run.relative_to(REPO_ROOT)),
            }
        )
    if len(rows) != 36:
        raise ValueError(f"expected 36 completed capacity runs, found {len(rows)}")
    lookup = {
        (row["method"], row["capacity"], row["data_seed"]): row for row in rows
    }
    groups: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[(row["method"], row["capacity"])].append(row)
    aggregates: list[dict[str, Any]] = []
    for (method, capacity), group in sorted(groups.items()):
        if len(group) != 3:
            raise ValueError(f"incomplete group {method}/{capacity}")
        paired: list[float] = []
        for row in group:
            if method == "mse":
                continue
            if method == "proximal":
                baseline = lookup[("mse", capacity, row["data_seed"])][
                    "test_regret"
                ]
            else:
                baseline = row["embedded_mse_test_regret"]
                if baseline is None:
                    raise ValueError(f"{method} lacks its embedded MSE receipt")
            paired.append(float(row["test_regret"]) - float(baseline))
        aggregates.append(
            {
                "method": method,
                "capacity": capacity,
                "seed_count": len(group),
                "mean_validation_regret": statistics.mean(
                    row["validation_regret"] for row in group
                ),
                "mean_test_regret": statistics.mean(
                    row["test_regret"] for row in group
                ),
                "mean_wall_seconds": statistics.mean(
                    row["wall_seconds"] for row in group
                ),
                "mean_paired_test_delta": (
                    None if not paired else statistics.mean(paired)
                ),
                "paired_test_wins": None if not paired else sum(x < 0 for x in paired),
                "paired_test_t_95_interval": (
                    None if not paired else _paired_interval(paired)
                ),
            }
        )
    return {"status": "complete", "rows": rows, "aggregates": aggregates}


def _markdown(summary: dict[str, Any]) -> str:
    lines = [
        "# Proximal capacity development",
        "",
        "Paired deltas compare raw Proximal with same-capacity MSE and anchored "
        "methods with their identical embedded MSE base. Negative is better.",
        "",
        "| method | capacity | validation | test | paired delta | wins | wall s |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for row in summary["aggregates"]:
        delta = row["mean_paired_test_delta"]
        wins = row["paired_test_wins"]
        lines.append(
            f"| {row['method']} | {row['capacity']} | "
            f"{row['mean_validation_regret']:.6f} | "
            f"{row['mean_test_regret']:.6f} | "
            f"{'--' if delta is None else f'{delta:+.6f}'} | "
            f"{'--' if wins is None else f'{wins}/3'} | "
            f"{row['mean_wall_seconds']:.1f} |"
        )
    return "\n".join(lines) + "\n"


def main() -> None:
    result = summarize()
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    write_json(RESULT_ROOT / "capacity.json", result)
    (RESULT_ROOT / "capacity.md").write_text(_markdown(result), encoding="utf-8")
    print(RESULT_ROOT / "capacity.md")


if __name__ == "__main__":
    main()
