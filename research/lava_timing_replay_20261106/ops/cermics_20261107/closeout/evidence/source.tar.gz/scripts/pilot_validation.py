"""Two validation views of one deterministic training trajectory."""
from __future__ import annotations
import copy
import random
import time
from dataclasses import replace
from pathlib import Path
import numpy as np
import torch
from pilot_common import sha

def prefix(split, n):
    return replace(split, **{k:v[:n] for k,v in vars(split).items() if isinstance(v,np.ndarray)})

class DualRecorder:
    def __init__(self, recorder, model, objective, validation, job, directory, batch_size, minimum_delta):
        if len(validation.contexts)!=100: raise ValueError('Dual validation requires 100 observations')
        self.recorder=recorder;self.model=model;self.objective=objective;self.validation=validation
        self.job=job;self.directory=Path(directory);self.batch_size=batch_size;self.minimum_delta=minimum_delta
        self.views={};self.extra_wall_seconds=0.0

    def __getattr__(self,name): return getattr(self.recorder,name)

    def append_curve(self,row):
        from proximal_spo.evaluation import evaluate_model
        from proximal_spo.artifacts import model_sha256
        if row.get('validation') is not None:
            started=time.perf_counter()
            # The extra evaluation must not perturb any training RNG stream.
            state=(random.getstate(),np.random.get_state(),torch.random.get_rng_state())
            try:
                small=evaluate_model(self.model,self.objective,prefix(self.validation,32),batch_size=self.batch_size).to_dict()
            finally:
                random.setstate(state[0]);np.random.set_state(state[1]);torch.random.set_rng_state(state[2])
            elapsed=time.perf_counter()-started;self.extra_wall_seconds+=elapsed
            row['validation_by_size']={'32':small,'100':copy.deepcopy(row['validation'])}
            row['extra_validation32_wall_seconds']=elapsed
            for n,metrics in row['validation_by_size'].items():
                score=float(metrics['mean_regret']);previous=self.views.get(n)
                if previous is None or score < previous['best_selection_score']-self.minimum_delta:
                    path=self.directory/f'validation_{n}_model.pt'
                    temporary=path.with_suffix('.pt.tmp')
                    torch.save({'model':{k:v.detach().cpu().clone() for k,v in self.model.state_dict().items()},
                        'epoch':row['epoch'],'job':self.job,'validation_size':int(n)},temporary)
                    temporary.replace(path)
                    self.views[n]={'best_epoch':row['epoch'],'best_selection_score':score,
                        'best_validation':copy.deepcopy(metrics),'parameter_sha256':model_sha256(self.model),
                        'checkpoint':str(path),'checkpoint_sha256':sha(path)}
        self.recorder.append_curve(row)

    def summaries(self):
        if set(self.views)!={'32','100'}: raise RuntimeError('Incomplete validation views')
        return copy.deepcopy(self.views)

def freeze_single(model, directory, best_epoch, best_score, job):
    from proximal_spo.artifacts import model_sha256
    path=Path(directory)/'model.pt'
    if not path.exists():torch.save({'model':model.state_dict(),'epoch':best_epoch,'job':job},path)
    return {'selection_uses_test':False,'best_epoch':best_epoch,'best_validation_score':best_score,
        'parameter_sha256':model_sha256(model),'checkpoint_sha256':sha(path),
        'validation_size':job['config']['sizes']['validation']}

