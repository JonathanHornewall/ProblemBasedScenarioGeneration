"""Full-dimension, training-only checks kept outside scientific selection."""
import argparse
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor

from build_central_path_final import read, write
from central_path_slurm import environment


def intopt_probe(root, route):
    import torch
    from physical128_data import load_job
    from proximal_spo.intopt_original import OriginalIntOptObjective
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    j=next(j for j in read(root/'screen.json')['jobs'] if j['method']=='intopt_original' and j['route']==route and j['parameters']['mu_cutoff']==1e-3)
    loaded=load_job(j)
    assert not loaded.provenance['test_bank_opened']
    assert (loaded.dataset.train.physical_costs==loaded.dataset.train.conditional_mean_costs).all()
    objective=OriginalIntOptObjective(loaded.problem,mu_cutoff=1e-3)
    prediction=torch.tensor(loaded.dataset.train.physical_costs.mean(axis=0)[None,:],dtype=torch.float32,requires_grad=True)
    observation=torch.tensor(loaded.dataset.train.physical_costs[:1],dtype=torch.float32)
    start=time.monotonic()
    result=objective.torch_signal(prediction,observation,torch.zeros(1))
    result.values.mean().backward()
    assert torch.isfinite(result.values).all() and torch.isfinite(prediction.grad).all()
    out={'status':'complete','route':route,'method':'intopt_original','single_context_forward_backward_seconds':time.monotonic()-start,
        'cost_dimension':loaded.problem.variable_count,'gradient_norm':float(prediction.grad.norm()),
        'public_hsd_indicators':objective.source.last_indicators,'test_bank_opened':False,
        'scientifically_eligible':False,'objective_receipt':objective.receipt()}
    objective.close();write(root/'preflight/intopt'/f'{route}.json',out)


def main(root):
    screen=read(root/'screen.json');controls=read(root/'CONTROL_JOBS.json')
    jobs=[]
    for source in controls:
        if source['repeat']!=0:continue
        for label,flags in [('control',{}),('no_guard',{'report_guard':False}),('no_center_scale',{'barrier_cost_scaling':'unit'}),('neither',{'report_guard':False,'barrier_cost_scaling':'unit'})]:
            j=copy.deepcopy(source)
            for key in ('frozen_horizon','original_checkpoint','original_job'):j.pop(key,None)
            j.update(id='diagnostic__'+source['route']+'__'+label,stage='screen',diagnostic_only=True,physical128_revision='physical_head_test128_20260925_v1')
            j['config']['name']=j['id'];j['config']['evaluate_test']=False
            j['config']['sizes']={'train':100,'validation':32,'test':128}
            j['config']['method_parameters'].update(flags)
            j['config']['training'].update(epochs=1,validation_epochs=[1],patience=2,selection_mode='validation_regret',maximum_optimization_seconds=180)
            j['resource_limits']={'preprocessing_cap_seconds':300,'job_wall_cap_seconds':600}
            jobs.append(j)
    path=root/'preflight/diagnostic.json';write(path,{**screen,'jobs':jobs})
    output=root/'preflight/results';(output/'logs').mkdir(parents=True,exist_ok=True)
    env=environment(root)
    tasks=[('cps',i) for i in range(len(jobs))]+[('intopt',r) for r in sorted({j['route'] for j in jobs})]
    def run(task):
        kind,index=task
        label=jobs[index]['id'] if kind=='cps' else 'intopt__'+index
        cmd=([str(root/'venv/bin/python'),str(root/'code/scripts/run_central_path_final.py'),'--manifest',str(path),'--job-index',str(index),'--output-root',str(output)] if kind=='cps' else
             [str(root/'venv/bin/python'),str(root/'code/scripts/preflight_cps_intopt_campaign.py'),'--root',str(root),'--intopt-route',index])
        with (output/'logs'/(label+'.log')).open('w') as log:
            child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            try:code=child.wait(timeout=650)
            except subprocess.TimeoutExpired:
                import signal
                os.killpg(child.pid,signal.SIGKILL);child.wait();code=124
        record_path=output/'receipts'/(label+'.json') if kind=='cps' else root/'preflight/intopt'/f'{index}.json'
        receipt=read(record_path) if record_path.exists() else {}
        issue=None
        if code or receipt.get('status')!='complete':
            issue=receipt.get('error','failed or timed out; see diagnostic log')
        if kind=='cps' and receipt.get('status')=='complete':
            assert receipt.get('test_bank_opened') is False and receipt.get('test_access') is False
        allowed_guard_failure=(kind=='cps' and (label.endswith('__no_guard') or label.endswith('__neither')) and
                               receipt.get('error_type')=='OracleFailure' and 'interior feasibility' in str(issue))
        result={'diagnostic':label,'status':receipt.get('status','missing'),'returncode':code,
                'issue':issue,'literal_guard_removal_numerical_failure':allowed_guard_failure}
        print(json.dumps(result),flush=True);return result
    with ThreadPoolExecutor(max_workers=8) as executor:
        results=list(executor.map(run,tasks))
    failures=[x for x in results if x['issue'] and not x['literal_guard_removal_numerical_failure']]
    proof={'status':'failed' if failures else 'complete','diagnostics':len(results),'results':results,
           'implementation_issues':failures,'scientifically_eligible':False}
    write(root/'preflight/VERIFICATION.json',proof)
    return bool(failures)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--intopt-route')
    args=p.parse_args()
    if args.intopt_route:intopt_probe(args.root,args.intopt_route)
    else:sys.exit(main(args.root))
