"""Combine the matched anchored and comparator development panels."""

from __future__ import annotations

import json
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any

from build_broad_cost_campaigns import DESIGNS
from build_proximal_next_campaigns import DEVELOPMENT_SEEDS

from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
ANCHOR_ROOT = REPO_ROOT / "runs" / "proximal_next" / "broad_matched_anchor"
COMPARATOR_ROOT = REPO_ROOT / "runs" / "proximal_next" / "broad_comparators"
METHODS = ("mse", "anchored_proximal", "proximal", "spo_plus", "wise", "knn")


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected object in {path}")
    return value


def _method_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for summary_path in sorted(ANCHOR_ROOT.glob("*/summary.json")):
        run = summary_path.parent
        summary = _load(summary_path)
        config = _load(run / "config.json")
        base = _load(run / "embedded_mse_base.json")
        phases = summary.get("training_phases", [])
        base_phases = [
            phase
            for phase in phases
            if isinstance(phase, dict) and phase.get("name") == "base_pretrain"
        ]
        if len(base_phases) != 1:
            raise ValueError(f"missing base-pretrain timing in {summary_path}")
        common = {
            "benchmark_id": str(config["benchmark_id"]),
            "data_seed": int(config["seeds"]["data"]),
        }
        rows.append(
            {
                **common,
                "method": "anchored_proximal",
                "test_regret": float(summary["test"]["mean_regret"]),
                "validation_regret": float(
                    summary["best_validation"]["mean_regret"]
                ),
                "wall_seconds": float(
                    summary["whole_pipeline_training_wall_seconds"]
                ),
            }
        )
        rows.append(
            {
                **common,
                "method": "mse",
                "test_regret": float(base["test"]["mean_regret"]),
                "validation_regret": float(base["validation"]["mean_regret"]),
                "wall_seconds": float(base_phases[0]["training_wall_seconds"]),
            }
        )
    for summary_path in sorted(COMPARATOR_ROOT.glob("*/summary.json")):
        run = summary_path.parent
        summary = _load(summary_path)
        config = _load(run / "config.json")
        rows.append(
            {
                "benchmark_id": str(config["benchmark_id"]),
                "data_seed": int(config["seeds"]["data"]),
                "method": str(config["method"]),
                "test_regret": float(summary["test"]["mean_regret"]),
                "validation_regret": float(
                    summary["best_validation"]["mean_regret"]
                ),
                "wall_seconds": float(
                    summary.get(
                        "whole_pipeline_training_wall_seconds",
                        summary["training_wall_seconds"],
                    )
                ),
            }
        )
    return rows


def summarize() -> dict[str, Any]:
    rows = _method_rows()
    expected = {
        (design.benchmark_id, method, seed)
        for design in DESIGNS
        for method in METHODS
        for seed in DEVELOPMENT_SEEDS
    }
    observed = {
        (row["benchmark_id"], row["method"], row["data_seed"]) for row in rows
    }
    if observed != expected or len(rows) != len(expected):
        missing = sorted(expected - observed)
        extra = sorted(observed - expected)
        raise ValueError(
            f"incomplete broad panel: missing={missing[:5]}, extra={extra[:5]}, "
            f"rows={len(rows)}, expected={len(expected)}"
        )

    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    lookup: dict[tuple[str, str, int], dict[str, Any]] = {}
    for row in rows:
        grouped[(row["benchmark_id"], row["method"])].append(row)
        lookup[(row["benchmark_id"], row["method"], row["data_seed"])] = row
    aggregates = []
    for (benchmark_id, method), group in sorted(grouped.items()):
        aggregates.append(
            {
                "benchmark_id": benchmark_id,
                "method": method,
                "seed_count": len(group),
                "mean_validation_regret": statistics.mean(
                    row["validation_regret"] for row in group
                ),
                "mean_test_regret": statistics.mean(
                    row["test_regret"] for row in group
                ),
                "mean_wall_seconds": statistics.mean(
                    row["wall_seconds"] for row in group
                ),
            }
        )

    paired = []
    for design in DESIGNS:
        for baseline in ("mse", "spo_plus", "proximal"):
            deltas = [
                lookup[(design.benchmark_id, "anchored_proximal", seed)][
                    "test_regret"
                ]
                - lookup[(design.benchmark_id, baseline, seed)]["test_regret"]
                for seed in DEVELOPMENT_SEEDS
            ]
            paired.append(
                {
                    "benchmark_id": design.benchmark_id,
                    "method": "anchored_proximal",
                    "baseline": baseline,
                    "mean_test_delta": statistics.mean(deltas),
                    "wins": sum(delta < 0 for delta in deltas),
                    "seed_count": len(deltas),
                }
            )
    return {
        "status": "complete",
        "development_only": True,
        "rows": rows,
        "aggregates": aggregates,
        "paired": paired,
    }


def _markdown(summary: dict[str, Any]) -> str:
    by_key = {
        (row["benchmark_id"], row["method"]): row
        for row in summary["aggregates"]
    }
    lines = [
        "# Broad capacity-matched development panel",
        "",
        "Three paired development seeds; lower test regret is better. Hyperparameters "
        "were selected in the earlier small-model development campaign and promoted "
        "without retuning.",
        "",
        "| benchmark | MSE | anchored | raw proximal | SPO+ | WISE | kNN |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for design in DESIGNS:
        values = [
            by_key[(design.benchmark_id, method)]["mean_test_regret"]
            for method in METHODS
        ]
        lines.append(
            f"| {design.benchmark_id} | "
            + " | ".join(f"{value:.6f}" for value in values)
            + " |"
        )
    lines.extend(
        [
            "",
            "## Anchored proximal paired differences",
            "",
            "Negative values favor anchored proximal.",
            "",
            "| benchmark | baseline | delta | wins |",
            "|---|---|---:|---:|",
        ]
    )
    for row in summary["paired"]:
        lines.append(
            f"| {row['benchmark_id']} | {row['baseline']} | "
            f"{row['mean_test_delta']:+.6f} | "
            f"{row['wins']}/{row['seed_count']} |"
        )
    return "\n".join(lines) + "\n"


def main() -> None:
    result = summarize()
    output_root = REPO_ROOT / "results" / "proximal_next"
    output_root.mkdir(parents=True, exist_ok=True)
    write_json(output_root / "broad_comparator_panel.json", result)
    (output_root / "broad_comparator_panel.md").write_text(
        _markdown(result), encoding="utf-8"
    )
    print(output_root / "broad_comparator_panel.md")


if __name__ == "__main__":
    main()
