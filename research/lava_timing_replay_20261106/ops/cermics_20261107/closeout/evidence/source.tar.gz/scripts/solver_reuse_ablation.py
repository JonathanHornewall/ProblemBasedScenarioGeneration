"""Prepare the exact main-table solver-lifecycle manifest; never launch fits."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import gzip
import hashlib
import itertools
import json
from pathlib import Path

REVISION = "solver_reuse_ablation_20261024_v1"
METHODS = ("spo_plus", "pfyl", "nce")
MODES = ("persistent_basis", "persistent_clear", "rebuild")
DEFAULT_RUN = "solver_reuse_ablation_20261024"
SEED_FIELDS = ("data", "initialization", "shuffle", "perturbation", "structural")


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")


def family(route):
    if route.startswith("dys_shortest_path_"):
        return "sp"
    if route.startswith("dys_cfl_"):
        return "cfl"
    if route.startswith("dys_knapsack_"):
        return "kp"
    if route.startswith("lava_random_lp_"):
        return "rlp"
    raise ValueError("Route outside the original main table")


def prepare(repo, output):
    if output.exists() and set(p.name for p in output.iterdir()) - {"analysis_preparation"}:
        raise FileExistsError("Explicit run root already exists; never replace its manifest")
    scaled = repo / "runs/scaled_data_neural_20261021"
    report = scaled / "reports/training_times_300epochs_20261024"
    ledger_path = scaled / "reports/validation_selected_linear_neural_20261023/selection_ledger.json"
    ledger = json.loads(ledger_path.read_text())
    assert ledger["selection_frozen_before_test_scalar_load"]
    choices = {(x["N"], x["method"], x["family"]): x for x in ledger["choices"]
               if x["method"] in METHODS}
    assert len(choices) == 48 and all(not x["test_scores_used"] for x in choices.values())
    with (report / "per_seed.csv").open() as f:
        rows = [r for r in csv.DictReader(f) if r["method"] in METHODS]
    assert len(rows) == 4800
    requested = {r["job_id"] for r in rows}
    references = {}
    for source_path in sorted({r["source_snapshot"] for r in rows}):
        with gzip.open(repo / source_path, "rt") as stream:
            data = json.load(stream)
        records = data.get("records", data.get("finals"))
        records = records.values() if isinstance(records, dict) else records
        for record in records:
            job = record["job"]
            if job["id"] in requested:
                assert record["status"] == "complete"
                prior = references.setdefault(job["id"], job)
                assert prior == job
    assert set(references) == requested and len(references) == 3000
    aliases, timings = defaultdict(list), {}
    for row in rows:
        job = references[row["job_id"]]
        n, method, route, depth = int(row["N"]), row["method"], row["route"], int(row["depth"])
        choice = choices[n, method, family(route)]
        assert n in (100, 300, 500, 1000) and method in METHODS
        assert job["config"]["sizes"]["train"] == n
        assert job["training_oracle"] == "continuous_relaxation" and not job["wise_transform"]
        assert job["config"]["model"]["depth"] == depth
        assert depth == (choice["chosen_depth"] if row["mode"] == "selected" else 0)
        assert row["chosen_phase"] == choice["chosen_phase" if row["mode"] == "selected" else "linear_phase"]
        assert all(int(row[k]) == job["config"]["seeds"][k] for k in SEED_FIELDS)
        training = job["config"]["training"]
        assert training["epochs"] == int(row["epochs_completed"]) == 300
        assert (training["optimizer"], training["batch_size"], training["weight_decay"],
                training["gradient_clip"], training["torch_threads"]) == ("adam", 32, 0., None, 1)
        assert training["maximum_optimization_seconds"] is None
        aliases[job["id"]].append({"panel": row["panel"], "N": n,
            "architecture_panel": row["mode"], "route": route, "method": method,
            "depth": depth, "source_job_id": job["id"]})
        timings[job["id"]] = float(row["optimization_wall_seconds"])
    permutations = list(itertools.permutations(MODES))
    seed_keys = {}
    for job in references.values():
        seeds = job["config"]["seeds"]
        seed_keys[digest(seeds)] = seeds
    assert len(seed_keys) == 10
    triplets, fits = [], []
    for index, (reference_id, job) in enumerate(sorted(references.items())):
        original_digest = digest(job)
        triplet_id = "slrt__" + digest({"revision": REVISION, "reference_job": original_digest})[:32]
        order = permutations[index % len(permutations)]
        fit_ids = {}
        for mode in MODES:
            fit_id = "slr__" + digest({"revision": REVISION,
                "reference_job": original_digest, "mode": mode})[:32]
            fit_ids[mode] = fit_id
            fits.append({"id": fit_id, "triplet_id": triplet_id, "mode": mode,
                "reference_job_id": reference_id, "reference_job_sha256": original_digest})
        triplets.append({"id": triplet_id, "reference_job_id": reference_id,
            "reference_job_sha256": original_digest, "method": job["method"],
            "route": job["route"], "N": job["config"]["sizes"]["train"],
            "depth": job["config"]["model"]["depth"], "seeds": job["config"]["seeds"],
            "original_seed_bundle_sha256": digest(job["config"]["seeds"]),
            "mode_order": list(order), "fit_ids": fit_ids,
            "logical_rows": aliases[reference_id],
            "reference_optimization_wall_seconds": timings[reference_id],
            "memory_gib": 6 if job["method"] == "nce" and job["route"] == "dys_cfl_500x10" else 3,
            "input_bank_group": "scaled" if job.get("scaled_data_neural_revision") else "simplified",
            "input_bank_key": job["route"] + "__data" + str(job["config"]["seeds"]["data"])})
    assert len(fits) == len({f["id"] for f in fits}) == 9000
    ref_hours = sum(timings.values()) / 3600
    counts = {
        "method_N_family_selection_entries": len(choices),
        "unique_method_N_family_depth_entries": len({(t['method'], t['N'], family(t['route']), t['depth']) for t in triplets}),
        "routes": len({t["route"] for t in triplets}), "original_seed_bundles": 10,
        "logical_reference_rows": len(rows), "distinct_reference_fits": len(triplets),
        "fresh_mode_fits": len(fits), "logical_mode_rows": len(rows) * 3,
        "by_method": dict(Counter(t["method"] for t in triplets)),
        "fresh_fits_by_method": {m: sum(t["method"] == m for t in triplets) * 3 for m in METHODS},
    }
    assert counts["unique_method_N_family_depth_entries"] == 60
    lookup_path = output / "analysis_preparation/analyzer_inventory_20261024_v1/MAIN_REFERENCE_LOOKUP.json.gz"
    with gzip.open(lookup_path, "rt") as stream:
        lookup = json.load(stream)["fits"]
    assert set(lookup) == set(references)
    expected_hashes = {}
    for jid, reference in references.items():
        assert lookup[jid]["job"] == reference
        expected_hashes[jid] = {k: lookup[jid]["data_hashes"][k] for k in ("train", "validation")}
    hashes_bytes = gzip.compress(json.dumps(expected_hashes, sort_keys=True,
        separators=(",", ":")).encode(), mtime=0)
    manifest = {"revision": REVISION, "status": "AWAITING_PARENT_REVIEW",
        "counts": counts, "modes": list(MODES), "triplets": triplets, "fits": fits,
        "selection_ledger": str(ledger_path.relative_to(repo)),
        "selection_ledger_sha256": hashlib.sha256(ledger_path.read_bytes()).hexdigest(),
        "expected_input_hashes": {"path": "EXPECTED_INPUT_HASHES.json.gz",
            "sha256": hashlib.sha256(hashes_bytes).hexdigest(),
            "source": "analysis_preparation/analyzer_inventory_20261024_v1/MAIN_REFERENCE_LOOKUP.json.gz",
            "scope": "Original training and observed validation arrays; sealed test unopened"},
        "logical_alias_policy": "Selected depth0 and linear rows share the exact same new fit; old fits are references only",
        "input_roots": {"scaled": "/home/jonathan.hornewall/runs/scaled_data_neural_20261021/frozen_data",
                        "simplified": "/home/jonathan.hornewall/runs/simplified_linear_campaign_20261020/frozen_data"},
        "protocol": {"training_oracle": "continuous_relaxation", "epochs": 300,
            "selection": "Exact old validation-only configuration, architecture and checkpoint schedule",
            "seed_policy": "Exact original full confirmation bundles; never derive replacement seeds",
            "preprocessing": "Same original per-method optDataset LP labels in all modes; snapshot counters afterward",
            "loss_policy": "Unmodified PyEPO1.0.2; NCE pool and solve_ratio unchanged",
            "recovery": "Original method-specific unknown/cold/scaled semantics with explicit native disposal",
            "pairing": "Three fresh processes sequentially on the same node and logical CPU; rotate mode order",
            "ties": "Solver tie-breaking may change trajectories; record outcomes without forcing parity or retuning",
            "timing": "Native aggregate wall/CPU clocks plus unchanged full300epoch optimization clocks; exclude preparation/validation/test"},
        "resources": {"site": "cermics", "additional_cpu_ceiling": 150,
            "cpu_ceiling_scope": "This campaign only; preserve all existing healthy allocations",
            "partitions_priority": ["defq", "defq-gpu"], "nice": 10000,
            "requeue": True, "threads_per_fit": 1, "gpu_count": 0,
            "protective_attempt_hours_proposed": 72,
            "reserve_bytes": 4 * 2**30, "storage_budget_pending_measurement": True},
        "artifacts": {"test_prediction_arrays": False,
            "checkpoint_policy": "maintained last/best/selected checkpoints; retain failures and logs",
            "projected_new_growth_gib": 8, "checkpoint_payload_estimate_gib": 2.072,
            "scope": "No input copies; compact per-seed metrics and timing records; no raw archive recovery"},
        "timing_estimate": {"reference_optimization_wall_hours": ref_hours,
            "three_reference_mode_optimization_wall_hours_proxy": 3 * ref_hours,
            "ideal_hours_at150_additional_cpus_proxy": 3 * ref_hours / 150,
            "longest_reference_triplet_hours_proxy": 3 * max(timings.values()) / 3600,
            "interpretation": "Planning proxy from old heterogeneous lifecycle/hardware timings; not a bound. "
                "Mode effects, preparation, evaluation, queueing and shared-host load remain unknown."},
        "handoff": {"main": "01a14a8b-3d7c-7d23-a8bb-2baa8f90c86c",
            "monitor": "01a167fb-97f6-7903-bb05-c7d19da0ab4f",
            "analyzer": "01a167fc-0385-7502-b7aa-744fc489c456"},
        "launch_gate": "Require parent REVIEW_READY for this exact manifest hash before new scientific fits",
        "preservation": "Compact code/seeds/configs/selections/per-seed metrics; no raw archive recovery or dependency cleanup",
    }
    output.mkdir(parents=True, exist_ok=True)
    write(output / "MANIFEST.json", manifest)
    (output / "EXPECTED_INPUT_HASHES.json.gz").write_bytes(hashes_bytes)
    compressed = gzip.compress(json.dumps(references, sort_keys=True, separators=(",", ":")).encode(), mtime=0)
    (output / "REFERENCE_JOBS.json.gz").write_bytes(compressed)
    write(output / "SEEDS.json", {"bundles": list(seed_keys.values()), "derived_seeds": False})
    write(output / "SELECTIONS.json", {"choices": list(choices.values()), "test_scores_used": False,
        "authoritative_ledger_sha256": manifest["selection_ledger_sha256"]})
    write(output / "PREPARATION.json", {"manifest_sha256": hashlib.sha256(
        (output / "MANIFEST.json").read_bytes()).hexdigest(),
        "reference_jobs_sha256": hashlib.sha256(compressed).hexdigest(),
        "numerical_fits_launched": 0, "status": "AWAITING_PARENT_REVIEW"})
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    plan = prepare(args.repo, args.output or args.repo / "runs" / DEFAULT_RUN)
    print(json.dumps({"counts": plan["counts"], "timing_estimate": plan["timing_estimate"]}, indent=2))
