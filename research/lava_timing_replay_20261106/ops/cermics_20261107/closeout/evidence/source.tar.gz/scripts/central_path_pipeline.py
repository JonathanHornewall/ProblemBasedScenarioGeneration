"""Advance independent method/setting groups through the frozen selection rule."""

from collections import defaultdict
import copy

from build_central_path_final import read, sha, write
from select_central_path_final import transition
from central_path_recovery import MemoryRecovery, RecoveryPending


class Pipeline:
    def __init__(self, root):
        self.root = root
        self.screen = read(root / "screen.json")
        # The original screen is immutable. An explicitly authorized additive
        # screen contributes disjoint selection groups and only appends jobs.
        self.fingerprint = sha(self.screen)
        addition_path = root / "additional_screen.json"
        addition = read(addition_path) if addition_path.exists() else None
        if addition is not None:
            original_groups = {(j["cell"], j["method"]) for j in self.screen["jobs"]}
            added_groups = {(j["cell"], j["method"]) for j in addition["jobs"]}
            if original_groups & added_groups:
                raise ValueError("additive screen would change an existing selection group")
            self.screen = copy.deepcopy(self.screen)
            for cell, info in addition["cells"].items():
                if cell in self.screen["cells"] and self.screen["cells"][cell] != info:
                    raise ValueError("additive screen changes an existing cell: " + cell)
                self.screen["cells"][cell] = info
            self.screen["methods"] = sorted(set(self.screen["methods"]) | set(addition["methods"]))
            self.screen["jobs"].extend(addition["jobs"])
            self.screen["cell_methods"] = {
                cell: sorted({j["method"] for j in self.screen["jobs"] if j["cell"] == cell})
                for cell in self.screen["cells"]
            }
        self.screen = copy.deepcopy(self.screen)
        self.recovery = MemoryRecovery(root, self.screen)
        self.path = root / "execution.json"
        self.groups = defaultdict(list)
        for job in self.screen["jobs"]:
            self.groups[(job["cell"], job["method"])].append(job)
        self.frozen = {"refinement": {}, "confirmation": {}}
        if self.path.exists():
            self.execution = read(self.path)
            if self.execution.get("screen_fingerprint") != self.fingerprint:
                raise ValueError("execution queue belongs to a different screen")
        else:
            self.execution = {
                **self.screen,
                "jobs": list(self.screen["jobs"]),
                "screen_fingerprint": self.fingerprint,
            }
            write(self.path, self.execution)
        self.known = {j["id"]: j for j in self.execution["jobs"]}
        if addition is not None:
            if self.execution.get("additional_screen_fingerprint", sha(addition)) != sha(addition):
                raise ValueError("the frozen additive screen changed")
            for job in addition["jobs"]:
                previous = self.known.get(job["id"])
                if previous is not None and previous != job:
                    raise ValueError("additive job identity changed: " + job["id"])
                if previous is None:
                    self.execution["jobs"].append(job)
                    self.known[job["id"]] = job
            self.execution.update(
                cells=self.screen["cells"], methods=self.screen["methods"],
                cell_methods=self.screen["cell_methods"],
                additional_screen_fingerprint=sha(addition),
            )
            write(self.path, self.execution)

        if self.recovery.attach(self.execution, self.known):
            write(self.path, self.execution)

    def refresh(self):
        """Append work only after its entire own development group is terminal."""
        changed = False
        for source_stage, target in (
            ("screen", "refinement"),
            ("refinement", "confirmation"),
        ):
            stage_changed = False
            for key in sorted(self.groups):
                if key in self.frozen[target]:
                    continue
                if (
                    source_stage == "refinement"
                    and key not in self.frozen[source_stage]
                ):
                    continue
                source = (
                    self.screen
                    if source_stage == "screen"
                    else self.frozen[source_stage][key]
                )
                jobs = self.groups[key] if source_stage == "screen" else source["jobs"]
                cell, method = key
                subset = {
                    **source,
                    "cells": {cell: self.screen["cells"][cell]},
                    "methods": [method],
                    "cell_methods": {cell: [method]},
                    "jobs": jobs,
                }
                signature = sha(subset)
                path = (
                    self.root
                    / "results/selections"
                    / (target + "__" + cell + "__" + method + self.recovery.suffix(key) + ".json")
                )
                if path.exists():
                    selected = read(path)
                    if selected.get("source_fingerprint") != signature:
                        raise ValueError(
                            "frozen group differs from source: " + str(key)
                        )
                else:
                    if not all(
                        (self.root / "results/receipts" / (j["id"] + ".json")).exists()
                        for j in jobs
                    ):
                        continue
                    if jobs:
                        selected = transition(subset, self.root / "results")
                    else:
                        selected = {
                            **subset,
                            "jobs": [],
                            "selection_receipt": {
                                "from_stage": source_stage,
                                "decisions": [],
                                "unavailable": [],
                                "missing_cells": [
                                    {
                                        "cell": cell,
                                        "method": method,
                                        "reason": "no eligible development candidate",
                                    }
                                ],
                                "test_scores_read": False,
                            },
                        }
                    try:
                        self.recovery.selected_jobs(key, selected, self.known)
                    except RecoveryPending:
                        continue
                    selected["source_fingerprint"] = signature
                    write(path, selected)
                self.frozen[target][key] = selected
                stage_changed = True
                for job in selected["jobs"]:
                    previous = self.known.get(job["id"])
                    if previous is not None:
                        if previous != job:
                            raise ValueError(
                                "append-only queue job changed: " + job["id"]
                            )
                    else:
                        self.execution["jobs"].append(job)
                        self.known[job["id"]] = job
                        changed = True
            if stage_changed or not (self.root / (target + ".json")).exists():
                parts = [self.frozen[target][k] for k in sorted(self.frozen[target])]
                aggregate = {
                    **self.screen,
                    "jobs": [j for part in parts for j in part["jobs"]],
                    "selection_receipt": {
                        "from_stage": source_stage,
                        **{
                            field: [
                                x
                                for part in parts
                                for x in part["selection_receipt"][field]
                            ]
                            for field in ("decisions", "unavailable", "missing_cells")
                        },
                        "test_scores_read": False,
                    },
                    "pipeline": {
                        "selected_groups": len(parts),
                        "expected_groups": len(self.groups),
                        "selection_complete": len(parts) == len(self.groups),
                    },
                }
                write(self.root / (target + ".json"), aggregate)
        if changed:
            write(self.path, self.execution)
        return changed
