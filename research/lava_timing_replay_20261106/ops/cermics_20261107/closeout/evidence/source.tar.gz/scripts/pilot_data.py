"""Frozen observations, nested validation sets and delayed opening of test data."""
from __future__ import annotations
import copy
import os
from dataclasses import replace
from pathlib import Path
import numpy as np
from pilot_common import REVISION, read, sha, write, digest
from physical128_data import bank_key, array_hash, json_value

def load_job(job):
    from scipy.sparse import csc_matrix
    from proximal_spo.data import DatasetBundle, PhysicalCostSplit
    from proximal_spo.problem import LinearProblem
    from proximal_spo.external_benchmarks import ExternalBenchmarkLoad
    if job.get('pilot_revision')!=REVISION: raise ValueError('Unregistered pilot')
    c=job['config']; n=c['sizes']['validation']; key=bank_key(job)
    if c['sizes']!={'train':100,'validation':n,'test':128} or n not in (32,100): raise ValueError('Pilot sizes differ')
    d=Path(os.environ['CENTRAL_PATH_FROZEN_DATA'])/key; meta=read(d/'receipt.json')
    for name in ('observations.npz','structure.npz','structure.json'):
        if sha(d/name)!=meta['files_sha256'][name]: raise ValueError('Frozen bank changed: '+name)
    with np.load(d/'observations.npz',allow_pickle=False) as a: arrays={k:a[k] for k in a.files}
    if any(k.startswith('test') or 'conditional' in k for k in arrays): raise ValueError('Hidden information in observations')
    extension=None
    if n==100:
        x=Path(os.environ['PILOT_VALIDATION_DATA'])/key; extension=read(x/'receipt.json')
        if sha(x/'observations.npz')!=extension['sha256']: raise ValueError('Validation extension changed')
        with np.load(x/'observations.npz',allow_pickle=False) as a:
            for k in a.files:
                if not k.startswith('validation__') or 'conditional' in k: raise ValueError('Invalid validation extension')
                if array_hash(a[k][:32])!=array_hash(arrays[k]): raise ValueError('Validation32 prefix changed')
                arrays[k]=a[k]
    splits={}; hashes={}
    for s in ('train','validation','test'):
        prefix='train' if s=='test' else s
        get=lambda name: arrays[prefix+'__'+name][:1] if s=='test' else arrays[prefix+'__'+name]
        costs=get('physical_costs'); coeff=get('coefficients') if prefix+'__coefficients' in arrays else None
        splits[s]=PhysicalCostSplit(get('contexts'),costs,costs,s,c['seeds']['data'],coeff,coeff)
        if s!='test':
            hashes[s]={f:array_hash(get(f)) for f in ('contexts','physical_costs')}
            hashes[s]['conditional_mean_costs']=hashes[s]['physical_costs']
    m=read(d/'structure.json')
    with np.load(d/'structure.npz',allow_pickle=False) as a:
        matrix=csc_matrix((a['matrix_data'],a['matrix_indices'],a['matrix_indptr']),shape=tuple(a['matrix_shape']))
        problem=LinearProblem(matrix,a['row_lower'],a['row_upper'],a['variable_lower'],a['variable_upper'],a['integrality'],m['name'],m['metadata'])
        dataset=DatasetBundle(**splits,fixed_anchor=a['fixed_anchor'],random_indices=a['random_indices'],
            benchmark_id=m['benchmark_id'],master_seed=m['master_seed'],law=m['law'],cost_statistic=a['cost_statistic'] if 'cost_statistic' in a else None)
    return ExternalBenchmarkLoad(problem,dataset,{'physical128':{'array_hashes':hashes},'pilot_bank_key':key,
        'original_receipt_sha256':sha(d/'receipt.json'),'validation_extension':extension,
        'test_bank_opened':False,'generator_called_by_fit':False})

def test_split(job, directory, selection):
    """Freeze validation decisions durably before reading any test array."""
    from proximal_spo.data import PhysicalCostSplit
    if job['stage']!='confirmation' or not job['config']['evaluate_test']: raise RuntimeError('Test forbidden in development')
    if not selection or selection.get('selection_uses_test'): raise RuntimeError('Missing validation freeze')
    write(Path(directory)/'VALIDATION_SELECTION_FREEZE.json',selection,immutable=True)
    d=Path(os.environ['CENTRAL_PATH_FROZEN_DATA'])/bank_key(job); m=read(d/'receipt.json')
    if sha(d/'test.npz')!=m['files_sha256']['test.npz']: raise ValueError('Test bank changed')
    write(Path(directory)/'TEST_ACCESS.json',{'validation_freeze_sha256':sha(Path(directory)/'VALIDATION_SELECTION_FREEZE.json'),
        'test_bank_sha256':m['files_sha256']['test.npz'],'test_scores_used_for_selection':False},immutable=True)
    with np.load(d/'test.npz',allow_pickle=False) as a:
        x={k:a[k] for k in a.files}
    if len(x['test__contexts'])!=128:raise ValueError('Test count changed')
    coeff=x.get('test__coefficients')
    return PhysicalCostSplit(x['test__contexts'],x['test__physical_costs'],x['test__conditional_mean_costs'],
        'test',job['config']['seeds']['data'],coeff,x.get('test__conditional_mean_coefficients',coeff))

def prepare_extension(item):
    """Upstream only, on a Slurm compute node; generate 68 new observed pairs."""
    root,key=item;root=Path(root)
    from proximal_spo.external_benchmarks import load_external_benchmark
    from proximal_spo.data import SplitSizes
    from proximal_spo.feasible_policies import _geometry_cache_key
    from proximal_spo.seeds import derive_seed
    d=root/'frozen_data'/key; original=read(d/'receipt.json')
    out=root/'validation100'/key
    if (out/'receipt.json').exists():
        old=read(out/'receipt.json')
        if sha(out/'observations.npz')!=old['sha256']: raise ValueError('Frozen extension corrupt')
        return old
    route,seed=key.split('__data');seed=int(seed)
    extension_seed=derive_seed(seed,'parsimonious-pilot-validation-extension-v1')
    generated=load_external_benchmark(route,SplitSizes(1,68,1),data_seed=extension_seed,conditional_reference_samples=1)
    # Structural invariance is checked against the exact archived problem, not assumed.
    template={'pilot_revision':REVISION,'physical128_revision':'physical_head_test128_20260925_v1',
        'route':route,'stage':'screen','config':{'sizes':{'train':100,'validation':32,'test':128},'seeds':{'data':seed}}}
    old=load_job(template)
    if _geometry_cache_key(old.problem)!=_geometry_cache_key(generated.problem): raise ValueError('Extension changed known structure')
    arrays={};before={}
    for f in ('contexts','physical_costs','coefficients'):
        a=getattr(old.dataset.validation,f);b=getattr(generated.dataset.validation,f)
        if a is None: continue
        arrays['validation__'+f]=np.concatenate([a,b],axis=0);before[f]=array_hash(a)
        if len(arrays['validation__'+f])!=100: raise ValueError('Extension count')
    out.mkdir(parents=True,exist_ok=True)
    tmp=out/f'observations.{os.getpid()}.tmp'
    with tmp.open('xb') as f:np.savez_compressed(f,**arrays)
    tmp.replace(out/'observations.npz')
    result={'key':key,'sha256':sha(out/'observations.npz'),'source_receipt_sha256':sha(d/'receipt.json'),
        'source_observations_sha256':original['files_sha256']['observations.npz'],
        'validation32_prefix_hashes':before,'extension_seed':extension_seed,'added_observed_pairs':68,
        'known_structure_unchanged':True,'test_file_opened':False,'learner_hidden_moments':False,
        'upstream_generator_provenance':json_value(generated.provenance)}
    write(out/'receipt.json',result,immutable=True);return result
