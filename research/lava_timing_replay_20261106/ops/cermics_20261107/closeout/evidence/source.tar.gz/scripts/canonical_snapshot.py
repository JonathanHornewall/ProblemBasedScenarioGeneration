"""Hash immutable terminal artifacts; optionally hash every stopped output."""
import argparse
import hashlib
import json
from pathlib import Path
from build_central_path_final import read, write


def snapshot(root, final=False):
    paths = set()
    for receipt in (root/'results/receipts').glob('*.json'):
        paths.add(receipt)
        rec = read(receipt)
        attempt = Path(rec.get('attempt_directory',root/'missing'))
        if attempt.is_relative_to(root):
            paths.update(p for p in attempt.rglob('*') if p.is_file())
    if final:
        paths.update(p for p in (root/'results').rglob('*') if p.is_file())
    result = {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
    write(root/'retrieval_hashes.json',result)
    return {'files':len(result),'receipts':len(list((root/'results/receipts').glob('*.json')))}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--final',action='store_true')
    args = p.parse_args()
    print(json.dumps(snapshot(args.root,args.final)))
