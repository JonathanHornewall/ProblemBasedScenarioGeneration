"""Upstream generation of the 56 larger banks, separate from all learners."""
import argparse
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
from pathlib import Path
import time
import numpy as np

from build_central_path_final import read, write
from physical128_data import digest, json_value, REVISION
from run_public_solver_free_matched import _hash_array


def prepare(entry, root):
    from proximal_spo.external_benchmarks import load_external_benchmark
    from proximal_spo.data import SplitSizes
    d = root/'frozen_data'/entry['key']
    if (d/'receipt.json').exists():
        receipt=read(d/'receipt.json')
        assert all(digest(d/n)==h for n,h in receipt['files_sha256'].items())
        return receipt
    if d.exists():d.rename(d.with_name(d.name+'.incomplete.'+str(time.time_ns())))
    d.mkdir(parents=True)
    loaded=load_external_benchmark(entry['route'],SplitSizes(100,32,128),
        data_seed=entry['seeds']['data'],conditional_reference_samples=entry['conditional_reference_samples'])
    p,b=loaded.problem,loaded.dataset
    observations,test={},{}
    for s in ('train','validation','test'):
        split=getattr(b,s)
        fields=('contexts','physical_costs','coefficients') if s!='test' else (
            'contexts','physical_costs','coefficients','conditional_mean_costs','conditional_mean_coefficients')
        for f in fields:
            a=getattr(split,f)
            if a is not None:(test if s=='test' else observations)[s+'__'+f]=a.copy()
    assert all('conditional' not in k and not k.startswith('test') for k in observations)
    structure={'matrix_data':p.matrix.data,'matrix_indices':p.matrix.indices,'matrix_indptr':p.matrix.indptr,
        'matrix_shape':np.array(p.matrix.shape),'row_lower':p.row_lower,'row_upper':p.row_upper,
        'variable_lower':p.variable_lower,'variable_upper':p.variable_upper,'integrality':p.integrality,
        'fixed_anchor':b.fixed_anchor,'random_indices':b.random_indices}
    if b.cost_statistic is not None:structure['cost_statistic']=b.cost_statistic
    for name,arrays in [('observations.npz',observations),('test.npz',test),('structure.npz',structure)]:
        with (d/name).open('xb') as f:np.savez_compressed(f,**arrays)
    write(d/'structure.json',{'name':p.name,'metadata':json_value(dict(p.metadata)),
        'benchmark_id':b.benchmark_id,'master_seed':b.master_seed,'law':b.law})
    hashes={s:{k.split('__',1)[1]:_hash_array(a) for k,a in {**observations,**test}.items()
                  if k.startswith(s+'__')} for s in ('train','validation','test')}
    for s in ('train','validation'):
        hashes[s]['conditional_mean_costs']=hashes[s]['physical_costs']
        if 'coefficients' in hashes[s]:hashes[s]['conditional_mean_coefficients']=hashes[s]['coefficients']
    receipt={'revision':REVISION,'key':entry['key'],'array_hashes':hashes,
        'sizes':{'train':100,'validation':32,'test':128},'upstream_generation':entry,
        'generator_provenance':json_value(loaded.provenance),
        'test_policy':'new larger banks frozen before any development fit; identical across methods and architecture arms',
        'learner_information':'100 observed training pairs and known optimization structure',
        'validation_information':'32 sampled observed pairs for selection only',
        'files_sha256':{n:digest(d/n) for n in ['observations.npz','test.npz','structure.npz','structure.json']}}
    write(d/'receipt.json',receipt)
    print(json.dumps({'key':entry['key'],'status':'complete','variables':p.variable_count}),flush=True)
    return receipt


def main(root,workers):
    plan=read(root/'NEW_BANK_PLAN.json')
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures=[pool.submit(prepare,e,root) for e in plan]
        receipts=[f.result() for f in futures]
    old=read(root/'FROZEN_BANK_INVENTORY.json')
    new=[{'key':r['key'],'files_sha256':r['files_sha256'],
        'receipt_sha256':digest(root/'frozen_data'/r['key']/'receipt.json')} for r in receipts]
    write(root/'ALL_FROZEN_BANK_INVENTORY.json',old+new)
    write(root/'NEW_BANK_VERIFICATION.json',{'status':'complete','banks':len(new),
        'total_banks':len(old+new),'source_manifest_sha256':digest(root/'source_receipt.json'),
        'new_plan_sha256':digest(root/'NEW_BANK_PLAN.json'),'completed_unix':time.time()})

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--workers',type=int,default=4)
    a=p.parse_args();assert 1<=a.workers<=8;main(a.root.resolve(),a.workers)
