"""Microprofile feasible-policy forward/VJP kernels without training a model."""

from __future__ import annotations

import argparse
import os
import platform
import time
from collections.abc import Callable
from dataclasses import replace
from pathlib import Path
from typing import Any

import numpy as np
import torch

from proximal_spo.artifacts import environment_receipt, source_sha256, write_json
from proximal_spo.benchmarks import build_benchmark
from proximal_spo.feasible_policies import PolyhedralPolicyGeometry
from proximal_spo.objectives import (
    DirectProjectionObjective,
    LogEnergyPolicyObjective,
    RayenPolicyObjective,
    SoftRadialLogBarrierObjective,
    SoftRadialPolicyObjective,
    TrainingBatch,
)
from proximal_spo.problem import PartialCostInterface

REPO_ROOT = Path(__file__).resolve().parents[1]


def _timed(
    function: Callable[[], object], *, samples: int, repetitions: int
) -> dict[str, float | int]:
    function()
    durations: list[float] = []
    for _ in range(repetitions):
        started = time.perf_counter()
        function()
        durations.append(time.perf_counter() - started)
    median = float(np.median(durations))
    return {
        "samples": samples,
        "repetitions": repetitions,
        "median_wall_seconds": median,
        "median_samples_per_second": samples / median,
        "minimum_wall_seconds": min(durations),
        "maximum_wall_seconds": max(durations),
    }


def _profile(
    benchmark_id: str,
    *,
    batch_size: int,
    repetitions: int,
    seed: int,
    include_direct_projection: bool,
) -> dict[str, Any]:
    problem = build_benchmark(benchmark_id, structural_seed=101)
    geometry = PolyhedralPolicyGeometry.compile(problem)
    generator = np.random.default_rng(seed)
    reports = generator.normal(
        scale=0.5, size=(batch_size, geometry.intrinsic_dimension)
    )
    costs = generator.normal(size=(batch_size, problem.variable_count))
    interface = PartialCostInterface.full_cost(problem)
    training_batch = TrainingBatch(
        contexts=np.zeros((batch_size, 1)),
        coefficients=costs,
        physical_costs=costs,
        target_decisions=np.zeros_like(costs),
        target_values=costs @ geometry.center - 1.0,
    )
    cached_training_batch = replace(
        training_batch,
        policy_reduced_costs=costs @ geometry.physical_map,
        policy_center_costs=costs @ geometry.center,
    )
    rayen_objective = RayenPolicyObjective(interface)
    soft_objective = SoftRadialPolicyObjective(
        interface,
        contraction="rational",
        contraction_scale=1.0,
        minimum_scale=0.01,
    )
    barrier_soft_objective = SoftRadialLogBarrierObjective(
        interface,
        contraction="rational",
        contraction_scale=1.0,
        minimum_scale=0.01,
        alpha_start=0.3,
        alpha_end=0.3,
        schedule="fixed",
        anneal_fraction=1.0,
        workers=1,
        random_seed=seed,
        training_physical_costs=training_batch.physical_costs,
        training_target_values=training_batch.target_values,
    )
    log_objective = LogEnergyPolicyObjective(
        interface,
        mu_start=0.3,
        mu_end=0.03,
        kernel_backend="numpy",
    )
    sparse_log_objective = LogEnergyPolicyObjective(
        interface,
        mu_start=0.3,
        mu_end=0.03,
        matrix_backend="sparse",
        kernel_backend="numpy",
    )

    policy_results: dict[str, Any] = {
        "rayen_policy": _timed(
            lambda: rayen_objective.signal(reports, training_batch),
            samples=batch_size,
            repetitions=repetitions,
        ),
        "rayen_policy_cached_costs": _timed(
            lambda: rayen_objective.signal(reports, cached_training_batch),
            samples=batch_size,
            repetitions=repetitions,
        ),
        "soft_radial_policy": _timed(
            lambda: soft_objective.signal(reports, training_batch),
            samples=batch_size,
            repetitions=repetitions,
        ),
        "soft_radial_policy_cached_costs": _timed(
            lambda: soft_objective.signal(reports, cached_training_batch),
            samples=batch_size,
            repetitions=repetitions,
        ),
        "soft_radial_log_barrier": _timed(
            lambda: barrier_soft_objective.signal(reports, training_batch),
            samples=batch_size,
            repetitions=repetitions,
        ),
        "soft_radial_log_barrier_cached_costs": _timed(
            lambda: barrier_soft_objective.signal(reports, cached_training_batch),
            samples=batch_size,
            repetitions=repetitions,
        ),
        "log_energy_policy": _timed(
            lambda: log_objective.signal(reports, training_batch),
            samples=batch_size,
            repetitions=repetitions,
        ),
        "log_energy_policy_cached_costs": _timed(
            lambda: log_objective.signal(reports, cached_training_batch),
            samples=batch_size,
            repetitions=repetitions,
        ),
        "log_energy_numpy_strict": _timed(
            lambda: geometry.log_energy_vjp(
                geometry.log_energy(
                    reports,
                    root_tolerance=1e-8,
                    matrix_backend="dense",
                ),
                costs,
            ),
            samples=batch_size,
            repetitions=repetitions,
        ),
        "log_energy_numpy_sparse_training": _timed(
            lambda: sparse_log_objective.signal(reports, training_batch),
            samples=batch_size,
            repetitions=repetitions,
        ),
        "log_energy_scalar_reference": _timed(
            lambda: geometry.log_energy_vjp(
                geometry.log_energy_reference(reports), costs
            ),
            samples=batch_size,
            repetitions=repetitions,
        ),
    }
    policy_results["log_energy_policy"]["speedup_over_scalar_reference"] = float(
        policy_results["log_energy_scalar_reference"]["median_wall_seconds"]
    ) / float(policy_results["log_energy_policy"]["median_wall_seconds"])

    torch_soft_objective = SoftRadialLogBarrierObjective(
        interface,
        contraction="rational",
        contraction_scale=1.0,
        minimum_scale=0.01,
        alpha_start=0.3,
        alpha_end=0.3,
        schedule="fixed",
        anneal_fraction=1.0,
        workers=1,
        random_seed=seed,
        training_physical_costs=training_batch.physical_costs,
        training_target_values=training_batch.target_values,
        kernel_backend="torch",
        torch_device="cpu",
    )
    torch_soft_reports = torch.tensor(
        reports,
        dtype=torch.float64,
        requires_grad=True,
    )
    torch_soft_costs = torch.tensor(costs, dtype=torch.float64)
    torch_soft_targets = torch.zeros(batch_size, dtype=torch.float64)
    torch_reduced_costs = torch.tensor(
        cached_training_batch.policy_reduced_costs,
        dtype=torch.float64,
    )
    torch_center_costs = torch.tensor(
        cached_training_batch.policy_center_costs,
        dtype=torch.float64,
    )

    def torch_soft_cpu() -> None:
        torch_soft_reports.grad = None
        signal = torch_soft_objective.torch_signal(
            torch_soft_reports,
            torch_soft_costs,
            torch_soft_targets,
            torch_reduced_costs,
            torch_center_costs,
        )
        signal.values.sum().backward()

    policy_results["soft_radial_log_barrier_torch_cpu_training"] = _timed(
        torch_soft_cpu,
        samples=batch_size,
        repetitions=repetitions,
    )

    torch_objective = LogEnergyPolicyObjective(
        interface,
        mu_start=0.3,
        mu_end=0.03,
        kernel_backend="torch",
        torch_device="cpu",
    )
    torch_reports = torch.tensor(reports, dtype=torch.float64, requires_grad=True)
    torch_costs = torch.tensor(costs, dtype=torch.float64)
    torch_targets = torch.zeros(batch_size, dtype=torch.float64)

    def torch_cpu() -> None:
        torch_reports.grad = None
        signal = torch_objective.torch_signal(torch_reports, torch_costs, torch_targets)
        signal.values.sum().backward()

    policy_results["log_energy_torch_cpu_training"] = _timed(
        torch_cpu,
        samples=batch_size,
        repetitions=repetitions,
    )

    cuda_objective: LogEnergyPolicyObjective | None = None
    if torch.cuda.is_available():
        cuda_objective = LogEnergyPolicyObjective(
            interface,
            mu_start=0.3,
            mu_end=0.03,
            kernel_backend="torch",
            torch_device="cuda",
        )
        cuda_reports = torch.tensor(
            reports,
            dtype=torch.float64,
            device="cuda",
            requires_grad=True,
        )
        cuda_costs = torch.tensor(costs, dtype=torch.float64, device="cuda")
        cuda_targets = torch.zeros(batch_size, dtype=torch.float64, device="cuda")

        def torch_cuda() -> None:
            cuda_reports.grad = None
            signal = cuda_objective.torch_signal(cuda_reports, cuda_costs, cuda_targets)
            signal.values.sum().backward()
            torch.cuda.synchronize()

        policy_results["log_energy_torch_cuda_training"] = _timed(
            torch_cuda,
            samples=batch_size,
            repetitions=repetitions,
        )
    else:
        policy_results["log_energy_torch_cuda_training"] = {
            "available": False,
            "reason": "torch.cuda.is_available() is false",
        }

    accelerator_soft_objectives: list[SoftRadialLogBarrierObjective] = []
    for device_name, available in (
        ("cuda", torch.cuda.is_available()),
        ("mps", torch.backends.mps.is_available()),
    ):
        key = f"soft_radial_log_barrier_torch_{device_name}_training"
        if not available:
            policy_results[key] = {
                "available": False,
                "reason": f"Torch {device_name} is unavailable",
            }
            continue
        accelerator_objective = SoftRadialLogBarrierObjective(
            interface,
            contraction="rational",
            contraction_scale=1.0,
            minimum_scale=0.01,
            alpha_start=0.3,
            alpha_end=0.3,
            schedule="fixed",
            anneal_fraction=1.0,
            workers=1,
            random_seed=seed,
            training_physical_costs=training_batch.physical_costs,
            training_target_values=training_batch.target_values,
            kernel_backend="torch",
            torch_device=device_name,
            training_dtype="float32",
        )
        accelerator_soft_objectives.append(accelerator_objective)
        device = torch.device(device_name)
        device_reports = torch.tensor(
            reports,
            dtype=torch.float32,
            device=device,
            requires_grad=True,
        )
        device_costs = torch.tensor(costs, dtype=torch.float32, device=device)
        device_targets = torch.zeros(batch_size, dtype=torch.float32, device=device)
        device_reduced_costs = torch.tensor(
            cached_training_batch.policy_reduced_costs,
            dtype=torch.float32,
            device=device,
        )
        device_center_costs = torch.tensor(
            cached_training_batch.policy_center_costs,
            dtype=torch.float32,
            device=device,
        )

        def torch_soft_accelerator(
            reports_tensor: torch.Tensor = device_reports,
            costs_tensor: torch.Tensor = device_costs,
            targets_tensor: torch.Tensor = device_targets,
            reduced_costs_tensor: torch.Tensor = device_reduced_costs,
            center_costs_tensor: torch.Tensor = device_center_costs,
            accelerator: SoftRadialLogBarrierObjective = accelerator_objective,
            synchronize_device: str = device_name,
        ) -> None:
            reports_tensor.grad = None
            signal = accelerator.torch_signal(
                reports_tensor,
                costs_tensor,
                targets_tensor,
                reduced_costs_tensor,
                center_costs_tensor,
            )
            signal.values.sum().backward()
            if synchronize_device == "cuda":
                torch.cuda.synchronize()
            else:
                torch.mps.synchronize()

        policy_results[key] = _timed(
            torch_soft_accelerator,
            samples=batch_size,
            repetitions=repetitions,
        )

    qp_objective: DirectProjectionObjective | None = None
    try:
        if include_direct_projection:
            # Intentionally profile the solver-in-the-loop policy last.
            qp_objective = DirectProjectionObjective(interface, workers=4)
            qp_outputs = geometry.center + generator.normal(
                scale=0.5, size=(batch_size, problem.variable_count)
            )
            policy_results["direct_projection"] = _timed(
                lambda: qp_objective.signal(qp_outputs, training_batch),
                samples=batch_size,
                repetitions=repetitions,
            )
    finally:
        if qp_objective is not None:
            qp_objective.close()
        rayen_objective.close()
        soft_objective.close()
        barrier_soft_objective.close()
        log_objective.close()
        sparse_log_objective.close()
        torch_objective.close()
        torch_soft_objective.close()
        for accelerator_objective in accelerator_soft_objectives:
            accelerator_objective.close()
        if cuda_objective is not None:
            cuda_objective.close()
    return {
        "benchmark_id": benchmark_id,
        "batch_size": batch_size,
        "seed": seed,
        "geometry": geometry.receipt_dict()["geometry"],
        "policies": policy_results,
        "scope": (
            "forward plus analytic or maintained implicit VJP; "
            "no neural-network training"
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--benchmark",
        action="append",
        default=[],
        help="benchmark id; repeat for multiple (defaults to grid and random LP)",
    )
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--repetitions", type=int, default=5)
    parser.add_argument("--seed", type=int, default=20260825)
    parser.add_argument("--skip-direct-projection", action="store_true")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("results/feasible_policy_profile.json"),
    )
    arguments = parser.parse_args()
    benchmarks = arguments.benchmark or ["cost.grid5", "cost.random_lp100x50"]
    if arguments.batch_size <= 0 or arguments.repetitions <= 0:
        parser.error("batch size and repetitions must be positive")
    result = {
        "source_sha256": source_sha256(REPO_ROOT),
        "environment": environment_receipt(REPO_ROOT),
        "hardware": {
            "machine": platform.machine(),
            "processor": platform.processor(),
            "logical_cpu_count": os.cpu_count(),
            "blas_thread_environment": {
                key: os.environ.get(key)
                for key in (
                    "OMP_NUM_THREADS",
                    "OPENBLAS_NUM_THREADS",
                    "MKL_NUM_THREADS",
                    "VECLIB_MAXIMUM_THREADS",
                )
            },
        },
        "profiles": [
            _profile(
                benchmark,
                batch_size=arguments.batch_size,
                repetitions=arguments.repetitions,
                seed=arguments.seed + index,
                include_direct_projection=not arguments.skip_direct_projection,
            )
            for index, benchmark in enumerate(benchmarks)
        ],
        "raw_reports_or_costs_persisted": False,
    }
    write_json(arguments.output, result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
