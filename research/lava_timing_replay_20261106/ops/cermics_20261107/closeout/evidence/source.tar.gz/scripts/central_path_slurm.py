#!/usr/bin/env python3
"""Bounded Slurm arrays with validation-only, durable campaign transitions."""

from __future__ import annotations

import argparse
import collections
import os
import shlex
import signal
import statistics
import subprocess
import time
from pathlib import Path

from build_central_path_final import read, write
from select_central_path_final import transition


def allocation(job):
    route, method = job["route"], job["method"]
    if method == "intopt_original":
        return "intopt"
    if method == "lava" and ("shortest_path" in route or "cfl" in route):
        return "heavy"
    if method == "cave" and "shortest_path" in route:
        return "heavy"
    if method in ("lava", "cave"):
        return "medium"
    return "light"


LIMITS = {"light": (16, 3), "medium": (4, 8), "heavy": (2, 48), "intopt": (1, 12)}


def heavy_partition():
    """Short CPU spillover only when no ordinary high-memory node is idle."""
    try:
        rows = subprocess.check_output(
            ["sinfo", "-p", "defq", "-N", "-h", "-o", "%m %t"], text=True
        ).splitlines()
    except FileNotFoundError:
        return "defq"  # Local dry-run; the actual submission checks live Slurm.
    for row in rows:
        memory, state = row.split()
        if int(memory) >= 49000 and state.rstrip("~*#") in ("idle", "mix"):
            return "defq"
    return "defq-gpu"


def environment(root):
    env = dict(os.environ)
    for name in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
    ):
        env[name] = "1"
    env.update(
        PYTHONUNBUFFERED="1",
        PYTHONPATH=f"{root}/code/src:{root}/external/src",
        SOLVER_FREE_DFL_REPO=str(root / "public"),
        DFL_EXTENSIONS_SRC=str(root / "external/src"),
        CENTRAL_PATH_GEOMETRY_CACHE=str(root / "geometry_cache"),
        ATLANTA_SOURCE_MANIFEST=str(root / "source_receipt.json"),
        CENTRAL_PATH_FROZEN_DATA=str(root / "frozen_data"),
    )
    return env


def self_command(root, command, *extra):
    return [
        str(root / "venv/bin/python"),
        str(root / "code/scripts/central_path_slurm.py"),
        command,
        "--root",
        str(root),
        *extra,
    ]


def submit(root, manifest_path, *, dependency=None, dry_run=False):
    manifest = read(manifest_path)
    stage = manifest["jobs"][0]["stage"] if manifest["jobs"] else "empty"
    index_root = root / "dispatch" / stage
    index_root.mkdir(parents=True, exist_ok=True)
    (root / "logs").mkdir(exist_ok=True)
    jobs_by_class = collections.defaultdict(list)
    for i, job in enumerate(manifest["jobs"]):
        if not (root / "results/receipts" / (job["id"] + ".json")).exists():
            jobs_by_class[allocation(job)].append(i)
    submissions = []
    for category, indices in jobs_by_class.items():
        concurrency, memory = LIMITS[category]
        partition = heavy_partition() if category == "heavy" else "defq"
        chunk_size = 1 if category == "heavy" else 4
        wall_limit = "03:00:00" if category == "heavy" else "12:00:00"
        # Four finite fits per array element keeps the array below 1000 tasks.
        chunks = [
            indices[i : i + chunk_size] for i in range(0, len(indices), chunk_size)
        ]
        if len(chunks) > 1000:
            raise ValueError("unexpected campaign size exceeds bounded array")
        index_file = index_root / (category + ".json")
        write(index_file, {"chunks": chunks, "memory_gib": memory})
        command = self_command(
            root,
            "worker",
            "--manifest",
            str(manifest_path),
            "--indices",
            str(index_file),
        )
        sbatch = [
            "sbatch",
            "--parsable",
            f"--partition={partition}",
            "--nice=10000",
            "--requeue",
            "--ntasks=1",
            "--cpus-per-task=1",
            f"--mem={memory}G",
            f"--time={wall_limit}",
            f"--array=0-{len(chunks) - 1}%{concurrency}",
            f"--job-name=cp-{stage[:4]}-{category}",
            f"--output={root}/logs/{stage}-{category}-%A_%a.log",
        ]
        if dependency:
            sbatch.append("--dependency=afterok:" + dependency)
        sbatch.extend(["--wrap", shlex.join(command)])
        job_id = (
            "dry-run"
            if dry_run
            else subprocess.check_output(sbatch, text=True, env=environment(root))
            .strip()
            .split(";")[0]
        )
        submissions.append(
            {
                "id": job_id,
                "class": category,
                "fits": len(indices),
                "elements": len(chunks),
                "concurrency": concurrency,
                "memory_gib_per_element": memory,
                "partition": partition,
                "command": sbatch,
            }
        )
    dependencies = ":".join(item["id"] for item in submissions)
    action = "summarize" if stage == "confirmation" else "advance"
    command = self_command(root, action, "--manifest", str(manifest_path))
    sbatch = [
        "sbatch",
        "--parsable",
        "--partition=defq",
        "--nice=10000",
        "--requeue",
        "--ntasks=1",
        "--cpus-per-task=1",
        "--mem=1G",
        "--time=00:15:00",
        f"--job-name=cp-{stage}-finish",
        f"--output={root}/logs/{stage}-finish-%j.log",
    ]
    if dependencies:
        sbatch.append("--dependency=afterany:" + dependencies)
    sbatch.extend(["--wrap", shlex.join(command)])
    finalizer = (
        "dry-run"
        if dry_run
        else subprocess.check_output(sbatch, text=True, env=environment(root))
        .strip()
        .split(";")[0]
    )
    receipt = {
        "stage": stage,
        "manifest": str(manifest_path),
        "submissions": submissions,
        "finalizer": finalizer,
        "submitted_unix": time.time(),
        "dry_run": dry_run,
    }
    write(root / "dispatch" / (stage + ".json"), receipt)
    print(receipt, flush=True)


def worker(root, manifest_path, indices_path):
    import psutil

    manifest = read(manifest_path)
    index = read(indices_path)
    indices = index["chunks"][int(os.environ["SLURM_ARRAY_TASK_ID"])]
    output = root / "results"
    (output / "logs").mkdir(parents=True, exist_ok=True)
    for i in indices:
        job = manifest["jobs"][i]
        receipt = output / "receipts" / (job["id"] + ".json")
        if receipt.exists():
            continue
        command = [
            str(root / "venv/bin/python"),
            str(root / "code/scripts/run_central_path_final.py"),
            "--manifest",
            str(manifest_path),
            "--job-index",
            str(i),
            "--output-root",
            str(output),
        ]
        started = time.monotonic()
        category = None
        with (output / "logs" / (job["id"] + ".log")).open("a") as log:
            child = subprocess.Popen(
                command,
                stdout=log,
                stderr=subprocess.STDOUT,
                env=environment(root),
                start_new_session=True,
            )
            while child.poll() is None:
                time.sleep(3)
                elapsed = time.monotonic() - started
                progress_path = output / "progress" / (job["id"] + ".json")
                progress = read(progress_path) if progress_path.exists() else {}
                try:
                    proc = psutil.Process(child.pid)
                    rss = sum(
                        p.memory_info().rss
                        for p in [proc, *proc.children(recursive=True)]
                    )
                except psutil.Error:
                    rss = 0
                if elapsed > manifest["protocol"]["job_wall_cap_seconds"] + 15:
                    category = "wall_time_cap"
                elif (
                    progress.get("phase") in ("imports", "preprocessing")
                    and elapsed > manifest["protocol"]["preprocessing_cap_seconds"] + 15
                ):
                    category = "preprocessing_time_cap"
                elif rss > index["memory_gib"] * 0.90 * 2**30:
                    category = "memory_cap"
                if category:
                    try:
                        os.killpg(child.pid, signal.SIGTERM)
                        child.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait()
                    except ProcessLookupError:
                        pass
                    break
        if not receipt.exists():
            progress_path = output / "progress" / (job["id"] + ".json")
            record = read(progress_path) if progress_path.exists() else {"job": job}
            record.update(
                status="censored" if category else "failed",
                error=category or "child exited without receipt",
                returncode=child.returncode,
                total_wall_seconds=time.monotonic() - started,
                slurm_job_id=os.environ.get("SLURM_JOB_ID"),
            )
            write(receipt, record)


def advance(root, manifest_path):
    manifest = read(manifest_path)
    next_manifest = transition(manifest, root / "results")
    next_stage = (
        "refinement" if manifest["jobs"][0]["stage"] == "screen" else "confirmation"
    )
    path = root / (next_stage + ".json")
    if path.exists():
        raise RuntimeError(
            "transition already written; inspect dispatch before resubmitting"
        )
    write(path, next_manifest)
    if not next_manifest["jobs"]:
        write(
            root / "BLOCKED.json",
            {"reason": "no eligible development settings", "manifest": str(path)},
        )
        return
    submit(root, path)


def summarize(root, manifest_path):
    manifest = read(manifest_path)
    grouped = collections.defaultdict(list)
    missing = []
    counts = collections.Counter()
    for job in manifest["jobs"]:
        path = root / "results/receipts" / (job["id"] + ".json")
        if not path.exists():
            missing.append(job["id"])
            continue
        record = read(path)
        counts[record["status"]] += 1
        if record["status"] == "complete":
            grouped[(job["cell"], job["method"])].append(record)
    rows = []
    for cell in manifest["cells"]:
        for method in manifest.get("cell_methods", {}).get(cell, manifest["methods"]):
            records = grouped[(cell, method)]
            values = [r["summary"]["test"]["normalized_mean_regret"] for r in records]
            values = [v for v in values if v is not None]
            row = {
                "cell": cell,
                "method": method,
                "completed_seeds": len(records),
                "expected_seeds": 10,
                "training_capped_seeds": sum(
                    r["summary"].get("optimization_cap_reached", False) for r in records
                ),
            }
            if values:
                row.update(
                    mean_normalized_regret=statistics.mean(values),
                    standard_deviation=statistics.stdev(values)
                    if len(values) > 1
                    else None,
                )
            rows.append(row)
    incomplete = [r for r in rows if r["completed_seeds"] != 10]
    result = {
        "status": "complete"
        if not incomplete and not missing
        else "terminal_with_incomplete_cells",
        "rows": rows,
        "receipt_counts": dict(counts),
        "missing_receipts": missing,
        "incomplete_cells": incomplete,
        "finished_unix": time.time(),
    }
    write(root / "FINAL_RESULTS.json", result)
    lines = [
        "# Central Path final campaign",
        "",
        "Status: " + result["status"],
        "",
        "| Setting | Method | Seeds | Mean normalized regret | SD |",
        "|---|---|---:|---:|---:|",
    ]
    for row in rows:
        mean = row.get("mean_normalized_regret")
        sd = row.get("standard_deviation")
        lines.append(
            f"| {row['cell']} | {row['method']} | {row['completed_seeds']}/10 | "
            + (f"{mean:.6g}" if mean is not None else "unavailable")
            + " | "
            + (f"{sd:.6g}" if sd is not None else "—")
            + " |"
        )
    (root / "FINAL_RESULTS.md").write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("command", choices=("submit", "worker", "advance", "summarize"))
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--indices", type=Path)
    p.add_argument("--dependency")
    p.add_argument("--dry-run", action="store_true")
    a = p.parse_args()
    if a.command == "submit":
        submit(a.root, a.manifest, dependency=a.dependency, dry_run=a.dry_run)
    elif a.command == "worker":
        worker(a.root, a.manifest, a.indices)
    elif a.command == "advance":
        advance(a.root, a.manifest)
    else:
        summarize(a.root, a.manifest)
