#!/usr/bin/env python3
"""VM supervisor: mirror receipts to private storage, then delete this VM.

Only the Compute Engine metadata identity is used. No user credential is copied
into a command, log, or archive. Uploaded bytes are verified by Cloud Storage MD5.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path


def metadata(path: str) -> str:
    request = urllib.request.Request("http://metadata.google.internal/computeMetadata/v1/" + path,
                                     headers={"Metadata-Flavor": "Google"})
    return urllib.request.urlopen(request, timeout=15).read().decode()


def request_json(url: str, *, method="GET", data=None, content_type="application/json"):
    token = json.loads(metadata("instance/service-accounts/default/token"))["access_token"]
    request = urllib.request.Request(url, method=method, data=data, headers={
        "Authorization": "Bearer " + token, "Content-Type": content_type,
    })
    with urllib.request.urlopen(request, timeout=90) as response:
        return json.loads(response.read())


def upload(bucket: str, name: str, data: bytes) -> None:
    url = ("https://storage.googleapis.com/upload/storage/v1/b/" + urllib.parse.quote(bucket, safe="")
           + "/o?uploadType=media&name=" + urllib.parse.quote(name, safe=""))
    result = request_json(url, method="POST", data=data, content_type="application/octet-stream")
    expected = base64.b64encode(hashlib.md5(data).digest()).decode()
    if result.get("md5Hash") != expected or int(result["size"]) != len(data):
        raise RuntimeError("Cloud Storage upload checksum mismatch")


def delete_self(expected_run: str) -> None:
    project = metadata("project/project-id")
    name = metadata("instance/name")
    zone = metadata("instance/zone").split("/")[-1]
    if project != "hornewall-compute" or not name.startswith(expected_run + "-"):
        raise RuntimeError("Refusing VM deletion: unexpected project/name")
    url = f"https://compute.googleapis.com/compute/v1/projects/{project}/zones/{zone}/instances/{name}"
    instance = request_json(url)
    if instance.get("labels", {}).get("run_id") != expected_run:
        raise RuntimeError("Refusing VM deletion: run label mismatch")
    request_json(url, method="DELETE")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--bucket", required=True)
    p.add_argument("--run-id", required=True)
    p.add_argument("--deadline-unix", type=float, required=True)
    p.add_argument("--failure-only", action="store_true")
    args = p.parse_args()
    name = metadata("instance/name")
    shard = int(name.rsplit("-", 1)[-1])
    output = args.root / "results"
    output.mkdir(parents=True, exist_ok=True)
    uploaded = {}

    def sync() -> None:
        for path in sorted(output.rglob("*")):
            if not path.is_file() or path.name.startswith("."):
                continue
            stamp = (path.stat().st_mtime_ns, path.stat().st_size)
            relative = path.relative_to(output).as_posix()
            if uploaded.get(relative) == stamp:
                continue
            data = path.read_bytes()
            upload(args.bucket, f"results/{name}/{relative}", data)
            uploaded[relative] = stamp

    try:
        if not args.failure_only:
            command = [sys.executable, str(args.root / "project/scripts/run_atlanta_timing_queue.py"),
                       "--manifest", str(args.root / "manifest.json"),
                       "--indices", str(args.root / f"shards/{shard}.json"),
                       "--output-root", str(output), "--workers", "8", "--memory-gib", "58",
                       "--deadline-unix", str(args.deadline_unix - 900)]
            child = subprocess.Popen(command, start_new_session=True)
            while child.poll() is None:
                try:
                    sync()
                except Exception as exc:
                    print("Artifact synchronization will retry:", type(exc).__name__, flush=True)
                if time.time() >= args.deadline_unix - 600:
                    os.killpg(child.pid, signal.SIGTERM)
                time.sleep(15)
            (output / "supervisor.json").write_text(json.dumps({"queue_returncode": child.returncode,
                "finished_unix": time.time(), "instance": name}) + "\n")
        else:
            (output / "bootstrap_failure.json").write_text(json.dumps({
                "instance": name, "failed_unix": time.time(), "status": "bootstrap_failed"}) + "\n")
        for attempt in range(5):
            try:
                sync()
                inventory = {f.relative_to(output).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest()
                             for f in output.rglob("*") if f.is_file() and not f.name.startswith(".")}
                upload(args.bucket, f"results/{name}/VERIFIED_UPLOADS.json",
                       (json.dumps(inventory, indent=2, sort_keys=True) + "\n").encode())
                break
            except Exception:
                if attempt == 4:
                    raise
                time.sleep(15)
        # This point is reached only after all final artifacts are stored and
        # verified. Compute Engine's absolute deletion deadline is independent.
        delete_self(args.run_id)
    except Exception as exc:
        # Stopping removes Compute Engine's termination timer. Request deletion
        # instead; if that API is unavailable, leave the running VM's absolute
        # deletion backstop intact. Uploads already received remain in storage.
        print(json.dumps({"status": "supervisor_failed", "instance": name,
                          "failure_type": type(exc).__name__,
                          "outputs_may_be_incomplete": True}), flush=True)
        try:
            delete_self(args.run_id)
        except Exception as deletion_error:
            print("Early deletion failed; absolute deletion deadline remains active:",
                  type(deletion_error).__name__, flush=True)
        raise


if __name__ == "__main__":
    main()
