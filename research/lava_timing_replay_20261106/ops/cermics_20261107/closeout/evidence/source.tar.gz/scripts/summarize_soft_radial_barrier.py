"""Select Soft-Radial barrier arms under two deployment interpretations."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json


def _load(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected an object in {path}")
    return payload


def _canonical_sha256(payload: Any) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _arm_identity(config: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    arm = {key: value for key, value in config.items() if key not in {"name", "seeds"}}
    return _canonical_sha256(arm), arm


def _seed_key(row: dict[str, Any]) -> tuple[object, ...]:
    seeds = row["seeds"]
    return tuple(seeds[key] for key in sorted(seeds))


def _standard_error(values: list[float]) -> float:
    if len(values) <= 1:
        return 0.0
    mean = sum(values) / len(values)
    variance = sum((value - mean) ** 2 for value in values) / (len(values) - 1)
    return math.sqrt(variance / len(values))


def summarize(run_root: Path, *, source_sha256: str) -> dict[str, Any]:
    candidates: list[dict[str, Any]] = []
    for directory in sorted(path for path in run_root.iterdir() if path.is_dir()):
        required = (
            directory / "status.json",
            directory / "config.json",
            directory / "environment.json",
            directory / "summary.json",
            directory / "deployment_ablation.json",
        )
        if not all(path.is_file() for path in required):
            continue
        status, config, environment, summary, ablation = map(_load, required)
        if status.get("status") != "complete":
            continue
        if config.get("method") != "soft_radial_log_barrier":
            continue
        if environment.get("source_sha256") != source_sha256:
            continue
        seeds = config.get("seeds")
        deployments = ablation.get("deployments")
        if not isinstance(seeds, dict) or not isinstance(deployments, dict):
            raise ValueError(f"malformed deployment receipt in {directory}")
        validation: dict[str, float] = {}
        for mode in ("soft", "hard_recovered"):
            mode_payload = deployments.get(mode)
            if not isinstance(mode_payload, dict):
                raise ValueError(f"missing {mode} deployment in {directory}")
            metrics = mode_payload.get("validation")
            if not isinstance(metrics, dict):
                raise ValueError(f"missing {mode} validation metrics in {directory}")
            validation[mode] = float(metrics["mean_regret"])
        arm_sha256, arm = _arm_identity(config)
        candidates.append(
            {
                "run_directory": str(directory),
                "name": config["name"],
                "benchmark_id": config["benchmark_id"],
                "interface": config["interface"],
                "method": config["method"],
                "seeds": seeds,
                "arm_sha256": arm_sha256,
                "arm": arm,
                "source_sha256": source_sha256,
                "best_epoch": summary["best_epoch"],
                "validation_mean_regret_by_deployment": validation,
                "training_wall_seconds": summary["training_wall_seconds"],
            }
        )
    if not candidates:
        raise ValueError(f"no completed source-matched runs below {run_root}")

    selected_arms: list[dict[str, Any]] = []
    selected_rows: list[dict[str, Any]] = []
    aggregates: list[dict[str, Any]] = []
    censored_incomplete_arms: list[dict[str, Any]] = []
    for benchmark_id in sorted({str(row["benchmark_id"]) for row in candidates}):
        benchmark_rows = [
            row for row in candidates if row["benchmark_id"] == benchmark_id
        ]
        grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in benchmark_rows:
            grouped[str(row["arm_sha256"])].append(row)
        expected_seeds = {
            _seed_key(row): row["seeds"] for row in benchmark_rows
        }
        eligible: dict[str, list[dict[str, Any]]] = {}
        for arm_sha256, rows in grouped.items():
            observed = {_seed_key(row): row["seeds"] for row in rows}
            if len(observed) != len(rows):
                raise ValueError(
                    f"duplicate seed rows for {benchmark_id}/{arm_sha256}"
                )
            if observed.keys() == expected_seeds.keys():
                eligible[arm_sha256] = rows
                continue
            censored_incomplete_arms.append(
                {
                    "benchmark_id": benchmark_id,
                    "arm_sha256": arm_sha256,
                    "arm": rows[0]["arm"],
                    "available_seeds": [
                        observed[key] for key in sorted(observed)
                    ],
                    "missing_seeds": [
                        expected_seeds[key]
                        for key in sorted(expected_seeds.keys() - observed.keys())
                    ],
                }
            )
        if not eligible:
            raise ValueError(f"no complete paired arms for {benchmark_id}")
        for selection_mode in ("soft", "hard_recovered"):
            ranked = sorted(
                eligible.items(),
                key=lambda item: (
                    sum(
                        float(
                            row["validation_mean_regret_by_deployment"][
                                selection_mode
                            ]
                        )
                        for row in item[1]
                    )
                    / len(item[1]),
                    item[0],
                ),
            )
            winning_sha, winning_rows = ranked[0]
            mean_validation = sum(
                float(row["validation_mean_regret_by_deployment"][selection_mode])
                for row in winning_rows
            ) / len(winning_rows)
            selected_arms.append(
                {
                    "benchmark_id": benchmark_id,
                    "selection_deployment": selection_mode,
                    "arm_sha256": winning_sha,
                    "arm": winning_rows[0]["arm"],
                    "mean_validation_regret": mean_validation,
                    "candidate_arm_count": len(eligible),
                    "censored_incomplete_arm_count": len(grouped) - len(eligible),
                }
            )
            test_by_mode: dict[str, list[float]] = defaultdict(list)
            for row in sorted(winning_rows, key=lambda item: str(item["name"])):
                ablation = _load(
                    Path(row["run_directory"]) / "deployment_ablation.json"
                )
                test_matrix: dict[str, float] = {}
                for test_mode in ("soft", "hard_recovered"):
                    regret = float(
                        ablation["deployments"][test_mode]["test"]["mean_regret"]
                    )
                    test_matrix[test_mode] = regret
                    test_by_mode[test_mode].append(regret)
                selected_rows.append(
                    {
                        **row,
                        "selection_deployment": selection_mode,
                        "test_mean_regret_by_deployment": test_matrix,
                    }
                )
            for test_mode, regrets in sorted(test_by_mode.items()):
                aggregates.append(
                    {
                        "benchmark_id": benchmark_id,
                        "selection_deployment": selection_mode,
                        "test_deployment": test_mode,
                        "seed_count": len(regrets),
                        "mean_test_regret": sum(regrets) / len(regrets),
                        "standard_error_test_regret": _standard_error(regrets),
                    }
                )
    return {
        "selection_rule": (
            "independently select one shared arm per benchmark under soft and "
            "hard-recovered-cost validation regret; only then expose the 2x2 "
            "test deployment matrix"
        ),
        "run_root": str(run_root),
        "source_sha256": source_sha256,
        "selected_arms": selected_arms,
        "selected": selected_rows,
        "aggregates": aggregates,
        "censored_incomplete_arms": censored_incomplete_arms,
        "candidate_rows_without_test_metrics": sorted(
            candidates, key=lambda row: str(row["name"])
        ),
    }


def render_markdown(summary: dict[str, Any]) -> str:
    lines = [
        "# Soft-Radial centered-log-barrier deployment ablation",
        "",
        str(summary["selection_rule"]),
        "",
        "| benchmark | selected by | tested as | mean regret | standard error |",
        "|---|---:|---:|---:|---:|",
    ]
    for row in summary["aggregates"]:
        lines.append(
            "| {benchmark_id} | {selection_deployment} | {test_deployment} | "
            "{mean_test_regret:.8g} | {standard_error_test_regret:.3g} |".format(
                **row
            )
        )
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", type=Path)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    arguments = parser.parse_args()
    summary = summarize(arguments.run_root, source_sha256=arguments.source_sha256)
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, summary)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.write_text(
        render_markdown(summary), encoding="utf-8"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
