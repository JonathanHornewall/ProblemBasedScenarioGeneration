"""Summarize one or more validation-only Atlas campaign waves."""

from __future__ import annotations

import argparse
from pathlib import Path

from proximal_spo.artifacts import write_json
from proximal_spo.development_analysis import (
    render_development_markdown,
    summarize_development,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", action="append", type=Path, required=True)
    parser.add_argument("--source-sha256", action="append")
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    arguments = parser.parse_args()
    summary = summarize_development(
        arguments.run_root,
        required_source_sha256=arguments.source_sha256,
    )
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, summary)
    arguments.markdown_output.write_text(
        render_development_markdown(summary), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
