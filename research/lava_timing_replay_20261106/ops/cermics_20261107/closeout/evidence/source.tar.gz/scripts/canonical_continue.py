"""Resume only unfinished cluster ownership after its Slurm allocation ends."""
import argparse
import fcntl
import json
import os
import sqlite3
import subprocess
import time
from pathlib import Path

from build_central_path_final import read, write


def recover_rows(root, db):
    """Receipts win; external leases and completed/censored rows stay untouched."""
    changed = []
    db.execute('BEGIN IMMEDIATE')
    try:
        for row in db.execute("SELECT id,status,host,worker,heartbeat FROM jobs WHERE status IN ('running','interrupted')").fetchall():
            if row['host'] not in ('node06.cluster.local','node07.cluster.local','node08.cluster.local','node09.cluster.local'):
                raise RuntimeError('Unexpected cluster ownership: '+str(dict(row)))
            receipt = root/'results/receipts'/(row['id']+'.json')
            status = 'terminal' if receipt.exists() else 'pending'
            db.execute('UPDATE jobs SET status=?,host=NULL,worker=NULL,heartbeat=NULL,rss=0 WHERE id=? AND status=?',
                       (status,row['id'],row['status']))
            changed.append({**dict(row),'new_status':status})
        db.commit()
    except BaseException:
        db.rollback()
        raise
    return changed


def activate(root, previous, seconds, workers=224):
    job = os.environ['SLURM_JOB_ID']
    if job == previous:
        raise RuntimeError('Continuation must use a distinct allocation')
    live = subprocess.check_output(['squeue','-h','-u',os.environ['USER'],'-o','%i'],text=True).split()
    if any(x.split('+')[0] == previous for x in live):
        raise RuntimeError('Previous allocation is still live; refusing overlap')
    guard=(root/'coordinator.lock').open('a')
    fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
    old=read(root/'burst_state.json')
    if str(old['slurm_job_id']) != previous:
        raise RuntimeError('Unexpected previous allocation identity')
    if old.get('status') == 'complete':
        return False
    archive=root/'continuations'/job
    archive.mkdir(parents=True,exist_ok=False)
    write(archive/'previous_burst_state.json',old)
    db=sqlite3.connect(root/'burst.sqlite',timeout=60);db.row_factory=sqlite3.Row
    rows=list(db.execute("SELECT id,status,host,worker,heartbeat FROM jobs WHERE status IN ('running','interrupted')"))
    write(archive/'previous_cluster_ownership.json',[dict(x) for x in rows])
    for row in rows:
        p=root/'results/progress'/(row['id']+'.json')
        if p.exists():
            write(archive/'partial_progress'/p.name,read(p))
    changes=recover_rows(root,db);db.close()
    now=time.time()
    prior_components=old.get('allocation_components',[int(previous)])
    if int(previous) in (11200,11203,11205):prior_components=[int(previous),int(previous)+1]
    state={**old,'slurm_job_id':job,'status':'running','started_unix':now,
           'deadline_unix':now+seconds,'maximum_workers':workers,
           'previous_allocations':sorted(set(old.get('previous_allocations',[])+prior_components)),
           'allocation_components':[int(job)],
           'continuation':True,'continuation_recovery':str(archive/'recovery.json')}
    write(archive/'recovery.json',{'updated_unix':now,'previous_allocation_stopped':True,
          'changes':changes,'external_leases_preserved':True,'receipts_preserved':True,
          'scientific_limits_unchanged':True,'cloud_limits_unchanged':True})
    write(root/'burst_state.json',state)
    write(root/'continuation_state.json',state)
    return True


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True)
    p.add_argument('--previous',required=True);p.add_argument('--seconds',type=int,default=5300)
    p.add_argument('--workers',type=int,default=224)
    a=p.parse_args()
    if not 1 <= a.workers <= 230:raise ValueError('Worker count exceeds campaign ceiling')
    raise SystemExit(0 if activate(a.root,a.previous,a.seconds,a.workers) else 10)
