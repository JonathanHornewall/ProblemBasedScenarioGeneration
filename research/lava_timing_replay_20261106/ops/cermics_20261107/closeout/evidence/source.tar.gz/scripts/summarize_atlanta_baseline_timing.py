#!/usr/bin/env python3
"""Report measured full-fit costs without imputing successful failed fits."""
from __future__ import annotations

import argparse
import csv
import json
import statistics
from pathlib import Path


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", required=True, type=Path)
    p.add_argument("--results", required=True, type=Path)
    p.add_argument("--output", required=True, type=Path)
    args = p.parse_args()
    manifest = json.loads(args.manifest.read_text())
    records = {}
    for f in args.results.rglob("receipts/*.json"):
        r = json.loads(f.read_text())
        if r.get("smoke_only"):
            continue
        key = r["job_id"]
        if key in records:
            raise RuntimeError(f"duplicate job receipt {key}")
        records[key] = r
    rows = []
    for route in manifest["routes"]:
        for method in manifest["methods"]:
            expected = [j for j in manifest["jobs"] if j["entry"]["route_id"] == route and j["method"] == method]
            rs = [records[j["id"]] for j in expected if j["id"] in records]
            success = [r for r in rs if r["status"] == "complete" and r["epochs_completed"] == 300]
            row = {"benchmark": route, "method": method, "complete": len(success),
                   "failed_or_incomplete": len(rs) - len(success), "pending": len(expected) - len(rs)}
            for name in ("training", "data_loading", "training_optimal_labels", "binding_geometry", "adjacent_geometry", "validation_reference", "validation_deployment"):
                values = [r["timing_seconds"].get(name, 0) for r in success]
                row[name + "_median_seconds"] = statistics.median(values) if values else None
            totals = [r["total_wall_seconds"] for r in success]
            row["total_median_seconds"] = statistics.median(totals) if totals else None
            row["total_min_seconds"] = min(totals) if totals else None
            row["total_max_seconds"] = max(totals) if totals else None
            rows.append(row)
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "timings.csv").open("w") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    complete = sum(r["complete"] for r in rows)
    all_measured = all(r["complete"] == 3 for r in rows)
    report = {
        "expected_runs": len(manifest["jobs"]), "completed_full_runs": complete,
        "terminal_receipts": len(records), "all_cells_measured_three_times": all_measured,
        "serial_hours_for_ten_final_restarts": sum(r["total_median_seconds"] * 10 for r in rows) / 3600 if all_measured else None,
        "note": "Fit medians include independent preprocessing and one final validation. Hyperparameter-search size remains a separate multiplier. Failed/incomplete fits are never treated as zero cost.",
        "rows": rows,
    }
    (args.output / "timings.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "rows"}))


if __name__ == "__main__":
    main()
