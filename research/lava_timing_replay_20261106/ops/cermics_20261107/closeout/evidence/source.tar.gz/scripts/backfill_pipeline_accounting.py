"""Derive whole-pipeline cost fields for legacy compact run receipts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import with_pipeline_accounting, write_json


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected a JSON object at {path}")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", nargs="?", type=Path, default=Path("runs"))
    arguments = parser.parse_args()
    updated = 0
    for summary_path in sorted(arguments.run_root.rglob("summary.json")):
        if summary_path.parent.name == "base_pretrain":
            continue
        summary = _object(summary_path)
        nested: list[tuple[str, dict[str, Any]]] = []
        base_path = summary_path.parent / "base_pretrain" / "summary.json"
        if base_path.is_file():
            nested.append(("base_pretrain", _object(base_path)))
        write_json(
            summary_path,
            with_pipeline_accounting(summary, nested_training_phases=nested),
        )
        updated += 1
    print(f"updated {updated} top-level run summaries")


if __name__ == "__main__":
    main()
