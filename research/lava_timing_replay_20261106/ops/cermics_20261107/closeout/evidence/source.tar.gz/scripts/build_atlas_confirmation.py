"""Build fixed-arm, paired-seed confirmation campaigns from development receipts."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
PATH_SUMMARY = REPO_ROOT / "results/development/atlas_paths_combined_validation.json"
LAVA_SUMMARY = REPO_ROOT / "results/development/atlas_lava_combined_validation.json"
PATH_SENTINELS = {
    "wise_shortest_path_5x5_degree_8",
    "lava_shortest_path_5x5_released_code",
    "dys_shortest_path_25x25",
    "directional_planted_path_additive_gaussian",
    "directional_random_cost_grid_additive_gaussian",
    "cave_sp5_degree_6",
}
PATH_METHODS = (
    "soft_radial_log_barrier",
    "mse",
    "wise",
    "spo_plus",
    "perturbed_fy",
    "sfge",
    "knn",
)
LAVA_SENTINELS = {
    "lava_random_lp_100x50_released_code",
    "lava_random_lp_200x50_released_code",
    "lava_random_lp_100x200_released_code",
}
LAVA_METHODS = (
    "soft_radial_log_barrier",
    "mse",
    "wise",
    "spo_plus",
    "knn",
)
CONFIRMATION_SEEDS = (
    {
        "data": 3109,
        "structural": 101,
        "initialization": 4103,
        "shuffle": 5101,
        "perturbation": 6101,
    },
    {
        "data": 3253,
        "structural": 101,
        "initialization": 4211,
        "shuffle": 5227,
        "perturbation": 6211,
    },
    {
        "data": 3391,
        "structural": 101,
        "initialization": 4337,
        "shuffle": 5347,
        "perturbation": 6337,
    },
)


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object at {path}")
    return payload


def _selected_configs(summary: dict[str, Any]) -> dict[tuple[str, str], dict[str, Any]]:
    selected = summary.get("selected_arms")
    if not isinstance(selected, list):
        raise ValueError("development summary lacks selected_arms")
    result: dict[tuple[str, str], dict[str, Any]] = {}
    for row in selected:
        if not isinstance(row, dict):
            raise ValueError("malformed selected arm")
        benchmark = row.get("benchmark_id")
        method = row.get("method")
        config = row.get("config")
        if not isinstance(benchmark, str) or not isinstance(method, str):
            raise ValueError("selected arm lacks benchmark or method")
        if not isinstance(config, dict):
            raise ValueError("selected arm lacks full config")
        key = (benchmark, method)
        if key in result:
            raise ValueError(f"duplicate selected arm {key}")
        result[key] = config
    return result


def build_path_confirmation(
    *, sentinels_only: bool, run_root: str | None = None
) -> dict[str, Any]:
    summary = _object(PATH_SUMMARY)
    if summary.get("selection_used_test") is not False:
        raise ValueError("development selection was not validation-only")
    selected = _selected_configs(summary)
    benchmarks = sorted({benchmark for benchmark, _method in selected})
    if sentinels_only:
        benchmarks = [
            benchmark for benchmark in benchmarks if benchmark in PATH_SENTINELS
        ]
    variants: list[dict[str, Any]] = []
    provenance: list[dict[str, Any]] = []
    for benchmark in benchmarks:
        for method in PATH_METHODS:
            key = (benchmark, method)
            if key not in selected:
                raise ValueError(f"missing selected development arm {key}")
            source_config = selected[key]
            short = str(source_config["name"]).split("_broad_")[0]
            source_row = next(
                row
                for row in summary["selected_arms"]
                if row["benchmark_id"] == benchmark and row["method"] == method
            )
            provenance.append(
                {
                    "benchmark_id": benchmark,
                    "method": method,
                    "development_run_directory": source_row["run_directory"],
                    "development_source_sha256": source_row["source_sha256"],
                    "development_validation_normalized_mean_regret": source_row[
                        "validation_normalized_mean_regret"
                    ],
                }
            )
            for index, seeds in enumerate(CONFIRMATION_SEEDS, start=1):
                config = copy.deepcopy(source_config)
                config["name"] = f"{short}_confirm_{method}_seed{index}"
                config["seeds"] = dict(seeds)
                config["evaluate_test"] = True
                variants.append(config)
    scope = "sentinels" if sentinels_only else "all_paths"
    return {
        "name": f"atlas_path_three_seed_confirmation_{scope}",
        "run_root": run_root or "results/campaigns/atlas_wave9_path_confirmation",
        "base": {},
        "design": {
            "confirmation": True,
            "selection_source": str(PATH_SUMMARY.relative_to(REPO_ROOT)),
            "selection_metric": "validation_normalized_mean_regret",
            "selection_used_test": False,
            "paired_seeds": list(CONFIRMATION_SEEDS),
            "selected_source_arms": provenance,
        },
        "variants": variants,
    }


def build_lava_confirmation(
    *, sentinels_only: bool, run_root: str | None = None
) -> dict[str, Any]:
    """Build the fixed-arm confirmation for all generic random-LP shapes."""

    summary = _object(LAVA_SUMMARY)
    if summary.get("selection_used_test") is not False:
        raise ValueError("development selection was not validation-only")
    selected = _selected_configs(summary)
    benchmarks = sorted({benchmark for benchmark, _method in selected})
    if sentinels_only:
        benchmarks = [
            benchmark for benchmark in benchmarks if benchmark in LAVA_SENTINELS
        ]
    variants: list[dict[str, Any]] = []
    provenance: list[dict[str, Any]] = []
    for benchmark in benchmarks:
        for method in LAVA_METHODS:
            key = (benchmark, method)
            if key not in selected:
                raise ValueError(f"missing selected development arm {key}")
            source_config = selected[key]
            source_row = next(
                row
                for row in summary["selected_arms"]
                if row["benchmark_id"] == benchmark and row["method"] == method
            )
            provenance.append(
                {
                    "benchmark_id": benchmark,
                    "method": method,
                    "development_run_directory": source_row["run_directory"],
                    "development_source_sha256": source_row["source_sha256"],
                    "development_validation_normalized_mean_regret": source_row[
                        "validation_normalized_mean_regret"
                    ],
                }
            )
            prefix = str(source_config["name"]).split("_")[0]
            for index, seeds in enumerate(CONFIRMATION_SEEDS, start=1):
                config = copy.deepcopy(source_config)
                config["name"] = f"{prefix}_confirm_{method}_seed{index}"
                config["seeds"] = dict(seeds)
                config["evaluate_test"] = True
                variants.append(config)
    scope = "sentinels" if sentinels_only else "all_lava"
    return {
        "name": f"atlas_lava_three_seed_confirmation_{scope}",
        "run_root": run_root or "results/campaigns/atlas_wave10_lava_confirmation",
        "base": {},
        "design": {
            "confirmation": True,
            "selection_source": str(LAVA_SUMMARY.relative_to(REPO_ROOT)),
            "selection_metric": "validation_normalized_mean_regret",
            "selection_used_test": False,
            "paired_seeds": list(CONFIRMATION_SEEDS),
            "selected_source_arms": provenance,
        },
        "variants": variants,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--scope",
        choices=("sentinels", "all-paths", "lava-sentinels", "all-lava"),
        default="sentinels",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--run-root",
        help="override the receipt root, for example for a clean sealed rerun",
    )
    arguments = parser.parse_args()
    if arguments.scope in {"sentinels", "all-paths"}:
        payload = build_path_confirmation(
            sentinels_only=arguments.scope == "sentinels",
            run_root=arguments.run_root,
        )
    else:
        payload = build_lava_confirmation(
            sentinels_only=arguments.scope == "lava-sentinels",
            run_root=arguments.run_root,
        )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = arguments.output.with_suffix(arguments.output.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    temporary.replace(arguments.output)
    print(f"wrote {len(payload['variants'])} variants to {arguments.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
