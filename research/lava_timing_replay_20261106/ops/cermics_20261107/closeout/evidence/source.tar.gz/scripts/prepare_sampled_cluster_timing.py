"""Freeze a separate timing manifest from completed sampled-validation selections."""
from __future__ import annotations

import collections
import copy
import shutil
import subprocess
import time
from pathlib import Path

from build_central_path_final import read, write
from canonical_cluster_timing import (METHODS, PROTOCOL, ROOT, sha, timing_job,
                                      timing_output, verify_manifest_arm, verify_ready)
from frozen_campaign_data import data_key


def bank_training_hashes(path, fields):
    import numpy as np
    from run_public_solver_free_matched import _hash_array
    with np.load(path, allow_pickle=False) as arrays:
        return {field: _hash_array(arrays["train__" + field]) for field in fields}


def sampled_sources(run, confirmation):
    """Use the frozen selection and all ten successful confirmations, not test scores."""
    sources, seen = [], set()
    for original in confirmation["jobs"]:
        if original.get("validation_costs") != "single_sample" or original.get("repeat") != 0:
            continue
        cell, method = original["comparison_cell"], original["method"]
        if (cell, method) in seen:
            raise RuntimeError("Duplicate sampled timing selection")
        seen.add((cell, method))
        selection = run / "cluster_retrieved/results/selections" / (
            f"confirmation__{original['cell']}__{method}.json")
        repaired = selection.with_name(selection.stem + "__memory_repair_v1.json")
        if repaired.exists():
            selection = repaired
        selected = read(selection)
        if {j["repeat"] for j in selected["jobs"]} != set(range(10)):
            raise RuntimeError("Sampled selection lacks its ten confirmation seeds")
        if next(j for j in selected["jobs"] if j["repeat"] == 0) != original:
            raise RuntimeError("Confirmation manifest and frozen sampled selection disagree")
        for job in selected["jobs"]:
            receipt = read(run / "cluster_retrieved/results/receipts" / (job["id"] + ".json"))
            if receipt["status"] != "complete" or receipt["job"] != job:
                raise RuntimeError("Sampled confirmation is not a matching successful receipt")
        path = run / "cluster_retrieved/results/receipts" / (original["id"] + ".json")
        receipt = read(path)
        validation = receipt["validation_protocol"]
        if (not validation["one_fixed_observed_cost_per_context"]
            or validation["selection_costs_sha256"] != receipt["data_hashes"]["validation"]["physical_costs"]
            or validation["contexts_sha256"] != receipt["data_hashes"]["validation"]["contexts"]):
            raise RuntimeError("Source did not use the fixed sampled validation costs")
        if receipt["summary"]["epochs_completed"] != original["frozen_horizon"]:
            raise RuntimeError("Source did not complete its frozen horizon")
        sources.append({"cell": cell, "method": method, "job": original,
            "receipt": receipt, "path": path, "sha256": sha(path),
            "selection_path": str(selection), "selection_sha256": sha(selection)})
    return sources


def prepare_sampled(run):
    target = read(run / "sampled_timing_target.json")
    if (target["validation_arm"] != "sampled" or target["target"] != "cermics"
        or target["matched_repeats"] != 1 or target["maximum_concurrent_fits"] != 8
        or target["maximum_allocated_cpus"] != 8):
        raise RuntimeError("Sampled timing protocol does not authorize this replay")
    confirmation = verify_ready(run)
    sources = sampled_sources(run, confirmation)
    output = timing_output(run, "sampled")
    remote_root = Path(read(run / "fleet.json")["cluster_root"])
    entries, bank_cache = [], {}
    for source in sources:
        original, receipt = source["job"], source["receipt"]
        bank_path = run / "cluster_retrieved/frozen_data" / (data_key(original) + ".npz")
        fields = receipt["data_hashes"]["train"]
        cache_key = (str(bank_path), tuple(sorted(fields)))
        if cache_key not in bank_cache:
            bank_cache[cache_key] = (sha(bank_path), bank_training_hashes(bank_path, fields))
        bank_sha, training_hashes = bank_cache[cache_key]
        if training_hashes != fields:
            raise RuntimeError("Sampled timing bank differs from the archived training arrays")
        bank = {"source_job": original["id"], "cell": source["cell"],
            "method": source["method"], "remote_bank": str(remote_root / "frozen_data" / bank_path.name),
            "local_bank": str(bank_path.resolve()), "bank_sha256": bank_sha,
            "verified_locally": True, "archived_training_hashes": training_hashes,
            "legacy_profile_bank": False}
        summary = receipt["summary"]
        planning = max(0.0, receipt.get("total_wall_seconds", receipt.get("elapsed_seconds", 0.0))
            - (summary.get("validation_wall_seconds") or 0.0)
            - (summary.get("test_evaluation_wall_seconds") or 0.0))
        entries.append({"job": timing_job(original, "sampled"), "source_job": original,
            "source_receipt_sha256": source["sha256"], "cell": source["cell"], "bank": bank,
            "source_selection_sha256": source["selection_sha256"],
            "estimated_non_evaluation_wall_seconds": planning,
            "memory_admission_gib": 12 if original["method"] == "lava" else 3})
    entries.sort(key=lambda e: (-e["estimated_non_evaluation_wall_seconds"], e["job"]["id"]))
    counts = collections.Counter(e["job"]["method"] for e in entries)
    control = read(run / "cluster_timing/manifest.json")
    expected_cells = {e["cell"] for e in control["entries"]}
    if (len(entries) != 272 or set(counts) != set(METHODS) or counts["lava"] != 27
        or any(counts[m] != 35 for m in METHODS if m != "lava")
        or {e["cell"] for e in entries} != expected_cells):
        raise RuntimeError("Sampled timing does not cover the final available 272 selections")
    manifest = {key: copy.deepcopy(control[key]) for key in (
        "schema", "concurrent_fits", "matched_repeats", "repeat", "threads_per_fit",
        "maximum_lava_fits", "memory_admission_gib", "allocation_memory_gib",
        "maximum_allocation_seconds", "test_evaluation", "validation_evaluation", "preparation_policy")}
    manifest.update(protocol_revision=PROTOCOL, validation_arm="sampled", entries=entries,
        source_revision=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        counts=dict(counts), mean_manifest_sha256=sha(run / "cluster_timing/manifest.json"))
    verify_manifest_arm(manifest, "sampled")
    path = output / "manifest.json"
    if path.exists() and read(path) != manifest:
        raise RuntimeError("Refusing to replace immutable sampled timing manifest")
    for source in sources:
        destination = output / "sources" / (source["job"]["id"] + ".json")
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists() and sha(destination) != source["sha256"]:
            raise RuntimeError("Frozen sampled source copy changed")
        if not destination.exists():
            shutil.copyfile(source["path"], destination)
    write(path, manifest)
    write(output / "prepared.json", {"updated_unix": time.time(), "status": "ready",
        "validation_arm": "sampled", "manifest_sha256": sha(path), "counts": dict(counts),
        "selection_complete": True, "all_source_receipts_and_banks_verified": True,
        "unique_training_banks": len(bank_cache), "mean_manifest_sha256": manifest["mean_manifest_sha256"]})
    return path
