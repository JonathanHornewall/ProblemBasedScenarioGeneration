#!/usr/bin/env python3
"""Detach a resumable Atlanta campaign behind already-running child jobs.

The desktop command runner may reap a shell-owned controller while children
started in their own sessions continue.  This tiny supervisor waits for the
known child PIDs, then replaces itself with the normal resumable launcher.
It never imposes a wall-time gate and never touches a child process.
"""

from __future__ import annotations

import argparse
import os
import time
from pathlib import Path


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _detach() -> None:
    """Double-fork into a fresh session before waiting or launching work."""

    if os.fork() > 0:
        os._exit(0)
    os.setsid()
    if os.fork() > 0:
        os._exit(0)


def main() -> int:
    _detach()
    parser = argparse.ArgumentParser()
    parser.add_argument("--wait-pid", type=int, action="append", default=[])
    parser.add_argument("--poll-seconds", type=float, default=30.0)
    parser.add_argument("--pid-file", type=Path)
    parser.add_argument("launcher", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if not args.launcher or args.launcher[0] != "--":
        parser.error("launcher command must follow --")
    if args.pid_file is not None:
        args.pid_file.parent.mkdir(parents=True, exist_ok=True)
        args.pid_file.write_text(f"{os.getpid()}\n", encoding="utf-8")
    command = args.launcher[1:]
    while any(_alive(pid) for pid in args.wait_pid):
        time.sleep(max(1.0, args.poll_seconds))
    os.execvpe(command[0], command, os.environ.copy())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
