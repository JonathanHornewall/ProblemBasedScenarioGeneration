#!/usr/bin/env python3
"""Keep a resumable Atlanta campaign alive across controller interruptions."""

from __future__ import annotations

import argparse
import subprocess
import time
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--python", type=Path, required=True)
    parser.add_argument("--launcher", type=Path, required=True)
    parser.add_argument("--poll-seconds", type=float, default=30.0)
    parser.add_argument("launcher_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    output_root = args.output_root.resolve()
    command = [
        str(args.python.resolve()),
        str(args.launcher.resolve()),
        *args.launcher_args,
    ]
    if command[2:3] == ["--"]:
        command.pop(2)
    while not (output_root / "finished.json").is_file():
        completed = subprocess.run(command, cwd=args.launcher.resolve().parents[1], check=False)
        if (output_root / "finished.json").is_file():
            return 0
        # Preserve the failed/interrupted controller's receipts and resume;
        # no child-level timeout is introduced here.
        time.sleep(max(1.0, args.poll_seconds))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
