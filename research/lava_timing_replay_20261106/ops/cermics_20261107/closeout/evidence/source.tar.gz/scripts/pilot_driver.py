"""Durable two-step queue shared by bounded one-core Slurm workers."""
from __future__ import annotations
import argparse
import collections
import copy
import fcntl
import json
import os
import signal
import socket
import statistics
import subprocess
import time
from pathlib import Path
from pilot_common import *

class Pilot:
    def __init__(self,root):
        self.root=Path(root);self.plan=read(self.root/'PLAN.json');self.records={};self.jobs=dict(self.plan['step1_jobs'])
        for j in self.jobs.values():write(self.root/'jobs'/(j['id']+'.json'),manifest(j),immutable=True)
        for p in (self.root/'jobs').glob('*.json'):
            j=read(p)['jobs'][0];self.jobs[j['id']]=j
        self.phase='step1';self.choices=None
        if (self.root/'STEP2_SELECTIONS.json').exists():self.choices=read(self.root/'STEP2_SELECTIONS.json')

    def record(self,j):
        jid=j if isinstance(j,str) else j['id']
        if jid in self.records:return self.records[jid]
        p=self.root/'results/receipts'/(jid+'.json')
        if p.exists():
            d=read(p)
            if d.get('job',{}).get('id')!=jid:raise ValueError('Receipt identity mismatch')
            if jid in self.jobs and digest(d['job'])!=digest(self.jobs[jid]):raise ValueError('Receipt payload differs from immutable job')
            if d['status'] not in ('complete','failed','censored'):raise ValueError('Nonterminal receipt')
            self.records[jid]=d;return d

    def require(self,j):
        if j['id'] in self.jobs and digest(self.jobs[j['id']])!=digest(j):raise ValueError('Job ID collision')
        self.jobs[j['id']]=j
        write(self.root/'jobs'/(j['id']+'.json'),manifest(j),immutable=True)
        return self.record(j)

    def screens(self,route):
        seeds=self.plan['cells'][route]['screen']
        return [make_job(t,seeds,step=2,stage='screen',dual=True,route=route) for t in self.plan['step2_family_grids'][family(route)]]

    def shortlist(self,route,n):
        rows=[];unavailable=[]
        for j in self.screens(route):
            d=self.record(j)
            if d is None:return None
            score=validation_choice(d,n)
            if score is None:unavailable.append({'job_id':j['id'],'status':d['status'],'error':d.get('error')})
            else:rows.append((score,j['candidate'],j))
        rows.sort(key=lambda r:(r[0],r[1]))
        return rows,unavailable

    def refined(self,route,n,short):
        rows=[];unavailable=[];candidates=[]
        for _,_,template in short[:3]:
            jobs=[make_job(template,s,step=2,stage='refinement',dual=True,route=route) for s in self.plan['cells'][route]['refinement']]
            records=[self.require(j) for j in jobs]
            candidates.append((template,jobs,records))
        if any(d is None for _,_,records in candidates for d in records):return None
        for template,jobs,records in candidates:
            scores=[validation_choice(d,n) for d in records]
            if all(v is not None for v in scores):rows.append((statistics.mean(scores),template['candidate'],template,jobs))
            else:unavailable.append({'candidate':template['candidate'],'jobs':[{'id':j['id'],'status':d['status']} for j,d in zip(jobs,records)]})
        rows.sort(key=lambda r:(r[0],r[1]))
        return rows,unavailable

    def advance(self):
        step1_ids=list(self.plan['step1_jobs'])
        pending1=[i for i in step1_ids if self.record(i) is None]
        for method in METHODS:
            groups=[g for g in self.plan['step1_groups'] if g['method']==method]
            ids={i for g in groups for arm in g['arms'].values() for i in arm}
            if all(self.record(i) is not None for i in ids):
                proof=self.root/'milestones'/('step1_'+method+'.json')
                if not proof.exists():
                    from summarize_parsimonious_pilot import method_summary
                    method_summary(self.root,method)
                    write(proof,{'method':method,'groups':len(groups),'terminal_fits':len(ids),
                        'counts':dict(collections.Counter(self.record(i)['status'] for i in ids)),
                        'receipt_sha256':{i:sha(self.root/'results/receipts'/(i+'.json')) for i in sorted(ids)},
                        'completed_unix':time.time()},immutable=True)
        if pending1:self.phase='step1'
        else:
            self.phase='step2_development'
            routes=sorted(self.plan['cells'])
            for route in routes:
                for j in self.screens(route):self.require(j)
            complete=True
            for route in routes:
                for n in (32,100):
                    result=self.shortlist(route,n)
                    if result is None:complete=False;continue
                    if self.refined(route,n,result[0]) is None:complete=False
            if complete and self.choices is None:
                choices=[]
                for route in routes:
                    for scope in ('per_instance','smallest_family'):
                        source=route if scope=='per_instance' else SMALLEST[family(route)]
                        for n in (32,100):
                            short,missing_screen=self.shortlist(source,n)
                            refined,missing_refine=self.refined(source,n,short)
                            for use_refine in (False,True):
                                ranked=refined if use_refine else short
                                selected=ranked[0][2] if ranked else None
                                choices.append({'route':route,'selection_route':source,'scope':scope,'validation_size':n,
                                    'refinement':use_refine,'candidate':None if selected is None else selected['candidate'],
                                    'selected_template':selected,'selection_score':None if not ranked else ranked[0][0],
                                    'shortlist':[r[1] for r in short[:3]],'unavailable_screen':missing_screen,
                                    'unavailable_refinement':missing_refine if use_refine else [],
                                    'test_scores_read':False,'epoch_selection':'each final run uses its own observed validation',
                                    'development_receipts':[j['id'] for j in self.screens(source)]+(
                                        [j['id'] for _,_,_,jj in refined for j in jj] if use_refine else [])})
                for row in choices:
                    row['id']=digest({k:row[k] for k in ('route','scope','validation_size','refinement')})[:24]
                self.choices={'choices':choices,'created_unix':time.time(),'test_scores_read':False,
                    'development_receipt_sha256':{i:sha(self.root/'results/receipts'/(i+'.json')) for i,j in self.jobs.items()
                        if j['pilot_step']==2 and j['stage']!='confirmation' and self.record(j) is not None}}
                write(self.root/'STEP2_SELECTIONS.json',self.choices,immutable=True)
            if self.choices is not None:
                self.phase='step2_confirmation'
                selected=collections.defaultdict(set);templates={}
                for c in self.choices['choices']:
                    if c['candidate'] is not None:
                        k=(c['route'],c['candidate']);selected[k].add(c['validation_size']);templates[k]=c['selected_template']
                assignments={}
                for (route,candidate),sizes in sorted(selected.items()):
                    ids=[]
                    for seed in self.plan['cells'][route]['confirmation']:
                        j=make_job(templates[route,candidate],seed,step=2,stage='confirmation',dual=True,route=route,test_sizes=sizes)
                        self.require(j);ids.append(j['id'])
                    assignments[route+'|'+candidate]=ids
                write(self.root/'STEP2_ASSIGNMENTS.json',assignments,immutable=True)
                if all(self.record(i) is not None for ids in assignments.values() for i in ids):self.phase='complete'
        pending=[]
        for j in self.jobs.values():
            if self.record(j) is None:
                # All Step 1 work precedes Step 2. Within Step 1 prefer whole methods.
                if self.phase=='step1' and j['pilot_step']!=1:continue
                priority=METHODS.index(j['method'])*10 if j['pilot_step']==1 else 100+(0 if j['stage']=='refinement' else 1 if j['stage']=='confirmation' else 2)
                pending.append({'id':j['id'],'priority':priority,'memory_gib':provision(j),'method':j['method']})
        pending.sort(key=lambda j:(j['priority'],j['id']))
        write(self.root/'QUEUE.json',{'phase':self.phase,'jobs':pending,'updated_unix':time.time()})
        counts=collections.Counter(d['status'] for d in self.records.values())
        status={'status':self.phase,'updated_unix':time.time(),'registered_unique_fits':len(self.jobs),
            'terminal_counts':dict(counts),'pending_fits':len(pending),'full_campaign_authorized':False}
        write(self.root/'STATUS.json',status)
        return self.phase=='complete'

def terminate(child):
    if child.poll() is not None:return
    try:os.killpg(child.pid,signal.SIGTERM)
    except ProcessLookupError:return
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:
        try:os.killpg(child.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        child.wait(timeout=5)

def node_reservation(root,token,memory=None):
    """Reserve a fit's provision within its node, releasing stale worker leases."""
    import psutil
    base=root/'node_admission';base.mkdir(exist_ok=True);host=socket.gethostname()
    with (base/(host+'.lock')).open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        path=base/(host+'.json');leases=read(path) if path.exists() else {}
        for key,value in list(leases.items()):
            try:alive=abs(psutil.Process(value['pid']).create_time()-value['created'])<.01
            except psutil.Error:alive=False
            if not alive:del leases[key]
        leases.pop(token,None)
        if memory is not None:
            if sum(v['memory_gib'] for v in leases.values())+memory>float(os.environ.get('PILOT_NODE_MEMORY_GIB','230')):
                write(path,leases);return False
            leases[token]={'pid':os.getpid(),'created':psutil.Process().create_time(),'memory_gib':memory,
                'job_id':os.environ['SLURM_JOB_ID']}
        write(path,leases);return True

def worker(root,capacity,leader=False):
    import psutil
    root=Path(root).resolve();root.joinpath('claims').mkdir(exist_ok=True);root.joinpath('workers').mkdir(exist_ok=True)
    token=os.environ.get('SLURM_JOB_ID','local')+'_'+os.environ.get('SLURM_NODEID','0')+'_'+os.environ.get('PILOT_WORKER_INDEX','0')
    heartbeat=root/'workers'/(token+'.json');stopped=False;active=None;claim=None;last_advance=0;campaign=None
    def stop(*args):
        nonlocal stopped
        stopped=True
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Scientific execution requires Slurm')
    if len(os.sched_getaffinity(0))!=1:raise RuntimeError('Each worker must be bound to one CPU')
    if leader:
        lock=(root/'coordinator.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if read(root/'preflight/VERIFICATION.json')['status']!='passed':raise RuntimeError('Pilot preflight gate failed')
        campaign=Pilot(root);campaign.advance()
    env=environment(root);started=time.time()
    try:
        while not stopped:
            if leader and time.time()-last_advance>8:
                if campaign.advance() and not (root/'PILOT_COMPLETE.json').exists():
                    from summarize_parsimonious_pilot import summarize
                    summarize(root);write(root/'PILOT_COMPLETE.json',{'status':'complete','finished_unix':time.time(),
                        'source_commit':read(root/'source_receipt.json')['git_commit'],'full_campaign_started':False},immutable=True)
                last_advance=time.time()
            if not (root/'QUEUE.json').exists():time.sleep(2);continue
            q=read(root/'QUEUE.json')
            if active is not None:
                child,j,opened,log=active;reason=None
                try:
                    processes=[psutil.Process(child.pid),*psutil.Process(child.pid).children(recursive=True)]
                    rss=sum(p.memory_info().rss for p in processes)/2**30
                except psutil.Error:rss=0
                if rss>provision(j)*.9:reason='memory_cap'
                limits=j['resource_limits'];progress=root/'results/progress'/(j['id']+'.json')
                state=read(progress) if progress.exists() else {}
                elapsed=time.time()-opened
                if limits['job_wall_cap_seconds'] is not None and elapsed>limits['job_wall_cap_seconds']+15:reason='wall_time_cap'
                if limits['preprocessing_cap_seconds'] is not None and state.get('phase') in (None,'imports','preprocessing') and elapsed>limits['preprocessing_cap_seconds']+15:reason='preprocessing_time_cap'
                if reason:terminate(child)
                if child.poll() is not None:
                    out=root/'results/receipts'/(j['id']+'.json')
                    if not out.exists():
                        state.update(job=j,status='censored' if reason else 'failed',error=reason or 'worker_exit_without_receipt',
                            returncode=child.returncode,total_wall_seconds=elapsed,finished_unix=time.time(),
                            test_access=state.get('test_access',False),smoke_only=bool(j.get('diagnostic_only')))
                        write(out,state,immutable=True)
                    log.close();claim.close();node_reservation(root,token);claim=None;active=None
            if active is None:
                if q['phase']=='complete':break
                for item in q['jobs']:
                    if item['memory_gib']>capacity:continue
                    jid=item['id'];out=root/'results/receipts'/(jid+'.json')
                    if out.exists():continue
                    candidate=(root/'claims'/(jid+'.lock')).open('a')
                    try:fcntl.flock(candidate,fcntl.LOCK_EX|fcntl.LOCK_NB)
                    except BlockingIOError:candidate.close();continue
                    if out.exists():candidate.close();continue
                    j=read(root/'jobs'/(jid+'.json'))['jobs'][0]
                    if not node_reservation(root,token,provision(j)):
                        candidate.close();continue
                    logpath=root/'results/logs'/(jid+'.log');logpath.parent.mkdir(parents=True,exist_ok=True)
                    log=logpath.open('a');cmd=[str(root/'venv/bin/python'),str(root/'code/scripts/run_central_path_final.py'),
                        '--manifest',str(root/'jobs'/(jid+'.json')),'--job-index','0','--output-root',str(root/'results')]
                    child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                    active=(child,j,time.time(),log);claim=candidate;break
            write(heartbeat,{'slurm_job_id':os.environ['SLURM_JOB_ID'],'array_task':os.environ.get('SLURM_ARRAY_TASK_ID'),
                'host':socket.gethostname(),'pid':os.getpid(),'capacity_gib':capacity,'updated_unix':time.time(),
                'fit_id':None if active is None else active[1]['id'],'fit_pid':None if active is None else active[0].pid,
                'phase':q['phase'],'leader':leader})
            time.sleep(2)
    finally:
        if active is not None:
            child,j,opened,log=active;terminate(child);log.close()
            write(root/'results/interruptions'/(j['id']+'.'+str(time.time_ns())+'.json'),
                {'job':j,'reason':'allocation_interruption','started_unix':opened,'ended_unix':time.time()},immutable=True)
        if claim is not None:claim.close()
        node_reservation(root,token)
        write(heartbeat,{'status':'ended','slurm_job_id':os.environ['SLURM_JOB_ID'],'host':socket.gethostname(),
            'pid':os.getpid(),'ended_unix':time.time(),'started_unix':started,'leader':leader})

def node_pool(root,workers=50,memory=230):
    root=Path(root).resolve()
    if int(os.environ.get('SLURM_CPUS_PER_TASK','0'))!=workers or workers*int(os.environ.get('SLURM_NTASKS','0'))>150:
        raise RuntimeError('Allocation does not match CPU ceiling')
    # Bind each process to a distinct allocated physical core, not two SMT siblings.
    physical={}
    for cpu in sorted(os.sched_getaffinity(0)):
        topo=Path(f'/sys/devices/system/cpu/cpu{cpu}/topology')
        key=((topo/'physical_package_id').read_text().strip(),(topo/'core_id').read_text().strip())
        physical.setdefault(key,cpu)
    cores=list(physical.values())
    if len(cores)<workers:raise RuntimeError('Insufficient distinct allocated physical cores')
    children=[];stopped=False
    def stop(*args):
        nonlocal stopped
        stopped=True
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    write(root/'ops'/('POOL_'+socket.gethostname()+'.json'),{'job_id':os.environ['SLURM_JOB_ID'],
        'cores':cores[:workers],'workers':workers,'memory_admission_gib':memory,'started_unix':time.time()})
    try:
        for index,cpu in enumerate(cores[:workers]):
            env=environment(root);env.update(PILOT_WORKER_INDEX=str(index),PILOT_NODE_MEMORY_GIB=str(memory))
            cmd=[str(root/'venv/bin/python'),str(root/'code/scripts/pilot_driver.py'),'--root',str(root),
                '--capacity-gib','12']
            if index==0 and os.environ.get('SLURM_NODEID')=='0':cmd.append('--leader')
            # taskset constrains the worker and all its numerical subprocesses.
            children.append(subprocess.Popen(['taskset','-c',str(cpu),*cmd],env=env))
        while not stopped and any(c.poll() is None for c in children):
            failed=[c.returncode for c in children if c.poll() not in (None,0)]
            if failed:raise RuntimeError('Worker process failed: '+str(failed))
            time.sleep(3)
    finally:
        for child in children:
            if child.poll() is None:child.terminate()
        for child in children:
            try:child.wait(timeout=20)
            except subprocess.TimeoutExpired:child.kill();child.wait()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--capacity-gib',type=int,required=True)
    p.add_argument('--leader',action='store_true');a=p.parse_args();worker(a.root,a.capacity_gib,a.leader)
