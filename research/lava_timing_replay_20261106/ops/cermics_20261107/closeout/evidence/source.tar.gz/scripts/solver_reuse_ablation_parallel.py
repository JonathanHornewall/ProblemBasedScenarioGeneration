"""Per-fit handoff inside existing Slurm allocations; numerical code unchanged."""
from __future__ import annotations

import argparse
from collections import Counter
import fcntl
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from pilot_common import read, write
from solver_reuse_ablation_ops import RESERVE, TERMINAL_STATES, command
from solver_reuse_ablation_scope import completion_state, effective_scope

AMENDMENT = "PLACEMENT_AMENDMENT_20261024_PARALLEL.json"
LEGACY_REASON = "human_authorized_parallel_mode_placement_amendment"
REFILL_BURST_LIMIT = 4
REFILL_BURST_SECONDS = 10.


def process(pid, start_ticks=None):
    try:
        p = Path("/proc") / str(pid)
        fields = (p / "stat").read_text().rsplit(")", 1)[1].split()
        if fields[0] == "Z" or (start_ticks is not None and str(start_ticks) != fields[19]):
            return None
        return {"pid": pid, "state": fields[0], "start_ticks": fields[19],
                "affinity": sorted(os.sched_getaffinity(pid))}
    except (FileNotFoundError, ProcessLookupError):
        return None


def physical(cpu):
    p = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
    return [(p / "physical_package_id").read_text().strip(), (p / "core_id").read_text().strip()]


def await_binding(pid, cpu, timeout=3.):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        child = process(pid)
        if child is None:
            raise RuntimeError("Mode child exited before binding acknowledgement")
        if child["affinity"] == [cpu]:
            return child
        time.sleep(.01)
    raise RuntimeError("Mode child did not acknowledge its claimed single CPU")


def failure(root, reason, **details):
    p = root / "ops/PARALLEL_FAILURE_HOLD.json"
    if not p.exists():
        write(p, {"reason": reason, "unix": time.time(), **details}, immutable=True)


def idle_release_jobs(completion, active, hosts, live):
    if not completion["science_terminal"] or active:
        raise RuntimeError("Healthy numerical processes or unfinished work forbid idle release")
    return [h["slurm_job_id"] for h in hosts if h["slurm_job_id"] in live]


def managed_hosts(amendment, registry):
    """Retain original placement; omit only explicitly reconciled idle owners."""
    hosts = []
    for host in amendment["hosts"]:
        matches = [h for h in registry["hosts"] if h["name"] == host["name"]]
        if (len(matches) != 1 or matches[0]["slurm_job_id"] != host["slurm_job_id"]
                or matches[0]["slots"] != host["slots"]):
            raise RuntimeError("Host ownership registry disagrees with placement amendment")
        record = matches[0]
        if record.get("retired"):
            row = record.get("exact_terminal_sacct", [])
            if (len(row) != 4 or row[0] != host["slurm_job_id"] or not row[1]
                    or row[1].split()[0].rstrip("+") not in TERMINAL_STATES
                    or row[2] in ("", "Unknown", "None") or not row[3]
                    or record.get("retirement_reason") != "verified_wholly_idle_allocation"
                    or not record.get("idle_verification")):
                raise RuntimeError("Retired allocation lacks exact terminal accounting and idle evidence")
            continue
        hosts.append(host)
    return hosts


def managed_workers(root, hosts):
    """Retired state files remain immutable history; every live owner is required."""
    workers = []
    for host in hosts:
        state = read(root / "ops/parallel_worker_states" / (host["name"] + ".json"))
        if state["host"] != host["name"] or state["slurm_job_id"] != host["slurm_job_id"]:
            raise RuntimeError("Parallel worker state disagrees with its managed allocation")
        workers.append(state)
    return workers


class Receipts:
    def __init__(self, root):
        self.root, self.statuses = root, {}

    def refresh(self):
        for p in (self.root / "results/receipts").glob("*.json"):
            if p.stem not in self.statuses:
                self.statuses[p.stem] = read(p)["status"]
        return self.statuses


def occupied(root, amendment, hostname, receipts):
    """Keep a fit's CPU/RAM occupied until actual process exit, even after receipt."""
    rows = []
    specs = [s for s in amendment["adopted_fits"] if s["hostname"] == hostname]
    for p in (root / "ops/parallel_fit_claims").glob("*.json"):
        claim = read(p)
        if claim["hostname"] != hostname:
            continue
        process_path = root / "ops/parallel_fit_processes" / (claim["fit_id"] + ".json")
        if not process_path.exists():
            rows.append({**claim, "pid": None, "launch_pending": True})
            if time.time() - claim["claimed_unix"] > 60:
                failure(root, "unresolved_launch_intent", fit_id=claim["fit_id"])
            continue
        specs.append({**claim, **read(process_path)})
    for spec in specs:
        live = process(spec["pid"], spec["start_ticks"])
        if live:
            if live["affinity"] != [spec["logical_cpu"]]:
                failure(root, "fit_affinity_changed", fit_id=spec["fit_id"], live=live)
            rows.append(spec)
        elif spec["fit_id"] not in receipts:
            failure(root, "fit_ended_without_receipt", fit_id=spec["fit_id"], process=spec)
    return rows


def compatible(placement, hostname, cpu_record):
    return (placement["hostname"] == hostname and placement["cpu_model"] == cpu_record["model"]
            and placement.get("core_type") == cpu_record.get("core_type"))


def choose(candidates, receipts, claims, placements, hostname, topology, busy, memory_available):
    """No three-core barrier: take one free physical core, prioritizing siblings."""
    free = [t for t in topology if t["physical_core"] not in busy]
    if not free:
        return None
    capacity = len({tuple(t["physical_core"]) for t in topology})
    ordered = sorted(candidates, key=lambda t: (t["id"] not in placements, -t["reference_optimization_wall_seconds"], t["id"]))
    for t in ordered:
        anchor = placements.get(t["id"])
        if anchor is None and capacity < 2:
            continue  # Preserve node07's assigned exception, avoid new serial triplets.
        if t["memory_gib"] > memory_available:
            continue
        core = next((c for c in free if anchor is None or compatible(anchor, hostname, c)), None)
        if core is None:
            continue
        for mode in t["mode_order"]:
            fid = t["fit_ids"][mode]
            if fid not in receipts and fid not in claims:
                return t, mode, core
    return None


def validate_placement(root, triplet, mode, before, owner):
    amendment = read(root / AMENDMENT)
    claim = read(root / "ops/parallel_fit_claims" / (triplet["fit_ids"][mode] + ".json"))
    placement = read(root / "ops/parallel_triplet_placements" / (triplet["id"] + ".json"))
    if (claim["owner"] != owner or claim["triplet_id"] != triplet["id"] or claim["mode"] != mode
            or claim["slurm_job_id"] != os.environ.get("SLURM_JOB_ID")
            or claim["logical_cpu"] != before["logical_cpu"]
            or claim["physical_core"] != [before["physical_package_id"], before["core_id"]]
            or before["hostname"] != placement["hostname"] or before["cpu_model"] != placement["cpu_model"]
            or triplet["id"] not in amendment["required_triplet_ids"]):
        raise RuntimeError("Parallel fit does not match its exclusive physical-core placement")
    return {"policy": "same_node_equivalent_distinct_physical_cores", "amendment": AMENDMENT,
            "claim": claim, "triplet_placement": placement,
            "earlier_exact_cpu_receipt_preserved": (root / "ops/triplet_hardware" / (triplet["id"] + ".json")).exists()}


def claim_fit(root, host, amendment, candidates, cache):
    with (root / "ops/assignment.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return None  # Publish/reap rather than wait behind another pool.
        receipts = cache.refresh()
        if any(s in ("failed", "censored") for s in receipts.values()):
            failure(root, "failed_or_censored_scientific_fit")
        hold = read(root / "ops/ADMISSION_HOLD.json")
        heartbeat = read(root / "ops/COORDINATOR_HEARTBEAT.json")
        if (not (root / "ops/PARALLEL_READY.json").exists() or heartbeat.get("placement") != AMENDMENT
                or hold.get("reason") != LEGACY_REASON or (root / "ops/PARALLEL_FAILURE_HOLD.json").exists()
                or (root / "ops/ACCOUNTING_HOLD.json").exists()
                or time.time() - heartbeat["unix"] > 600
                or time.time() >= amendment["deadline_unix"] or (root / "ops/TERMINAL.json").exists()
                or shutil.disk_usage(root).free < RESERVE):
            return None
        live = occupied(root, amendment, host["hostname"], receipts)
        if (root / "ops/PARALLEL_FAILURE_HOLD.json").exists():
            return None
        claimed = {p.stem for p in (root / "ops/parallel_fit_claims").glob("*.json")}
        claimed.update(s["fit_id"] for s in amendment["adopted_fits"])
        placements = {p.stem: read(p) for p in (root / "ops/parallel_triplet_placements").glob("*.json")}
        busy = [s["physical_core"] for s in live]
        used = sum(s["memory_gib"] for s in live if s["host"] == host["name"])
        overhead = 1 if host["slots"] == 1 else 2
        selected = choose(candidates, receipts, claimed, placements, host["hostname"], host["topology"], busy,
                          host["memory_gib"] - overhead - used)
        if selected is None:
            return None
        t, mode, core = selected
        mem = {line.split(":")[0]: int(line.split()[1]) for line in Path("/proc/meminfo").read_text().splitlines() if line.startswith("MemAvailable:")}
        if mem.get("MemAvailable", 0) < (t["memory_gib"] + 2) * 2**20:
            return None
        fid = t["fit_ids"][mode]
        # A never-reconciled older lock is not permission to repeat that fit.
        if (root / "ops/fit_locks" / (fid + ".lock")).exists():
            failure(root, "unowned_prior_fit_lock", fit_id=fid)
            return None
        placement = placements.get(t["id"])
        if placement is None:
            placement = {"triplet_id": t["id"], "hostname": host["hostname"], "cpu_model": core["model"],
                         "core_type": core.get("core_type"), "assigned_unix": time.time(), "policy": "same_node_equivalent_physical_cores"}
            write(root / "ops/parallel_triplet_placements" / (t["id"] + ".json"), placement, immutable=True)
        claim = {"fit_id": fid, "triplet_id": t["id"], "mode": mode, "host": host["name"],
                 "hostname": host["hostname"], "slurm_job_id": host["slurm_job_id"], "logical_cpu": core["cpu"],
                 "physical_core": core["physical_core"], "memory_gib": t["memory_gib"],
                 "owner": f"{host['name']}:{os.getpid()}:{time.time_ns()}", "claimed_unix": time.time()}
        write(root / "ops/parallel_fit_claims" / (fid + ".json"), claim, immutable=True)
        return claim


def pool(root, host_name):
    amendment = read(root / AMENDMENT)
    host = next(h for h in amendment["hosts"] if h["name"] == host_name)
    allowed = {c["cpu"] for c in host["topology"]}
    if os.environ.get("SLURM_JOB_ID") != host["slurm_job_id"] or not allowed <= os.sched_getaffinity(0):
        raise RuntimeError("Parallel pool must remain inside its original Slurm core set")
    os.sched_setaffinity(0, allowed)
    guard = (root / "ops/parallel_pool_locks" / (host_name + ".lock"))
    guard.parent.mkdir(parents=True, exist_ok=True)
    with guard.open("a") as singleton:
        fcntl.flock(singleton, fcntl.LOCK_EX | fcntl.LOCK_NB)
        manifest = read(root / "MANIFEST.json")
        candidates = [t for t in manifest["triplets"] if t["id"] in amendment["required_triplet_ids"]]
        cache, children = Receipts(root), {}
        env = dict(os.environ)
        env.update(PYTHONPATH=f"{root}/code/scripts:{root}/code/src:{root}/code/vendor/external/src",
                   SOLVER_FREE_DFL_REPO=str(root / "code/vendor/public"), DFL_EXTENSIONS_SRC=str(root / "code/vendor/external/src"), SIMPLIFIED_ROOT=str(root))
        for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
            env[key] = "1"
        while time.time() < amendment["deadline_unix"] and not (root / "ops/TERMINAL.json").exists():
            for fid, (child, log) in list(children.items()):
                if child.poll() is not None:
                    log.close()
                    if not (root / "results/receipts" / (fid + ".json")).exists():
                        failure(root, "new_fit_exit_without_receipt", fit_id=fid, returncode=child.returncode)
                    del children[fid]
            cache.refresh()
            burst_started = time.monotonic()
            for launch_index in range(REFILL_BURST_LIMIT):
                # Short fits can free cores during refill. Always reach the
                # worker heartbeat/reaping path even if capacity keeps opening.
                if launch_index and time.monotonic() - burst_started >= REFILL_BURST_SECONDS:
                    break
                claim = claim_fit(root, host, amendment, candidates, cache)
                if claim is None:
                    break
                fid = claim["fit_id"]
                log = (root / "logs" / (fid + ".log")).open("ab")
                argv = ["taskset", "-c", str(claim["logical_cpu"]), sys.executable, "-B", str(Path(__file__).with_name("solver_reuse_ablation_worker.py")),
                        "--root", str(root), "--triplet-id", claim["triplet_id"], "--mode", claim["mode"], "--parallel-owner", claim["owner"]]
                try:
                    child = subprocess.Popen(argv, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
                    # Other managers see the immutable launch reservation until
                    # taskset has actually bound the child. Never publish a
                    # transient inherited wide affinity as a running fit.
                    started = await_binding(child.pid, claim["logical_cpu"])
                    write(root / "ops/parallel_fit_processes" / (fid + ".json"), {"pid": child.pid, "start_ticks": started["start_ticks"]}, immutable=True)
                    children[fid] = child, log
                except BaseException as exc:
                    failure(root, "single_launch_outcome_needs_reconciliation", fit_id=fid, error=repr(exc))
                    raise
            rows = occupied(root, amendment, host["hostname"], cache.statuses)
            own = [s for s in rows if s["host"] == host_name]
            write(root / "ops/parallel_worker_states" / (host_name + ".json"),
                  {"host": host_name, "slurm_job_id": host["slurm_job_id"], "pid": os.getpid(), "active": own, "unix": time.time(), "status": "running"})
            time.sleep(3)


def coordinate(root):
    with (root / "ops/controller.lock").open("a") as guard:
        fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
        write(root / "ops/CONTROLLER_PROCESS.json", {"pid": os.getpid(), "unix": time.time(), "placement": AMENDMENT})
        amendment, scope, cache = read(root / AMENDMENT), effective_scope(root), Receipts(root)
        hosts = managed_hosts(amendment, read(root / "ops/HOSTS.json"))
        while True:
            receipts = cache.refresh()
            if any(s in ("failed", "censored") for s in receipts.values()):
                failure(root, "failed_or_censored_scientific_fit")
            queue = command(["squeue", "-h", "-r", "-u", "jonathan.hornewall", "-o", "%i|%C"])
            live = {line.split("|")[0]: int(line.split("|")[1]) for line in queue.splitlines()}
            for h in hosts:
                if h["slurm_job_id"] not in live:
                    rows = command(["sacct", "-n", "-P", "-X", "-j", h["slurm_job_id"], "--format=JobIDRaw,State,End"])
                    exact = [r.split("|") for r in rows.splitlines() if r.split("|")[0] == h["slurm_job_id"]]
                    known = len(exact) == 1 and exact[0][1].split()[0].rstrip("+") in TERMINAL_STATES and exact[0][2] not in ("", "Unknown", "None")
                    write(root / "ops/ACCOUNTING_HOLD.json", {"job_id": h["slurm_job_id"], "exact_rows": exact, "known_terminal": known, "action": "Reconcile unresolved fit ownership; no automatic rerun", "unix": time.time()})
            completion = completion_state(scope, {}, receipts)
            workers = managed_workers(root, hosts)
            active = [a for w in workers for a in w["active"]]
            stale = [w["host"] for w in workers if time.time() - w["unix"] > 60]
            if stale:
                failure(root, "parallel_pool_metadata_stale", hosts=stale)
            expired = time.time() >= amendment["deadline_unix"]
            # Receipt publication can precede process exit. Do not release the
            # stopped metadata owners until every actual numerical child ended.
            completion["science_terminal"] = completion["science_terminal"] and not active
            hold = (root / "ops/PARALLEL_FAILURE_HOLD.json").exists() or (root / "ops/ACCOUNTING_HOLD.json").exists()
            storage_hold = shutil.disk_usage(root).free < RESERVE
            write(root / "ops/COORDINATOR_HEARTBEAT.json", {"unix": time.time(), "science_terminal": completion["science_terminal"], "attempt_expired": expired, "storage_hold": storage_hold, "parallel_hold": hold, "placement": AMENDMENT})
            current = {**completion, "terminal_counts": dict(Counter(receipts.values())), "updated_unix": time.time(),
                       "active": active, "active_mode_processes": len(active), "active_triplets": len({a["triplet_id"] for a in active}),
                       "active_required_modes": sum(a["fit_id"] in scope["required_fit_ids"] for a in active),
                       "pending_mode_fits": 900 - completion["required_complete"] - sum(a["fit_id"] in scope["required_fit_ids"] and receipts.get(a["fit_id"]) != "complete" for a in active),
                       "additional_cpu_ceiling": 150, "campaign_reserved_cpus": sum(live.get(h["slurm_job_id"], 0) for h in hosts),
                       "all_jonathan_reserved_cpus": sum(live.values()), "allocated_slots": sum(h["slots"] for h in hosts),
                       "storage_hold": storage_hold, "parallel_hold": hold, "disk_free_bytes": shutil.disk_usage(root).free,
                       "attempt_expired": expired, "deadline_unix": amendment["deadline_unix"], "coordinator_pid": os.getpid(),
                       "placement_amendment": AMENDMENT, "legacy_sequential_hold_intentional": True}
            write(root / "ops/CURRENT_STATUS.json", current)
            if completion["science_terminal"] or expired:
                name = "EXECUTION_TERMINAL.json" if completion["science_terminal"] else "ATTEMPT_TERMINAL.json"
                write(root / "ops" / name, {"reason": "science_complete" if completion["science_terminal"] else "protective_deadline_unfinished", "campaign_complete": completion["science_terminal"], "unix": time.time()}, immutable=True)
                if completion["science_terminal"]:
                    jobs = idle_release_jobs(completion, active, hosts, live)
                    intent = {"job_ids": jobs, "actual_active_modes": [], "required_complete": 900,
                              "extras_drained": True, "unix": time.time(), "action": "Single exact owned idle allocation release; includes stopped metadata drivers"}
                    write(root / "ops/PARALLEL_IDLE_RELEASE_INTENT.json", intent, immutable=True)
                    if jobs:
                        try:
                            result = subprocess.run(["scancel", *jobs], capture_output=True, text=True, timeout=20)
                            ack = {"returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr, "unix": time.time()}
                        except Exception as exc:
                            ack = {"unknown_outcome": repr(exc), "action": "Reconcile these exact job IDs before another mutation", "unix": time.time()}
                        write(root / "ops/PARALLEL_IDLE_RELEASE_ACK.json", ack)
                return
            time.sleep(15)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("coordinate", "pool"))
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--host")
    args = parser.parse_args()
    coordinate(args.root) if args.operation == "coordinate" else pool(args.root, args.host)
