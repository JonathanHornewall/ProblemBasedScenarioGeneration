"""Build the staged, test-blind publication campaign.

The broad grids are deliberately pilot-informed rather than Cartesian.  Every
material factor is varied, but interactions are promoted only after a first
validation pass.  This keeps the campaign finite while giving every retained
method a comparable optimization and capacity search.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
PATH_GUIDE = REPO_ROOT / "results/development/atlas_paths_combined_validation.json"
LAVA_GUIDE = REPO_ROOT / "results/development/atlas_lava_combined_validation.json"
INTEGER_COVERAGE_CONFIG = REPO_ROOT / "configs/integer_relaxation/coverage.json"

PATH_SENTINELS = (
    "cave_sp5_degree_6",
    "directional_random_cost_grid_additive_gaussian",
    "dys_shortest_path_25x25",
    "lava_shortest_path_5x5_released_code",
    "wise_shortest_path_5x5_degree_8",
)
LAVA_SENTINELS = (
    "lava_random_lp_100x50_released_code",
    "lava_random_lp_100x200_released_code",
    "lava_random_lp_400x50_released_code",
)


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object at {path}")
    return payload


def _selected(path: Path) -> dict[tuple[str, str], dict[str, Any]]:
    payload = _object(path)
    if payload.get("selection_used_test") is not False:
        raise ValueError(f"pilot guide is not validation-only: {path}")
    result: dict[tuple[str, str], dict[str, Any]] = {}
    for row in payload["selected_arms"]:
        key = (str(row["benchmark_id"]), str(row["method"]))
        result[key] = copy.deepcopy(row["config"])
    return result


PATH_SELECTED = _selected(PATH_GUIDE)
LAVA_SELECTED = _selected(LAVA_GUIDE)
ALL_PATH_BENCHMARKS = tuple(sorted({key[0] for key in PATH_SELECTED}))
ALL_LAVA_BENCHMARKS = tuple(sorted({key[0] for key in LAVA_SELECTED}))
LOCAL_CONTINUOUS_BENCHMARKS = (
    "cost.assignment10",
    "cost.facility30x5_relaxation",
    "cost.grid5",
    "cost.knapsack20x5",
    "cost.knapsack50x5",
    "cost.random_lp60x30",
    "cost.random_lp100x50",
    "cost.topk20x5",
)
PRACTICAL_INTEGER_BENCHMARKS = (
    "wise_knapsack_16x2_degree_1",
    "wise_knapsack_16x2_degree_2",
    "wise_knapsack_16x2_degree_4",
    "dys_knapsack_50x2",
    "dys_knapsack_100x2",
    "dys_knapsack_200x2",
    "dys_knapsack_400x2",
    "dys_knapsack_500x2",
    "dys_cfl_50x5",
    "dys_cfl_100x10",
    "dys_cfl_200x10",
    "dys_cfl_250x10",
    "directional_binary_m_0_alpha_1",
    "sfge_kp50_values_seed_0",
    "pyepo_mdkp32x2_degree_1_noise_0_0_seed_0",
    "pyepo_mdkp32x2_degree_1_noise_0_5_seed_0",
    "pyepo_mdkp32x2_degree_2_noise_0_0_seed_0",
    "pyepo_mdkp32x2_degree_2_noise_0_5_seed_0",
    "pyepo_mdkp32x2_degree_4_noise_0_0_seed_0",
    "pyepo_mdkp32x2_degree_4_noise_0_5_seed_0",
    "pyepo_mdkp32x2_degree_6_noise_0_0_seed_0",
    "pyepo_mdkp32x2_degree_6_noise_0_5_seed_0",
    "predictiveco_cubic_topk",
    "predictiveco_knapsack_synthetic",
    "cost.binary_knapsack20x5",
    "cost.binary_knapsack50x5",
    "cost.facility15x4_mip",
    "cost.facility30x5_mip",
)
EXACT_INTEGER_PILOT_BENCHMARKS = (
    "wise_knapsack_16x2_degree_1",
    "dys_knapsack_50x2",
    "dys_cfl_50x5",
    "directional_binary_m_0_alpha_1",
    "sfge_kp50_values_seed_0",
    "pyepo_mdkp32x2_degree_4_noise_0_5_seed_0",
    "predictiveco_cubic_topk",
    "predictiveco_knapsack_synthetic",
    "cost.binary_knapsack20x5",
    "cost.facility15x4_mip",
)


def _slug(value: object) -> str:
    return str(value).replace(".", "p").replace("-", "_")


def _deduplicate(rows: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for row in rows:
        payload = copy.deepcopy(row)
        payload.pop("name", None)
        key = hashlib.sha256(
            json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        if key in seen:
            continue
        seen.add(key)
        result.append(row)
    return result


def _training_grid(
    *,
    train_size: int,
    horizon: int,
    large_width: int,
) -> list[tuple[str, dict[str, Any], dict[str, Any]]]:
    batch128 = min(128, train_size)
    batch512 = min(512, train_size)
    full = train_size
    sparse = tuple(
        epoch
        for epoch in (5, 10, 20, 40, 80, 120, 180, 240, 300, 450, 600)
        if epoch <= horizon
    )

    def training(
        rate: float,
        batch: int,
        schedule: str = "constant",
    ) -> dict[str, Any]:
        return {
            "epochs": horizon,
            "batch_size": batch,
            "learning_rate": rate,
            "patience": horizon + 1,
            "validation_interval": horizon,
            "validation_epochs": list(sparse),
            "learning_rate_schedule": schedule,
            "minimum_learning_rate_ratio": 0.1,
            "gradient_diagnostic_interval": 8,
            "torch_threads": 1,
        }

    small = {"depth": 2, "width": 64}
    large = {"depth": 3, "width": large_width}
    rows: list[tuple[str, dict[str, Any], dict[str, Any]]] = []
    for rate in (3e-4, 1e-3, 3e-3):
        rows.append((f"small_b512_lr{_slug(rate)}", small, training(rate, batch512)))
    for batch in (batch128, full):
        rows.append((f"small_b{batch}_lr1e3", small, training(1e-3, batch)))
    for rate in (3e-4, 1e-3, 3e-3):
        rows.append((f"large_b512_lr{_slug(rate)}", large, training(rate, batch512)))
    rows.append(
        (
            "small_b512_lr1e3_cosine",
            small,
            training(1e-3, batch512, "cosine"),
        )
    )
    unique: list[tuple[str, dict[str, Any], dict[str, Any]]] = []
    seen: set[str] = set()
    for tag, model, spec in rows:
        key = json.dumps([model, spec], sort_keys=True)
        if key not in seen:
            seen.add(key)
            unique.append((tag, model, spec))
    return unique


def _guided_base(
    benchmark: str,
    method: str,
    *,
    lava: bool,
    horizon: int = 300,
) -> dict[str, Any]:
    selected = LAVA_SELECTED if lava else PATH_SELECTED
    source_method = method
    if method not in {item[1] for item in selected if item[0] == benchmark}:
        source_method = "mse"
    config = copy.deepcopy(selected[(benchmark, source_method)])
    config["name"] = "placeholder"
    config["method"] = method
    config["evaluate_test"] = False
    config["method_parameters"] = {}
    config["workers"] = 4 if lava else 1
    config["training"].update(
        {
            "epochs": horizon,
            "patience": horizon + 1,
            "validation_interval": horizon,
            "gradient_diagnostic_interval": 8,
            "torch_threads": 1,
        }
    )
    return config


def _neural_method_rows(
    benchmark: str,
    method: str,
    *,
    lava: bool,
    horizon: int,
    base_override: dict[str, Any] | None = None,
    large_width_override: int | None = None,
) -> list[dict[str, Any]]:
    base = (
        _guided_base(benchmark, method, lava=lava, horizon=horizon)
        if base_override is None
        else copy.deepcopy(base_override)
    )
    train_size = int(base["sizes"]["train"])
    width = (
        512 if lava else 256
    ) if large_width_override is None else large_width_override
    rows: list[dict[str, Any]] = []
    for tag, model, training in _training_grid(
        train_size=train_size, horizon=horizon, large_width=width
    ):
        row = copy.deepcopy(base)
        row["name"] = f"pubdev_{_slug(benchmark)}_{method}_{tag}"
        row["model"].update(model)
        row["training"].update(training)
        rows.append(row)
    return _deduplicate(rows)


def _barrier_rows(
    benchmark: str,
    *,
    lava: bool,
    horizon: int = 300,
    base_override: dict[str, Any] | None = None,
    prior_parameters_override: dict[str, Any] | None = None,
    large_width_override: int | None = None,
) -> list[dict[str, Any]]:
    if prior_parameters_override is None:
        selected = LAVA_SELECTED if lava else PATH_SELECTED
        prior = copy.deepcopy(selected[(benchmark, "soft_radial_log_barrier")])
        prior_parameters = prior.get("method_parameters", {})
    else:
        prior_parameters = copy.deepcopy(prior_parameters_override)
    prior_alpha = float(prior_parameters.get("alpha_start", 0.1))
    base = (
        _guided_base(
            benchmark, "soft_radial_log_barrier", lava=lava, horizon=horizon
        )
        if base_override is None
        else copy.deepcopy(base_override)
    )
    train_size = int(base["sizes"]["train"])
    nominal_batch = min(512, train_size)
    width = (
        512 if lava else 256
    ) if large_width_override is None else large_width_override
    common = {
        "contraction": str(prior_parameters.get("contraction", "rational")),
        "contraction_scale": float(prior_parameters.get("contraction_scale", 1.0)),
        "minimum_scale": float(prior_parameters.get("minimum_scale", 0.01)),
        "alpha_start": prior_alpha,
        "alpha_end": prior_alpha,
        "schedule": "fixed",
        "deployment_mode": "hard_recovered",
        "kernel_backend": "torch",
        "torch_device": "cpu",
    }
    rows: list[dict[str, Any]] = []

    def add(
        tag: str,
        *,
        parameters: dict[str, Any] | None = None,
        rate: float = 1e-3,
        batch: int = nominal_batch,
        depth: int = 2,
        width_value: int = 64,
        lr_schedule: str = "constant",
    ) -> None:
        row = copy.deepcopy(base)
        row["name"] = f"pubdev_{_slug(benchmark)}_barrier_{tag}"
        row["model"].update({"depth": depth, "width": width_value})
        sparse = [
            epoch
            for epoch in (5, 10, 20, 40, 80, 120, 180, 240, 300, 450, 600)
            if epoch <= horizon
        ]
        row["training"].update(
            {
                "epochs": horizon,
                "batch_size": batch,
                "learning_rate": rate,
                "patience": horizon + 1,
                "validation_interval": horizon,
                "validation_epochs": sparse,
                "learning_rate_schedule": lr_schedule,
                "minimum_learning_rate_ratio": 0.1,
                "gradient_diagnostic_interval": 8,
                "torch_threads": 1,
            }
        )
        row["method_parameters"] = {**common, **(parameters or {})}
        rows.append(row)

    for tag, model, training in _training_grid(
        train_size=train_size, horizon=horizon, large_width=width
    ):
        add(
            f"optim_{tag}",
            rate=float(training["learning_rate"]),
            batch=int(training["batch_size"]),
            depth=int(model["depth"]),
            width_value=int(model["width"]),
            lr_schedule=str(training["learning_rate_schedule"]),
        )
    for alpha in (0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0):
        add(
            f"alpha{_slug(alpha)}",
            parameters={"alpha_start": alpha, "alpha_end": alpha},
        )
    for contraction in ("rational", "exponential", "hyperbolic"):
        add(f"chart_{contraction}", parameters={"contraction": contraction})
    for scale in (0.3, 3.0):
        add(
            f"radius{_slug(scale)}",
            parameters={"contraction_scale": scale},
        )
    for minimum in (0.001, 0.05):
        add(
            f"minimum{_slug(minimum)}",
            parameters={"minimum_scale": minimum},
        )
    for start in (1.0, 3.0):
        add(
            f"homotopy{_slug(start)}to0p1",
            parameters={
                "alpha_start": start,
                "alpha_end": 0.1,
                "schedule": "geometric",
                "anneal_fraction": 0.75,
            },
        )
    return _deduplicate(rows)


def _knn_rows(
    benchmark: str,
    *,
    lava: bool,
    base_override: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    base = (
        _guided_base(benchmark, "knn", lava=lava, horizon=1)
        if base_override is None
        else copy.deepcopy(base_override)
    )
    train_size = int(base["sizes"]["train"])
    rows: list[dict[str, Any]] = []
    for weighted in (False, True):
        for neighbors in (5, 10, 25, 50, 100, 200):
            if neighbors > train_size:
                continue
            row = copy.deepcopy(base)
            row["name"] = (
                f"pubdev_{_slug(benchmark)}_knn_k{neighbors}_w{int(weighted)}"
            )
            row["method_parameters"] = {
                "neighbors": neighbors,
                "distance_weighted": weighted,
            }
            rows.append(row)
    return rows


def _oracle_method_rows(
    benchmark: str,
    method: str,
    parameter: str,
    *,
    lava: bool,
    horizon: int = 100,
    base_override: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    base = (
        _guided_base(benchmark, method, lava=lava, horizon=horizon)
        if base_override is None
        else copy.deepcopy(base_override)
    )
    train_size = int(base["sizes"]["train"])
    base["model"].update({"depth": 2, "width": 64})
    base["training"].update(
        {
            "batch_size": min(128, train_size),
            "epochs": horizon,
            "patience": horizon + 1,
            "validation_interval": horizon,
            "validation_epochs": [10, 25, 50, horizon],
            "gradient_diagnostic_interval": 8,
        }
    )
    rows: list[dict[str, Any]] = []
    for value in (0.03, 0.1, 0.3, 1.0):
        for samples in (4, 8):
            row = copy.deepcopy(base)
            row["name"] = (
                f"pubdev_{_slug(benchmark)}_{method}_{parameter}{_slug(value)}_s{samples}"
            )
            row["method_parameters"] = {parameter: value, "samples": samples}
            rows.append(row)
    for rate in (3e-4, 3e-3):
        row = copy.deepcopy(base)
        row["name"] = f"pubdev_{_slug(benchmark)}_{method}_lr{_slug(rate)}"
        row["training"]["learning_rate"] = rate
        row["method_parameters"] = {parameter: 0.1, "samples": 4}
        rows.append(row)
    return _deduplicate(rows)


def _projection_rows(benchmark: str, *, lava: bool) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for method in ("soft_radial_policy", "rayen_policy"):
        for row in _neural_method_rows(
            benchmark, method, lava=lava, horizon=200
        ):
            if method == "soft_radial_policy":
                row["method_parameters"] = {
                    "contraction": "rational",
                    "contraction_scale": 1.0,
                    "minimum_scale": 0.01,
                    "kernel_backend": "torch",
                    "torch_device": "cpu",
                }
            rows.append(row)
    energy = _guided_base(benchmark, "log_energy_policy", lava=lava, horizon=200)
    energy["model"].update({"depth": 2, "width": 64, "dtype": "float64"})
    energy["training"].update(
        {
            "batch_size": min(512, int(energy["sizes"]["train"])),
            "validation_epochs": [10, 20, 40, 80, 120, 160, 200],
        }
    )
    for alpha in (0.1, 1.0, 3.0):
        for rate in (3e-4, 1e-3, 3e-3):
            row = copy.deepcopy(energy)
            row["name"] = (
                f"pubdev_{_slug(benchmark)}_log_energy_a{_slug(alpha)}_lr{_slug(rate)}"
            )
            row["training"]["learning_rate"] = rate
            row["method_parameters"] = {
                "alpha_start": alpha,
                "alpha_end": alpha,
                "schedule": "fixed",
                "energy_guard": "uncapped",
                "training_root_tolerance": 1e-5,
                "evaluation_root_tolerance": 1e-8,
                "matrix_backend": "auto",
                "kernel_backend": "numpy",
                "deployment_mode": "hard_recovered",
            }
            rows.append(row)
    return _deduplicate(rows)


def continuous_sentinels() -> dict[str, Any]:
    variants: list[dict[str, Any]] = []
    for lava, benchmarks in ((False, PATH_SENTINELS), (True, LAVA_SENTINELS)):
        for benchmark in benchmarks:
            for method in ("mse", "wise", "spo_plus"):
                variants.extend(
                    _neural_method_rows(
                        benchmark, method, lava=lava, horizon=300
                    )
                )
            variants.extend(_barrier_rows(benchmark, lava=lava))
            variants.extend(_knn_rows(benchmark, lava=lava))

            # Solver-heavy controls run broadly on the path families.  On
            # generic LPs the 100x50 route is the bounded runtime sentinel.
            if not lava or benchmark == LAVA_SENTINELS[0]:
                variants.extend(
                    _oracle_method_rows(
                        benchmark, "sfge", "sigma", lava=lava
                    )
                )
                variants.extend(
                    _oracle_method_rows(
                        benchmark, "perturbed_fy", "epsilon", lava=lava
                    )
                )
                variants.extend(_projection_rows(benchmark, lava=lava))

    return {
        "name": "publication_continuous_sentinel_development",
        "run_root": "results/campaigns/publication_continuous_sentinels",
        "design": {
            "stage": "development",
            "test_blind": True,
            "pilot_guides": [
                str(PATH_GUIDE.relative_to(REPO_ROOT)),
                str(LAVA_GUIDE.relative_to(REPO_ROOT)),
            ],
            "pilot_guides_used_only_for_search_range": True,
            "selection_metric": "validation_normalized_mean_regret",
            "material_factors": [
                "learning_rate",
                "batch_size",
                "capacity",
                "learning_rate_schedule",
                "barrier_parameter",
                "report_chart",
                "chart_radius",
                "training_horizon",
            ],
            "hard_deployment_validation": True,
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def continuous_remaining() -> dict[str, Any]:
    """Build the remainder of the 25-route continuous native Atlas.

    Solver-heavy controls are propagated across the structured path families,
    where the exact batched oracle makes the comparison scalable.  Their
    generic-LP propagation remains conditional on the 100x50 sentinel runtime
    gate and is therefore not silently embedded in this manifest.
    """

    variants: list[dict[str, Any]] = []
    for lava, benchmarks, sentinels in (
        (False, ALL_PATH_BENCHMARKS, set(PATH_SENTINELS)),
        (True, ALL_LAVA_BENCHMARKS, set(LAVA_SENTINELS)),
    ):
        for benchmark in benchmarks:
            if benchmark in sentinels:
                continue
            for method in ("mse", "wise", "spo_plus"):
                variants.extend(
                    _neural_method_rows(
                        benchmark, method, lava=lava, horizon=300
                    )
                )
            variants.extend(_barrier_rows(benchmark, lava=lava))
            variants.extend(_knn_rows(benchmark, lava=lava))
            if not lava:
                variants.extend(
                    _oracle_method_rows(
                        benchmark, "sfge", "sigma", lava=False
                    )
                )
                variants.extend(
                    _oracle_method_rows(
                        benchmark, "perturbed_fy", "epsilon", lava=False
                    )
                )
                variants.extend(_projection_rows(benchmark, lava=False))
    return {
        "name": "publication_continuous_remaining_development",
        "run_root": "results/campaigns/publication_continuous_remaining",
        "design": {
            "stage": "development",
            "test_blind": True,
            "selection_metric": "validation_normalized_mean_regret",
            "scope": "remaining routes after the frozen sentinel wave",
            "path_solver_heavy_controls": "full coverage",
            "generic_lp_solver_heavy_controls": (
                "deferred pending the 100x50 runtime gate"
            ),
            "hard_deployment_validation": True,
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def _local_base(
    benchmark: str,
    method: str,
    *,
    interface: str,
    random_fraction: float,
    skewed: bool = False,
    horizon: int = 300,
) -> dict[str, Any]:
    if skewed:
        sizes = {"train": 4096, "validation": 8192, "test": 1}
        law = {
            "context_dimension": 1,
            "random_fraction": 1.0,
            "style": "positive",
            "noise": "skewed_failure",
            "noise_scale": 0.1,
            "signal_scale": 0.1,
            "polynomial_degree": 1,
        }
        batch = 256
        evaluation_batch = 2048
        workers = 1
    else:
        sizes = {"train": 1024, "validation": 256, "test": 1}
        if "knapsack" in benchmark:
            cost_style = "negative"
        elif "random_lp" in benchmark:
            cost_style = "signed"
        else:
            cost_style = "positive"
        law = {
            "context_dimension": 8,
            "random_fraction": random_fraction,
            "style": cost_style,
            "noise": "gaussian",
            "noise_scale": 0.25,
            "signal_scale": 0.8,
            "polynomial_degree": 2,
        }
        batch = 128
        evaluation_batch = 512
        workers = 4
    return {
        "name": "placeholder",
        "benchmark_id": benchmark,
        "benchmark_source": "local",
        "conditional_reference_samples": 128,
        "cost_coordinate_normalization": "standardize",
        "evaluate_test": False,
        "method": method,
        "interface": interface,
        "workers": workers,
        "sizes": sizes,
        "law": law,
        "model": {
            "depth": 2,
            "width": 64,
            "activation": "silu",
            "layer_norm": False,
            "correction_depth": 1,
            "correction_width": 64,
            "dtype": "float32",
        },
        "training": {
            "epochs": horizon,
            "batch_size": batch,
            "learning_rate": 1e-3,
            "weight_decay": 1e-5,
            "optimizer": "adamw",
            "gradient_clip": 10.0,
            "validation_interval": horizon,
            "patience": horizon + 1,
            "minimum_delta": 1e-8,
            "evaluation_batch_size": evaluation_batch,
            "torch_threads": 1,
            "selection_mode": "validation_regret",
            "gradient_diagnostic_interval": 8,
        },
        "seeds": {
            "data": 1103,
            "structural": 101,
            "initialization": 7201,
            "shuffle": 7301,
            "perturbation": 7401,
        },
        "method_parameters": {},
    }


def _local_core_rows(
    benchmark: str,
    *,
    interface: str,
    random_fraction: float,
    route_name: str,
    skewed: bool = False,
) -> list[dict[str, Any]]:
    variants: list[dict[str, Any]] = []
    horizon = 150 if skewed else 300
    large_width = 128 if skewed else 256
    for method in ("mse", "wise", "spo_plus"):
        base = _local_base(
            benchmark,
            method,
            interface=interface,
            random_fraction=random_fraction,
            skewed=skewed,
            horizon=horizon,
        )
        variants.extend(
            _neural_method_rows(
                route_name,
                method,
                lava=False,
                horizon=horizon,
                base_override=base,
                large_width_override=large_width,
            )
        )
    barrier_base = _local_base(
        benchmark,
        "soft_radial_log_barrier",
        interface=interface,
        random_fraction=random_fraction,
        skewed=skewed,
        horizon=horizon,
    )
    variants.extend(
        _barrier_rows(
            route_name,
            lava=False,
            horizon=horizon,
            base_override=barrier_base,
            prior_parameters_override={
                "contraction": "rational",
                "contraction_scale": 1.0,
                "minimum_scale": 0.01,
                "alpha_start": 0.1,
            },
            large_width_override=large_width,
        )
    )
    knn_base = _local_base(
        benchmark,
        "knn",
        interface=interface,
        random_fraction=random_fraction,
        skewed=skewed,
        horizon=1,
    )
    variants.extend(_knn_rows(route_name, lava=False, base_override=knn_base))
    return variants


def local_continuous_and_skew() -> dict[str, Any]:
    variants: list[dict[str, Any]] = []
    control_routes = {
        ("cost.grid5", "partial", 0.25),
        ("cost.assignment10", "full", 0.25),
        ("cost.random_lp100x50", "full", 1.0),
    }
    for benchmark in LOCAL_CONTINUOUS_BENCHMARKS:
        for interface, fraction in (
            ("partial", 0.25),
            ("full", 0.25),
            ("full", 1.0),
        ):
            route = f"{benchmark}_{interface}_random{_slug(fraction)}"
            variants.extend(
                _local_core_rows(
                    benchmark,
                    interface=interface,
                    random_fraction=fraction,
                    route_name=route,
                )
            )
            if (benchmark, interface, fraction) in control_routes:
                for method, parameter in (
                    ("sfge", "sigma"),
                    ("perturbed_fy", "epsilon"),
                ):
                    base = _local_base(
                        benchmark,
                        method,
                        interface=interface,
                        random_fraction=fraction,
                        horizon=100,
                    )
                    variants.extend(
                        _oracle_method_rows(
                            route,
                            method,
                            parameter,
                            lava=False,
                            base_override=base,
                        )
                    )

    skew_route = "analytic_scalar_box_frozen_skew"
    variants.extend(
        _local_core_rows(
            "analytic.scalar_box",
            interface="full",
            random_fraction=1.0,
            route_name=skew_route,
            skewed=True,
        )
    )
    for method, parameter in (("sfge", "sigma"), ("perturbed_fy", "epsilon")):
        base = _local_base(
            "analytic.scalar_box",
            method,
            interface="full",
            random_fraction=1.0,
            skewed=True,
            horizon=100,
        )
        variants.extend(
            _oracle_method_rows(
                skew_route,
                method,
                parameter,
                lava=False,
                base_override=base,
            )
        )
    return {
        "name": "publication_local_continuous_and_skew_development",
        "run_root": "results/campaigns/publication_local_continuous_skew",
        "design": {
            "stage": "development",
            "test_blind": True,
            "scope": (
                "conventional local LP families, partial/full random-cost "
                "interfaces, and the frozen analytic skew-noise stress test"
            ),
            "same_law_partial_vs_full_interface": True,
            "selection_metric": "validation_normalized_mean_regret",
            "hard_deployment_validation": True,
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def _deep_merge(
    base: dict[str, Any], override: dict[str, Any]
) -> dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(result.get(key), dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def _integer_coverage_bases() -> dict[str, dict[str, Any]]:
    payload = _object(INTEGER_COVERAGE_CONFIG)
    base = payload["base"]
    result: dict[str, dict[str, Any]] = {}
    for variant in payload["variants"]:
        if variant["method"] != "mse":
            continue
        config = _deep_merge(base, variant)
        result[str(config["benchmark_id"])] = config
    return result


def _integer_base(
    benchmark: str,
    method: str,
    *,
    horizon: int,
    pilot: bool = False,
) -> dict[str, Any]:
    base = copy.deepcopy(_integer_coverage_bases()[benchmark])
    base["name"] = "placeholder"
    base["method"] = method
    base["method_parameters"] = {}
    base["evaluate_test"] = False
    base["sizes"]["test"] = 1
    # Local multidimensional knapsacks are minimization models with the zero
    # vector feasible.  Positive costs make every contextual instance
    # identically trivial.  Their registered cost law is therefore negative;
    # the external benchmark adapters retain their source-defined laws.
    if benchmark.startswith("cost.binary_knapsack"):
        base["law"]["style"] = "negative"
    if pilot:
        base["sizes"]["train"] = min(16, int(base["sizes"]["train"]))
        base["sizes"]["validation"] = min(
            4, int(base["sizes"]["validation"])
        )
    train_size = int(base["sizes"]["train"])
    checkpoints = [
        epoch for epoch in (10, 25, 50, 100, 200, 300) if epoch <= horizon
    ]
    base["model"].update({"depth": 2, "width": 64, "dtype": "float32"})
    base["training"].update(
        {
            "epochs": horizon,
            "batch_size": min(64, train_size),
            "learning_rate": 1e-3,
            "patience": horizon + 1,
            "validation_interval": horizon,
            "validation_epochs": checkpoints or [horizon],
            "learning_rate_schedule": "constant",
            "minimum_learning_rate_ratio": 0.1,
            "gradient_diagnostic_interval": 8,
            "evaluation_batch_size": max(32, int(base["sizes"]["validation"])),
            "torch_threads": 1,
            "selection_mode": "validation_regret",
        }
    )
    base["seeds"].update(
        {"initialization": 8201, "shuffle": 8301, "perturbation": 8401}
    )
    return base


def _integer_neural_rows(
    benchmark: str,
    method: str,
    *,
    horizon: int = 300,
) -> list[dict[str, Any]]:
    base = _integer_base(benchmark, method, horizon=horizon)
    train_size = int(base["sizes"]["train"])
    rows: list[dict[str, Any]] = []

    def add(tag: str, rate: float, batch: int, depth: int, width: int) -> None:
        row = copy.deepcopy(base)
        row["name"] = f"pubdev_integer_{_slug(benchmark)}_{method}_{tag}"
        row["training"].update({"learning_rate": rate, "batch_size": batch})
        row["model"].update({"depth": depth, "width": width})
        rows.append(row)

    nominal_batch = min(64, train_size)
    for rate in (3e-4, 1e-3, 3e-3):
        add(f"small_lr{_slug(rate)}", rate, nominal_batch, 2, 64)
        add(f"large_lr{_slug(rate)}", rate, nominal_batch, 3, 128)
    for batch in sorted({min(32, train_size), train_size}):
        add(f"small_b{batch}", 1e-3, batch, 2, 64)
    cosine = copy.deepcopy(base)
    cosine["name"] = f"pubdev_integer_{_slug(benchmark)}_{method}_cosine"
    cosine["training"]["learning_rate_schedule"] = "cosine"
    rows.append(cosine)
    return _deduplicate(rows)


def _integer_barrier_rows(benchmark: str) -> list[dict[str, Any]]:
    base = _integer_base(
        benchmark, "soft_radial_log_barrier", horizon=300
    )
    rows = _barrier_rows(
        f"integer_{benchmark}",
        lava=False,
        horizon=300,
        base_override=base,
        prior_parameters_override={
            "contraction": "rational",
            "contraction_scale": 1.0,
            "minimum_scale": 0.01,
            "alpha_start": 0.1,
        },
        large_width_override=128,
    )
    small_batch = copy.deepcopy(rows[0])
    small_batch["name"] = (
        f"pubdev_integer_{_slug(benchmark)}_barrier_small_b32"
    )
    small_batch["training"]["batch_size"] = min(
        32, int(base["sizes"]["train"])
    )
    rows.append(small_batch)
    return _deduplicate(rows)


def _integer_sfge_relaxation_rows(benchmark: str) -> list[dict[str, Any]]:
    base = _integer_base(benchmark, "sfge_relaxation", horizon=100)
    base["training"]["batch_size"] = min(32, int(base["sizes"]["train"]))
    rows: list[dict[str, Any]] = []
    for sigma in (0.03, 0.1, 0.3, 1.0):
        for samples in (2, 4):
            row = copy.deepcopy(base)
            row["name"] = (
                f"pubdev_integer_{_slug(benchmark)}_sfge_relax_"
                f"sigma{_slug(sigma)}_s{samples}"
            )
            row["method_parameters"] = {"sigma": sigma, "samples": samples}
            rows.append(row)
    return rows


def practical_integer_development() -> dict[str, Any]:
    variants: list[dict[str, Any]] = []
    for benchmark in PRACTICAL_INTEGER_BENCHMARKS:
        for method in ("mse", "wise", "spo_plus_relaxation"):
            variants.extend(_integer_neural_rows(benchmark, method))
        variants.extend(_integer_barrier_rows(benchmark))
        variants.extend(_integer_sfge_relaxation_rows(benchmark))
        knn = _integer_base(benchmark, "knn", horizon=1)
        variants.extend(
            _knn_rows(
                f"integer_{benchmark}", lava=False, base_override=knn
            )
        )
    return {
        "name": "publication_practical_integer_relaxation_development",
        "run_root": "results/campaigns/publication_integer_practical",
        "design": {
            "stage": "development",
            "test_blind": True,
            "scope": "28 practical MILP routes from nine source-anchored families",
            "training": "continuous relaxation for barrier, SPO+, and SFGE",
            "deployment_and_validation": "exact hard MIP",
            "selection_metric": "validation_normalized_mean_regret",
            "exact_integer_training": "separate bounded pilot manifest",
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def exact_integer_runtime_pilots() -> dict[str, Any]:
    variants: list[dict[str, Any]] = []
    for benchmark in EXACT_INTEGER_PILOT_BENCHMARKS:
        spo = _integer_base(benchmark, "spo_plus", horizon=10, pilot=True)
        spo["name"] = f"pubpilot_exact_integer_{_slug(benchmark)}_spo_plus"
        spo["training"].update(
            {
                "batch_size": min(4, int(spo["sizes"]["train"])),
                "validation_epochs": [10],
            }
        )
        variants.append(spo)
        for sigma in (0.1, 0.3):
            sfge = _integer_base(benchmark, "sfge", horizon=5, pilot=True)
            sfge["name"] = (
                f"pubpilot_exact_integer_{_slug(benchmark)}_sfge_"
                f"sigma{_slug(sigma)}"
            )
            sfge["training"].update(
                {
                    "batch_size": min(4, int(sfge["sizes"]["train"])),
                    "validation_epochs": [5],
                }
            )
            sfge["method_parameters"] = {"sigma": sigma, "samples": 1}
            variants.append(sfge)
    return {
        "name": "publication_exact_integer_solver_loop_runtime_pilots",
        "run_root": "results/campaigns/publication_integer_exact_pilots",
        "design": {
            "stage": "bounded_runtime_preflight",
            "test_blind": True,
            "scope": "one representative practical route per integer family",
            "training": "exact integer solver in the loop",
            "purpose": (
                "measure the exact-integer SPO+/SFGE scalability boundary; "
                "not a performance comparison"
            ),
            "hard_tail_omissions": (
                "routes already exceeding the registered reference-solve "
                "preflight are not launched"
            ),
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "stage",
        choices=(
            "continuous-sentinels",
            "continuous-remaining",
            "local-continuous-skew",
            "integer-practical",
            "integer-exact-pilots",
        ),
        default="continuous-sentinels",
    )
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    if arguments.stage == "continuous-sentinels":
        payload = continuous_sentinels()
    elif arguments.stage == "continuous-remaining":
        payload = continuous_remaining()
    elif arguments.stage == "local-continuous-skew":
        payload = local_continuous_and_skew()
    elif arguments.stage == "integer-practical":
        payload = practical_integer_development()
    else:
        payload = exact_integer_runtime_pilots()
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.output, payload)
    print(f"wrote {len(payload['variants'])} variants to {arguments.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
