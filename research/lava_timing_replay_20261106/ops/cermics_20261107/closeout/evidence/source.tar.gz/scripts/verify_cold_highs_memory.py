"""Isolated actual-benchmark parity/memory probe; never a campaign receipt."""
import argparse
import hashlib
import json
import os
import time
from pathlib import Path

import numpy as np
import psutil
import torch
from pyepo.func import SPOPlus

from build_central_path_final import read, write
from run_central_path_final import load_job_data
from proximal_spo.canonical_baselines import ColdHighsOptModel
from proximal_spo.public_highs import HighsOptModel


class LegacyCold(HighsOptModel):
    def setObj(self,c):self._cost=np.asarray(c,dtype=np.float64).copy()
    def solve(self):
        self._model,self.x=self._getModel()
        super().setObj(self._cost)
        return super().solve()


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True)
    p.add_argument('--route',required=True);p.add_argument('--variant',choices=['legacy','fixed'],required=True)
    a=p.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1)
    os.environ['CENTRAL_PATH_FROZEN_DATA']=str(a.root/'frozen_data')
    os.environ['CENTRAL_PATH_FROZEN_DATA_READONLY']='1'
    job=next(j for j in read(a.root/'screen.json')['jobs'] if j['method']=='spo_plus' and j['route']==a.route and j['config']['sizes']['train']==800)
    loaded=load_job_data(job);problem=loaded.problem.continuous_relaxation()
    costs=loaded.dataset.train.physical_costs[:64];contexts=loaded.dataset.train.contexts[:64]
    labels=ColdHighsOptModel(problem);solutions=[];objectives=[]
    for cost in costs:
        labels.setObj(cost);x,z=labels.solve();solutions.append(x);objectives.append(z)
    torch.manual_seed(91023)
    network=torch.nn.Linear(contexts.shape[1],costs.shape[1]);optimizer=torch.optim.SGD(network.parameters(),lr=.001)
    loss=SPOPlus((LegacyCold if a.variant=='legacy' else ColdHighsOptModel)(problem),processes=1,solve_ratio=1,reduction='mean',dataset=None)
    xx=torch.tensor(contexts,dtype=torch.float32);cc=torch.tensor(costs,dtype=torch.float32)
    ss=torch.tensor(np.asarray(solutions),dtype=torch.float32);zz=torch.tensor(objectives,dtype=torch.float32)[:,None]
    samples=[];digest=hashlib.sha256();process=psutil.Process();started=time.monotonic()
    for step in range(101):
        if step%10==0:samples.append({'step':step,'rss_mib':process.memory_info().rss/2**20})
        if step==100:break
        start=(step%4)*16;idx=slice(start,start+16);optimizer.zero_grad()
        value=loss(network(xx[idx]),cc[idx],ss[idx],zz[idx]);value.backward()
        digest.update(value.detach().numpy().tobytes())
        for parameter in network.parameters():digest.update(parameter.grad.numpy().tobytes())
        optimizer.step()
    weights=hashlib.sha256(b''.join(t.detach().numpy().tobytes() for t in network.parameters())).hexdigest()
    record={'variant':a.variant,'route':a.route,'source_job':job['id'],'full_training_size':800,'diagnostic_examples':64,
            'updates':100,'cold_training_solves':1600,'samples':samples,'wall_seconds':time.monotonic()-started,
            'loss_gradient_sha256':digest.hexdigest(),'weights_sha256':weights,'frozen_data':loaded.provenance['frozen_data'],
            'maximum_rss_growth_mib':max(x['rss_mib'] for x in samples)-samples[0]['rss_mib'],
            'late_rss_growth_mib':samples[-1]['rss_mib']-samples[2]['rss_mib'],'scientific_result':False}
    target=a.root/'spo_memory_preflight'/(a.route+'_'+a.variant+'.json');write(target,record);print(json.dumps(record))
