"""Cache only deterministic training or observed-validation preparation.

The cache identity contains the actual split arrays and problem, oracle kind,
structural seed and implementation. Train and validation entries are disjoint.
Test preparation is never read from or written to this cache.
"""
import hashlib
import json
import os
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
from proximal_spo.feasible_policies import _geometry_cache_key
from proximal_spo.objectives import PreparedSplit
from proximal_spo.oracles import OracleStats
from proximal_spo.policy_geometry_cache import entry_lock, load_entry, save_entry, sha_file
from physical128_data import array_hash


def prepare_cached(problem, oracle_kind, structural_seed, arrays, factory, update):
    directory = os.environ.get('CP_SPO_PREPARATION_CACHE')
    split = arrays['split']
    if not directory or split not in ('train','validation'):
        return factory()
    if not np.array_equal(arrays['physical_costs'], arrays['conditional_mean_costs']):
        raise ValueError('Preparation cache may only receive observed train/validation costs')
    root=Path(directory)
    code=Path(__file__).resolve().parents[1]
    identity={'schema':'observed-split-preparation-v1','split':split,
        'geometry':_geometry_cache_key(problem),'oracle':oracle_kind,'structural_seed':structural_seed,
        'arrays':{k:array_hash(v) for k,v in arrays.items() if k!='split'},
        'source':{p:sha_file(code/p) for p in
                  ('scripts/cached_preparation.py','src/proximal_spo/objectives.py',
                   'src/proximal_spo/oracles.py','src/proximal_spo/canonical_baselines.py')}}
    key=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()
    path=root/split/key
    started=time.perf_counter()
    with entry_lock(root,split+'-'+key):
        hit=path.exists()
        if not hit:
            prepared=factory()
            data=vars(prepared)
            save_entry(path,{k:v for k,v in data.items() if isinstance(v,np.ndarray)},
                {'identity':identity,'split':split,'preparation_stats':asdict(prepared.preparation_stats),
                 'none_fields':[k for k,v in data.items() if v is None]})
        saved=load_entry(path)
        if saved['metadata']['identity'] != identity:raise ValueError('Preparation cache identity mismatch')
        meta=saved['metadata']
        result=PreparedSplit(**saved['arrays'],**{k:None for k in meta['none_fields']},
            split=split,preparation_stats=OracleStats(**meta['preparation_stats']))
    receipt={'split':split,'key':key,'cache_hit':hit,'reference_solve_calls_this_fit':0 if hit else result.preparation_stats.calls,
        'wall_seconds':time.perf_counter()-started,'entry_manifest_sha256':saved['cache']['manifest_sha256'],
        'information_budget':'observed split only; no cross-split statistics'}
    if os.environ.get('CP_SPO_PREPARATION_LOG'):
        with Path(os.environ['CP_SPO_PREPARATION_LOG']).open('a') as f:f.write(json.dumps(receipt,sort_keys=True)+'\n')
    update('preprocessing',last_preparation_cache=receipt)
    return result
