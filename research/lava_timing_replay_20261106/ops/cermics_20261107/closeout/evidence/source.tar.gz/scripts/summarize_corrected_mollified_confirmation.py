"""Freeze the paired result of the corrected mollification confirmation."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any

from scipy.stats import t as student_t

from proximal_spo.artifacts import write_json

ROOT = Path(__file__).resolve().parents[1]
RUN_ROOT = ROOT / "runs" / "mollified_corrected" / "confirmation"
CAMPAIGN = ROOT / "configs" / "mollified_corrected" / "confirmation.json"
SELECTION = ROOT / "results" / "mollified_corrected" / "final_selection.json"
OLD_SUMMARY = ROOT / "results" / "pyepo_small_tau" / "confirmation_summary.json"
OUTPUT = ROOT / "results" / "mollified_corrected" / "confirmation.json"
MARKDOWN = ROOT / "results" / "mollified_corrected" / "confirmation.md"
SEEDS = set(range(11, 21))
BASELINES = ("mse", "wise", "spo_plus", "anchored_proximal", "proximal")


def _object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected an object at {path}")
    return value


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _interval(values: list[float]) -> tuple[float, float, float]:
    mean = sum(values) / len(values)
    variance = sum((value - mean) ** 2 for value in values) / (len(values) - 1)
    standard_error = math.sqrt(variance / len(values))
    radius = float(student_t.ppf(0.975, len(values) - 1)) * standard_error
    return standard_error, mean - radius, mean + radius


def _paired(
    method: dict[int, float], baseline: dict[int, float], label: str
) -> dict[str, Any]:
    differences = [method[seed] - baseline[seed] for seed in sorted(SEEDS)]
    ordered = sorted(differences)
    standard_error, lower, upper = _interval(differences)
    return {
        "baseline": label,
        "mean_difference": sum(differences) / len(differences),
        "median_difference": (ordered[4] + ordered[5]) / 2.0,
        "standard_error": standard_error,
        "student_t_95_interval": [lower, upper],
        "wins": sum(value < 0.0 for value in differences),
        "ties": sum(value == 0.0 for value in differences),
    }


def summarize() -> dict[str, Any]:
    campaign = _object(CAMPAIGN)
    selection = _object(SELECTION)
    design = campaign["design"]
    if design["frozen_selection_sha256"] != _sha256(SELECTION):
        raise ValueError("frozen selection changed after confirmation was configured")
    if design["development_source_sha256"] != selection["development_source_sha256"]:
        raise ValueError("confirmation and selected source digests differ")
    if set(design["confirmation_seeds"]) != SEEDS:
        raise ValueError("confirmation seed cohort changed")

    expected_arm = selection["selected_arm"]
    source = str(selection["development_source_sha256"])
    rows: list[dict[str, Any]] = []
    for directory in sorted(path for path in RUN_ROOT.iterdir() if path.is_dir()):
        required = [
            directory / "status.json",
            directory / "config.json",
            directory / "environment.json",
            directory / "summary.json",
            directory / "embedded_mse_base.json",
        ]
        if not all(path.is_file() for path in required):
            continue
        status, config, environment, result, base = map(_object, required)
        if config.get("method") != "mollified_anchored_proximal":
            continue
        if environment.get("source_sha256") != source:
            continue
        if status.get("status") != "complete":
            raise ValueError(f"unfinished confirmation run: {directory}")
        for field in ("method", "method_parameters", "model", "training"):
            if config.get(field) != expected_arm.get(field):
                raise ValueError(f"confirmation changed selected field {field}")
        seed = int(config["seeds"]["data"])
        rows.append(
            {
                "data_seed": seed,
                "test_regret": float(result["test"]["mean_regret"]),
                "mse_test_regret": float(base["test"]["mean_regret"]),
                "paired_mse_difference": float(result["test"]["mean_regret"])
                - float(base["test"]["mean_regret"]),
                "validation_regret": float(result["best_validation"]["mean_regret"]),
                "best_epoch": int(result["best_epoch"]),
                "whole_pipeline_wall_seconds": float(
                    result["whole_pipeline_training_wall_seconds"]
                ),
                "training_oracle_calls": int(
                    result["total_training_oracle_stats"]["calls"]
                ),
                "mse_parameter_sha256": str(base["parameter_sha256"]),
                "run_directory": str(directory.relative_to(ROOT)),
            }
        )
    rows.sort(key=lambda row: int(row["data_seed"]))
    if len(rows) != len(SEEDS) or {row["data_seed"] for row in rows} != SEEDS:
        raise ValueError("confirmation does not contain exactly one run per seed")

    old = _object(OLD_SUMMARY)
    baseline_rows = {
        label: {
            int(row["data_seed"]): float(row["test_mean_regret"])
            for row in old["rows"]
            if row["label"] == label
        }
        for label in BASELINES
    }
    if any(set(values) != SEEDS for values in baseline_rows.values()):
        raise ValueError("frozen baseline summary is incomplete")
    old_mse_digests = {
        int(row["data_seed"]): str(row["parameter_sha256"])
        for row in old["rows"]
        if row["label"] == "mse"
    }
    for row in rows:
        seed = int(row["data_seed"])
        if row["mse_parameter_sha256"] != old_mse_digests[seed]:
            raise ValueError(f"embedded MSE checkpoint differs for seed {seed}")
        if abs(row["mse_test_regret"] - baseline_rows["mse"][seed]) > 1e-12:
            raise ValueError(f"embedded MSE result differs for seed {seed}")

    method = {int(row["data_seed"]): float(row["test_regret"]) for row in rows}
    regrets = list(method.values())
    standard_error, lower, upper = _interval(regrets)
    return {
        "status": "complete",
        "method": "mollified_anchored_proximal",
        "selected_hyperparameters": expected_arm,
        "data_seeds": sorted(SEEDS),
        "mean_test_regret": sum(regrets) / len(regrets),
        "standard_error_test_regret": standard_error,
        "student_t_95_interval": [lower, upper],
        "mean_whole_pipeline_wall_seconds": sum(
            float(row["whole_pipeline_wall_seconds"]) for row in rows
        )
        / len(rows),
        "paired_comparisons": [
            _paired(method, baseline_rows[label], label) for label in BASELINES
        ],
        "rows": rows,
        "provenance": {
            "campaign": str(CAMPAIGN.relative_to(ROOT)),
            "campaign_sha256": _sha256(CAMPAIGN),
            "selection": str(SELECTION.relative_to(ROOT)),
            "selection_sha256": _sha256(SELECTION),
            "source_sha256": source,
            "frozen_baseline_summary": str(OLD_SUMMARY.relative_to(ROOT)),
            "frozen_baseline_summary_sha256": _sha256(OLD_SUMMARY),
            "confirmation_seed_status": design["confirmation_seed_status"],
            "raw_data_or_model_weights_persisted": False,
        },
    }


def _markdown(summary: dict[str, Any]) -> str:
    lines = [
        "# Corrected mollification confirmation",
        "",
        f"Mean test regret: **{summary['mean_test_regret']:.6f}** "
        f"(ten seeds; 95% t interval "
        f"[{summary['student_t_95_interval'][0]:.6f}, "
        f"{summary['student_t_95_interval'][1]:.6f}]).",
        "",
        "| baseline | baseline mean | paired delta | 95% paired interval | wins |",
        "|---|---:|---:|---:|---:|",
    ]
    for comparison in summary["paired_comparisons"]:
        label = comparison["baseline"]
        baseline = next(
            aggregate
            for aggregate in _object(OLD_SUMMARY)["aggregates"]
            if aggregate["label"] == label
        )
        interval = comparison["student_t_95_interval"]
        lines.append(
            f"| {label} | {baseline['mean_test_regret']:.6f} | "
            f"{comparison['mean_difference']:+.6f} | "
            f"[{interval[0]:+.6f}, {interval[1]:+.6f}] | "
            f"{comparison['wins']}/10 |"
        )
    lines.extend(
        [
            "",
            "Negative paired deltas favor corrected mollification. The confirmation "
            "cohort was reused under the user's explicit authorization, as recorded "
            "in the frozen campaign receipt.",
        ]
    )
    return "\n".join(lines) + "\n"


if __name__ == "__main__":
    result = summarize()
    write_json(OUTPUT, result)
    MARKDOWN.write_text(_markdown(result), encoding="utf-8")
    print(MARKDOWN)
