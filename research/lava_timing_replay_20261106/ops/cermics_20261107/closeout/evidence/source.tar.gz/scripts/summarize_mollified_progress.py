"""Emit a provisional, non-selecting progress receipt for mollified campaigns."""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected an object at {path}")
    return payload


def summarize(run_root: Path) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for directory in sorted(path for path in run_root.iterdir() if path.is_dir()):
        required = (
            directory / "status.json",
            directory / "config.json",
            directory / "summary.json",
            directory / "mollification_diagnostics.json",
        )
        if not all(path.is_file() for path in required):
            continue
        status, config, summary, diagnostics = map(_object, required)
        if status.get("status") != "complete":
            continue
        parameters = config["method_parameters"]
        training = config["training"]
        validation = summary["best_validation"]
        mechanism = diagnostics["validation"]
        rows.append(
            {
                "name": config["name"],
                "data_seed": config["seeds"]["data"],
                "sigma": parameters["sigma"],
                "tau": parameters["tau"],
                "learning_rate": training["learning_rate"],
                "training_samples": parameters["training_samples"],
                "validation_mean_regret": validation["mean_regret"],
                "deterministic_validation_mean_regret": mechanism[
                    "deterministic_mean_regret"
                ],
                "changed_mse_decision_rate": mechanism[
                    "changed_mse_decision_rate"
                ],
                "mse_wrong_to_corrected_rate": mechanism[
                    "mse_wrong_to_corrected_rate"
                ],
                "mse_correct_to_damaged_rate": mechanism[
                    "mse_correct_to_damaged_rate"
                ],
                "training_wall_seconds": summary[
                    "whole_pipeline_training_wall_seconds"
                ],
            }
        )
    grouped: dict[tuple[float, float, float, int], list[dict[str, Any]]] = (
        defaultdict(list)
    )
    for row in rows:
        key = (
            float(row["sigma"]),
            float(row["tau"]),
            float(row["learning_rate"]),
            int(row["training_samples"]),
        )
        grouped[key].append(row)
    arms: list[dict[str, Any]] = []
    for key, arm_rows in sorted(grouped.items()):
        values = [float(row["validation_mean_regret"]) for row in arm_rows]
        arms.append(
            {
                "sigma": key[0],
                "tau": key[1],
                "learning_rate": key[2],
                "training_samples": key[3],
                "completed_seed_count": len(arm_rows),
                "completed_data_seeds": sorted(
                    int(row["data_seed"]) for row in arm_rows
                ),
                "provisional_mean_validation_regret": sum(values) / len(values),
            }
        )
    return {
        "run_root": str(run_root),
        "completed_run_count": len(rows),
        "selection_permitted": False,
        "warning": (
            "provisional progress only; use summarize_mollified_development.py "
            "after every declared arm x seed cell completes"
        ),
        "arms": arms,
        "completed_rows": rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    write_json(arguments.output, summarize(arguments.run_root))


if __name__ == "__main__":
    main()
