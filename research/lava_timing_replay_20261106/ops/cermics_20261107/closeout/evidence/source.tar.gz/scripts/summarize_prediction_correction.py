#!/usr/bin/env python3
"""Summarize one source-consistent prediction-correction campaign."""

from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]

PAIR_ONLY_METHODS = (
    "restore_mu_learned_gauge",
    "learned_global_scale_gauge",
    "direct_contextual_scale_gauge",
    "learn_exact_ray_labels",
    "project_feature_mse_to_ray_gauge",
    "project_feature_mse_to_full_cone",
    "learn_exact_full_cone_labels",
)
DISPLAY_NAMES = {
    "raw_direction": "Raw decision direction",
    "restore_known_mu": "Restore known mu",
    "restore_mu_learned_gauge": "Known mu + learned gauge",
    "learned_global_scale_gauge": "Learned global scale + gauge",
    "direct_contextual_scale_gauge": "Contextual scale + gauge",
    "learn_exact_ray_labels": "Learn exact ray labels",
    "project_feature_mse_to_ray_gauge": "Feature MSE -> ray/gauge",
    "project_feature_mse_to_full_cone": "Feature MSE -> full cone",
    "learn_exact_full_cone_labels": "Learn exact full-cone labels",
    "oracle_conditional_ray_gauge": "Oracle conditional ray/gauge",
    "oracle_conditional_full_cone": "Oracle conditional full cone",
    "mse": "MSE",
    "wise": "WISE",
    "spo_plus": "SPO+",
    "soft_radial_log_barrier": "Base hard Soft-Radial",
}


def _load(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object in {path}")
    return payload


def _latest_progress(stage: str) -> tuple[Path, dict[str, Any]]:
    root = REPO_ROOT / "runs" / "prediction_correction" / stage
    candidates = list(root.glob("campaign_progress_*.json"))
    if not candidates:
        raise FileNotFoundError(f"no campaign progress receipt under {root}")
    path = max(candidates, key=lambda candidate: candidate.stat().st_mtime_ns)
    progress = _load(path)
    runs = progress.get("runs", [])
    if not isinstance(runs, list) or not runs:
        raise ValueError(f"campaign receipt {path} contains no runs")
    incomplete = [run for run in runs if run.get("status") != "complete"]
    if incomplete:
        names = [str(run.get("config")) for run in incomplete]
        raise ValueError(f"campaign is incomplete: {names}")
    return path, progress


def _aggregate(values: list[float]) -> dict[str, float | int]:
    if not values:
        raise ValueError("cannot aggregate an empty metric")
    n = len(values)
    average = mean(values)
    standard_deviation = stdev(values) if n > 1 else 0.0
    if n == 3:
        critical = 4.3026527297
    elif n > 1:
        critical = 1.96
    else:
        critical = 0.0
    half_width = critical * standard_deviation / math.sqrt(n)
    return {
        "n": n,
        "mean": average,
        "standard_deviation": standard_deviation,
        "descriptive_95_interval_lower": average - half_width,
        "descriptive_95_interval_upper": average + half_width,
    }


def _metric_table(
    rows: list[dict[str, Any]], key: str
) -> dict[str, dict[str, dict[str, float | int]]]:
    grouped: dict[tuple[str, str], list[float]] = defaultdict(list)
    for row in rows:
        value = row.get(key)
        if value is not None:
            grouped[(row["benchmark"], row["method"])].append(float(value))
    result: dict[str, dict[str, dict[str, float | int]]] = defaultdict(dict)
    for (benchmark, method), values in sorted(grouped.items()):
        result[benchmark][method] = _aggregate(values)
    return dict(result)


def _format(value: float) -> str:
    if abs(value) >= 100.0 or (0.0 < abs(value) < 1e-3):
        return f"{value:.3e}"
    return f"{value:.4f}"


def _markdown_table(
    title: str,
    table: dict[str, dict[str, dict[str, float | int]]],
    methods: tuple[str, ...],
) -> list[str]:
    benchmarks = sorted(table)
    lines = [f"## {title}", ""]
    benchmark_headers = " | ".join(
        benchmark.replace("cost.", "") for benchmark in benchmarks
    )
    lines.append(
        "| Method | " + benchmark_headers + " |"
    )
    lines.append("| --- | " + " | ".join("---:" for _ in benchmarks) + " |")
    for method in methods:
        cells: list[str] = []
        for benchmark in benchmarks:
            aggregate = table.get(benchmark, {}).get(method)
            cells.append(
                "--" if aggregate is None else _format(float(aggregate["mean"]))
            )
        label = DISPLAY_NAMES.get(method, method)
        lines.append(f"| {label} | " + " | ".join(cells) + " |")
    lines.append("")
    return lines


def summarize(stage: str) -> tuple[dict[str, Any], str]:
    progress_path, progress = _latest_progress(stage)
    rows: list[dict[str, Any]] = []
    selected_rows: list[dict[str, Any]] = []
    timing_rows: list[dict[str, Any]] = []
    method_timing_rows: list[dict[str, Any]] = []
    selected_timing_rows: list[dict[str, Any]] = []
    audit_rows: list[dict[str, Any]] = []
    source_hashes: set[str] = set()
    for receipt in progress["runs"]:
        source_hashes.add(str(receipt["source_sha256"]))
        config = receipt["expanded_config"]
        run_directory = REPO_ROOT / str(receipt["run_directory"])
        summary = _load(run_directory / "summary.json")
        benchmark = str(config["benchmark_id"])
        seed = int(config["seeds"]["data"])
        method = str(config["method"])
        diagnostics = _load(run_directory / "prediction_diagnostics.json")
        physical = diagnostics.get("physical_cost_prediction")
        if isinstance(physical, dict) and method != "soft_radial_log_barrier":
            rows.append(
                {
                    "benchmark": benchmark,
                    "seed": seed,
                    "method": method,
                    "conditional_mse": physical["conditional_mse_per_coordinate"],
                    "scenario_mse": physical["scenario_mse_per_coordinate"],
                    "regret": summary["test"]["mean_regret"],
                    "base_training_wall_seconds": summary[
                        "training_wall_seconds"
                    ],
                }
            )
        if method != "soft_radial_log_barrier":
            continue
        correction = _load(run_directory / "prediction_correction.json")
        rows.append(
            {
                "benchmark": benchmark,
                "seed": seed,
                "method": "soft_radial_log_barrier",
                "conditional_mse": None,
                "scenario_mse": None,
                "regret": correction["base_decision_test_mean_regret"],
                "base_training_wall_seconds": summary["training_wall_seconds"],
            }
        )
        methods = correction["methods"]
        selected_receipts = correction["fit_receipt"]["selected_methods"]
        for correction_name, receipt_details in selected_receipts.items():
            method_timing_rows.append(
                {
                    "benchmark": benchmark,
                    "seed": seed,
                    "method": correction_name,
                    "all_candidate_wall_seconds": receipt_details[
                        "all_candidate_fit_and_prediction_wall_seconds"
                    ],
                    "selected_candidate_wall_seconds": receipt_details[
                        "selected_candidate_fit_and_prediction_wall_seconds"
                    ],
                }
            )
        for correction_name, details in methods.items():
            rows.append(
                {
                    "benchmark": benchmark,
                    "seed": seed,
                    "method": correction_name,
                    "conditional_mse": details["prediction"][
                        "conditional_mse_per_coordinate"
                    ],
                    "scenario_mse": details["prediction"][
                        "scenario_mse_per_coordinate"
                    ],
                    "regret": correction["base_decision_test_mean_regret"],
                }
            )
            audit = details.get("decision_invariance_audit")
            if isinstance(audit, dict):
                audit_rows.append(
                    {
                        "benchmark": benchmark,
                        "seed": seed,
                        "method": correction_name,
                        "match_rate": audit["base_decision_match_rate"],
                        "maximum_distance": audit["maximum_decision_distance"],
                    }
                )
        selectable = [
            (name, methods[name])
            for name in PAIR_ONLY_METHODS
            if name in methods
            and methods[name]["validation_scenario_mse_per_coordinate"] is not None
        ]
        selected_name, selected = min(
            selectable,
            key=lambda item: (
                float(item[1]["validation_scenario_mse_per_coordinate"]),
                item[0],
            ),
        )
        selected_rows.append(
            {
                "benchmark": benchmark,
                "seed": seed,
                "selected_method": selected_name,
                "conditional_mse": selected["prediction"][
                    "conditional_mse_per_coordinate"
                ],
                "validation_scenario_mse": selected[
                    "validation_scenario_mse_per_coordinate"
                ],
            }
        )
        correction_timing = correction["timing"]
        feature_preparation = sum(
            float(
                correction_timing["frozen_base_feature_evaluation_wall_seconds"]
                [split]
            )
            for split in ("train", "validation")
        )
        selected_receipt = selected_receipts[selected_name]
        is_full_cone = "full_cone" in selected_name
        base_decision_preparation = (
            sum(
                float(correction_timing["base_decision_solve_wall_seconds"][split])
                for split in ("train", "validation")
            )
            if is_full_cone
            else 0.0
        )
        label_projection = (
            float(
                correction["fit_receipt"]["timing"][
                    "training_label_projection_wall_seconds"
                ]
            )
            if selected_name == "learn_exact_full_cone_labels"
            else 0.0
        )
        selected_timing_rows.append(
            {
                "benchmark": benchmark,
                "seed": seed,
                "method": selected_name,
                "fixed_ridge_wall_seconds": (
                    feature_preparation
                    + base_decision_preparation
                    + label_projection
                    + float(
                        selected_receipt[
                            "selected_candidate_fit_and_prediction_wall_seconds"
                        ]
                    )
                ),
                "full_ridge_grid_wall_seconds": (
                    feature_preparation
                    + base_decision_preparation
                    + label_projection
                    + float(
                        selected_receipt[
                            "all_candidate_fit_and_prediction_wall_seconds"
                        ]
                    )
                ),
                "training_base_decision_calls": (
                    sum(
                        int(
                            correction["base_decision_oracle_stats_by_split"][split][
                                "calls"
                            ]
                        )
                        for split in ("train", "validation")
                    )
                    if is_full_cone
                    else 0
                ),
            }
        )
        timing = correction["timing"]
        timing_rows.append(
            {
                "benchmark": benchmark,
                "seed": seed,
                "base_training_wall_seconds": summary["training_wall_seconds"],
                "correction_training_wall_seconds": timing[
                    "incremental_pair_only_training_wall_seconds"
                ],
                "whole_pipeline_training_wall_seconds": summary[
                    "whole_pipeline_training_wall_seconds"
                ],
                "audit_wall_seconds_excluded": timing[
                    "decision_invariance_audit_wall_seconds"
                ],
                "correction_training_oracle_calls": sum(
                    int(correction["base_decision_oracle_stats_by_split"][split]["calls"])
                    for split in ("train", "validation")
                ),
            }
        )
    if len(source_hashes) != 1:
        raise ValueError(f"campaign mixes source hashes: {sorted(source_hashes)}")

    regret = _metric_table(rows, "regret")
    prediction = _metric_table(rows, "conditional_mse")
    scenario_prediction = _metric_table(rows, "scenario_mse")
    base_training_time = _metric_table(rows, "base_training_wall_seconds")
    selected_by_benchmark: dict[str, dict[str, Any]] = {}
    for benchmark in sorted({row["benchmark"] for row in selected_rows}):
        subset = [row for row in selected_rows if row["benchmark"] == benchmark]
        selected_by_benchmark[benchmark] = {
            "conditional_mse": _aggregate(
                [float(row["conditional_mse"]) for row in subset]
            ),
            "selected_methods_by_seed": {
                str(row["seed"]): row["selected_method"] for row in subset
            },
        }
    timing_by_benchmark: dict[str, dict[str, Any]] = {}
    for benchmark in sorted({row["benchmark"] for row in timing_rows}):
        subset = [row for row in timing_rows if row["benchmark"] == benchmark]
        timing_by_benchmark[benchmark] = {
            key: _aggregate([float(row[key]) for row in subset])
            for key in (
                "base_training_wall_seconds",
                "correction_training_wall_seconds",
                "whole_pipeline_training_wall_seconds",
                "audit_wall_seconds_excluded",
                "correction_training_oracle_calls",
            )
        }
    per_method_timing = _metric_table(
        method_timing_rows, "all_candidate_wall_seconds"
    )
    selected_timing_by_benchmark: dict[str, dict[str, Any]] = {}
    for benchmark in sorted({row["benchmark"] for row in selected_timing_rows}):
        subset = [
            row for row in selected_timing_rows if row["benchmark"] == benchmark
        ]
        selected_timing_by_benchmark[benchmark] = {
            "fixed_ridge_wall_seconds": _aggregate(
                [float(row["fixed_ridge_wall_seconds"]) for row in subset]
            ),
            "full_ridge_grid_wall_seconds": _aggregate(
                [float(row["full_ridge_grid_wall_seconds"]) for row in subset]
            ),
            "training_base_decision_calls": _aggregate(
                [float(row["training_base_decision_calls"]) for row in subset]
            ),
        }
    audit_failures = [
        row
        for row in audit_rows
        if float(row["match_rate"]) < 1.0
        or float(row["maximum_distance"]) > 1e-7
    ]
    result = {
        "status": stage,
        "scientific_status": (
            "implementation validation" if stage == "smoke" else "development"
        ),
        "source_sha256": next(iter(source_hashes)),
        "campaign_progress": str(progress_path.relative_to(REPO_ROOT)),
        "supervision": "ordinary context-scenario pairs only",
        "selection": (
            "ridge and correction family selected using validation scenario MSE; "
            "test conditional means used for evaluation only"
        ),
        "deployment": (
            "the uncorrected base cost chooses the decision; the correction is a "
            "post-decision prediction/interpretability sidecar"
        ),
        "regret": regret,
        "conditional_prediction_mse": prediction,
        "scenario_prediction_mse": scenario_prediction,
        "base_method_training_wall_seconds": base_training_time,
        "validation_selected_pair_only": selected_by_benchmark,
        "timing": timing_by_benchmark,
        "per_method_ridge_search_fit_and_prediction_wall_seconds": (
            per_method_timing
        ),
        "validation_selected_method_estimated_standalone_cost": (
            selected_timing_by_benchmark
        ),
        "decision_invariance_audit": {
            "rows": audit_rows,
            "failure_count": len(audit_failures),
            "failures": audit_failures,
            "excluded_from_training_and_deployment_cost": True,
        },
        "raw_predictions_persisted": False,
    }

    benchmark_keys = tuple(sorted(regret))
    regret_methods = (
        "soft_radial_log_barrier",
        "mse",
        "wise",
        "spo_plus",
    )
    prediction_methods = (
        "raw_direction",
        "restore_known_mu",
        *PAIR_ONLY_METHODS,
        "mse",
        "wise",
        "spo_plus",
        "oracle_conditional_ray_gauge",
        "oracle_conditional_full_cone",
    )
    lines = [
        f"# Prediction correction — {stage}",
        "",
        "The corrected cost is a post-decision explanatory sidecar. The original "
        "hard Soft-Radial direction remains the deployed optimizer input, so every "
        "correction has exactly the base method's decision regret by construction.",
        "",
        "All learned corrections use context-scenario pairs only. Ridge and method "
        "selection use validation scenario MSE; conditional means are test-only "
        "diagnostics. Solver replay is a bounded invariance audit and is excluded "
        "from training and deployment time.",
        "",
    ]
    lines.extend(_markdown_table("Decision regret", regret, regret_methods))
    lines.extend(
        _markdown_table(
            "Base-method training wall seconds", base_training_time, regret_methods
        )
    )
    lines.extend(
        _markdown_table(
            "Conditional cost MSE per coordinate", prediction, prediction_methods
        )
    )
    lines.extend(["## Validation-selected pair-only correction", ""])
    lines.append("| Benchmark | Test conditional MSE | Selected method(s) by seed |")
    lines.append("| --- | ---: | --- |")
    for benchmark in benchmark_keys:
        entry = selected_by_benchmark[benchmark]
        methods = ", ".join(
            f"{seed}: {DISPLAY_NAMES.get(name, name)}"
            for seed, name in sorted(entry["selected_methods_by_seed"].items())
        )
        lines.append(
            f"| {benchmark.replace('cost.', '')} | "
            f"{_format(float(entry['conditional_mse']['mean']))} | {methods} |"
        )
    lines.extend(["", "## Incremental training cost", ""])
    lines.append(
        "| Benchmark | Base training (s) | Correction suite (s) | "
        "Full pipeline (s) | Correction oracle calls |"
    )
    lines.append("| --- | ---: | ---: | ---: | ---: |")
    for benchmark in benchmark_keys:
        entry = timing_by_benchmark[benchmark]
        lines.append(
            f"| {benchmark.replace('cost.', '')} | "
            f"{_format(float(entry['base_training_wall_seconds']['mean']))} | "
            f"{_format(float(entry['correction_training_wall_seconds']['mean']))} | "
            f"{_format(float(entry['whole_pipeline_training_wall_seconds']['mean']))} "
            "| "
            f"{float(entry['correction_training_oracle_calls']['mean']):.0f} |"
        )
    lines.extend(["", "## Selected correction's standalone cost", ""])
    lines.append(
        "This reconstructs the cost of fitting only the validation-selected "
        "correction family. The fixed-ridge column uses the selected ridge; the "
        "grid column includes the full four-value ridge search."
    )
    lines.append("")
    lines.append(
        "| Benchmark | Fixed ridge (s) | Four-ridge grid (s) | "
        "Additional training decision solves |"
    )
    lines.append("| --- | ---: | ---: | ---: |")
    for benchmark in benchmark_keys:
        entry = selected_timing_by_benchmark[benchmark]
        lines.append(
            f"| {benchmark.replace('cost.', '')} | "
            f"{_format(float(entry['fixed_ridge_wall_seconds']['mean']))} | "
            f"{_format(float(entry['full_ridge_grid_wall_seconds']['mean']))} | "
            f"{float(entry['training_base_decision_calls']['mean']):.0f} |"
        )
    lines.extend(["", "## Per-method correction search time", ""])
    lines.append(
        "This is the complete ridge-grid fitting and train/validation/test "
        "prediction time for each branch. Shared frozen-feature extraction and "
        "base-decision preprocessing are reported only in the suite total above."
    )
    lines.append("")
    lines.extend(
        _markdown_table(
            "Per-method ridge-grid wall seconds",
            per_method_timing,
            PAIR_ONLY_METHODS,
        )
    )
    lines.extend(
        [
            "",
            f"Decision-invariance audit failures: **{len(audit_failures)}**.",
            "",
            "Intervals in the JSON artifact are descriptive. These are development "
            "results, not untouched confirmation evidence."
            if stage == "development"
            else (
                "Smoke results validate execution only; they are not scientific "
                "evidence."
            ),
            "",
        ]
    )
    return result, "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("smoke", "development"))
    args = parser.parse_args()
    result, markdown = summarize(args.stage)
    output = REPO_ROOT / "results" / "prediction_correction"
    output.mkdir(parents=True, exist_ok=True)
    json_path = output / f"{args.stage}_summary.json"
    markdown_path = output / f"{args.stage}_summary.md"
    json_path.write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    markdown_path.write_text(markdown, encoding="utf-8")
    print(json_path)
    print(markdown_path)


if __name__ == "__main__":
    main()
