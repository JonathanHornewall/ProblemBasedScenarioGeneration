"""Build the paired final-epoch raw-regret refinement for analytic skew."""

from __future__ import annotations

import argparse
from pathlib import Path

from proximal_spo.artifacts import write_json
from proximal_spo.frozen_skew_protocol import (
    build_frozen_skew_refinement_campaign,
    completed_frozen_skew_development_rows,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", action="append", type=Path, required=True)
    parser.add_argument("--source-sha256", action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--campaign-run-root", required=True)
    parser.add_argument("--top-k", type=int, default=3)
    arguments = parser.parse_args()
    rows = completed_frozen_skew_development_rows(
        arguments.run_root,
        required_source_sha256=arguments.source_sha256,
    )
    campaign = build_frozen_skew_refinement_campaign(
        rows,
        run_root=arguments.campaign_run_root,
        top_k=arguments.top_k,
    )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.output, campaign)
    print(f"wrote {len(campaign['variants'])} frozen-skew refinement runs")


if __name__ == "__main__":
    main()
