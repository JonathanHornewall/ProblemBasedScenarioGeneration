# ruff: noqa: E501
"""Package only new fits, charging them against the original USD 50 campaign cap."""

import argparse
import datetime as dt
import hashlib
import json
import subprocess
import tarfile
import time
from pathlib import Path

from build_central_path_final import read, write

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/central_path_extension_20260923"
DEST = RUN / "hornewall"
RUN_ID = "central-path-extension-20260923"
BUCKET = "hornewall-central-path-extension-20260923"


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--original-root", type=Path, required=True)
    a = p.parse_args()
    original = a.original_root.resolve() / "runs/central_path_final_20260922"
    staging = original / "staging"
    prior_cost = read(original / "hornewall/budget.json")["completion"][
        "conservative_total_upper_usd"
    ]
    preflight = read(RUN / "preflight/preflight.json")
    assert preflight["passed"] and len(preflight["fits"]) == 34
    assert not read(RUN / "preservation_audit.json")["mismatches"]
    assert (
        read(
            RUN / "preflight_nce_replay_v2/receipts/preflight_nce_previous_failure.json"
        )["status"]
        == "complete"
    )
    resources = read(DEST / "resource_preflight.json")
    for key in (
        "instances",
        "disks",
        "addresses",
        "snapshots",
        "reservations",
        "forwarding-rules",
        "routers",
        "images",
        "buckets",
    ):
        assert resources[key] == {"returncode": 0, "data": []}, key
    billing = read(DEST / "billing_preflight.json")
    assert time.time() - billing["verified_unix"] < 3600
    assert (
        time.time() - dt.datetime.fromisoformat(resources["checked_utc"]).timestamp()
        < 3600
    )
    previous = read(DEST / "budget.json") if (DEST / "budget.json").exists() else {}
    hours = 6.3
    deadline = previous.get("deadline_unix", int(time.time() + hours * 3600))
    incremental = ((3.2 + 100 * 0.000136986 + 0.005) * hours + 3) * 1.1
    budget = {
        "run_id": RUN_ID,
        "bucket": BUCKET,
        "instance": RUN_ID + "-0",
        "zone": "us-east1-b",
        "project": "hornewall-compute",
        "configuration": "jonathan",
        "approved_maximum_usd": 50,
        "prior_conservative_upper_usd": prior_cost,
        "remaining_campaign_budget_usd": 50 - prior_cost,
        "maximum_vm_hours": hours,
        "deadline_unix": deadline,
        "termination_time": dt.datetime.fromtimestamp(deadline, dt.UTC).isoformat(),
        "machine_type": "n2-standard-64",
        "vcpu": 64,
        "memory_gib": 256,
        "maximum_concurrency": 64,
        "boot_disk_gib": 100,
        "quoted_compute_usd_hour": 3.107776,
        "compute_usd_hour": 3.2,
        "disk_usd_hour": 100 * 0.000136986,
        "ipv4_usd_hour": 0.005,
        "storage_and_network_reserve_usd": 3,
        "uncertainty_margin": 0.1,
        "conservative_incremental_commitment_usd": incremental,
        "conservative_commitment_usd": prior_cost + incremental,
        "billing": billing,
        "project_active_unposted_resources": [],
        "launch_authorization": "User authorized Hornewall experiments with complete authority under USD 50; this extension retains that cumulative cap and all completed outputs.",
        "billing_inventory_limitation": "The previously documented inaccessible linked project remains outside verified resource inventory; original explicit authorization under the campaign cap applies.",
    }
    assert budget["conservative_commitment_usd"] < 50
    write(DEST / "budget.json", budget)
    subprocess.run(
        ["git", "diff", "--exit-code", "HEAD"],
        cwd=ROOT,
        check=True,
        stdout=subprocess.DEVNULL,
    )
    subprocess.run(
        [
            "git",
            "archive",
            "--format=tar.gz",
            "--prefix=code/",
            "-o",
            str(DEST / "code.tar.gz"),
            "HEAD",
        ],
        cwd=ROOT,
        check=True,
    )
    frozen = read(staging / "source_receipt.json")
    files = {
        "code.tar.gz": DEST / "code.tar.gz",
        "screen.json": RUN / "screen.json",
        "preflight.json": RUN / "preflight/preflight.json",
        "preservation_audit.json": RUN / "preservation_audit.json",
        **{
            n: staging / n
            for n in ("external.tar.gz", "public.tar.gz", "requirements.lock")
        },
    }
    for name in ("external.tar.gz", "public.tar.gz", "requirements.lock"):
        assert (
            hashlib.sha256(files[name].read_bytes()).hexdigest()
            == frozen["files"][name]
        )
    receipt = {
        "project_commit": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip(),
        "base_project_commit": "22e35c168d764364110c9c47503c4e420958a7ec",
        "external_commit": frozen["external_commit"],
        "public_commit": frozen["public_commit"],
        "python": "3.13.5",
        "change": "Independent fixed-grid baseline and pure-LP policy extension",
        "files": {
            n: hashlib.sha256(f.read_bytes()).hexdigest() for n, f in files.items()
        },
    }
    write(DEST / "source_receipt.json", receipt)
    # Successful deterministic geometry may be reused by its original content
    # key. No fitted model, score, failed cache entry, or selector is imported.
    geometry_files = {}
    origin_cache = original / "hornewall/migration/geometry_cache"
    seed_receipt = {}
    for path in sorted(origin_cache.glob("*.json")):
        meta = read(path)
        data = path.with_suffix(".pickle")
        if meta.get("status") != "complete" or not data.exists():
            continue
        seed_receipt[path.stem] = {
            "metadata_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "pickle_sha256": hashlib.sha256(data.read_bytes()).hexdigest(),
            "pickle_bytes": data.stat().st_size,
        }
        copied_meta = DEST / "geometry_seed" / path.name
        write(
            copied_meta,
            {
                **meta,
                "serialized_bytes": data.stat().st_size,
                "origin": "completed campaign deterministic geometry cache",
            },
        )
        geometry_files["geometry_cache/" + path.name] = copied_meta
        geometry_files["geometry_cache/" + data.name] = data
    write(DEST / "geometry_seed_receipt.json", seed_receipt)
    source = DEST / "source.tar.gz"
    with tarfile.open(source, "w:gz", compresslevel=1) as archive:
        for name, path in {
            **files,
            **geometry_files,
            "geometry_seed_receipt.json": DEST / "geometry_seed_receipt.json",
            "budget.json": DEST / "budget.json",
            "source_receipt.json": DEST / "source_receipt.json",
        }.items():
            archive.add(path, arcname=name)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    args = f"--root /opt/central-path --bucket {BUCKET} --run-id {RUN_ID} --deadline-unix {deadline}"
    supervisor = (ROOT / "scripts/central_path_cloud_vm.py").read_text()
    api = (ROOT / "scripts/atlanta_timing_vm.py").read_text()
    startup = f"""#!/bin/bash
set -euo pipefail
mkdir -p /opt/central-path/results /opt/cp-supervisor
exec > >(tee -a /opt/central-path/bootstrap.log) 2>&1
cat > /opt/cp-supervisor/atlanta_timing_vm.py <<'CP_API'
{api}
CP_API
cat > /opt/cp-supervisor/central_path_cloud_vm.py <<'CP_SUPERVISOR'
{supervisor}
CP_SUPERVISOR
cleanup_failure() {{ python3 /opt/cp-supervisor/central_path_cloud_vm.py {args} --failure-only; }}
trap cleanup_failure ERR
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3 curl git ca-certificates
python3 - <<'CP_DOWNLOAD'
import hashlib,json,tarfile,urllib.request
from pathlib import Path
req=urllib.request.Request('http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token',headers={{'Metadata-Flavor':'Google'}})
token=json.loads(urllib.request.urlopen(req,timeout=15).read())['access_token']
req=urllib.request.Request('https://storage.googleapis.com/{BUCKET}/source.tar.gz',headers={{'Authorization':'Bearer '+token}})
data=urllib.request.urlopen(req,timeout=300).read()
assert hashlib.sha256(data).hexdigest()=='{digest}'
path=Path('/opt/source.tar.gz'); path.write_bytes(data)
with tarfile.open(path) as tar: tar.extractall('/opt/central-path')
root=Path('/opt/central-path')
for name in ('code','external','public'):
 destination=root if name=='code' else root/name
 destination.mkdir(exist_ok=True)
 with tarfile.open(root/(name+'.tar.gz')) as tar: tar.extractall(destination)
CP_DOWNLOAD
bash /opt/central-path/code/scripts/bootstrap_central_path_final.sh /opt/central-path
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONUNBUFFERED=1
export PYTHONPATH=/opt/central-path/code/src:/opt/central-path/external/src
export SOLVER_FREE_DFL_REPO=/opt/central-path/public DFL_EXTENSIONS_SRC=/opt/central-path/external/src
export ATLANTA_SOURCE_MANIFEST=/opt/central-path/source_receipt.json
/opt/central-path/venv/bin/python /opt/central-path/code/scripts/check_central_path_extension.py --manifest /opt/central-path/screen.json --output-root /opt/central-path/results/cloud_preflight --workers 16 --cloud
trap - ERR
exec /opt/central-path/venv/bin/python /opt/cp-supervisor/central_path_cloud_vm.py {args}
"""
    (DEST / "startup.sh").write_text(startup)
    write(
        DEST / "launch.json",
        {
            "budget": budget,
            "source_sha256": digest,
            "source_bytes": source.stat().st_size,
        },
    )
    write(
        DEST / "lifecycle.json",
        {"rule": [{"action": {"type": "Delete"}, "condition": {"age": 7}}]},
    )
    print(
        json.dumps(
            {
                "source_bytes": source.stat().st_size,
                "incremental_upper_usd": incremental,
                "cumulative_upper_usd": prior_cost + incremental,
                "deadline": budget["termination_time"],
            }
        )
    )


if __name__ == "__main__":
    main()
