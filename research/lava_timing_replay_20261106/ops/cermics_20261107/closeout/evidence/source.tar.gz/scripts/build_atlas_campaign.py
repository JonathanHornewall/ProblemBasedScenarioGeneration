"""Build deterministic, validation-only single-stage Atlas campaign waves.

The generated JSON is consumed by ``scripts/run_campaign.py``.  Keeping the
factorized screens here avoids opaque hand-edited Cartesian products while
retaining every expanded RunSpec in the campaign progress receipt.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]

PATH_BENCHMARKS = (
    ("directional", "directional_random_cost_grid_additive_gaussian", 1600, 200, 1000),
    ("dys10", "dys_shortest_path_10x10", 800, 200, 1000),
    ("cave6", "cave_sp5_degree_6", 1000, 1000, 1000),
)

ALL_PATH_BENCHMARKS = (
    *(
        (
            f"wise{degree}",
            f"wise_shortest_path_5x5_degree_{degree}",
            1600,
            1000,
            1000,
            903,
            "wise",
        )
        for degree in (1, 2, 4, 6, 8)
    ),
    (
        "lava_sp5",
        "lava_shortest_path_5x5_released_code",
        1000,
        200,
        1000,
        1103,
        "lava_path",
    ),
    *(
        (f"dys{size}", f"dys_shortest_path_{size}x{size}", 800, 200, 1000, 1103, "dys")
        for size in (5, 10, 15, 20, 25)
    ),
    (
        "directional_planted_uniform",
        "directional_planted_path_multiplicative_uniform",
        1600,
        200,
        1000,
        1103,
        "directional",
    ),
    (
        "directional_planted_gaussian",
        "directional_planted_path_additive_gaussian",
        1600,
        200,
        1000,
        1103,
        "directional",
    ),
    (
        "directional_random_uniform",
        "directional_random_cost_grid_multiplicative_uniform",
        1600,
        200,
        1000,
        1103,
        "directional",
    ),
    (
        "directional_random_gaussian",
        "directional_random_cost_grid_additive_gaussian",
        1600,
        200,
        1000,
        1103,
        "directional",
    ),
    ("cave4", "cave_sp5_degree_4", 1000, 1000, 1000, 1103, "cave"),
    ("cave6", "cave_sp5_degree_6", 1000, 1000, 1000, 1103, "cave"),
)

LAVA_LADDER_BENCHMARKS = (
    ("lava50x50", "lava_random_lp_50x50_released_code"),
    ("lava100x25", "lava_random_lp_100x25_released_code"),
    ("lava100x50", "lava_random_lp_100x50_released_code"),
    ("lava150x50", "lava_random_lp_150x50_paper_appendix"),
    ("lava100x100", "lava_random_lp_100x100_released_code"),
    ("lava200x50", "lava_random_lp_200x50_released_code"),
    ("lava100x200", "lava_random_lp_100x200_released_code"),
    ("lava400x50", "lava_random_lp_400x50_released_code"),
)

PATH_CAPACITY_SENTINELS = {
    "wise8",
    "lava_sp5",
    "dys25",
    "directional_planted_uniform",
    "directional_random_gaussian",
    "cave6",
}

REFINEMENT_BENCHMARKS = (
    (
        "wise4",
        "wise_shortest_path_5x5_degree_4",
        1600,
        1000,
        1000,
        903,
        0.1,
        {"mse": 1e-3, "wise": 3e-4, "spo_plus": 3e-4},
    ),
    (
        "directional",
        "directional_random_cost_grid_additive_gaussian",
        1600,
        200,
        1000,
        1103,
        1.0,
        {"mse": 3e-3, "wise": 3e-3, "spo_plus": 3e-4},
    ),
    (
        "dys10",
        "dys_shortest_path_10x10",
        800,
        200,
        1000,
        1103,
        1.0,
        {"mse": 3e-4, "wise": 3e-3, "spo_plus": 3e-4},
    ),
    (
        "cave6",
        "cave_sp5_degree_6",
        1000,
        1000,
        1000,
        1103,
        1.0,
        {"mse": 3e-4, "wise": 1e-3, "spo_plus": 3e-4},
    ),
)


def _base() -> dict[str, Any]:
    return {
        "name": "placeholder",
        "benchmark_id": "placeholder",
        "benchmark_source": "dfl_extensions_lab",
        "conditional_reference_samples": 128,
        "cost_coordinate_normalization": "standardize",
        "evaluate_test": False,
        "method": "mse",
        "interface": "full",
        "workers": 2,
        "sizes": {"train": 800, "validation": 200, "test": 1000},
        "model": {
            "depth": 2,
            "width": 64,
            "activation": "silu",
            "layer_norm": False,
            "correction_depth": 1,
            "correction_width": 64,
            "dtype": "float32",
        },
        "training": {
            "epochs": 100,
            "batch_size": 128,
            "learning_rate": 0.001,
            "weight_decay": 1e-5,
            "optimizer": "adamw",
            "gradient_clip": 10.0,
            "validation_interval": 5,
            "patience": 20,
            "minimum_delta": 1e-8,
            "evaluation_batch_size": 1000,
            "torch_threads": 2,
            "selection_mode": "validation_regret",
        },
        "seeds": {
            "data": 1103,
            "structural": 101,
            "initialization": 201,
            "shuffle": 301,
            "perturbation": 401,
        },
        "method_parameters": {},
    }


def _barrier(family: str, alpha: float, *, scale: float = 1.0) -> dict[str, Any]:
    return {
        "contraction": family,
        "contraction_scale": scale,
        "minimum_scale": 0.01,
        "alpha_start": alpha,
        "alpha_end": alpha,
        "schedule": "fixed",
        "deployment_mode": "hard_recovered",
    }


def _energy(alpha: float) -> dict[str, Any]:
    return {
        "alpha_start": alpha,
        "alpha_end": alpha,
        "schedule": "fixed",
        "energy_guard": "uncapped",
        "training_root_tolerance": 1e-5,
        "evaluation_root_tolerance": 1e-8,
        "matrix_backend": "auto",
        "kernel_backend": "numpy",
        "deployment_mode": "hard_recovered",
    }


def _path_variants(
    prefix: str,
    benchmark_id: str,
    train: int,
    validation: int,
    test: int,
) -> list[dict[str, Any]]:
    common = {
        "benchmark_id": benchmark_id,
        "sizes": {"train": train, "validation": validation, "test": test},
    }
    rows: list[dict[str, Any]] = []

    def add(suffix: str, **updates: Any) -> None:
        rows.append({"name": f"{prefix}_{suffix}", **common, **updates})

    for method in ("mse", "wise", "spo_plus"):
        for tag, rate in (("lr3e4", 3e-4), ("lr1e3", 1e-3), ("lr3e3", 3e-3)):
            add(
                f"{method}_{tag}",
                method=method,
                training={"learning_rate": rate},
            )
    for tag, sigma in (("s01", 0.1), ("s03", 0.3), ("s1", 1.0)):
        add(
            f"sfge_{tag}",
            method="sfge",
            method_parameters={"sigma": sigma, "samples": 8},
        )
    add(
        "knn50",
        method="knn",
        method_parameters={"neighbors": 50, "distance_weighted": True},
    )
    add(
        "soft_radial",
        method="soft_radial_policy",
        method_parameters={
            "contraction": "rational",
            "contraction_scale": 1.0,
            "minimum_scale": 0.01,
        },
    )
    for family, alphas in (
        ("hyperbolic", (0.03, 0.1, 0.3, 1.0)),
        ("exponential", (0.03, 0.1, 0.3, 1.0)),
        ("rational", (1.0, 3.0, 10.0)),
    ):
        for alpha in alphas:
            tag = str(alpha).replace(".", "p")
            add(
                f"barrier_{family}_{tag}",
                method="soft_radial_log_barrier",
                method_parameters=_barrier(family, alpha),
            )
    for alpha in (0.1, 1.0, 3.0):
        tag = str(alpha).replace(".", "p")
        add(
            f"energy_{tag}",
            method="log_energy_policy",
            method_parameters=_energy(alpha),
        )
    return rows


def representative_paths() -> dict[str, Any]:
    variants: list[dict[str, Any]] = []
    for row in PATH_BENCHMARKS:
        variants.extend(_path_variants(*row))
    return {
        "name": "atlas_wave1_representative_paths_validation_screen",
        "run_root": "results/campaigns/atlas_wave1_representative_paths",
        "base": _base(),
        "variants": variants,
    }


def lava_screen() -> dict[str, Any]:
    prefix = "lava100x50"
    common = {
        "benchmark_id": "lava_random_lp_100x50_released_code",
        "sizes": {"train": 800, "validation": 200, "test": 1000},
    }
    rows: list[dict[str, Any]] = []

    def add(suffix: str, **updates: Any) -> None:
        rows.append({"name": f"{prefix}_{suffix}", **common, **updates})

    for method in ("mse", "wise", "spo_plus"):
        for tag, rate in (("lr3e4", 3e-4), ("lr1e3", 1e-3), ("lr3e3", 3e-3)):
            add(
                f"{method}_{tag}",
                method=method,
                training={"learning_rate": rate},
            )
    for tag, sigma in (("s01", 0.1), ("s03", 0.3), ("s1", 1.0)):
        add(
            f"sfge_{tag}",
            method="sfge",
            training={"epochs": 50, "patience": 10},
            method_parameters={"sigma": sigma, "samples": 4},
        )
    add(
        "knn50",
        method="knn",
        method_parameters={"neighbors": 50, "distance_weighted": True},
    )
    add(
        "soft_radial",
        method="soft_radial_policy",
        method_parameters={
            "contraction": "rational",
            "contraction_scale": 1.0,
            "minimum_scale": 0.01,
        },
    )
    for family, alphas in (
        ("hyperbolic", (0.03, 0.1, 0.3, 1.0, 3.0)),
        ("exponential", (0.1, 1.0)),
        ("rational", (1.0, 3.0, 10.0)),
    ):
        for alpha in alphas:
            tag = str(alpha).replace(".", "p")
            add(
                f"barrier_{family}_{tag}",
                method="soft_radial_log_barrier",
                method_parameters=_barrier(family, alpha),
            )
    for alpha in (0.1, 1.0, 3.0):
        tag = str(alpha).replace(".", "p")
        add(
            f"energy_{tag}",
            method="log_energy_policy",
            method_parameters=_energy(alpha),
        )
    return {
        "name": "atlas_wave2_lava100x50_validation_screen",
        "run_root": "results/campaigns/atlas_wave2_lava100x50",
        "base": _base(),
        "variants": rows,
    }


def refinement_paths() -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for benchmark in REFINEMENT_BENCHMARKS:
        (
            prefix,
            benchmark_id,
            train,
            validation,
            test,
            data_seed,
            center_alpha,
            baseline_rates,
        ) = benchmark
        common = {
            "benchmark_id": benchmark_id,
            "sizes": {"train": train, "validation": validation, "test": test},
            "seeds": {"data": data_seed},
        }

        def add(
            suffix: str,
            *,
            _prefix: str = prefix,
            _common: dict[str, Any] = common,
            **updates: Any,
        ) -> None:
            rows.append({"name": f"{_prefix}_refine_{suffix}", **_common, **updates})

        long_training = {"epochs": 200, "patience": 40}
        alpha_grid = sorted({0.03, 0.1, 0.3, 1.0, 3.0, center_alpha})
        for alpha in alpha_grid:
            tag = str(alpha).replace(".", "p")
            add(
                f"hyp_alpha_{tag}",
                method="soft_radial_log_barrier",
                training=long_training,
                method_parameters=_barrier("hyperbolic", alpha),
            )
        for tag, rate in (("lr3e4", 3e-4), ("lr3e3", 3e-3)):
            add(
                f"hyp_{tag}",
                method="soft_radial_log_barrier",
                training={**long_training, "learning_rate": rate},
                method_parameters=_barrier("hyperbolic", center_alpha),
            )
        for scale in (0.1, 0.3, 3.0, 10.0):
            tag = str(scale).replace(".", "p")
            add(
                f"hyp_scale_{tag}",
                method="soft_radial_log_barrier",
                training=long_training,
                method_parameters=_barrier("hyperbolic", center_alpha, scale=scale),
            )
        add(
            "exp_control",
            method="soft_radial_log_barrier",
            training=long_training,
            method_parameters=_barrier("exponential", center_alpha),
        )
        for width in (128, 256):
            add(
                f"hyp_width{width}",
                method="soft_radial_log_barrier",
                model={"depth": 3, "width": width},
                training=long_training,
                method_parameters=_barrier("hyperbolic", center_alpha),
            )
        for method in ("mse", "wise", "spo_plus"):
            rate = baseline_rates[method]
            add(
                f"{method}_width64",
                method=method,
                training={**long_training, "learning_rate": rate},
            )
            for width in (128, 256):
                add(
                    f"{method}_width{width}",
                    method=method,
                    model={"depth": 3, "width": width},
                    training={**long_training, "learning_rate": rate},
                )
    return {
        "name": "atlas_wave3_path_refinement_validation",
        "run_root": "results/campaigns/atlas_wave3_path_refinement",
        "base": _base(),
        "variants": rows,
    }


def _family_model(family: str, method: str) -> dict[str, Any]:
    """Transfer only architecture choices screened on a representative route."""

    widths = {
        "wise": {
            "soft_radial_log_barrier": (2, 64),
            "mse": (3, 128),
            "wise": (3, 256),
            "spo_plus": (2, 64),
        },
        "directional": {
            "soft_radial_log_barrier": (2, 64),
            "mse": (2, 64),
            "wise": (2, 64),
            "spo_plus": (2, 64),
        },
        "dys": {
            "soft_radial_log_barrier": (3, 256),
            "mse": (3, 256),
            "wise": (2, 64),
            "spo_plus": (3, 128),
        },
        "cave": {
            "soft_radial_log_barrier": (3, 256),
            "mse": (3, 256),
            "wise": (3, 128),
            "spo_plus": (2, 64),
        },
    }
    depth, width = widths.get(family, {}).get(method, (2, 64))
    return {"depth": depth, "width": width}


def broad_path_ladder() -> dict[str, Any]:
    """Factorized per-route tuning over every continuous path factory."""

    rows: list[dict[str, Any]] = []
    for (
        prefix,
        benchmark_id,
        train,
        validation,
        test,
        data_seed,
        family,
    ) in ALL_PATH_BENCHMARKS:
        common = {
            "benchmark_id": benchmark_id,
            "sizes": {"train": train, "validation": validation, "test": test},
            "seeds": {"data": data_seed},
        }

        def add(
            suffix: str,
            *,
            _prefix: str = prefix,
            _common: dict[str, Any] = common,
            **updates: Any,
        ) -> None:
            rows.append({"name": f"{_prefix}_broad_{suffix}", **_common, **updates})

        for method in ("mse", "wise", "spo_plus"):
            for tag, rate in (("lr3e4", 3e-4), ("lr1e3", 1e-3), ("lr3e3", 3e-3)):
                add(
                    f"{method}_{tag}",
                    method=method,
                    model=_family_model(family, method),
                    training={"epochs": 200, "patience": 40, "learning_rate": rate},
                )
        for epsilon in (0.1, 0.3, 1.0, 3.0):
            tag = str(epsilon).replace(".", "p")
            add(
                f"pfy_eps{tag}",
                method="perturbed_fy",
                training={"epochs": 150, "patience": 30},
                method_parameters={"epsilon": epsilon, "samples": 3},
            )
        for tag, rate in (("lr3e4", 3e-4), ("lr3e3", 3e-3)):
            add(
                f"pfy_eps1_{tag}",
                method="perturbed_fy",
                training={"epochs": 150, "patience": 30, "learning_rate": rate},
                method_parameters={"epsilon": 1.0, "samples": 3},
            )
        for tag, sigma in (("s01", 0.1), ("s03", 0.3), ("s1", 1.0)):
            add(
                f"sfge_{tag}",
                method="sfge",
                training={"epochs": 100, "patience": 20},
                method_parameters={"sigma": sigma, "samples": 8},
            )
        add(
            "knn50",
            method="knn",
            method_parameters={"neighbors": 50, "distance_weighted": True},
        )
        barrier_model = _family_model(family, "soft_radial_log_barrier")
        for alpha in (0.03, 0.1, 0.3, 1.0, 3.0):
            tag = str(alpha).replace(".", "p")
            add(
                f"barrier_hyp_alpha{tag}",
                method="soft_radial_log_barrier",
                model=barrier_model,
                training={"epochs": 200, "patience": 40},
                method_parameters=_barrier("hyperbolic", alpha),
            )
        for scale in (0.1, 0.3, 3.0):
            tag = str(scale).replace(".", "p")
            add(
                f"barrier_hyp_scale{tag}",
                method="soft_radial_log_barrier",
                model=barrier_model,
                training={"epochs": 200, "patience": 40},
                method_parameters=_barrier("hyperbolic", 1.0, scale=scale),
            )
        for tag, rate in (("lr3e4", 3e-4), ("lr3e3", 3e-3)):
            add(
                f"barrier_hyp_{tag}",
                method="soft_radial_log_barrier",
                model=barrier_model,
                training={"epochs": 200, "patience": 40, "learning_rate": rate},
                method_parameters=_barrier("hyperbolic", 1.0),
            )
        add(
            "rayen",
            method="rayen_policy",
            training={"epochs": 100, "patience": 20},
        )
        add(
            "soft_radial",
            method="soft_radial_policy",
            training={"epochs": 100, "patience": 20},
            method_parameters={
                "contraction": "rational",
                "contraction_scale": 1.0,
                "minimum_scale": 0.01,
            },
        )
        add(
            "log_energy",
            method="log_energy_policy",
            training={"epochs": 100, "patience": 20},
            method_parameters=_energy(1.0),
        )
    return {
        "name": "atlas_wave4_all_continuous_paths_validation",
        "run_root": "results/campaigns/atlas_wave4_all_paths",
        "base": _base(),
        "variants": rows,
    }


def lava_ladder_fast() -> dict[str, Any]:
    """Fast first pass over the generic-LP shape and scale ladder."""

    rows: list[dict[str, Any]] = []
    for prefix, benchmark_id in LAVA_LADDER_BENCHMARKS:
        common = {
            "benchmark_id": benchmark_id,
            "sizes": {"train": 800, "validation": 200, "test": 1000},
            # Three campaign processes times four persistent HiGHS workers use
            # twelve cores on the 14-core host.  The worker microprofile found
            # this materially faster than one or two workers while preserving
            # headroom for the desktop and result writer.
            "workers": 4,
        }

        def add(
            suffix: str,
            *,
            _prefix: str = prefix,
            _common: dict[str, Any] = common,
            **updates: Any,
        ) -> None:
            rows.append({"name": f"{_prefix}_fast_{suffix}", **_common, **updates})

        for method in ("mse", "wise", "spo_plus"):
            for tag, rate in (("lr3e4", 3e-4), ("lr1e3", 1e-3), ("lr3e3", 3e-3)):
                add(
                    f"{method}_{tag}",
                    method=method,
                    training={"learning_rate": rate},
                )
        add(
            "knn50",
            method="knn",
            method_parameters={"neighbors": 50, "distance_weighted": True},
        )
        for alpha in (0.03, 0.1, 0.3, 1.0, 3.0):
            tag = str(alpha).replace(".", "p")
            add(
                f"barrier_hyp_alpha{tag}",
                method="soft_radial_log_barrier",
                method_parameters=_barrier("hyperbolic", alpha),
            )
        for scale in (0.1, 0.3, 3.0):
            tag = str(scale).replace(".", "p")
            add(
                f"barrier_hyp_scale{tag}",
                method="soft_radial_log_barrier",
                method_parameters=_barrier("hyperbolic", 1.0, scale=scale),
            )
        add(
            "barrier_exp_control",
            method="soft_radial_log_barrier",
            method_parameters=_barrier("exponential", 1.0),
        )
        add(
            "log_energy",
            method="log_energy_policy",
            method_parameters=_energy(1.0),
        )
    return {
        "name": "atlas_wave5_lava_generic_lp_fast_validation",
        "run_root": "results/campaigns/atlas_wave5_lava_fast",
        "base": _base(),
        "variants": rows,
    }


def lava_barrier_refinement() -> dict[str, Any]:
    """Refine every dimension that hit the boundary of the fast LAVA grid."""

    rows: list[dict[str, Any]] = []
    for prefix, benchmark_id in LAVA_LADDER_BENCHMARKS:
        common = {
            "benchmark_id": benchmark_id,
            "sizes": {"train": 800, "validation": 200, "test": 1000},
            "workers": 4,
            "method": "soft_radial_log_barrier",
        }

        def add(
            suffix: str,
            *,
            _prefix: str = prefix,
            _common: dict[str, Any] = common,
            **updates: Any,
        ) -> None:
            rows.append({"name": f"{_prefix}_refine_{suffix}", **_common, **updates})

        long_training = {"epochs": 300, "patience": 60}
        for scale in (0.01, 0.03, 0.05, 0.1, 0.2):
            tag = str(scale).replace(".", "p")
            add(
                f"scale{tag}",
                training=long_training,
                method_parameters=_barrier("hyperbolic", 1.0, scale=scale),
            )
        for alpha in (0.003, 0.01, 0.03, 0.1, 0.3, 1.0, 3.0):
            tag = str(alpha).replace(".", "p")
            add(
                f"scale0p03_alpha{tag}",
                training=long_training,
                method_parameters=_barrier("hyperbolic", alpha, scale=0.03),
            )
        for tag, rate in (
            ("lr1e4", 1e-4),
            ("lr3e4", 3e-4),
            ("lr3e3", 3e-3),
        ):
            add(
                f"scale0p03_{tag}",
                training={**long_training, "learning_rate": rate},
                method_parameters=_barrier("hyperbolic", 1.0, scale=0.03),
            )
        for depth, width in ((3, 128), (3, 256), (3, 512)):
            add(
                f"scale0p03_width{width}",
                model={"depth": depth, "width": width},
                training=long_training,
                method_parameters=_barrier("hyperbolic", 1.0, scale=0.03),
            )
        for tag, decay in (("wd0", 0.0), ("wd1e6", 1e-6), ("wd1e4", 1e-4)):
            add(
                f"scale0p03_{tag}",
                training={**long_training, "weight_decay": decay},
                method_parameters=_barrier("hyperbolic", 1.0, scale=0.03),
            )
        for batch_size in (64, 256, 512):
            add(
                f"scale0p03_batch{batch_size}",
                training={**long_training, "batch_size": batch_size},
                method_parameters=_barrier("hyperbolic", 1.0, scale=0.03),
            )
    return {
        "name": "atlas_wave6_lava_barrier_refinement_validation",
        "run_root": "results/campaigns/atlas_wave6_lava_refinement",
        "base": _base(),
        "variants": rows,
    }


def lava_matched_capacity_baselines() -> dict[str, Any]:
    """Match the refined barrier network and training budget for core baselines."""

    rows: list[dict[str, Any]] = []
    default_rates = {"mse": 3e-3, "wise": 3e-3, "spo_plus": 1e-3}
    for prefix, benchmark_id in LAVA_LADDER_BENCHMARKS:
        common = {
            "benchmark_id": benchmark_id,
            "sizes": {"train": 800, "validation": 200, "test": 1000},
            "workers": 4,
        }

        def add(
            suffix: str,
            *,
            _prefix: str = prefix,
            _common: dict[str, Any] = common,
            **updates: Any,
        ) -> None:
            rows.append({"name": f"{_prefix}_matched_{suffix}", **_common, **updates})

        long_training = {"epochs": 300, "patience": 60}
        for method, default_rate in default_rates.items():
            for width in (64, 128, 256):
                add(
                    f"{method}_width{width}",
                    method=method,
                    model={"depth": 3, "width": width},
                    training={
                        **long_training,
                        "learning_rate": default_rate,
                    },
                )
            for tag, rate in (
                ("lr3e4", 3e-4),
                ("lr1e3", 1e-3),
                ("lr3e3", 3e-3),
            ):
                add(
                    f"{method}_width512_{tag}",
                    method=method,
                    model={"depth": 3, "width": 512},
                    training={**long_training, "learning_rate": rate},
                )
    return {
        "name": "atlas_wave7_lava_matched_capacity_baselines_validation",
        "run_root": "results/campaigns/atlas_wave7_lava_matched_baselines",
        "base": _base(),
        "variants": rows,
    }


def _best_development_arm(
    *, run_root: Path, benchmark_id: str, method: str
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Select one completed arm using validation regret and retain provenance."""

    candidates: list[tuple[float, str, dict[str, Any], dict[str, Any]]] = []
    for directory in sorted(path for path in run_root.iterdir() if path.is_dir()):
        paths = {
            "status": directory / "status.json",
            "config": directory / "config.json",
            "summary": directory / "summary.json",
            "environment": directory / "environment.json",
        }
        if not all(path.is_file() for path in paths.values()):
            continue
        status = json.loads(paths["status"].read_text(encoding="utf-8"))
        config = json.loads(paths["config"].read_text(encoding="utf-8"))
        summary = json.loads(paths["summary"].read_text(encoding="utf-8"))
        environment = json.loads(paths["environment"].read_text(encoding="utf-8"))
        if status.get("status") != "complete":
            continue
        if config.get("benchmark_id") != benchmark_id or config.get("method") != method:
            continue
        validation = summary.get("best_validation")
        if not isinstance(validation, dict):
            continue
        regret = validation.get("normalized_mean_regret")
        if not isinstance(regret, (int, float)) or isinstance(regret, bool):
            continue
        source = environment.get("source_sha256")
        if not isinstance(source, str) or len(source) != 64:
            raise ValueError(f"missing executable source digest in {directory}")
        provenance = {
            "run_directory": str(directory.relative_to(REPO_ROOT)),
            "source_sha256": source,
            "validation_normalized_mean_regret": float(regret),
        }
        candidates.append((float(regret), str(directory), config, provenance))
    if not candidates:
        raise ValueError(
            f"no completed {method} arm for {benchmark_id} below {run_root}"
        )
    _, _, config, provenance = min(candidates, key=lambda row: (row[0], row[1]))
    return config, provenance


def path_matched_capacity(*, sentinels_only: bool) -> dict[str, Any]:
    """Audit the broad path conclusions under one shared high-capacity budget.

    Hyperparameters other than capacity and learning rate are selected from the
    validation-only broad screen.  The generated campaign is self-contained;
    the selection receipts below make that transfer auditable.
    """

    source_root = REPO_ROOT / "results/campaigns/atlas_wave4_all_paths"
    if not source_root.is_dir():
        raise FileNotFoundError(
            "run atlas_wave4_all_paths before building the capacity audit"
        )
    rows: list[dict[str, Any]] = []
    selections: list[dict[str, Any]] = []
    methods = (
        "mse",
        "wise",
        "spo_plus",
        "soft_radial_log_barrier",
        "perturbed_fy",
        "sfge",
    )
    for (
        prefix,
        benchmark_id,
        train,
        validation,
        test,
        data_seed,
        _family,
    ) in ALL_PATH_BENCHMARKS:
        if sentinels_only and prefix not in PATH_CAPACITY_SENTINELS:
            continue
        common = {
            "benchmark_id": benchmark_id,
            "sizes": {"train": train, "validation": validation, "test": test},
            "seeds": {"data": data_seed},
        }
        for method in methods:
            selected, provenance = _best_development_arm(
                run_root=source_root,
                benchmark_id=benchmark_id,
                method=method,
            )
            selections.append(
                {
                    "benchmark_id": benchmark_id,
                    "method": method,
                    **provenance,
                }
            )
            method_parameters = selected.get("method_parameters", {})
            for tag, rate in (
                ("lr3e4", 3e-4),
                ("lr1e3", 1e-3),
                ("lr3e3", 3e-3),
            ):
                rows.append(
                    {
                        "name": f"{prefix}_capacity_{method}_{tag}",
                        **common,
                        "method": method,
                        "model": {"depth": 3, "width": 512},
                        "training": {
                            "epochs": 300,
                            "patience": 60,
                            "learning_rate": rate,
                        },
                        "method_parameters": method_parameters,
                    }
                )
    scope = "sentinels" if sentinels_only else "all_paths"
    return {
        "name": f"atlas_path_matched_capacity_{scope}_validation",
        "run_root": "results/campaigns/atlas_wave8_path_matched_capacity",
        "base": _base(),
        "design": {
            "development_only": True,
            "selection_metric": "validation_normalized_mean_regret",
            "source_run_root": str(source_root.relative_to(REPO_ROOT)),
            "selected_source_arms": selections,
            "capacity_audit": {
                "depth": 3,
                "width": 512,
                "epochs": 300,
                "learning_rates": [3e-4, 1e-3, 3e-3],
            },
        },
        "variants": rows,
    }


def exact_qp_projection_screen() -> dict[str, Any]:
    """Late, expensive control for exact Euclidean projection in the loop."""

    benchmarks = (
        ("wise4", "wise_shortest_path_5x5_degree_4", 1600, 1000, 1000, 903),
        (
            "directional_random_gaussian",
            "directional_random_cost_grid_additive_gaussian",
            1600,
            200,
            1000,
            1103,
        ),
    )
    rows: list[dict[str, Any]] = []
    for prefix, benchmark_id, train, validation, test, data_seed in benchmarks:
        common = {
            "benchmark_id": benchmark_id,
            "sizes": {"train": train, "validation": validation, "test": test},
            "seeds": {"data": data_seed},
            "method": "direct_projection",
        }
        for depth, width in ((2, 64), (3, 128), (3, 256)):
            for tag, rate in (
                ("lr3e4", 3e-4),
                ("lr1e3", 1e-3),
                ("lr3e3", 3e-3),
            ):
                rows.append(
                    {
                        "name": f"{prefix}_exact_qp_width{width}_{tag}",
                        **common,
                        "model": {"depth": depth, "width": width},
                        "training": {
                            "epochs": 100,
                            "patience": 20,
                            "learning_rate": rate,
                        },
                    }
                )
    return {
        "name": "atlas_wave11_exact_qp_projection_validation_screen",
        "run_root": "results/campaigns/atlas_wave11_exact_qp_projection",
        "base": _base(),
        "design": {
            "development_only": True,
            "late_expensive_control": True,
            "selection_metric": "validation_normalized_mean_regret",
        },
        "variants": rows,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--wave",
        choices=(
            "representative-paths",
            "lava-screen",
            "refinement-paths",
            "broad-paths",
            "lava-ladder-fast",
            "lava-barrier-refinement",
            "lava-matched-baselines",
            "path-capacity-sentinels",
            "path-capacity-full",
            "exact-qp-projection",
        ),
        default="representative-paths",
    )
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    if arguments.wave == "representative-paths":
        payload = representative_paths()
    elif arguments.wave == "lava-screen":
        payload = lava_screen()
    elif arguments.wave == "refinement-paths":
        payload = refinement_paths()
    elif arguments.wave == "broad-paths":
        payload = broad_path_ladder()
    elif arguments.wave == "lava-ladder-fast":
        payload = lava_ladder_fast()
    elif arguments.wave == "lava-barrier-refinement":
        payload = lava_barrier_refinement()
    elif arguments.wave == "lava-matched-baselines":
        payload = lava_matched_capacity_baselines()
    elif arguments.wave == "path-capacity-sentinels":
        payload = path_matched_capacity(sentinels_only=True)
    elif arguments.wave == "path-capacity-full":
        payload = path_matched_capacity(sentinels_only=False)
    else:
        payload = exact_qp_projection_screen()
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = arguments.output.with_suffix(arguments.output.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    temporary.replace(arguments.output)
    print(f"wrote {len(payload['variants'])} variants to {arguments.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
