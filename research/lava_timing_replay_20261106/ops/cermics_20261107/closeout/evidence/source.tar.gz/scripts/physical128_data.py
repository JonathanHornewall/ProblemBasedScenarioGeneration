"""Frozen observed training/validation pairs and a sealed 128-context test bank.

Only the upstream preparation entry point calls a benchmark generator, to
recover the known optimization structure. Fitting loads archived observations;
population moments are absent from its train/validation arrays.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import time
from pathlib import Path

import numpy as np
from build_central_path_final import read, write

REVISION = "physical_head_test128_20260925_v1"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bank_key(job):
    return job["route"] + "__data" + str(job["config"]["seeds"]["data"])


def array_hash(a):
    a = np.ascontiguousarray(a)
    h = hashlib.sha256()
    h.update(str(a.dtype).encode())
    h.update(np.asarray(a.shape, dtype=np.int64).tobytes())
    h.update(a.tobytes())
    return h.hexdigest()


def json_value(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {k: json_value(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [json_value(v) for v in value]
    return value


def observed_arrays(saved):
    """No hidden conditional moments enter fitting or its preprocessing."""
    arrays = {}
    for split, n in (("train", 100), ("validation", 32)):
        for field in ("contexts", "physical_costs", "coefficients"):
            name = split + "__" + field
            if name in saved:
                arrays[name] = saved[name][:n].copy()
        if len(arrays[split + "__contexts"]) != n:
            raise ValueError("Archived observed split is too short")
    return arrays


def prepare(entry, root):
    from proximal_spo.data import SplitSizes
    from proximal_spo.external_benchmarks import load_external_benchmark
    from run_public_solver_free_matched import _hash_array

    key = entry["key"]
    directory = root / "frozen_data" / key
    if (directory / "receipt.json").exists():
        meta = read(directory / "receipt.json")
        for name, expected in meta["files_sha256"].items():
            if digest(directory / name) != expected:
                raise ValueError("Previously frozen bank changed")
        return meta
    if directory.exists():
        directory.rename(directory.with_name(directory.name + ".incomplete." + str(time.time_ns())))
    directory.mkdir(parents=True, exist_ok=False)
    source = Path(entry["source_bank"])
    source_sha = digest(source)
    with np.load(source, allow_pickle=False) as saved:
        observations = observed_arrays(saved)
        test = {k: saved[k][:128].copy() for k in saved.files if k.startswith("test__")}
        if len(test["test__contexts"]) != 128:
            raise ValueError("Test bank is too short")
        source_hashes = {k: _hash_array(saved[k]) for k in saved.files}
    j = entry["source_job"]
    # Upstream structure extraction is separate from fitting. Generated costs
    # are discarded; all observations and test references come from the archive.
    loaded = load_external_benchmark(j["route"], SplitSizes(1, 1, 1),
        data_seed=j["config"]["seeds"]["data"], conditional_reference_samples=1)
    p, d = loaded.problem, loaded.dataset
    structure = {"matrix_data": p.matrix.data, "matrix_indices": p.matrix.indices,
        "matrix_indptr": p.matrix.indptr, "matrix_shape": np.array(p.matrix.shape),
        "row_lower": p.row_lower, "row_upper": p.row_upper,
        "variable_lower": p.variable_lower, "variable_upper": p.variable_upper,
        "integrality": p.integrality, "fixed_anchor": d.fixed_anchor,
        "random_indices": d.random_indices}
    if d.cost_statistic is not None:
        structure["cost_statistic"] = d.cost_statistic
    for name, arrays in (("observations.npz", observations), ("test.npz", test),
                         ("structure.npz", structure)):
        with (directory / name).open("xb") as stream:
            np.savez_compressed(stream, **arrays)
    write(directory / "structure.json", {"name": p.name, "metadata": json_value(dict(p.metadata)),
        "benchmark_id": d.benchmark_id, "master_seed": d.master_seed, "law": d.law})
    if digest(source) != source_sha:
        raise ValueError("Archived bank changed during read")
    hashes = {s: {f: _hash_array(a) for k, a in {**observations, **test}.items()
                  for prefix, f in [k.split("__", 1)] if prefix == s}
              for s in ("train", "validation", "test")}
    for split in ("train", "validation"):
        hashes[split]["conditional_mean_costs"] = hashes[split]["physical_costs"]
        if "coefficients" in hashes[split]:
            hashes[split]["conditional_mean_coefficients"] = hashes[split]["coefficients"]
    result = {"revision": REVISION, "key": key, "source_bank": str(source),
        "source_bank_sha256": source_sha, "source_array_hashes": source_hashes,
        "array_hashes": hashes, "sizes": {"train": 100, "validation": 32, "test": 128},
        "test_policy": "first_128_archived_contexts_and_costs_fixed_before_new_results",
        "learner_information": "100 observed training pairs and known optimization structure",
        "validation_information": "32 observed pairs for selection only",
        "files_sha256": {n: digest(directory / n) for n in
            ("observations.npz", "test.npz", "structure.npz", "structure.json")}}
    write(directory / "receipt.json", result)
    return result


def load_job(job):
    from scipy.sparse import csc_matrix
    from proximal_spo.data import DatasetBundle, PhysicalCostSplit
    from proximal_spo.problem import LinearProblem
    from proximal_spo.external_benchmarks import ExternalBenchmarkLoad

    if job["physical128_revision"] != REVISION or job["config"]["sizes"] != {
            "train": 100, "validation": 32, "test": 128}:
        raise ValueError("Unregistered physical/test128 protocol")
    directory = Path(os.environ["CENTRAL_PATH_FROZEN_DATA"]) / bank_key(job)
    receipt = read(directory / "receipt.json")
    access_test = job["stage"] in ("confirmation", "reevaluation")
    names = ["observations.npz", "structure.npz", "structure.json"]
    if access_test:
        names.append("test.npz")
    for name in names:
        if digest(directory / name) != receipt["files_sha256"][name]:
            raise ValueError("Frozen input SHA256 mismatch: " + name)
    with np.load(directory / "observations.npz", allow_pickle=False) as a:
        arrays = {k: a[k] for k in a.files}
    if access_test:
        with np.load(directory / "test.npz", allow_pickle=False) as a:
            arrays.update({k: a[k] for k in a.files})
    else:
        # DatasetBundle requires a test-shaped object. Use a non-held-out dummy;
        # no test file is opened during screening/refinement or timing.
        for f in ("contexts", "physical_costs", "coefficients"):
            k = "train__" + f
            if k in arrays:
                arrays["test__" + f] = arrays[k][:1].copy()
    splits = {}
    for s in ("train", "validation", "test"):
        costs = arrays[s + "__physical_costs"]
        coefficients = arrays.get(s + "__coefficients")
        means = arrays.get(s + "__conditional_mean_costs", costs)
        mean_coefficients = arrays.get(s + "__conditional_mean_coefficients", coefficients)
        splits[s] = PhysicalCostSplit(arrays[s + "__contexts"], costs, means, s,
            job["config"]["seeds"]["data"], coefficients, mean_coefficients)
    m = read(directory / "structure.json")
    with np.load(directory / "structure.npz", allow_pickle=False) as a:
        matrix = csc_matrix((a["matrix_data"], a["matrix_indices"], a["matrix_indptr"]),
                            shape=tuple(a["matrix_shape"]))
        problem = LinearProblem(matrix, a["row_lower"], a["row_upper"],
            a["variable_lower"], a["variable_upper"], a["integrality"], m["name"], m["metadata"])
        dataset = DatasetBundle(**splits, fixed_anchor=a["fixed_anchor"],
            random_indices=a["random_indices"], benchmark_id=m["benchmark_id"],
            master_seed=m["master_seed"], law=m["law"],
            cost_statistic=a["cost_statistic"] if "cost_statistic" in a else None)
    return ExternalBenchmarkLoad(problem, dataset, {"physical128": receipt,
        "test_bank_opened": access_test, "generator_called_by_fit": False})


if __name__ == "__main__":
    from concurrent.futures import ProcessPoolExecutor
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    if not 1 <= args.workers <= 8:
        raise ValueError("Bounded upstream preparation uses at most eight workers")
    entries = read(args.root / "bank_plan.json")["entries"]
    with ProcessPoolExecutor(args.workers) as pool:
        futures = [pool.submit(prepare, e, args.root) for e in entries]
        records = [f.result() for f in futures]
    write(args.root / "input_preparation_verification.json", {"status": "complete",
        "count": len(records), "banks": records, "revision": REVISION})
    print(json.dumps({"status": "complete", "banks": len(records)}), flush=True)
