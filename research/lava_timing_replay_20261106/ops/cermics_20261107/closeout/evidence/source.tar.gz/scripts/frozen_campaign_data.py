"""Freeze full generated arrays once; replay the same bytes on every host."""
import fcntl
import hashlib
import json
import os
from dataclasses import replace
from pathlib import Path

import numpy as np

FIELDS = ("contexts", "physical_costs", "conditional_mean_costs",
          "coefficients", "conditional_mean_coefficients")


def data_key(job):
    c = job["config"]
    identity = {"route":job["route"], "sizes":c["sizes"], "original_sizes":job["original_sizes"],
                "data_seed":c["seeds"]["data"], "reference_samples":c["conditional_reference_samples"],
                "external_commit":"f3bdd0cde748f0ecbef85477c9e4caef1096fc2d"}
    return hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()


def freeze_or_restore(job, loaded):
    location = os.environ.get("CENTRAL_PATH_FROZEN_DATA")
    if not location:
        return loaded
    root = Path(location)
    root.mkdir(parents=True,exist_ok=True)
    key = data_key(job)
    path = root / (key + ".npz")
    with (root / (key + ".lock")).open("a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if not path.exists():
            if os.environ.get("CENTRAL_PATH_FROZEN_DATA_READONLY") == "1":
                raise RuntimeError("Authoritative frozen dataset not delivered: " + key)
            arrays = {s+"__"+f:getattr(getattr(loaded.dataset,s),f)
                      for s in ("train","validation","test") for f in FIELDS
                      if getattr(getattr(loaded.dataset,s),f) is not None}
            temporary = root / (key + f".{os.getpid()}.tmp")
            with temporary.open("wb") as stream:
                np.savez_compressed(stream,**arrays)
            temporary.replace(path)
        with np.load(path,allow_pickle=False) as data:
            splits = {s:replace(getattr(loaded.dataset,s),**{
                f:data[s+"__"+f] for f in FIELDS if s+"__"+f in data.files})
                for s in ("train","validation","test")}
    return replace(loaded,dataset=replace(loaded.dataset,**splits),provenance={
        **loaded.provenance,"frozen_data":{"key":key,"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}})
