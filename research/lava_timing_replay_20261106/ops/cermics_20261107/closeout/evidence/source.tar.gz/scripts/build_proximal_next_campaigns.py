"""Build the next paired development campaigns for the proximal surrogate.

The campaigns are deliberately diagnostic rather than confirmatory:

* ``capacity`` changes only neural capacity within each method family;
* ``matched-anchor`` matches MSE-base and proximal-correction capacity;
* ``broad-matched-anchor`` carries that matched design across six families;
* ``broad-comparators`` matches capacity and data for standard comparators;
* ``residual-mse-control`` gives MSE the same frozen-base correction pipeline;
* ``mollification-samples`` changes only the finite antithetic bank size K.

Both use larger fixed validation/test splits than the first pass so that rare
high-regret switches are visible before any configuration is promoted to the
broad benchmark panel.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
from typing import Any

from build_broad_cost_campaigns import DESIGNS

from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPO_ROOT / "configs" / "proximal_next"

DEVELOPMENT_SEEDS = (1, 2, 3)
CAPACITIES = (
    ("small", 2, 64),
    ("medium", 3, 128),
    ("large", 4, 256),
)
MOLLIFICATION_SAMPLES = (16, 32)
RESIDUAL_MSE_RATES = (1e-5, 3e-5, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2)


def _tag(value: float) -> str:
    return f"{value:.0e}".replace("-", "m").replace("+", "p")


def _seeds(seed: int) -> dict[str, int]:
    return {
        "data": seed,
        "structural": 101,
        "initialization": 200 + seed,
        "shuffle": 300 + seed,
        "perturbation": 400 + seed,
    }


def _base(seed: int) -> dict[str, Any]:
    return {
        "name": "base",
        "benchmark_id": "cost.grid5",
        "method": "mse",
        "interface": "full",
        "workers": 4,
        "sizes": {"train": 1024, "validation": 1024, "test": 4096},
        "law": {
            "context_dimension": 5,
            "random_fraction": 1.0,
            "style": "positive",
            "noise": "pyepo_uniform",
            "noise_scale": 0.5,
            "signal_scale": 1.0,
            "polynomial_degree": 6,
        },
        "model": {
            "depth": 2,
            "width": 64,
            "activation": "silu",
            "layer_norm": False,
            "correction_depth": 2,
            "correction_width": 64,
        },
        "training": {
            "epochs": 200,
            "batch_size": 128,
            "learning_rate": 1e-3,
            "weight_decay": 1e-5,
            "optimizer": "adamw",
            "gradient_clip": 10.0,
            "validation_interval": 5,
            "patience": 40,
            "minimum_delta": 1e-5,
            "evaluation_batch_size": 512,
            "torch_threads": 2,
            "selection_mode": "validation_regret",
        },
        "seeds": _seeds(seed),
        "method_parameters": {},
    }


def _capacity_model(
    label: str, depth: int, width: int, *, correction_only: bool
) -> dict[str, Any]:
    del label
    if correction_only:
        return {
            "depth": 2,
            "width": 64,
            "correction_depth": depth,
            "correction_width": width,
        }
    return {
        "depth": depth,
        "width": width,
        "correction_depth": depth,
        "correction_width": width,
    }


def _variant(
    *,
    seed: int,
    method: str,
    capacity: tuple[str, int, int],
    training: dict[str, Any] | None = None,
    method_parameters: dict[str, Any] | None = None,
    suffix: str = "",
) -> dict[str, Any]:
    label, depth, width = capacity
    result: dict[str, Any] = {
        "name": f"next_{method}_{label}_s{seed}{suffix}",
        "method": method,
        "model": _capacity_model(
            label,
            depth,
            width,
            correction_only=method
            in {
                "anchored_proximal",
                "mollified_anchored_proximal",
                "residual_mse",
            },
        ),
        "seeds": _seeds(seed),
        "method_parameters": copy.deepcopy(method_parameters or {}),
    }
    if training:
        result["training"] = copy.deepcopy(training)
    return result


def capacity_payload() -> dict[str, Any]:
    variants: list[dict[str, Any]] = []
    for seed in DEVELOPMENT_SEEDS:
        for capacity in CAPACITIES:
            variants.extend(
                [
                    _variant(seed=seed, method="mse", capacity=capacity),
                    _variant(
                        seed=seed,
                        method="proximal",
                        capacity=capacity,
                        method_parameters={
                            "tau": 3000.0,
                            "parameterization": "normalized",
                            "exact_head": False,
                        },
                    ),
                    _variant(
                        seed=seed,
                        method="anchored_proximal",
                        capacity=capacity,
                        training={"learning_rate": 1e-2},
                        method_parameters={
                            "tau": 300.0,
                            "alpha": 1.0,
                            "base_method": "mse",
                            "base_epochs": 200,
                            "base_learning_rate": 1e-3,
                            "base_batch_size": 128,
                            "freeze_base": True,
                            "center_on_base_decision": True,
                        },
                    ),
                    _variant(
                        seed=seed,
                        method="mollified_anchored_proximal",
                        capacity=capacity,
                        training={"learning_rate": 3e-3},
                        method_parameters={
                            "tau": 0.1,
                            "sigma": 0.1,
                            "training_samples": 8,
                            "evaluation_samples": 8,
                            "base_epochs": 200,
                            "base_learning_rate": 1e-3,
                            "base_batch_size": 128,
                        },
                    ),
                ]
            )
    return {
        "name": "proximal_next_capacity",
        "run_root": "runs/proximal_next/capacity",
        "base": _base(DEVELOPMENT_SEEDS[0]),
        "variants": variants,
        "design": {
            "purpose": "capacity diagnostic with paired MSE gates",
            "development_seeds": list(DEVELOPMENT_SEEDS),
            "capacities": [
                {"label": label, "depth": depth, "width": width}
                for label, depth, width in CAPACITIES
            ],
            "selection_metric": "mean paired validation regret versus MSE",
            "test_used_for_selection": False,
            "campaign_jobs": 2,
            "solver_workers_per_job": 4,
            "raw_weights_persisted": False,
        },
    }


def mollification_samples_payload() -> dict[str, Any]:
    variants: list[dict[str, Any]] = []
    for seed in DEVELOPMENT_SEEDS:
        for capacity in CAPACITIES:
            for samples in MOLLIFICATION_SAMPLES:
                variants.append(
                    _variant(
                        seed=seed,
                        method="mollified_anchored_proximal",
                        capacity=capacity,
                        training={"learning_rate": 3e-3},
                        method_parameters={
                            "tau": 0.1,
                            "sigma": 0.1,
                            "training_samples": samples,
                            "evaluation_samples": samples,
                            "base_epochs": 200,
                            "base_learning_rate": 1e-3,
                            "base_batch_size": 128,
                        },
                        suffix=f"_k{samples}",
                    )
                )
    return {
        "name": "proximal_next_mollification_samples",
        "run_root": "runs/proximal_next/mollification_samples",
        "base": _base(DEVELOPMENT_SEEDS[0]),
        "variants": variants,
        "design": {
            "purpose": "finite antithetic bank sensitivity at frozen sigma tau LR",
            "development_seeds": list(DEVELOPMENT_SEEDS),
            "capacities": [label for label, _, _ in CAPACITIES],
            "training_and_evaluation_samples": list(MOLLIFICATION_SAMPLES),
            "fixed_sigma": 0.1,
            "fixed_tau": 0.1,
            "fixed_learning_rate": 3e-3,
            "test_used_for_selection": False,
            "campaign_jobs": 2,
            "solver_workers_per_job": 4,
            "raw_weights_persisted": False,
        },
    }


def matched_anchor_payload() -> dict[str, Any]:
    """Match the embedded MSE base and correction network capacity.

    The first capacity campaign deliberately changed only correction capacity
    for anchored methods. This companion campaign asks the paper-critical
    question: can proximal correction improve an already expressive MSE base?
    """

    variants: list[dict[str, Any]] = []
    for seed in DEVELOPMENT_SEEDS:
        for capacity in CAPACITIES[1:]:
            label, depth, width = capacity
            model = {
                "depth": depth,
                "width": width,
                "correction_depth": depth,
                "correction_width": width,
            }
            variants.append(
                {
                    "name": f"next_matched_anchor_{label}_s{seed}",
                    "method": "anchored_proximal",
                    "model": model,
                    "training": {"learning_rate": 1e-2},
                    "seeds": _seeds(seed),
                    "method_parameters": {
                        "tau": 300.0,
                        "alpha": 1.0,
                        "base_method": "mse",
                        "base_epochs": 200,
                        "base_learning_rate": 1e-3,
                        "base_batch_size": 128,
                        "freeze_base": True,
                        "center_on_base_decision": True,
                    },
                }
            )
    return {
        "name": "proximal_next_matched_anchor",
        "run_root": "runs/proximal_next/matched_anchor",
        "base": _base(DEVELOPMENT_SEEDS[0]),
        "variants": variants,
        "design": {
            "purpose": "proximal correction on a capacity-matched strong MSE base",
            "development_seeds": list(DEVELOPMENT_SEEDS),
            "capacities": [label for label, _, _ in CAPACITIES[1:]],
            "primary_comparison": "corrected policy versus identical embedded MSE",
            "test_used_for_selection": False,
            "campaign_jobs": 2,
            "solver_workers_per_job": 4,
            "raw_weights_persisted": False,
        },
    }


def _load_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected an object in {path}")
    return value


def _selected_arm(
    selection: dict[str, Any], benchmark_id: str, method: str
) -> dict[str, Any]:
    rows = selection.get("selected_arms")
    if not isinstance(rows, list):
        raise ValueError("broad anchored selection lacks selected_arms")
    matches = [
        row
        for row in rows
        if row.get("benchmark_id") == benchmark_id
        and row.get("method") == method
    ]
    if len(matches) != 1 or not isinstance(matches[0].get("arm"), dict):
        raise ValueError(f"missing {method} selection for {benchmark_id}")
    return copy.deepcopy(matches[0]["arm"])


def broad_matched_anchor_payload() -> dict[str, Any]:
    """Promote the matched large anchored model to the six-family panel."""

    selection_path = (
        REPO_ROOT / "results" / "broad_cost" / "anchored_refinement_selection.json"
    )
    selection = _load_object(selection_path)
    variants: list[dict[str, Any]] = []
    for design in DESIGNS:
        selected = _selected_arm(
            selection, design.benchmark_id, "anchored_proximal"
        )
        for seed in DEVELOPMENT_SEEDS:
            arm = copy.deepcopy(selected)
            arm["name"] = f"next_broad_{design.tag}_matched_large_s{seed}"
            arm["workers"] = 4
            arm["sizes"] = {"train": 1024, "validation": 1024, "test": 4096}
            arm["model"] = {
                "depth": 4,
                "width": 256,
                "activation": "silu",
                "layer_norm": False,
                "correction_depth": 4,
                "correction_width": 256,
            }
            arm["training"].update(
                {
                    "epochs": 200,
                    "batch_size": 128,
                    "validation_interval": 5,
                    "patience": 40,
                    "evaluation_batch_size": 512,
                    "torch_threads": 2,
                    "selection_mode": "validation_regret",
                }
            )
            arm["method_parameters"].update(
                {
                    "base_epochs": 200,
                    "base_batch_size": 128,
                    "freeze_base": True,
                    "center_on_base_decision": True,
                }
            )
            arm["seeds"] = _seeds(seed)
            variants.append(arm)
    return {
        "name": "proximal_next_broad_matched_anchor",
        "run_root": "runs/proximal_next/broad_matched_anchor",
        "base": _base(DEVELOPMENT_SEEDS[0]),
        "variants": variants,
        "design": {
            "purpose": "six-family test of proximal correction over strong MSE",
            "development_seeds": list(DEVELOPMENT_SEEDS),
            "benchmarks": [design.benchmark_id for design in DESIGNS],
            "capacity": {"depth": 4, "width": 256},
            "primary_comparison": "corrected policy versus identical embedded MSE",
            "hyperparameter_source": str(selection_path.relative_to(REPO_ROOT)),
            "hyperparameter_source_sha256": hashlib.sha256(
                selection_path.read_bytes()
            ).hexdigest(),
            "capacity_and_data_promoted_without_retuning": True,
            "test_used_for_selection": False,
            "campaign_jobs": 2,
            "solver_workers_per_job": 4,
            "raw_weights_persisted": False,
        },
    }


def broad_comparator_payload() -> dict[str, Any]:
    """Capacity-match the standard comparator panel on the same data streams."""

    selection_path = REPO_ROOT / "results" / "broad_cost" / "refinement_selection.json"
    selection = _load_object(selection_path)
    methods = ("proximal", "spo_plus", "wise", "knn")
    variants: list[dict[str, Any]] = []
    for design in DESIGNS:
        for method in methods:
            selected = _selected_arm(selection, design.benchmark_id, method)
            for seed in DEVELOPMENT_SEEDS:
                arm = copy.deepcopy(selected)
                arm["name"] = f"next_broad_{design.tag}_{method}_large_s{seed}"
                arm["workers"] = 4
                arm["sizes"] = {
                    "train": 1024,
                    "validation": 1024,
                    "test": 4096,
                }
                arm["model"] = {
                    "depth": 4,
                    "width": 256,
                    "activation": "silu",
                    "layer_norm": False,
                    "correction_depth": 4,
                    "correction_width": 256,
                }
                arm["training"].update(
                    {
                        "epochs": 200,
                        "batch_size": 128,
                        "validation_interval": 5,
                        "patience": 40,
                        "evaluation_batch_size": 512,
                        "torch_threads": 2,
                        "selection_mode": "validation_regret",
                    }
                )
                arm["seeds"] = _seeds(seed)
                variants.append(arm)
    return {
        "name": "proximal_next_broad_comparators",
        "run_root": "runs/proximal_next/broad_comparators",
        "base": _base(DEVELOPMENT_SEEDS[0]),
        "variants": variants,
        "design": {
            "purpose": "capacity-matched comparator panel for broad proximal study",
            "development_seeds": list(DEVELOPMENT_SEEDS),
            "benchmarks": [design.benchmark_id for design in DESIGNS],
            "methods": list(methods),
            "capacity": {"depth": 4, "width": 256},
            "hyperparameter_source": str(selection_path.relative_to(REPO_ROOT)),
            "hyperparameter_source_sha256": hashlib.sha256(
                selection_path.read_bytes()
            ).hexdigest(),
            "capacity_and_data_promoted_without_retuning": True,
            "test_used_for_selection": False,
            "campaign_jobs": 2,
            "solver_workers_per_job": 4,
            "raw_weights_persisted": False,
        },
    }


def residual_mse_control_payload() -> dict[str, Any]:
    """Give MSE the same frozen base, residual network, and validation budget."""

    selection_path = (
        REPO_ROOT / "results" / "broad_cost" / "anchored_refinement_selection.json"
    )
    selection = _load_object(selection_path)
    variants: list[dict[str, Any]] = []
    for design in DESIGNS:
        anchored = _selected_arm(
            selection, design.benchmark_id, "anchored_proximal"
        )
        base_parameters = anchored["method_parameters"]
        for seed in DEVELOPMENT_SEEDS:
            for rate in RESIDUAL_MSE_RATES:
                arm = copy.deepcopy(anchored)
                arm["name"] = (
                    f"next_{design.tag}_residual_mse_large_s{seed}_lr{_tag(rate)}"
                )
                arm["method"] = "residual_mse"
                arm["workers"] = 2
                arm["sizes"] = {
                    "train": 1024,
                    "validation": 1024,
                    "test": 4096,
                }
                arm["model"] = {
                    "depth": 4,
                    "width": 256,
                    "activation": "silu",
                    "layer_norm": False,
                    "correction_depth": 4,
                    "correction_width": 256,
                }
                arm["training"].update(
                    {
                        "epochs": 200,
                        "batch_size": 128,
                        "learning_rate": rate,
                        "validation_interval": 5,
                        "patience": 40,
                        "evaluation_batch_size": 512,
                        "torch_threads": 2,
                        "selection_mode": "validation_regret",
                    }
                )
                arm["method_parameters"] = {
                    "base_method": "mse",
                    "base_epochs": 200,
                    "base_learning_rate": float(
                        base_parameters["base_learning_rate"]
                    ),
                    "base_batch_size": 128,
                    "freeze_base": True,
                }
                arm["seeds"] = _seeds(seed)
                variants.append(arm)
    return {
        "name": "proximal_next_residual_mse_control",
        "run_root": "runs/proximal_next/residual_mse_control",
        "base": _base(DEVELOPMENT_SEEDS[0]),
        "variants": variants,
        "design": {
            "purpose": "structurally matched residual-MSE control",
            "development_seeds": list(DEVELOPMENT_SEEDS),
            "benchmarks": [design.benchmark_id for design in DESIGNS],
            "learning_rates": list(RESIDUAL_MSE_RATES),
            "capacity": {"depth": 4, "width": 256},
            "primary_comparison": (
                "residual MSE versus its identical embedded MSE base and the "
                "matched anchored-proximal correction"
            ),
            "hyperparameter_source": str(selection_path.relative_to(REPO_ROOT)),
            "hyperparameter_source_sha256": hashlib.sha256(
                selection_path.read_bytes()
            ).hexdigest(),
            "selection_metric": "mean validation decision regret across three seeds",
            "test_used_for_selection": False,
            "campaign_jobs": 3,
            "solver_workers_per_job": 2,
            "raw_weights_persisted": False,
        },
    }


def _write(name: str, payload: dict[str, Any]) -> Path:
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    path = CONFIG_ROOT / f"{name}.json"
    write_json(path, payload)
    return path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "stage",
        choices=(
            "capacity",
            "matched-anchor",
            "broad-matched-anchor",
            "broad-comparators",
            "residual-mse-control",
            "mollification-samples",
            "all",
        ),
        default="all",
        nargs="?",
    )
    arguments = parser.parse_args()
    paths: list[Path] = []
    if arguments.stage in {"capacity", "all"}:
        paths.append(_write("capacity", capacity_payload()))
    if arguments.stage in {"matched-anchor", "all"}:
        paths.append(_write("matched_anchor", matched_anchor_payload()))
    if arguments.stage in {"broad-matched-anchor", "all"}:
        paths.append(
            _write("broad_matched_anchor", broad_matched_anchor_payload())
        )
    if arguments.stage in {"broad-comparators", "all"}:
        paths.append(_write("broad_comparators", broad_comparator_payload()))
    if arguments.stage in {"residual-mse-control", "all"}:
        paths.append(
            _write("residual_mse_control", residual_mse_control_payload())
        )
    if arguments.stage in {"mollification-samples", "all"}:
        paths.append(
            _write("mollification_samples", mollification_samples_payload())
        )
    for path in paths:
        print(path)


if __name__ == "__main__":
    main()
