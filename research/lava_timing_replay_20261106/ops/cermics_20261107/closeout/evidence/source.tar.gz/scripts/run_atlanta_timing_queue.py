#!/usr/bin/env python3
"""Durable per-VM queue with bounded concurrency and explicit terminal receipts."""
from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import psutil

from run_atlanta_baseline_timing import write


def memory_gib(job: dict) -> float:
    route, method = job["entry"]["route_id"], job["method"]
    if method == "lava" and ("shortest_path_25x25" in route or "cfl_" in route):
        return 44.0
    if method == "cave" and "shortest_path_25x25" in route:
        return 30.0
    if method == "cave" and "cfl_" in route:
        return 6.0
    if method == "lava":
        return 6.0
    return 2.0


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--output-root", type=Path, required=True)
    p.add_argument("--indices", type=Path, required=True)
    p.add_argument("--workers", type=int, default=8)
    p.add_argument("--memory-gib", type=float, default=58)
    p.add_argument("--deadline-unix", type=float, required=True)
    p.add_argument("--python", default=sys.executable)
    args = p.parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)
    (args.output_root / "logs").mkdir(exist_ok=True)
    jobs = json.loads(args.manifest.read_text())["jobs"]
    indices = json.loads(args.indices.read_text())
    pending = [i for i in indices if not (args.output_root / "receipts" / f"{jobs[i]['id']}.json").exists()]
    # Start long fits immediately, while fitting light jobs around their memory.
    pending.sort(key=lambda i: (-memory_gib(jobs[i]), jobs[i]["repeat"], i))
    active = {}
    stop = False

    def stopping(signum, frame):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, stopping)
    signal.signal(signal.SIGINT, stopping)
    env = dict(os.environ)
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        env[key] = "1"
    env["PYTHONUNBUFFERED"] = "1"

    def terminal(i: int, category: str, elapsed: float, code: int | None) -> None:
        job = jobs[i]
        receipt = args.output_root / "receipts" / f"{job['id']}.json"
        if receipt.exists():
            return
        progress = args.output_root / "progress" / f"{job['id']}.json"
        record = json.loads(progress.read_text()) if progress.exists() else {
            "job_id": job["id"], "job_index": i, "method": job["method"],
            "route": job["entry"]["route_id"], "repeat": job["repeat"],
            "epochs_requested": 300, "epochs_completed": 0,
        }
        record.update(status="incomplete", failure_category=category,
                      parent_wall_seconds=elapsed, returncode=code,
                      finished_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
        write(receipt, record)

    while pending or active:
        if time.time() >= args.deadline_unix:
            stop = True
        if stop:
            for i in pending:
                terminal(i, "deadline_before_launch", 0.0, None)
            pending.clear()
            for i, task in active.items():
                if task.get("terminated") is None:
                    try:
                        os.killpg(task["process"].pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    task["terminated"] = time.monotonic()
        for task in active.values():
            if task.get("terminated") is not None and time.monotonic() - task["terminated"] > 15:
                try:
                    os.killpg(task["process"].pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            try:
                process = psutil.Process(task["process"].pid)
                task["rss_gib"] = sum(p.memory_info().rss for p in [process, *process.children(recursive=True)]) / 2**30
            except psutil.Error:
                task["rss_gib"] = 0.0
        if active and sum(t.get("rss_gib", 0) for t in active.values()) > args.memory_gib:
            victim = max(active.values(), key=lambda t: t.get("rss_gib", 0))
            if victim.get("terminated") is None:
                try:
                    os.killpg(victim["process"].pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                victim["terminated"] = time.monotonic()
                victim["failure_category"] = "vm_memory_limit"
        for i in list(active):
            task = active[i]
            code = task["process"].poll()
            if code is None:
                continue
            task["log"].close()
            terminal(i, task.get("failure_category", "campaign_deadline" if stop else "child_exit_without_receipt"),
                     time.monotonic() - task["started"], code)
            del active[i]
        while not stop and len(active) < args.workers:
            used = sum(memory_gib(jobs[i]) for i in active)
            selected = next((i for i in pending if memory_gib(jobs[i]) + used <= args.memory_gib), None)
            if selected is None:
                break
            pending.remove(selected)
            job = jobs[selected]
            log = (args.output_root / "logs" / f"{job['id']}.log").open("a")
            command = [args.python, str(Path(__file__).with_name("run_atlanta_baseline_timing.py")),
                       "run", "--manifest", str(args.manifest), "--job-index", str(selected),
                       "--output-root", str(args.output_root)]
            child = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            active[selected] = {"process": child, "log": log, "started": time.monotonic()}
        write(args.output_root / "queue_status.json", {
            "kind": "atlanta_timing_queue", "pid": os.getpid(), "expected": len(indices),
            "pending": len(pending), "running": [jobs[i]["id"] for i in active],
            "terminal": len(indices) - len(pending) - len(active),
            "updated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "deadline_unix": args.deadline_unix,
        })
        if pending or active:
            time.sleep(2)
    write(args.output_root / "QUEUE_DONE.json", {
        "kind": "atlanta_timing_queue_terminal", "expected": len(indices),
        "stopped_at_deadline": stop, "finished_unix": time.time(),
    })


if __name__ == "__main__":
    main()
