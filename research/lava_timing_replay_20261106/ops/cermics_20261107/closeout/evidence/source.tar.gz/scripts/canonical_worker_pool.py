"""Replace exited run-owned workers without interrupting healthy fits."""
import argparse
import fcntl
import json
import os
import signal
import socket
import subprocess
import time
from pathlib import Path

import psutil

from build_central_path_final import read, write
from central_path_slurm import environment


def run(root, capacity, memory_gib):
    host=socket.gethostname()
    guard=(root/('worker_pool_'+host+'.lock')).open('a')
    fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
    deadline=min(read(root/'burst_state.json')['deadline_unix'],float(os.environ.get('CPS_WORKER_CUTOFF','inf')))
    stopped=False
    children=[]
    def stop(*args):
        nonlocal stopped
        stopped=True
    signal.signal(signal.SIGTERM,stop)
    signal.signal(signal.SIGINT,stop)
    command=[str(root/'venv/bin/python'),str(root/'code/scripts/canonical_cluster.py'),
             'worker','--root',str(root),'--memory-gib',str(memory_gib)]
    with (root/'logs'/('supervised_'+host+'.log')).open('a') as log:
        while not stopped and time.time()<deadline-30:
            if read(root/'burst_state.json').get('status')=='complete':
                break
            children=[p for p in children if p.poll() is None]
            workers=[]
            for p in psutil.process_iter(['cmdline']):
                c=p.info['cmdline'] or []
                if command[1] in c and 'worker' in c and str(root) in c:
                    workers.append(p.pid)
            # Reap only dead workers owned by this run and this host. Keep
            # the interrupted attempt, then let the coordinator resume it.
            import canonical_cluster
            db=canonical_cluster.connect(root)
            for row in db.execute("SELECT id,worker FROM jobs WHERE status='running' AND host=?",(host,)).fetchall():
                if row['worker'] in workers:
                    continue
                progress=root/'results/progress'/(row['id']+'.json')
                rec=read(progress) if progress.exists() else {}
                child_pid=rec.get('pid')
                if child_pid and psutil.pid_exists(child_pid):
                    try:
                        child=psutil.Process(child_pid)
                        args=child.cmdline()
                        if str(root/'code/scripts/run_central_path_final.py') in args and str(root/'execution.json') in args:
                            child.terminate()
                            try:child.wait(timeout=10)
                            except psutil.TimeoutExpired:child.kill();child.wait(timeout=10)
                        else:
                            continue
                    except psutil.NoSuchProcess:
                        pass
                write(root/'results/interruptions'/(row['id']+'.supervisor.json'),
                      {'status':'interrupted','reason':'run-owned worker exited','prior_progress':rec,'updated_unix':time.time()})
                db.execute("UPDATE jobs SET status='interrupted' WHERE id=? AND status='running'",(row['id'],))
            db.commit();db.close()
            added=max(0,capacity-len(workers))
            for _ in range(added):
                children.append(subprocess.Popen(command,env=environment(root),stdout=log,stderr=subprocess.STDOUT))
            write(root/('worker_pool_'+host+'.json'),{
                'updated_unix':time.time(),'capacity':capacity,'observed_workers':len(workers),
                'added_workers':added,'supervised_workers':len(children),
                'deadline_unix':deadline,'status':'running'})
            time.sleep(5)
        for p in children:
            if p.poll() is None:
                p.terminate()
        for p in children:
            try:p.wait(timeout=15)
            except subprocess.TimeoutExpired:pass
    write(root/('worker_pool_'+host+'.json'),{'updated_unix':time.time(),'status':'stopped','deadline_unix':deadline})


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--workers',type=int,required=True)
    p.add_argument('--memory-gib',type=float,required=True)
    a=p.parse_args()
    run(a.root.resolve(),a.workers,a.memory_gib)
