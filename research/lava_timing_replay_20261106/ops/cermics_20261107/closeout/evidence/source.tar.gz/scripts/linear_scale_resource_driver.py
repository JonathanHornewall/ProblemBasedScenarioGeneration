"""Thirty-core base and bounded extra workers before the existing absolute cutoff."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import time

from build_central_path_final import read,write
from central_path_slurm import environment

CUTOFF=1790581209.0


def main(root):
    from canonical_cluster import setup
    assert int(os.environ['SLURM_CPUS_PER_TASK'])==30
    assert read(root/'preflight/VERIFICATION.json')['status']=='complete'
    assert read(root/'NEW_BANK_VERIFICATION.json')['status']=='complete'
    assert read(root/'INPUT_TRANSFER_VERIFICATION.json')['status']=='complete'
    setup(root)
    state=read(root/'burst_state.json')
    if state.get('status')=='complete':return
    schedule={'base_job':os.environ['SLURM_JOB_ID'],'base_cpus':30,'burst_cpus':62,
        'absolute_cutoff_unix':CUTOFF,'aggregate_ceiling_before':100,'aggregate_ceiling_after':30,
        'reserved_other_campaign_cpus':8,'started_unix':time.time(),'status':'starting'}
    write(root/'RESOURCE_SCHEDULE.json',schedule)
    burst=None
    # A whole bounded fit must fit before the cutoff before bursting is useful.
    if time.time()+9150<CUTOFF:
        burst=subprocess.check_output(['sbatch','--parsable',str(root/'launch_burst.sbatch')],text=True).strip().split(';')[0]
        assert burst.isdigit()
    schedule.update(burst_job=burst,status='running');write(root/'RESOURCE_SCHEDULE.json',schedule)
    env=environment(root);py=str(root/'venv/bin/python');scripts=root/'code/scripts'
    stopped=False;children=[];cancelled=False
    def stop(*args):
        nonlocal stopped
        stopped=True
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        with (root/'logs/coordinator.log').open('a') as log:
            coordinator=subprocess.Popen([py,str(scripts/'canonical_cluster.py'),'coordinate','--root',str(root)],env=env,stdout=log,stderr=subprocess.STDOUT)
            pool=subprocess.Popen([py,str(scripts/'canonical_worker_pool.py'),'--root',str(root),'--workers','30','--memory-gib','160'],env=env)
            children=[pool,coordinator]
            while not stopped and time.time()<state['deadline_unix']-90:
                if burst and time.time()>=CUTOFF-30 and not cancelled:
                    subprocess.run(['scancel',burst],check=False);cancelled=True
                    schedule.update(status='downscaled_to_30',cancelled_at_unix=time.time());write(root/'RESOURCE_SCHEDULE.json',schedule)
                if coordinator.poll() is not None:
                    if coordinator.returncode:raise RuntimeError('coordinator exited nonzero')
                    assert read(root/'burst_state.json')['status']=='complete'
                    break
                if pool.poll() is not None:raise RuntimeError('base worker supervisor exited early')
                time.sleep(2)
    finally:
        if burst:subprocess.run(['scancel',burst],check=False)
        for p in children:
            if p.poll() is None:p.terminate()
        for p in children:
            try:p.wait(timeout=30)
            except subprocess.TimeoutExpired:p.kill();p.wait()
        schedule.update(finished_unix=time.time(),status=read(root/'burst_state.json').get('status'))
        write(root/'RESOURCE_SCHEDULE.json',schedule)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);main(p.parse_args().root.resolve())
