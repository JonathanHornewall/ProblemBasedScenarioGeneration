"""Transfer leased datasets directly from CERMICS to the run-owned VMs."""
import argparse
import shlex
import subprocess
from pathlib import Path
from build_central_path_final import read
from frozen_campaign_data import data_key
from exact_validation_reference import needs_analytic_reference_file, analytic_reference_name


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--host',choices=('hornewall','tito'),required=True)
    a=p.parse_args();r=a.root;h=read(r/'cloud_transfer.json')[a.host]
    manifest=r/'leases'/(a.host+'.json')
    files=r/'leases'/(a.host+'.datasets.txt')
    bank_jobs = read(manifest)['jobs']
    from physical128_data import bank_key
    names = {data_key(j) + '.npz' for j in bank_jobs if not j.get('physical128_revision')}
    names.update(bank_key(j)+'/'+n for j in bank_jobs if j.get('physical128_revision')
                 for n in ('receipt.json','observations.npz','structure.npz','structure.json','test.npz'))
    names.update(data_key(j) + '.json' for j in bank_jobs if j.get('normal_validation_revision'))
    files.write_text(''.join(k+'\n' for k in sorted(names)))
    ssh=['ssh','-i',str(r/'cloud_ssh_key'),'-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+str(r/'cloud_known_hosts')]
    subprocess.run(['rsync','-az','--timeout=60','-e',shlex.join(ssh),'--files-from='+str(files),str(r/'frozen_data')+'/',h['ssh_target']+':'+h['root']+'/frozen_data/'],check=True)
    references=sorted({analytic_reference_name(j) for j in read(manifest)['jobs'] if needs_analytic_reference_file(j)})
    if references:
        reference_list=r/'leases'/(a.host+'.validation-references.txt')
        reference_list.write_text(''.join(name+'\n' for name in references))
        subprocess.run([*ssh,h['ssh_target'],'mkdir -p '+shlex.quote(h['root']+'/frozen_validation')],check=True)
        subprocess.run(['rsync','-az','--timeout=60','-e',shlex.join(ssh),'--files-from='+str(reference_list),str(r/'frozen_validation')+'/',h['ssh_target']+':'+h['root']+'/frozen_validation/'],check=True)
    subprocess.run(['rsync','-az','--timeout=60','-e',shlex.join(ssh),str(manifest),h['ssh_target']+':'+h['root']+'/execution.next.json'],check=True)
    subprocess.run([*ssh,h['ssh_target'],'mv '+shlex.quote(h['root']+'/execution.next.json')+' '+shlex.quote(h['root']+'/execution.json')],check=True)
