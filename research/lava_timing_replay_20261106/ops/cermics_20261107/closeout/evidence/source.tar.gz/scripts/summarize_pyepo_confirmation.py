"""Summarize the frozen ten-seed PyEPO small-tau confirmation campaign."""

from __future__ import annotations

import argparse
from pathlib import Path

from proximal_spo.analysis import (
    render_confirmation_markdown,
    summarize_confirmation,
)
from proximal_spo.artifacts import write_json

EXPECTED_LABELS = {
    "mse",
    "wise",
    "spo_plus",
    "proximal",
    "anchored_proximal",
    "exact_proximal_linear",
    "exact_proximal_mse_base",
    "post_adam_exact_proximal",
    "post_adam_centered_exact_proximal",
}
CENSORED_LABELS = {"post_adam_centered_exact_proximal"}


def _source_overrides(
    *, default: str | None, raw_overrides: list[str]
) -> dict[str, str] | None:
    if not raw_overrides:
        return None
    if default is None:
        raise ValueError("--source-override requires --source-sha256")
    result = {label: default for label in EXPECTED_LABELS}
    for item in raw_overrides:
        label, separator, digest = item.partition("=")
        if separator != "=" or label not in EXPECTED_LABELS or len(digest) != 64:
            raise ValueError(f"invalid source override {item!r}")
        result[label] = digest
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", type=Path)
    parser.add_argument("--source-sha256")
    parser.add_argument(
        "--source-override",
        action="append",
        default=[],
        metavar="LABEL=SHA256",
        help="use a different frozen executable digest for one method label",
    )
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    arguments = parser.parse_args()
    source_by_label = _source_overrides(
        default=arguments.source_sha256,
        raw_overrides=arguments.source_override,
    )
    summary = summarize_confirmation(
        arguments.run_root,
        source_sha256=(arguments.source_sha256 if source_by_label is None else None),
        source_sha256_by_label=source_by_label,
        expected_data_seeds=set(range(11, 21)),
        expected_labels=EXPECTED_LABELS,
        censored_labels=CENSORED_LABELS,
    )
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, summary)
    arguments.markdown_output.write_text(
        render_confirmation_markdown(summary), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
