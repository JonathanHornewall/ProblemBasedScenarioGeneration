"""Freeze only the four requested reruns; preserve all original seed grids."""
import copy
import hashlib
import json
from pathlib import Path
import sys

from build_central_path_final import read, write, sha

ROOT = Path(__file__).resolve().parents[1]
METHODS = ("mse", "wise", "spo_plus", "central_path_barrier_validation")


def build(destination):
    if (destination / "screen.json").exists():
        raise RuntimeError("Refusing to overwrite a frozen campaign")
    roots = [ROOT.parent / "ProximalSPO-final-20260922/runs/central_path_final_20260922/hornewall/retrieved",
             ROOT.parent / "ProximalSPO-extension-20260923/runs/central_path_extension_20260923/hornewall/retrieved"]
    cells, jobs, sources = {}, [], {}
    for source in roots:
        path = source / "screen.json"
        manifest = read(path)
        sources[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        for original in manifest["jobs"]:
            if original["method"] not in METHODS:
                continue
            job = copy.deepcopy(original)
            cells[job["cell"]] = manifest["cells"][job["cell"]]
            job["protocol_revision"] = "physical_relaxed_spo_conditional_validation_v1"
            job["source_candidate"] = original["candidate"]
            job["config"]["evaluate_test"] = False
            job["validation_costs"] = "conditional_mean"
            if job["method"] in ("mse", "wise", "spo_plus"):
                job["baseline_protocol"] = "physical_cold_highs_v1"
                job["config"]["method"] = job["method"]
                job["config"]["cost_coordinate_normalization"] = "none"
                job["spo_training_domain"] = "continuous_relaxation" if job["method"] == "spo_plus" else None
            identity = sha({"config":job["config"], "method":job["method"],
                            "revision":job["protocol_revision"]})[:16]
            job.update(candidate=identity, id=f"screen__{job['cell']}__{job['method']}__{identity}")
            job["config"]["name"] = job["id"]
            jobs.append(job)
    assert len(cells) == 35
    jobs.sort(key=lambda j: (j.get("arm_order", 0), j["cell"], j["method"]))
    write(destination / "screen.json", {"schema":"canonical_targeted_rerun_v1", "cells":cells,
        "methods":list(METHODS), "jobs":jobs, "source_sha256":sources,
        "protocol":{"per_cell_method_pipeline":True, "extra_continuous_conditional_tuning":False,
            "original_seed_bundles_preserved":True, "preprocessing_cap_seconds":3600,
            "job_wall_cap_seconds":21600, "training_cap_seconds":3600,
            "method_waves":[["mse","wise"],["spo_plus"],["central_path_barrier_validation"]],
            "refinement":"Three original seeds, top three original-grid candidates",
            "confirmation":"Ten original seeds; frozen configuration and epoch horizon",
            "barrier_selection":"Conditional-mean cost plus barrier within mu; conditional-mean regret between mu",
            "hard_validation_results":"Preserved, already conditional mean throughout",
            "spo_training_domain":"continuous_relaxation", "deployment_domain":"original LP/MIP",
            "final_timing":"Separate sequential Mac training fits after selection; optimizer-only wall and CPU time",
            "cloud_combined_ceiling_usd":100, "cloud_maximum_lifetime_hours":6}})
    write(destination / "burst_contract.json", {"run_id":destination.name,
        "groups":[list(x) for x in sorted({(j['cell'],j['method']) for j in jobs})],
        "maximum_workers":230, "maximum_seconds":14400})
    return jobs


if __name__ == "__main__":
    from collections import Counter
    jobs = build(Path(sys.argv[1]).resolve())
    print(json.dumps(dict(Counter(j["method"] for j in jobs))))
