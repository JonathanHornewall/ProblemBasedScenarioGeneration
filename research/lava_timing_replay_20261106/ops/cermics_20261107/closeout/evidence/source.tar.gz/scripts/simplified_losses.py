"""New-campaign WiSE adapters around the maintained objectives/public losses.

The public loss is called once per collated minibatch (including NCE's shared
solution-pool/RNG update). Only stateless LAVA is sliced after batch collation.
"""
from __future__ import annotations

from dataclasses import replace

import numpy as np
import torch


def normalize_costs(costs):
    costs = np.asarray(costs, dtype=np.float64)
    norms = np.linalg.norm(costs, axis=1)
    directions = np.divide(costs, norms[:, None], out=np.zeros_like(costs),
                           where=norms[:, None] > 0)
    return directions, norms


def wise_cp_objective(spec, interface, train, deployment_problem):
    """Keep the chart/whitening/guard, calibrating only on normalized costs."""
    from proximal_spo.runner import _objective
    from proximal_spo.objectives import TorchBatchSignal

    normalized, norms = normalize_costs(train.physical_costs)
    targets = np.divide(train.target_values, norms, out=np.zeros_like(norms), where=norms > 0)
    calibration = replace(train, physical_costs=normalized, target_values=targets)
    objective = _objective(spec, interface, calibration, deployment_problem=deployment_problem)
    if not objective.torch_training:
        objective.close()
        raise ValueError("WiSE CP-SPO requires the maintained Torch policy kernel")
    ordinary_signal = objective.torch_signal

    def signal(outputs, physical_costs, target_values, policy_reduced_costs=None, policy_center_costs=None):
        base = ordinary_signal(outputs, physical_costs, target_values,
                               policy_reduced_costs, policy_center_costs)
        weights = torch.linalg.vector_norm(physical_costs, dim=1)
        contribution = weights * float(objective.mu) * base.components['barrier_energy']
        # The raw target objective is the usual parameter-independent offset.
        # Exact zero-cost observations therefore have zero value and gradient.
        return TorchBatchSignal(base.components['linear_regret'] + contribution,
            base.stats, base.decisions, components={**base.components,
                'barrier_contribution': contribution, 'wise_norm': weights})

    ordinary_receipt = objective.receipt
    objective.torch_signal = signal
    objective.receipt = lambda: {**ordinary_receipt(), 'wise_adaptation': True,
        'wise_formula': 'mean(c^T z - raw_lp_target + norm(c) * mu_W * R(z))',
        'wise_calibration': 'training-only median normalized analytic-center regret',
        'whole_surrogate_weighted': True, 'predicted_cost_normalization': False}
    return objective


def public_loss(method, model, parameters, dataset, perturbation_seed, *, weighted):
    from extension_losses import create_loss
    loss = create_loss(method, model, parameters, dataset)
    if weighted and method in ('spo_plus', 'pfyl', 'nce'):
        # create_loss_func does not forward arbitrary constructor arguments.
        # This is a supported public setting in pinned PyEPO 1.0.2.
        loss.reduction = 'none'
    if method == 'pfyl':
        loss.rnd = np.random.RandomState(perturbation_seed)
    return loss


def batch_loss(method, loss, prediction, batch, *, weights=None):
    if method == 'spo_plus':
        values = loss(prediction, batch[1], batch[2], batch[3])
    elif method in ('pfyl', 'nce'):
        values = loss(prediction, batch[2])
    elif method == 'lava':
        if weights is None:
            return loss(prediction, batch[7], batch[4], -1.0)
        # Preserve the full padded vertex axis and public threshold behavior.
        values = torch.stack([loss(prediction[i:i+1], batch[7][i:i+1],
                                   batch[4][i:i+1], -1.0)
                              for i in range(len(prediction))])
    else:
        raise ValueError(method)
    if weights is None:
        return values
    if values.numel() != len(prediction):
        raise ValueError('Public loss did not return one value per example')
    return (values.reshape(-1) * weights).mean()


def wise_mse(prediction, normalized_costs, norms):
    return (norms * (prediction - normalized_costs).square().sum(dim=1)).mean()
