#!/usr/bin/env python3
# ruff: noqa: E501
"""Package a frozen campaign and generate its bounded Google Cloud launch."""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import subprocess
import tarfile
import time
from pathlib import Path

from build_central_path_final import read, write

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "runs/central_path_final_20260922"
DEST = RUN / "hornewall"
RUN_ID = "central-path-final-20260922"
BUCKET = "hornewall-central-path-final-20260922"


def main():
    # Retries share the original cost window; never silently reset the timer.
    prior = read(DEST / "budget.json") if (DEST / "budget.json").exists() else {}
    deadline = prior.get("deadline_unix", int(time.time() + 13 * 3600))
    budget = {
        "run_id": RUN_ID,
        "bucket": BUCKET,
        "instance": RUN_ID + "-0",
        "project": "hornewall-compute",
        "configuration": "jonathan",
        "approved_maximum_usd": 50,
        "maximum_vm_hours": 13,
        "deadline_unix": deadline,
        "termination_time": dt.datetime.fromtimestamp(deadline, dt.UTC).isoformat(),
        "machine_type": "n2-standard-64",
        "vcpu": 64,
        "memory_gib": 256,
        "maximum_concurrency": 64,
        "boot_disk_gib": 100,
        "compute_usd_hour": 3.107776,
        "disk_usd_hour": 100 * 0.000136986,
        "ipv4_usd_hour": 0.005,
        "storage_and_network_reserve_usd": 3,
        "uncertainty_margin": 0.1,
        "conservative_commitment_usd": ((3.107776 + 100 * 0.000136986 + 0.005) * 13 + 3)
        * 1.1,
        "posted_account_gross_display": "SEK 5.48",
        "credit_remaining_display": "SEK 2847.97",
        "credit_expiry": "2026-12-11",
        "billing_verified_utc": dt.datetime.now(dt.UTC).isoformat(),
        "project_active_unposted_resources": [],
        "billing_inventory_limitation": "A second linked My First Project cannot be inventoried with the current account; its Compute API is disabled. The account-wide unposted balance is not asserted to be known.",
        "launch_authorization": "User explicitly authorized immediate Hornewall launch with complete authority subject to a USD 50 run limit; this supersedes the skill's requirement to block on missing linked-project inventory. This run has its own provider-enforced deletion deadline.",
    }
    assert budget["conservative_commitment_usd"] < budget["approved_maximum_usd"]
    write(DEST / "budget.json", budget)
    source = DEST / "source.tar.gz"
    subprocess.run(
        [
            "git",
            "archive",
            "--format=tar.gz",
            "--prefix=code/",
            "-o",
            str(DEST / "code.tar.gz"),
            "HEAD",
        ],
        cwd=ROOT,
        check=True,
    )
    receipt = read(RUN / "staging/source_receipt.json")
    receipt.update(
        previous_project_commit=receipt["project_commit"],
        project_commit=subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip(),
        change="Cloud scheduling, backups, and migration only; frozen scientific code and screen manifest unchanged",
    )
    receipt["files"] = {
        name: hashlib.sha256(path.read_bytes()).hexdigest()
        for name, path in {
            "code.tar.gz": DEST / "code.tar.gz",
            **{
                name: RUN / "staging" / name
                for name in (
                    "external.tar.gz",
                    "public.tar.gz",
                    "screen.json",
                    "preflight.json",
                    "requirements.lock",
                )
            },
        }.items()
    }
    write(DEST / "source_receipt.json", receipt)
    with tarfile.open(source, "w:gz", compresslevel=1) as archive:
        for name in (
            "external.tar.gz",
            "public.tar.gz",
            "screen.json",
            "preflight.json",
            "requirements.lock",
        ):
            archive.add(RUN / "staging" / name, arcname=name)
        for name in ("code.tar.gz", "budget.json", "source_receipt.json"):
            archive.add(DEST / name, arcname=name)
        for name in ("results", "geometry_cache"):
            archive.add(
                DEST / "migration" / name,
                arcname=name,
                filter=lambda info: (
                    None if Path(info.name).name.startswith(".") else info
                ),
            )
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    args = f"--root /opt/central-path --bucket {BUCKET} --run-id {RUN_ID} --deadline-unix {deadline}"
    supervisor = (ROOT / "scripts/central_path_cloud_vm.py").read_text()
    api = (ROOT / "scripts/atlanta_timing_vm.py").read_text()
    startup = f"""#!/bin/bash
set -euo pipefail
mkdir -p /opt/central-path/results /opt/cp-supervisor
exec > >(tee -a /opt/central-path/bootstrap.log) 2>&1
cat > /opt/cp-supervisor/atlanta_timing_vm.py <<'CP_API'
{api}
CP_API
cat > /opt/cp-supervisor/central_path_cloud_vm.py <<'CP_SUPERVISOR'
{supervisor}
CP_SUPERVISOR
cleanup_failure() {{ python3 /opt/cp-supervisor/central_path_cloud_vm.py {args} --failure-only; }}
trap cleanup_failure ERR
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3 curl git ca-certificates
python3 - <<'CP_DOWNLOAD'
import hashlib,json,tarfile,urllib.request
from pathlib import Path
req=urllib.request.Request('http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token',headers={{'Metadata-Flavor':'Google'}})
token=json.loads(urllib.request.urlopen(req,timeout=15).read())['access_token']
req=urllib.request.Request('https://storage.googleapis.com/{BUCKET}/source.tar.gz',headers={{'Authorization':'Bearer '+token}})
data=urllib.request.urlopen(req,timeout=300).read()
assert hashlib.sha256(data).hexdigest()=='{digest}'
path=Path('/opt/source.tar.gz'); path.write_bytes(data)
with tarfile.open(path) as tar: tar.extractall('/opt/central-path')
root=Path('/opt/central-path')
for name in ('code','external','public'):
 destination=root if name=='code' else root/name
 destination.mkdir(exist_ok=True)
 with tarfile.open(root/(name+'.tar.gz')) as tar: tar.extractall(destination)
CP_DOWNLOAD
bash /opt/central-path/code/scripts/bootstrap_central_path_final.sh /opt/central-path
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONUNBUFFERED=1
export PYTHONPATH=/opt/central-path/code/src:/opt/central-path/external/src
export SOLVER_FREE_DFL_REPO=/opt/central-path/public DFL_EXTENSIONS_SRC=/opt/central-path/external/src
export ATLANTA_SOURCE_MANIFEST=/opt/central-path/source_receipt.json
/opt/central-path/venv/bin/python - <<'CP_PREFLIGHT'
import json,subprocess,os
from pathlib import Path
r=Path('/opt/central-path')
j=json.loads((r/'screen.json').read_text())['jobs']
selected={{}}
for i,job in enumerate(j):
 if job['route']=='dys_shortest_path_5x5': selected.setdefault(job['method'],i)
assert len(selected)==9
for method,i in selected.items():
 subprocess.run([str(r/'venv/bin/python'),str(r/'code/scripts/run_central_path_final.py'),'--manifest',str(r/'screen.json'),'--job-index',str(i),'--output-root',str(r/'results/cloud_preflight'),'--smoke'],check=True,env=os.environ)
print('CLOUD_PREFLIGHT_PASSED',len(selected),flush=True)
CP_PREFLIGHT
trap - ERR
exec /opt/central-path/venv/bin/python /opt/cp-supervisor/central_path_cloud_vm.py {args}
"""
    (DEST / "startup.sh").write_text(startup)
    write(
        DEST / "launch.json",
        {
            "budget": budget,
            "source_sha256": digest,
            "source_bytes": source.stat().st_size,
        },
    )
    write(
        DEST / "lifecycle.json",
        {"rule": [{"action": {"type": "Delete"}, "condition": {"age": 7}}]},
    )
    print(
        json.dumps(
            {
                "bytes": source.stat().st_size,
                "sha256": digest,
                "budget_usd": budget["conservative_commitment_usd"],
                "deadline": budget["termination_time"],
            }
        )
    )


if __name__ == "__main__":
    main()
