#!/usr/bin/env python3
"""Run the released public SFGE implementation on one paper route/seed.

The route, source split, data seed, and network seed come from the matched
paper manifest.  SFGE's own Gaussian module and ``training_step`` are retained
unchanged; only the benchmark facade and conditional-mean evaluation are
adapted.  Test reference solves are delayed until after validation checkpoint
selection.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
import random
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[1]
MANIFEST_ROOT = Path("/private/tmp/dfl-single-stage-suite-bd6026b/src")


def _load_manifest(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("entries"), list):
        raise ValueError("matched manifest must contain an entries list")
    return value


def _hash_array(value: Any) -> str:
    array = np.ascontiguousarray(np.asarray(value))
    digest = hashlib.sha256()
    digest.update(str(array.dtype).encode("ascii"))
    digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
    digest.update(array.view(np.uint8))
    return digest.hexdigest()


def _write_progress(
    path: Path | None,
    receipt: dict[str, Any],
    trained: list[dict[str, Any]],
    requested_count: int,
    *,
    final: bool = False,
) -> None:
    """Publish arm-level progress without serializing live torch modules."""

    if path is None:
        return
    arms = [
        {key: value for key, value in row.items() if key != "module"}
        for row in trained
    ]
    terminal = len(arms) >= requested_count and all(
        row.get("status") in {"trained", "failed", "complete"} for row in arms
    )
    payload = dict(receipt)
    if terminal:
        if all(row.get("status") in {"trained", "complete"} for row in arms):
            progress_status = "complete"
        elif any(row.get("status") in {"trained", "complete"} for row in arms):
            progress_status = "partial_failure"
        else:
            progress_status = "failed"
    else:
        progress_status = "in_progress"
    if progress_status == "complete" and receipt.get("test_access") and not final:
        progress_status = "in_progress"
    payload.update(
        {
            "status": progress_status,
            "arms": arms,
            "progress": {
                "completed_arms": len(arms),
                "requested_arms": requested_count,
                "arms_complete": terminal,
                "final_receipt_written": bool(final),
            },
        }
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    temporary.replace(path)


def _seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def _parse_csv(value: str, cast: Any = float) -> list[Any]:
    items = [item.strip() for item in value.split(",") if item.strip()]
    if not items:
        raise argparse.ArgumentTypeError("at least one value is required")
    return [cast(item) for item in items]


def _public_parts() -> tuple[Any, Any, Any, Any, Any, Any]:
    from run_public_sfge_external import (
        EXTERNAL_SRC,
        PUBLIC_REPO,
        _ArrayDataset,
        _PublicLinearProblem,
        _build_public_problem,
        _tree_hash,
    )

    return (
        PUBLIC_REPO,
        EXTERNAL_SRC,
        _ArrayDataset,
        _PublicLinearProblem,
        _build_public_problem,
        _tree_hash,
    )


def _prediction(module: Any, contexts: np.ndarray) -> np.ndarray:
    module.eval()
    with torch.no_grad():
        x = torch.as_tensor(np.asarray(contexts), dtype=torch.float32)
        output = module.net(x=x, sample=False, return_scaled=True)
        prediction = output[1] if isinstance(output, tuple) else output
    return prediction.detach().cpu().numpy().astype(np.float64, copy=False)


def _evaluate_with_reference(
    module: Any,
    contexts: np.ndarray,
    conditional_costs: np.ndarray,
    solver: Any,
    reference: np.ndarray,
) -> tuple[float, dict[str, Any]]:
    prediction = _prediction(module, contexts)
    deployed = solver.solve_many(prediction)
    values = np.sum(np.asarray(conditional_costs, dtype=np.float64) * deployed.decisions, axis=1)
    reference = np.asarray(reference, dtype=np.float64)
    regret = values - reference
    tolerance = 5e-7 * (
        1.0 + np.abs(reference) + np.sum(np.abs(conditional_costs), axis=1)
    )
    if np.any(regret < -tolerance):
        raise RuntimeError(f"materially negative conditional regret {regret.min():.3e}")
    regret = np.maximum(regret, 0.0)
    denominator = float(np.mean(np.abs(reference)))
    return float(np.mean(regret) / denominator), {
        "mean_regret": float(np.mean(regret)),
        "normalized_regret": float(np.mean(regret) / denominator),
        "median_regret": float(np.median(regret)),
        "maximum_regret": float(np.max(regret)),
        "positive_regret_rate": float(np.mean(regret > 1e-8)),
        "sample_count": int(len(regret)),
        "solver_seconds": float(deployed.stats.solver_seconds),
        "oracle_calls": int(deployed.stats.calls),
    }


def _arms(
    sigmas: list[float],
    learning_rates: list[float],
    standardize_values: list[bool],
    sce_losses: list[bool],
) -> list[dict[str, Any]]:
    return [
        {
            "name": (
                f"SFGE_sigma{sigma:g}_lr{lr:g}_std{int(std)}_sce{int(sce)}"
            ),
            "sigma": sigma,
            "lr": lr,
            "standardize_batch_values": std,
            "sce_loss": sce,
        }
        for sigma in sigmas
        for lr in learning_rates
        for std in standardize_values
        for sce in sce_losses
    ]


def _train_arm(
    entry: dict[str, Any],
    training_problem: Any,
    evaluation_solver: Any,
    train: Any,
    validation_contexts: np.ndarray,
    validation_costs: np.ndarray,
    validation_reference: np.ndarray,
    arm: dict[str, Any],
    *,
    seed: int,
    epochs: int,
    batch_size: int,
    evaluate_test: bool = False,
) -> dict[str, Any]:
    public_repo, _, _, _, _, _ = _public_parts()
    sys.path.insert(0, str(public_repo))
    # The public SFGE checkout uses a namespace-style ``data`` directory,
    # while the pinned Solver-Free checkout (also present on the campaign
    # PYTHONPATH for the other arms) owns a conventional top-level ``data``
    # package.  Importing the public utility by path avoids that unrelated
    # package collision without modifying either public checkout.
    import importlib.util

    utility_path = public_repo / "data/generation_scripts/utility.py"
    utility_spec = importlib.util.spec_from_file_location(
        "sfge_public_generation_utility", utility_path
    )
    if utility_spec is None or utility_spec.loader is None:
        raise ImportError(f"cannot load public SFGE utility: {utility_path}")
    utility_module = importlib.util.module_from_spec(utility_spec)
    utility_spec.loader.exec_module(utility_module)
    set_seeds = utility_module.set_seeds
    from methods.sfge import SFGEModule
    from utils.probabilistic_models import MultivariateGaussianModule
    from utils.scale_layer import ScaleLayer
    from proximal_spo.models import ModelSpec, StandardizedMLP, input_statistics

    set_seeds(seed)
    torch.set_num_threads(2)
    model_raw = {
        **dict(entry.get("model") or {}),
        **dict(arm.get("model") or {}),
    }
    model_spec = ModelSpec(
        width=int(model_raw.get("width", 64)),
        depth=int(model_raw.get("depth", 2)),
        activation=str(model_raw.get("activation", "silu")),
        layer_norm=bool(model_raw.get("layer_norm", False)),
        dtype="float32",
    )
    input_mean, input_scale = input_statistics(np.asarray(train.feats))
    net = StandardizedMLP(
        int(train.x.shape[1]),
        int(train.y.shape[1]),
        model_spec,
        input_mean=input_mean,
        input_scale=input_scale,
        output_bias=np.zeros(int(train.y.shape[1]), dtype=np.float32),
    )
    cost_mean = np.asarray(train.costs, dtype=np.float64).mean(axis=0)
    cost_scale = np.asarray(train.costs, dtype=np.float64).std(axis=0)
    cost_scale = np.where(cost_scale < 1e-8, 1.0, cost_scale)
    gaussian = MultivariateGaussianModule(
        net=net,
        scale_layer=ScaleLayer(
            translation_term=cost_mean.astype(np.float32),
            multiplication_factor=cost_scale.astype(np.float32),
        ),
        input_shape=int(train.x.shape[1]),
        output_shape=int(train.y.shape[1]),
        init_std_dev_val=math.log(float(arm["sigma"])),
        covariance_type="static",
    )
    module = SFGEModule(
        net=gaussian,
        optimization_problem=training_problem,
        annealer=None,
        lr=float(arm["lr"]),
        sce_loss=bool(arm["sce_loss"]),
        std_batch_vals=bool(arm["standardize_batch_values"]),
    )
    batch_size = int(arm.get("batch_size", batch_size))
    epochs = int(arm.get("epochs", epochs))
    loader = DataLoader(train, batch_size=min(batch_size, len(train)), shuffle=True)
    optimizer = torch.optim.Adam(module.parameters(), lr=float(arm["lr"]))
    best_state: dict[str, torch.Tensor] | None = None
    best_val = float("inf")
    best_epoch = 0
    curves: list[dict[str, Any]] = []
    started = time.perf_counter()
    for epoch in range(1, epochs + 1):
        module.train()
        for batch_index, batch in enumerate(loader):
            value = module.training_step(batch, batch_index)
            if not torch.isfinite(value):
                raise RuntimeError(f"non-finite SFGE loss at epoch {epoch}")
            optimizer.zero_grad(set_to_none=True)
            value.backward()
            torch.nn.utils.clip_grad_norm_(module.parameters(), 10.0)
            optimizer.step()
        val_value, val_metrics = _evaluate_with_reference(
            module,
            validation_contexts,
            validation_costs,
            evaluation_solver,
            validation_reference,
        )
        curves.append({"epoch": epoch, "validation": val_metrics})
        if val_value < best_val:
            best_val = val_value
            best_epoch = epoch
            best_state = {
                key: value.detach().cpu().clone()
                for key, value in module.state_dict().items()
            }
    if best_state is None:
        raise RuntimeError("SFGE produced no validation checkpoint")
    module.load_state_dict(best_state)
    result = {
        **arm,
        "status": "trained",
        "best_epoch": best_epoch,
        "validation_regret": best_val,
        "training_wall_seconds": time.perf_counter() - started,
        "curves": curves,
        "module": module,
    }
    if evaluate_test:
        raise RuntimeError(
            "_train_arm test evaluation is intentionally delegated to run_entry "
            "after validation selection"
        )
    return result


def run_entry(
    entry: dict[str, Any],
    *,
    sigmas: list[float],
    learning_rates: list[float],
    standardize_values: list[bool],
    sce_losses: list[bool],
    epochs_override: int | None,
    batch_size_override: int | None,
    evaluate_test: bool = True,
    progress_path: Path | None = None,
) -> dict[str, Any]:
    started = time.perf_counter()
    public_repo, external_src, ArrayDataset, _, build_public_problem, tree_hash = _public_parts()
    sys.path.insert(0, str(ROOT / "src"))
    sys.path.insert(0, str(external_src))
    from dfl_extensions_lab.benchmarks import SplitSizes
    from proximal_spo.external_benchmarks import load_external_benchmark

    receipt: dict[str, Any] = {
        "kind": "paper_public_sfge_matched_run",
        "route_id": entry["route_id"],
        "benchmark_id": entry["benchmark_id"],
        "source_config": entry.get("source_config"),
        "seeds": entry["seeds"],
        "sizes": entry["sizes"],
        "test_access": bool(evaluate_test),
        "protocol": {
            "public_sfge_training_step": True,
            "train_on_continuous_relaxation": True,
            "hard_integer_evaluation": True,
            "test_used_for_selection": False,
            "test_reference_solved_after_selection": True,
            "metric": "conditional_mean_normalized_decision_regret",
            "cost_coordinates": "standardized_train_split_beta_mapped_to_physical_cost",
            "raw_data_persisted": False,
            "raw_weights_persisted": False,
        },
    }
    try:
        sizes = entry["sizes"]
        loaded = load_external_benchmark(
            str(entry["benchmark_id"]),
            SplitSizes(int(sizes["train"]), int(sizes["validation"]), int(sizes["test"])),
            data_seed=int(entry["seeds"]["data"]),
            conditional_reference_samples=int(entry["conditional_reference_samples"]),
        )
        relaxed = loaded.problem.continuous_relaxation(
            name=f"{loaded.problem.name}.continuous_training"
        )
        training_problem, _ = build_public_problem(relaxed)
        evaluation_problem, evaluation_solver = build_public_problem(loaded.problem)
        train_costs = np.asarray(loaded.dataset.train.physical_costs, dtype=np.float64)
        cost_mean = train_costs.mean(axis=0)
        cost_scale = train_costs.std(axis=0)
        cost_scale = np.where(cost_scale < 1e-8, 1.0, cost_scale)
        train = ArrayDataset(
            loaded.dataset.train.contexts,
            train_costs,
            # SFGE's public training step requires an LP optimal solution for
            # each observed training cost.  The released implementation uses
            # standardized targets for the Gaussian and unscales its sampled
            # report before calling the oracle.
            _solve_targets(relaxed, train_costs),
            scaled_costs=(train_costs - cost_mean) / cost_scale,
        )
        val_contexts = loaded.dataset.validation.contexts
        val_costs = loaded.dataset.validation.conditional_mean_costs
        val_reference = evaluation_solver.solve_many(val_costs).objectives
        receipt["dataset"] = {
            "train_context_sha256": _hash_array(loaded.dataset.train.contexts),
            "train_cost_sha256": _hash_array(loaded.dataset.train.physical_costs),
            "validation_context_sha256": _hash_array(val_contexts),
            "evaluation_problem": loaded.problem.name,
            "training_problem": relaxed.name,
            "evaluation_integral_variables": int(np.sum(loaded.problem.integrality)),
            "training_integral_variables": 0,
            "cost_coordinate_mean_sha256": _hash_array(cost_mean),
            "cost_coordinate_scale_sha256": _hash_array(cost_scale),
            "cost_coordinate_source": "training physical-cost mean/std; public ScaleLayer",
        }
        training_spec = dict(entry.get("training") or {})
        epochs = int(epochs_override or training_spec.get("epochs", 100))
        batch_size = int(batch_size_override or training_spec.get("batch_size", 64))
        trained: list[dict[str, Any]] = []
        requested_arms = _arms(sigmas, learning_rates, standardize_values, sce_losses)
        _write_progress(progress_path, receipt, trained, len(requested_arms))
        for arm in requested_arms:
            try:
                trained.append(
                    _train_arm(
                        entry,
                        training_problem,
                        evaluation_solver,
                        train,
                        val_contexts,
                        val_costs,
                        val_reference,
                        arm,
                        seed=int(entry["seeds"]["initialization"]),
                        epochs=epochs,
                        batch_size=batch_size,
                    )
                )
            except BaseException as error:
                trained.append({
                    **arm,
                    "status": "failed",
                    "error_type": type(error).__name__,
                    "error": str(error),
                })
            _write_progress(progress_path, receipt, trained, len(requested_arms))
        valid = [row for row in trained if row.get("status") == "trained"]
        if not valid:
            for row in trained:
                row.pop("module", None)
            receipt["arms"] = trained
            raise RuntimeError("all SFGE arms failed")
        selected = min(valid, key=lambda row: float(row["validation_regret"]))
        test_value = None
        test_metrics = None
        if evaluate_test:
            test_costs = loaded.dataset.test.conditional_mean_costs
            test_reference = evaluation_solver.solve_many(test_costs).objectives
            test_value, test_metrics = _evaluate_with_reference(
                selected["module"],
                loaded.dataset.test.contexts,
                test_costs,
                evaluation_solver,
                test_reference,
            )
        for row in trained:
            row.pop("module", None)
        receipt.update({
            "status": "complete" if len(valid) == len(trained) else "partial_failure",
            "training": {
                "epochs": epochs,
                "batch_size": batch_size,
                "arms": len(trained),
                "selected_arm": selected["name"],
            },
            "arms": trained,
            "selected_test_regret": test_value,
            "selected_test_metrics": test_metrics,
            "test_access": bool(evaluate_test),
            "source": {
                "sfge_repository": str(public_repo),
                "sfge_commit": subprocess.check_output(
                    ["git", "rev-parse", "HEAD"], cwd=public_repo, text=True
                ).strip(),
                "sfge_tree_sha256": tree_hash(public_repo),
                "external_source": str(external_src),
            },
        })
        _write_progress(progress_path, receipt, trained, len(requested_arms), final=True)
    except BaseException as error:
        receipt.update({
            "status": "failed",
            "error_type": type(error).__name__,
            "error": str(error),
        })
    receipt["wall_seconds"] = time.perf_counter() - started
    if progress_path is not None and receipt.get("status") == "failed":
        _write_progress(
            progress_path,
            receipt,
            receipt.get("arms", []),
            len(receipt.get("arms", [])),
            final=True,
        )
    return receipt


def _solve_targets(problem: Any, costs: np.ndarray) -> np.ndarray:
    from proximal_spo.oracles import PersistentLPSolver

    solver = PersistentLPSolver(problem, random_seed=0)
    return solver.solve_many(np.asarray(costs, dtype=np.float64)).decisions.astype(np.float32)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--entry-index", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--sigmas", default="0.3")
    parser.add_argument("--learning-rates", default="0.01")
    parser.add_argument("--standardize-values", default="1")
    parser.add_argument("--sce-losses", default="0")
    parser.add_argument("--epochs", type=int)
    parser.add_argument("--batch-size", type=int)
    parser.add_argument("--progress", type=Path)
    parser.add_argument(
        "--validation-only",
        action="store_true",
        help="select arms from validation without opening the test split/oracle",
    )
    args = parser.parse_args()
    manifest = _load_manifest(args.manifest)
    if not 0 <= args.entry_index < len(manifest["entries"]):
        raise IndexError("entry index outside manifest")
    standardize = [bool(int(value)) for value in _parse_csv(args.standardize_values, int)]
    sce = [bool(int(value)) for value in _parse_csv(args.sce_losses, int)]
    receipt = run_entry(
        manifest["entries"][args.entry_index],
        sigmas=_parse_csv(args.sigmas, float),
        learning_rates=_parse_csv(args.learning_rates, float),
        standardize_values=standardize,
        sce_losses=sce,
        epochs_override=args.epochs,
        batch_size_override=args.batch_size,
        evaluate_test=not args.validation_only,
        progress_path=args.progress,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return 0 if receipt["status"] == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
