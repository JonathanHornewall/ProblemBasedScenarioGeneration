"""Durable Mac relay: exclusive leases, verified imports, exact cloud cleanup."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import fcntl
import hashlib
import json
import shlex
import subprocess
import time
from pathlib import Path

from build_central_path_final import read, write


def run(args, **kwargs):
    return subprocess.check_output(args,text=True,timeout=180,**kwargs)


class Relay:
    def __init__(self, root):
        self.root = root
        self.config = read(root/'fleet.json')
        self.cluster = self.config['cluster_root']
        self.state_path = root/'relay_state.json'
        self.state = read(self.state_path) if self.state_path.exists() else {'hosts':{}}

    def cluster_cmd(self, command):
        return run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','shared_cluster',command])

    def ssh_options(self, host):
        return ['ssh','-i',self.config['ssh_key'],'-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15',
                '-o','StrictHostKeyChecking=accept-new','-o','UserKnownHostsFile='+str(self.root/'known_hosts')]

    def ssh(self, host, command):
        return run([*self.ssh_options(host),host['ssh_target'],command])

    def sync(self, source, target, host=None, extra=()):
        transport = shlex.join(self.ssh_options(host)) if host else 'ssh -o BatchMode=yes -o ConnectTimeout=15'
        return run(['rsync','-az','--timeout=90','-e',transport,*extra,source,target])

    def import_results(self, name, host, final=False):
        return json.loads(self.cluster_cmd(shlex.join([self.cluster+'/venv/bin/python',self.cluster+'/code/scripts/canonical_pull_cloud.py','--root',self.cluster,'--host',name,*(['--final'] if final else [])])))

    def legacy_mac_import(self, name, host, final=False):
        remote = host['root']
        local = self.root/name/'retrieved'
        local.mkdir(parents=True,exist_ok=True)
        self.ssh(host,shlex.join([remote+'/venv/bin/python',remote+'/code/scripts/canonical_snapshot.py','--root',remote,*(['--final'] if final else [])]))
        self.sync(host['ssh_target']+':'+remote+'/results/',str(local/'results')+'/',host)
        self.sync(host['ssh_target']+':'+remote+'/retrieval_hashes.json',str(local/'retrieval_hashes.json'),host)
        hashes = read(local/'retrieval_hashes.json')
        for filename, digest in hashes.items():
            if hashlib.sha256((local/filename).read_bytes()).hexdigest() != digest:
                raise ValueError('Retrieval checksum mismatch: '+filename)
        # Artifacts precede receipts: selectors can never observe an incomplete import.
        self.sync(str(local/'results')+'/',f'shared_cluster:{self.cluster}/results/',extra=('--exclude=receipts/','--exclude=queue_status.json','--exclude=progress/'))
        incoming = self.cluster+'/imports/'+name
        self.cluster_cmd('mkdir -p '+shlex.quote(incoming))
        receipts = local/'results/receipts'
        if receipts.exists():
            self.sync(str(receipts)+'/',f'shared_cluster:{incoming}/')
            self.cluster_cmd(shlex.join([self.cluster+'/venv/bin/python',self.cluster+'/code/scripts/canonical_import.py','--root',self.cluster,'--host',name]))
        return {'verified_files':len(hashes),'receipts':len(list(receipts.glob('*.json'))),'verified_unix':time.time()}

    def refill(self, name, host):
        local = self.root/name
        self.cluster_cmd(shlex.join([self.cluster+'/venv/bin/python',self.cluster+'/code/scripts/canonical_cluster.py','lease','--root',self.cluster,'--host',name,'--count',str(host['workers']+max(2,host['workers']//4))]))
        self.sync(f'shared_cluster:{self.cluster}/leases/{name}.json',str(local/'execution.json'))
        self.cluster_cmd(shlex.join([self.cluster+'/venv/bin/python',self.cluster+'/code/scripts/canonical_push_data.py','--root',self.cluster,'--host',name]))
        return len(read(local/'execution.json')['jobs'])

    def finish(self, name, host):
        self.ssh(host,'touch '+shlex.quote(host['root']+'/STOP'))
        status = json.loads(self.ssh(host,'cat '+shlex.quote(host['root']+'/worker_state.json')))
        if status['status'] != 'stopped':
            return {'status':'stopping','updated_unix':time.time()}
        verified = self.import_results(name,host,final=True)
        base = ['gcloud','--configuration='+host['configuration'],'--project='+host['project'],'compute','instances']
        details = json.loads(run([*base,'describe',host['instance'],'--zone='+host['zone'],'--format=json']))
        if str(details['id']) != str(host['instance_id']):
            raise ValueError('Instance identity changed; refusing cleanup')
        run([*base,'delete',host['instance'],'--zone='+host['zone'],'--quiet'])
        remaining = json.loads(run([*base,'list','--filter=name='+host['instance'],'--format=json']))
        disks = json.loads(run(['gcloud','--configuration='+host['configuration'],'--project='+host['project'],'compute','disks','list','--filter=name='+host['instance'],'--format=json']))
        if remaining or disks:
            raise ValueError('Run resource remains after deletion')
        return {'status':'deleted','verified':verified,'finished_unix':time.time()}

    def host_tick(self, name, host, complete):
        old = self.state['hosts'].get(name,{})
        if old.get('status') == 'deleted':
            return old
        if not host.get('ready'):
            return {'status':'awaiting_setup','updated_unix':time.time()}
        try:
            worker = json.loads(self.ssh(host,'cat '+shlex.quote(host['root']+'/worker_state.json')))
            if complete or worker.get('status') == 'stopped' or time.time() >= host['scientific_deadline_unix']:
                return self.finish(name,host)
            result = self.import_results(name,host)
            result.update(status='active',leased_jobs=self.refill(name,host),updated_unix=time.time())
            return result
        except Exception as e:
            return {**old,'last_error':str(e),'error_unix':time.time()}

    def tick(self):
        self.config = read(self.root/'fleet.json')
        cluster_state = json.loads(self.cluster_cmd('cat '+shlex.quote(self.cluster+'/burst_state.json')))
        complete = cluster_state.get('status') == 'complete'
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = {name:pool.submit(self.host_tick,name,host,complete) for name,host in self.config['hosts'].items()}
            for name, future in futures.items():
                self.state['hosts'][name] = future.result()
        self.state.update(updated_unix=time.time(),cluster=cluster_state)
        write(self.state_path,self.state)
        return complete and all(x.get('status') == 'deleted' for x in self.state['hosts'].values())


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--once',action='store_true')
    args = p.parse_args()
    guard = (args.root/'relay.lock').open('a')
    fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
    relay = Relay(args.root)
    while True:
        try:
            if relay.tick() or args.once:
                break
        except Exception as e:
            write(args.root/'relay_error.json',{'error':str(e),'time':time.time()})
        time.sleep(15)
