#!/usr/bin/env python
"""Build a matched official-PyEPO replay from a frozen SPO+ manifest."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any


def build_campaign(
    source: dict[str, Any], *, seed_suffix: str | None
) -> dict[str, Any]:
    variants = source.get("variants")
    if not isinstance(variants, list):
        raise ValueError("source campaign has no variants")
    selected: list[dict[str, Any]] = []
    for raw in variants:
        if not isinstance(raw, dict) or raw.get("method") != "spo_plus":
            continue
        name = str(raw.get("name", ""))
        if seed_suffix is not None and not name.endswith(seed_suffix):
            continue
        variant = copy.deepcopy(raw)
        variant["method"] = "pyepo_spo_plus"
        variant["method_parameters"] = {}
        variant["workers"] = 1
        seed_label = name.rsplit("_", 1)[-1]
        variant["name"] = f"pyepo_canonical_{variant['benchmark_id']}_{seed_label}"
        selected.append(variant)
    if not selected:
        raise ValueError("no matching SPO+ variants found")
    route_seed_pairs = {
        (str(item["benchmark_id"]), int(item["seeds"]["data"])) for item in selected
    }
    if len(route_seed_pairs) != len(selected):
        raise ValueError("selected campaign contains duplicate route/seed pairs")
    return {
        "base": {},
        "design": {
            "purpose": "post_hoc_official_pyepo_spoplus_implementation_audit",
            "source_campaign": source.get("name"),
            "source_manifest_method": "spo_plus",
            "replacement_method": "pyepo_spo_plus",
            "hyperparameters_changed": False,
            "test_already_opened_in_source_campaign": True,
            "selection_role": "implementation_replay_not_model_selection",
            "seed_suffix": seed_suffix,
            "route_count": len({item["benchmark_id"] for item in selected}),
            "variant_count": len(selected),
        },
        "name": "pyepo_canonical_continuous_audit",
        "run_root": "results/campaigns/pyepo_canonical_continuous_audit",
        "variants": selected,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--all-seeds",
        action="store_true",
        help="retain every frozen seed instead of the seed-1 route audit",
    )
    arguments = parser.parse_args()
    source = json.loads(arguments.source.read_text(encoding="utf-8"))
    campaign = build_campaign(
        source,
        seed_suffix=None if arguments.all_seeds else "_seed1",
    )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(
        json.dumps(campaign, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(
        f"wrote {campaign['design']['variant_count']} variants across "
        f"{campaign['design']['route_count']} routes to {arguments.output}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
