"""Add fixed baseline grids and direct LP policies without reopening completed fits."""

from __future__ import annotations

import argparse
import copy
import hashlib
from collections import defaultdict
from pathlib import Path

from build_central_path_final import METHODS, SCREEN_STAGES, read, setting, sha, write

MDKP = "pyepo_mdkp32x2_degree_6_noise_0_5_seed_0"
DIRECT_METHODS = (
    "direct_projection",
    "rayen_policy",
    "soft_radial_policy",
    "log_energy_policy",
)
DIRECT_ROUTES = ("dys_shortest_path_25x25", "lava_random_lp_400x50_released_code")
GRIDS = {
    "pfyl": [{"sigma": s, "n_samples": 1} for s in (0.01, 0.1, 1.0, 10.0)],
    "nce": [{"solve_ratio": p} for p in (0.01, 0.05, 0.2, 1.0)],
    "cave": [
        {"loss_type": "exact_cave", "solver": "clarabel"},
        *[
            {
                "loss_type": "inner_cave",
                "solver": "clarabel",
                "max_iter": k,
                "solve_ratio": 1.0,
                "inner_ratio": 0.2,
            }
            for k in (1, 3, 10)
        ],
        {
            "loss_type": "inner_cave",
            "solver": "clarabel",
            "max_iter": 3,
            "solve_ratio": 0.3,
            "inner_ratio": 0.2,
        },
    ],
    "lava": [{"threshold": -e, "vertex_tolerance": 0.0} for e in (0.0, 0.01, 0.1, 1.0)],
}


def build(completed_path, archive):
    completed = read(completed_path)
    if len(completed["cells"]) != 34:
        raise ValueError("expected the frozen 34-cell core campaign")
    cells = copy.deepcopy(completed["cells"])
    sources = {
        str(completed_path.resolve()): hashlib.sha256(
            completed_path.read_bytes()
        ).hexdigest()
    }
    common, cp = defaultdict(list), defaultdict(list)
    for job in completed["jobs"]:
        if job["stage"] != "screen":
            raise ValueError(
                "input must be the original screen, without outcome-based selection"
            )
        if job["method"] == "mse":
            common[job["cell"]].append(job)
        elif job["method"] == "central_path_hard_validation":
            cp[job["cell"]].append(job)

    old = defaultdict(dict)
    for stage in SCREEN_STAGES:
        for path in sorted((archive / stage).glob("*/config.json")):
            c = read(path)
            if c["benchmark_id"] != MDKP or c["method"] not in (
                "mse",
                "spo_plus",
                "spo_plus_relaxation",
                "soft_radial_log_barrier",
            ):
                continue
            sources[str(path.resolve())] = hashlib.sha256(path.read_bytes()).hexdigest()
            old[c["method"].replace("spo_plus_relaxation", "spo_plus")].setdefault(
                setting(c), c
            )
    path = archive / "configs/integer_confirmation.json"
    sources[str(path.resolve())] = hashlib.sha256(path.read_bytes()).hexdigest()
    conf = {
        c["seeds"]["initialization"]: {"seeds": c["seeds"], "sizes": c["sizes"]}
        for c in read(path)["variants"]
        if c["benchmark_id"] == MDKP
    }
    refine = {}
    for path in sorted(
        (archive / "publication_integer_fixed_source_refinement").glob("*/config.json")
    ):
        c = read(path)
        if c["benchmark_id"] == MDKP:
            refine[c["seeds"]["initialization"]] = c["seeds"]
            sources[str(path.resolve())] = hashlib.sha256(path.read_bytes()).hexdigest()
    if len(conf) != 10 or len(refine) != 3:
        raise ValueError(f"MDKP original seed coverage: {len(conf)}/{len(refine)}")
    sizes = conf[min(conf)]["sizes"]
    if any(c["sizes"] != sizes for c in conf.values()):
        raise ValueError("inconsistent MDKP archived splits")
    mdcell = MDKP + "__train100"
    cells[mdcell] = {
        "route": MDKP,
        "train_size": 100,
        "original_sizes": sizes,
        "confirmation_seeds": [conf[k]["seeds"] for k in sorted(conf)],
        "refinement_seeds": [refine[k] for k in sorted(refine)],
    }
    jobs = []

    def add(cell, method, template, params, direct_params=None):
        c = copy.deepcopy(template["config"])
        info = cells[cell]
        c.update(
            workers=1,
            evaluate_test=False,
            sizes={**info["original_sizes"], "train": info["train_size"]},
        )
        c["training"].update(
            torch_threads=1,
            maximum_optimization_seconds=3600.0,
            selection_mode="validation_regret",
        )
        c["training"]["batch_size"] = min(
            info["train_size"], c["training"]["batch_size"]
        )
        c["method_parameters"] = {
            k: v
            for k, v in c["method_parameters"].items()
            if not k.startswith("prediction_correction")
        }
        if method in DIRECT_METHODS:
            if info["route"] not in DIRECT_ROUTES:
                raise ValueError(
                    "direct policy requested outside the declared pure LPs"
                )
            c.update(method=method, method_parameters=direct_params or {})
        identity = sha(
            {
                "revision": "extension_20260923",
                "config": setting(c),
                "parameters": params,
                "method": method,
            }
        )[:16]
        job = {
            "id": f"screen__{cell}__{method}__{identity}",
            "stage": "screen",
            "cell": cell,
            "route": info["route"],
            "method": method,
            "candidate": identity,
            "repeat": 0,
            "config": c,
            "parameters": copy.deepcopy(params),
            "original_sizes": info["original_sizes"],
            "source_screen_name": template.get("source_screen_name", c["name"]),
        }
        if not any(j["id"] == job["id"] for j in jobs):
            jobs.append(job)
        return job

    for method in METHODS:
        source = (
            "soft_radial_log_barrier"
            if method.startswith("central_path_")
            else (method if method in ("mse", "spo_plus") else "mse")
        )
        if not old[source]:
            raise ValueError("missing MDKP archived broad candidates: " + source)
        for c in old[source].values():
            job = add(mdcell, method, {"config": c}, {})
            if method == "mse":
                common[mdcell].append(job)
    for cell in cells:
        for method, grid in GRIDS.items():
            for template in common[cell]:
                for params in grid:
                    add(cell, method, template, params)
        if cells[cell]["route"] in DIRECT_ROUTES:
            soft_maps = {}
            for template in cp[cell]:
                p = {
                    k: v
                    for k, v in template["config"]["method_parameters"].items()
                    if k
                    in (
                        "contraction",
                        "contraction_scale",
                        "minimum_scale",
                        "kernel_backend",
                        "torch_device",
                    )
                }
                soft_maps[sha(p)] = p
            for method in DIRECT_METHODS:
                maps = (
                    list(soft_maps.values())
                    if method == "soft_radial_policy"
                    else (
                        [{"alpha_start": 0.0, "alpha_end": 0.0, "schedule": "fixed"}]
                        if method == "log_energy_policy"
                        else [{}]
                    )
                )
                for template in common[cell]:
                    for p in maps:
                        add(cell, method, template, {}, p)
    counts, cell_methods = defaultdict(int), defaultdict(set)
    for job in jobs:
        key = (job["cell"], job["method"])
        job["arm_order"] = counts[key]
        counts[key] += 1
        cell_methods[job["cell"]].add(job["method"])
    jobs.sort(key=lambda j: (j["arm_order"], j["cell"], j["method"]))
    return {
        "schema": "central_path_extension_v1",
        "cells": cells,
        "methods": sorted({j["method"] for j in jobs}),
        "cell_methods": {k: sorted(v) for k, v in cell_methods.items()},
        "jobs": jobs,
        "source_sha256": sources,
        "protocol": {
            **completed["protocol"],
            "revision": "fixed_baseline_and_direct_policy_extension_20260923",
            "deferred_methods": [],
            "bounded_search_extension": False,
            "completed_results_are_immutable": True,
            "checkpoint_schedules_unchanged": True,
            "new_baselines": (
                "declared loss grids crossed with archived MSE optimizer/capacity grid"
            ),
            "loss_grids": GRIDS,
            "direct_policy": {
                "routes": DIRECT_ROUTES,
                "training_sizes": [100, 800],
                "methods": DIRECT_METHODS,
                "training_loss": "observed physical linear cost; zero barrier weight",
                "deployment": "mapped feasible decision, without hard recovery",
                "selection": "unsmoothed conditional-mean validation regret",
                "soft_radial_maps": (
                    "all distinct archived broad chart parameters "
                    "crossed with common grid"
                ),
            },
        },
    }


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--completed-screen", type=Path, required=True)
    p.add_argument("--archive", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    result = build(a.completed_screen, a.archive)
    write(a.output, result)
    print(
        {
            "cells": len(result["cells"]),
            "method_cells": sum(map(len, result["cell_methods"].values())),
            "screen_fits": len(result["jobs"]),
        }
    )
