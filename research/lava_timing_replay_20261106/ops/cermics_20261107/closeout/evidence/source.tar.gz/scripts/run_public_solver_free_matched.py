#!/usr/bin/env python3
"""Run source-matched public CaVE/LAVA on one paper benchmark/seed.

This driver deliberately separates three things that were conflated in the
old external screen: public loss code, the paper's exact data split, and the
paper's conditional-mean regret metric.  CaVE and LAVA are imported from the
pinned Solver-Free-DFL checkout.  MIPs are trained on the continuous
relaxation and evaluated with the original integer model.  A receipt is
written per manifest entry, so the campaign can be launched in parallel and
partial results remain auditable.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import random
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import scipy.linalg
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PUBLIC_REPO = Path(
    os.environ.get("SOLVER_FREE_DFL_REPO", "/private/tmp/dfl-public-solver-free")
).resolve()
EXTERNAL_SRC = Path(
    os.environ.get(
        "DFL_EXTENSIONS_SRC", "/private/tmp/dfl-single-stage-suite-bd6026b/src"
    )
).resolve()

# Make public imports available before any public module is imported.
sys.path.insert(0, str(PUBLIC_REPO))
sys.path.insert(0, str(EXTERNAL_SRC))
sys.path.insert(0, str(PROJECT_ROOT / "src"))


def _hash_array(value: Any) -> str:
    array = np.ascontiguousarray(np.asarray(value))
    digest = hashlib.sha256()
    digest.update(str(array.dtype).encode("ascii"))
    digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
    digest.update(array.view(np.uint8))
    return digest.hexdigest()


def _tree_hash(root: Path) -> str:
    digest = hashlib.sha256()
    tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=root).split(b"\0")
    for raw in sorted(item for item in tracked if item):
        digest.update(raw)
        digest.update((root / os.fsdecode(raw)).read_bytes())
    return digest.hexdigest()


def _public_commit(root: Path) -> str | None:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=root, text=True
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def _seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def _parse_csv(value: str, cast: Any = float) -> list[Any]:
    values = [item.strip() for item in value.split(",") if item.strip()]
    if not values:
        raise argparse.ArgumentTypeError("at least one value is required")
    return [cast(item) for item in values]


def _load_manifest(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("entries"), list):
        raise ValueError("matched manifest must contain an entries list")
    return value


def _fixed_model(problem: Any, *, integer: bool | None = None, backend: str = "highs") -> Any:
    """Create the public PyEPO model around exactly one maintained LP/MIP."""

    if backend == "highs":
        from proximal_spo.public_highs import HighsOptModel
        if integer is False:
            problem = problem.continuous_relaxation()
        elif integer is True:
            from dataclasses import replace
            problem = replace(problem, integrality=np.ones(problem.variable_count, dtype=np.int64))
        return HighsOptModel(problem)
    if backend != "gurobi":
        raise ValueError(f"Unsupported solver backend: {backend}")

    import gurobipy as gp
    from gurobipy import GRB
    from pyepo.model.grb.grbmodel import optGrbModel

    class FixedLinearModel(optGrbModel):
        def __init__(self, source: Any, force_integer: bool | None) -> None:
            self.source = source
            self.force_integer = force_integer
            self.is_ILP = (
                bool(force_integer)
                if force_integer is not None
                else bool(np.any(np.asarray(source.integrality, dtype=np.int64)))
            )
            super().__init__()

        def _getModel(self):  # type: ignore[no-untyped-def]
            model = gp.Model(f"matched_public_{self.source.name}")
            model.Params.OutputFlag = 0
            # The public PyEPO/Gurobi model otherwise defaults to using every
            # logical core.  One campaign child owns one model, so leaving the
            # default uncapped would multiply threads across workers and can
            # overload a workstation without changing the optimization
            # problem.  This is a resource-control setting only; all solver
            # tolerances and integer semantics remain unchanged.
            model.Params.Threads = 1
            model.Params.ConcurrentMIP = 1
            lower = np.asarray(self.source.variable_lower, dtype=float)
            upper = np.asarray(self.source.variable_upper, dtype=float)
            integrality = np.asarray(self.source.integrality, dtype=np.int64)
            variables = {
                index: model.addVar(
                    lb=float(lower[index]),
                    ub=float(upper[index]),
                    vtype=(
                        GRB.INTEGER
                        if self.force_integer is True or integrality[index]
                        else GRB.CONTINUOUS
                    ),
                    name=f"z[{index}]",
                )
                for index in range(self.source.variable_count)
            }
            model.modelSense = GRB.MINIMIZE
            matrix = self.source.matrix.tocsr()
            for row in range(self.source.constraint_count):
                indices = matrix.indices[matrix.indptr[row] : matrix.indptr[row + 1]]
                values = matrix.data[matrix.indptr[row] : matrix.indptr[row + 1]]
                expr = gp.LinExpr(
                    values.tolist(), [variables[int(index)] for index in indices]
                )
                lower_row = float(self.source.row_lower[row])
                upper_row = float(self.source.row_upper[row])
                if np.isfinite(lower_row) and np.isfinite(upper_row):
                    if abs(lower_row - upper_row) <= 1e-10:
                        model.addConstr(expr == lower_row)
                    else:
                        model.addConstr(expr >= lower_row)
                        model.addConstr(expr <= upper_row)
                elif np.isfinite(lower_row):
                    model.addConstr(expr >= lower_row)
                elif np.isfinite(upper_row):
                    model.addConstr(expr <= upper_row)
            return model, variables

    return FixedLinearModel(problem, integer)


def _integer_evaluation_problem(problem: Any) -> Any:
    from proximal_spo.problem import LinearProblem

    return LinearProblem(
        matrix=problem.matrix,
        row_lower=problem.row_lower,
        row_upper=problem.row_upper,
        variable_lower=problem.variable_lower,
        variable_upper=problem.variable_upper,
        integrality=np.asarray(problem.integrality, dtype=np.int64),
        name=f"{problem.name}.integer_evaluation",
        metadata={**dict(problem.metadata), "matched_public_integer_evaluation": True},
    )


class RobustAugmentedDataset:  # populated dynamically below
    pass


def BindingOnlyDataset(model, feats, costs):
    from proximal_spo.public_highs import HighsOptModel, HighsBindingDataset
    if isinstance(model, HighsOptModel):
        return HighsBindingDataset(model, feats, costs)
    return GurobiBindingOnlyDataset(model, feats, costs)


class GurobiBindingOnlyDataset(Dataset):
    """Exact public binding-cone labels without adjacent-vertex enumeration.

    CaVE consumes only the binding normals.  The public augmented dataset also
    computes every adjacent vertex, which is needed by LAVA but is unnecessary
    (and potentially enormous) for CaVE.  This adapter keeps the public model
    solves and binding-normal convention exactly, while supplying a padded
    dummy adjacent-vertex field for the shared public collator.
    """

    def __init__(self, model: Any, feats: np.ndarray, costs: np.ndarray) -> None:
        from gurobipy import GRB

        self.model = model
        self.feats = np.asarray(feats, dtype=np.float64)
        self.costs = np.asarray(costs, dtype=np.float64)
        self.sols: list[np.ndarray] = []
        self.objs: list[list[float]] = []
        self.relaxed_sols: list[np.ndarray] = []
        self.relaxed_objs: list[list[float]] = []
        self.ctrs: list[np.ndarray] = []
        self.adjacent_verts: list[np.ndarray] = []
        work = model.copy()
        for cost in self.costs:
            solved = work
            solved.setObj(cost)
            sol, obj = solved.solve()
            variables = list(solved.x.values()) if isinstance(solved.x, dict) else list(solved.x)
            constrs: list[list[float]] = []
            for constr in solved._model.getConstrs():
                if abs(constr.Slack) >= 1e-5:
                    continue
                row = [solved._model.getCoeff(constr, var) for var in variables]
                if constr.sense == GRB.LESS_EQUAL:
                    constrs.append(row)
                elif constr.sense == GRB.GREATER_EQUAL:
                    constrs.append([-value for value in row])
                elif constr.sense == GRB.EQUAL:
                    constrs.extend([row, [-value for value in row]])
                else:
                    raise ValueError(f"invalid Gurobi constraint sense {constr.sense!r}")
            for index, variable in enumerate(variables):
                if sol[index] <= 1e-5:
                    row = [0.0] * len(variables)
                    row[index] = -1.0
                    constrs.append(row)
                elif np.isfinite(variable.ub) and sol[index] >= variable.ub - 1e-5:
                    row = [0.0] * len(variables)
                    row[index] = 1.0
                    constrs.append(row)
            self.sols.append(np.asarray(sol, dtype=np.float64))
            self.objs.append([float(obj)])
            self.relaxed_sols.append(np.asarray(sol, dtype=np.float64))
            self.relaxed_objs.append([float(obj)])
            self.ctrs.append(np.asarray(constrs, dtype=np.float64))
            self.adjacent_verts.append(np.zeros((1, len(variables)), dtype=np.float64))
        self.geometry_row_reduction = False

    def __len__(self) -> int:
        return len(self.feats)

    def __getitem__(self, index: int):
        return (
            torch.as_tensor(self.feats[index], dtype=torch.float32),
            torch.as_tensor(self.costs[index], dtype=torch.float32),
            torch.as_tensor(self.sols[index], dtype=torch.float32),
            torch.as_tensor(self.objs[index], dtype=torch.float32),
            torch.as_tensor(self.relaxed_sols[index], dtype=torch.float32),
            torch.as_tensor(self.relaxed_objs[index], dtype=torch.float32),
            torch.as_tensor(self.ctrs[index], dtype=torch.float32),
            torch.as_tensor(self.adjacent_verts[index], dtype=torch.float32),
        )


def _make_robust_dataset_class(backend: str = "highs") -> type[Any]:
    """Select a solver adapter around the unchanged public enumeration.

    The explicit Gurobi reference branch retains the historical redundant-row
    and TNP assertion recovery. HiGHS additionally converts fixed logical row
    variables into a structural basis. The released 250-basis cap remains;
    different native bases need not yield the same truncated neighbourhood.
    """

    if backend == "highs":
        from proximal_spo.public_highs import HighsLAVADataset
        return HighsLAVADataset
    if backend != "gurobi":
        raise ValueError(f"Unsupported solver backend: {backend}")

    from data.dataset_augmented import (
        get_adjacent_vertices_degenerate_case,
        get_adjacent_vertices_non_degenerate_case,
        optDatasetAugmented,
    )

    class Robust(optDatasetAugmented):
        geometry_row_reduction = False

        def __init__(self, model: Any, feats: np.ndarray, costs: np.ndarray):
            self._reusable_solve_model = None
            self.adjacency_tnp_retry_count = 0
            super().__init__(model, feats, costs)

        def _solve(self, cost):
            # The upstream dataset copies the full Gurobi model per sample.
            # Objective replacement on one isolated model is exact and avoids
            # hundreds of repeated model clones during public-label setup.
            if self._reusable_solve_model is None:
                self._reusable_solve_model = self.model.copy()
            self._reusable_solve_model.setObj(cost)
            sol, obj = self._reusable_solve_model.solve()
            return sol, obj, self._reusable_solve_model

        def _get_adjacent_vertices(self, slack_model: Any, matrix: np.ndarray):
            all_vars = slack_model.getVars()
            solution = np.asarray([var.x for var in all_vars], dtype=float)
            basis_status = np.asarray([var.VBasis for var in all_vars])
            basic = np.where(basis_status == 0)[0]
            non_basic = np.where(basis_status != 0)[0]
            if matrix.shape[0] != len(basic):
                basis_matrix = matrix[:, basic]
                rank = int(np.linalg.matrix_rank(basis_matrix, tol=1e-8))
                if rank != len(basic):
                    raise RuntimeError(
                        "public adjacency basis is rank deficient beyond redundant "
                        f"rows: shape={matrix.shape}, basic={len(basic)}, rank={rank}"
                    )
                # QR with column pivoting on B^T selects independent rows of B.
                _, _, pivots = scipy.linalg.qr(
                    basis_matrix.T, mode="economic", pivoting=True
                )
                matrix = np.asarray(matrix[np.asarray(pivots[: len(basic)])], dtype=float)
                self.geometry_row_reduction = True
            sigma = np.sum(solution[basic] < 1e-10)
            if sigma == 0:
                return get_adjacent_vertices_non_degenerate_case(
                    matrix, basic, non_basic, solution, True
                )
            try:
                return get_adjacent_vertices_degenerate_case(
                    matrix, basic, non_basic, solution, True, True
                )
            except AssertionError as error:
                # The pinned public routine's TNP lexicographic certificate is
                # numerically brittle on some degenerate CFL vertices.  Its
                # own exact helper exposes a non-TNP branch; retry that branch
                # rather than substituting binding-only labels (which would
                # no longer be a valid LAVA run).  The caller records the
                # retry count, and downstream checks verify the returned
                # vertices are finite and have the expected dimension.
                self.adjacency_tnp_retry_count += 1
                return get_adjacent_vertices_degenerate_case(
                    matrix, basic, non_basic, solution, True, False
                )

    return Robust


def _load_entry(
    entry: dict[str, Any], *, need_lava: bool
) -> tuple[Any, Any, Any, Any, Any]:
    from dfl_extensions_lab.benchmarks import SplitSizes
    from proximal_spo.external_benchmarks import load_external_benchmark

    sizes = entry["sizes"]
    loaded = load_external_benchmark(
        str(entry["benchmark_id"]),
        SplitSizes(
            train=int(sizes["train"]),
            validation=int(sizes["validation"]),
            test=int(sizes["test"]),
        ),
        data_seed=int(entry["seeds"]["data"]),
        conditional_reference_samples=int(entry["conditional_reference_samples"]),
    )
    problem = loaded.problem
    relaxed = problem.continuous_relaxation(name=f"{problem.name}.continuous_training")
    public_model = _fixed_model(relaxed, integer=False)
    if need_lava:
        robust_cls = _make_robust_dataset_class()
        train = robust_cls(
            public_model,
            loaded.dataset.train.contexts,
            loaded.dataset.train.physical_costs,
        )
    else:
        train = BindingOnlyDataset(
            public_model,
            loaded.dataset.train.contexts,
            loaded.dataset.train.physical_costs,
        )
    eval_problem = (
        _integer_evaluation_problem(problem)
        if np.any(np.asarray(problem.integrality, dtype=np.int64))
        else problem
    )
    from proximal_spo.oracles import PersistentLPSolver

    solver = PersistentLPSolver(eval_problem, random_seed=int(entry["seeds"]["structural"]))
    # Reference values are conditional means, matching BCR's evaluation
    # contract.  They are computed once and never used to fit a model.
    val_reference = solver.solve_many(
        loaded.dataset.validation.conditional_mean_costs
    ).objectives
    # Test conditional targets are deliberately not solved here.  They are
    # computed only after the validation-selected checkpoint has been frozen,
    # preserving the test-blind selection protocol.
    return loaded, public_model, train, solver, (val_reference, None)


def _make_model(entry: dict[str, Any], contexts: np.ndarray, costs: np.ndarray) -> nn.Module:
    from proximal_spo.models import ModelSpec, StandardizedMLP, input_statistics

    raw = dict(entry.get("model") or {})
    spec = ModelSpec(
        width=int(raw.get("width", 64)),
        depth=int(raw.get("depth", 2)),
        activation=str(raw.get("activation", "silu")),
        layer_norm=bool(raw.get("layer_norm", False)),
        dtype=str(raw.get("dtype", "float32")),
    )
    mean, scale = input_statistics(contexts)
    if entry.get("physical_cost_output"):
        # A trainable physical-cost head, with no fixed affine output decoder.
        # Only the supplied observed training pairs set input normalization and
        # the initial (trainable) bias, matching the physical MSE/SPO+ controls.
        model = StandardizedMLP(contexts.shape[1], costs.shape[1], spec,
            input_mean=mean, input_scale=scale,
            output_bias=np.mean(costs, axis=0))
        model.physical_cost_output = True
        return model
    # Match the paper's coordinate contract: learn standardized coefficients
    # beta and map them to physical costs c = mean + scale * beta before the
    # public loss and every deployment solve.  Zero beta is therefore the
    # train-split mean cost, which is both stable for CaVE's cosine chart and
    # exactly the affine standardization used by BCR.
    cost_mean = np.mean(costs, axis=0).astype(np.float64)
    cost_scale = np.std(costs, axis=0).astype(np.float64)
    cost_scale = np.where(cost_scale < 1e-8, 1.0, cost_scale)
    model = StandardizedMLP(
        contexts.shape[1],
        costs.shape[1],
        spec,
        input_mean=mean,
        input_scale=scale,
        output_bias=np.zeros(costs.shape[1], dtype=np.float64),
    )
    # These are fixed train-split buffers for the method's affine output map;
    # they are not learned network weights and are included in the receipt.
    model.register_buffer("cost_mean", torch.as_tensor(cost_mean, dtype=torch.float32))
    model.register_buffer("cost_scale", torch.as_tensor(cost_scale, dtype=torch.float32))
    return model


def _physical_prediction(model: nn.Module, contexts: np.ndarray | torch.Tensor) -> torch.Tensor:
    if isinstance(contexts, np.ndarray):
        contexts = torch.as_tensor(contexts, dtype=torch.float32)
    beta = model(contexts)
    if getattr(model, "physical_cost_output", False):
        if hasattr(model, "cost_mean") or hasattr(model, "cost_scale"):
            raise RuntimeError("Physical head must not have an affine cost decoder")
        return beta
    mean = getattr(model, "cost_mean")
    scale = getattr(model, "cost_scale")
    return mean.to(device=beta.device, dtype=beta.dtype) + beta * scale.to(
        device=beta.device, dtype=beta.dtype
    )


def _evaluate(
    model: nn.Module,
    contexts: np.ndarray,
    conditional_costs: np.ndarray,
    reference_values: np.ndarray,
    solver: Any,
) -> tuple[float, dict[str, Any]]:
    model.eval()
    with torch.no_grad():
        output = _physical_prediction(model, contexts).detach().cpu().numpy()
    deployed = solver.solve_many(np.asarray(output, dtype=np.float64))
    values = np.sum(np.asarray(conditional_costs) * deployed.decisions, axis=1)
    regret = values - np.asarray(reference_values)
    tolerance = 5e-7 * (
        1.0 + np.abs(reference_values) + np.sum(np.abs(conditional_costs), axis=1)
    )
    if np.any(regret < -tolerance):
        raise RuntimeError(f"materially negative conditional regret {regret.min():.3e}")
    regret = np.maximum(regret, 0.0)
    denominator = float(np.mean(np.abs(reference_values)))
    normalized = float(np.mean(regret) / denominator) if denominator > 1e-8 else None
    return normalized if normalized is not None else float(np.mean(regret)), {
        "mean_regret": float(np.mean(regret)),
        "normalized_regret": normalized,
        "median_regret": float(np.median(regret)),
        "maximum_regret": float(np.max(regret)),
        "positive_regret_rate": float(np.mean(regret > 1e-8)),
        "sample_count": int(len(regret)),
        "solver_seconds": float(deployed.stats.solver_seconds),
        "oracle_calls": int(deployed.stats.calls),
    }


def _train_arm(
    entry: dict[str, Any],
    arm: dict[str, Any],
    public_model: Any,
    train: Any,
    solver: Any,
    references: tuple[np.ndarray, np.ndarray],
    loaded: Any,
    *,
    epochs: int,
    validation_interval: int,
    evaluate_test: bool = True,
) -> dict[str, Any]:
    import pyepo.func as func
    from methods.cave import exactConeAlignedCosine
    from methods.lava import LAVA
    from proximal_spo.public_highs import public_geometry
    collate_fn_2 = public_geometry(str(PUBLIC_REPO)).collate_fn_2

    seeds = entry["seeds"]
    _seed(int(seeds["initialization"]) + int(arm.get("seed_offset", 0)))
    contexts = np.asarray(loaded.dataset.train.contexts, dtype=np.float64)
    costs = np.asarray(loaded.dataset.train.physical_costs, dtype=np.float64)
    model_entry = copy.deepcopy(entry)
    model_entry["model"] = {
        **dict(entry.get("model") or {}),
        **dict(arm.get("model") or {}),
    }
    model = _make_model(model_entry, contexts, costs)
    kind = str(arm["kind"])
    if kind == "cave":
        loss = exactConeAlignedCosine(
            public_model,
            solver=str(arm.get("solver", "nnls")),
            reduction="mean",
            processes=1,
        )
    elif kind == "lava":
        loss = LAVA(public_model, threshold=float(arm.get("threshold", -0.1)))
    else:
        raise ValueError(f"unknown public solver-free arm {kind!r}")

    training = dict(entry.get("training") or {})
    training.update(
        {
            key: value
            for key, value in arm.items()
            if key in {"batch_size", "learning_rate", "weight_decay", "torch_threads", "gradient_clip"}
        }
    )
    batch_size = int(training.get("batch_size", 64))
    learning_rate = float(training.get("learning_rate", 1e-3))
    weight_decay = float(training.get("weight_decay", 1e-5))
    torch.set_num_threads(max(1, int(training.get("torch_threads", 1))))
    generator = torch.Generator()
    generator.manual_seed(int(seeds["shuffle"]))
    loader = DataLoader(
        train,
        batch_size=min(batch_size, len(train)),
        shuffle=True,
        collate_fn=collate_fn_2,
        generator=generator,
    )
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)
    best_state: dict[str, torch.Tensor] | None = None
    best_val = float("inf")
    best_epoch = 0
    curves: list[dict[str, Any]] = []
    started = time.perf_counter()
    for epoch in range(1, epochs + 1):
        model.train()
        losses: list[float] = []
        for batch in loader:
            x, c, w, z, w_rel, z_rel, bctr, adj_verts = batch
            prediction = _physical_prediction(model, x)
            if kind == "cave":
                value = loss(prediction, bctr)
            else:
                value = loss(prediction, adj_verts, w_rel, -1.0)
            if not torch.isfinite(value):
                raise RuntimeError(f"non-finite {kind} loss at epoch {epoch}")
            optimizer.zero_grad(set_to_none=True)
            value.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(training.get("gradient_clip", 10.0)))
            optimizer.step()
            losses.append(float(value.detach().cpu()))
        record: dict[str, Any] = {
            "epoch": epoch,
            "training_loss": float(np.mean(losses)) if losses else None,
        }
        if epoch == epochs or epoch % max(1, validation_interval) == 0:
            val_value, val_metrics = _evaluate(
                model,
                loaded.dataset.validation.contexts,
                loaded.dataset.validation.conditional_mean_costs,
                references[0],
                solver,
            )
            record["validation"] = val_metrics
            if val_value < best_val:
                best_val = val_value
                best_epoch = epoch
                best_state = {
                    key: value.detach().cpu().clone()
                    for key, value in model.state_dict().items()
                }
        curves.append(record)
    if best_state is None:
        raise RuntimeError("no validation checkpoint was produced")
    model.load_state_dict(best_state)
    result = {
        **arm,
        "status": "complete",
        "best_epoch": best_epoch,
        "epochs_completed": epochs,
        "validation_regret": best_val,
        "validation_metric": "conditional_mean_normalized_decision_regret",
        "training_wall_seconds": time.perf_counter() - started,
        "curves": curves,
    }
    if evaluate_test:
        if references[1] is None:
            test_reference = solver.solve_many(
                loaded.dataset.test.conditional_mean_costs
            ).objectives
        else:
            test_reference = references[1]
        test_value, test_metrics = _evaluate(
            model,
            loaded.dataset.test.contexts,
            loaded.dataset.test.conditional_mean_costs,
            test_reference,
            solver,
        )
        result.update({"test_regret": test_value, "test_metrics": test_metrics})
    return result


def _arms(solvers: list[str], thresholds: list[float]) -> list[dict[str, Any]]:
    return [
        {"name": f"CaVE_{solver}", "kind": "cave", "solver": solver}
        for solver in solvers
    ] + [
        {
            "name": f"LAVA_threshold{threshold:g}",
            "kind": "lava",
            "threshold": threshold,
        }
        for threshold in thresholds
    ]


def run_entry(
    entry: dict[str, Any],
    *,
    public_methods: list[str],
    cave_solvers: list[str],
    lava_thresholds: list[float],
    epochs_override: int | None,
    validation_interval_override: int | None,
) -> dict[str, Any]:
    started = time.perf_counter()
    base_receipt: dict[str, Any] = {
        "kind": "paper_public_solver_free_matched_run",
        "route_id": entry["route_id"],
        "benchmark_id": entry["benchmark_id"],
        "source_config": entry.get("source_config"),
        "seeds": entry["seeds"],
        "sizes": entry["sizes"],
        "protocol": {
            "optimization_backend": "HiGHS",
            "public_losses_and_enumeration_unchanged": True,
            "train_on_continuous_relaxation": True,
            "hard_integer_evaluation": True,
            "test_used_for_selection": False,
            "test_reference_solved_after_selection": True,
            "metric": "conditional_mean_normalized_decision_regret",
            "cost_coordinates": "standardized_train_split_beta_mapped_to_physical_cost",
            "raw_data_persisted": False,
            "raw_weights_persisted": False,
        },
        "source": {
            "solver_free_repository": str(PUBLIC_REPO),
            "solver_free_commit": _public_commit(PUBLIC_REPO),
            "solver_free_tree_sha256": _tree_hash(PUBLIC_REPO),
            "external_source": str(EXTERNAL_SRC),
        },
    }
    try:
        loaded, public_model, train, solver, references = _load_entry(
            entry, need_lava="lava" in set(public_methods)
        )
        base_receipt["dataset"] = {
            "train_context_sha256": _hash_array(loaded.dataset.train.contexts),
            "train_cost_sha256": _hash_array(loaded.dataset.train.physical_costs),
            "validation_context_sha256": _hash_array(loaded.dataset.validation.contexts),
            "test_context_sha256": _hash_array(loaded.dataset.test.contexts),
            "training_problem": public_model.source.name,
            "evaluation_problem": solver.problem.name,
            "training_integral_variables": 0,
            "evaluation_integral_variables": int(np.sum(solver.problem.integrality)),
            "augmented_geometry_row_reduction": bool(
                getattr(train, "geometry_row_reduction", False)
            ),
            "augmented_samples": len(train),
            "adjacency_tnp_retry_count": int(
                getattr(train, "adjacency_tnp_retry_count", 0)
            ),
            "cost_coordinate_mean_sha256": _hash_array(
                np.mean(np.asarray(loaded.dataset.train.physical_costs), axis=0)
            ),
            "cost_coordinate_scale_sha256": _hash_array(
                np.where(
                    np.std(np.asarray(loaded.dataset.train.physical_costs), axis=0) < 1e-8,
                    1.0,
                    np.std(np.asarray(loaded.dataset.train.physical_costs), axis=0),
                )
            ),
            "cost_coordinate_source": "training physical-cost mean/std, no test statistics",
        }
        training = dict(entry.get("training") or {})
        epochs = int(epochs_override or training.get("epochs", 100))
        interval = int(
            validation_interval_override
            or min(10, max(1, epochs // 20))
        )
        arms = _arms(cave_solvers, lava_thresholds)
        selected = [arm for arm in arms if arm["kind"] in set(public_methods)]
        if not selected:
            raise ValueError("no selected public methods")
        results: list[dict[str, Any]] = []
        for arm in selected:
            try:
                result = _train_arm(
                    entry,
                    arm,
                    public_model,
                    train,
                    solver,
                    references,
                    loaded,
                    epochs=epochs,
                    validation_interval=interval,
                )
            except BaseException as error:
                result = {
                    **arm,
                    "status": "failed",
                    "error_type": type(error).__name__,
                    "error": str(error),
                }
            results.append(result)
            print(
                json.dumps(
                    {
                        "route": entry["route_id"],
                        "data_seed": entry["seeds"]["data"],
                        "arm": arm["name"],
                        "status": result["status"],
                        "test_regret": result.get("test_regret"),
                    }
                ),
                flush=True,
            )
        base_receipt.update(
            {
                "status": "complete" if all(r["status"] == "complete" for r in results) else "partial_failure",
                "training": {
                    "epochs": epochs,
                    "validation_interval": interval,
                    "learning_rate": training.get("learning_rate"),
                    "batch_size": training.get("batch_size"),
                },
                "arms": results,
            }
        )
    except BaseException as error:
        base_receipt.update(
            {
                "status": "failed",
                "error_type": type(error).__name__,
                "error": str(error),
            }
        )
    base_receipt["wall_seconds"] = time.perf_counter() - started
    return base_receipt


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--entry-index", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--methods",
        default="cave,lava",
        help="comma-separated public methods (cave,lava)",
    )
    parser.add_argument("--cave-solvers", default="nnls")
    parser.add_argument("--lava-thresholds", default="-0.1")
    parser.add_argument("--epochs", type=int)
    parser.add_argument("--validation-interval", type=int)
    args = parser.parse_args()
    manifest = _load_manifest(args.manifest)
    if not 0 <= args.entry_index < len(manifest["entries"]):
        raise IndexError("entry index outside manifest")
    entry = manifest["entries"][args.entry_index]
    methods = [str(value) for value in _parse_csv(args.methods, str)]
    solvers = [str(value) for value in _parse_csv(args.cave_solvers, str)]
    thresholds = [float(value) for value in _parse_csv(args.lava_thresholds, float)]
    receipt = run_entry(
        entry,
        public_methods=methods,
        cave_solvers=solvers,
        lava_thresholds=thresholds,
        epochs_override=args.epochs,
        validation_interval_override=args.validation_interval,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    return 0 if receipt["status"] == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
