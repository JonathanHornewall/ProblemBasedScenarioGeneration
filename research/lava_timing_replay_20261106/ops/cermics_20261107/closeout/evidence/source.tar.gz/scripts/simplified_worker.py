"""Bounded Slurm pools, kernel fit claims and a fixed-core serial timing arm."""
from __future__ import annotations

import argparse
import fcntl
import os
import signal
import socket
import subprocess
import time
from pathlib import Path

from pilot_driver import node_reservation, terminate
from simplified_campaign import Campaign, environment, manifest, provision, read, write


def clock_state(root, j, now=None):
    path = root / 'results/training_clocks' / (j['id'] + '.json')
    if not path.exists(): return None
    state = read(path)
    elapsed = state['consumed_training_seconds']
    if state['active_since_unix'] is not None:
        elapsed += (time.time() if now is None else now) - state['active_since_unix']
    return {**state, 'measured_or_active_training_seconds': elapsed}


def worker(root, role, index, memory):
    import psutil
    root = Path(root); env = environment(root)
    if not os.environ.get('SLURM_JOB_ID') or len(os.sched_getaffinity(0)) != 1:
        raise RuntimeError('Each Slurm worker must be bound to one CPU')
    for name in ('claims', 'workers', 'results/logs'): (root / name).mkdir(parents=True, exist_ok=True)
    token = os.environ['SLURM_JOB_ID'] + '_' + role + '_' + socket.gethostname() + '_' + str(index)
    heartbeat = root / 'workers' / (token + '.json')
    stopped = False; active = None; claim = None

    def stop(*args):
        nonlocal stopped
        stopped = True
    signal.signal(signal.SIGTERM, stop); signal.signal(signal.SIGINT, stop)
    os.environ['PILOT_NODE_MEMORY_GIB'] = str(memory)
    try:
        while not stopped:
            queue_path = root / ('QUEUE_' + role + '.json')
            if not queue_path.exists(): time.sleep(2); continue
            queue = read(queue_path)
            if active:
                child, j, opened, log = active; reason = None
                try:
                    processes = [psutil.Process(child.pid), *psutil.Process(child.pid).children(recursive=True)]
                    rss = sum(p.memory_info().rss for p in processes) / 2**30
                except psutil.Error: rss = 0
                if rss > provision(j) * .95: reason = 'memory_admission_exhausted'
                elapsed = time.time() - opened
                wall_limit = j['resource_limits']['job_wall_cap_seconds']
                if wall_limit and elapsed >= wall_limit: reason = 'overall_wall_limit_exhausted'
                clock = clock_state(root, j) if j['training_oracle'] == 'native_integer' else None
                if reason: terminate(child)
                if child.poll() is not None:
                    out = root / 'results/receipts' / (j['id'] + '.json')
                    if not out.exists():
                        progress = root / 'results/progress' / (j['id'] + '.json')
                        state = read(progress) if progress.exists() else {}
                        state.update(job=j, status='censored' if reason else 'failed', error=reason or 'worker_exit_without_receipt',
                            returncode=child.returncode, total_wall_seconds=elapsed, finished_unix=time.time(),
                            test_access=bool(state.get('test_access')), smoke_only=False,
                            training_clock=clock)
                        write(out, state, immutable=True)
                    log.close(); claim.close(); node_reservation(root, token); claim = None; active = None
            if active is None:
                if (root / 'CAMPAIGN_COMPLETE.json').exists() or (role == 'main' and queue.get('science_complete')):
                    break
                for item in queue['jobs']:
                    out = root / 'results/receipts' / (item['id'] + '.json')
                    if out.exists(): continue
                    guard = (root / 'claims' / (item['id'] + '.lock')).open('a')
                    try: fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except BlockingIOError: guard.close(); continue
                    if out.exists(): guard.close(); continue
                    j = read(root / 'jobs' / (item['id'] + '.json'))['jobs'][0]
                    if not node_reservation(root, token, provision(j)): guard.close(); continue
                    # An interrupted fit's measured clock is never silently reset.
                    if j['training_oracle'] == 'native_integer' and clock_state(root, j) is not None:
                        write(out, {'job': j, 'status': 'censored', 'error': 'interrupted_training_no_restart',
                            'training_clock': clock_state(root, j), 'test_access': False}, immutable=True)
                        guard.close(); node_reservation(root, token); continue
                    path = root / 'results/logs' / (j['id'] + '.log'); log = path.open('a')
                    if role == 'timing':
                        write(root/'timing_host_samples'/(j['id']+'.json'), {'job_id': os.environ['SLURM_JOB_ID'],
                            'host': socket.gethostname(), 'physical_cpu': sorted(os.sched_getaffinity(0)),
                            'load_average': list(os.getloadavg()), 'sampled_unix': time.time(),
                            'claim': 'matched hardware and private Slurm core; shared host contention is possible'}, immutable=True)
                    cmd = [str(root/'venv/bin/python'), str(root/'code/scripts/run_central_path_final.py'),
                        '--manifest', str(root/'jobs'/(j['id']+'.json')), '--job-index', '0', '--output-root', str(root/'results')]
                    child = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                    active = (child, j, time.time(), log); claim = guard; break
            write(heartbeat, {'job_id': os.environ['SLURM_JOB_ID'], 'role': role, 'host': socket.gethostname(),
                'pid': os.getpid(), 'updated_unix': time.time(), 'affinity': sorted(os.sched_getaffinity(0)),
                'fit_id': active[1]['id'] if active else None, 'phase': queue['phase']})
            time.sleep(1)
    finally:
        if active:
            child, j, opened, log = active; terminate(child); log.close()
            out = root / 'results/receipts' / (j['id'] + '.json')
            if not out.exists():
                write(out, {'job': j, 'status': 'censored', 'error': 'allocation_interruption_no_automatic_retry',
                    'training_clock': clock_state(root, j), 'test_access': False,
                    'total_wall_seconds': time.time() - opened}, immutable=True)
        if claim: claim.close()
        node_reservation(root, token)
        write(heartbeat, {'status': 'ended', 'job_id': os.environ['SLURM_JOB_ID'], 'role': role,
            'host': socket.gethostname(), 'ended_unix': time.time()})


def coordinator(root):
    root = Path(root)
    if read(root / 'preflight/VERIFICATION.json')['status'] != 'passed':
        raise RuntimeError('Focused Slurm preflight did not pass')
    with (root / 'coordinator.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        campaign = Campaign(root)
        while not campaign.advance(): time.sleep(10)


def pool(root, workers, memory, role, leader):
    if workers > int(os.environ.get('SLURM_CPUS_PER_TASK', '0')):
        raise RuntimeError('Worker count exceeds Slurm allocation')
    if role == 'timing' and (socket.gethostname().split('.', 1)[0] != read(root/'RESOURCE_CONTRACT.json')['timing_node'] or workers != 1):
        raise RuntimeError('Timing node/core contract differs')
    physical = {}
    for cpu in sorted(os.sched_getaffinity(0)):
        topo = Path(f'/sys/devices/system/cpu/cpu{cpu}/topology')
        key = ((topo/'physical_package_id').read_text().strip(), (topo/'core_id').read_text().strip())
        physical.setdefault(key, cpu)
    cores = list(physical.values())
    if len(cores) < workers: raise RuntimeError('Insufficient allocated physical cores')
    root.joinpath('ops').mkdir(exist_ok=True)
    write(root/'ops'/('POOL_'+role+'_'+socket.gethostname()+'.json'), {'job_id': os.environ['SLURM_JOB_ID'],
        'role': role, 'cores': cores[:workers], 'workers': workers, 'memory_admission_gib': memory,
        'isolation': 'matched_hardware_single_core_shared_host' if role == 'timing' else 'shared_slurm_cpu_allocation',
        'host_load_at_start': list(os.getloadavg())})
    env = environment(root); children = []; stopped = False
    def stop(*args):
        nonlocal stopped
        stopped = True
    signal.signal(signal.SIGTERM, stop); signal.signal(signal.SIGINT, stop)
    try:
        if leader:
            # The coordinator performs metadata work alongside its bound worker;
            # it does not consume another numerical core.
            coordinator_core = cores[workers] if len(cores) > workers else cores[0]
            children.append(subprocess.Popen(['taskset', '-c', str(coordinator_core), str(root/'venv/bin/python'),
                str(root/'code/scripts/simplified_worker.py'), '--root', str(root), '--coordinator'], env=env))
        for i, cpu in enumerate(cores[:workers]):
            children.append(subprocess.Popen(['taskset', '-c', str(cpu), str(root/'venv/bin/python'),
                str(root/'code/scripts/simplified_worker.py'), '--root', str(root), '--role', role,
                '--index', str(i), '--memory', str(memory)], env=env))
        while not stopped and any(c.poll() is None for c in children):
            failures = [c.returncode for c in children if c.poll() not in (None, 0)]
            if failures: raise RuntimeError('Pool process failed: ' + str(failures))
            time.sleep(3)
    finally:
        for c in children:
            if c.poll() is None: c.terminate()
        for c in children:
            try: c.wait(timeout=20)
            except subprocess.TimeoutExpired: c.kill(); c.wait()


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--root', type=Path, required=True)
    p.add_argument('--role', choices=['main', 'timing'], default='main'); p.add_argument('--index', type=int, default=0)
    p.add_argument('--memory', type=float, default=210); p.add_argument('--pool', type=int)
    p.add_argument('--leader', action='store_true'); p.add_argument('--coordinator', action='store_true')
    a = p.parse_args(); root = a.root.resolve()
    if a.coordinator: coordinator(root)
    elif a.pool: pool(root, a.pool, a.memory, a.role, a.leader)
    else: worker(root, a.role, a.index, a.memory)
