"""Cache only locally generated public geometry, including explicit failures."""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
import pickle
import time
from pathlib import Path

from build_central_path_final import write


def geometry_cache_key(job, contexts, costs):
    import run_public_solver_free_matched as matched
    return hashlib.sha256(
        json.dumps(
            {
                "route": job["route"],
                "method": job["method"],
                "contexts": matched._hash_array(contexts),
                "costs": matched._hash_array(costs),
                "vertex_tolerance": job["parameters"].get("vertex_tolerance", 0.0),
                "adapter": hashlib.sha256(
                    (
                        Path(__file__).parents[1] / "src/proximal_spo/public_highs.py"
                    ).read_bytes()
                ).hexdigest(),
                "public_commit": matched._public_commit(matched.PUBLIC_REPO),
                "schema": 1,
            },
            sort_keys=True,
        ).encode()
    ).hexdigest()


def get_geometry(job, model, contexts, costs, update):
    import run_public_solver_free_matched as matched
    from proximal_spo.public_highs import HighsBindingDataset, HighsLAVADataset

    key = geometry_cache_key(job, contexts, costs)
    cache = Path(os.environ["CENTRAL_PATH_GEOMETRY_CACHE"])
    cache.mkdir(parents=True, exist_ok=True)
    path, receipt = cache / (key + ".pickle"), cache / (key + ".json")
    update("preprocessing", geometry_cache_key=key)
    with (cache / (key + ".lock")).open("a+b") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        if receipt.exists():
            meta = json.loads(receipt.read_text())
            if meta["status"] != "complete":
                error = (
                    TimeoutError
                    if meta.get("resource_limited")
                    or meta.get("error_type") == "TimeoutError"
                    else RuntimeError
                )
                raise error("shared geometry unavailable: " + meta["error"])
            if path.exists():
                # These files are generated solely by this isolated campaign.
                with path.open("rb") as f:
                    fields = pickle.load(f)
                dataset = HighsBindingDataset.__new__(HighsBindingDataset)
                dataset.__dict__.update(fields)
                dataset.model, dataset.feats, dataset.costs = model, contexts, costs
                dataset.geometry_cache_receipt = {**meta, "hit": True, "key": key}
                update("preprocessing", geometry_cache_hit=True)
                return dataset
        started = time.perf_counter()
        try:
            if job["method"] == "cave":
                dataset = HighsBindingDataset(model, contexts, costs)
                geometry = None
            else:
                dataset = HighsLAVADataset(
                    model,
                    contexts,
                    costs,
                    public_repo=matched.PUBLIC_REPO,
                    vertex_tolerance=job["parameters"]["vertex_tolerance"],
                    progress=lambda n, d: update(
                        "preprocessing", geometry_samples_processed=n
                    ),
                )
                geometry = {
                    "public_source_sha256": dataset.public.source_sha256,
                    "vertex_counts": [len(x) for x in dataset.adjacent_verts],
                    "basis_completions": dataset.basis_completion_count,
                    "anchor_reselections": dataset.anchor_reselection_count,
                    "tnp_retries": dataset.adjacency_tnp_retry_count,
                    "vertex_tolerance": dataset.vertex_tolerance,
                    "basis_enumeration_cap": 250,
                    "completeness_certified": False,
                }
            fields = {
                name: getattr(dataset, name)
                for name in (
                    "sols",
                    "objs",
                    "relaxed_sols",
                    "relaxed_objs",
                    "ctrs",
                    "adjacent_verts",
                )
            }
            temporary = cache / (key + f".{os.getpid()}.tmp")
            with temporary.open("wb") as f:
                pickle.dump(fields, f, protocol=5)
            serialized_bytes = temporary.stat().st_size
            # Bound shared-home storage; oversized entries remain uncached.
            with (cache / "quota.lock").open("a+b") as quota:
                fcntl.flock(quota.fileno(), fcntl.LOCK_EX)
                used = sum(p.stat().st_size for p in cache.glob("*.pickle"))
                retained = used + temporary.stat().st_size <= 30 * 2**30
                if retained:
                    temporary.replace(path)
                else:
                    temporary.unlink()
            meta = {
                "status": "complete",
                "seconds": time.perf_counter() - started,
                "retained": retained,
                "geometry": geometry,
                "serialized_bytes": serialized_bytes,
            }
            write(receipt, meta)
            dataset.geometry_cache_receipt = {**meta, "hit": False, "key": key}
            return dataset
        except Exception as exc:
            # A shared preprocessing failure is never disguised as a fitted model.
            write(
                receipt,
                {
                    "status": "failed",
                    "seconds": time.perf_counter() - started,
                    "error": str(exc),
                    "error_type": type(exc).__name__,
                    "resource_limited": isinstance(exc, TimeoutError),
                },
            )
            raise
