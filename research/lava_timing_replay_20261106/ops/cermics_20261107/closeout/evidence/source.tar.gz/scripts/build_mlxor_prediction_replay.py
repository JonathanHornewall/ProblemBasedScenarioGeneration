#!/usr/bin/env python3
"""Build the compact MLxOR prediction, regret, and timing replays.

The paper retains one shortest-path LP, one random LP, and the integral
PredictiveCO top-k LP.  It reuses the frozen ten-seed winning configurations
for BCR--SoftRadial, MSE, WISE, and SPO+.  Only BCR receives the
decision-preserving physical-cost sidecar.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

CONTINUOUS_REPRESENTATIVES = {
    "dys_shortest_path_25x25": "largest DYS shortest-path route",
    "lava_random_lp_150x50_paper_appendix": ("LAVA paper-appendix random-LP route"),
}
CONTINUOUS_METHODS = {"soft_radial_log_barrier", "mse", "wise", "spo_plus"}
TOPK_METHODS = {
    "soft_radial_log_barrier",
    "mse",
    "wise",
    "spo_plus_relaxation",
}


def _prepare(raw: dict[str, Any]) -> dict[str, Any]:
    variant = copy.deepcopy(raw)
    original_name = str(variant["name"])
    variant["name"] = f"mlxor_prediction_{original_name}"
    if variant["method"] == "soft_radial_log_barrier":
        parameters = dict(variant.get("method_parameters", {}))
        parameters.update(
            {
                "prediction_correction": True,
                "prediction_correction_cone": True,
                "prediction_correction_exact_only": True,
                "prediction_correction_include_projected_head": False,
                "prediction_correction_legacy": False,
                "prediction_correction_minimum_scale": 1e-6,
                "prediction_correction_mse_epochs": 180,
                "prediction_correction_mse_learning_rate": 3e-4,
                "prediction_correction_mu_normalize_directions": True,
                "prediction_correction_neural": True,
                "prediction_correction_neural_epochs": 1,
                "prediction_correction_neural_learning_rates": [1e-3],
                "prediction_correction_neural_patience": 1,
                "prediction_correction_replay_audit_size": 4,
                "prediction_correction_ridges": [1e-5],
            }
        )
        variant["method_parameters"] = parameters
    return variant


def build(continuous: dict[str, Any], integer: dict[str, Any]) -> dict[str, Any]:
    selected: list[dict[str, Any]] = []
    for raw in continuous["variants"]:
        if (
            raw.get("method") in CONTINUOUS_METHODS
            and raw.get("benchmark_id") in CONTINUOUS_REPRESENTATIVES
        ):
            selected.append(_prepare(raw))
    for raw in integer["variants"]:
        if (
            raw.get("method") in TOPK_METHODS
            and raw.get("benchmark_id") == "predictiveco_cubic_topk"
        ):
            selected.append(_prepare(raw))

    identities = {(item["name"], int(item["seeds"]["data"])) for item in selected}
    if len(identities) != len(selected):
        raise ValueError("duplicate replay identity")
    expected = 3 * 4 * 10
    if len(selected) != expected:
        raise ValueError(f"expected {expected} variants, found {len(selected)}")
    return {
        "base": {},
        "design": {
            "purpose": "mlxor_compact_physical_cost_and_regret_replay",
            "source_manifests": [
                "configs/publication/continuous_confirmation.json",
                "configs/publication/integer_confirmation.json",
            ],
            "decision_hyperparameters_changed": False,
            "test_already_opened_in_source_campaign": True,
            "selection_role": (
                "post_hoc_prediction_diagnostic_not_decision_model_selection"
            ),
            "continuous_representatives": CONTINUOUS_REPRESENTATIVES,
            "topk_representative": (
                "PredictiveCO cubic top-k; integral polytope with zero LP gap"
            ),
            "methods": sorted(CONTINUOUS_METHODS | TOPK_METHODS),
            "paired_seed_count": 10,
            "variant_count": len(selected),
        },
        "name": "mlxor_prediction_representative_replay",
        "run_root": "results/campaigns/mlxor_prediction_representative_replay",
        "variants": selected,
    }


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    continuous = json.loads(
        (root / "configs/publication/continuous_confirmation.json").read_text()
    )
    integer = json.loads(
        (root / "configs/publication/integer_confirmation.json").read_text()
    )
    campaign = build(continuous, integer)
    output = root / "configs/mlxor/prediction_replay.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(campaign, indent=2, sort_keys=True) + "\n")
    print(f"wrote {len(campaign['variants'])} variants to {output}")
    topk = copy.deepcopy(campaign)
    topk["name"] = "mlxor_prediction_replay_topk"
    topk["run_root"] = "results/campaigns/mlxor_prediction_replay_topk"
    topk["variants"] = [
        variant
        for variant in campaign["variants"]
        if variant["benchmark_id"] == "predictiveco_cubic_topk"
    ]
    topk["design"] = dict(campaign["design"])
    topk["design"]["purpose"] = "missing_topk_physical_cost_replay"
    topk["design"]["variant_count"] = len(topk["variants"])
    topk_output = root / "configs/mlxor/prediction_replay_topk.json"
    topk_output.write_text(json.dumps(topk, indent=2, sort_keys=True) + "\n")
    print(f"wrote {len(topk['variants'])} variants to {topk_output}")

    spo_prediction = copy.deepcopy(campaign)
    spo_prediction["name"] = "mlxor_prediction_replay_spo_diagnostic"
    spo_prediction["run_root"] = (
        "results/campaigns/mlxor_prediction_replay_spo_diagnostic"
    )
    spo_prediction["variants"] = [
        variant
        for variant in campaign["variants"]
        if variant["method"] in {"spo_plus", "spo_plus_relaxation"}
    ]
    spo_prediction["design"] = dict(campaign["design"])
    spo_prediction["design"]["purpose"] = (
        "physical_cost_diagnostic_replay_after_exposing_spo_cost_reports"
    )
    spo_prediction["design"]["variant_count"] = len(spo_prediction["variants"])
    spo_output = root / "configs/mlxor/prediction_replay_spo.json"
    spo_output.write_text(
        json.dumps(spo_prediction, indent=2, sort_keys=True) + "\n"
    )
    print(f"wrote {len(spo_prediction['variants'])} variants to {spo_output}")

    canonical = copy.deepcopy(
        next(
            variant
            for variant in topk["variants"]
            if variant["method"] == "spo_plus_relaxation"
            and variant["name"].endswith("seed1")
        )
    )
    canonical["name"] = "mlxor_pyepo_canonical_predictiveco_topk_seed1"
    canonical["method"] = "pyepo_spo_plus_relaxation"
    canonical["evaluate_test"] = False
    canonical_timing = {
        "base": {},
        "design": {
            "purpose": "canonical_pyepo_training_wall_time_only",
            "pyepo_version": "2.2.7",
            "test_evaluated": False,
            "zero_integrality_gap": True,
        },
        "name": "mlxor_pyepo_topk_timing",
        "run_root": "results/campaigns/mlxor_pyepo_topk_timing",
        "variants": [canonical],
    }
    timing_output = root / "configs/mlxor/pyepo_topk_timing.json"
    timing_output.write_text(
        json.dumps(canonical_timing, indent=2, sort_keys=True) + "\n"
    )
    print(f"wrote canonical timing config to {timing_output}")
    smoke_variant = copy.deepcopy(
        next(
            variant
            for variant in campaign["variants"]
            if variant["method"] == "soft_radial_log_barrier"
        )
    )
    smoke_variant["name"] = "mlxor_prediction_correction_smoke"
    smoke_variant["sizes"] = {"train": 32, "validation": 24, "test": 24}
    smoke_variant["training"].update(
        {
            "epochs": 2,
            "patience": 3,
            "schedule_reference_epochs": 2,
            "selection_mode": "last",
            "validation_epochs": [2],
            "validation_interval": 2,
        }
    )
    smoke_variant["method_parameters"].update(
        {
            "prediction_correction_mse_epochs": 2,
            "prediction_correction_replay_audit_size": 2,
        }
    )
    smoke = {
        "base": {},
        "design": {"purpose": "execution_smoke_only"},
        "name": "mlxor_prediction_correction_smoke",
        "run_root": "results/campaigns/mlxor_prediction_correction_smoke",
        "variants": [smoke_variant],
    }
    smoke_output = root / "configs/mlxor/prediction_smoke.json"
    smoke_output.write_text(json.dumps(smoke, indent=2, sort_keys=True) + "\n")
    print(f"wrote smoke config to {smoke_output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
