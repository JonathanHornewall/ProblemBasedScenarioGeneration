"""Execute an append-only leased queue; the CERMICS coordinator owns selection."""
import argparse
import fcntl
import os
import signal
import time
import psutil
from pathlib import Path

from build_central_path_final import read, write
import central_path_cloud as cloud


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    args = p.parse_args()
    root = args.root.resolve()
    guard = (root/'worker.lock').open('a')
    fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
    config = read(root/'cloud_contract.json')
    stop = False
    def signal_stop(*_):
        nonlocal stop
        stop = True
    signal.signal(signal.SIGTERM,signal_stop)
    signal.signal(signal.SIGINT,signal_stop)
    os.environ['CENTRAL_PATH_FROZEN_DATA_READONLY'] = '1'
    cloud.reservation = lambda job,cached=None: 0.95 if job['method'] in ('mse','wise','spo_plus') else 1.5
    path = root/'execution.json'
    last_mtime = 0
    def refresh():
        nonlocal last_mtime
        mtime = path.stat().st_mtime_ns
        changed = mtime != last_mtime
        last_mtime = mtime
        return changed
    def stopping():
        sent = sum(v.bytes_sent for k,v in psutil.net_io_counters(pernic=True).items() if k != 'lo')
        return (stop or (root/'STOP').exists() or time.time() >= config['scientific_deadline_unix']
                or sent >= config['egress_stop_gib']*2**30)
    while not stopping():
        if path.exists():
            cloud.run_stage(root,path,workers=config['workers'],memory_gib=config['memory_gib'],
                deadline=config['scientific_deadline_unix'],stopping=stopping,refresh=refresh)
        write(root/'worker_state.json',{'updated_unix':time.time(),'status':'waiting_for_leases','pid':os.getpid()})
        time.sleep(3)
    write(root/'worker_state.json',{'updated_unix':time.time(),'status':'stopped','pid':os.getpid()})


if __name__ == '__main__':
    main()
