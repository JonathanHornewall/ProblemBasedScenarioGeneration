"""Full, ordered linear campaign; no refinement and no pilot result reuse."""
from __future__ import annotations

import argparse
import collections
import copy
import itertools
import os
import time
from pathlib import Path

from physical128_data import bank_key
from pilot_common import CPS, EPOCHS, LARGE, SMALLEST, digest, family, read, sha, write
from simplified_data import REVISION

WCP = 'central_path_wise_validation'
MAIN = ['mse', CPS, WCP, 'wise', 'spo_plus', 'pfyl', 'nce', 'lava']
WISE = ['wise_spo_plus', 'wise_pfyl', 'wise_nce', 'wise_lava']
METHODS = MAIN + WISE
LR = [0.0003, 0.001, 0.003, 0.01]
ALPHA = [0.01, 0.03, 0.1, 0.3, 1., 3., 10.]
SIGMA = ALPHA
RHO = [0.25, 0.5, 0.75, 0.9]
KAPPA = [0.03, 0.3, 1., 3., 10.]
CONTRACTION = ['rational', 'exponential', 'hyperbolic']
SOLVE_RATIO = [0.01, 0.03, 0.05, 0.1, 0.2, 0.5, 1.]
THRESHOLD = [0., -0.01, -0.1, -1.]


def base_method(method):
    return CPS if method == WCP else 'mse' if method == 'wise' else method.removeprefix('wise_')


def applicable(method, route):
    return base_method(method) != 'lava' or family(route) in ('kp', 'rlp')


def grid(method):
    base = base_method(method)
    if base == CPS:
        return [dict(learning_rate=lr, alpha=alpha, rho=rho, contraction=contraction, kappa=kappa)
                for lr, alpha, rho, contraction, kappa in itertools.product(LR, ALPHA, RHO, CONTRACTION, KAPPA)]
    extra = ('sigma', SIGMA) if base == 'pfyl' else ('solve_ratio', SOLVE_RATIO) if base == 'nce' else (
             'threshold', THRESHOLD) if base == 'lava' else (None, [None])
    return [dict(learning_rate=lr, **({extra[0]: v} if extra[0] else {})) for lr, v in itertools.product(LR, extra[1])]


def make_job(template, method, route, seeds, choices, *, stage='screen', oracle='continuous_relaxation', preflight=False):
    method = 'wise' if method == 'wise_mse' else method
    c = copy.deepcopy(template['config'])
    for k in ('name',): c.pop(k, None)
    c.update(benchmark_id=route, seeds=copy.deepcopy(seeds), evaluate_test=stage == 'confirmation',
        sizes={'train': 100, 'validation': 32, 'test': 100}, workers=1,
        interface='full', physical_cost_output=base_method(method) != CPS)
    c['training'].update(optimizer='adam', weight_decay=0., gradient_clip=None,
        learning_rate=choices['learning_rate'], batch_size=32, epochs=2 if preflight else 300,
        schedule_reference_epochs=300, learning_rate_schedule='constant',
        validation_epochs=[1, 2] if preflight else EPOCHS, patience=301, minimum_delta=1e-8,
        selection_mode='last' if stage == 'timing' else 'validation_regret', torch_threads=1,
        maximum_optimization_seconds=3600. if base_method(method) == 'lava' and stage != 'timing' else None)
    parameters = {}
    if base_method(method) == CPS:
        c.pop('physical_cost_output', None)
        c['method'] = 'soft_radial_log_barrier'
        c['method_parameters'].update(alpha_start=choices['alpha'], alpha_end=choices['alpha'],
            schedule='fixed', guard_safety_factor=choices['rho'], contraction=choices['contraction'],
            contraction_scale=choices['kappa'], minimum_scale=0.01, kernel_backend='torch', torch_device='cpu')
    else:
        c.update(method='mse', method_parameters={}, cost_coordinate_normalization='none')
        if base_method(method) == 'pfyl': parameters = {'sigma': choices['sigma'], 'n_samples': 1}
        if base_method(method) == 'nce': parameters = {'solve_ratio': choices['solve_ratio']}
        if base_method(method) == 'spo_plus': parameters = {'solve_ratio': 1.}
        if base_method(method) == 'lava': parameters = {'threshold': choices['threshold'], 'vertex_tolerance': 0.}
    is_lava = base_method(method) == 'lava'
    job = {'simplified_revision': REVISION, 'method': method, 'base_method': base_method(method),
        'wise_transform': method == WCP or method == 'wise' or method.startswith('wise_'),
        'config': c, 'parameters': parameters, 'choices': choices, 'route': route, 'stage': stage,
        'training_oracle': oracle, 'architecture_arm': 'linear',
        'linear_scale_revision': 'linear_scale_20260928_v1',
        'validation_costs': 'single_sample', 'analytic_validation': False,
        'resource_limits': {'preprocessing_cap_seconds': 3600 if is_lava else None,
            'job_wall_cap_seconds': 9000 if is_lava else None}}
    if stage == 'timing': job['frozen_horizon'] = 2 if preflight else 300
    if preflight: job['diagnostic_only'] = True
    job['candidate'] = digest({'method': method, 'choices': choices})[:20]
    job['id'] = 'simplified__' + digest(job)[:32]
    c['name'] = job['id']
    return job


def manifest(job):
    return {'protocol': {'simplified_revision': REVISION}, 'jobs': [job]}


def provision(job):
    if job['route'] == 'dys_cfl_500x10' or (job['route'] in LARGE and job['base_method'] == CPS): return 12
    return 6 if job['route'] in LARGE else 3


def environment(root):
    root = Path(root); code = root / 'code'; env = dict(os.environ)
    for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
        env[key] = '1'
    env.update(PYTHONUNBUFFERED='1', PYTHONPATH=f'{code}/scripts:{code}/src:{code}/vendor/external/src',
        SOLVER_FREE_DFL_REPO=str(code/'vendor/public'), DFL_EXTENSIONS_SRC=str(code/'vendor/external/src'),
        ATLANTA_SOURCE_MANIFEST=str(root/'source_receipt.json'), CENTRAL_PATH_FROZEN_DATA=str(root/'frozen_data'),
        CP_SPO_GEOMETRY_CACHE=str(root/'policy_geometry_cache'), CP_SPO_PREPARATION_CACHE=str(root/'observed_preparation_cache'),
        CENTRAL_PATH_GEOMETRY_CACHE=str(root/'lava_geometry_cache'), SIMPLIFIED_ROOT=str(root))
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    # The new campaign prepares its own policy cache and never writes the pilot.
    env.pop('CP_SPO_GEOMETRY_CACHE_READONLY', None)
    return env


def assert_adam(optimizer, spec):
    import torch
    if type(optimizer) is not torch.optim.Adam or spec.gradient_clip is not None:
        raise ValueError('New campaign requires Adam without clipping')
    d = optimizer.defaults
    if (d['betas'], d['eps'], d['amsgrad'], d['weight_decay']) != ((.9, .999), 1e-8, False, 0.):
        raise ValueError('New campaign requires standard Adam defaults')


def save_training_clock(directory, job, elapsed, epochs_completed, batch_examples, update, *, active=False):
    root = Path(os.environ.get('SIMPLIFIED_ROOT', Path(directory).parent))
    path = root / 'results/training_clocks' / (job['id'] + '.json')
    write(path, {'job_id': job['id'], 'consumed_training_seconds': elapsed,
        'scientific_training_limit_seconds': None, 'epochs_completed': epochs_completed,
        'batch_examples': batch_examples, 'active_since_unix': time.time() if active else None})
    update('training', optimization_seconds=elapsed)


def build(pilot_root, root):
    old = read(pilot_root / 'PLAN.json'); templates = {}
    for group in old['step1_groups']:
        j = old['step1_jobs'][group['arms']['no_clip_no_decay_batch32'][0]]
        templates.setdefault(j['method'], j)
    routes = sorted(old['cells']); seeds = copy.deepcopy(old['cells'])
    # One fixed historical development bundle per family, shared by every
    # candidate/method; ten full paired final bundles are shared across routes.
    for v in seeds.values():
        if len(v['confirmation']) != 10: raise ValueError('Ten paired final seeds required')
        v.pop('refinement', None)
    screen_jobs = []
    for method in METHODS:
        for route in SMALLEST.values():
            if applicable(method, route):
                screen_jobs += [make_job(templates[base_method(method)], method, route, seeds[route]['screen'], q)
                                for q in grid(method)]
    counts = dict(collections.Counter(j['method'] for j in screen_jobs))
    final_count = sum(10 for m in METHODS for r in routes if applicable(m, r))
    if len(screen_jobs) != 14016 or final_count != 2200 or counts[CPS] + counts[WCP] != 13440:
        raise ValueError(('Unexpected full screen/final count', len(screen_jobs), final_count, counts))
    keys = sorted({r+'__data'+str(s['data']) for r in routes for s in seeds[r]['confirmation']} |
        {r+'__data'+str(seeds[r]['screen']['data']) for r in SMALLEST.values()})
    plan = {'revision': REVISION, 'method_order': MAIN, 'wise_stage_order': WISE,
        'logical_aliases': {'wise_mse': 'wise'}, 'routes': routes, 'smallest_routes': SMALLEST,
        'cells': seeds, 'templates': templates, 'bank_keys': keys,
        'screen_jobs': screen_jobs, 'counts': {'screens': len(screen_jobs), 'finals': final_count,
            'cp_and_wcp_screens': 13440, 'screens_by_method': counts},
        'optimizer': {'class': 'Adam', 'betas': [.9, .999], 'eps': 1e-8, 'amsgrad': False,
            'weight_decay': 0., 'gradient_clip': None},
        'maximum_allocated_cpus': 150, 'integer_diagnostic_seed_index': 0,
        'integer_training_budget_seconds': None, 'integer_overall_wall_limit_seconds': None,
        'source_pilot_plan_sha256': sha(pilot_root / 'PLAN.json'),
        'observed_data_policy': 'reuse exact train100/validation32 banks',
        'test_policy': 'new derived stream, analytic conditional expectations, sealed until final checkpoint freeze',
        'scientific_launch_authorized': True}
    write(root / 'PLAN.json', plan, immutable=True)
    write(root / 'BUILD_COUNTS.json', plan['counts'], immutable=True)
    return plan


def successful(record):
    return bool(record and record['status'] == 'complete' and not record.get('smoke_only')
        and record.get('summary', {}).get('epochs_completed') == 300
        and not record['summary'].get('optimization_cap_reached'))


def score(record):
    if record.get('test_access') or record.get('test_bank_opened') or record.get('summary', {}).get('test') is not None:
        raise ValueError('Development selection received test access')
    if not successful(record): return None
    value = float(record['summary']['best_selection_score'])
    import math
    return value if math.isfinite(value) else None


class Campaign:
    def __init__(self, root):
        self.root = Path(root); self.plan = read(self.root / 'PLAN.json'); self.jobs = {}; self.records = {}
        self.selections = {}; self.final_groups = {}; self.timing_groups = {}; self.integer_jobs = []
        for j in self.plan['screen_jobs']: self.require(j)
        for p in (self.root / 'jobs').glob('*.json'):
            j = read(p)['jobs'][0]; self.jobs[j['id']] = j

    def record(self, j):
        jid = j if isinstance(j, str) else j['id']
        if jid in self.records: return self.records[jid]
        path = self.root / 'results/receipts' / (jid + '.json')
        if path.exists():
            r = read(path)
            if digest(r['job']) != digest(self.jobs[jid]) or r['status'] not in ('complete', 'failed', 'censored'):
                raise ValueError('Terminal receipt identity/status differs')
            self.records[jid] = r
            return r

    def require(self, j):
        if j['id'] in self.jobs:
            if self.jobs[j['id']] != j: raise ValueError('Immutable job collision')
        else:
            write(self.root / 'jobs' / (j['id'] + '.json'), manifest(j), immutable=True)
            self.jobs[j['id']] = j
        return self.record(j)

    def select(self, method, fam):
        key = method + '__' + fam
        if key in self.selections: return self.selections[key]
        jobs = [j for j in self.plan['screen_jobs'] if j['method'] == method and family(j['route']) == fam]
        records = [self.record(j) for j in jobs]
        if any(r is None for r in records): return None
        rows = [(score(r), i, j) for i, (j, r) in enumerate(zip(jobs, records))]
        eligible = [v for v in rows if v[0] is not None]
        eligible.sort(key=lambda v: (v[0], v[1]))
        result = {'method': method, 'family': fam, 'selected_template': eligible[0][2] if eligible else None,
            'score': eligible[0][0] if eligible else None, 'test_scores_read': False,
            'screen_fits': len(jobs), 'unavailable': [{'id': j['id'], 'status': r['status'], 'error': r.get('error')}
                for j, r in zip(jobs, records) if not successful(r)],
            'tie_rule': 'observed validation score then declared Cartesian candidate order',
            'final_checkpoint_rule': 'each refit selects its own checkpoint on its own validation32'}
        write(self.root / 'selections' / (key + '.json'), result, immutable=True)
        self.selections[key] = result
        return result

    def advance_group(self, methods, label):
        all_terminal = True
        for method in methods:
            assignments = []
            for route in self.plan['routes']:
                if not applicable(method, route): continue
                selected = self.select(method, family(route))
                if selected is None:
                    all_terminal = False
                    continue
                template = selected['selected_template']
                if template is None: continue
                for seed in self.plan['cells'][route]['confirmation']:
                    j = make_job(template, method, route, seed, template['choices'], stage='confirmation')
                    self.require(j); assignments.append(j['id'])
            self.final_groups[method] = assignments
            selections_ready = all(self.select(method, f) is not None for f, r in SMALLEST.items() if applicable(method, r))
            terminal = selections_ready and all(self.record(j) for j in assignments)
            if not terminal: all_terminal = False
            elif not (self.root / 'milestones' / (method + '.json')).exists():
                records = [self.record(j) for j in assignments]
                write(self.root / 'milestones' / (method + '.json'), {'method': method, 'stage': label,
                    'final_fits': len(records), 'counts': dict(collections.Counter(r['status'] for r in records)),
                    'paired_test_mean_regret': {route: [self.record(i)['summary']['test']['mean_regret']
                        for i in assignments if self.jobs[i]['route'] == route and successful(self.record(i))
                        and self.record(i)['summary'].get('test')] for route in self.plan['routes'] if applicable(method, route)},
                    'finished_unix': time.time()}, immutable=True)
        return all_terminal

    def timing(self, methods, label):
        ids = []
        for method in methods:
            for route in self.plan['routes']:
                if not applicable(method, route): continue
                selected = self.select(method, family(route))
                if not selected or not selected['selected_template']: continue
                t = selected['selected_template']
                seed = self.plan['cells'][route]['confirmation'][0]
                j = make_job(t, method, route, seed, t['choices'], stage='timing')
                j['timing_stage'] = label
                # Include timing provenance in the immutable execution identity.
                j['config'].pop('name'); j['id'] = 'simplified_timing__' + digest(j)[:32]; j['config']['name'] = j['id']
                self.require(j); ids.append(j['id'])
        self.timing_groups[label] = ids
        return all(self.record(j) for j in ids)

    def advance(self):
        main_done = self.advance_group(MAIN, 'main')
        main_timing_done = self.timing(MAIN, 'main') if main_done else False
        wise_done = self.advance_group(WISE, 'wise') if main_done else False
        wise_timing_done = self.timing(WISE, 'wise') if wise_done else False
        integer_ready = main_done and wise_done and main_timing_done and wise_timing_done
        if integer_ready:
            native_routes = read(self.root / 'DATA_READY.json')['native_integer_routes']
            for base in ('spo_plus', 'pfyl', 'nce'):
                for method in (base, 'wise_' + base):
                    for route in native_routes:
                        selected = self.select(method, family(route))
                        if not selected or not selected['selected_template']: continue
                        t = selected['selected_template']
                        j = make_job(t, method, route, self.plan['cells'][route]['confirmation'][0],
                            t['choices'], stage='confirmation', oracle='native_integer')
                        self.require(j)
                        if j['id'] not in self.integer_jobs: self.integer_jobs.append(j['id'])
            write(self.root / 'INTEGER_SCOPE.json', {'fits': len(self.integer_jobs), 'ids': self.integer_jobs,
                'non_native_routes_not_applicable': sorted(set(self.plan['routes']) - set(native_routes)),
                'training_budget_seconds_per_fit': None, 'retuning_candidates': 0}, immutable=True)
        done = integer_ready and all(self.record(i) for i in self.integer_jobs)
        pending_main = []; pending_timing = []
        for j in self.jobs.values():
            if self.record(j): continue
            if j['stage'] == 'timing':
                pending_timing.append(j)
            elif j['training_oracle'] == 'native_integer':
                if integer_ready: pending_timing.append(j)
            elif j['method'] in MAIN or main_done:
                pending_main.append(j)
        pending_main.sort(key=lambda j: (METHODS.index(j['method']), j['stage'] != 'confirmation',
                                         list(SMALLEST).index(family(j['route'])), j['choices']['learning_rate'], j['id']))
        integer_order = ['spo_plus', 'wise_spo_plus', 'pfyl', 'wise_pfyl', 'nce', 'wise_nce']
        pending_timing.sort(key=lambda j: (2 if j['training_oracle'] == 'native_integer' else 0 if j['timing_stage'] == 'main' else 1,
            integer_order.index(j['method']) if j['training_oracle'] == 'native_integer' else METHODS.index(j['method']), j['route']))
        phase = 'complete' if done else 'integer' if integer_ready else 'wise' if main_done else 'main'
        for role, jobs in (('main', pending_main), ('timing', pending_timing)):
            # A bounded ready queue, regenerated as completions arrive.
            write(self.root / ('QUEUE_' + role + '.json'), {'phase': phase, 'jobs': [
                {'id': j['id'], 'memory_gib': provision(j), 'method': j['method']} for j in jobs[:512]],
                'science_complete': main_done and wise_done, 'updated_unix': time.time()})
        status = {'status': phase, 'main_science_done': main_done, 'wise_science_done': wise_done,
            'main_timing_done': main_timing_done, 'wise_timing_done': wise_timing_done,
            'registered_unique_fits': len(self.jobs), 'terminal_counts': dict(collections.Counter(r['status'] for r in self.records.values())),
            'pending_main': len(pending_main), 'pending_serial': len(pending_timing), 'updated_unix': time.time()}
        write(self.root / 'STATUS.json', status)
        if done and not (self.root / 'CAMPAIGN_COMPLETE.json').exists():
            write(self.root / 'CAMPAIGN_COMPLETE.json', status, immutable=True)
        return done


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--root', type=Path, required=True)
    p.add_argument('--pilot-root', type=Path, required=True); a = p.parse_args()
    result = build(a.pilot_root.resolve(), a.root.resolve()); print(result['counts'])
