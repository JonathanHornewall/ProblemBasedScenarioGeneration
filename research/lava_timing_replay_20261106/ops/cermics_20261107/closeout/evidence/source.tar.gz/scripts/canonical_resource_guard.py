#!/usr/bin/env python3
"""Enforce declared wall limits outside native solver calls, without restarting fits.

The campaign worker remains the only receipt writer. This bounded companion
records a separate enforcement event and terminates only verified run-owned
children after their existing limit plus the worker's 15-second grace period.
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
import signal
import socket
import sqlite3
import time
from pathlib import Path

import psutil

from build_central_path_final import read, write


def resource_limits(defaults, job):
    return {**defaults, **job.get("resource_limits", {})}


def limit_reason(defaults, job, phase, elapsed, grace=15):
    limits = resource_limits(defaults, job)
    if phase in (None, "imports", "preprocessing") and elapsed > limits["preprocessing_cap_seconds"] + grace:
        return "preprocessing_time_cap"
    if elapsed > limits["job_wall_cap_seconds"] + grace:
        return "wall_time_cap"
    return None


def owned_command(command, root, index):
    expected = [str(root / "code/scripts/run_central_path_final.py"), "--manifest",
                str(root / "execution.json"), "--job-index", str(index),
                "--output-root", str(root / "results")]
    return len(command) == len(expected) + 1 and command[1:] == expected


def watch(root, allocation):
    if (os.environ.get("SLURM_JOB_ID") != str(allocation)
        or socket.gethostname().split(".")[0] != "node08"):
        raise RuntimeError("Guard must run inside the authorized node08 allocation")
    output = root / "results/resource_enforcement"
    output.mkdir(exist_ok=True)
    guard = (output / "watch.lock").open("a")
    fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
    state = read(root / "burst_state.json")
    if str(state["slurm_job_id"]) != str(allocation):
        raise RuntimeError("Guard allocation does not own this campaign")
    deadline = state["deadline_unix"] - 20
    defaults = read(root / "screen.json")["protocol"]
    db = sqlite3.connect(f"file:{root / 'burst.sqlite'}?mode=ro", uri=True, timeout=30)
    db.row_factory = sqlite3.Row
    stopped = False
    events = {}
    def stop(signum, frame):
        nonlocal stopped
        stopped = True
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    while not stopped and time.time() < deadline:
        state = read(root / "burst_state.json")
        if str(state["slurm_job_id"]) != str(allocation) or state.get("status") == "complete":
            break
        rows = db.execute("SELECT * FROM jobs WHERE status='running'").fetchall()
        active = []
        for row in rows:
            job = json.loads(row["payload"])
            # This companion is scoped to the remaining sampled NCE work.
            if job["method"] != "nce" or job.get("validation_costs") != "single_sample":
                continue
            receipt = root / "results/receipts" / (job["id"] + ".json")
            progress = root / "results/progress" / (job["id"] + ".json")
            if receipt.exists() or not progress.exists():
                continue
            record = read(progress)
            try:
                proc = psutil.Process(record["pid"])
                if (not owned_command(proc.cmdline(), root, row["idx"])
                    or proc.ppid() != row["worker"]
                    or abs(proc.create_time() - row["started"]) > 30
                    or os.getpgid(proc.pid) != proc.pid):
                    raise RuntimeError("Refusing an unverified fit process identity")
                origin = max(proc.create_time(), row["started"])
                elapsed = time.time() - origin
                reason = limit_reason(defaults, job, record.get("phase"), elapsed)
                active.append({"id": job["id"], "pid": proc.pid, "elapsed": elapsed,
                    "job_wall_cap_seconds": resource_limits(defaults, job)["job_wall_cap_seconds"],
                    "enforcement_due_unix": origin + resource_limits(defaults, job)["job_wall_cap_seconds"] + 15})
                if reason is None or receipt.exists():
                    continue
                event = {"job": job, "reason": reason, "status": "enforcing",
                    "created_unix": time.time(), "pid": proc.pid, "worker_pid": proc.ppid(),
                    "process_created_unix": proc.create_time(), "elapsed_seconds": elapsed,
                    "declared_limits": resource_limits(defaults, job), "grace_seconds": 15,
                    "allocation": allocation, "partial_progress": record,
                    "receipt_writer": "existing canonical campaign worker"}
                event_path = output / (job["id"] + ".json")
                if event_path.exists():
                    raise RuntimeError("Refusing duplicate enforcement for a fit")
                write(event_path, event)
                # A successful receipt always wins a near-boundary race.
                if not receipt.exists() and owned_command(proc.cmdline(), root, row["idx"]):
                    os.killpg(proc.pid, signal.SIGTERM)
                    try:
                        proc.wait(timeout=5)
                    except psutil.TimeoutExpired:
                        if owned_command(proc.cmdline(), root, row["idx"]):
                            os.killpg(proc.pid, signal.SIGKILL)
                            proc.wait(timeout=5)
                event.update(status="process_stopped", stopped_unix=time.time())
                write(event_path, event)
                events[job["id"]] = event_path
            except (psutil.NoSuchProcess, ProcessLookupError):
                continue
        for job_id, path in list(events.items()):
            receipt = root / "results/receipts" / (job_id + ".json")
            if receipt.exists():
                value = read(receipt)
                event = read(path)
                event.update(status="receipt_verified", receipt_status=value["status"],
                    receipt_error=value.get("error"), verified_unix=time.time())
                write(path, event)
                del events[job_id]
        write(root / "declared_wall_guard_status.json", {"updated_unix": time.time(),
            "status": "watching", "allocation": allocation, "deadline_unix": deadline,
            "active": active, "awaiting_receipts": list(events)})
        time.sleep(3)
    db.close()
    write(root / "declared_wall_guard_status.json", {"updated_unix": time.time(),
        "status": "stopped", "allocation": allocation, "deadline_unix": deadline,
        "awaiting_receipts": list(events)})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--allocation", type=int, required=True)
    args = parser.parse_args()
    watch(args.root.resolve(), args.allocation)
