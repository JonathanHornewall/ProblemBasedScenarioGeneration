"""Exact reused observations with a new upstream-only sealed test100 stream."""
from __future__ import annotations

import argparse
import os
import shutil
from dataclasses import replace
from pathlib import Path

import numpy as np

from physical128_data import array_hash, bank_key, json_value
from pilot_common import read, sha, write

REVISION = 'simplified_linear_test100_20261020_v1'


def analytic_test_reference(route, loaded):
    test = loaded.dataset.test
    receipt = next(x for x in loaded.provenance['conditional_reference']['splits'] if x['split'] == 'test')
    if receipt['estimator'].startswith('exact'):
        return test, receipt
    # Reuse the maintained analytic integrals, including rounding and clipping.
    # Direct factories also cover the authorized 500-customer/1000-item routes.
    from dfl_extensions_lab.benchmarks.families.published_single_stage import (
        make_dys_capacitated_facility_location, make_dys_two_dimensional_knapsack)
    if route.startswith('dys_cfl_'):
        customers, facilities = map(int, route.removeprefix('dys_cfl_').split('x'))
        benchmark = make_dys_capacitated_facility_location(customers=customers, facilities=facilities)
    elif route.startswith('dys_knapsack_'):
        items, constraints = map(int, route.removeprefix('dys_knapsack_').split('x'))
        if constraints != 2: raise ValueError('Unregistered knapsack law')
        benchmark = make_dys_two_dimensional_knapsack(items=items)
    else:
        raise ValueError('No registered exact test reference: ' + route)
    from exact_validation_reference import _compute_reference
    coeff, physical, formula = _compute_reference({'route': route}, test, benchmark=benchmark)
    return replace(test, conditional_mean_costs=physical, conditional_mean_coefficients=coeff), {
        'estimator': 'analytic integral of quantized uniform cost', 'formula': formula,
        'replaces': receipt, 'samples_per_context': 0}


def prepare(item):
    root, old_root, key = map(Path, item)
    key = str(key)
    destination = root / 'frozen_data' / key
    if (destination / 'receipt.json').exists():
        return read(destination / 'receipt.json')
    if destination.exists():
        raise RuntimeError('Incomplete data preparation requires review: ' + key)
    source = old_root / 'frozen_data' / key
    original = read(source / 'receipt.json')
    destination.mkdir(parents=True)
    for name in ('observations.npz', 'structure.npz', 'structure.json'):
        if sha(source / name) != original['files_sha256'][name]:
            raise ValueError('Observed input changed: ' + key + '/' + name)
        shutil.copyfile(source / name, destination / name)
    from proximal_spo.data import SplitSizes
    from proximal_spo.external_benchmarks import load_external_benchmark
    from proximal_spo.seeds import derive_seed
    from proximal_spo.feasible_policies import _geometry_cache_key
    route, data_seed = key.split('__data')
    test_seed = derive_seed(int(data_seed), REVISION, 'fresh-sealed-test-contexts')
    generated = load_external_benchmark(route, SplitSizes(1, 1, 100),
        data_seed=test_seed, conditional_reference_samples=1)
    test, test_reference = analytic_test_reference(route, generated)
    # Compare the exact native physical model while ignoring descriptive names.
    p = load_structure(destination)
    if _geometry_cache_key(p) != _geometry_cache_key(generated.problem):
        raise ValueError('Fresh test generation changed the native problem')
    with np.load(destination / 'observations.npz', allow_pickle=False) as a:
        observed = {k: a[k] for k in a.files}
    if any('conditional' in k or k.startswith('test') for k in observed):
        raise ValueError('Hidden information in fitting bank')
    for split in ('train', 'validation'):
        if observed[split+'__contexts'].shape[1] != test.contexts.shape[1] or observed[split+'__physical_costs'].shape[1] != test.physical_costs.shape[1]:
            raise ValueError('Fresh test and archived observed input contracts differ')
    arrays = {'test__' + k: getattr(test, k) for k in
        ('contexts', 'physical_costs', 'conditional_mean_costs', 'coefficients', 'conditional_mean_coefficients')
        if getattr(test, k) is not None}
    if array_hash(test.contexts) == original.get('array_hashes', {}).get('test', {}).get('contexts'):
        raise ValueError('Fresh test stream equals the historical bank')
    with (destination / 'test.npz').open('xb') as f:
        np.savez_compressed(f, **arrays)
    result = {'revision': REVISION, 'key': key, 'source_observed_receipt_sha256': sha(source / 'receipt.json'),
        'observations_policy': 'exact historical observed train100 and validation32; no hidden means',
        'test_policy': 'new independent derived test stream; analytic conditional mean reference',
        'test_seed': test_seed, 'source_data_seed': int(data_seed),
        'test_reference': test_reference,
        'sizes': {'train': 100, 'validation': 32, 'test': 100},
        'native_integer_count': int(np.count_nonzero(p.integrality)),
        'context_dimension': int(test.contexts.shape[1]),
        'known_structure_unchanged': True,
        'upstream_provenance': json_value(generated.provenance),
        'array_hashes': {k: array_hash(v) for k, v in observed.items()},
        'files_sha256': {n: sha(destination / n) for n in
            ('observations.npz', 'structure.npz', 'structure.json', 'test.npz')}}
    write(destination / 'receipt.json', result, immutable=True)
    return result


def load_structure(directory):
    from scipy.sparse import csc_matrix
    from proximal_spo.problem import LinearProblem
    m = read(directory / 'structure.json')
    with np.load(directory / 'structure.npz', allow_pickle=False) as a:
        matrix = csc_matrix((a['matrix_data'], a['matrix_indices'], a['matrix_indptr']),
                            shape=tuple(a['matrix_shape']))
        return LinearProblem(matrix, a['row_lower'], a['row_upper'], a['variable_lower'],
            a['variable_upper'], a['integrality'], m['name'], m['metadata'])


def load_job(job):
    from proximal_spo.data import DatasetBundle, PhysicalCostSplit
    from proximal_spo.external_benchmarks import ExternalBenchmarkLoad
    if job.get('simplified_revision') != REVISION or job['config']['sizes'] != {
            'train': 100, 'validation': 32, 'test': 100}:
        raise ValueError('Unregistered campaign data contract')
    directory = Path(os.environ['CENTRAL_PATH_FROZEN_DATA']) / bank_key(job)
    receipt = read(directory / 'receipt.json')
    for name in ('observations.npz', 'structure.npz', 'structure.json'):
        if sha(directory / name) != receipt['files_sha256'][name]:
            raise ValueError('Frozen fitting bank changed')
    with np.load(directory / 'observations.npz', allow_pickle=False) as a:
        arrays = {k: a[k] for k in a.files}
    if any('conditional' in k or k.startswith('test') for k in arrays):
        raise ValueError('Hidden information in fitting bank')
    splits = {}
    for s in ('train', 'validation', 'test'):
        prefix = 'train' if s == 'test' else s
        get = lambda k: arrays[prefix+'__'+k][:1] if s == 'test' else arrays[prefix+'__'+k]
        costs = get('physical_costs')
        coeff = get('coefficients') if prefix+'__coefficients' in arrays else None
        splits[s] = PhysicalCostSplit(get('contexts'), costs, costs, s,
            job['config']['seeds']['data'], coeff, coeff)
    m = read(directory / 'structure.json')
    with np.load(directory / 'structure.npz', allow_pickle=False) as a:
        dataset = DatasetBundle(**splits, fixed_anchor=a['fixed_anchor'], random_indices=a['random_indices'],
            benchmark_id=m['benchmark_id'], master_seed=m['master_seed'], law=m['law'],
            cost_statistic=a['cost_statistic'] if 'cost_statistic' in a else None)
    fitting_receipt = {k: receipt[k] for k in ('revision', 'key', 'source_observed_receipt_sha256',
        'observations_policy', 'sizes', 'native_integer_count', 'context_dimension', 'known_structure_unchanged') if k in receipt}
    return ExternalBenchmarkLoad(load_structure(directory), dataset, {'simplified_data': fitting_receipt,
        'test_bank_opened': False, 'generator_called_by_fit': False})


def test_split(job, directory, selection):
    from proximal_spo.data import PhysicalCostSplit
    if job['stage'] != 'confirmation' or not job['config']['evaluate_test']:
        raise RuntimeError('Test access forbidden before final checkpoint freeze')
    if not selection or selection.get('selection_uses_test'):
        raise RuntimeError('Missing observed-validation checkpoint freeze')
    write(Path(directory) / 'VALIDATION_SELECTION_FREEZE.json', selection, immutable=True)
    bank = Path(os.environ['CENTRAL_PATH_FROZEN_DATA']) / bank_key(job)
    receipt = read(bank / 'receipt.json')
    if sha(bank / 'test.npz') != receipt['files_sha256']['test.npz']:
        raise ValueError('Sealed test bank changed')
    write(Path(directory) / 'TEST_ACCESS.json', {'test_bank_sha256': receipt['files_sha256']['test.npz'],
        'validation_freeze_sha256': sha(Path(directory) / 'VALIDATION_SELECTION_FREEZE.json'),
        'test_scores_used_for_selection': False}, immutable=True)
    with np.load(bank / 'test.npz', allow_pickle=False) as a:
        x = {k: a[k] for k in a.files}
    if len(x['test__contexts']) != 100:
        raise ValueError('Test100 bank changed')
    coeff = x.get('test__coefficients')
    return PhysicalCostSplit(x['test__contexts'], x['test__physical_costs'], x['test__conditional_mean_costs'],
        'test', receipt['test_seed'], coeff, x.get('test__conditional_mean_coefficients', coeff))


if __name__ == '__main__':
    from concurrent.futures import ProcessPoolExecutor
    p = argparse.ArgumentParser(); p.add_argument('--root', type=Path, required=True)
    p.add_argument('--old-root', type=Path, required=True); p.add_argument('--workers', type=int, default=4)
    a = p.parse_args()
    if not os.environ.get('SLURM_JOB_ID') or not 1 <= a.workers <= 8:
        raise RuntimeError('Upstream numerical preparation requires bounded Slurm execution')
    plan = read(a.root / 'PLAN.json')
    with ProcessPoolExecutor(a.workers) as pool:
        records = list(pool.map(prepare, [(str(a.root), str(a.old_root), k) for k in plan['bank_keys']]))
    write(a.root / 'DATA_READY.json', {'status': 'complete', 'banks': len(records),
        'native_integer_routes': sorted({r['key'].split('__data')[0] for r in records if r['native_integer_count']})}, immutable=True)
