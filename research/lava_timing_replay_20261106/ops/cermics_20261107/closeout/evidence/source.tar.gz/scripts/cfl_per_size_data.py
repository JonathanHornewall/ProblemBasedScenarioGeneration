"""Add only missing CFL development observations; all numerical work is in Slurm."""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
import os
from pathlib import Path
import socket
import time

from pilot_common import read, sha, write
from cfl_per_size_retuning import ROUTES


def prepare(item):
    root, route = item
    root = Path(root)
    from scaled_data_neural_data import REVISION, prepare_retuning_development, prepare_retuning_validation
    plan = read(root / 'PLAN.json')
    key = route + '__data' + str(plan['cells'][route]['screen']['data'])
    source = Path(plan['pilot_root']) / 'frozen_data' / key
    bank = root / 'frozen_data' / key
    if not bank.exists():
        import numpy as np
        original = read(source / 'receipt.json')
        bank.mkdir(parents=True)
        for old_name, new_name in [('observations.npz', 'observations_n100.npz'),
                                   ('structure.npz', 'structure.npz'), ('structure.json', 'structure.json')]:
            if sha(source / old_name) != original['files_sha256'][old_name]:
                raise ValueError('Original development observations/structure changed')
            (bank / new_name).symlink_to(source / old_name)
        with np.load(bank / 'observations_n100.npz', allow_pickle=False) as data:
            if any('test' in k or 'conditional' in k for k in data.files):
                raise ValueError('Development observations contain hidden information')
            dimension = data['train__contexts'].shape[1]
        from simplified_data import load_structure
        receipt = {'revision': REVISION, 'key': key, 'available_train_sizes': [100],
            'sizes': {'train': 100, 'validation': 32, 'test': 100},
            'source_observed_receipt_sha256': sha(source / 'receipt.json'),
            'source_files_sha256': original['files_sha256'],
            'files_sha256': {n: sha(bank / n) for n in ('observations_n100.npz', 'structure.npz', 'structure.json')},
            'test_seed': None, 'test_policy': 'development-only bank; no test file prepared or opened',
            'observations_policy': 'exact archived per-route train100/validation32 observations',
            'native_integer_count': int(np.count_nonzero(load_structure(source).integrality)),
            'context_dimension': int(dimension), 'known_structure_unchanged': True}
        write(bank / 'receipt.json', receipt, immutable=True)
    training = prepare_retuning_development((root, key))
    validation = prepare_retuning_validation((root, key))
    result = {'route': route, 'key': key, 'status': 'complete',
        'training_receipt_sha256': sha(root / 'frozen_data/retuning_development' / key / 'receipt.json'),
        'validation_receipt_sha256': sha(root / 'frozen_data/retuning_validation' / key / 'receipt.json'),
        'training_sizes': training['available_train_sizes'],
        'validation_sizes': validation['available_validation_sizes'], 'finished_unix': time.time()}
    write(root / 'ops/preparation' / (route + '.json'), result, immutable=True)
    return result


def safe_prepare(item):
    try:
        return prepare(item)
    except Exception as exc:
        root, route = item
        result = {'route': route, 'status': 'failed', 'error': repr(exc), 'finished_unix': time.time()}
        write(Path(root) / 'ops/preparation' / (route + '.json'), result, immutable=True)
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    if not os.environ.get('SLURM_JOB_ID') or socket.gethostname().startswith('master'):
        raise RuntimeError('Bounded Slurm preparation required')
    if os.environ.get('SLURM_RESTART_COUNT', '0') != '0':
        permit = read(args.root / 'ops/PREP_UNSTARTED_REQUEUE.json')
        if (permit['job_id'] != os.environ['SLURM_JOB_ID'] or permit['prior_user_code_started'] is not False
                or permit['authorized_action'] != 'move_proven_unstarted_existing_job_to_defq_gpu'):
            raise RuntimeError('Interrupted numerical preparation cannot restart automatically')
    with ProcessPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(safe_prepare, [(str(args.root), r) for r in ROUTES]))
    write(args.root / 'ops/PREPARATION_STATUS.json', {'status': 'complete' if all(
        r['status'] == 'complete' for r in results) else 'failed', 'routes': results, 'finished_unix': time.time()})


if __name__ == '__main__':
    main()
