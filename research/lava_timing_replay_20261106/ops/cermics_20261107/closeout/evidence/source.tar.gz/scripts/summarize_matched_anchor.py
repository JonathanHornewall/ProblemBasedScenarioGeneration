"""Summarize paired corrected-versus-embedded-MSE anchored campaigns."""

from __future__ import annotations

import argparse
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]


def _paired_interval(values: list[float]) -> list[float] | None:
    if len(values) < 2:
        return None
    critical = {2: 12.706204736, 3: 4.30265273}.get(len(values))
    if critical is None:
        return None
    mean = statistics.mean(values)
    standard_error = statistics.stdev(values) / math.sqrt(len(values))
    return [mean - critical * standard_error, mean + critical * standard_error]


def summarize(run_root: Path) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for summary_path in sorted(run_root.glob("*/summary.json")):
        run = summary_path.parent
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        config = json.loads((run / "config.json").read_text(encoding="utf-8"))
        base = json.loads(
            (run / "embedded_mse_base.json").read_text(encoding="utf-8")
        )
        delta = float(summary["test"]["mean_regret"]) - float(
            base["test"]["mean_regret"]
        )
        rows.append(
            {
                "benchmark_id": str(config["benchmark_id"]),
                "name": str(config["name"]),
                "data_seed": int(config["seeds"]["data"]),
                "validation_regret": float(
                    summary["best_validation"]["mean_regret"]
                ),
                "test_regret": float(summary["test"]["mean_regret"]),
                "embedded_mse_validation_regret": float(
                    base["validation"]["mean_regret"]
                ),
                "embedded_mse_test_regret": float(base["test"]["mean_regret"]),
                "paired_test_delta": delta,
                "best_epoch": int(summary["best_epoch"]),
                "wall_seconds": float(
                    summary["whole_pipeline_training_wall_seconds"]
                ),
                "run_directory": str(run.relative_to(REPO_ROOT)),
            }
        )
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        key = row["benchmark_id"]
        if "matched_anchor_" in row["name"]:
            capacity = next(
                label for label in ("medium", "large") if f"_{label}_s" in row["name"]
            )
            key = f"{key}:{capacity}"
        groups[key].append(row)
    aggregates: list[dict[str, Any]] = []
    for key, group in sorted(groups.items()):
        deltas = [row["paired_test_delta"] for row in group]
        aggregates.append(
            {
                "group": key,
                "seed_count": len(group),
                "mean_test_regret": statistics.mean(
                    row["test_regret"] for row in group
                ),
                "mean_embedded_mse_test_regret": statistics.mean(
                    row["embedded_mse_test_regret"] for row in group
                ),
                "mean_paired_test_delta": statistics.mean(deltas),
                "relative_improvement": -statistics.mean(deltas)
                / statistics.mean(row["embedded_mse_test_regret"] for row in group),
                "paired_test_wins": sum(delta < 0 for delta in deltas),
                "paired_test_t_95_interval": _paired_interval(deltas),
                "mean_wall_seconds": statistics.mean(
                    row["wall_seconds"] for row in group
                ),
            }
        )
    return {
        "status": "complete",
        "run_root": str(run_root.relative_to(REPO_ROOT)),
        "rows": rows,
        "aggregates": aggregates,
    }


def _markdown(summary: dict[str, Any]) -> str:
    lines = [
        "# Matched MSE-anchor development",
        "",
        "Every row compares proximal correction with its identical embedded "
        "MSE checkpoint. Negative paired delta is better.",
        "",
        "| group | seeds | corrected | MSE | delta | relative gain | wins | wall s |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in summary["aggregates"]:
        lines.append(
            f"| {row['group']} | {row['seed_count']} | "
            f"{row['mean_test_regret']:.6f} | "
            f"{row['mean_embedded_mse_test_regret']:.6f} | "
            f"{row['mean_paired_test_delta']:+.6f} | "
            f"{100.0 * row['relative_improvement']:.1f}% | "
            f"{row['paired_test_wins']}/{row['seed_count']} | "
            f"{row['mean_wall_seconds']:.1f} |"
        )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", type=Path)
    parser.add_argument("output_stem")
    arguments = parser.parse_args()
    run_root = arguments.run_root.resolve()
    result = summarize(run_root)
    result_root = REPO_ROOT / "results" / "proximal_next"
    result_root.mkdir(parents=True, exist_ok=True)
    write_json(result_root / f"{arguments.output_stem}.json", result)
    (result_root / f"{arguments.output_stem}.md").write_text(
        _markdown(result), encoding="utf-8"
    )
    print(result_root / f"{arguments.output_stem}.md")


if __name__ == "__main__":
    main()
