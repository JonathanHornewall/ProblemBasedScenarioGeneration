"""Build the staged matched barrier/deployment mechanism ablation."""

from __future__ import annotations

import argparse
from pathlib import Path

from proximal_spo.artifacts import source_sha256, write_json
from proximal_spo.barrier_mechanism_ablation import (
    build_horizon_extension_campaign,
    build_paired_confirmation_campaign,
    build_paired_refinement_campaign,
    build_screen_campaign,
    load_json_object,
    validate_campaign,
)
from proximal_spo.development_analysis import completed_validation_rows

REPO_ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "stage",
        choices=("screen", "refinement", "horizon-extension", "confirmation"),
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-root", action="append", type=Path)
    parser.add_argument("--campaign-run-root", required=True)
    parser.add_argument(
        "--continuous-confirmation",
        type=Path,
        default=REPO_ROOT / "configs/publication/continuous_confirmation.json",
    )
    parser.add_argument("--selected-confirmation", type=Path)
    parser.add_argument("--boundary-horizon", type=int, default=300)
    parser.add_argument("--extended-horizon", type=int, default=600)
    arguments = parser.parse_args()

    if arguments.stage == "screen":
        if arguments.run_root:
            parser.error("screen does not accept --run-root")
        payload = build_screen_campaign(
            load_json_object(arguments.continuous_confirmation),
            run_root=arguments.campaign_run_root,
        )
    elif arguments.stage == "horizon-extension":
        if arguments.run_root:
            parser.error("horizon-extension does not accept --run-root")
        if arguments.selected_confirmation is None:
            parser.error("horizon-extension requires --selected-confirmation")
        payload = build_horizon_extension_campaign(
            load_json_object(arguments.selected_confirmation),
            run_root=arguments.campaign_run_root,
            boundary_horizon=arguments.boundary_horizon,
            extended_horizon=arguments.extended_horizon,
        )
    else:
        if not arguments.run_root:
            parser.error(f"{arguments.stage} requires --run-root")
        rows = completed_validation_rows(arguments.run_root)
        if arguments.stage == "refinement":
            payload = build_paired_refinement_campaign(
                rows, run_root=arguments.campaign_run_root
            )
        else:
            payload = build_paired_confirmation_campaign(
                rows, run_root=arguments.campaign_run_root
            )
    payload["source_sha256_at_generation"] = source_sha256(REPO_ROOT)
    validate_campaign(payload)
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.output, payload)
    print(f"wrote {len(payload['variants'])} variants to {arguments.output}")


if __name__ == "__main__":
    main()
