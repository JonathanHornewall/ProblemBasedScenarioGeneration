"""Validation-only selection and boundary gates for mollified PyEPO runs."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from collections import defaultdict
from contextlib import suppress
from pathlib import Path
from typing import Any

from mollified_pyepo_design import (
    DEVELOPMENT_SEEDS,
    INITIAL_TAU,
    REFINEMENT_RATES,
    REFINEMENT_TAUS,
    SCREEN_SIGMAS,
    _base,
    _neighbor_sigmas,
    _variant,
)

from proximal_spo.analysis import summarize_validation_selection
from proximal_spo.artifacts import source_sha256, write_json
from proximal_spo.config import RunSpec

REPO_ROOT = Path(__file__).resolve().parents[1]
ALLOWED_TAUS = REFINEMENT_TAUS


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in override.items():
        current = merged.get(key)
        if isinstance(current, dict) and isinstance(value, dict):
            merged[key] = _deep_merge(current, value)
        else:
            merged[key] = value
    return merged


def _arm_sha256(config: dict[str, Any]) -> str:
    arm = {key: value for key, value in config.items() if key not in {"name", "seeds"}}
    serialized = json.dumps(arm, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _resolve_receipt_path(path: str) -> Path:
    candidate = Path(path)
    return candidate if candidate.is_absolute() else REPO_ROOT / candidate


def _seed_key(seeds: dict[str, Any]) -> tuple[Any, ...]:
    return tuple(
        seeds.get(key)
        for key in ("structural", "data", "initialization", "shuffle", "perturbation")
    )


def _campaign_cells(
    payload: dict[str, Any], *, label: str
) -> set[tuple[str, tuple[Any, ...]]]:
    cells: set[tuple[str, tuple[Any, ...]]] = set()
    base = payload.get("base")
    variants = payload.get("variants")
    if not isinstance(base, dict) or not isinstance(variants, list):
        raise ValueError(f"expected a templated campaign: {label}")
    for variant in variants:
        if not isinstance(variant, dict):
            raise ValueError(f"campaign variant must be an object: {label}")
        spec = RunSpec.from_dict(_deep_merge(base, variant))
        config = spec.to_dict()
        cell = (_arm_sha256(config), _seed_key(config["seeds"]))
        if cell in cells:
            raise ValueError(f"duplicate expected arm x seed cell: {label}")
        cells.add(cell)
    return cells


def _expected_cells(campaigns: list[Path]) -> set[tuple[str, tuple[Any, ...]]]:
    cells: set[tuple[str, tuple[Any, ...]]] = set()
    for path in campaigns:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise ValueError(f"campaign must be an object: {path}")
        current = _campaign_cells(payload, label=str(path))
        overlap = cells & current
        if overlap:
            raise ValueError(
                f"campaigns repeat {len(overlap)} expected arm x seed cells"
            )
        cells.update(current)
    return cells


def _canonical_cells(
    variants: list[dict[str, Any]],
) -> set[tuple[str, tuple[Any, ...]]]:
    return _campaign_cells(
        {"base": _base(DEVELOPMENT_SEEDS[0]), "variants": variants},
        label="canonical mollified design",
    )


def _verify_screen_campaign(path: Path) -> None:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("screen campaign must be an object")
    variants = [
        _variant(
            seed=seed,
            sigma=sigma,
            tau=INITIAL_TAU,
            learning_rate=0.003,
            prefix="moll_screen",
        )
        for sigma in SCREEN_SIGMAS
        for seed in DEVELOPMENT_SEEDS
    ]
    if (
        payload.get("name") != "mollified_pyepo_development_screen"
        or payload.get("run_root") != "runs/mollified_pyepo/development_screen"
        or _campaign_cells(payload, label=str(path)) != _canonical_cells(variants)
    ):
        raise ValueError("screen campaign is not the canonical 18-cell design")


def _verify_refinement_campaign(path: Path) -> None:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("refinement campaign must be an object")
    design = payload.get("design_receipt")
    if not isinstance(design, dict):
        raise ValueError("refinement campaign lacks its design receipt")
    screen_path = _resolve_receipt_path(str(design.get("screen_selection")))
    screen_digest = design.get("screen_selection_sha256")
    if (
        not screen_path.is_file()
        or not isinstance(screen_digest, str)
        or _file_sha256(screen_path) != screen_digest
    ):
        raise ValueError("refinement campaign has no authenticated screen predecessor")
    screen, _ = _verify_static_selection_receipt(
        screen_path, required_stage="screen"
    )
    if design.get("screen_source_sha256") != screen.get("source_sha256"):
        raise ValueError("refinement and screen executable sources differ")
    positive = screen.get("best_positive_arm")
    if not isinstance(positive, dict):
        raise ValueError("screen predecessor has no best positive arm")
    parameters = positive.get("method_parameters")
    if not isinstance(parameters, dict):
        raise ValueError("screen best-positive arm is malformed")
    best_sigma = float(parameters["sigma"])
    sigmas = _neighbor_sigmas(best_sigma)
    variants = [
        _variant(
            seed=seed,
            sigma=sigma,
            tau=tau,
            learning_rate=rate,
            prefix="moll_refine",
        )
        for sigma, tau, rate in itertools.product(
            sigmas, REFINEMENT_TAUS, REFINEMENT_RATES
        )
        for seed in DEVELOPMENT_SEEDS
    ]
    expected_design = {
        "screen_selection": design.get("screen_selection"),
        "screen_selection_sha256": _file_sha256(screen_path),
        "screen_source_sha256": screen.get("source_sha256"),
        "best_positive_sigma": best_sigma,
        "refinement_sigmas": list(sigmas),
        "refinement_taus": list(REFINEMENT_TAUS),
        "refinement_learning_rates": list(REFINEMENT_RATES),
    }
    if design != expected_design:
        raise ValueError("refinement design receipt is not canonical")
    if (
        payload.get("name") != "mollified_pyepo_local_refinement"
        or payload.get("run_root") != "runs/mollified_pyepo/development_refinement"
        or _campaign_cells(payload, label=str(path)) != _canonical_cells(variants)
    ):
        raise ValueError(
            "refinement campaign is not the complete canonical Cartesian design"
        )


def _validate_expected_cells(summary: dict[str, Any], campaigns: list[Path]) -> None:
    expected = _expected_cells(campaigns)
    rows = summary.get("candidate_rows")
    if not isinstance(rows, list):
        raise ValueError("selection evidence lacks candidate rows")
    actual = {
        (str(row["arm_sha256"]), _seed_key(row["seeds"]))
        for row in rows
    }
    if actual != expected or len(rows) != len(expected):
        missing = expected - actual
        extra = actual - expected
        raise ValueError(
            "completed development cells do not exactly match the declared campaigns: "
            f"missing={len(missing)}, extra={len(extra)}, "
            f"duplicate_count={len(rows) - len(actual)}"
        )


def _verify_candidate_rows_against_live_runs(
    payload: dict[str, Any], campaigns: list[Path]
) -> None:
    source = payload.get("source_sha256")
    if not isinstance(source, str):
        raise ValueError("selection receipt lacks its executable source")
    expected = _expected_cells(campaigns)
    run_roots: set[Path] = set()
    for campaign in campaigns:
        campaign_payload = json.loads(campaign.read_text(encoding="utf-8"))
        run_root = campaign_payload.get("run_root")
        if not isinstance(run_root, str):
            raise ValueError("campaign lacks its run root")
        run_roots.add((REPO_ROOT / run_root).resolve())
    live_rows: list[dict[str, Any]] = []
    for run_root in sorted(run_roots):
        live = summarize_validation_selection(run_root, source_sha256=source)
        live_rows.extend(
            row
            for row in live["candidate_rows"]
            if (str(row["arm_sha256"]), _seed_key(row["seeds"])) in expected
        )
    _validate_expected_cells({"candidate_rows": live_rows}, campaigns)
    recorded = payload.get("candidate_rows")
    if not isinstance(recorded, list):
        raise ValueError("selection receipt lacks candidate rows")
    def row_key(row: dict[str, Any]) -> tuple[str, tuple[Any, ...]]:
        return str(row["arm_sha256"]), _seed_key(row["seeds"])

    def normalized(row: dict[str, Any]) -> dict[str, Any]:
        result = dict(row)
        run_directory = Path(str(result.get("run_directory")))
        if run_directory.is_absolute():
            with suppress(ValueError):
                run_directory = run_directory.relative_to(REPO_ROOT)
        result["run_directory"] = str(run_directory)
        return result

    recorded_normalized = [normalized(row) for row in recorded]
    live_normalized = [normalized(row) for row in live_rows]
    if sorted(recorded_normalized, key=row_key) != sorted(
        live_normalized, key=row_key
    ):
        raise ValueError("selection candidate rows differ from live run artifacts")


def _embedded_base_digests(summary: dict[str, Any]) -> list[dict[str, Any]]:
    by_seed: dict[tuple[Any, ...], set[str]] = defaultdict(set)
    seed_receipts: dict[tuple[Any, ...], dict[str, Any]] = {}
    for row in summary["candidate_rows"]:
        run_directory = Path(str(row["run_directory"]))
        if not run_directory.is_absolute():
            run_directory = REPO_ROOT / run_directory
        path = run_directory / "embedded_mse_base.json"
        if not path.is_file():
            raise ValueError(f"mollified arm lacks embedded MSE receipt: {path}")
        payload = json.loads(path.read_text(encoding="utf-8"))
        digest = payload.get("parameter_sha256")
        if not isinstance(digest, str) or len(digest) != 64:
            raise ValueError(f"malformed embedded MSE digest: {path}")
        key = _seed_key(row["seeds"])
        by_seed[key].add(digest)
        seed_receipts[key] = dict(row["seeds"])
    if any(len(values) != 1 for values in by_seed.values()):
        raise ValueError("embedded MSE base differs across hyperparameter arms")
    return [
        {
            "seeds": seed_receipts[key],
            "parameter_sha256": next(iter(by_seed[key])),
        }
        for key in sorted(by_seed, key=str)
    ]


def _rank_arms(summary: dict[str, Any]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in summary["candidate_rows"]:
        grouped[str(row["arm_sha256"])].append(row)
    ranked: list[dict[str, Any]] = []
    for arm_sha, rows in grouped.items():
        seed_keys = {_seed_key(row["seeds"]) for row in rows}
        if len(seed_keys) != 3 or len(rows) != 3:
            raise ValueError(f"arm {arm_sha} does not have exactly three paired seeds")
        arm = rows[0]["arm"]
        parameters = arm["method_parameters"]
        training = arm["training"]
        ranked.append(
            {
                "arm_sha256": arm_sha,
                "arm": arm,
                "sigma": float(parameters["sigma"]),
                "tau": float(parameters["tau"]),
                "learning_rate": float(training["learning_rate"]),
                "training_samples": int(parameters["training_samples"]),
                "mean_validation_regret": sum(
                    float(row["validation_mean_regret"]) for row in rows
                )
                / len(rows),
                "seed_count": len(rows),
                "selected_names": sorted(str(row["name"]) for row in rows),
            }
        )
    return sorted(
        ranked, key=lambda row: (row["mean_validation_regret"], row["arm_sha256"])
    )


def _boundaries(ranked: list[dict[str, Any]]) -> list[dict[str, str]]:
    winner = ranked[0]
    result: list[dict[str, str]] = []
    for axis in ("sigma", "tau", "learning_rate"):
        values = sorted({float(row[axis]) for row in ranked})
        if axis == "tau":
            unexpected = sorted(set(values) - set(ALLOWED_TAUS))
            if unexpected:
                raise ValueError(
                    f"tau grid contains values outside {ALLOWED_TAUS}: {unexpected}"
                )
            # Tau is a deliberately closed discrete grid in this experiment.
            # It never participates in outward boundary expansion.
            continue
        selected = float(winner[axis])
        if len(values) <= 1:
            continue
        if selected == values[0]:
            result.append({"axis": axis, "side": "lower"})
        if selected == values[-1]:
            result.append({"axis": axis, "side": "upper"})
    return result


def _verified_campaign_paths(payload: dict[str, Any]) -> list[Path]:
    receipts = payload.get("expected_campaign_receipts")
    if not isinstance(receipts, list) or not receipts:
        raise ValueError("selection receipt lacks expected campaign hashes")
    paths: list[Path] = []
    for receipt in receipts:
        if not isinstance(receipt, dict):
            raise ValueError("malformed expected campaign receipt")
        path = _resolve_receipt_path(str(receipt.get("path")))
        digest = receipt.get("sha256")
        if (
            not path.is_file()
            or not isinstance(digest, str)
            or _file_sha256(path) != digest
        ):
            raise ValueError("a campaign used for selection has changed")
        paths.append(path)
    if len(paths) != len(set(paths)):
        raise ValueError("selection receipt repeats a campaign")
    return paths


def _verify_ranked_payload(payload: dict[str, Any]) -> list[dict[str, Any]]:
    rows = payload.get("candidate_rows")
    recorded = payload.get("ranked_arms")
    if not isinstance(rows, list) or not isinstance(recorded, list):
        raise ValueError("selection receipt lacks ranked candidate evidence")
    recomputed = _rank_arms({"candidate_rows": rows})
    if recomputed != recorded:
        raise ValueError("selection ranking does not match its candidate rows")
    if not recomputed:
        raise ValueError("selection receipt contains no candidates")
    winner = recomputed[0]
    if (
        payload.get("selected_arm") != winner["arm"]
        or payload.get("selected_arm_sha256") != winner["arm_sha256"]
        or payload.get("selected_mean_validation_regret")
        != winner["mean_validation_regret"]
    ):
        raise ValueError("selection winner does not match the recorded ranking")
    return recomputed


def _verify_screen_fields(
    payload: dict[str, Any], ranked: list[dict[str, Any]]
) -> None:
    positive = [row for row in ranked if float(row["sigma"]) > 0.0]
    control = [row for row in ranked if float(row["sigma"]) == 0.0]
    if not positive or len(control) != 1:
        raise ValueError("screen must contain positive arms and one zero control")
    best = positive[0]
    zero = control[0]
    difference = (
        best["mean_validation_regret"] - zero["mean_validation_regret"]
    )
    if (
        payload.get("best_positive_arm") != best["arm"]
        or payload.get("best_positive_arm_sha256") != best["arm_sha256"]
        or payload.get("best_positive_mean_validation_regret")
        != best["mean_validation_regret"]
        or payload.get("sigma_zero_mean_validation_regret")
        != zero["mean_validation_regret"]
        or payload.get("best_positive_minus_sigma_zero_validation_regret")
        != difference
    ):
        raise ValueError("screen best-positive or zero-control fields are inconsistent")


def _verify_static_selection_receipt(
    path: Path, *, required_stage: str
) -> tuple[dict[str, Any], list[Path]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if (
        not isinstance(payload, dict)
        or payload.get("selection_stage") != required_stage
    ):
        raise ValueError(f"invalid {required_stage} selection receipt")
    recorded_source = payload.get("source_sha256")
    if (
        not isinstance(recorded_source, str)
        or recorded_source != source_sha256(REPO_ROOT)
    ):
        raise ValueError("selection receipt was produced by different source")
    campaigns = _verified_campaign_paths(payload)
    if required_stage == "screen":
        if len(campaigns) != 1:
            raise ValueError("screen receipt must authenticate exactly one campaign")
        _verify_screen_campaign(campaigns[0])
    elif required_stage == "refinement":
        if len(campaigns) != 1:
            raise ValueError(
                "refinement receipt must authenticate exactly one campaign"
            )
        _verify_refinement_campaign(campaigns[0])
    _validate_expected_cells(payload, campaigns)
    _verify_candidate_rows_against_live_runs(payload, campaigns)
    ranked = _verify_ranked_payload(payload)
    selected = payload.get("selected_arm")
    selected_digest = payload.get("selected_arm_sha256")
    if (
        not isinstance(selected, dict)
        or not isinstance(selected_digest, str)
        or _arm_sha256(selected) != selected_digest
    ):
        raise ValueError("selected arm does not match its recorded hash")
    if required_stage == "refinement":
        boundaries = _boundaries(ranked)
        if payload.get("boundary_axes") != boundaries:
            raise ValueError("refinement boundary axes do not match its ranking")
        if payload.get("boundary_expansion_required") is not bool(boundaries):
            raise ValueError("refinement boundary decision is inconsistent")
    elif required_stage == "screen":
        _verify_screen_fields(payload, ranked)
    if required_stage == "provisional":
        prior_path_raw = payload.get("refinement_selection")
        prior_digest = payload.get("refinement_selection_sha256")
        if not isinstance(prior_path_raw, str) or not isinstance(prior_digest, str):
            raise ValueError("provisional receipt lacks its refinement receipt")
        prior_path = _resolve_receipt_path(prior_path_raw)
        if not prior_path.is_file() or _file_sha256(prior_path) != prior_digest:
            raise ValueError("refinement receipt changed after provisional selection")
        prior, prior_campaigns = _verify_static_selection_receipt(
            prior_path, required_stage="refinement"
        )
        required = bool(prior["boundary_expansion_required"])
        campaign_set = set(campaigns)
        prior_set = set(prior_campaigns)
        if not prior_set <= campaign_set:
            raise ValueError("provisional receipt omits the refinement campaign")
        added = campaign_set - prior_set
        if (required and len(added) != 1) or (not required and added):
            raise ValueError("provisional receipt violates the one-expansion rule")
        if required:
            _verify_boundary_campaign(
                next(iter(added)),
                refinement_path=prior_path,
                refinement=prior,
            )
        if payload.get("boundary_expansion_performed") is not required:
            raise ValueError("provisional boundary gate is inconsistent")
    return payload, campaigns


def _rank_campaign_subset(
    summary: dict[str, Any], campaigns: list[Path]
) -> list[dict[str, Any]]:
    expected = _expected_cells(campaigns)
    rows = [
        row
        for row in summary["candidate_rows"]
        if (str(row["arm_sha256"]), _seed_key(row["seeds"])) in expected
    ]
    actual = {
        (str(row["arm_sha256"]), _seed_key(row["seeds"])) for row in rows
    }
    if actual != expected or len(rows) != len(expected):
        raise ValueError("live refinement results do not match the refinement receipt")
    return _rank_arms({"candidate_rows": rows})


def _outward_value(axis: str, value: float, side: str) -> float:
    if axis == "sigma":
        result = value / 2.0 if side == "lower" else value * 2.0
    elif axis == "learning_rate":
        result = value / 3.0 if side == "lower" else value * 3.0
    elif axis == "tau":
        raise ValueError(
            "tau boundary expansion is forbidden; use exactly "
            f"{ALLOWED_TAUS}"
        )
    else:
        raise ValueError(f"unknown boundary axis: {axis}")
    return float(f"{result:.12g}")


def _boundary_settings(
    refinement: dict[str, Any]
) -> tuple[dict[str, float], set[tuple[float, float, float]]]:
    selected = refinement.get("selected_arm")
    axes = refinement.get("boundary_axes")
    if not isinstance(selected, dict) or not isinstance(axes, list) or not axes:
        raise ValueError("boundary expansion requires a boundary-limited winner")
    parameters = selected.get("method_parameters")
    training = selected.get("training")
    if not isinstance(parameters, dict) or not isinstance(training, dict):
        raise ValueError("refinement winner is malformed")
    base = {
        "sigma": float(parameters["sigma"]),
        "tau": float(parameters["tau"]),
        "learning_rate": float(training["learning_rate"]),
    }
    outward: dict[str, float] = {}
    for item in axes:
        if not isinstance(item, dict):
            raise ValueError("malformed refinement boundary axis")
        axis = str(item.get("axis"))
        side = str(item.get("side"))
        if axis in outward or side not in {"lower", "upper"}:
            raise ValueError("malformed or duplicate refinement boundary axis")
        outward[axis] = _outward_value(axis, base[axis], side)
    settings: set[tuple[float, float, float]] = set()
    names = sorted(outward)
    for count in range(1, len(names) + 1):
        for subset in itertools.combinations(names, count):
            values = dict(base)
            for axis in subset:
                values[axis] = outward[axis]
            settings.add(
                (values["sigma"], values["tau"], values["learning_rate"])
            )
    return outward, settings


def _verify_boundary_campaign(
    campaign_path: Path,
    *,
    refinement_path: Path,
    refinement: dict[str, Any],
) -> None:
    payload = json.loads(campaign_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("boundary campaign must be an object")
    design = payload.get("design_receipt")
    if not isinstance(design, dict):
        raise ValueError("boundary campaign lacks its design receipt")
    recorded_refinement = _resolve_receipt_path(
        str(design.get("refinement_selection"))
    )
    if recorded_refinement.resolve() != refinement_path.resolve():
        raise ValueError("boundary campaign points to another refinement receipt")
    if design.get("refinement_selection_sha256") != _file_sha256(refinement_path):
        raise ValueError("boundary campaign refinement digest is invalid")
    if design.get("refinement_source_sha256") != refinement.get("source_sha256"):
        raise ValueError("boundary campaign source differs from refinement")
    outward, settings = _boundary_settings(refinement)
    if design.get("expanded_axes") != refinement.get("boundary_axes"):
        raise ValueError("boundary campaign expands the wrong axes")
    if design.get("outward_values") != outward:
        raise ValueError("boundary campaign has incorrect outward values")
    if design.get("joint_boundary_combinations_included") is not True:
        raise ValueError("boundary campaign omits required joint combinations")

    prior_campaigns = _verified_campaign_paths(refinement)
    prior_run_roots = {
        str(json.loads(path.read_text(encoding="utf-8")).get("run_root"))
        for path in prior_campaigns
    }
    if len(prior_run_roots) != 1 or payload.get("run_root") not in prior_run_roots:
        raise ValueError("boundary campaign does not share the refinement run root")

    selected = refinement["selected_arm"]
    expected_digests: set[str] = set()
    for sigma, tau, learning_rate in settings:
        expected_arm = json.loads(json.dumps(selected))
        expected_arm["method_parameters"]["sigma"] = sigma
        expected_arm["method_parameters"]["tau"] = tau
        expected_arm["training"]["learning_rate"] = learning_rate
        expected_digests.add(_arm_sha256(expected_arm))
    selected_digest = str(refinement["selected_arm_sha256"])
    expected_seeds = {
        _seed_key(row["seeds"])
        for row in refinement["candidate_rows"]
        if str(row["arm_sha256"]) == selected_digest
    }
    if len(expected_seeds) != 3:
        raise ValueError("refinement winner does not have three paired seeds")
    base = payload.get("base")
    variants = payload.get("variants")
    if not isinstance(base, dict) or not isinstance(variants, list):
        raise ValueError("boundary campaign is not a templated campaign")
    actual: dict[str, set[tuple[Any, ...]]] = defaultdict(set)
    for variant in variants:
        if not isinstance(variant, dict):
            raise ValueError("boundary campaign contains a malformed variant")
        config = RunSpec.from_dict(_deep_merge(base, variant)).to_dict()
        digest = _arm_sha256(config)
        seed = _seed_key(config["seeds"])
        if seed in actual[digest]:
            raise ValueError("boundary campaign duplicates an arm x seed cell")
        actual[digest].add(seed)
    if set(actual) != expected_digests or any(
        seeds != expected_seeds for seeds in actual.values()
    ):
        raise ValueError("boundary campaign is not the prescribed outward expansion")


def _render(summary: dict[str, Any]) -> str:
    lines = [
        "# Mollified PyEPO development selection",
        "",
        f"Stage: `{summary['selection_stage']}`.",
        "Selection uses mean validation regret across paired development seeds only.",
        "",
        "| Rank | sigma | tau | learning rate | K | Mean validation regret |",
        "| ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for rank, row in enumerate(summary["ranked_arms"], start=1):
        lines.append(
            f"| {rank} | {row['sigma']:.6g} | {row['tau']:.6g} | "
            f"{row['learning_rate']:.6g} | {row['training_samples']} | "
            f"{row['mean_validation_regret']:.9g} |"
        )
    if summary.get("boundary_axes"):
        lines.extend(
            [
                "",
                "Boundary expansion required: "
                + ", ".join(
                    f"{item['axis']}:{item['side']}"
                    for item in summary["boundary_axes"]
                )
                + ".",
            ]
        )
    lines.extend(
        [
            "",
            f"Confirmation ready: `{summary.get('confirmation_ready', False)}`.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", type=Path)
    parser.add_argument(
        "--stage", choices=("screen", "refinement", "provisional"), required=True
    )
    parser.add_argument(
        "--expected-campaign", type=Path, action="append", required=True
    )
    parser.add_argument("--refinement-selection", type=Path)
    parser.add_argument("--source-sha256")
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    arguments = parser.parse_args()
    summary = summarize_validation_selection(
        arguments.run_root, source_sha256=arguments.source_sha256
    )
    if arguments.stage == "screen":
        if len(arguments.expected_campaign) != 1:
            raise ValueError("screen selection requires exactly one campaign")
        _verify_screen_campaign(arguments.expected_campaign[0])
    elif arguments.stage == "refinement":
        if len(arguments.expected_campaign) != 1:
            raise ValueError("refinement selection requires exactly one campaign")
        _verify_refinement_campaign(arguments.expected_campaign[0])
    _validate_expected_cells(summary, arguments.expected_campaign)
    embedded_bases = _embedded_base_digests(summary)
    ranked = _rank_arms(summary)
    output: dict[str, Any] = {
        **summary,
        "selection_stage": arguments.stage,
        "expected_campaign_receipts": [
            {"path": str(path), "sha256": _file_sha256(path)}
            for path in arguments.expected_campaign
        ],
        "selection_metric": "mean validation regret across data seeds 1, 2, 3",
        "ranked_arms": ranked,
        "selected_arm": ranked[0]["arm"],
        "selected_arm_sha256": ranked[0]["arm_sha256"],
        "selected_mean_validation_regret": ranked[0]["mean_validation_regret"],
        "embedded_mse_base_digests": embedded_bases,
        "confirmation_ready": False,
    }
    if arguments.stage == "screen":
        positive = [row for row in ranked if row["sigma"] > 0.0]
        control = [row for row in ranked if row["sigma"] == 0.0]
        if not positive or len(control) != 1:
            raise ValueError(
                "screen must contain positive sigma arms and one zero control"
            )
        output["best_positive_arm"] = positive[0]["arm"]
        output["best_positive_arm_sha256"] = positive[0]["arm_sha256"]
        output["best_positive_mean_validation_regret"] = positive[0][
            "mean_validation_regret"
        ]
        output["sigma_zero_mean_validation_regret"] = control[0][
            "mean_validation_regret"
        ]
        output["best_positive_minus_sigma_zero_validation_regret"] = (
            positive[0]["mean_validation_regret"]
            - control[0]["mean_validation_regret"]
        )
    elif arguments.stage == "refinement":
        output["boundary_axes"] = _boundaries(ranked)
        output["boundary_expansion_required"] = bool(output["boundary_axes"])
    else:
        if arguments.refinement_selection is None:
            raise ValueError("final stage requires --refinement-selection")
        prior, prior_campaigns = _verify_static_selection_receipt(
            arguments.refinement_selection, required_stage="refinement"
        )
        live_prior_ranked = _rank_campaign_subset(summary, prior_campaigns)
        if live_prior_ranked != prior["ranked_arms"]:
            raise ValueError("refinement receipt no longer matches live results")
        required = bool(_boundaries(live_prior_ranked))
        current_campaigns = {path.resolve() for path in arguments.expected_campaign}
        prior_campaign_set = {path.resolve() for path in prior_campaigns}
        if not prior_campaign_set <= current_campaigns:
            raise ValueError("provisional selection omitted the refinement campaign")
        added = current_campaigns - prior_campaign_set
        if (required and len(added) != 1) or (not required and added):
            raise ValueError("provisional selection violates the one-expansion rule")
        if required:
            _verify_boundary_campaign(
                next(iter(added)),
                refinement_path=arguments.refinement_selection,
                refinement=prior,
            )
        output["initial_boundary_axes"] = prior.get("boundary_axes", [])
        output["boundary_expansion_performed"] = required
        output["one_expansion_rule_satisfied"] = True
        output["k_sensitivity_required"] = True
        output["confirmation_ready"] = False
        output["refinement_selection"] = str(arguments.refinement_selection)
        output["refinement_selection_sha256"] = _file_sha256(
            arguments.refinement_selection
        )
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, output)
    arguments.markdown_output.write_text(_render(output), encoding="utf-8")


if __name__ == "__main__":
    main()
