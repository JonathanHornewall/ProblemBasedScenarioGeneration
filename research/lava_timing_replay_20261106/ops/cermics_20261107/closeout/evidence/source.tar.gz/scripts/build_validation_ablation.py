"""Add matched expected/sampled validation without changing existing results."""
import argparse
import collections
import copy
import hashlib
import json
from pathlib import Path

from build_central_path_final import read, sha, write

ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOTS = [
    ROOT.parent / "ProximalSPO-final-20260922/runs/central_path_final_20260922/hornewall/retrieved",
    ROOT.parent / "ProximalSPO-extension-20260923/runs/central_path_extension_20260923/hornewall/retrieved",
]
METHODS = {"mse", "wise", "spo_plus", "central_path_hard_validation",
           "central_path_barrier_validation", "lava", "pfyl", "nce"}


def variant(original, mode, source_protocol, exact_candidate=None):
    job = copy.deepcopy(original)
    source_cell = job["cell"]
    job["comparison_cell"] = source_cell
    job["validation_costs"] = mode
    job["analytic_validation"] = mode == "conditional_mean"
    job["validation_experiment"] = "validation_noise_20260923_v1"
    job["protocol_revision"] = "physical_relaxed_spo_conditional_validation_v1"
    job["source_job_id"] = original["id"]
    job["source_candidate"] = original["candidate"]
    job["paired_exact_candidate"] = exact_candidate or original["candidate"]
    job["resource_limits"] = {k: source_protocol[k] for k in
                              ("preprocessing_cap_seconds", "job_wall_cap_seconds")}
    if mode == "single_sample":
        job["cell"] = source_cell + "__validation_sampled"
    config = job["config"]
    config["evaluate_test"] = False
    config.pop("name", None)
    identity = sha({"config":config, "method":job["method"],
                    "parameters":job.get("parameters"), "validation_costs":mode,
                    "experiment":job["validation_experiment"],
                    "analytic_validation":job["analytic_validation"]})[:16]
    job.update(candidate=identity, id=f"screen__{job['cell']}__{job['method']}__{identity}")
    config["name"] = job["id"]
    return job


def build(root):
    destination = root / "additional_screen.json"
    if destination.exists():
        raise RuntimeError("Refusing to overwrite the additive validation study")
    base = read(root / "screen.json")
    cells, jobs, sources = {}, [], {}
    for original in base["jobs"]:
        job = variant(original, "single_sample", base["protocol"])
        cells[job["cell"]] = copy.deepcopy(base["cells"][original["cell"]])
        jobs.append(job)
        if original["method"] == "central_path_barrier_validation" and (
                original["route"].startswith(("dys_cfl_", "dys_knapsack_", "pyepo_mdkp"))):
            exact = variant(original, "conditional_mean", base["protocol"])
            exact["cell"] = original["cell"] + "__validation_exact"
            exact["id"] = f"screen__{exact['cell']}__{exact['method']}__{exact['candidate']}"
            exact["config"]["name"] = exact["id"]
            exact["paired_exact_candidate"] = exact["candidate"]
            job["paired_exact_candidate"] = exact["candidate"]
            cells[exact["cell"]] = copy.deepcopy(base["cells"][original["cell"]])
            jobs.append(exact)
    for source_root in SOURCE_ROOTS:
        path = source_root / "screen.json"
        source = read(path)
        sources[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        for original in source["jobs"]:
            if original["method"] not in ("central_path_hard_validation", "lava", "pfyl", "nce"):
                continue
            if original["method"] == "central_path_hard_validation":
                exact = variant(original, "conditional_mean", source["protocol"])
                exact["paired_exact_candidate"] = exact["candidate"]
                cells[exact["cell"]] = copy.deepcopy(base["cells"][original["cell"]])
                jobs.append(exact)
                sampled = variant(original, "single_sample", source["protocol"], exact["candidate"])
            else:
                sampled = variant(original, "single_sample", source["protocol"])
            cells[sampled["cell"]] = copy.deepcopy(base["cells"][original["cell"]])
            jobs.append(sampled)
    assert {j["method"] for j in jobs} == METHODS
    assert len({j["id"] for j in jobs}) == len(jobs)
    assert len({j["comparison_cell"] for j in jobs}) == 35
    # Interleave exact/noisy Central-Path jobs within their shared priority.
    jobs.sort(key=lambda j: (j.get("arm_order", 0), j["comparison_cell"],
                             j["method"], j["validation_costs"], j["candidate"]))
    result = {"schema":"validation_noise_additive_v1", "cells":cells,
              "methods":sorted(METHODS), "jobs":jobs, "source_sha256":sources,
              "base_screen_sha256":hashlib.sha256((root/"screen.json").read_bytes()).hexdigest(),
              "contract":{
                  "validation":"One original observed physical cost per validation context, fixed across candidates and seeds; no resampling",
                  "selection":"Original full grid, top three, three refinement seeds, common horizon, ten confirmations; sampled costs also select between mu",
                  "unchanged":"Training data/costs, contexts, seeds, held-out tests, loss parameters, model/optimizer grids and training caps",
                  "test":"Original fixed reference after selection: analytic on 26 cells, archived Monte Carlo on nine integer cells",
                  "priority":["ours","mse","wise","spo_plus","lava","pfyl","nce"],
                  "cave":"excluded by explicit user instruction",
                  "new_expectation_control":"Fresh analytic hard-validation Central-Path selection on 35 cells; analytic soft-validation supplement on nine previously Monte Carlo cells; existing analytic soft validation on 26 cells",
                  "preserve_existing_results":True}}
    write(destination,result)
    return result


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",type=Path,required=True)
    args=parser.parse_args()
    result=build(args.root)
    print(json.dumps({"jobs":len(result["jobs"]),"groups":len({(j['cell'],j['method']) for j in result['jobs']}),
                      "by_method":dict(collections.Counter(j['method'] for j in result['jobs']))}))
