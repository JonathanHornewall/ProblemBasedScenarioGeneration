"""Attach exact observed-training geometry caches without mutating originals."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from build_central_path_final import read, write
from final_geometry_cache import geometry_cache_key


def sha_file(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for b in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def reuse(root):
    oldroots = [Path("/home/jonathan.hornewall/runs") / n / "geometry_cache"
                for n in ("normal_validation32_20260925", "canonical_targeted_20260923")]
    dest = root / "geometry_cache"
    dest.mkdir(exist_ok=True)
    candidates = {}
    for j in read(root / "screen.json")["jobs"]:
        if j["method"] == "lava":
            candidates.setdefault(j["route"], j)
    records = []
    for e in read(root / "bank_plan.json")["entries"]:
        route = e["source_job"]["route"]
        if route not in candidates:
            continue
        j = candidates[route]
        bank = root / "frozen_data" / e["key"] / "observations.npz"
        with np.load(bank, allow_pickle=False) as a:
            key = geometry_cache_key(j, a["train__contexts"], a["train__physical_costs"])
        row = {"bank": e["key"], "geometry_key": key, "reused": False}
        for source in oldroots:
            meta, data = source / (key + ".json"), source / (key + ".pickle")
            if not meta.exists() or not data.exists():
                continue
            m = read(meta)
            if m.get("status") != "complete":
                continue
            # Key binds observed array bytes, route, adapter and pinned loss source.
            checksum = sha_file(data)
            target = dest / data.name
            if not target.exists():
                target.symlink_to(data)
            elif target.resolve() != data.resolve():
                raise ValueError("Unexpected cache target")
            m.update(reused_from=str(data), reused_sha256=checksum, retained=True)
            write(dest / meta.name, m)
            row.update(reused=True, source=str(data), source_sha256=checksum,
                       serialized_bytes=data.stat().st_size)
            break
        records.append(row)
    result = {"status": "complete", "exact_keys_checked": len(records),
              "reused": sum(r["reused"] for r in records), "records": records,
              "originals_read_only": True, "training_observations_only": True}
    write(root / "geometry_reuse_verification.json", result)
    print(json.dumps({k: v for k, v in result.items() if k != "records"}), flush=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    reuse(p.parse_args().root)
