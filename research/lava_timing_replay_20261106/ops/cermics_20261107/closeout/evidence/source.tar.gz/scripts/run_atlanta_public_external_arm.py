#!/usr/bin/env python3
"""Run one validation-only or confirmation arm for an Atlanta route.

The executable method code is imported from the pinned public repositories;
this file only supplies the maintained route adapter and the campaign receipt
contract.  Development invocations never open the test reference oracle.
"""

from __future__ import annotations

import copy
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def _load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_atomic(path: Path, value: Any) -> None:
    """Write a receipt atomically so the parent never reads half-written JSON."""

    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    temporary.replace(path)


def _hash_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _git_commit(path: Path) -> str | None:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=path, text=True
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def _tree_hash(path: Path) -> str | None:
    try:
        digest = hashlib.sha256()
        names = subprocess.check_output(
            ["git", "ls-files", "-z"], cwd=path
        ).split(b"\0")
        for raw in sorted(item for item in names if item):
            digest.update(raw)
            digest.update((path / os.fsdecode(raw)).read_bytes())
        return digest.hexdigest()
    except (OSError, subprocess.CalledProcessError):
        return None


def _source_receipt(method: str) -> dict[str, Any]:
    solver_free = Path(
        os.environ.get("SOLVER_FREE_DFL_REPO", "/private/tmp/dfl-public-solver-free")
    ).resolve()
    sfge = Path(
        os.environ.get(
            "SFGE_PUBLIC_REPO", "/private/tmp/atlanta-public-baseline-sources/sfge-c62241ad8"
        )
    ).resolve()
    external = Path(
        os.environ.get("DFL_EXTENSIONS_SRC", "/private/tmp/dfl-gefcom57-campaign/src")
    ).resolve()
    result: dict[str, Any] = {
        "external_benchmark_source": str(external),
        "external_benchmark_commit": _git_commit(external.parent),
        "external_benchmark_tree_sha256": _tree_hash(external.parent),
    }
    if method in {"cave", "lava"}:
        result.update(
            {
                "solver_free_repository": str(solver_free),
                "solver_free_commit": _git_commit(solver_free),
                "solver_free_tree_sha256": _tree_hash(solver_free),
            }
        )
    if method == "sfge":
        result.update(
            {
                "sfge_repository": str(sfge),
                "sfge_commit": _git_commit(sfge),
                "sfge_tree_sha256": _tree_hash(sfge),
            }
        )
    return result


def _base_receipt(
    entry: dict[str, Any],
    *,
    method: str,
    stage: str,
    validation_only: bool,
    manifest: Path,
    arms: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "kind": "atlanta_public_external_arm_run",
        "version": 1,
        "stage": stage,
        "method": method,
        "route_id": entry["route_id"],
        "benchmark_id": entry["benchmark_id"],
        "seeds": entry["seeds"],
        "sizes": entry["sizes"],
        "manifest": str(manifest.resolve()),
        "manifest_sha256": _hash_file(manifest),
        "arms_requested": arms,
        "test_access": not validation_only,
        "protocol": {
            "train_on_continuous_relaxation_for_mips": True,
            "validation_and_test_on_original_source_integrality": True,
            "test_used_for_selection": False,
            "test_reference_solved_after_validation_selection": True,
            "metric": "conditional_mean_normalized_decision_regret",
            "public_method_code_unchanged": True,
            "raw_data_persisted": False,
            "raw_weights_persisted": False,
        },
        "source": _source_receipt(method),
    }


def _write_progress(
    path: Path | None,
    base: dict[str, Any],
    results: list[dict[str, Any]],
    requested_count: int,
    *,
    final: bool = False,
) -> None:
    if path is None:
        return
    clean_results = [
        {key: value for key, value in result.items() if key != "module"}
        for result in results
    ]
    terminal = len(clean_results) >= requested_count and all(
        result.get("status") in {"complete", "trained", "failed"}
        for result in clean_results
    )
    if terminal:
        if all(result.get("status") in {"complete", "trained"} for result in clean_results):
            progress_status = "complete"
        elif any(result.get("status") in {"complete", "trained"} for result in clean_results):
            progress_status = "partial_failure"
        else:
            progress_status = "failed"
    else:
        progress_status = "in_progress"
    if progress_status == "complete" and base.get("test_access") and not final:
        progress_status = "in_progress"
    payload = dict(base)
    # Validation-only children can be harvested as soon as all arms are
    # terminal. Confirmation children remain in progress until their final
    # test metrics have been written.
    payload.update(
        {
            "status": progress_status,
            "arms": clean_results,
            "progress": {
                "completed_arms": len(clean_results),
                "requested_arms": requested_count,
                "arms_complete": terminal,
                "final_receipt_written": bool(final),
            },
        }
    )
    _write_atomic(path, payload)


def _run_solver_free(
    entry: dict[str, Any],
    arms: list[dict[str, Any]],
    *,
    method: str,
    stage: str,
    validation_only: bool,
    manifest: Path,
    progress_path: Path | None,
) -> dict[str, Any]:
    # Import only after the environment has supplied the pinned source paths.
    import run_public_solver_free_matched as public

    loaded, public_model, train, solver, references = public._load_entry(
        entry, need_lava=method == "lava"
    )
    results: list[dict[str, Any]] = []
    base = _base_receipt(
        entry,
        method=method,
        stage=stage,
        validation_only=validation_only,
        manifest=manifest,
        arms=arms,
    )
    _write_progress(progress_path, base, results, len(arms))
    training = dict(entry.get("training") or {})
    for arm in arms:
        started = time.perf_counter()
        try:
            result = public._train_arm(
                entry,
                {**arm, "kind": method},
                public_model,
                train,
                solver,
                references,
                loaded,
                epochs=int(arm.get("epochs", training.get("epochs", 300))),
                validation_interval=int(
                    arm.get(
                        "validation_interval",
                        training.get("validation_interval", 10),
                    )
                ),
                evaluate_test=not validation_only,
            )
            result["test_access"] = not validation_only
        except BaseException as error:  # preserve per-arm failures for audit
            result = {
                **arm,
                "kind": method,
                "status": "failed",
                "error_type": type(error).__name__,
                "error": str(error),
                "test_access": False,
            }
        result["arm_wall_seconds"] = time.perf_counter() - started
        results.append(result)
        _write_progress(progress_path, base, results, len(arms))
        print(
            json.dumps(
                {
                    "route": entry["route_id"],
                    "method": method,
                    "arm": arm.get("name"),
                    "status": result.get("status"),
                    "validation_regret": result.get("validation_regret"),
                    "test_regret": result.get("test_regret"),
                }
            ),
            flush=True,
        )
    receipt = base
    receipt.update(
        {
            "status": "complete" if all(r.get("status") == "complete" for r in results) else "partial_failure",
            "dataset": {
                "training_problem": public_model.source.name,
                "evaluation_problem": solver.problem.name,
                "training_integral_variables": 0,
                "evaluation_integral_variables": int(np.sum(solver.problem.integrality)),
                "augmented_samples": len(train),
                "augmented_geometry_row_reduction": bool(
                    getattr(train, "geometry_row_reduction", False)
                ),
                "adjacency_tnp_retry_count": int(
                    getattr(train, "adjacency_tnp_retry_count", 0)
                ),
            },
            "arms": results,
        }
    )
    _write_progress(progress_path, receipt, results, len(arms), final=True)
    return receipt


def _run_sfge(
    entry: dict[str, Any],
    arms: list[dict[str, Any]],
    *,
    stage: str,
    validation_only: bool,
    manifest: Path,
    progress_path: Path | None,
) -> dict[str, Any]:
    import run_public_sfge_matched as public

    # A child keeps one geometry/data load and one public SFGE training loop
    # over its arm grid.  The campaign groups arms with the same architecture,
    # horizon, and batch size, so no hidden cross-arm state is shared.
    groups: dict[str, list[dict[str, Any]]] = {}
    for arm in arms:
        key = json.dumps(
            {
                "model": arm.get("model", {}),
                "epochs": arm.get("epochs"),
                "batch_size": arm.get("batch_size"),
            },
            sort_keys=True,
        )
        groups.setdefault(key, []).append(arm)
    if len(groups) != 1:
        raise ValueError("an SFGE child must contain one model/horizon/batch group")
    group = next(iter(groups.values()))
    variant = copy.deepcopy(entry)
    first = group[0]
    if first.get("model"):
        variant["model"] = {**dict(entry.get("model") or {}), **first["model"]}
    if first.get("epochs") is not None or first.get("batch_size") is not None:
        variant["training"] = {
            **dict(entry.get("training") or {}),
            **({"epochs": first["epochs"]} if first.get("epochs") is not None else {}),
            **(
                {"batch_size": first["batch_size"]}
                if first.get("batch_size") is not None
                else {}
            ),
        }
    result = public.run_entry(
        variant,
        sigmas=sorted({float(arm["sigma"]) for arm in group}),
        learning_rates=sorted({float(arm["lr"]) for arm in group}),
        standardize_values=sorted(
            {bool(arm.get("standardize_batch_values", True)) for arm in group}
        ),
        sce_losses=sorted({bool(arm.get("sce_loss", False)) for arm in group}),
        epochs_override=(int(first["epochs"]) if first.get("epochs") is not None else None),
        batch_size_override=(
            int(first["batch_size"]) if first.get("batch_size") is not None else None
        ),
        evaluate_test=not validation_only,
        progress_path=progress_path,
    )
    result.update(
        {
            "kind": "atlanta_public_external_arm_run",
            "version": 1,
            "stage": stage,
            "method": "sfge",
            "manifest": str(manifest.resolve()),
            "manifest_sha256": _hash_file(manifest),
            "test_access": not validation_only,
            "arms_requested": arms,
            "protocol": {
                "train_on_continuous_relaxation_for_mips": True,
                "validation_and_test_on_original_source_integrality": True,
                "test_used_for_selection": False,
                "test_reference_solved_after_validation_selection": True,
                "metric": "conditional_mean_normalized_decision_regret",
                "public_method_code_unchanged": True,
                "raw_data_persisted": False,
                "raw_weights_persisted": False,
            },
            "source": _source_receipt("sfge"),
        }
    )
    return result


def main() -> int:
    parser = __import__("argparse").ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--entry-index", type=int, required=True)
    parser.add_argument("--arms", type=Path, required=True)
    parser.add_argument("--method", choices=("cave", "lava", "sfge"), required=True)
    parser.add_argument("--stage", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--progress", type=Path)
    parser.add_argument("--validation-only", action="store_true")
    args = parser.parse_args()
    started = time.perf_counter()
    manifest = _load(args.manifest)
    entry = manifest["entries"][args.entry_index]
    arms = list(_load(args.arms))
    try:
        if args.method == "sfge":
            receipt = _run_sfge(
                entry,
                arms,
                stage=args.stage,
                validation_only=args.validation_only,
                manifest=args.manifest,
                progress_path=args.progress,
            )
        else:
            receipt = _run_solver_free(
                entry,
                arms,
                method=args.method,
                stage=args.stage,
                validation_only=args.validation_only,
                manifest=args.manifest,
                progress_path=args.progress,
            )
    except BaseException as error:
        receipt = _base_receipt(
            entry,
            method=args.method,
            stage=args.stage,
            validation_only=args.validation_only,
            manifest=args.manifest,
            arms=arms,
        )
        receipt.update(
            {
                "status": "failed",
                "error_type": type(error).__name__,
                "error": str(error),
            }
        )
    receipt["wall_seconds"] = time.perf_counter() - started
    args.output.parent.mkdir(parents=True, exist_ok=True)
    _write_atomic(args.output, receipt)
    return 0 if receipt.get("status") == "complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
