"""Canonical losses for the isolated, paired local implementation diagnostic."""
from __future__ import annotations

import time
import numpy as np
import torch
from pyepo.func import SPOPlus

from proximal_spo.objectives import BatchSignal, Deployment, WISEObjective
from proximal_spo.oracles import BatchSolutions, OracleStats
from proximal_spo.problem import PartialCostInterface
from proximal_spo.public_highs import HighsOptModel


class MeasuredHighsModel(HighsOptModel):
    """Plain existing HiGHS adapter; instrumentation does not alter solutions."""

    def __init__(self, source, *, presolve=True):
        self.cumulative = OracleStats()
        super().__init__(source, presolve=presolve)

    def solve(self):
        started = time.perf_counter()
        result = super().solve()
        info = self._model.getInfo()
        self.cumulative += OracleStats(
            calls=1, iterations=int(info.simplex_iteration_count),
            wall_seconds=time.perf_counter()-started,
        )
        return result


class PlainHighsBatch:
    """Serial PyEPO-style objective updates, without keyed bases or DP."""

    def __init__(self, problem):
        self.model = MeasuredHighsModel(problem)

    def solve_many(self, costs, sample_keys=None):
        del sample_keys
        before = self.model.cumulative
        decisions, values = [], []
        for cost in costs:
            self.model.setObj(cost)
            decision, value = self.model.solve()
            decisions.append(decision)
            values.append(value)
        after = self.model.cumulative
        return BatchSolutions(np.asarray(decisions), np.asarray(values), OracleStats(
            calls=after.calls-before.calls, iterations=after.iterations-before.iterations,
            wall_seconds=after.wall_seconds-before.wall_seconds,
        ))

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class CanonicalSPOPlus:
    """Delegate the loss AND its backward pass to pinned PyEPO SPOPlus.

    The existing shared trainer consumes per-example gradients. PyEPO's
    supported reduction='none' supplies them; the trainer averages the batch,
    identically to reduction='mean'. The affine network-output map is retained.
    """

    name = "spo_plus"

    def __init__(self, interface, deployment_problem):
        self.interface = interface
        self.output_dimension = interface.report_dimension
        self.model = MeasuredHighsModel(interface.problem)
        self.loss = SPOPlus(self.model, processes=1, solve_ratio=1, reduction="none")
        self._deployment_lp = PlainHighsBatch(deployment_problem)

    def signal(self, outputs, batch):
        before = self.model.cumulative
        report = torch.tensor(outputs, requires_grad=True)
        cost = (torch.as_tensor(self.interface.fixed_cost, dtype=report.dtype)
                + report @ torch.as_tensor(self.interface.statistic, dtype=report.dtype))
        value = self.loss(
            cost, torch.as_tensor(batch.physical_costs, dtype=report.dtype),
            torch.as_tensor(batch.target_decisions, dtype=report.dtype),
            torch.as_tensor(batch.target_values[:, None], dtype=report.dtype),
        )
        value.sum().backward()
        after = self.model.cumulative
        return BatchSignal(
            value.detach().numpy().astype(np.float64),
            report.grad.detach().numpy().astype(np.float64),
            OracleStats(calls=after.calls-before.calls,
                        iterations=after.iterations-before.iterations,
                        wall_seconds=after.wall_seconds-before.wall_seconds),
        )

    def predicted_physical_costs(self, outputs):
        return self.interface.physical_cost(np.asarray(outputs, dtype=np.float64))

    def deploy(self, outputs):
        physical = self.predicted_physical_costs(outputs)
        result = self._deployment_lp.solve_many(physical)
        return Deployment(result.decisions, outputs, result.stats)

    def deploy_with_sample_keys(self, outputs, sample_keys):
        return self.deploy(outputs)

    def close(self):
        self._deployment_lp.close()


class PhysicalWISE(WISEObjective):
    """Published WISE formula on physical costs; no augmented coordinates.

    WISEObjective.signal is exactly norm(c)*||u-c/norm(c)||^2 and its
    analytic gradient. Supplying the identity interface makes its coefficients
    physical costs. Only the deployment adapter is replaced here.
    """

    def __init__(self, problem):
        self.interface = PartialCostInterface.full_cost(problem)
        self.augmented = False
        self.output_dimension = problem.variable_count
        self.zero_tolerance = 1e-12
        self._lp = PlainHighsBatch(problem)
