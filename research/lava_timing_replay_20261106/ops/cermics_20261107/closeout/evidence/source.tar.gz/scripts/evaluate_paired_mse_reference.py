"""Reconstruct the exact unprojected MSE networks paired to a correction run."""

from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path
from typing import Any

import numpy as np

from proximal_spo.artifacts import write_json
from proximal_spo.benchmarks import build_benchmark
from proximal_spo.config import RunSpec
from proximal_spo.data import generate_dataset
from proximal_spo.neural_prediction_correction import (
    fit_pair_mse_network,
    mse_network_arrays,
)

REPO_ROOT = Path(__file__).resolve().parents[1]


def _mean(rows: list[dict[str, Any]], field: str) -> float:
    return float(statistics.mean(float(row[field]) for row in rows))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("campaign", type=Path)
    arguments = parser.parse_args()
    campaign = json.loads(arguments.campaign.read_text(encoding="utf-8"))
    rows: list[dict[str, Any]] = []
    for raw in campaign["variants"]:
        spec = RunSpec.from_dict(raw)
        problem = build_benchmark(
            spec.benchmark_id, structural_seed=spec.seeds.structural
        )
        dataset = generate_dataset(
            problem,
            spec.benchmark_id,
            spec.sizes,
            data_seed=spec.seeds.data,
            structural_seed=spec.seeds.structural,
            law=spec.law,
        )
        interface = dataset.interface(spec.interface, problem)
        train_coefficients, _ = dataset.coefficients(dataset.train, spec.interface)
        validation_coefficients, _ = dataset.coefficients(
            dataset.validation, spec.interface
        )
        model, receipt = fit_pair_mse_network(
            train_contexts=dataset.train.contexts,
            train_coefficients=train_coefficients,
            validation_contexts=dataset.validation.contexts,
            validation_coefficients=validation_coefficients,
            model_spec=spec.model,
            learning_rate=float(
                spec.method_parameters["prediction_correction_mse_learning_rate"]
            ),
            epochs=int(spec.method_parameters["prediction_correction_mse_epochs"]),
            batch_size=spec.training.batch_size,
            patience=spec.training.patience,
            weight_decay=spec.training.weight_decay,
            initialization_seed=spec.seeds.initialization + 70_001,
            shuffle_seed=spec.seeds.shuffle + 70_001,
        )
        _, _, validation_physical = mse_network_arrays(
            model,
            dataset.validation.contexts,
            interface,
            batch_size=spec.training.evaluation_batch_size,
        )
        _, _, test_physical = mse_network_arrays(
            model,
            dataset.test.contexts,
            interface,
            batch_size=spec.training.evaluation_batch_size,
        )
        rows.append(
            {
                "benchmark_id": spec.benchmark_id,
                "data_seed": spec.seeds.data,
                "conditional_mse_per_coordinate": float(
                    np.mean(
                        (test_physical - dataset.test.conditional_mean_costs) ** 2
                    )
                ),
                "test_scenario_mse_per_coordinate": float(
                    np.mean((test_physical - dataset.test.physical_costs) ** 2)
                ),
                "validation_scenario_mse_per_coordinate": float(
                    np.mean(
                        (
                            validation_physical
                            - dataset.validation.physical_costs
                        )
                        ** 2
                    )
                ),
                "training_wall_seconds": receipt["training_wall_seconds"],
                "training_solver_calls": 0,
            }
        )
    aggregate: dict[str, dict[str, float]] = {}
    for benchmark in sorted({str(row["benchmark_id"]) for row in rows}):
        selected = [row for row in rows if row["benchmark_id"] == benchmark]
        aggregate[benchmark] = {
            "conditional_mse_per_coordinate": _mean(
                selected, "conditional_mse_per_coordinate"
            ),
            "test_scenario_mse_per_coordinate": _mean(
                selected, "test_scenario_mse_per_coordinate"
            ),
            "validation_scenario_mse_per_coordinate": _mean(
                selected, "validation_scenario_mse_per_coordinate"
            ),
            "training_wall_seconds": _mean(selected, "training_wall_seconds"),
        }
    output = REPO_ROOT / "results" / "prediction_correction" / (
        "neural_development_paired_mse.json"
    )
    write_json(
        output,
        {
            "status": "development",
            "supervision": "context-scenario pairs only",
            "selection": "validation scenario coefficient MSE",
            "training_solver_calls": 0,
            "rows": rows,
            "aggregate": aggregate,
        },
    )
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
