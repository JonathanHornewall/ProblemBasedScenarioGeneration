#!/usr/bin/env python3
"""Continuously verify private result backups and delete a disposable campaign VM."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import signal
import subprocess
import tarfile
import time
from pathlib import Path

from atlanta_timing_vm import delete_self, metadata, upload


class Mirror:
    def __init__(self, root, bucket):
        self.root, self.bucket = root, bucket
        self.stamps, self.inventory = {}, {}
        self.retired = {}
        self.sequence, self.uploaded_bytes = 0, 0
        self.state = root / "mirror/state.json"
        if self.state.exists():
            saved = json.loads(self.state.read_text())
            self.stamps = {k: tuple(v) for k, v in saved["stamps"].items()}
            self.inventory = saved["inventory"]
            self.sequence = saved["sequence"]
            self.uploaded_bytes = saved["uploaded_bytes"]
            self.retired = saved.get("retired", {})

    def sync(self):
        # A resource retry moves only its failed receipt into a permanent archive.
        # Record that move so retrieval cannot retain a stale terminal receipt.
        for path in (self.root / "results/resource_retries").glob("*/*.json"):
            name = "results/receipts/" + path.parent.name + ".json"
            if name not in self.inventory or (self.root / name).exists():
                continue
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if self.inventory[name]["sha256"] != digest:
                raise RuntimeError("Resource archive differs from retired receipt")
            self.retired[name] = digest
            self.inventory.pop(name)
            self.stamps.pop(name, None)
        paths = list((self.root / "results").rglob("*"))
        paths += list(self.root.glob("*.json"))
        paths += list(self.root.glob("FINAL_RESULTS.*"))
        paths += [self.root / "bootstrap.log"]
        pending, total = [], 0
        for path in sorted(set(paths)):
            if not path.is_file() or path.is_symlink() or path.name.endswith(".tmp"):
                continue
            relative = path.relative_to(self.root).as_posix()
            stat = path.stat()
            stamp = (stat.st_mtime_ns, stat.st_size)
            if self.stamps.get(relative) == stamp:
                continue
            data = path.read_bytes()
            pending.append((relative, stamp, data))
            total += len(data)
            if total >= 64 * 2**20:
                self.flush(pending)
                pending, total = [], 0
        if pending:
            self.flush(pending)
        self.save_state()
        upload(
            self.bucket,
            "backup/index.json",
            json.dumps(
                {
                    "files": self.inventory,
                    "batches": self.sequence,
                    "uploaded_bytes": self.uploaded_bytes,
                    "retired_files": self.retired,
                    "updated_unix": time.time(),
                },
                sort_keys=True,
            ).encode(),
        )

    def flush(self, pending):
        blob = f"backup/batch-{self.sequence:06d}.tar.gz"
        buffer = io.BytesIO()
        with tarfile.open(fileobj=buffer, mode="w:gz", compresslevel=3) as archive:
            for relative, _stamp, data in pending:
                info = tarfile.TarInfo(relative)
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
        payload = buffer.getvalue()
        upload(self.bucket, blob, payload)  # Server-reported checksum and size checked.
        self.uploaded_bytes += len(payload)
        for relative, stamp, data in pending:
            self.stamps[relative] = stamp
            self.inventory[relative] = {
                "sha256": hashlib.sha256(data).hexdigest(),
                "size": len(data),
                "blob": blob,
            }
            self.retired.pop(relative, None)
        self.sequence += 1
        self.save_state()

    def save_state(self):
        self.state.parent.mkdir(exist_ok=True)
        temporary = self.state.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(
                {
                    "stamps": self.stamps,
                    "inventory": self.inventory,
                    "sequence": self.sequence,
                    "uploaded_bytes": self.uploaded_bytes,
                    "retired": self.retired,
                }
            )
        )
        temporary.replace(self.state)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--bucket", required=True)
    p.add_argument("--run-id", required=True)
    p.add_argument("--deadline-unix", type=float, required=True)
    p.add_argument("--failure-only", action="store_true")
    args = p.parse_args()
    root = args.root.resolve()
    (root / "results").mkdir(parents=True, exist_ok=True)
    mirror = Mirror(root, args.bucket)
    child = None
    try:
        if not args.failure_only:
            child = subprocess.Popen(
                [
                    str(root / "venv/bin/python"),
                    str(root / "code/scripts/central_path_cloud.py"),
                    "--root",
                    str(root),
                    "--workers",
                    "64",
                    "--memory-gib",
                    "236",
                    "--deadline-unix",
                    str(args.deadline_unix - 900),
                ],
                start_new_session=True,
            )
            last_good = time.monotonic()
            while child.poll() is None:
                try:
                    mirror.sync()
                    last_good = time.monotonic()
                except Exception as exc:
                    print("Backup retry:", type(exc).__name__, flush=True)
                if (
                    time.time() >= args.deadline_unix - 600
                    or time.monotonic() - last_good > 600
                    or mirror.uploaded_bytes >= 7 * 2**30
                ):
                    os.killpg(child.pid, signal.SIGTERM)
                time.sleep(30)
            (root / "results/supervisor.json").write_text(
                json.dumps(
                    {
                        "queue_returncode": child.returncode,
                        "finished_unix": time.time(),
                        "instance": metadata("instance/name"),
                    }
                )
                + "\n"
            )
        else:
            (root / "results/bootstrap_failure.json").write_text(
                json.dumps(
                    {
                        "status": "bootstrap_failed",
                        "finished_unix": time.time(),
                    }
                )
                + "\n"
            )
        for attempt in range(5):
            try:
                mirror.sync()
                upload(
                    args.bucket,
                    "backup/FINAL.json",
                    json.dumps(
                        {
                            "verified_files": len(mirror.inventory),
                            "batches": mirror.sequence,
                            "finished_unix": time.time(),
                            "index_complete": True,
                        }
                    ).encode(),
                )
                break
            except Exception:
                if attempt == 4:
                    raise
                time.sleep(15)
        delete_self(args.run_id)
    except Exception:
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
        # The provider's fixed deletion deadline remains an independent backstop.
        # Existing verified batches survive a final upload or early-delete failure.
        try:
            delete_self(args.run_id)
        except Exception as exc:
            print("Early deletion unavailable:", type(exc).__name__, flush=True)
        raise


if __name__ == "__main__":
    main()
