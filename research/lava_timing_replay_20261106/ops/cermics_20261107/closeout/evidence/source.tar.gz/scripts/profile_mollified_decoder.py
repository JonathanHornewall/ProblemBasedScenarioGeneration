"""Profile exact sparse K-cell decoders without launching neural training."""

from __future__ import annotations

import argparse
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np

from proximal_spo.artifacts import environment_receipt, write_json
from proximal_spo.benchmarks import build_benchmark
from proximal_spo.mollification import MollifiedAnchoredProximalObjective
from proximal_spo.problem import PartialCostInterface


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    arguments = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    problem = build_benchmark("cost.grid5", structural_seed=101)
    interface = PartialCostInterface.full_cost(problem)
    random = np.random.Generator(np.random.PCG64(991))
    objective = MollifiedAnchoredProximalObjective(
        interface,
        tau=300.0,
        sigma=0.25,
        residual_scale=np.ones(interface.report_dimension),
        training_samples=8,
        evaluation_samples=64,
        workers=arguments.workers,
        random_seed=401,
    )
    rows: list[dict[str, object]] = []
    try:
        for role, outer_samples, cells in (
            ("training", 128, 8),
            ("evaluation", 64, 64),
        ):
            outputs = random.normal(
                size=(outer_samples, 2 * interface.report_dimension)
            )
            objective.prime_base_cache(
                outputs[:, : interface.report_dimension], role=role
            )
            for pass_name in ("cold_factorization", "warm_reuse"):
                started = time.perf_counter()
                details = objective.decode_details(outputs, role=role)
                wall = time.perf_counter() - started
                rows.append(
                    {
                        "role": role,
                        "pass": pass_name,
                        "outer_samples": outer_samples,
                        "cells": cells,
                        "product_variables": cells * problem.variable_count
                        + interface.report_dimension,
                        "product_constraints": cells * problem.constraint_count
                        + interface.report_dimension,
                        "wall_seconds": wall,
                        "contexts_per_second": outer_samples / wall,
                        "oracle_stats": asdict(details.deployment.stats),
                    }
                )
    finally:
        objective.close()
    write_json(
        arguments.output,
        {
            "purpose": "implementation profile, not scientific method evidence",
            "benchmark_id": "cost.grid5",
            "workers": arguments.workers,
            "formulation": "sparse product cells plus explicit average statistic",
            "raw_outputs_persisted": False,
            "rows": rows,
            "environment": environment_receipt(root),
        },
    )


if __name__ == "__main__":
    main()
