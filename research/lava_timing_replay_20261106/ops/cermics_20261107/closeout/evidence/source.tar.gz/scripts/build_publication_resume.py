"""Resume only unfinished, non-gated variants from a frozen campaign."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json
from proximal_spo.publication_selection import build_remaining_campaign


def _object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object at {path}")
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--progress", type=Path, required=True)
    parser.add_argument("--exclude", action="append", default=[])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-root", required=True)
    parser.add_argument("--name", required=True)
    arguments = parser.parse_args()
    progress = _object(arguments.progress)
    runs = progress.get("runs")
    if not isinstance(runs, list):
        raise ValueError("progress receipt has no runs")
    completed_names = []
    for row in runs:
        if not isinstance(row, dict) or row.get("status") not in {
            "complete",
            "skipped_complete",
        }:
            continue
        config = row.get("expanded_config")
        if not isinstance(config, dict) or not isinstance(config.get("name"), str):
            raise ValueError("completed progress row lacks expanded config name")
        completed_names.append(str(config["name"]))
    campaign = build_remaining_campaign(
        _object(arguments.source),
        completed_names=completed_names,
        excluded_names=arguments.exclude,
        run_root=arguments.run_root,
        name=arguments.name,
    )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.output, campaign)
    print(
        f"wrote {len(campaign['variants'])} resumed runs to {arguments.output}"
    )


if __name__ == "__main__":
    main()
