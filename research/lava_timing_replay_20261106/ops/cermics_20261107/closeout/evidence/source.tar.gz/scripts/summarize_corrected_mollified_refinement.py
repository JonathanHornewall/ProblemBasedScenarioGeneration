"""Incrementally summarize the corrected mollification refinement campaign."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
RESULT_ROOT = REPO_ROOT / "results" / "mollified_corrected"


def _progress_path(campaign: Path, run_root: Path) -> Path:
    digest = hashlib.sha256(campaign.read_bytes()).hexdigest()[:10]
    candidates = sorted(
        run_root.glob(f"campaign_progress_{digest}_*.json"),
        key=lambda path: path.stat().st_mtime_ns,
    )
    if not candidates:
        raise FileNotFoundError("campaign has no progress receipt yet")
    return candidates[-1]


def _completed_rows(progress: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    base_by_seed: dict[int, tuple[str, float]] = {}
    for receipt in progress["runs"]:
        if receipt.get("status") not in {"complete", "skipped_complete"}:
            continue
        config = receipt["expanded_config"]
        run_path = REPO_ROOT / receipt["run_directory"]
        summary = json.loads((run_path / "summary.json").read_text(encoding="utf-8"))
        base = json.loads(
            (run_path / "embedded_mse_base.json").read_text(encoding="utf-8")
        )
        diagnostic = json.loads(
            (run_path / "mollification_diagnostics.json").read_text(
                encoding="utf-8"
            )
        )
        if diagnostic.get("deployment_rule") != "hard_optimizer_at_recovered_cost":
            raise ValueError(f"incorrect deployment rule in {run_path}")
        seed = int(config["seeds"]["data"])
        base_key = (
            str(base["parameter_sha256"]),
            float(base["validation"]["mean_regret"]),
        )
        if base_by_seed.setdefault(seed, base_key) != base_key:
            raise ValueError(f"embedded MSE base changed within seed {seed}")
        regret = float(summary["best_validation"]["mean_regret"])
        base_regret = float(base["validation"]["mean_regret"])
        rows.append(
            {
                "name": str(config["name"]),
                "data_seed": seed,
                "sigma": float(config["method_parameters"]["sigma"]),
                "tau": float(config["method_parameters"]["tau"]),
                "learning_rate": float(config["training"]["learning_rate"]),
                "validation_regret": regret,
                "mse_validation_regret": base_regret,
                "paired_delta": regret - base_regret,
                "best_epoch": int(summary["best_epoch"]),
                "epochs_completed": int(summary["epochs_completed"]),
                "training_wall_seconds": float(summary["training_wall_seconds"]),
                "run_directory": str(receipt["run_directory"]),
            }
        )
    return sorted(
        rows,
        key=lambda row: (row["tau"], row["learning_rate"], row["data_seed"]),
    )


def _aggregate(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[tuple[float, float], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[(row["tau"], row["learning_rate"])].append(row)
    result = []
    for (tau, learning_rate), group in groups.items():
        deltas = [float(row["paired_delta"]) for row in group]
        result.append(
            {
                "tau": tau,
                "learning_rate": learning_rate,
                "completed_seeds": sorted(int(row["data_seed"]) for row in group),
                "seed_count": len(group),
                "mean_validation_regret": sum(
                    float(row["validation_regret"]) for row in group
                )
                / len(group),
                "mean_mse_validation_regret": sum(
                    float(row["mse_validation_regret"]) for row in group
                )
                / len(group),
                "mean_paired_delta": sum(deltas) / len(deltas),
                "improved_seed_count": sum(delta < 0.0 for delta in deltas),
                "mean_best_epoch": sum(int(row["best_epoch"]) for row in group)
                / len(group),
                "mean_epochs_completed": sum(
                    int(row["epochs_completed"]) for row in group
                )
                / len(group),
                "mean_training_wall_seconds": sum(
                    float(row["training_wall_seconds"]) for row in group
                )
                / len(group),
            }
        )
    return sorted(
        result,
        key=lambda row: (
            row["seed_count"] != 3,
            row["mean_paired_delta"],
            row["tau"],
            row["learning_rate"],
        ),
    )


def _markdown(summary: dict[str, Any]) -> str:
    lines = [
        "# Corrected mollification optimization refinement",
        "",
        f"Completed runs: **{summary['completed_runs']}/{summary['expected_runs']}**. ",
        f"Complete three-seed arms: **{summary['complete_arms']}/"
        f"{summary['expected_arms']}**.",
        "",
        "| rank | tau | learning rate | paired delta | wins | mean regret | "
        "mean best epoch |",
        "|---:|---:|---:|---:|---:|---:|---:|",
    ]
    complete = [row for row in summary["aggregates"] if row["seed_count"] == 3]
    for rank, row in enumerate(complete, start=1):
        lines.append(
            f"| {rank} | {row['tau']:g} | {row['learning_rate']:g} | "
            f"{row['mean_paired_delta']:+.6f} | "
            f"{row['improved_seed_count']}/3 | "
            f"{row['mean_validation_regret']:.6f} | "
            f"{row['mean_best_epoch']:.1f} |"
        )
    if not complete:
        lines.append("| -- | -- | -- | -- | -- | -- | -- |")
    return "\n".join(lines) + "\n"


def summarize(campaign: Path) -> dict[str, Any]:
    payload = json.loads(campaign.read_text(encoding="utf-8"))
    run_root = REPO_ROOT / str(payload["run_root"])
    progress_path = _progress_path(campaign, run_root)
    progress = json.loads(progress_path.read_text(encoding="utf-8"))
    rows = _completed_rows(progress)
    aggregates = _aggregate(rows)
    expected_arms = len(payload["design"]["taus"]) * len(
        payload["design"]["learning_rates"]
    )
    return {
        "campaign": str(campaign.relative_to(REPO_ROOT)),
        "campaign_progress": str(progress_path.relative_to(REPO_ROOT)),
        "source_sha256": progress["source_sha256"],
        "design": payload["design"],
        "expected_runs": len(payload["variants"]),
        "completed_runs": len(rows),
        "expected_arms": expected_arms,
        "complete_arms": sum(row["seed_count"] == 3 for row in aggregates),
        "rows": rows,
        "aggregates": aggregates,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--strict", action="store_true")
    arguments = parser.parse_args()
    summary = summarize(arguments.campaign.resolve())
    if arguments.strict and summary["completed_runs"] != summary["expected_runs"]:
        raise ValueError("strict summary requested before campaign completion")
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    write_json(RESULT_ROOT / "optimization_refinement_progress.json", summary)
    (RESULT_ROOT / "optimization_refinement_progress.md").write_text(
        _markdown(summary), encoding="utf-8"
    )
    buffer = io.StringIO()
    fieldnames = list(summary["rows"][0]) if summary["rows"] else ["name"]
    writer = csv.DictWriter(buffer, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(summary["rows"])
    (RESULT_ROOT / "optimization_refinement_progress.csv").write_text(
        buffer.getvalue(), encoding="utf-8"
    )
    print(RESULT_ROOT / "optimization_refinement_progress.md")


if __name__ == "__main__":
    main()
