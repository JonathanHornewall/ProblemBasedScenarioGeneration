#!/usr/bin/env python3
"""Validation-only transitions; never read test scores to select a setting."""

from __future__ import annotations

import argparse
import copy
import statistics
from collections import defaultdict
from pathlib import Path

from build_central_path_final import read, write


def mu_group(job):
    p = job["config"]["method_parameters"]
    return float(p.get("alpha_end", p.get("alpha_start", 0.0)))


def hard_score(summary):
    metrics = summary["best_validation"]
    normalized = metrics.get("normalized_mean_regret")
    return float(metrics["mean_regret"] if normalized is None else normalized)


def shortlist(rows, method, count):
    # Select every chart/optimizer factor within a fixed endpoint temperature
    # by barrier score before exposing those winners to hard-regret selection.
    if method == "central_path_barrier_validation":
        groups = defaultdict(list)
        for row in rows:
            groups[mu_group(row["job"])].append(row)
        rows = [
            min(g, key=lambda r: (r["selection"], r["job"]["candidate"]))
            for g in groups.values()
        ]
    return sorted(rows, key=lambda r: (r["hard"], r["job"]["candidate"]))[:count]


def common_horizon(records, barrier):
    curves = []
    for record in records:
        values = {}
        for row in record["curve"]:
            if "selection_score" not in row:
                continue
            if barrier:
                value = row["selection_score"]
            else:
                metrics = row["validation"]
                value = metrics.get("normalized_mean_regret")
                if value is None:
                    value = metrics["mean_regret"]
            values[row["epoch"]] = value
        curves.append(values)
    epochs = set.intersection(*(set(c) for c in curves))
    if not epochs:
        raise ValueError("refinement seeds have no common validation checkpoints")
    epoch = min(epochs, key=lambda e: (statistics.mean(c[e] for c in curves), e))
    return epoch, {
        str(e): statistics.mean(c[e] for c in curves) for e in sorted(epochs)
    }


def transition(manifest, output_root):
    stages = {j["stage"] for j in manifest["jobs"]}
    if len(stages) != 1 or stages == {"confirmation"}:
        raise ValueError("only a homogeneous development stage can select models")
    stage = next(iter(stages))
    groups, unavailable = defaultdict(list), []
    for job in manifest["jobs"]:
        path = output_root / "receipts" / (job["id"] + ".json")
        if not path.exists():
            raise ValueError("stage not terminal: " + job["id"])
        record = read(path)
        if record.get("smoke_only"):
            raise ValueError("smoke receipts cannot enter scientific selection")
        if record["status"] != "complete":
            unavailable.append(
                {
                    "id": job["id"],
                    "status": record["status"],
                    "error": record.get("error"),
                }
            )
            continue
        if record["test_access"] or record["summary"].get("test") is not None:
            raise ValueError("test data accessed during development")
        groups[(job["cell"], job["method"], job["candidate"])].append(record)
    grouped = defaultdict(list)
    for (cell, method, candidate), records in groups.items():
        if len(records) != (1 if stage == "screen" else 3):
            unavailable.append(
                {
                    "cell": cell,
                    "method": method,
                    "candidate": candidate,
                    "status": "incomplete_refinement_seed_bundle",
                }
            )
            continue
        grouped[(cell, method)].append(
            {
                "job": records[0]["job"],
                "records": records,
                "selection": statistics.mean(
                    r["summary"]["best_selection_score"] for r in records
                ),
                "hard": statistics.mean(hard_score(r["summary"]) for r in records),
            }
        )
    jobs, decisions, missing_cells = [], [], []
    for cell in manifest["cells"]:
        for method in manifest.get("cell_methods", {}).get(cell, manifest["methods"]):
            selected = shortlist(
                grouped[(cell, method)], method, 3 if stage == "screen" else 1
            )
            if not selected:
                missing_cells.append(
                    {
                        "cell": cell,
                        "method": method,
                        "reason": "no eligible development candidate",
                    }
                )
                continue
            info = manifest["cells"][cell]
            for row in selected:
                source = row["job"]
                next_stage = "refinement" if stage == "screen" else "confirmation"
                seeds = (
                    info["refinement_seeds"]
                    if stage == "screen"
                    else info["confirmation_seeds"]
                )
                decision = {k: source[k] for k in ("cell", "method", "candidate")}
                decision.update(
                    selection_score=row["selection"], hard_regret=row["hard"]
                )
                epoch = None
                if stage == "refinement":
                    epoch, curve = common_horizon(
                        row["records"], method == "central_path_barrier_validation"
                    )
                    decision.update(frozen_horizon=epoch, mean_validation_curve=curve)
                decisions.append(decision)
                for repeat, seed in enumerate(seeds):
                    job = copy.deepcopy(source)
                    job.update(
                        stage=next_stage,
                        repeat=repeat,
                        id=f"{next_stage}__{cell}__{method}__{source['candidate']}__r{repeat}",
                    )
                    config = job["config"]
                    config["seeds"] = seed
                    config["evaluate_test"] = next_stage == "confirmation"
                    config["name"] = job["id"]
                    if epoch is not None:
                        job["frozen_horizon"] = epoch
                        config["training"]["schedule_reference_epochs"] = config[
                            "training"
                        ]["epochs"]
                        config["training"].update(
                            epochs=max(1, epoch),
                            validation_epochs=[max(1, epoch)],
                            selection_mode="last",
                        )
                    jobs.append(job)
    jobs.sort(
        key=lambda j: (j["repeat"], j.get("arm_order", 0), j["cell"], j["method"])
    )
    return {
        **manifest,
        "jobs": jobs,
        "selection_receipt": {
            "from_stage": stage,
            "decisions": decisions,
            "unavailable": unavailable,
            "missing_cells": missing_cells,
            "test_scores_read": False,
        },
    }


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--output-root", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    write(a.output, transition(read(a.manifest), a.output_root))
