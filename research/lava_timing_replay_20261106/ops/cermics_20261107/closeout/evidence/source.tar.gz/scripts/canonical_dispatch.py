"""Global user-directed waves: MSE/WISE, SPO+, then optional barrier rerun."""
from build_central_path_final import read, write
import time


def dispatch_state(root, jobs):
    waves = read(root / "screen.json")["protocol"]["method_waves"]
    groups = {(j["cell"],j["method"]) for j in jobs}
    repair = root / "spo_memory_recovery.json"
    repaired = {(j["cell"], j["method"]) for j in read(repair)["jobs"]} if repair.exists() else set()
    active_wave = len(waves)
    for index, methods in enumerate(waves):
        terminal = True
        for cell, method in groups:
            if method not in methods:
                continue
            suffix = "__memory_repair_v1" if (cell, method) in repaired else ""
            path = root / "results/selections" / f"confirmation__{cell}__{method}{suffix}.json"
            if not path.exists() or any(not (root / "results/receipts" / (j["id"]+".json")).exists()
                                        for j in read(path)["jobs"]):
                terminal = False
                break
        if not terminal:
            active_wave = index
            break
    deferred = [m for wave in waves[active_wave+1:] for m in wave]
    # Preserve the requested first wave without idling hundreds of cores behind
    # its final, already-dispatched test evaluations. No tuning decision remains
    # in that wave, and MSE/WISE keep priority over every SPO+ claim.
    backfill = False
    if len(waves) > 1 and active_wave == 0 and (root / 'burst.sqlite').exists():
        import sqlite3
        first = [(cell,method) for cell,method in groups if method in waves[0]]
        selected = all((root/'results/selections'/f'confirmation__{c}__{m}.json').exists() for c,m in first)
        if selected:
            db=sqlite3.connect(root/'burst.sqlite',timeout=60)
            import json
            waiting=any(json.loads(row[0])['method'] in waves[0] for row in db.execute("SELECT payload FROM jobs WHERE status IN ('pending','deferred','interrupted')"))
            db.close()
            if not waiting:
                backfill=True
                deferred=[m for m in deferred if m not in waves[1]]
    override_path = root / 'dispatch_override.json'
    override = read(override_path) if override_path.exists() else {}
    released = set(override.get('release_methods', []))
    deferred = [method for method in deferred if method not in released]
    active = waves[0]+waves[1] if backfill else waves[active_wave] if active_wave < len(waves) else []
    active = sorted(set(active) | (released & {j['method'] for j in jobs}))
    status = {"updated_unix":time.time(),"active_wave":active_wave,
              "active_methods":active,
              "spo_backfills_final_first_wave_fits":backfill,
              "explicitly_released_methods":sorted(released),
              "deferred_methods":deferred}
    write(root / "results/dispatch_status.json",status)
    return status


def apply_burst_gate(db, deferred):
    rows = db.execute("SELECT id,payload,status FROM jobs WHERE status IN ('pending','deferred')").fetchall()
    import json
    for row in rows:
        status = "deferred" if json.loads(row["payload"])["method"] in deferred else "pending"
        if row["status"] != status:
            # A worker may have claimed this row since the SELECT. Never turn
            # its running/external ownership back into dispatchable work.
            db.execute("UPDATE jobs SET status=? WHERE id=? AND status=?",(status,row["id"],row["status"]))
    db.commit()
