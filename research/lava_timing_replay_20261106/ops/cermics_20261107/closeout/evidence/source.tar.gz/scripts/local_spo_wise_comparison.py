#!/usr/bin/env python3
"""Build, execute and summarize a frozen paired top-three local diagnostic."""
from __future__ import annotations

import argparse
import collections
import copy
import csv
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import statistics
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
RUN = ROOT / "runs/local_spo_wise_top3_20260923"
EXTERNAL = BASE / "public-baseline-sources-20260905/dfl-extensions-lab-fixed/src"
PUBLIC = BASE / "public-baseline-sources-20260905/solver-free-dfl"
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "scripts"), str(EXTERNAL), str(PUBLIC)]
os.environ.setdefault("DFL_EXTENSIONS_SRC", str(EXTERNAL))
os.environ.setdefault("SOLVER_FREE_DFL_REPO", str(PUBLIC))


def read(path):
    return json.loads(Path(path).read_text())


def write(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True, allow_nan=False)+"\n")
    tmp.replace(path)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def build(args):
    from select_central_path_final import common_horizon, hard_score
    sources = [
        BASE / "ProximalSPO-final-20260922/runs/central_path_final_20260922/hornewall/retrieved",
        BASE / "ProximalSPO-extension-20260923/runs/central_path_extension_20260923/hornewall/retrieved",
    ]
    groups, cells, source_hashes = collections.defaultdict(list), {}, {}
    for root in sources:
        manifest_path = root / "refinement.json"
        manifest = read(manifest_path)
        source_hashes[str(manifest_path)] = sha(manifest_path)
        for job in manifest["jobs"]:
            if job["method"] not in ("spo_plus", "wise"):
                continue
            path = root / "results/receipts" / (job["id"]+".json")
            record = read(path)
            assert record["status"] == "complete" and not record["test_access"]
            assert record["summary"].get("test") is None
            source_hashes[str(path)] = sha(path)
            groups[job["cell"],job["method"],job["candidate"]].append(record)
            cells[job["cell"]] = manifest["cells"][job["cell"]]
    shortlist = collections.defaultdict(list)
    for (cell, method, candidate), records in groups.items():
        assert len(records) == 3
        epoch, curve = common_horizon(records, False)
        shortlist[cell,method].append({
            "candidate":candidate, "template":records[0]["job"],
            "original_refinement_score":statistics.mean(hard_score(r["summary"]) for r in records),
            "frozen_horizon":epoch, "mean_validation_curve":curve,
        })
    assert len(cells)==35 and len(shortlist)==70
    jobs, rankings = [], []
    for (cell, method), candidates in sorted(shortlist.items()):
        assert len(candidates)==3, (cell,method,len(candidates))
        candidates.sort(key=lambda x:(x["original_refinement_score"],x["candidate"]))
        for rank, candidate in enumerate(candidates,1):
            source = candidate["template"]
            rankings.append({"cell":cell,"method":method,"rank":rank,
                             **{k:v for k,v in candidate.items() if k!="template"}})
            for repeat, seeds in enumerate(cells[cell]["refinement_seeds"]):
                for implementation in ("legacy","canonical"):
                    job = copy.deepcopy(source)
                    job.update(
                        id=f"validation__{cell}__{method}__rank{rank}__r{repeat}__{implementation}",
                        stage="validation", repeat=repeat, implementation=implementation,
                        original_rank=rank,
                    )
                    config=job["config"]
                    config.update(name=job["id"],seeds=seeds,evaluate_test=False,workers=1)
                    config["training"].update(
                        selection_mode="validation_regret", torch_threads=1,
                    )
                    jobs.append(job)
    # Cover all settings for the first seed/rank before later replications.
    jobs.sort(key=lambda j:(j["repeat"],j["original_rank"],j["method"],j["cell"],j["implementation"]))
    manifest={"created_utc":now(),"purpose":"Paired implementation diagnostic; not a replacement publication campaign",
        "protocol":{
            "validation_repeats":3,"test_repeats":10,"benchmark_training_size_cells":35,"configurations_per_cell_method":3,
            "seeds":"All three original refinement seed bundles for validation; all ten original confirmation bundles for testing",
            "selection":"Original three screened/refined candidates, ranked by archived refinement validation only",
            "horizons":"Original validation checkpoint schedule; choose each implementation's candidate and common horizon from its three new validation runs, then freeze for ten test runs",
            "no_test_based_selection":True,"test_scores_are_diagnostic_only":True,
            "training_sizes":"Retain every current cell, including the original-size companion cells and all 100-example cells",
            "comparison":"Legacy local controls versus canonical PyEPO SPOPlus+plain HiGHS or physical-coordinate WISE+plain HiGHS",
            "training_on_integer_families":"Preserve continuous LP relaxation for SPO+; original integer deployment",
            "maximum_optimization_seconds":3600,"job_wall_cap_seconds":21600,
            "original_results_modified":False,"remote_compute":False,
        },"cells":cells,"rankings":rankings,"sources":source_hashes,"jobs":jobs}
    if (RUN/"manifest.json").exists():
        raise RuntimeError("Refusing to overwrite frozen manifest")
    write(RUN/"manifest.json",manifest)
    code_paths=[ROOT/"scripts/local_spo_wise_comparison.py",ROOT/"scripts/local_spo_wise_objectives.py",
                ROOT/"scripts/run_central_path_final.py",ROOT/"src/proximal_spo/training.py",
                ROOT/"src/proximal_spo/objectives.py",ROOT/"src/proximal_spo/public_highs.py"]
    write(RUN/"source_receipt.json",{"created_utc":now(),"manifest_sha256":sha(RUN/"manifest.json"),
        "files":{str(p):sha(p) for p in code_paths},"external_commit":"f3bdd0cde748f0ecbef85477c9e4caef1096fc2d",
        "python":sys.version,"host":platform.node()})
    print(json.dumps({"validation_fits":len(jobs),"planned_test_fits":35*2*2*10,"cells":35,"manifest":str(RUN/"manifest.json")}))


def fit(job, loaded, directory, update):
    import numpy as np
    import torch
    from proximal_spo.artifacts import RunRecorder, model_sha256
    from proximal_spo.config import RunSpec
    from proximal_spo.evaluation import evaluate_model, predict_in_batches
    from proximal_spo.objectives import prepare_split, PreparedSplit, sample_keys_for_split
    from proximal_spo.oracles import make_lp_oracle, OracleStats
    from proximal_spo.problem import PartialCostInterface
    from proximal_spo.runner import _coefficient_transform, _objective, _standard_model
    from proximal_spo.training import train_model
    from local_spo_wise_objectives import CanonicalSPOPlus, PhysicalWISE, PlainHighsBatch

    config=copy.deepcopy(job["config"])
    method=job["method"]
    canonical=job["implementation"]=="canonical"
    if method=="wise":
        config["method"]="wise"
        if canonical:
            config["cost_coordinate_normalization"]="none"
    spec=RunSpec.from_dict(config)
    dataset,problem=loaded.dataset,loaded.problem
    interface,transform=_coefficient_transform(spec,dataset,dataset.interface(spec.interface,problem))
    training_problem=problem.continuous_relaxation() if method=="spo_plus" else problem
    objective_interface=PartialCostInterface(training_problem,interface.fixed_cost,interface.statistic)
    setup={}

    def prepare(split, geometry):
        start=time.perf_counter()
        if canonical and method=="wise":
            # Facility location stores only uncertain costs as coefficients;
            # physical WISE also includes the deterministic cost coordinates.
            coefficients=split.physical_costs
            means=split.conditional_mean_costs
        else:
            coefficients,means=dataset.coefficients(split,spec.interface)
            coefficients,means=transform.apply(coefficients),transform.apply(means)
        with (PlainHighsBatch(geometry) if canonical else
              make_lp_oracle(geometry,workers=1,random_seed=spec.seeds.structural)) as oracle:
            result=prepare_split(contexts=split.contexts,
                coefficients=coefficients,conditional_mean_coefficients=means,
                physical_costs=split.physical_costs,conditional_mean_costs=split.conditional_mean_costs,
                split=split.split,oracle=oracle)
        setup[split.split+"_reference_preparation_seconds"]=time.perf_counter()-start
        return result

    update("training_reference_preparation")
    train=prepare(dataset.train,training_problem)
    update("validation_reference_preparation")
    validation=prepare(dataset.validation,problem)
    if canonical:
        objective=CanonicalSPOPlus(objective_interface,problem) if method=="spo_plus" else PhysicalWISE(problem)
    else:
        objective=_objective(spec,objective_interface,train,deployment_problem=problem)
    try:
        torch.manual_seed(spec.seeds.initialization)
        model=_standard_model(spec,train,objective,train.coefficients.mean(axis=0),np.zeros(1))
        initial_hash=model_sha256(model)
        recorder=RunRecorder(directory/"training",config=spec.to_dict(),repo_root=ROOT)
        update("training",epochs_completed=0)
        optimization_seconds=0.0
        def checkpoint(row):
            nonlocal optimization_seconds
            optimization_seconds+=row.get("epoch_wall_seconds",0.0)
            # The shared trainer calls this after stopping the optimizer timer.
            if "validation" in row or row["epoch"] % 25 == 0:
                temporary=directory/"last_model.pt.tmp"
                torch.save({"state_dict":model.state_dict(),"epoch":row["epoch"],
                            "config":spec.to_dict(),"job":job},temporary)
                temporary.replace(directory/"last_model.pt")
            update("training",epochs_completed=row["epoch"],optimizer_seconds=optimization_seconds)
        if job.get("frozen_horizon",spec.training.epochs):
            result=train_model(model=model,objective=objective,train=train,validation=validation,test=None,
                spec=spec.training,shuffle_seed=spec.seeds.shuffle,recorder=recorder,
                epoch_callback=checkpoint)
            summary=result.to_dict()
        else:
            metrics=evaluate_model(model,objective,validation,batch_size=spec.training.evaluation_batch_size)
            summary={"epochs_completed":0,"best_epoch":0,"best_validation":metrics.to_dict(),
                     "optimization_wall_seconds":0,"parameter_sha256":model_sha256(model),"optimization_cap_reached":False}
            recorder.append_curve({"epoch":0,"validation":metrics.to_dict(),
                "selection_score":metrics.mean_regret,"initialization_checkpoint":True})
            recorder.finish(summary)
        update("checkpoint")
        torch.save({"state_dict":model.state_dict(),"config":spec.to_dict(),"job":job},directory/"model.pt")
        summary["test"]=None
        if job["stage"]=="testing":
            update("test_reference_preparation")
            test=prepare(dataset.test,problem)
            update("test_evaluation")
            start=time.perf_counter()
            summary["test"]=evaluate_model(model,objective,test,batch_size=spec.training.evaluation_batch_size).to_dict()
            summary["test_evaluation_wall_seconds"]=time.perf_counter()-start
            pred=predict_in_batches(model,test.contexts,batch_size=spec.training.evaluation_batch_size)
            np.savez_compressed(directory/"test_predictions.npz",outputs=pred,
                                physical_costs=objective.predicted_physical_costs(pred))
        summary.update(initial_parameter_sha256=initial_hash,preparation_timing=setup,
            implementation=type(objective).__name__,effective_config=spec.to_dict(),
            timing_definition="Original shared trainer's optimizer-loop counter; excludes reference preparation, validation, epoch selection, checkpoint writes and test")
        curve=[json.loads(line) for line in recorder.curve_path.read_text().splitlines()]
        return summary,curve
    finally:
        objective.close()


def worker(args):
    import random
    import numpy as np
    import torch
    from proximal_spo.artifacts import environment_receipt
    from run_central_path_final import load_job_data
    from run_public_solver_free_matched import _hash_array
    manifest=read(args.manifest)
    job=copy.deepcopy(manifest["jobs"][args.index])
    run=args.manifest.parent
    if args.smoke and run.resolve()==RUN.resolve():
        raise ValueError("Smoke jobs must use a separate preflight manifest directory")
    destination=run/"receipts"/(job["id"]+".json")
    directory=run/"attempts"/job["id"]
    directory.mkdir(parents=True,exist_ok=True)
    lock=(directory/"worker.lock").open("w")
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    if destination.exists():
        return
    if args.smoke:
        job["original_sizes"]={"train":8,"validation":3,"test":3}
        job["config"]["sizes"]={"train":4,"validation":3,"test":3}
        job["config"]["training"].update(epochs=2,batch_size=4,validation_epochs=[2])
        job["frozen_horizon"]=2
    started=time.perf_counter()
    record={"job":job,"status":"running","started_utc":now(),"pid":os.getpid(),"host":platform.node(),
            "manifest_sha256":sha(args.manifest),"smoke_only":args.smoke,"attempt_directory":str(directory)}

    def update(phase,**values):
        record.update(phase=phase,elapsed_seconds=time.perf_counter()-started,**values)
        write(run/"progress"/(job["id"]+".json"),record)

    def interrupted(signum,frame):
        raise TimeoutError(f"Signal {signum} during {record.get('phase')}; partial artifacts retained")

    for signum in (signal.SIGTERM,signal.SIGINT,signal.SIGALRM):
        signal.signal(signum,interrupted)
    signal.setitimer(signal.ITIMER_REAL,manifest["protocol"]["job_wall_cap_seconds"])
    try:
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        random.seed(job["config"]["seeds"]["initialization"])
        np.random.seed(job["config"]["seeds"]["initialization"])
        record["environment"]=environment_receipt(ROOT)
        import importlib.metadata
        record["environment"]["packages"]["pyepo"]=importlib.metadata.version("pyepo")
        source_receipt=run/"source_receipt.json"
        if source_receipt.exists():
            frozen=read(source_receipt)
            for path,expected in frozen["files"].items():
                if sha(path)!=expected:
                    raise RuntimeError("Scientific source changed after freezing: "+path)
            parent_hash=manifest.get("parent_manifest_sha256",sha(args.manifest))
            if parent_hash!=frozen["manifest_sha256"]:
                raise RuntimeError("Manifest differs from its frozen source receipt")
            record["source_receipt_sha256"]=sha(source_receipt)
        update("data_generation")
        loaded=load_job_data(job)
        record["data_hashes"]={split:{field:_hash_array(getattr(getattr(loaded.dataset,split),field))
            for field in ("contexts","physical_costs","conditional_mean_costs")}
            for split in ("train","validation","test")}
        record["benchmark_provenance"]=loaded.provenance
        record["summary"],record["curve"]=fit(job,loaded,directory,update)
        record["test_access"]=job["stage"]=="testing"
        record["status"]="complete"
    except Exception as error:
        record.update(status="interrupted" if isinstance(error,TimeoutError) else "failed",
                      error=str(error),traceback=traceback.format_exc())
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        record.update(finished_utc=now(),total_wall_seconds=time.perf_counter()-started)
        write(destination,record)
        update(record["status"])
    if record["status"]!="complete":
        raise SystemExit(1)


def select_testing(args):
    """Freeze each winner using only its three-seed validation records."""
    from select_central_path_final import common_horizon, hard_score
    run=args.manifest.parent
    destination=run/"testing_manifest.json"
    if destination.exists():
        return destination
    manifest=read(args.manifest)
    groups=collections.defaultdict(list)
    missing=[]
    for job in manifest["jobs"]:
        path=run/"receipts"/(job["id"]+".json")
        if not path.exists():
            missing.append(job["id"]);continue
        record=read(path)
        if record["status"]!="complete":
            missing.append(job["id"]);continue
        assert not record["test_access"] and record["summary"].get("test") is None
        assert not record.get("smoke_only"), "Smoke receipts cannot select scientific models"
        groups[job["cell"],job["method"],job["implementation"],job["candidate"]].append(record)
    if missing:
        write(run/"SELECTION_BLOCKED.json",{"reason":"Incomplete validation stage; no automatic selection from partial seed bundles","jobs":missing})
        return None
    candidates=collections.defaultdict(list)
    for (cell,method,implementation,candidate),records in groups.items():
        assert len(records)==3
        horizon,curve=common_horizon(records,False)
        candidates[cell,method,implementation].append({"candidate":candidate,"horizon":horizon,
            "score":statistics.mean(hard_score(r["summary"]) for r in records),
            "mean_validation_curve":curve,"template":records[0]["job"]})
    jobs,decisions=[],[]
    assert len(candidates)==140
    for (cell,method,implementation),entries in sorted(candidates.items()):
        assert len(entries)==3
        entries.sort(key=lambda x:(x["score"],x["candidate"]))
        chosen=entries[0]
        decisions.append({"cell":cell,"method":method,"implementation":implementation,
                          "candidate":chosen["candidate"],"horizon":chosen["horizon"],"score":chosen["score"],
                          "ranking":[{k:v for k,v in x.items() if k!="template"} for x in entries],"test_scores_read":False})
        for repeat,seeds in enumerate(manifest["cells"][cell]["confirmation_seeds"]):
            job=copy.deepcopy(chosen["template"])
            job.update(id=f"testing__{cell}__{method}__r{repeat}__{implementation}",
                       stage="testing",repeat=repeat,frozen_horizon=chosen["horizon"])
            config=job["config"]
            config.update(name=job["id"],seeds=seeds,evaluate_test=True)
            config["training"].update(schedule_reference_epochs=config["training"]["epochs"],
                epochs=max(1,chosen["horizon"]),validation_epochs=[max(1,chosen["horizon"])],selection_mode="last")
            jobs.append(job)
    jobs.sort(key=lambda j:(j["repeat"],j["method"],j["cell"],j["implementation"]))
    write(destination,{**manifest,"jobs":jobs,"created_utc":now(),"parent_manifest_sha256":sha(args.manifest),"selection_decisions":decisions})
    return destination


def summarize(args):
    manifest=read(args.manifest)
    run=args.manifest.parent
    if (run/"testing_manifest.json").exists():
        manifest=read(run/"testing_manifest.json")
    records={p.stem:read(p) for p in (run/"receipts").glob("*.json")}
    pairs=collections.defaultdict(dict)
    status=collections.Counter()
    for job in manifest["jobs"]:
        record=records.get(job["id"])
        status[record["status"] if record else "remaining"]+=1
        if record and record["status"]=="complete":
            assert not record.get("smoke_only")
            key=(job["cell"],job["method"],job["candidate"] if job["stage"]=="validation" else "validation_selected",
                 job["original_rank"] if job["stage"]=="validation" else 0,job["repeat"])
            pairs[key][job["implementation"]]=record
    paired=[]
    for (cell,method,candidate,rank,repeat),pair in pairs.items():
        if set(pair)!={"legacy","canonical"}:
            continue
        left,right=pair["legacy"],pair["canonical"]
        assert left["data_hashes"]==right["data_hashes"],(cell,method,repeat)
        a,b=left["summary"],right["summary"]
        metric="test" if left["job"]["stage"]=="testing" else "best_validation"
        paired.append({"cell":cell,"method":method,"candidate":candidate,"rank":rank,"repeat":repeat,"metric":metric,
            "legacy_horizon":left["job"].get("frozen_horizon"),"canonical_horizon":right["job"].get("frozen_horizon"),
            "legacy_candidate":left["job"]["candidate"],"canonical_candidate":right["job"]["candidate"],
            "legacy_regret_pct":100*a[metric]["normalized_mean_regret"],
            "canonical_regret_pct":100*b[metric]["normalized_mean_regret"],
            "delta_percentage_points":100*(b[metric]["normalized_mean_regret"]-a[metric]["normalized_mean_regret"]),
            "legacy_validation_regret":a["best_validation"]["mean_regret"],
            "canonical_validation_regret":b["best_validation"]["mean_regret"],
            "legacy_optimizer_seconds":a["optimization_wall_seconds"],
            "canonical_optimizer_seconds":b["optimization_wall_seconds"],
            "same_initial_weights":a["initial_parameter_sha256"]==b["initial_parameter_sha256"],
            "same_final_weights":a["parameter_sha256"]==b["parameter_sha256"],
            "legacy_cap":a.get("optimization_cap_reached",False),"canonical_cap":b.get("optimization_cap_reached",False),
        })
    grouped=collections.defaultdict(list)
    for row in paired:
        grouped[row["cell"],row["method"],row["rank"]].append(row)
    table=[]
    for (cell,method,rank),values in sorted(grouped.items()):
        row={"cell":cell,"method":method,"rank":rank,"paired_seeds":len(values)}
        for key in ("legacy_regret_pct","canonical_regret_pct","delta_percentage_points",
                    "legacy_optimizer_seconds","canonical_optimizer_seconds"):
            row[key]=statistics.mean(x[key] for x in values)
        row["delta_sd"]=statistics.stdev(x["delta_percentage_points"] for x in values) if len(values)>1 else None
        table.append(row)
    stage=manifest["jobs"][0]["stage"]
    output={"updated_utc":now(),"stage":stage,"status":dict(status),"paired_runs":len(paired),"per_pair":paired,"per_configuration":table,
            "interpretation":"Three-seed validation over the three archived configurations per method/cell, then ten fresh confirmation fits of each implementation's validation-selected winner. Original publication results preserved. No test-based selection."}
    write(run/"COMPARISON.json",output)
    if paired:
        with (run/"COMPARISON_PAIRS.csv").open("w") as f:
            writer=csv.DictWriter(f,fieldnames=list(paired[0]));writer.writeheader();writer.writerows(paired)
    lines=["# Local SPO+ / WISE implementation comparison","",output["interpretation"],"",
           f"Status: {dict(status)}. Complete pairs: {len(paired)}.","",
           f"Current stage: {stage}. Regret is normalized conditional regret in percent. Delta is canonical minus legacy, in percentage points. Negative favors canonical.","",
           "| Benchmark / training size | Method | Original rank | Paired seeds | Legacy % | Canonical % | Delta pp |",
           "|---|---|---:|---:|---:|---:|---:|"]
    for row in table:
        lines.append(f"| {row['cell']} | {row['method']} | {row['rank']} | {row['paired_seeds']} | {row['legacy_regret_pct']:.4f} | {row['canonical_regret_pct']:.4f} | {row['delta_percentage_points']:+.4f} |")
    (run/"COMPARISON.md").write_text("\n".join(lines)+"\n")
    return output


def controller(args):
    import psutil
    run=args.manifest.parent
    lock=(run/"controller.lock").open("w")
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    manifest=read(args.manifest)
    if (run/"testing_manifest.json").exists():
        args.manifest=run/"testing_manifest.json"
        manifest=read(args.manifest)
    jobs=manifest["jobs"]
    for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS","VECLIB_MAXIMUM_THREADS"):
        os.environ[key]="1"
    os.environ["PYTHONUNBUFFERED"]="1"
    active={}
    pending=[]
    for index,job in enumerate(jobs):
        if (run/"receipts"/(job["id"]+".json")).exists():
            continue
        path=run/"progress"/(job["id"]+".json")
        previous=read(path) if path.exists() else {}
        try:
            p=psutil.Process(previous["pid"])
            if "worker" in p.cmdline() and str(args.manifest) in p.cmdline():
                p.cpu_percent();active[index]={"process":p,"started":time.time(),"popen":None}
                continue
        except (psutil.Error,KeyError):
            pass
        pending.append(index)
    stop=False
    def stopping(signum,frame):
        nonlocal stop
        stop=True
    signal.signal(signal.SIGTERM,stopping)
    signal.signal(signal.SIGINT,stopping)
    (run/"logs").mkdir(exist_ok=True)
    last_report=0
    while True:
        if not pending and not active:
            if jobs[0]["stage"]=="validation":
                summarize(args)
                testing=select_testing(args)
                if testing is None:
                    write(run/"controller_status.json",{"status":"validation_incomplete","updated_utc":now()})
                    return
                args.manifest=testing
                jobs=read(testing)["jobs"]
                pending=[i for i,j in enumerate(jobs) if not (run/"receipts"/(j["id"]+".json")).exists()]
            else:
                break
        for index,item in list(active.items()):
            process=item["process"]
            if item["popen"] is not None:
                ended=item["popen"].poll() is not None
            else:
                try:ended=not process.is_running() or process.status()==psutil.STATUS_ZOMBIE
                except psutil.Error:ended=True
            if ended:
                path=run/"receipts"/(jobs[index]["id"]+".json")
                if not path.exists():
                    write(path,{"job":jobs[index],"status":"interrupted","error":"Worker exited without final receipt; partial artifacts preserved"})
                active.pop(index)
        if stop or (run/"STOP").exists():
            for item in active.values():
                try:item["process"].terminate()
                except psutil.Error:pass
            write(run/"controller_status.json",{"status":"stopping","pending":len(pending),"active":len(active),"updated_utc":now()})
            return
        while pending and len(active)<args.workers and psutil.virtual_memory().available>5*2**30:
            index=pending.pop(0)
            path=run/"logs"/(jobs[index]["id"]+".log")
            with path.open("a") as log:
                process=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),"worker","--manifest",str(args.manifest),"--index",str(index)],
                    cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            p=psutil.Process(process.pid);p.cpu_percent()
            active[index]={"process":p,"popen":process,"started":time.time()}
        live=[]
        for index,item in active.items():
            try:
                p=item["process"]
                progress=run/"progress"/(jobs[index]["id"]+".json")
                rec=read(progress) if progress.exists() else {}
                live.append({"index":index,"job_id":jobs[index]["id"],"pid":p.pid,"cpu_percent":p.cpu_percent(),
                    "rss_gib":p.memory_info().rss/2**30,"phase":rec.get("phase","starting"),"epochs_completed":rec.get("epochs_completed")})
            except psutil.Error:pass
        write(run/"controller_status.json",{"status":"running","updated_utc":now(),"pending":len(pending),"active":live,
            "workers":args.workers,"available_memory_gib":psutil.virtual_memory().available/2**30,
            "worker_cpu_percent":sum(x["cpu_percent"] for x in live)})
        if time.time()-last_report>30:
            summarize(args);last_report=time.time()
        time.sleep(2)
    output=summarize(args)
    write(run/"controller_status.json",{"status":"finished","updated_utc":now(),"counts":output["status"],"paired_runs":output["paired_runs"]})
    write(run/"FINISHED.json",{"finished_utc":now(),"counts":output["status"],"paired_runs":output["paired_runs"]})


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("action",choices=("build","worker","controller","summarize"))
    p.add_argument("--manifest",type=Path,default=RUN/"manifest.json")
    p.add_argument("--workers",type=int,default=14)
    p.add_argument("--index",type=int)
    p.add_argument("--smoke",action="store_true")
    args=p.parse_args()
    {"build":build,"worker":worker,"controller":controller,"summarize":summarize}[args.action](args)


if __name__=="__main__":
    main()
