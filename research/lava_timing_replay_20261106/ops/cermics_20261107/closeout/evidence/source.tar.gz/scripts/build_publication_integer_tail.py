"""Build a correctness-preserving accelerated tail of integer development."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json
from proximal_spo.publication_selection import build_integer_accelerated_tail


def _object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object at {path}")
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-root", required=True)
    parser.add_argument("--start-index", type=int, required=True)
    parser.add_argument("--workers", type=int, default=4)
    arguments = parser.parse_args()
    campaign = build_integer_accelerated_tail(
        _object(arguments.source),
        start_index=arguments.start_index,
        run_root=arguments.run_root,
        workers=arguments.workers,
    )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.output, campaign)
    print(
        f"wrote {len(campaign['variants'])} accelerated integer tail runs to "
        f"{arguments.output}"
    )


if __name__ == "__main__":
    main()
