"""Summarize frozen paired test-confirmation campaigns."""

from __future__ import annotations

import argparse
from pathlib import Path

from proximal_spo.artifacts import write_json
from proximal_spo.confirmation_analysis import (
    render_confirmation_markdown,
    summarize_confirmation,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", action="append", type=Path, required=True)
    parser.add_argument("--manifest", action="append", type=Path, required=True)
    parser.add_argument("--allowed-replaced-variants", type=int, default=0)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    parser.add_argument("--target-method", default="soft_radial_log_barrier")
    parser.add_argument("--required-seeds", type=int, default=10)
    parser.add_argument(
        "--evidence-note",
        action="append",
        default=[],
        help="Additional panel-specific evidence boundary (repeatable).",
    )
    arguments = parser.parse_args()
    summary = summarize_confirmation(
        arguments.run_root,
        target_method=arguments.target_method,
        required_seed_count=arguments.required_seeds,
        manifest_paths=arguments.manifest,
        allowed_replaced_variant_count=arguments.allowed_replaced_variants,
    )
    summary["additional_evidence_notes"] = list(arguments.evidence_note)
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, summary)
    arguments.markdown_output.write_text(
        render_confirmation_markdown(summary), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
