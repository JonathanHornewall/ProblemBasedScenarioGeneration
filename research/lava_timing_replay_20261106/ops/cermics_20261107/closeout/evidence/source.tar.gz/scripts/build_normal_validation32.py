"""Freeze the paper's ordinary-validation correction without reading test scores."""
import argparse
import copy
import hashlib
from pathlib import Path

from build_central_path_final import read, sha, write

REVISION = "observed_validation32_20260925_v1"
METHODS = ("central_path_hard_validation", "mse", "spo_plus", "wise", "pfyl", "nce", "lava")
ROUTES = tuple(f"dys_shortest_path_{n}x{n}" for n in (10, 15, 20, 25)) + (
    "dys_cfl_50x5", "dys_cfl_100x10", "dys_cfl_200x10", "dys_cfl_250x10",
    "lava_random_lp_50x50_released_code", "lava_random_lp_150x50_paper_appendix",
    "lava_random_lp_200x50_released_code", "lava_random_lp_400x50_released_code",
) + tuple(f"dys_knapsack_{n}x2" for n in (50, 100, 200, 500))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build(archive, destination):
    if (destination / "screen.json").exists():
        raise RuntimeError("Refusing to overwrite the correction manifest")
    original = read(archive / "additional_screen.json")
    timings = read(archive / "cluster_timing_sampled/manifest.json")
    available = {(x["cell"], x["job"]["method"]) for x in timings["entries"]}
    retained = {f"{route}__train100" for route in ROUTES}
    jobs, cells, reused, unavailable = [], {}, [], []
    selected_sources = {}
    for cell in sorted(retained):
        source_cell = cell + "__validation_sampled"
        candidates = [j for j in original["jobs"] if j["cell"] == source_cell and j["method"] in METHODS]
        sizes = {j["config"]["sizes"]["validation"] for j in candidates}
        if len(sizes) != 1:
            raise ValueError("Original methods have different validation sizes")
        size = sizes.pop()
        for method in METHODS:
            if (cell, method) not in available:
                if method != "lava":
                    raise ValueError("Unexpected missing baseline")
                unavailable.append({"cell": cell, "method": method, "reason": "original geometry unavailable, independent of validation size"})
            elif size == 32:
                source = next(e for e in timings["entries"] if (e["cell"], e["job"]["method"]) == (cell, method))
                reused.append({"cell": cell, "method": method, "source_job": source["source_job"],
                               "source_receipt_sha256": source["source_receipt_sha256"]})
        if size == 32:
            continue
        corrected_cell = cell + "__validation32"
        info = copy.deepcopy(original["cells"][source_cell])
        info.update(validation_size=32, original_validation_size=size, source_cell=source_cell)
        cells[corrected_cell] = info
        for source in candidates:
            if (cell, source["method"]) not in available:
                continue
            j = copy.deepcopy(source)
            j.update(cell=corrected_cell, comparison_cell=cell, source_validation_job=source["id"],
                     normal_validation_revision=REVISION, validation_experiment=REVISION,
                     validation_costs="single_sample", analytic_validation=False)
            j.pop("paired_exact_candidate", None)
            j["config"]["sizes"]["validation"] = 32
            j["config"]["evaluate_test"] = False
            j["config"].pop("name", None)
            candidate = sha({"source_candidate": source["candidate"], "revision": REVISION,
                             "config": j["config"], "parameters": j["parameters"], "method": j["method"]})[:16]
            j.update(candidate=candidate, id=f"screen__{corrected_cell}__{j['method']}__{candidate}")
            j["config"]["name"] = j["id"]
            prior = archive / "cluster_retrieved/results/receipts" / (source["id"] + ".json")
            if prior.exists():
                receipt = read(prior)
                j["historical_screen_wall_seconds"] = receipt.get("total_wall_seconds", receipt.get("elapsed_seconds", 0.0))
            jobs.append(j)
            selected_sources[j["id"]] = source["id"]
    assert len(cells) == 11 and len(reused) == 34 and len(unavailable) == 5
    groups = sorted({(j["cell"], j["method"]) for j in jobs})
    assert len(groups) == 73 and len(jobs) == 1350
    jobs.sort(key=lambda j: (-j.get("historical_screen_wall_seconds", 0.0), j["cell"], j["method"], j["candidate"]))
    base_protocol = read(archive / "screen.json")["protocol"]
    protocol = {**base_protocol, "method_waves": [list(METHODS)],
        "validation": "32 fixed context-observed-cost pairs per data seed; never conditional means",
        "refinement": "original top-three rule and original three seed bundles",
        "confirmation": "original ten seed bundles and newly validation-selected fixed horizon",
        "held_out_training_test_arrays_preserved": True,
        "validation_resize": "first 32 archived pairs for 200; regenerate only the validation split at 32 using the original seed for 24",
        "final_timing": "all 107 available paper selections, repeat0, optimizer-only on node09; fresh preparation reported separately",
        "hard_selection": "observed-cost validation regret, including mu and horizon selection",
        "barrier_selection": "not included", "cloud_combined_ceiling_usd": None,
        "cloud_maximum_lifetime_hours": 6}
    result = {"schema": REVISION, "jobs": jobs, "cells": cells, "methods": list(METHODS),
        "cell_methods": {c: sorted({j['method'] for j in jobs if j['cell'] == c}) for c in cells},
        "protocol": protocol,
        "source_sha256": {str(archive / "additional_screen.json"): digest(archive / "additional_screen.json"),
                          str(archive / "cluster_timing_sampled/manifest.json"): digest(archive / "cluster_timing_sampled/manifest.json")}}
    write(destination / "screen.json", result)
    write(destination / "paper_scope.json", {"revision": REVISION, "cells": sorted(retained),
        "methods": list(METHODS), "training_size": 100, "validation_size": 32,
        "changed_groups": [list(g) for g in groups], "reused_groups": reused,
        "unavailable_groups": unavailable, "source_jobs": selected_sources,
        "selection_uses_test": False, "original_seeds_preserved": True})
    write(destination / "burst_contract.json", {"run_id": destination.name, "groups": groups,
        "maximum_workers": 100, "maximum_cloud_workers": {"hornewall": 64, "tito": 12},
        "maximum_seconds": 14300, "finite_allocation_seconds": 14400})
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--archive", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    result = build(a.archive.resolve(), a.output.resolve())
    print({"jobs": len(result["jobs"]), "cells": len(result["cells"])})
