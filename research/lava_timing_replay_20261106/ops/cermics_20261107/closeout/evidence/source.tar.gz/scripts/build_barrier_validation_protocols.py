"""Build the corrected barrier-validation protocol campaign.

The previous broad screens are used only as validation-only proposal data.
Every selected candidate is retrained under hard-deployment checkpointing and
fixed-temperature continuation on the current source.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from build_feasible_policy_campaigns import DEVELOPMENT_SEEDS

from proximal_spo.artifacts import source_sha256, write_json
from proximal_spo.config import RunSpec

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPO_ROOT / "configs" / "barrier_validation"
RESULT_ROOT = REPO_ROOT / "results" / "barrier_validation"
RUN_ROOT = REPO_ROOT / "runs"
PILOT_BENCHMARKS = frozenset({"cost.grid5", "cost.assignment10"})
MAXIMUM_ARMS_PER_METHOD_BENCHMARK = 24
FIXED_ALPHA_REPRESENTATIVES = (0.0, 0.001, 0.01, 0.1, 1.0, 3.0, 10.0, 30.0, 100.0)
PROTOCOL_PARAMETERS: dict[str, object] = {
    "validation_protocol_suite": True,
    "continuation_epochs": 60,
    "continuation_extension_epochs": 60,
    "continuation_late_window": 10,
    "continuation_minimum_delta": 1e-6,
}
LONG_HOLD_PARAMETERS: dict[str, object] = {
    "validation_protocol_suite": True,
    "continuation_epochs": 300,
    "continuation_extension_epochs": 180,
    "continuation_late_window": 20,
    "continuation_minimum_delta": 1e-6,
}


@dataclass(frozen=True)
class ProposalRecord:
    config: dict[str, Any]
    validation_soft: float
    validation_hard: float
    seed: int
    run_directory: str
    source_sha256: str
    priority: int


@dataclass(frozen=True)
class CandidateArm:
    key: str
    config: dict[str, Any]
    validation_soft: float
    validation_hard: float
    proposal_seed_count: int
    proposal_runs: tuple[str, ...]
    reasons: tuple[str, ...] = ()


def _canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def _digest(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value)).hexdigest()


def _status_complete(directory: Path) -> bool:
    path = directory / "status.json"
    if not path.is_file():
        return False
    try:
        payload = json.loads(path.read_text())
        return isinstance(payload, dict) and payload.get("status") == "complete"
    except (OSError, json.JSONDecodeError):
        return False


def _proposal_sources() -> tuple[tuple[Path, int], ...]:
    return (
        (RUN_ROOT / "log_energy_barrier" / "development_screen", 1),
        (RUN_ROOT / "log_energy_barrier" / "hard_boundary", 2),
        (RUN_ROOT / "log_energy_barrier" / "deployment_repair_v3", 3),
        (RUN_ROOT / "soft_radial_log_barrier" / "development_screen", 1),
        (RUN_ROOT / "soft_radial_log_barrier" / "hard_boundary", 2),
    )


def _protocol_config(raw: dict[str, Any]) -> dict[str, Any] | None:
    method = raw.get("method")
    if method not in {"log_energy_policy", "soft_radial_log_barrier"}:
        return None
    result = copy.deepcopy(raw)
    result["name"] = "candidate"
    result["workers"] = 2
    result["training"]["selection_mode"] = "last"
    result["training"]["patience"] = 1_000
    result["training"]["validation_interval"] = 5
    result["training"]["torch_threads"] = 2
    parameters = result["method_parameters"]
    if method == "log_energy_policy":
        if parameters.get("energy_guard") == "legacy_capped":
            return None
        # Exact arms are useful proposals, but the main protocol trains the
        # coercive uncapped objective.  Exact replay happens after selection.
        parameters["energy_guard"] = "uncapped"
        parameters.setdefault("training_root_tolerance", 1e-6)
        parameters.setdefault("evaluation_root_tolerance", 1e-8)
        parameters.setdefault("matrix_backend", "auto")
        parameters.setdefault("kernel_backend", "numpy")
        parameters.setdefault("torch_device", "auto")
    parameters.update(PROTOCOL_PARAMETERS)
    return result


def _arm_payload(config: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(config)
    result.pop("name", None)
    result.pop("seeds", None)
    return result


def _collect_proposals() -> list[ProposalRecord]:
    by_arm_seed: dict[tuple[str, int], ProposalRecord] = {}
    for root, priority in _proposal_sources():
        if not root.is_dir():
            continue
        for directory in sorted(root.iterdir()):
            if not directory.is_dir() or not _status_complete(directory):
                continue
            config_path = directory / "config.json"
            deployment_path = directory / "deployment_ablation.json"
            environment_path = directory / "environment.json"
            if not (
                config_path.is_file()
                and deployment_path.is_file()
                and environment_path.is_file()
            ):
                continue
            try:
                raw_config = json.loads(config_path.read_text())
                deployment = json.loads(deployment_path.read_text())
                environment = json.loads(environment_path.read_text())
                config = _protocol_config(raw_config)
                if config is None:
                    continue
                validation_soft = float(
                    deployment["deployments"]["soft"]["validation"]["mean_regret"]
                )
                validation_hard = float(
                    deployment["deployments"]["hard_recovered"]["validation"]
                    ["mean_regret"]
                )
                seed = int(raw_config["seeds"]["data"])
            except (KeyError, TypeError, ValueError, json.JSONDecodeError):
                continue
            arm_key = _digest(_arm_payload(config))
            record = ProposalRecord(
                config=config,
                validation_soft=validation_soft,
                validation_hard=validation_hard,
                seed=seed,
                run_directory=str(directory.relative_to(REPO_ROOT)),
                source_sha256=str(environment.get("source_sha256", "unknown")),
                priority=priority,
            )
            key = (arm_key, seed)
            previous = by_arm_seed.get(key)
            if previous is None or (record.priority, record.run_directory) > (
                previous.priority,
                previous.run_directory,
            ):
                by_arm_seed[key] = record
    return list(by_arm_seed.values())


def _aggregate(proposals: list[ProposalRecord]) -> list[CandidateArm]:
    grouped: dict[str, list[ProposalRecord]] = {}
    for record in proposals:
        grouped.setdefault(_digest(_arm_payload(record.config)), []).append(record)
    result: list[CandidateArm] = []
    for key, rows in grouped.items():
        rows.sort(key=lambda row: row.seed)
        result.append(
            CandidateArm(
                key=key,
                config=copy.deepcopy(rows[0].config),
                validation_soft=sum(row.validation_soft for row in rows) / len(rows),
                validation_hard=sum(row.validation_hard for row in rows) / len(rows),
                proposal_seed_count=len({row.seed for row in rows}),
                proposal_runs=tuple(row.run_directory for row in rows),
            )
        )
    return result


def _schedule(arm: CandidateArm) -> str:
    return str(arm.config["method_parameters"].get("schedule", "fixed"))


def _fixed_alpha(arm: CandidateArm) -> float | None:
    parameters = arm.config["method_parameters"]
    if _schedule(arm) != "fixed" or "alpha_start" not in parameters:
        return None
    return float(parameters["alpha_start"])


def _select_group(rows: list[CandidateArm]) -> list[CandidateArm]:
    reasons: dict[str, set[str]] = {}

    def add(arm: CandidateArm, reason: str) -> None:
        reasons.setdefault(arm.key, set()).add(reason)

    hard = sorted(rows, key=lambda arm: (arm.validation_hard, arm.key))
    soft = sorted(rows, key=lambda arm: (arm.validation_soft, arm.key))
    for arm in hard[:8]:
        add(arm, "top8_previous_hard_validation")
    for arm in soft[:5]:
        add(arm, "top5_previous_soft_validation")
    for schedule in ("fixed", "geometric", "arithmetic"):
        scheduled = [arm for arm in rows if _schedule(arm) == schedule]
        if scheduled:
            add(
                min(scheduled, key=lambda arm: (arm.validation_hard, arm.key)),
                f"best_{schedule}_previous_hard_validation",
            )
            add(
                min(scheduled, key=lambda arm: (arm.validation_soft, arm.key)),
                f"best_{schedule}_previous_soft_validation",
            )
    for alpha in FIXED_ALPHA_REPRESENTATIVES:
        matching = [
            arm
            for arm in rows
            if _fixed_alpha(arm) is not None
            and abs(float(_fixed_alpha(arm)) - alpha) <= 1e-15
        ]
        if matching:
            add(
                min(matching, key=lambda arm: (arm.validation_hard, arm.key)),
                f"fixed_alpha_{alpha:g}_coverage",
            )
    hard_rank = {arm.key: rank for rank, arm in enumerate(hard)}
    soft_rank = {arm.key: rank for rank, arm in enumerate(soft)}
    selected = [arm for arm in rows if arm.key in reasons]
    selected.sort(
        key=lambda arm: (
            min(hard_rank[arm.key], soft_rank[arm.key]),
            hard_rank[arm.key] + soft_rank[arm.key],
            arm.key,
        )
    )
    selected = selected[:MAXIMUM_ARMS_PER_METHOD_BENCHMARK]
    return [
        CandidateArm(
            key=arm.key,
            config=arm.config,
            validation_soft=arm.validation_soft,
            validation_hard=arm.validation_hard,
            proposal_seed_count=arm.proposal_seed_count,
            proposal_runs=arm.proposal_runs,
            reasons=tuple(sorted(reasons[arm.key])),
        )
        for arm in selected
    ]


def _candidate_pool() -> list[CandidateArm]:
    proposals = _collect_proposals()
    if not proposals:
        raise ValueError("no completed barrier proposal runs were found")
    grouped: dict[tuple[str, str], list[CandidateArm]] = {}
    for arm in _aggregate(proposals):
        grouped.setdefault(
            (str(arm.config["benchmark_id"]), str(arm.config["method"])), []
        ).append(arm)
    expected = {
        (benchmark, method)
        for benchmark in {
            "cost.assignment10",
            "cost.facility30x5_relaxation",
            "cost.grid5",
            "cost.knapsack50x5",
            "cost.random_lp100x50",
            "cost.topk20x5",
        }
        for method in {"log_energy_policy", "soft_radial_log_barrier"}
    }
    if set(grouped) != expected:
        missing = sorted(expected - set(grouped))
        raise ValueError(f"proposal coverage mismatch: {missing}")
    selected: list[CandidateArm] = []
    for key in sorted(grouped):
        selected.extend(_select_group(grouped[key]))
    return selected


def _seed_payload(seed: int) -> dict[str, int]:
    return {
        "data": seed,
        "structural": 101,
        "initialization": 200 + seed,
        "shuffle": 300 + seed,
        "perturbation": 400 + seed,
    }


def _variants(
    pool: list[CandidateArm],
    *,
    seeds: tuple[int, ...],
    benchmarks: frozenset[str] | None = None,
    smoke: bool = False,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for arm in pool:
        if benchmarks is not None and arm.config["benchmark_id"] not in benchmarks:
            continue
        for seed in seeds:
            row = copy.deepcopy(arm.config)
            method_tag = (
                "logenergy"
                if row["method"] == "log_energy_policy"
                else "softbar"
            )
            benchmark_tag = str(row["benchmark_id"]).replace("cost.", "").replace(
                "_relaxation", ""
            )
            row["name"] = (
                f"{benchmark_tag}_s{seed}_{method_tag}_protocol_{arm.key[:10]}"
            )
            row["seeds"] = _seed_payload(seed)
            if smoke:
                row["name"] += "_smoke"
                row["sizes"] = {"train": 64, "validation": 32, "test": 32}
                row["model"].update({"width": 16, "depth": 1})
                row["training"].update(
                    {
                        "epochs": 3,
                        "batch_size": 32,
                        "validation_interval": 1,
                        "evaluation_batch_size": 64,
                        "torch_threads": 1,
                    }
                )
                row["method_parameters"].update(
                    {
                        "continuation_epochs": 2,
                        "continuation_extension_epochs": 2,
                        "continuation_late_window": 1,
                    }
                )
                row["workers"] = 1
            RunSpec.from_dict(row)
            rows.append(row)
    return rows


def _long_hold_variants(*, exact: bool = False) -> tuple[list[dict[str, Any]], str]:
    summary_path = RESULT_ROOT / "development.json"
    if not summary_path.is_file():
        raise ValueError("development protocol summary is required for long hold")
    summary = json.loads(summary_path.read_text())
    winners = [
        row
        for row in summary.get("selected", [])
        if row.get("method") == "log_energy_policy"
        and row.get("protocol") == "winner_only_hold"
        and row.get("validation_selector") == "hard_recovered"
    ]
    expected_benchmarks = {
        "cost.assignment10",
        "cost.facility30x5_relaxation",
        "cost.grid5",
        "cost.knapsack50x5",
        "cost.random_lp100x50",
        "cost.topk20x5",
    }
    observed_benchmarks = {str(row["benchmark_id"]) for row in winners}
    if observed_benchmarks != expected_benchmarks or len(winners) != len(
        expected_benchmarks
    ):
        raise ValueError("development summary has incomplete long-hold winners")
    variants: list[dict[str, Any]] = []
    winner_receipt: list[dict[str, Any]] = []
    for winner in sorted(winners, key=lambda row: str(row["benchmark_id"])):
        arm = copy.deepcopy(winner["arm"])
        arm["method_parameters"].update(LONG_HOLD_PARAMETERS)
        if exact:
            arm["method_parameters"]["energy_guard"] = "exact"
        arm["workers"] = 2
        arm["training"]["torch_threads"] = 2
        arm["training"]["selection_mode"] = "last"
        arm["training"]["patience"] = 1_000
        arm["training"]["validation_interval"] = 5
        benchmark_tag = str(arm["benchmark_id"]).replace("cost.", "").replace(
            "_relaxation", ""
        )
        for seed in DEVELOPMENT_SEEDS:
            row = copy.deepcopy(arm)
            guard_tag = "exact_" if exact else ""
            row["name"] = (
                f"{benchmark_tag}_s{seed}_logenergy_{guard_tag}long_hold"
            )
            row["seeds"] = _seed_payload(seed)
            RunSpec.from_dict(row)
            variants.append(row)
        winner_receipt.append(
            {
                "benchmark_id": winner["benchmark_id"],
                "source_arm_sha256": winner["arm_sha256"],
                "development_run_directories": winner["run_directories"],
                "arm": _arm_payload(arm),
            }
        )
    receipt = {
        "status": (
            "selected_log_energy_exact_long_hold_audit"
            if exact
            else "selected_log_energy_long_hold_audit"
        ),
        "source_summary": str(summary_path.relative_to(REPO_ROOT)),
        "source_summary_sha256": _digest(summary),
        "development_source_sha256": summary["source_sha256"],
        "test_metrics_used_for_selection": False,
        "continuation_parameters": LONG_HOLD_PARAMETERS,
        "energy_guard": "exact" if exact else "uncapped",
        "winners": winner_receipt,
    }
    digest = _digest(receipt)
    receipt["selected_winners_sha256"] = digest
    pool_name = "exact_long_hold_pool.json" if exact else "long_hold_pool.json"
    write_json(RESULT_ROOT / pool_name, receipt)
    return variants, digest


def _write_campaign(
    path: Path,
    *,
    name: str,
    run_root: str,
    variants: list[dict[str, Any]],
    pool_digest: str,
) -> None:
    if not variants:
        raise ValueError("campaign cannot be empty")
    write_json(
        path,
        {
            "name": name,
            "run_root": run_root,
            # Variants are deliberately self-contained because the two maps
            # have disjoint method-parameter schemas.  A populated template
            # would deep-merge log-energy-only fields into Soft-Radial arms.
            "base": {},
            "variants": variants,
            "source_sha256_at_generation": source_sha256(REPO_ROOT),
            "candidate_pool_sha256": pool_digest,
            "selection_contract": (
                "every checkpoint uses hard-recovered validation regret; soft "
                "validation can rank arms only at the hard-selected state"
            ),
        },
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "stage",
        choices=(
            "smoke",
            "pilot",
            "development",
            "long_hold",
            "exact_long_hold",
        ),
    )
    arguments = parser.parse_args()
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    if arguments.stage in {"long_hold", "exact_long_hold"}:
        exact = arguments.stage == "exact_long_hold"
        variants, winner_digest = _long_hold_variants(exact=exact)
        filename = "exact_long_hold.json" if exact else "long_hold.json"
        run_root = (
            "runs/barrier_validation/exact_long_hold"
            if exact
            else "runs/barrier_validation/long_hold"
        )
        _write_campaign(
            CONFIG_ROOT / filename,
            name=(
                "barrier_validation_log_energy_exact_long_hold"
                if exact
                else "barrier_validation_log_energy_long_hold"
            ),
            run_root=run_root,
            variants=variants,
            pool_digest=winner_digest,
        )
        return 0
    pool = _candidate_pool()
    pool_receipt = {
        "status": "validation_only_proposal_pool",
        "arm_count": len(pool),
        "maximum_arms_per_method_benchmark": MAXIMUM_ARMS_PER_METHOD_BENCHMARK,
        "source_sha256_at_generation": source_sha256(REPO_ROOT),
        "test_metrics_used_for_proposals": False,
        "arms": [
            {
                "arm_sha256": arm.key,
                "benchmark_id": arm.config["benchmark_id"],
                "method": arm.config["method"],
                "previous_validation_soft": arm.validation_soft,
                "previous_validation_hard_recovered": arm.validation_hard,
                "proposal_seed_count": arm.proposal_seed_count,
                "proposal_runs": arm.proposal_runs,
                "selection_reasons": arm.reasons,
                "arm": _arm_payload(arm.config),
            }
            for arm in pool
        ],
    }
    pool_digest = _digest(pool_receipt)
    pool_receipt["candidate_pool_sha256"] = pool_digest
    write_json(RESULT_ROOT / "candidate_pool.json", pool_receipt)
    if arguments.stage == "smoke":
        # One arm per map on two geometrically distinct problems.
        subset: list[CandidateArm] = []
        for benchmark in sorted(PILOT_BENCHMARKS):
            for method in ("log_energy_policy", "soft_radial_log_barrier"):
                subset.append(
                    next(
                        arm
                        for arm in pool
                        if arm.config["benchmark_id"] == benchmark
                        and arm.config["method"] == method
                    )
                )
        variants = _variants(
            subset,
            seeds=(DEVELOPMENT_SEEDS[0],),
            smoke=True,
        )
        _write_campaign(
            CONFIG_ROOT / "smoke.json",
            name="barrier_validation_protocol_smoke",
            run_root="runs/barrier_validation/smoke",
            variants=variants,
            pool_digest=pool_digest,
        )
    elif arguments.stage == "pilot":
        variants = _variants(
            pool,
            seeds=(DEVELOPMENT_SEEDS[0],),
            benchmarks=PILOT_BENCHMARKS,
        )
        _write_campaign(
            CONFIG_ROOT / "pilot.json",
            name="barrier_validation_protocol_pilot",
            run_root="runs/barrier_validation/pilot",
            variants=variants,
            pool_digest=pool_digest,
        )
    else:
        variants = _variants(pool, seeds=DEVELOPMENT_SEEDS)
        _write_campaign(
            CONFIG_ROOT / "development.json",
            name="barrier_validation_protocol_development",
            run_root="runs/barrier_validation/development",
            variants=variants,
            pool_digest=pool_digest,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
