"""Build the matched log-energy versus Soft-Radial barrier campaign.

The schedule, hold period, learning-rate grid, data, and neural architecture
match ``build_soft_radial_barrier_campaigns.py``.  The primary screen gives the
exact fail-fast and uncapped-guarded charts identical tuning budgets.  The old
capped-energy objective is generated only as a diagnostic stage.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

from build_feasible_policy_campaigns import DESIGNS, DEVELOPMENT_SEEDS, _base
from build_soft_radial_barrier_campaigns import (
    EFFECTIVE_LEARNING_RATES,
    FIXED_ALPHAS,
    HARD_BOUNDARY_ALPHAS,
    HOMOTOPY_ENDS,
    HOMOTOPY_STARTS,
)

from proximal_spo.artifacts import source_sha256, write_json
from proximal_spo.config import RunSpec

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPO_ROOT / "configs" / "log_energy_barrier"
PRIMARY_GUARDS = ("exact", "uncapped")
LEGACY_DIAGNOSTIC_RATE = 3e-5
ANNEAL_FRACTION = 0.75


def _tag(value: float) -> str:
    if value == 0.0:
        return "0"
    return f"{value:.0e}".replace("-", "m").replace("+", "p")


def _schedule_rows() -> list[tuple[str, float, float]]:
    rows = [("fixed", alpha, alpha) for alpha in FIXED_ALPHAS]
    for start in HOMOTOPY_STARTS:
        for end in HOMOTOPY_ENDS:
            if start / end < 10.0:
                continue
            rows.append(("geometric", start, end))
            rows.append(("arithmetic", start, end))
    if len(rows) != 54:
        raise AssertionError("unexpected log-energy schedule count")
    return rows


def _variant(
    *,
    design: Any,
    seed: int,
    schedule: str,
    alpha_start: float,
    alpha_end: float,
    learning_rate: float,
    energy_guard: str,
) -> dict[str, Any]:
    row = _base(design, seed)
    row["name"] = (
        f"{design.tag}_s{seed}_logenergy_{energy_guard}_{schedule}_"
        f"a{_tag(alpha_start)}to{_tag(alpha_end)}_"
        f"lr{_tag(learning_rate)}"
    )
    row["method"] = "log_energy_policy"
    row["training"]["learning_rate"] = learning_rate
    row["training"]["weight_decay"] = 0.0
    row["method_parameters"] = {
        "alpha_start": alpha_start,
        "alpha_end": alpha_end,
        "schedule": schedule,
        "anneal_fraction": ANNEAL_FRACTION,
        "energy_guard": energy_guard,
    }
    return row


def _screen_variants() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for design in DESIGNS:
        for seed in DEVELOPMENT_SEEDS:
            for energy_guard in PRIMARY_GUARDS:
                for schedule, alpha_start, alpha_end in _schedule_rows():
                    for learning_rate in EFFECTIVE_LEARNING_RATES:
                        rows.append(
                            _variant(
                                design=design,
                                seed=seed,
                                schedule=schedule,
                                alpha_start=alpha_start,
                                alpha_end=alpha_end,
                                learning_rate=learning_rate,
                                energy_guard=energy_guard,
                            )
                        )
    if len(rows) != 9_720:
        raise AssertionError("unexpected log-energy primary screen size")
    return rows


def _legacy_variants() -> list[dict[str, Any]]:
    rows = [
        _variant(
            design=design,
            seed=seed,
            schedule=schedule,
            alpha_start=alpha_start,
            alpha_end=alpha_end,
            learning_rate=LEGACY_DIAGNOSTIC_RATE,
            energy_guard="legacy_capped",
        )
        for design in DESIGNS
        for seed in DEVELOPMENT_SEEDS
        for schedule, alpha_start, alpha_end in _schedule_rows()
    ]
    if len(rows) != 972:
        raise AssertionError("unexpected legacy diagnostic size")
    return rows


def _hard_boundary_variants() -> list[dict[str, Any]]:
    """Match the Soft-Radial fixed-alpha hard-deployment expansion."""

    rows = [
        _variant(
            design=design,
            seed=seed,
            schedule="fixed",
            alpha_start=alpha,
            alpha_end=alpha,
            learning_rate=barrier_step / alpha,
            energy_guard=energy_guard,
        )
        for design in DESIGNS
        for seed in DEVELOPMENT_SEEDS
        for energy_guard in PRIMARY_GUARDS
        for alpha in HARD_BOUNDARY_ALPHAS
        for barrier_step in EFFECTIVE_LEARNING_RATES
    ]
    if len(rows) != 900:
        raise AssertionError("unexpected log-energy hard-boundary size")
    return rows


def _smoke_variants() -> list[dict[str, Any]]:
    schedules = (
        ("fixed", 0.03, 0.03),
        ("geometric", 0.3, 0.003),
        ("arithmetic", 0.3, 0.003),
    )
    rows: list[dict[str, Any]] = []
    for design in DESIGNS:
        for energy_guard in (*PRIMARY_GUARDS, "legacy_capped"):
            for schedule, start, end in schedules:
                row = _variant(
                    design=design,
                    seed=DEVELOPMENT_SEEDS[0],
                    schedule=schedule,
                    alpha_start=start,
                    alpha_end=end,
                    learning_rate=3e-5,
                    energy_guard=energy_guard,
                )
                row["name"] = f"{row['name']}_smoke"
                row["workers"] = 1
                row["sizes"] = {"train": 64, "validation": 32, "test": 32}
                row["model"].update({"width": 16, "depth": 1})
                row["training"].update(
                    {
                        "epochs": 2,
                        "batch_size": 32,
                        "validation_interval": 1,
                        "patience": 2,
                        "torch_threads": 1,
                    }
                )
                rows.append(row)
    if len(rows) != 54:
        raise AssertionError("unexpected log-energy smoke size")
    return rows


def _write(
    path: Path,
    *,
    name: str,
    run_root: str,
    rows: list[dict[str, Any]],
) -> None:
    for row in rows:
        RunSpec.from_dict(row)
    write_json(
        path,
        {
            "name": name,
            "run_root": run_root,
            "base": _base(DESIGNS[0], DEVELOPMENT_SEEDS[0]),
            "variants": rows,
            "source_sha256_at_generation": source_sha256(REPO_ROOT),
            "comparison_contract": (
                "same alpha schedules, 0.75 anneal fraction, learning-rate grid, "
                "data, architecture, and training budget as Soft-Radial barrier"
            ),
            "guard_protocol": (
                "exact and uncapped receive full paired screens; legacy capped "
                "is diagnostic only"
            ),
        },
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "stage", choices=("smoke", "screen", "legacy", "hard_boundary")
    )
    arguments = parser.parse_args()
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    if arguments.stage == "smoke":
        _write(
            CONFIG_ROOT / "smoke.json",
            name="log_energy_barrier_smoke",
            run_root="runs/log_energy_barrier/smoke",
            rows=_smoke_variants(),
        )
    elif arguments.stage == "screen":
        _write(
            CONFIG_ROOT / "development_screen.json",
            name="log_energy_barrier_development_screen",
            run_root="runs/log_energy_barrier/development_screen",
            rows=_screen_variants(),
        )
    elif arguments.stage == "legacy":
        _write(
            CONFIG_ROOT / "legacy_diagnostic.json",
            name="log_energy_barrier_legacy_diagnostic",
            run_root="runs/log_energy_barrier/legacy_diagnostic",
            rows=_legacy_variants(),
        )
    else:
        _write(
            CONFIG_ROOT / "hard_boundary.json",
            name="log_energy_barrier_hard_boundary",
            run_root="runs/log_energy_barrier/hard_boundary",
            rows=_hard_boundary_variants(),
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
