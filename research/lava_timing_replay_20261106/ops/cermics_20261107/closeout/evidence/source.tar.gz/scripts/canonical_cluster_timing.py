#!/usr/bin/env python3
"""Frozen repeat-0 training replays on eight shared, matched CERMICS cores.

This queue has no selector and cannot dispatch scientific campaign work. It
uses a separate code snapshot, output directory, singleton lock and receipts.
"""
from __future__ import annotations

import argparse
import collections
import contextlib
import copy
import fcntl
import hashlib
import json
import os
import platform
import shutil
import signal
import subprocess
import sys
import time
import traceback
from pathlib import Path

from build_central_path_final import read, write
from canonical_resource_guard import limit_reason
from frozen_campaign_data import data_key

ROOT = Path(__file__).resolve().parents[1]
METHODS = ("mse", "wise", "spo_plus", "central_path_hard_validation",
           "central_path_barrier_validation", "pfyl", "nce", "lava")
PROTOCOL = "single_repeat_parallel_shared_cpu_20260924"


def timing_output(run, validation_arm="mean"):
    if validation_arm not in ("mean", "sampled"):
        raise ValueError("Unknown timing selection arm")
    return run / ("cluster_timing" if validation_arm == "mean" else "cluster_timing_sampled")


def verify_manifest_arm(manifest, validation_arm):
    if manifest.get("validation_arm", "mean") != validation_arm:
        raise RuntimeError("Timing manifest belongs to a different validation arm")
    for entry in manifest["entries"]:
        sampled = entry["source_job"].get("validation_costs") == "single_sample"
        if sampled != (validation_arm == "sampled"):
            raise RuntimeError("Timing source belongs to a different validation arm")


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_ready(run):
    """Only locally retrieved terminal results may authorize a timing manifest."""
    target = read(run / "timing_target.json")
    if (target["target"] != "cermics" or target["matched_repeats"] != 1
        or target["maximum_concurrent_fits"] != 8
        or target["maximum_allocated_cpus"] != 8):
        raise RuntimeError("Timing protocol does not authorize this queue")
    if read(run / "spo_memory_repair.json")["status"] != "complete":
        raise RuntimeError("SPO repair selections and confirmations remain unfinished")
    retrieved = run / "cluster_retrieved"
    confirmation = read(retrieved / "confirmation.json")
    pipeline = confirmation["pipeline"]
    if pipeline["expected_groups"] != 464 or not pipeline["selection_complete"]:
        raise RuntimeError("All 464 selection groups must be terminal before timing")
    for job in confirmation["jobs"]:
        path = retrieved / "results/receipts" / (job["id"] + ".json")
        if not path.exists() or read(path)["status"] not in ("complete", "censored", "failed"):
            raise RuntimeError("Confirmation not retrieved and terminal: " + job["id"])
    audit = read(run / "monitor_latest.json")
    if (audit["preserved_files_changed"] or audit["sampled_hash_issues"]
        or sum(audit["all_group_states"].get(k, 0) for k in ("selecting", "confirming"))):
        raise RuntimeError("Campaign integrity/readiness audit is not complete")
    return confirmation


def timing_job(original, validation_arm="mean"):
    timing_output(Path("."), validation_arm)
    if (original["method"] not in METHODS or original.get("repeat") != 0
        or original["stage"] != "confirmation"
        or (original.get("validation_costs") == "single_sample") != (validation_arm == "sampled")):
        raise ValueError("Timing accepts only prespecified confirmation repeat 0 from its selected arm")
    if original["method"] in ("mse", "wise", "spo_plus"):
        if original.get("baseline_protocol") != "physical_cold_highs_v1":
            raise ValueError("Canonical physical baseline is required")
    job = copy.deepcopy(original)
    job["source_confirmation_id"] = original["id"]
    prefix = "cluster_timing__" if validation_arm == "mean" else "cluster_timing_sampled__"
    job["id"] = prefix + original["id"]
    job["stage"] = "timing"
    job["config"]["evaluate_test"] = False
    training = job["config"]["training"]
    if original.get("frozen_horizon") is None:
        raise ValueError("No frozen horizon on source confirmation")
    horizon = int(original["frozen_horizon"])
    if horizon < 0:
        raise ValueError("Invalid frozen horizon")
    training.update(epochs=max(1, horizon), selection_mode="last",
        maximum_optimization_seconds=None, validation_epochs=[max(1, horizon)],
        torch_threads=1)
    # Loading uses the explicit frozen bank, also for historical public jobs.
    # No analytic validation construction or validation solve is necessary.
    job["protocol_revision"] = "physical_relaxed_spo_conditional_validation_v1"
    job.pop("analytic_validation", None)
    return job


def refresh_missing_inputs(run, inventory, banks, confirmation):
    """Append the two restored SPO controls; never replace an existing source."""
    existing = {(row["cell"], row["method"]) for row in inventory["fits"]}
    for original in confirmation["jobs"]:
        cell = original.get("comparison_cell", original["cell"])
        if (original["method"] != "spo_plus" or original.get("repeat") != 0
            or original.get("validation_costs") == "single_sample"
            or (cell, original["method"]) in existing):
            continue
        path = run / "cluster_retrieved/results/receipts" / (original["id"] + ".json")
        receipt = read(path)
        if receipt["status"] != "complete":
            raise RuntimeError("Restored SPO repeat 0 is not a completed fit")
        bank = run / "cluster_retrieved/frozen_data" / (data_key(original) + ".npz")
        row = {"source_receipt": str(path), "sha256": sha(path), "id": original["id"],
               "cell": cell, "method": original["method"], "job": original,
               "data_hashes": receipt["data_hashes"], "has_frozen_bank": True}
        inventory["fits"].append(row)
        # All canonical banks share this remote parent; legacy profiles do not.
        remote_parent = Path(next(b["remote_bank"] for b in banks["fits"]
                                  if not b["legacy_profile_bank"])).parent
        banks["fits"].append({"source_job": original["id"], "cell": cell,
            "method": original["method"], "remote_bank": str(remote_parent / bank.name),
            "local_bank": str(bank), "bank_sha256": sha(bank), "verified_locally": True,
            "archived_training_hashes": receipt["data_hashes"]["train"],
            "legacy_profile_bank": False})
        existing.add((cell, original["method"]))
    missing = [key for key in inventory["known_missing_primary_cells"]
               if tuple(key.rsplit("/", 1)) not in existing]
    if missing:
        raise RuntimeError("Required restored controls remain missing: " + str(missing))
    return inventory, banks


def prepare(run):
    confirmation = verify_ready(run)
    inventory, banks = refresh_missing_inputs(run, read(run / "timing_source_inventory.json"),
        read(run / "timing_input_bank_map.json"), confirmation)
    bank_map = {row["source_job"]: row for row in banks["fits"]}
    output = run / "cluster_timing"
    entries, seen = [], set()
    for source in inventory["fits"]:
        original = source["job"]
        key = (source["cell"], source["method"])
        if key in seen:
            raise RuntimeError("Duplicate timing cell/method: " + str(key))
        seen.add(key)
        receipt_path = Path(source["source_receipt"])
        if sha(receipt_path) != source["sha256"]:
            raise RuntimeError("Archived source receipt changed")
        receipt = read(receipt_path)
        if receipt["status"] != "complete" or receipt["job"]["id"] != original["id"]:
            raise RuntimeError("Timing source is not a matching completed receipt")
        if receipt["summary"]["epochs_completed"] != original["frozen_horizon"]:
            raise RuntimeError("Source confirmation did not finish its selected horizon")
        bank = bank_map[original["id"]]
        if sha(bank["local_bank"]) != bank["bank_sha256"]:
            raise RuntimeError("Frozen timing bank changed")
        if source["data_hashes"]["train"] != bank["archived_training_hashes"]:
            raise RuntimeError("Timing bank has the wrong archived training hashes")
        job = timing_job(original)
        summary = receipt["summary"]
        planning_seconds = max(0.0, receipt.get("total_wall_seconds", receipt.get("elapsed_seconds", 0.0))
            - (summary.get("validation_wall_seconds") or 0.0)
            - (summary.get("test_evaluation_wall_seconds") or 0.0))
        entries.append({"job": job, "source_receipt_sha256": source["sha256"],
            "source_job": original, "cell": source["cell"], "bank": bank,
            "estimated_non_evaluation_wall_seconds": planning_seconds,
            "memory_admission_gib": 12 if job["method"] == "lava" else 3})
    # Fixed historical runtime estimates are used only for queue placement.
    # Starting the long fits first avoids a long, nearly idle timing tail.
    entries.sort(key=lambda e: (-e["estimated_non_evaluation_wall_seconds"], e["job"]["id"]))
    counts = collections.Counter(e["job"]["method"] for e in entries)
    if set(counts) != set(METHODS) or any(counts[m] != 35 for m in METHODS if m != "lava"):
        raise RuntimeError("All seven non-LAVA methods must cover the 35 selected cells")
    manifest = {"schema": 1, "protocol_revision": PROTOCOL, "entries": entries,
        "concurrent_fits": 8, "matched_repeats": 1, "repeat": 0,
        "threads_per_fit": 1, "maximum_lava_fits": 2, "memory_admission_gib": 42,
        "allocation_memory_gib": 48, "maximum_allocation_seconds": 14400,
        "test_evaluation": False, "validation_evaluation": False,
        "preparation_policy": "Fresh model, optimizer and method preparation, including LAVA geometry. No campaign geometry cache is read or changed. Preparation is recorded separately from optimizer timing.",
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"],
            cwd=ROOT, text=True).strip(), "counts": dict(counts)}
    path = output / "manifest.json"
    if path.exists() and read(path) != manifest:
        raise RuntimeError("Refusing to replace an immutable timing manifest")
    for source in inventory["fits"]:
        destination = output / "sources" / (source["id"] + ".json")
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists() and sha(destination) != source["sha256"]:
            raise RuntimeError("Frozen source copy changed")
        if not destination.exists():
            shutil.copyfile(source["source_receipt"], destination)
    write(path, manifest)
    write(output / "prepared.json", {"updated_unix": time.time(), "status": "ready",
        "manifest_sha256": sha(path), "counts": dict(counts),
        "selection_complete": True, "all_source_receipts_and_banks_verified": True})
    return path


def fit(run, index, cpu, validation_arm="mean"):
    if platform.system() != "Linux" or not os.environ.get("SLURM_JOB_ID"):
        raise RuntimeError("Final timings require a CERMICS Slurm allocation")
    os.sched_setaffinity(0, {cpu})
    timing_root = timing_output(run, validation_arm)
    manifest = read(timing_root / "manifest.json")
    verify_manifest_arm(manifest, validation_arm)
    entry = manifest["entries"][index]
    job = entry["job"]
    output = timing_root / "results"
    receipt_path = output / "receipts" / (job["id"] + ".json")
    if receipt_path.exists():
        return
    locks = output / "locks"
    locks.mkdir(parents=True, exist_ok=True)
    with (locks / (job["id"] + ".lock")).open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if receipt_path.exists():
            return
        started, cpu_started = time.perf_counter(), time.process_time()
        directory = output / "attempts" / job["id"] / str(time.time_ns())
        directory.mkdir(parents=True)
        record = {"job": job, "status": "running", "phase": "preprocessing",
            "pid": os.getpid(), "host": platform.node(), "cpu_affinity": [cpu],
            "slurm_job": os.environ["SLURM_JOB_ID"], "started_unix": time.time(),
            "threads_per_fit": 1, "maximum_concurrent_fits": 8,
            "source_receipt_sha256": entry["source_receipt_sha256"],
            "source_job": entry["source_job"]["id"], "directory": str(directory),
            "validation_evaluation": False, "test_evaluation": False,
            "timing_boundary": "epoch setup and optimizer batches, before epoch reporting"}
        progress = output / "progress" / (job["id"] + ".json")
        def update(phase, **values):
            record.update(phase=phase, updated_unix=time.time(), **values)
            write(progress, record)
        limits = job.get("resource_limits", {})
        wall_cap = int(limits.get("job_wall_cap_seconds", 9000))
        prep_cap = min(3600, int(limits.get("preprocessing_cap_seconds", 3600)))
        def timeout(signum, frame):
            raise TimeoutError("Timing " + record["phase"] + " time cap reached")
        def interrupted(signum, frame):
            raise InterruptedError("Timing allocation interrupted; partials preserved")
        def training_started():
            record["preparation_wall_seconds"] = time.perf_counter() - started
            record["preparation_cpu_seconds"] = time.process_time() - cpu_started
            signal.setitimer(signal.ITIMER_REAL, max(.01, wall_cap - (time.perf_counter() - started)))
            update("training")
        signal.signal(signal.SIGALRM, timeout)
        signal.signal(signal.SIGTERM, interrupted)
        signal.setitimer(signal.ITIMER_REAL, prep_cap)
        update("preprocessing")
        try:
            source_path = timing_root / "sources" / (entry["source_job"]["id"] + ".json")
            if sha(source_path) != entry["source_receipt_sha256"]:
                raise RuntimeError("Source receipt copy failed verification")
            bank = Path(entry["bank"]["remote_bank"])
            if not bank.is_relative_to(run) or sha(bank) != entry["bank"]["bank_sha256"]:
                raise RuntimeError("Timing input bank failed verification")
            os.environ["CENTRAL_PATH_FROZEN_DATA"] = str(bank.parent)
            os.environ["CENTRAL_PATH_FROZEN_DATA_READONLY"] = "1"
            import torch
            from run_central_path_final import load_job_data, core_fit, baseline_fit
            from run_public_solver_free_matched import _hash_array
            torch.set_num_threads(1)
            torch.set_num_interop_threads(1)
            loaded = load_job_data(job)
            hashes = {key: _hash_array(getattr(loaded.dataset.train, key))
                      for key in entry["bank"]["archived_training_hashes"]}
            if hashes != entry["bank"]["archived_training_hashes"]:
                raise RuntimeError("Timing training arrays differ from source confirmation")
            record.update(training_hashes=hashes, frozen_bank_sha256=sha(bank))
            trainer = baseline_fit if job["method"] in ("pfyl", "nce", "lava") else core_fit
            summary, _ = trainer(job, loaded, directory, update, training_started, timing_only=True)
            if summary["epochs_completed"] != job["frozen_horizon"]:
                raise RuntimeError("Timing did not finish the frozen horizon")
            if summary["test"] is not None or summary["best_validation"] is not None:
                raise RuntimeError("Timing unexpectedly evaluated held-out data")
            record.update(status="complete", summary=summary,
                training_only_wall_seconds=summary["optimization_wall_seconds"],
                training_only_cpu_seconds=summary["optimization_cpu_seconds"])
        except InterruptedError as exc:
            record.update(status="interrupted", error=str(exc))
        except Exception as exc:
            record.update(status="censored" if isinstance(exc, TimeoutError) else "failed",
                error=str(exc), traceback=traceback.format_exc())
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
        import resource
        record.update(total_process_wall_seconds=time.perf_counter() - started,
            total_process_cpu_seconds=time.process_time() - cpu_started, updated_unix=time.time(),
            peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024)
        write(directory / "receipt.json", record)
        if record["status"] != "interrupted":
            write(receipt_path, record)
        write(progress, record)


def eligible(entry, active_entries, memory_limit=42, lava_limit=2):
    return (sum(e["memory_admission_gib"] for e in active_entries)
            + entry["memory_admission_gib"] <= memory_limit
            and (entry["job"]["method"] != "lava"
                 or sum(e["job"]["method"] == "lava" for e in active_entries) < lava_limit))


def environment(run):
    env = dict(os.environ)
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        env[key] = "1"
    env.update(PYTHONUNBUFFERED="1", PYTHONPATH=f"{ROOT}/src:{ROOT}/scripts:{run}/external/src",
        DFL_EXTENSIONS_SRC=str(run / "external/src"), SOLVER_FREE_DFL_REPO=str(run / "public"),
        ATLANTA_SOURCE_MANIFEST=str(run / "source_receipt.json"))
    # A callback-cleanup-only source change changed the campaign's geometry
    # cache keys. Rebuild selected timing geometry within its original cap,
    # rather than aliasing cache identities or mutating the scientific cache.
    env.pop("CENTRAL_PATH_GEOMETRY_CACHE", None)
    return env


def run_queue(run, seconds, validation_arm="mean"):
    import psutil
    if (not 1 <= seconds <= 14300 or not os.environ.get("SLURM_JOB_ID")
        or int(os.environ.get("SLURM_CPUS_PER_TASK", "0")) != 8
        or int(os.environ.get("SLURM_JOB_NUM_NODES", "0")) != 1
        or platform.node().split(".")[0] not in ("node07", "node08", "node09")
        or "6730P" not in Path("/proc/cpuinfo").read_text()):
        raise RuntimeError("Timing requires eight shared cores on one matching CERMICS node")
    output = timing_output(run, validation_arm)
    output.mkdir(exist_ok=True)
    lock = (output / "queue.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    manifest = read(output / "manifest.json")
    verify_manifest_arm(manifest, validation_arm)
    prepared = read(output / "prepared.json")
    if sha(output / "manifest.json") != prepared["manifest_sha256"]:
        raise RuntimeError("Timing manifest was changed after readiness verification")
    cpus, physical = [], set()
    for cpu in sorted(os.sched_getaffinity(0)):
        topology = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        core = (topology.joinpath("physical_package_id").read_text(),
                topology.joinpath("core_id").read_text())
        if core not in physical:
            cpus.append(cpu); physical.add(core)
    if len(cpus) < 8:
        raise RuntimeError("Allocation does not expose eight distinct physical cores")
    cpus = cpus[:8]
    deadline = time.time() + seconds
    write(output / "allocation.json", {"started_unix": time.time(), "deadline_unix": deadline,
        "job_id": os.environ["SLURM_JOB_ID"], "host": platform.node(), "cpu_affinity": cpus,
        "cpu_model": "Intel Xeon 6730P", "maximum_concurrency": 8, "threads_per_fit": 1,
        "initial_loadavg": os.getloadavg(), "initial_memory": psutil.virtual_memory()._asdict(),
        "exclusive_node": False, "manifest_sha256": prepared["manifest_sha256"]})
    active, pending = {}, []
    for index, entry in enumerate(manifest["entries"]):
        if not (output / "results/receipts" / (entry["job"]["id"] + ".json")).exists():
            pending.append(index)
    stop, stop_reason = False, None
    def stopping(signum, frame):
        nonlocal stop
        stop = True
    signal.signal(signal.SIGTERM, stopping)
    signal.signal(signal.SIGINT, stopping)
    env = environment(run)
    results = output / "results"
    (results / "logs").mkdir(parents=True, exist_ok=True)
    try:
        while (pending or active) and not stop and time.time() < deadline:
            for cpu, state in list(active.items()):
                entry = manifest["entries"][state["index"]]
                progress_path = results / "progress" / (entry["job"]["id"] + ".json")
                if state["process"].poll() is None:
                    progress = read(progress_path) if progress_path.exists() else {}
                    guard_job = copy.deepcopy(entry["job"])
                    limits = guard_job.setdefault("resource_limits", {})
                    limits["preprocessing_cap_seconds"] = min(3600, limits.get("preprocessing_cap_seconds", 3600))
                    reason = limit_reason({"job_wall_cap_seconds": 9000, "preprocessing_cap_seconds": 3600},
                        guard_job, progress.get("phase"), time.time() - state["started_unix"])
                    if reason:
                        # The parent enforces limits even while a native solver
                        # prevents the child's Python alarm from being handled.
                        state["limit_reason"] = reason
                        with contextlib.suppress(ProcessLookupError):
                            os.killpg(state["process"].pid, signal.SIGTERM)
                        try:
                            state["process"].wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            with contextlib.suppress(ProcessLookupError):
                                os.killpg(state["process"].pid, signal.SIGKILL)
                            state["process"].wait(timeout=5)
                if state["process"].poll() is not None:
                    state["log"].close()
                    receipt = results / "receipts" / (entry["job"]["id"] + ".json")
                    if not receipt.exists():
                        partial = read(progress_path) if progress_path.exists() else {}
                        partial.update(status="censored" if state.get("limit_reason") else "failed",
                            job=entry["job"], error=state.get("limit_reason", "timing subprocess exited without terminal receipt"),
                            returncode=state["process"].returncode, updated_unix=time.time(),
                            external_wall_guard=True)
                        write(receipt, partial)
                    del active[cpu]
            for cpu in cpus:
                if cpu in active:
                    continue
                active_entries = [manifest["entries"][a["index"]] for a in active.values()]
                index = next((i for i in pending if eligible(manifest["entries"][i], active_entries)), None)
                if index is None:
                    break
                entry = manifest["entries"][index]
                log = (results / "logs" / (entry["job"]["id"] + ".log")).open("a")
                process = subprocess.Popen([sys.executable, __file__, "fit", "--root", str(run),
                    "--index", str(index), "--cpu", str(cpu), "--validation-arm", validation_arm],
                    stdout=log, stderr=subprocess.STDOUT,
                    env=env, start_new_session=True)
                active[cpu] = {"process": process, "index": index, "log": log,
                               "started_unix": time.time()}
                pending.remove(index)
            samples = []
            for cpu, state in active.items():
                try:
                    proc = psutil.Process(state["process"].pid)
                    usage = proc.cpu_times()
                    samples.append({"cpu": cpu, "index": state["index"], "pid": proc.pid,
                        "rss_bytes": proc.memory_info().rss, "cpu_seconds": usage.user + usage.system})
                except psutil.Error:
                    pass
            if sum(s["rss_bytes"] for s in samples) > 45 * 2**30:
                stop, stop_reason = True, "Aggregate timing RSS exceeded the 45 GiB safety guard"
            with (output / "utilization.jsonl").open("a") as stream:
                stream.write(json.dumps({"unix": time.time(), "fits": samples,
                    "node_loadavg": os.getloadavg(), "node_cpu_percent": psutil.cpu_percent(),
                    "available_memory_bytes": psutil.virtual_memory().available}) + "\n")
            write(output / "status.json", {"status": "running", "updated_unix": time.time(),
                "active": len(active), "pending": len(pending), "deadline_unix": deadline,
                "receipts": len(list((results / "receipts").glob("*.json"))),
                "rss_bytes": sum(s["rss_bytes"] for s in samples)})
            time.sleep(2)
    finally:
        for state in active.values():
            if state["process"].poll() is None:
                os.killpg(state["process"].pid, signal.SIGTERM)
        shutdown_deadline = time.monotonic() + 20
        for state in active.values():
            try:
                state["process"].wait(timeout=max(.01, shutdown_deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                os.killpg(state["process"].pid, signal.SIGKILL)
                state["process"].wait()
            state["log"].close()
    counts = collections.Counter(read(p)["status"] for p in (results / "receipts").glob("*.json"))
    write(output / "status.json", {"updated_unix": time.time(), "counts": dict(counts),
        "status": "complete" if counts["complete"] == len(manifest["entries"]) else "incomplete",
        "stop_reason": stop_reason,
        "pending_or_interrupted": len(manifest["entries"]) - sum(counts.values())})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "queue", "fit"))
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--seconds", type=int, default=14300)
    parser.add_argument("--index", type=int)
    parser.add_argument("--cpu", type=int)
    parser.add_argument("--validation-arm", choices=("mean", "sampled"), default="mean")
    args = parser.parse_args()
    if args.action == "prepare":
        if args.validation_arm == "sampled":
            from prepare_sampled_cluster_timing import prepare_sampled
            print(prepare_sampled(args.root))
        else:
            print(prepare(args.root))
    elif args.action == "queue":
        run_queue(args.root, args.seconds, args.validation_arm)
    else:
        fit(args.root, args.index, args.cpu, args.validation_arm)


if __name__ == "__main__":
    main()
