"""Finite shared-cluster pools for already reviewed, independent mode triplets.

The coordinator performs only JSON/file and Slurm metadata operations. Fits are
separate one-thread, bound-CPU processes inside finite Slurm allocations.
"""
from __future__ import annotations

import argparse
from collections import Counter
import fcntl
import json
import math
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import time

from pilot_common import read, write
from solver_reuse_ablation_scope import completion_state, effective_scope

USER = "jonathan.hornewall"
RESERVE = 4 * 2**30 + 150 * 32 * 2**20
TERMINAL_STATES = {"COMPLETED", "FAILED", "CANCELLED", "TIMEOUT", "OUT_OF_MEMORY",
                   "NODE_FAIL", "PREEMPTED", "BOOT_FAIL", "DEADLINE", "REVOKED"}


def command(args, timeout=25):
    return subprocess.check_output(args, text=True, timeout=timeout).strip()


def cluster_state():
    nodes = []
    for line in command(["scontrol", "show", "nodes", "-o"]).splitlines():
        d = dict(re.findall(r"(\w+)=([^ ]+)", line))
        nodes.append({"name": d["NodeName"], "partitions": d.get("Partitions", "").split(","),
            "available": not any(s in d["State"] for s in ("DRAIN", "DOWN", "FAIL", "UNKNOWN", "RESERVED")),
            "idle_cpus": int(d["CPUTot"]) - int(d["CPUAlloc"]),
            "real_gib": int(d["RealMemory"]) / 1024,
            "alloc_gib": int(d["AllocMem"]) / 1024,
            "free_gib": int(d.get("FreeMem", "0")) / 1024})
    jobs = []
    for line in command(["squeue", "-h", "-r", "-o", "%i|%j|%u|%t|%C|%P|%N|%m|%n"]).splitlines():
        a = line.split("|")
        m = re.fullmatch(r"([0-9.]+)([KMGT]?)([cn]?)", a[7])
        if m is None:
            raise ValueError("Unknown requested Slurm memory: " + a[7])
        memory = float(m[1]) * {"K": 1/2**20, "": 1/1024, "M": 1/1024, "G": 1, "T": 1024}[m[2]]
        if m[3] == "c":
            memory *= int(a[4])
        jobs.append(dict(id=a[0], name=a[1], user=a[2], state=a[3], cpus=int(a[4]),
                         partition=a[5], node=a[6], requested_nodes=a[8], memory_gib=memory))
    unknown_placement = any(j["state"] == "PD" and j["requested_nodes"] in ("", "(null)")
                            for j in jobs)
    for n in nodes:
        assigned = [j for j in jobs if n["name"] in (j["node"], j["requested_nodes"])]
        requested = sum(j["memory_gib"] for j in assigned)
        unknown = unknown_placement or any(j["memory_gib"] <= 0 for j in assigned)
        n["requested_gib"] = requested
        n["memory_hold"] = unknown
        n["available_gib"] = 0 if unknown else max(0., min(
            n["real_gib"] - max(n["alloc_gib"], requested), n["free_gib"] - 2.))
    return {"nodes": nodes, "jobs": jobs, "observed_unix": time.time()}


def admission(state, hosts, ceiling=150):
    owned = {h["slurm_job_id"] for h in hosts}
    reserved = sum(j["cpus"] for j in state["jobs"] if j["id"] in owned)
    remaining = max(0, ceiling - reserved)
    result = []
    for partition in ("defq", "defq-gpu"):
        for n in sorted(state["nodes"], key=lambda x: x["name"]):
            if not n["available"] or partition not in n["partitions"] or remaining == 0:
                continue
            if any(x["node"] == n["name"] for x in result):
                continue
            slots = min(remaining, n["idle_cpus"], math.floor((n["available_gib"] - 1) / 3))
            if slots < 1:
                continue
            # Honest per-fit3/6GiB admission inside a pool; optional slack lets
            # NCE500 triplets use6GiB without rebuilding healthy allocations.
            memory = min(math.floor(n["available_gib"]), slots * 3 + 1 + 32)
            result.append(dict(node=n["name"], partition=partition, slots=slots, memory_gib=memory))
            remaining -= slots
    return {"campaign_reserved_cpus": reserved,
            "all_user_reserved_cpus": sum(j["cpus"] for j in state["jobs"] if j["user"] == USER),
            "additional_campaign_ceiling": ceiling, "allocations": result}


def initialize_queue(root, manifest):
    path = root / "ops/DISPATCH_STATE.json"
    if not path.exists():
        ordered = sorted(manifest["triplets"], key=lambda t: (-t["reference_optimization_wall_seconds"], t["id"]))
        write(path, {"pending": [t["id"] for t in ordered], "claimed": 0,
                     "policy": "long reference triplets first; no stage barrier"})


def claim(root, host, core, memory_available, lookup):
    path = root / "ops/DISPATCH_STATE.json"
    with (root / "ops/assignment.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if (root / "ops/ADMISSION_HOLD.json").exists() or shutil.disk_usage(root).free < RESERVE:
            return None
        state = read(path)
        scope = effective_scope(root)
        selected = next((i for i, tid in enumerate(state["pending"])
                         if lookup[tid]["memory_gib"] <= memory_available
                         and (scope is None or tid in scope["required_triplet_ids"])), None)
        if selected is None:
            return None
        tid = state["pending"].pop(selected)
        receipt = root / "ops/triplet_claims" / (tid + ".json")
        if receipt.exists():
            raise RuntimeError("A triplet has durable ownership already; reconcile it")
        write(receipt, dict(id=tid, host=host, logical_cpu=core, slurm_job_id=os.environ["SLURM_JOB_ID"],
            claimed_unix=time.time(), memory_gib=lookup[tid]["memory_gib"], status="claimed"), immutable=True)
        state["claimed"] += 1
        write(path, state)
        return lookup[tid]


def pool(root, host, slots, memory_gib):
    manifest = read(root / "MANIFEST.json")
    deadline = read(root / "ops/LAUNCH.json")["deadline_unix"]
    cores = sorted(os.sched_getaffinity(0))
    if not os.environ.get("SLURM_JOB_ID") or len(cores) != slots or os.uname().nodename.startswith("master"):
        raise RuntimeError("Pool must run in its exact Slurm CPU allocation")
    lookup = {t["id"]: t for t in manifest["triplets"]}
    active = {}
    path = root / "ops/worker_states" / (host + ".json")
    while True:
        for core, item in list(active.items()):
            child, triplet, log = item
            if child.poll() is not None:
                log.close()
                statuses = {mode: read(root / "results/receipts" / (fid + ".json"))["status"]
                    if (root / "results/receipts" / (fid + ".json")).exists() else "missing"
                    for mode, fid in triplet["fit_ids"].items()}
                write(root / "ops/triplet_outcomes" / (triplet["id"] + ".json"),
                    dict(id=triplet["id"], host=host, statuses=statuses,
                         returncode=child.returncode, finished_unix=time.time()), immutable=True)
                if any(status != "complete" for status in statuses.values()):
                    from solver_reuse_ablation_worker import hold_dispatch
                    hold_dispatch(root, triplet["id"], "triplet_failed_or_missing_receipt")
                del active[core]
        heartbeat = root / "ops/COORDINATOR_HEARTBEAT.json"
        fresh = heartbeat.exists() and time.time() - read(heartbeat)["unix"] < 600
        stopped = time.time() >= deadline or (root / "ops/TERMINAL.json").exists()
        if fresh and not stopped:
            for core in cores:
                if core in active:
                    continue
                used = sum(t["memory_gib"] for _, t, _ in active.values())
                triplet = claim(root, host, core, memory_gib - used - 1, lookup)
                if triplet is None:
                    continue
                log = (root / "logs" / (triplet["id"] + ".log")).open("ab")
                child = subprocess.Popen(["taskset", "-c", str(core), sys.executable, "-B",
                    str(Path(__file__).with_name("solver_reuse_ablation_worker.py")),
                    "--root", str(root), "--triplet-id", triplet["id"]],
                    stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                active[core] = (child, triplet, log)
        write(path, dict(host=host, slurm_job_id=os.environ["SLURM_JOB_ID"], slots=slots,
            active=[{"triplet_id": t["id"], "pid": p.pid, "logical_cpu": core,
                     "memory_gib": t["memory_gib"]} for core, (p, t, _) in active.items()],
            coordinator_fresh=fresh, unix=time.time(), status="running"))
        pending = read(root / "ops/DISPATCH_STATE.json")["pending"]
        eligible = any(lookup[tid]["memory_gib"] <= memory_gib - 1 for tid in pending)
        if not active and (not pending or not eligible or stopped or not fresh
                           or (root / "ops/ADMISSION_HOLD.json").exists()):
            break
        time.sleep(2)
    write(path, dict(host=host, slurm_job_id=os.environ["SLURM_JOB_ID"], status="ended",
                     active=[], unix=time.time()))


class Coordinator:
    def __init__(self, root):
        import hashlib
        self.root = root
        self.manifest = read(root / "MANIFEST.json")
        review = read(root / "REVIEW_READY.json")
        if (review.get("status") != "approved" or review.get("manifest_sha256") != hashlib.sha256(
                (root / "MANIFEST.json").read_bytes()).hexdigest()
                or review.get("source_commit") != read(root / "source_receipt.json")["scientific_source_commit"]):
            raise RuntimeError("Coordinator source/manifest has not passed exact parent review")
        self.launch = read(root / "ops/LAUNCH.json")
        self.hosts_path = root / "ops/HOSTS.json"
        self.hosts = read(self.hosts_path)["hosts"] if self.hosts_path.exists() else []
        self.receipts = {}
        self.last_admission = 0
        initialize_queue(root, self.manifest)

    def reconcile(self, state):
        live = {j["id"] for j in state["jobs"]}
        for h in self.hosts:
            if h.get("retired") or h["slurm_job_id"] in live:
                continue
            rows = [r.split("|") for r in command(["sacct", "-n", "-P", "-X", "-j", h["slurm_job_id"],
                "--format=JobIDRaw,State,End"]).splitlines() if r.split("|")[0] == h["slurm_job_id"]]
            if (len(rows) != 1 or rows[0][1].split()[0].rstrip("+") not in TERMINAL_STATES
                    or rows[0][2] in ("", "Unknown", "None")):
                write(self.root / "ops/ACCOUNTING_HOLD.json", {"host": h, "rows": rows, "unix": time.time()})
                continue
            h.update(retired=True, exact_terminal_sacct=rows[0], retired_unix=time.time())
            worker_path = self.root / "ops/worker_states" / (h["name"] + ".json")
            worker = read(worker_path) if worker_path.exists() else {}
            if worker.get("status") != "ended" or worker.get("active"):
                write(self.root / "ops/ATTEMPT_FAILURE.json", {"reason": "allocation_ended_with_unresolved_triplet",
                    "host": h, "worker": worker, "unix": time.time(),
                    "action": "Concrete diagnosis/recovery required; completed fits and all claims retained"})
                write(self.root / "ops/ADMISSION_HOLD.json", {"reason": "unresolved_ended_allocation"})
        write(self.hosts_path, {"hosts": self.hosts})

    def admit(self, state, pending):
        if not pending or time.time() - self.last_admission < 60 or (self.root / "ops/ADMISSION_HOLD.json").exists():
            return
        self.last_admission = time.time()
        plan = admission(state, self.hosts)
        write(self.root / "ops/ADMISSION_CURRENT.json", {**plan, "basis": state})
        lookup = {t["id"]: t for t in self.manifest["triplets"]}
        minimum_memory = min(lookup[tid]["memory_gib"] for tid in pending)
        useful = len(pending)
        for entry in plan["allocations"]:
            if time.time() >= self.launch["deadline_unix"] - 600:
                continue
            name = "slr_" + entry["node"] + "_" + str(time.time_ns())
            slots = min(entry["slots"], useful)
            memory = min(entry["memory_gib"], slots * 3 + 1 + 32)
            if slots < 1 or memory < minimum_memory + 1:
                continue
            script_path = self.root / "ops/allocations" / (name + ".sbatch")
            script = "\n".join(["#!/bin/bash", "set -euo pipefail",
                "export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1",
                "export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1",
                "export PYTHONPATH=" + shlex.quote(str(self.root / "code/scripts") + ":" + str(self.root / "code/src") + ":" + str(self.root / "code/vendor/external/src")),
                "export SOLVER_FREE_DFL_REPO=" + shlex.quote(str(self.root / "code/vendor/public")),
                "export DFL_EXTENSIONS_SRC=" + shlex.quote(str(self.root / "code/vendor/external/src")),
                "export SIMPLIFIED_ROOT=" + shlex.quote(str(self.root)),
                "exec srun --ntasks=1 --cpus-per-task=" + str(slots) + " --cpu-bind=cores " + shlex.join([
                    str(self.root / "venv/bin/python"), "-B", str(Path(__file__).resolve()), "pool",
                    "--root", str(self.root), "--host", name, "--slots", str(slots), "--memory-gib", str(memory)]), ""])
            script_path.parent.mkdir(parents=True, exist_ok=True)
            script_path.write_text(script)
            seconds = max(1, int(self.launch["deadline_unix"] - time.time()))
            wall = f"{seconds//3600}:{seconds%3600//60:02}:{seconds%60:02}"
            argv = ["sbatch", "--parsable", "--partition=" + entry["partition"], "--nodelist=" + entry["node"],
                "--nice=10000", "--requeue", "--job-name=" + name, "--nodes=1", "--ntasks=1",
                "--cpus-per-task=" + str(slots), "--mem=" + str(memory * 1024) + "M", "--time=" + wall,
                "--output=" + str(self.root / "logs" / (name + "-%j.log")), str(script_path)]
            write(script_path.with_suffix(".intent.json"), dict(argv=argv, name=name, unix=time.time()), immutable=True)
            try:
                jid = command(argv).split(";")[0]
            except Exception:
                matches = [j for j in cluster_state()["jobs"] if j["name"] == name]
                if len(matches) != 1:
                    write(self.root / "ops/ADMISSION_HOLD.json", {"reason": "unknown_submission", "name": name})
                    raise RuntimeError("Unknown single submission; reconcile exact intent " + name)
                jid = matches[0]["id"]
            host = {**entry, "name": name, "slots": slots, "memory_gib": memory,
                    "slurm_job_id": jid, "created_unix": time.time()}
            self.hosts.append(host)
            write(self.hosts_path, {"hosts": self.hosts})
            useful -= slots

    def tick(self):
        state = cluster_state()
        self.reconcile(state)
        for p in (self.root / "results/receipts").glob("*.json"):
            if p.stem not in self.receipts:
                self.receipts[p.stem] = read(p)["status"]
        counts = Counter(self.receipts.values())
        scope = effective_scope(self.root)
        if counts["failed"] or counts["censored"]:
            from solver_reuse_ablation_worker import hold_dispatch
            hold_dispatch(self.root, "see_results_receipts", "failed_or_censored_fit")
        pending = read(self.root / "ops/DISPATCH_STATE.json")["pending"]
        if scope:
            pending = [tid for tid in pending if tid in scope["required_triplet_ids"]]
        completion = completion_state(scope, self.manifest, self.receipts)
        complete = completion["science_terminal"]
        expired = time.time() >= self.launch["deadline_unix"]
        storage_hold = shutil.disk_usage(self.root).free < RESERVE
        write(self.root / "ops/COORDINATOR_HEARTBEAT.json", {"unix": time.time(), "science_terminal": complete,
            "attempt_expired": expired, "storage_hold": storage_hold})
        if not complete and not expired and not storage_hold:
            self.admit(state, pending)
        workers = [read(p) for p in (self.root / "ops/worker_states").glob("*.json")]
        active = [a for w in workers if w.get("status") == "running" for a in w.get("active", [])]
        current = {"updated_unix": time.time(), **completion,
            "original_expected_fits": 9000, "original_expected_triplets": 3000,
            "scope_amendment": "SCOPE_AMENDMENT_20261024_ONE_SEED.json" if scope else None,
            "terminal_counts": dict(counts), "pending_triplets": len(pending), "active_triplets": len(active),
            "allocated_slots": sum(h["slots"] for h in self.hosts if not h.get("retired")),
            "campaign_reserved_cpus": sum(j["cpus"] for j in state["jobs"] if j["id"] in {h["slurm_job_id"] for h in self.hosts}),
            "all_jonathan_reserved_cpus": sum(j["cpus"] for j in state["jobs"] if j["user"] == USER),
            "additional_cpu_ceiling": 150, "science_terminal": complete,
            "attempt_expired": expired, "disk_free_bytes": shutil.disk_usage(self.root).free,
            "storage_hold": storage_hold, "deadline_unix": self.launch["deadline_unix"],
            "coordinator_pid": os.getpid(), "active": active}
        write(self.root / "ops/CURRENT_STATUS.json", current)
        if complete:
            write(self.root / "ops/EXECUTION_TERMINAL.json", {"reason": "science_complete", "unix": time.time()}, immutable=True)
        elif expired:
            write(self.root / "ops/ATTEMPT_TERMINAL.json", {"reason": "protective_deadline_unfinished",
                "terminal_counts": dict(counts), "unix": time.time(), "campaign_complete": False}, immutable=True)
        return complete or expired


def coordinate(root):
    with (root / "ops/controller.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        write(root / "ops/CONTROLLER_PROCESS.json", {"pid": os.getpid(), "unix": time.time()})
        coordinator = Coordinator(root)
        while not coordinator.tick():
            time.sleep(20)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=["coordinate", "pool"])
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--host")
    parser.add_argument("--slots", type=int)
    parser.add_argument("--memory-gib", type=float)
    args = parser.parse_args()
    if args.operation == "coordinate":
        coordinate(args.root)
    else:
        pool(args.root, args.host, args.slots, args.memory_gib)
