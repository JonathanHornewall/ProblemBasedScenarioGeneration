"""Pass declared parameters to unmodified pinned public loss implementations."""


def create_loss(method, model, parameters, dataset):
    from utils.create_loss_func import create_loss_func

    params = dict(parameters)
    params.pop("vertex_tolerance", None)
    loss_type = params.pop("loss_type", method)
    if loss_type in ("exact_cave", "inner_cave"):
        from methods.cave import exactConeAlignedCosine, innerConeAlignedCosine

        cls = (
            exactConeAlignedCosine
            if loss_type == "exact_cave"
            else innerConeAlignedCosine
        )
        return cls(model, processes=1, **params)
    return create_loss_func(loss_type, model, params, dataset)
