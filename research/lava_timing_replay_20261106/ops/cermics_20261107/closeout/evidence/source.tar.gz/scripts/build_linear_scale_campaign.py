"""Freeze the authorized affine-only and enlarged-instance comparison.

Project the archived candidate list onto a one-layer predictor. Deduplicate only
identical projected configurations; never form a new Cartesian tuning grid.
"""
from __future__ import annotations
import argparse
import collections
import copy
import gzip
import hashlib
import json
from pathlib import Path

from build_central_path_final import read, write, sha

METHODS = ['central_path_hard_validation','mse','wise','spo_plus','pfyl','nce','lava']
LARGE = {
    'dys_shortest_path_50x50': 'dys_shortest_path_25x25',
    'dys_cfl_500x10': 'dys_cfl_250x10',
    'dys_knapsack_1000x2': 'dys_knapsack_500x2',
    'lava_random_lp_800x50_released_code': 'lava_random_lp_400x50_released_code',
}
REVISION = 'linear_scale_20260928_v1'


def archived_groups(package):
    mapping = read(package/'FINAL_TUNING_GROUP_MAP.json')
    manifests = {f:json.loads(gzip.decompress((package/f).read_bytes()))
                 for row in mapping for f in row['archives']}
    groups, cells = {}, {}
    for row in mapping:
        ids = set(row['screen_job_ids'])
        jobs = [j for f in row['archives'] for j in manifests[f]['jobs'] if j['id'] in ids]
        assert len(jobs) == len(ids)
        groups[row['route'],row['method']] = jobs
        source = next(manifests[f] for f in row['archives'] if any(j['id'] in ids for j in manifests[f]['jobs']))
        info = copy.deepcopy(source['cells'][jobs[0]['cell']])
        if row['route'] in cells:
            assert cells[row['route']]['confirmation_seeds'] == info['confirmation_seeds']
            assert cells[row['route']]['refinement_seeds'] == info['refinement_seeds']
        cells[row['route']] = info
    return groups, cells


def linear_model(model):
    # Width/activation/correction fields are ignored at depth zero, but freeze
    # one representation so architecture duplicates do not receive extra tries.
    return {**model, 'depth':0, 'width':64, 'activation':'silu',
            'layer_norm':False, 'correction_depth':0, 'correction_width':64}


def configure(template, route, arm):
    j = copy.deepcopy(template)
    j.update(reference_job_id=template['id'], route=route, stage='screen', repeat=0,
             cell=f'{route}__train100__{arm}__20260928', architecture_arm=arm,
             linear_scale_revision=REVISION, validation_costs='single_sample',
             analytic_validation=False, physical128_revision='physical_head_test128_20260925_v1')
    j.pop('frozen_horizon',None)
    c = j['config']
    c.update(benchmark_id=route, sizes={'train':100,'validation':32,'test':128}, evaluate_test=False)
    c['training']['torch_threads'] = 1
    if arm == 'linear': c['model'] = linear_model(c['model'])
    # Preserve all scientific fields except identity and the requested model.
    payload = {k:v for k,v in c.items() if k not in ('name','seeds','workers','evaluate_test')}
    j['candidate'] = sha({'config':payload,'method':j['method'],'parameters':j['parameters']})[:16]
    j['id'] = f"screen__{j['cell']}__{j['method']}__{j['candidate']}"
    c['name'] = j['id']
    return j


def lava_extension(groups, source_route):
    if (source_route,'lava') in groups: return groups[source_route,'lava']
    family = 'shortest_path' if 'shortest_path' in source_route else 'cfl'
    donor = next(jobs for (route,method),jobs in groups.items() if method=='lava' and family in route)
    parameters = {sha(j['parameters']):j['parameters'] for j in donor}
    result = []
    for common in groups[source_route,'mse']:
        for parameter in parameters.values():
            t = copy.deepcopy(donor[0])
            t['id'] = common['id']+'__lava_extension__'+sha(parameter)[:8]
            t['config'].update(model=copy.deepcopy(common['config']['model']),
                               training=copy.deepcopy(common['config']['training']),
                               seeds=copy.deepcopy(common['config']['seeds']))
            t['parameters'] = copy.deepcopy(parameter)
            t['extension_common_template'] = common['id']
            t['extension_method_template'] = donor[0]['id']
            result.append(t)
    return result


def build(package, root):
    assert not (root/'screen.json').exists(), 'Frozen campaign already exists'
    groups, old_cells = archived_groups(package)
    jobs, cells, ledger, unavailable = [], {}, [], []
    specs = [(r,r,'linear') for r in sorted(old_cells)]
    specs += [(r,s,a) for r,s in LARGE.items() for a in ('linear','neural')]
    for route,source,arm in specs:
        cell = f'{route}__train100__{arm}__20260928'
        cells[cell] = {**copy.deepcopy(old_cells[source]),'route':route,
                       'train_size':100,'validation_size':32,'test_size':128,
                       'architecture_arm':arm,'source_route':source}
        for method in METHODS:
            templates = groups.get((source,method))
            if templates is None:
                if route in LARGE and method=='lava': templates=lava_extension(groups,source)
                else:
                    assert method=='lava'
                    unavailable.append({'cell':cell,'route':route,'method':method,'architecture_arm':arm,
                        'reason':'No eligible original LAVA geometry; preserved as unavailable, not a performance result'})
                    continue
            projected = {}
            for template in templates:
                j = configure(template,route,arm)
                if j['id'] not in projected: projected[j['id']] = [j,[]]
                projected[j['id']][1].append(template['id'])
            for j,originals in projected.values():
                j['projected_from_screen_ids'] = sorted(originals)
                jobs.append(j)
                ledger.append({'id':j['id'],'route':route,'method':method,'architecture_arm':arm,
                    'source_route':source,'source_ids':sorted(originals),
                    'model':j['config']['model'],'training':j['config']['training'],
                    'method_parameters':j['config']['method_parameters'],'public_parameters':j['parameters']})
    jobs.sort(key=lambda j:(j['route'] in LARGE,j['cell'],METHODS.index(j['method']),j['candidate']))
    assert len({j['id'] for j in jobs}) == len(jobs)
    assert not any(j['method']=='intopt_original' for j in jobs)
    # All methods see the same projected common configuration options and schedule.
    common={}
    for j in jobs:
        key=(j['cell'],j['method'])
        common.setdefault(key,set()).add(sha({'model':j['config']['model'],'training':j['config']['training']}))
    for cell in cells:
        reference=common[cell,'mse']
        for method in METHODS:
            if (cell,method) in common:
                assert common[cell,method]==reference,(cell,method,'common grid differs')
    protocol = {'method_waves':[METHODS], 'per_cell_method_pipeline':True,
        'training':'100 observed pairs; data-only preprocessing',
        'validation':'32 sampled observed costs, fixed across candidates/checkpoints; selection only',
        'test':'128 frozen contexts, opened only after configuration and horizon selection',
        'linear':'one affine predictor; fixed train-only input standardization is affine; method components retained',
        'neural':'unchanged original architecture/configuration candidate list for the four larger instances',
        'selection':'original top-three screening, three-seed refinement, ten full seed-bundle confirmations',
        'resource_caps':'original 3600-second preparation/optimization and 9000-second fit caps',
        'intopt_excluded_by_user':True, 'test_scores_read_for_selection':False}
    screen={'schema':REVISION,'protocol':protocol,'cells':cells,'methods':METHODS,
        'cell_methods':{c:[m for m in METHODS if (c,m) in common] for c in cells},'jobs':jobs}
    write(root/'screen.json',screen)
    write(root/'initial_execution.json',{**screen,'screen_fingerprint':sha(screen)})
    write(root/'execution.json',{**screen,'screen_fingerprint':sha(screen)})
    write(root/'TUNING_GRID.json',ledger)
    write(root/'UNAVAILABLE_ORIGINAL_GROUPS.json',unavailable)
    write(root/'LARGE_INSTANCES.json',LARGE)
    write(root/'FULL_CAMPAIGN_METHODS.json',{'required_methods':METHODS,'excluded':['intopt_original'],
        'authorization':'User: exclude IntOpt again; it is no longer part of the main suite.'})
    inventory, new_plan, seen = [], [], set()
    for j in jobs:
        for seed in [j['config']['seeds']]+cells[j['cell']]['refinement_seeds']+cells[j['cell']]['confirmation_seeds']:
            key=j['route']+'__data'+str(seed['data'])
            if key in seen:continue
            seen.add(key)
            if j['route'] in LARGE:
                new_plan.append({'key':key,'route':j['route'],'seeds':seed,
                    'conditional_reference_samples':j['config']['conditional_reference_samples']})
            else:
                d=package/'frozen_data'/key; receipt=read(d/'receipt.json')
                for name,digest in receipt['files_sha256'].items():
                    assert hashlib.sha256((d/name).read_bytes()).hexdigest()==digest
                inventory.append({'key':key,'files_sha256':receipt['files_sha256'],
                    'receipt_sha256':hashlib.sha256((d/'receipt.json').read_bytes()).hexdigest()})
    write(root/'FROZEN_BANK_INVENTORY.json',inventory)
    write(root/'NEW_BANK_PLAN.json',new_plan)
    write(root/'burst_contract.json',{'run_id':root.name,'maximum_workers':92,
        'maximum_seconds':48*3600,'groups':sorted(common),'absolute_burst_cutoff_unix':1790581209,
        'downscale_workers':30,'aggregate_ceiling_includes_other_campaign':True})
    proof={'status':'complete','screen_fits':len(jobs),'groups':len(common),
        'original_unavailable_groups':len(unavailable),'existing_banks':len(inventory),
        'new_banks':len(new_plan),'maximum_refinement_fits':len(common)*9,
        'maximum_confirmations':len(common)*10,'by_architecture':dict(collections.Counter(j['architecture_arm'] for j in jobs)),
        'common_grids_equal':True,'sizes':{'train':100,'validation':32,'test':128},
        'source_package':str(package),'source_group_map_sha256':hashlib.sha256((package/'FINAL_TUNING_GROUP_MAP.json').read_bytes()).hexdigest(),
        'intopt_excluded':True}
    write(root/'BUILD_VERIFICATION.json',proof);print(json.dumps(proof,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--package',type=Path,required=True);p.add_argument('--root',type=Path,required=True)
    a=p.parse_args();build(a.package.resolve(),a.root.resolve())
