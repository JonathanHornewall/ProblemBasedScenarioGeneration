"""Additive, validation-only nonlinear-depth transfer; never starts a fit."""
from __future__ import annotations

import math
from pathlib import Path

from pilot_common import SMALLEST, read, sha, write

REVISION = 'frozen_nonlinear_retuning_20261022_v1'
AMENDMENT = 'FROZEN_NONLINEAR_RETUNING_AMENDMENT_20261022.json'
PHASES = [
    {'id': f'nonlinear_retune_n{n}', 'train': n, 'validation': v,
     'epochs': 300, 'depth': None, 'tune': True, 'frozen_nonlinear_depth': True}
    for n, v in ((300, 96), (500, 160), (1000, 320))
]
PHASE_IDS = frozenset(p['id'] for p in PHASES)
PROTOCOL = {
    'candidate_depths': [1, 2, 3], 'selection_training_samples': 100,
    'selection_validation_samples': 32, 'retune_existing_full_grid': True,
    'training_samples': [300, 500, 1000],
    'validation_samples_by_training_size': {'300': 96, '500': 160, '1000': 320},
    'test_samples': 100, 'epochs': 300, 'batch_size': 32, 'hidden_width': 64,
    'activation': 'gelu', 'optimizer': 'adam', 'weight_decay': 0,
    'gradient_clip': None, 'final_seed_bundles': 10, 'test_scores_read': False,
}


def extend_plan(root, plan):
    root = Path(root)
    path = root / AMENDMENT
    if not path.exists():
        return plan
    amendment = read(path)
    mismatched = [k for k, v in PROTOCOL.items() if amendment.get(k) != v]
    retained = read(root / 'SCOPE_AMENDMENT.json')['retained_methods']
    if amendment.get('retained_methods') != retained:
        mismatched.append('retained_methods')
    commit = amendment.get('runtime_source_commit', '')
    if len(commit) != 40 or any(c not in '0123456789abcdef' for c in commit):
        mismatched.append('runtime_source_commit')
    if mismatched:
        plan['deferred_nonlinear_phase_extension'] = {
            'amendment': AMENDMENT, 'mismatched_fields': mismatched}
        return plan
    existing = {p['id'] for p in plan['phases']}
    plan['phases'].extend({**p, 'retained_methods': list(retained), 'runtime_source_commit': commit}
                          for p in PHASES if p['id'] not in existing)
    plan['effective_nonlinear_phase_extension'] = {
        'amendment': AMENDMENT, 'revision': REVISION,
        'added_phases': [p['id'] for p in PHASES],
        'depth_selection': 'N100 development validation32 only; lower-depth tie',
        'missing_choice': 'hold affected method/family only'}
    return plan


def resolve_phase(root, phase, method, fam, *, freeze=False):
    """Freeze one pair only after all three N100 development selections exist."""
    if phase['id'] not in PHASE_IDS:
        return phase
    root = Path(root)
    relative = Path('architecture_choices/nonlinear_transfer') / (method + '__' + fam + '.json')
    path = root / relative
    if not path.exists():
        if not freeze:
            return None
        sources = []
        for depth in (1, 2, 3):
            source = Path('selections') / f'mlp_depth{depth}' / (method + '__' + fam + '.json')
            if not (root / source).exists():
                return None
            selection = read(root / source)
            if selection.get('test_scores_read') is not False:
                raise ValueError('Nonlinear depth selection received test information')
            if selection['method'] != method or selection['family'] != fam:
                raise ValueError('Nonlinear depth selection method/family differs')
            template = selection.get('selected_template')
            if template is None or selection.get('score') is None:
                return None
            score = float(selection['score'])
            if not math.isfinite(score):
                raise ValueError('Nonfinite nonlinear development score')
            config = template['config']
            if (config['model']['depth'], config['sizes']['train'],
                    config['sizes']['validation']) != (depth, 100, 32):
                raise ValueError('Depth source is not the matching N100/validation32 screen')
            sources.append({'depth': depth, 'score': score,
                            'path': str(source), 'sha256': sha(root / source)})
        best = min(sources, key=lambda s: (s['score'], s['depth']))
        write(path, {'revision': REVISION, 'method': method, 'family': fam,
            'allowed_depths': [1, 2, 3], 'selected_depth': best['depth'],
            'score': best['score'], 'sources': sources,
            'selection_data': 'smallest-family N100 development observed validation32',
            'tie_rule': 'lower depth on exact validation-score tie',
            'test_scores_read': False}, immutable=True)
    choice = read(path)
    if (choice.get('revision') != REVISION or choice.get('method') != method
            or choice.get('family') != fam or choice.get('allowed_depths') != [1, 2, 3]
            or choice.get('selected_depth') not in (1, 2, 3)
            or choice.get('test_scores_read') is not False):
        raise ValueError('Frozen nonlinear depth contract differs')
    return {**phase, 'depth': choice['selected_depth'],
            'frozen_depth_choice': {'path': str(relative), 'sha256': sha(path)}}


def write_linear_comparisons(root, plan):
    """Reuse matched larger-data development selections; no extra fits/test reads."""
    if not plan.get('effective_nonlinear_phase_extension'):
        return
    root = Path(root)
    for phase in PHASES:
        for method in read(root / 'SCOPE_AMENDMENT.json')['retained_methods']:
            for fam in SMALLEST:
                name = method + '__' + fam + '.json'
                paths = [Path('selections') / p / name for p in
                         (f"linear_retune_n{phase['train']}", phase['id'])]
                if not all((root / p).exists() for p in paths):
                    continue
                selections = [read(root / p) for p in paths]
                if any(s.get('test_scores_read') is not False for s in selections):
                    raise ValueError('Transferred-versus-linear selection received test information')
                if any(s.get('selected_template') is None or s.get('score') is None
                       for s in selections):
                    continue
                candidates = []
                for source, selection in zip(paths, selections):
                    config = selection['selected_template']['config']
                    if (config['sizes']['train'], config['sizes']['validation']) != (
                            phase['train'], phase['validation']):
                        raise ValueError('Transferred-versus-linear development sizes differ')
                    score = float(selection['score'])
                    if not math.isfinite(score):
                        raise ValueError('Nonfinite transferred-versus-linear score')
                    candidates.append({'depth': config['model']['depth'], 'score': score,
                                       'path': str(source), 'sha256': sha(root / source)})
                best = min(candidates, key=lambda s: (s['score'], s['depth']))
                frozen = resolve_phase(root, phase, method, fam)
                if (frozen is None or candidates[0]['depth'] != 0
                        or candidates[1]['depth'] != frozen['depth']):
                    raise ValueError('Transferred-versus-linear architectures differ from the frozen contract')
                write(root / 'architecture_choices' / f"transfer_vs_linear_n{phase['train']}" / name,
                      {'method': method, 'family': fam, 'candidates': candidates,
                       'selected_depth': best['depth'], 'score': best['score'],
                       'selection_data': f"matched development N{phase['train']}/validation{phase['validation']}",
                       'tie_rule': 'lower depth on exact validation-score tie',
                       'test_scores_read': False, 'new_fits': 0}, immutable=True)
