"""Select and summarize the structurally matched residual-MSE control."""

from __future__ import annotations

import json
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
RUN_ROOT = REPO_ROOT / "runs" / "proximal_next" / "residual_mse_control"
ANCHOR_ROOT = REPO_ROOT / "runs" / "proximal_next" / "broad_matched_anchor"
RESULT_ROOT = REPO_ROOT / "results" / "proximal_next"
EXPECTED_BENCHMARKS = 6
EXPECTED_SEEDS = {1, 2, 3}
EXPECTED_RATES = {1e-5, 3e-5, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2}


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected an object in {path}")
    return value


def _anchored_rows() -> dict[tuple[str, int], dict[str, Any]]:
    rows: dict[tuple[str, int], dict[str, Any]] = {}
    for summary_path in sorted(ANCHOR_ROOT.glob("*/summary.json")):
        run = summary_path.parent
        config = _load(run / "config.json")
        if config.get("method") != "anchored_proximal":
            continue
        key = (str(config["benchmark_id"]), int(config["seeds"]["data"]))
        if key in rows:
            raise ValueError(f"duplicate anchored comparator {key}")
        rows[key] = {
            "test_regret": float(_load(summary_path)["test"]["mean_regret"]),
            "base": _load(run / "embedded_mse_base.json"),
            "run_directory": str(run.relative_to(REPO_ROOT)),
        }
    if len(rows) != EXPECTED_BENCHMARKS * len(EXPECTED_SEEDS):
        raise ValueError(f"expected 18 anchored comparators, found {len(rows)}")
    return rows


def summarize() -> dict[str, Any]:
    anchors = _anchored_rows()
    rows: list[dict[str, Any]] = []
    for summary_path in sorted(RUN_ROOT.glob("*/summary.json")):
        run = summary_path.parent
        config = _load(run / "config.json")
        if config.get("method") != "residual_mse":
            raise ValueError(f"unexpected method in {run}")
        summary = _load(summary_path)
        base = _load(run / "embedded_mse_base.json")
        benchmark = str(config["benchmark_id"])
        seed = int(config["seeds"]["data"])
        rate = float(config["training"]["learning_rate"])
        anchor = anchors[(benchmark, seed)]
        if base["parameter_sha256"] != anchor["base"]["parameter_sha256"]:
            raise ValueError(f"MSE base parameter mismatch for {benchmark}/seed {seed}")
        for split in ("validation", "test"):
            if abs(
                float(base[split]["mean_regret"])
                - float(anchor["base"][split]["mean_regret"])
            ) > 1e-12:
                raise ValueError(
                    f"MSE base metric mismatch for {benchmark}/seed {seed}"
                )
        rows.append(
            {
                "benchmark_id": benchmark,
                "data_seed": seed,
                "learning_rate": rate,
                "best_epoch": int(summary["best_epoch"]),
                "validation_regret": float(
                    summary["best_validation"]["mean_regret"]
                ),
                "test_regret": float(summary["test"]["mean_regret"]),
                "mse_validation_regret": float(base["validation"]["mean_regret"]),
                "mse_test_regret": float(base["test"]["mean_regret"]),
                "anchored_test_regret": float(anchor["test_regret"]),
                "run_directory": str(run.relative_to(REPO_ROOT)),
            }
        )
    expected = EXPECTED_BENCHMARKS * len(EXPECTED_SEEDS) * len(EXPECTED_RATES)
    if len(rows) != expected:
        raise ValueError(f"expected {expected} completed runs, found {len(rows)}")

    grouped: dict[tuple[str, float], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[(row["benchmark_id"], row["learning_rate"])].append(row)
    benchmarks = sorted({row["benchmark_id"] for row in rows})
    selections: list[dict[str, Any]] = []
    rate_tables: list[dict[str, Any]] = []
    for benchmark in benchmarks:
        candidates: list[tuple[float, float, list[dict[str, Any]]]] = []
        for rate in sorted(EXPECTED_RATES):
            group = grouped[(benchmark, rate)]
            if {row["data_seed"] for row in group} != EXPECTED_SEEDS:
                raise ValueError(f"incomplete {benchmark}/{rate} group")
            mean_validation = statistics.mean(
                row["validation_regret"] for row in group
            )
            candidates.append((mean_validation, rate, group))
            rate_tables.append(
                {
                    "benchmark_id": benchmark,
                    "learning_rate": rate,
                    "mean_validation_regret": mean_validation,
                    "mean_test_regret": statistics.mean(
                        row["test_regret"] for row in group
                    ),
                    "mean_best_epoch": statistics.mean(
                        row["best_epoch"] for row in group
                    ),
                }
            )
        _, selected_rate, selected = min(
            candidates, key=lambda item: (item[0], item[1])
        )
        residual_test = [row["test_regret"] for row in selected]
        mse_test = [row["mse_test_regret"] for row in selected]
        anchored_test = [row["anchored_test_regret"] for row in selected]
        mse_deltas = [
            left - right
            for left, right in zip(residual_test, mse_test, strict=True)
        ]
        anchored_deltas = [
            left - right
            for left, right in zip(residual_test, anchored_test, strict=True)
        ]
        selections.append(
            {
                "benchmark_id": benchmark,
                "selected_learning_rate": selected_rate,
                "mean_validation_regret": statistics.mean(
                    row["validation_regret"] for row in selected
                ),
                "mean_test_regret": statistics.mean(residual_test),
                "mean_mse_test_regret": statistics.mean(mse_test),
                "mean_anchored_test_regret": statistics.mean(anchored_test),
                "mean_delta_vs_mse": statistics.mean(mse_deltas),
                "wins_vs_mse": sum(delta < 0.0 for delta in mse_deltas),
                "mean_delta_vs_anchored": statistics.mean(anchored_deltas),
                "wins_vs_anchored": sum(delta < 0.0 for delta in anchored_deltas),
                "best_epochs": [row["best_epoch"] for row in selected],
                "selected_runs": [row["run_directory"] for row in selected],
            }
        )
    return {
        "status": "complete",
        "selection_scope": (
            "development; learning rate selected by mean validation regret"
        ),
        "test_used_for_selection": False,
        "shared_mse_base_verified": True,
        "rows": rows,
        "rate_tables": rate_tables,
        "selections": selections,
    }


def _markdown(summary: dict[str, Any]) -> str:
    lines = [
        "# Structurally matched residual-MSE control",
        "",
        "The residual-MSE branch uses the identical frozen MSE checkpoint and "
        "correction architecture as anchored proximal. Its learning rate is selected "
        "by mean validation decision regret across three development seeds. Negative "
        "deltas favor residual MSE.",
        "",
        "| benchmark | LR | residual MSE | base MSE | anchored proximal | "
        "delta vs MSE | wins | delta vs anchored | wins | best epochs |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for row in summary["selections"]:
        lines.append(
            f"| {row['benchmark_id']} | {row['selected_learning_rate']:.0e} | "
            f"{row['mean_test_regret']:.6f} | {row['mean_mse_test_regret']:.6f} | "
            f"{row['mean_anchored_test_regret']:.6f} | "
            f"{row['mean_delta_vs_mse']:+.6f} | {row['wins_vs_mse']}/3 | "
            f"{row['mean_delta_vs_anchored']:+.6f} | "
            f"{row['wins_vs_anchored']}/3 | {row['best_epochs']} |"
        )
    return "\n".join(lines) + "\n"


def main() -> None:
    summary = summarize()
    RESULT_ROOT.mkdir(parents=True, exist_ok=True)
    write_json(RESULT_ROOT / "residual_mse_control.json", summary)
    output = RESULT_ROOT / "residual_mse_control.md"
    output.write_text(_markdown(summary), encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
