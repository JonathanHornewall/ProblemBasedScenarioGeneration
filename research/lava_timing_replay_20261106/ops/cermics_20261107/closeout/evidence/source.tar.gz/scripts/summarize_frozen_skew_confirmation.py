"""Summarize sealed analytic-skew confirmation using paired raw regret."""

from __future__ import annotations

import argparse
from pathlib import Path

from proximal_spo.artifacts import write_json
from proximal_spo.frozen_skew_protocol import (
    render_frozen_skew_markdown,
    summarize_frozen_skew_confirmation,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", action="append", type=Path, required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    parser.add_argument("--target-method", default="soft_radial_log_barrier")
    parser.add_argument("--required-seeds", type=int, default=10)
    arguments = parser.parse_args()
    summary = summarize_frozen_skew_confirmation(
        arguments.run_root,
        target_method=arguments.target_method,
        required_seed_count=arguments.required_seeds,
    )
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, summary)
    arguments.markdown_output.write_text(
        render_frozen_skew_markdown(summary), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
