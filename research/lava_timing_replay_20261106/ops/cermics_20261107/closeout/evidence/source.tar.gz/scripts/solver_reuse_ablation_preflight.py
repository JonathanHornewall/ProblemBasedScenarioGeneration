"""Small Linux/Slurm binding and existing-input check; no scientific fit."""
from pathlib import Path
import gzip
import importlib.metadata
import json
import os
import socket
import sys
import time
import traceback


def check(root):
    import numpy as np
    import torch
    from pyepo.data.dataset import optDataset
    from pyepo.func import NCE, SPOPlus, perturbedFenchelYoung
    from proximal_spo.problem import LinearProblem
    from proximal_spo.solver_lifecycle import LifecycleHighsOptModel, LifecycleSession, MODES
    import run_central_path_final as maintained
    import run_public_solver_free_matched as matched
    from solver_reuse_ablation_worker import validate_input_hashes
    if not os.environ.get('SLURM_JOB_ID') or socket.gethostname().startswith('master'):
        raise RuntimeError('Preflight must execute under Slurm')
    assert len(os.sched_getaffinity(0)) == 1
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    versions = {p: importlib.metadata.version(p) for p in ['highspy', 'pyepo', 'numpy', 'scipy', 'torch']}
    assert versions['highspy'] == '1.12.0' and versions['pyepo'] == '1.0.2'
    p = LinearProblem(np.ones((1, 3)), np.ones(1), np.ones(1), np.zeros(3), np.ones(3))
    native_checks = []
    for mode in MODES:
        model = LifecycleHighsOptModel(p, mode=mode)
        before = []
        run = model._run
        def observed_run():
            before.append((model._model.getBasis().valid, model._model.getSolution().value_valid))
            return run()
        model._run = observed_run
        try:
            for cost in ([3., 2., 1.], [1., 3., 2.], [2., 1., 3.]):
                model.setObj(cost)
                _, value = model.solve()
                assert value == 1.
            if mode == 'persistent_basis':
                assert [x[0] for x in before] == [False, True, True]
            else:
                assert before == [(False, False)] * 3
            native_checks.append({'mode': mode, 'basis_solution_before_run': before})
        finally:
            model.close()
    loss_checks = []
    for method in ['spo_plus', 'pfyl', 'nce']:
        for mode in MODES:
            session = LifecycleSession(method, mode)
            try:
                model = session.preprocessing_model(p)
                costs = np.array([[3., 2., 1.], [1., 3., 2.], [2., 1., 3.]])
                dataset = optDataset(model, np.ones((3, 2)), costs)
                model = session.training_model(model, dataset)
                loss = SPOPlus(model, dataset=dataset) if method == 'spo_plus' else (
                    perturbedFenchelYoung(model, n_samples=1, sigma=.3, seed=401) if method == 'pfyl' else
                    NCE(model, solve_ratio=.5, dataset=dataset))
                session.instrument_loss(loss)
                session.start_optimization()
                np.random.seed(301)
                prediction = torch.tensor(costs*.7, dtype=torch.float32, requires_grad=True)
                solutions = torch.tensor(dataset.sols, dtype=torch.float32)
                value = loss(prediction, torch.tensor(costs, dtype=torch.float32), solutions,
                             torch.tensor(dataset.objs, dtype=torch.float32)) if method == 'spo_plus' else loss(prediction, solutions)
                value.backward()
                assert torch.isfinite(value) and torch.isfinite(prediction.grad).all()
                loss_checks.append({'method': method, 'mode': mode, 'finite_loss_gradient': True})
            finally:
                session.close()
    manifest = json.loads((root/'MANIFEST.json').read_text())
    with gzip.open(root/'REFERENCE_JOBS.json.gz', 'rt') as stream:
        refs = json.load(stream)
    input_checks = []
    for method, n, depth, group in [('spo_plus', 100, 0, 'simplified'), ('nce', 300, 0, 'scaled'), ('pfyl', 1000, 1, 'scaled')]:
        triplet = next(t for t in manifest['triplets'] if (t['method'], t['N'], t['depth'], t['input_bank_group']) == (method, n, depth, group)
                       and (n != 1000 or t['route'] == 'dys_shortest_path_10x10'))
        job = refs[triplet['reference_job_id']]
        os.environ['CENTRAL_PATH_FROZEN_DATA'] = manifest['input_roots'][group]
        loaded = maintained.load_job_data(job)
        hashes = {split: {field: matched._hash_array(getattr(getattr(loaded.dataset, split), field))
                  for field in ['contexts', 'physical_costs', 'conditional_mean_costs']} for split in ['train', 'validation']}
        validate_input_hashes(root, manifest, job['id'], hashes)
        assert loaded.provenance['generator_called_by_fit'] is False
        assert loaded.provenance['test_bank_opened'] is False
        input_checks.append({'job_id': job['id'], 'method': method, 'N': n, 'group': group,
            'input_hashes_match_original': True, 'test_unopened': True, 'generator_not_called': True})
    return {'status': 'passed', 'versions': versions, 'native_checks': native_checks,
            'public_loss_smokes': loss_checks, 'existing_input_checks': input_checks,
            'scientific_fits': 0, 'host': socket.gethostname(), 'affinity': sorted(os.sched_getaffinity(0)),
            'slurm_job_id': os.environ['SLURM_JOB_ID']}


if __name__ == '__main__':
    root = Path(sys.argv[1])
    started = time.perf_counter()
    try:
        result = check(root)
    except BaseException as exc:
        result = {'status': 'failed', 'error': repr(exc), 'traceback': traceback.format_exc(), 'scientific_fits': 0}
    result.update(finished_unix=time.time(), wall_seconds=time.perf_counter()-started)
    (root/'ops/PREFLIGHT_RESULT.json').write_text(json.dumps(result, sort_keys=True, indent=2)+'\n')
    print(json.dumps(result, sort_keys=True))
    sys.exit(0 if result['status'] == 'passed' else 1)
