#!/usr/bin/env python3
"""Run the frozen campaign on one disposable VM, with a resumable budget stop."""

from __future__ import annotations

import argparse
import collections
import contextlib
import fcntl
import os
import signal
import subprocess
import time
from pathlib import Path

import psutil
from build_central_path_final import read, write
from central_path_slurm import LIMITS, environment, summarize
from central_path_slurm import allocation as slurm_allocation
from select_central_path_final import transition


def allocation(job):
    if job["method"] == "cave" and "cfl" in job["route"]:
        return "heavy"  # First cloud wave exceeded the original 8 GiB allocation.
    return slurm_allocation(job)


def geometry_group(job):
    return (
        job["cell"],
        job["method"],
        job.get("config", {}).get("seeds", {}).get("data"),
    )


def reservation(job, cached=None):
    # Calibrated from the first cloud wave: 31 fits used 21 GiB in total.
    # Admission reserves do not change the independent per-fit memory caps.
    category = allocation(job)
    meta = (cached or {}).get(geometry_group(job))
    if meta and (meta.get("retained") or meta.get("status") != "complete"):
        if meta.get("status") != "complete":
            return 1.5  # Read the cached failure and issue an explicit receipt.
        return max(2.0, 1.5 + 2 * meta.get("serialized_bytes", 0) / 2**30)
    return {"light": 1.5, "medium": 2.0, "heavy": 44.0}[category]


def select_pending(pending, active, jobs, memory_gib, cached=None):
    """Backfill CPU slots without queuing many copies of the same geometry."""
    used = sum(
        max(reservation(jobs[i], cached), t.get("rss_gib", 0))
        for i, t in active.items()
    )
    ready = {
        k
        for k, v in (cached or {}).items()
        if v.get("retained") or v.get("status") != "complete"
    }
    heavy = sum(
        allocation(jobs[i]) == "heavy" and geometry_group(jobs[i]) not in ready
        for i in active
    )
    other_pending = any(allocation(jobs[i]) != "heavy" for i in pending)
    geometry = {
        geometry_group(jobs[i])
        for i in active
        if allocation(jobs[i]) in ("heavy", "medium")
        and geometry_group(jobs[i]) not in ready
    }
    for i in pending:
        job = jobs[i]
        category = allocation(job)
        is_ready = geometry_group(job) in ready
        if category == "heavy" and not is_ready and heavy >= 2 and other_pending:
            continue
        if (
            category in ("heavy", "medium")
            and not is_ready
            and geometry_group(job) in geometry
        ):
            continue
        if used + reservation(job, cached) <= memory_gib:
            return i
    return None


def stop_process(task, reason):
    if "terminated" not in task:
        task.update(terminated=time.monotonic(), reason=reason)
        with contextlib.suppress(ProcessLookupError):
            os.killpg(task["process"].pid, signal.SIGTERM)
    elif time.monotonic() - task["terminated"] > 15:
        with contextlib.suppress(ProcessLookupError):
            os.killpg(task["process"].pid, signal.SIGKILL)


class AdoptedProcess:
    """Monitor an already-running fit after replacing only its controller."""

    def __init__(self, process, receipt):
        self.process, self.receipt = process, receipt
        self.pid, self.created = process.pid, process.create_time()

    def poll(self):
        if self.receipt.exists():
            return 0
        try:
            if (
                not self.process.is_running()
                or self.process.create_time() != self.created
                or self.process.status() == psutil.STATUS_ZOMBIE
            ):
                return -1
        except psutil.Error:
            return -1
        return None


def adopt_running(root, path, jobs, pending):
    """Adopt only matching live PIDs; never restart or signal their fits."""
    active = {}
    for i in list(pending):
        progress = root / "results/progress" / (jobs[i]["id"] + ".json")
        if not progress.exists():
            continue
        record = read(progress)
        if (
            record.get("status") != "running"
            or record.get("job", {}).get("id") != jobs[i]["id"]
        ):
            continue
        try:
            proc = psutil.Process(record["pid"])
            command = proc.cmdline()
            runner = str(root / "code/scripts/run_central_path_final.py")
            if (
                runner not in command
                or "--manifest" not in command
                or "--job-index" not in command
                or command[command.index("--manifest") + 1] != str(path)
                or command[command.index("--job-index") + 1] != str(i)
            ):
                continue
            elapsed = max(0.0, time.time() - proc.create_time())
            receipt = root / "results/receipts" / (jobs[i]["id"] + ".json")
            process = AdoptedProcess(proc, receipt)
            if process.poll() is not None:
                continue
        except (psutil.Error, KeyError, IndexError):
            continue
        active[i] = {
            "process": process,
            "started": time.monotonic() - elapsed,
            "log": (root / "results/logs" / (jobs[i]["id"] + ".log")).open("a"),
        }
        pending.remove(i)
    if active:
        write(
            root / "results/controller_adoption.json",
            {
                "adopted": [
                    {"job": jobs[i]["id"], "pid": t["process"].pid}
                    for i, t in active.items()
                ],
                "fits_restarted": 0,
                "time_unix": time.time(),
            },
        )
    return active


def retry_legacy_projection_memory_fit(root, job):
    """Preserve the failed unchunked attempt; retry only before selection freezes."""
    if job["method"] != "direct_projection" or job.get("stage") != "screen":
        return False
    path = root / "results/receipts" / (job["id"] + ".json")
    if not path.exists():
        return False
    record = read(path)
    if (
        record.get("status") != "censored"
        or record.get("error") != "memory_cap"
        or record.get("projection_chunk_size") == 32
    ):
        return False
    frozen = (
        root
        / "results/selections"
        / ("refinement__" + job["cell"] + "__direct_projection.json")
    )
    if frozen.exists():
        return False
    target = (
        root
        / "results/resource_retries"
        / job["id"]
        / (str(record.get("pid", "unknown")) + ".json")
    )
    if target.exists():
        raise RuntimeError("refusing to overwrite an archived resource attempt")
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as archive:
        archive.write(path.read_bytes())
    path.unlink()
    return True


def run_stage(root, path, *, workers, memory_gib, deadline, stopping, refresh=None):
    manifest = read(path)
    jobs = manifest["jobs"]
    receipt_names = {job["id"] + ".json" for job in jobs}
    output = root / "results"
    (output / "logs").mkdir(parents=True, exist_ok=True)
    for job in jobs:
        retry_legacy_projection_memory_fit(root, job)
    pending = [
        i
        for i, j in enumerate(jobs)
        if not (output / "receipts" / (j["id"] + ".json")).exists()
    ]
    # Large geometry starts early; candidates are otherwise in frozen order.
    pending.sort(key=lambda i: (-reservation(jobs[i]), i))
    active = adopt_running(root, path, jobs, pending)
    recorded = {}
    cached = {}
    stop = False
    while True:
        stop = stopping() or time.time() >= deadline
        if refresh is not None and not stop and refresh():
            updated = read(path)
            new_jobs = updated["jobs"]
            if new_jobs[: len(jobs)] != jobs:
                raise ValueError("running execution manifest must be append-only")
            pending.extend(
                i
                for i in range(len(jobs), len(new_jobs))
                if not (output / "receipts" / (new_jobs[i]["id"] + ".json")).exists()
            )
            manifest, jobs = updated, new_jobs
            receipt_names = {job["id"] + ".json" for job in jobs}
        for i, task in list(active.items()):
            child = task["process"]
            elapsed = time.monotonic() - task["started"]
            progress_path = output / "progress" / (jobs[i]["id"] + ".json")
            progress = read(progress_path) if progress_path.exists() else {}
            key = progress.get("geometry_cache_key")
            geometry_receipt = root / "geometry_cache" / (str(key) + ".json")
            if key and geometry_receipt.exists():
                cached[geometry_group(jobs[i])] = read(geometry_receipt)
            try:
                proc = psutil.Process(child.pid)
                task["rss_gib"] = (
                    sum(
                        p.memory_info().rss
                        for p in [proc, *proc.children(recursive=True)]
                    )
                    / 2**30
                )
            except psutil.Error:
                task["rss_gib"] = 0.0
            reason = None
            if stop:
                reason = (
                    "budget_interrupted"
                    if time.time() >= deadline
                    else "controller_interrupted"
                )
            elif elapsed > manifest["protocol"]["job_wall_cap_seconds"] + 15:
                reason = "wall_time_cap"
            elif (
                progress.get("phase") in (None, "imports", "preprocessing")
                and elapsed > manifest["protocol"]["preprocessing_cap_seconds"] + 15
            ):
                reason = "preprocessing_time_cap"
            elif task["rss_gib"] > LIMITS[allocation(jobs[i])][1] * 0.9:
                reason = "memory_cap"
            if reason or "terminated" in task:
                stop_process(task, reason or task["reason"])
            code = child.poll()
            if code is None:
                continue
            task["log"].close()
            receipt = output / "receipts" / (jobs[i]["id"] + ".json")
            if not receipt.exists():
                reason = task.get("reason", "child_exit_without_receipt")
                record = progress or {"job": jobs[i]}
                record.update(
                    status="interrupted"
                    if reason in ("budget_interrupted", "controller_interrupted")
                    else "censored",
                    error=reason,
                    returncode=code,
                    total_wall_seconds=elapsed,
                    finished_unix=time.time(),
                )
                # Budget interruptions remain retryable and cannot affect selection.
                target = (
                    output / "interruptions" / (jobs[i]["id"] + ".json")
                    if stop
                    else receipt
                )
                write(target, record)
                if (
                    not stop
                    and key
                    and not geometry_receipt.exists()
                    and progress.get("phase") == "preprocessing"
                    and reason
                    in (
                        "memory_cap",
                        "vm_memory_cap",
                        "preprocessing_time_cap",
                        "wall_time_cap",
                    )
                ):
                    meta = {
                        "status": "censored",
                        "resource_limited": True,
                        "error": reason,
                        "error_type": "ResourceLimit",
                        "seconds": elapsed,
                        "origin_job": jobs[i]["id"],
                    }
                    write(geometry_receipt, meta)
                    cached[geometry_group(jobs[i])] = meta
            if retry_legacy_projection_memory_fit(root, jobs[i]):
                recorded.pop(jobs[i]["id"] + ".json", None)
                pending.append(i)
            del active[i]
        if active and sum(t.get("rss_gib", 0) for t in active.values()) > memory_gib:
            stop_process(
                max(active.values(), key=lambda t: t.get("rss_gib", 0)), "vm_memory_cap"
            )
        while not stop and len(active) < workers:
            i = select_pending(pending, active, jobs, memory_gib, cached)
            if i is None or psutil.virtual_memory().available < 4 * 2**30:
                break
            pending.remove(i)
            log = (output / "logs" / (jobs[i]["id"] + ".log")).open("a")
            command = [
                str(root / "venv/bin/python"),
                str(root / "code/scripts/run_central_path_final.py"),
                "--manifest",
                str(path),
                "--job-index",
                str(i),
                "--output-root",
                str(output),
            ]
            child = subprocess.Popen(
                command,
                env=environment(root),
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            active[i] = {"process": child, "log": log, "started": time.monotonic()}
        counts = collections.Counter()
        stage_counts = collections.defaultdict(collections.Counter)
        for p in (output / "receipts").glob("*.json"):
            if p.name in receipt_names:
                if p.name not in recorded:
                    recorded[p.name] = read(p)["status"]
                counts[recorded[p.name]] += 1
                stage_counts[p.name.split("__", 1)[0]][recorded[p.name]] += 1
        stages = {job["stage"] for job in jobs}
        write(
            output / "queue_status.json",
            {
                "stage": next(iter(stages)) if len(stages) == 1 else "pipeline",
                "manifest": path.name,
                "expected": len(jobs),
                "pending": len(pending),
                "running": [jobs[i]["id"] for i in active],
                "terminal": dict(counts),
                "terminal_by_stage": dict(stage_counts),
                "workers": workers,
                "rss_gib": sum(t.get("rss_gib", 0) for t in active.values()),
                "updated_unix": time.time(),
                "deadline_unix": deadline,
                "stopping": stop,
            },
        )
        if stop and not active:
            return False
        if not pending and not active:
            # Finishing children may have unlocked their next stage this tick.
            if refresh is not None and refresh():
                updated = read(path)
                if updated["jobs"][: len(jobs)] != jobs:
                    raise ValueError("running execution manifest must be append-only")
                pending.extend(
                    i
                    for i in range(len(jobs), len(updated["jobs"]))
                    if not (
                        output / "receipts" / (updated["jobs"][i]["id"] + ".json")
                    ).exists()
                )
                manifest, jobs = updated, updated["jobs"]
                receipt_names = {job["id"] + ".json" for job in jobs}
                continue
            return True
        if pending or active:
            time.sleep(3)
    return True


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--workers", type=int, default=64)
    p.add_argument("--memory-gib", type=float, default=236)
    p.add_argument("--deadline-unix", type=float, required=True)
    args = p.parse_args()
    root = args.root.resolve()
    (root / "results").mkdir(exist_ok=True)
    lock = (root / "queue.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    stop = False

    def stopping(signum, frame):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, stopping)
    signal.signal(signal.SIGINT, stopping)
    if read(root / "screen.json")["protocol"].get("per_cell_method_pipeline"):
        from central_path_pipeline import Pipeline

        pipeline = Pipeline(root)
        for job in pipeline.execution["jobs"]:
            retry_legacy_projection_memory_fit(root, job)
        pipeline.refresh()
        complete = run_stage(
            root,
            pipeline.path,
            workers=args.workers,
            memory_gib=args.memory_gib,
            deadline=args.deadline_unix,
            stopping=lambda: stop,
            refresh=pipeline.refresh,
        )
        if complete:
            summarize(root, root / "confirmation.json")
        write(
            root / "results/CLOUD_DONE.json",
            {
                "status": read(root / "FINAL_RESULTS.json")["status"]
                if complete
                else ("controller_stopped" if stop else "budget_stopped"),
                "stage": "pipeline",
                "remaining_work_is_retryable": not complete,
                "finished_unix": time.time(),
            },
        )
        return
    for stage, next_stage in (
        ("screen", "refinement"),
        ("refinement", "confirmation"),
        ("confirmation", None),
    ):
        path = root / (stage + ".json")
        manifest = read(path)
        if not manifest["jobs"]:
            write(
                root / "results/CLOUD_DONE.json",
                {"status": "no_eligible_candidates", "stage": stage},
            )
            return
        complete = run_stage(
            root,
            path,
            workers=args.workers,
            memory_gib=args.memory_gib,
            deadline=args.deadline_unix,
            stopping=lambda: stop,
        )
        if not complete:
            write(
                root / "results/CLOUD_DONE.json",
                {
                    "status": "controller_stopped" if stop else "budget_stopped",
                    "stage": stage,
                    "remaining_work_is_retryable": True,
                },
            )
            return
        if next_stage:
            destination = root / (next_stage + ".json")
            selected = transition(manifest, root / "results")
            if destination.exists():
                if read(destination) != selected:
                    raise RuntimeError(
                        "existing selection differs from frozen receipts"
                    )
            else:
                write(destination, selected)
        else:
            summarize(root, path)
            write(
                root / "results/CLOUD_DONE.json",
                {"status": "complete", "finished_unix": time.time()},
            )


if __name__ == "__main__":
    main()
