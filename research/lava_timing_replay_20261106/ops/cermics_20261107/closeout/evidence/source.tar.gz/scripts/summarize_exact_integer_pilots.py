"""Summarize bounded exact-integer solver-loop runtime pilots."""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected a JSON object at {path}")
    return payload


def summarize(run_root: Path, *, source_sha256: str) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for directory in sorted(path for path in run_root.iterdir() if path.is_dir()):
        paths = {
            name: directory / f"{name}.json"
            for name in ("status", "config", "environment", "summary")
        }
        if not all(path.is_file() for path in paths.values()):
            continue
        status = _object(paths["status"])
        config = _object(paths["config"])
        environment = _object(paths["environment"])
        result = _object(paths["summary"])
        if status.get("status") != "complete":
            continue
        if environment.get("source_sha256") != source_sha256:
            continue
        oracle = result.get("total_training_oracle_stats")
        validation = result.get("best_validation")
        if not isinstance(oracle, dict) or not isinstance(validation, dict):
            raise ValueError(f"malformed completed receipt in {directory}")
        rows.append(
            {
                "benchmark_id": config.get("benchmark_id"),
                "git_commit": environment.get("git_commit"),
                "git_dirty": environment.get("git_dirty"),
                "method": config.get("method"),
                "method_parameters": config.get("method_parameters", {}),
                "source_sha256": source_sha256,
                "training_oracle_calls": int(oracle["calls"]),
                "training_solver_seconds": float(oracle["solver_seconds"]),
                "training_wall_seconds": float(result["training_wall_seconds"]),
                "validation_normalized_mean_regret": validation.get(
                    "normalized_mean_regret"
                ),
            }
        )
    if not rows:
        raise ValueError("no completed pilots matched the requested source digest")

    methods: dict[str, list[dict[str, Any]]] = defaultdict(list)
    routes: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        methods[str(row["method"])].append(row)
        routes[str(row["benchmark_id"])].append(row)

    method_summary: dict[str, dict[str, float | int]] = {}
    for method, method_rows in sorted(methods.items()):
        method_summary[method] = {
            "run_count": len(method_rows),
            "mean_training_wall_seconds": sum(
                float(row["training_wall_seconds"]) for row in method_rows
            )
            / len(method_rows),
            "maximum_training_wall_seconds": max(
                float(row["training_wall_seconds"]) for row in method_rows
            ),
            "maximum_solver_seconds": max(
                float(row["training_solver_seconds"]) for row in method_rows
            ),
            "mean_oracle_calls": sum(
                int(row["training_oracle_calls"]) for row in method_rows
            )
            / len(method_rows),
        }

    route_summary: list[dict[str, Any]] = []
    for benchmark_id, route_rows in sorted(routes.items()):
        route_summary.append(
            {
                "benchmark_id": benchmark_id,
                "run_count": len(route_rows),
                "maximum_training_wall_seconds": max(
                    float(row["training_wall_seconds"]) for row in route_rows
                ),
                "mean_training_wall_seconds": sum(
                    float(row["training_wall_seconds"]) for row in route_rows
                )
                / len(route_rows),
            }
        )

    commits = {str(row["git_commit"]) for row in rows}
    dirty_values = {bool(row["git_dirty"]) for row in rows}
    if len(commits) != 1 or dirty_values != {False}:
        raise ValueError("pilots do not share one clean immutable commit")
    return {
        "evidence_boundary": (
            "Tiny 16-train/4-validation pilots with 160 exact integer oracle "
            "calls per run; not comparative performance evidence."
        ),
        "source_sha256": source_sha256,
        "git_commit": next(iter(commits)),
        "run_count": len(rows),
        "failure_count": 0,
        "route_count": len(routes),
        "methods": method_summary,
        "routes": route_summary,
        "rows": rows,
    }


def render_markdown(summary: dict[str, Any]) -> str:
    lines = [
        "# Corrected exact-integer runtime pilot receipt",
        "",
        "This is a computation-only gate. Tiny validation regrets are not "
        "comparative performance evidence.",
        "",
        f"- Clean commit: `{summary['git_commit']}`",
        f"- Executable source digest: `{summary['source_sha256']}`",
        f"- Routes: {summary['route_count']}",
        f"- Runs: {summary['run_count']}",
        f"- Failures: {summary['failure_count']}",
        "- Test evaluation: disabled",
        "",
        "| Method | Runs | Mean train s | Maximum train s | "
        "Maximum solver s | Mean exact calls |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for method, values in sorted(summary["methods"].items()):
        lines.append(
            f"| {method} | {values['run_count']} | "
            f"{values['mean_training_wall_seconds']:.3f} | "
            f"{values['maximum_training_wall_seconds']:.3f} | "
            f"{values['maximum_solver_seconds']:.3f} | "
            f"{values['mean_oracle_calls']:.0f} |"
        )
    lines.extend(
        [
            "",
            "| Route | Runs | Mean train s | Maximum train s |",
            "|---|---:|---:|---:|",
        ]
    )
    for route in sorted(
        summary["routes"],
        key=lambda row: float(row["maximum_training_wall_seconds"]),
        reverse=True,
    ):
        lines.append(
            f"| {route['benchmark_id']} | {route['run_count']} | "
            f"{route['mean_training_wall_seconds']:.3f} | "
            f"{route['maximum_training_wall_seconds']:.3f} |"
        )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", type=Path)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    arguments = parser.parse_args()
    summary = summarize(
        arguments.run_root, source_sha256=arguments.source_sha256
    )
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, summary)
    arguments.markdown_output.write_text(
        render_markdown(summary), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
