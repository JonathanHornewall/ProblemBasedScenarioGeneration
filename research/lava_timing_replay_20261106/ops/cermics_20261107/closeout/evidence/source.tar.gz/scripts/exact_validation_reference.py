"""Analytic validation expectations for the frozen integer benchmark laws.

Training pairs and the archived test reference are never changed. Continuous
uniform expectations account for ceiling, clipping and decimal rounding.
"""
from dataclasses import replace
import importlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import numpy as np


def uniform_ceil_mean(low, high):
    low, high = np.broadcast_arrays(np.asarray(low, dtype=np.longdouble),
                                    np.asarray(high, dtype=np.longdouble))
    if np.any(high < low):
        raise ValueError("Reversed uniform interval")
    width = high-low
    a, b = low-np.floor(low), high-np.floor(high)
    correction = np.divide(b*(1-b)-a*(1-a), 2*width,
                           out=np.zeros_like(width), where=width != 0)
    value = (low+high)/2 + np.longdouble(.5) + correction
    value = np.where(np.floor(low) == np.floor(high), np.floor(low)+1, value)
    return np.asarray(np.where(width == 0, np.ceil(low), value), dtype=np.float64)


def uniform_clipped_round_mean(low, high, lower=.01, upper=100., step=.01):
    low, high = np.broadcast_arrays(np.asarray(low, dtype=np.longdouble),
                                    np.asarray(high, dtype=np.longdouble))
    if np.any(high < low):
        raise ValueError("Reversed uniform interval")
    lower, upper, step = map(lambda x: np.longdouble(str(x)), (lower, upper, step))
    def primitive(x):
        clipped = np.clip(x, lower, upper)
        shifted = clipped/step + np.longdouble(.5)
        frac = shifted-np.floor(shifted)
        middle = clipped*clipped/2 + step*step*(frac*(1-frac)/2-np.longdouble(.125))
        return middle + np.where(x < lower, lower*(x-lower),
                                 np.where(x > upper, upper*(x-upper), 0))
    width = high-low
    result = np.divide(primitive(high)-primitive(low), width,
                       out=np.zeros_like(width), where=width != 0)
    deterministic = np.round(np.clip(np.asarray(low, dtype=float), float(lower), float(upper)), 2)
    return np.asarray(np.where(width == 0, deterministic, result), dtype=np.float64)


def needs_analytic_reference_file(job):
    return bool(job.get("analytic_validation")) and job["route"].startswith(
        ("dys_cfl_", "dys_knapsack_", "pyepo_mdkp"))


def analytic_reference_name(job):
    from frozen_campaign_data import data_key
    return data_key(job) + "__quantized_uniform_v1.npz"


def _compute_reference(job, split, *, benchmark=None):
    if benchmark is None:
        package = importlib.import_module("dfl_extensions_lab.benchmarks")
        benchmark = (package.get_native_factory_route(job["route"]).build()
                     if hasattr(package,"get_native_factory_route") else package.get_benchmark(job["route"]))
    provider = benchmark.generator
    generator = getattr(provider, "scenario_generator", None)
    if type(generator).__name__ == "PublishedPolynomialCostGenerator" and generator.ceiling:
        linear = split.contexts @ generator.coefficient.T / np.sqrt(generator.context_dimension)
        base = generator.multiplier*((linear+3.)**generator.degree+generator.additive) / generator.normalization_base**generator.degree
        width = generator.noise_width
        coefficients = generator.objective_sign * uniform_ceil_mean(base*(1-width),base*(1+width))
        formula = "Integral of ceil(polynomial(context) * Uniform(1-w,1+w))"
    elif type(generator).__name__ == "DYSFacilityLocationCostGenerator":
        linear = split.contexts @ generator.coefficient.T / np.sqrt(generator.coefficient.shape[1])
        base = (linear+3.)**generator.degree / 3.**(generator.degree-1)
        width = generator.noise_width
        coefficients = uniform_clipped_round_mean(base*(1-width),base*(1+width))
        formula = "Integral of round(clip(polynomial(context) * Uniform(1-w,1+w),0.01,100),2)"
    elif type(provider).__name__ == "PyEPOMDKPProvider":
        _, coefficient, _ = provider._structure()
        linear = split.contexts @ coefficient.T / np.sqrt(provider.context_dimension)
        base = ((linear+3.)**provider.degree+1.)*5./3.5**provider.degree
        width = provider.noise_width
        coefficients = -uniform_ceil_mean(base*(1-width),base*(1+width))
        formula = "Negative integral of ceil(PyEPO polynomial(context) * Uniform(1-w,1+w))"
    else:
        raise ValueError("No certified analytic validation expectation for " + job["route"])
    from proximal_spo.external_benchmarks import _physical_costs
    exposure = getattr(benchmark,"cost_exposure",None)
    if exposure is None:
        exposure = np.eye(int(benchmark.feasible_model.variable_count))
    physical = _physical_costs(coefficients, exposure, benchmark.feasible_model.c)
    return coefficients, physical, formula


def analytic_validation_view(job, loaded):
    split = loaded.dataset.validation
    receipt = next(x for x in loaded.provenance["conditional_reference"]["splits"]
                   if x["split"] == "validation")
    if receipt["estimator"].startswith("exact"):
        return replace(loaded, provenance={**loaded.provenance,
                       "validation_reference_override":{"analytic":True,"reused_certified_reference":True,
                                                        "estimator":receipt["estimator"]}})
    location = os.environ.get("CENTRAL_PATH_FROZEN_DATA")
    provenance = {}
    if location:
        root = Path(location).parent / "frozen_validation"
        root.mkdir(parents=True,exist_ok=True)
        path = root / analytic_reference_name(job)
        with path.with_suffix(".lock").open("a") as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            if not path.exists():
                if os.environ.get("CENTRAL_PATH_FROZEN_DATA_READONLY") == "1":
                    raise RuntimeError("Authoritative analytic validation reference not delivered: " + path.name)
                coefficients, physical, formula = _compute_reference(job,split)
                temporary = path.with_suffix(f".{os.getpid()}.tmp")
                with temporary.open("wb") as stream:
                    np.savez_compressed(stream,coefficients=coefficients,physical=physical,formula=np.asarray(formula))
                temporary.replace(path)
            with np.load(path,allow_pickle=False) as arrays:
                coefficients,physical,formula=arrays["coefficients"],arrays["physical"],str(arrays["formula"])
        provenance={"frozen_reference_file":path.name,"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
    else:
        coefficients,physical,formula=_compute_reference(job,split)
    validation = replace(split,conditional_mean_coefficients=coefficients,
                         conditional_mean_costs=physical)
    return replace(loaded, dataset=replace(loaded.dataset,validation=validation),
                   provenance={**loaded.provenance,"validation_reference_override":{
                       "analytic":True,"estimator":"analytic integral of quantized uniform cost",
                       "formula":formula,"replaces":receipt,"training_and_test_unchanged":True,**provenance}})
