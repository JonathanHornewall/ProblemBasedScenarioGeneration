#!/usr/bin/env python3
"""Validate full-size Atlanta LP/slack models, optionally one-sample geometry."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import highspy
import numpy as np
import run_public_solver_free_matched as matched
import scipy.linalg
from dfl_extensions_lab.benchmarks import SplitSizes
from run_atlanta_baseline_timing import digest, write

from proximal_spo.external_benchmarks import load_external_benchmark
from proximal_spo.public_highs import (
    HighsLAVADataset,
    HighsOptModel,
    binding_normals,
    slack_form,
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--route-index", type=int)
    parser.add_argument("--geometry", action="store_true")
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    entries = {}
    for job in manifest["jobs"]:
        entries.setdefault(job["entry"]["route_id"], job["entry"])
    report = {
        "kind": "atlanta_highs_model_audit",
        "highs_version": highspy.Highs().version(),
        "adapter_sha256": digest(
            matched.PROJECT_ROOT / "src/proximal_spo/public_highs.py"
        ),
        "full_model_dimensions": True,
        "training_samples_per_route": 1,
        "full_geometry_requested": args.geometry,
        "cases": [],
    }
    for index, (route, entry) in enumerate(entries.items()):
        if args.route_index is not None and args.route_index != index:
            continue
        start = time.perf_counter()
        case = {"route": route, "status": "running"}
        report["cases"].append(case)
        write(args.output, report)
        try:
            loaded = load_external_benchmark(
                entry["benchmark_id"],
                SplitSizes(train=1, validation=1, test=1),
                data_seed=entry["seeds"]["data"],
                conditional_reference_samples=entry["conditional_reference_samples"],
            )
            problem = loaded.problem.continuous_relaxation()
            cost = loaded.dataset.train.physical_costs[0]
            original = HighsOptModel(problem)
            original.setObj(cost)
            solution, objective = original.solve()
            slack_problem = slack_form(problem)
            slack = HighsOptModel(slack_problem, presolve=False)
            slack.setObj(np.pad(cost, (0, slack_problem.variable_count - len(cost))))
            slack_solution, slack_objective = slack.solve()
            slack_solution = np.asarray(slack_solution)
            tolerance = 1e-7 * (1 + abs(objective) + np.abs(cost).sum())
            if abs(slack_objective - objective) > tolerance:
                raise RuntimeError("Original/slack optimum mismatch")
            # Exercise basis conversion independently of costly neighbour enumeration.
            basis = HighsLAVADataset.__new__(HighsLAVADataset)
            basis.slack_model, basis.slack_problem = slack, slack_problem
            basis.slack_model_A = slack_problem.matrix.toarray()
            basis._reduced_rows = None
            basis.geometry_row_reduction = False
            basis.basis_completion_count = 0
            matrix, basic, nonbasic = basis._basis(slack_solution)
            rhs = (
                slack_problem.row_lower
                if basis._reduced_rows is None
                else slack_problem.row_lower[basis._reduced_rows]
            )
            reconstructed = np.zeros(slack_problem.variable_count)
            reconstructed[basic] = scipy.linalg.solve(matrix[:, basic], rhs)
            residual = float(
                np.max(
                    np.abs(
                        slack_problem.matrix @ reconstructed - slack_problem.row_lower
                    ),
                    initial=0,
                )
            )
            if residual > 1e-6 or np.min(reconstructed, initial=0) < -1e-7:
                raise RuntimeError("Reconstructed structural basis is infeasible")
            case.update(
                variables=problem.variable_count,
                constraints=problem.constraint_count,
                slack_variables=slack_problem.variable_count,
                slack_constraints=slack_problem.constraint_count,
                original_objective=objective,
                slack_objective=slack_objective,
                binding_normals=len(binding_normals(problem, np.asarray(solution))),
                independent_rows=matrix.shape[0],
                structural_basis_columns=len(basic),
                basis_completion=basis.basis_completion_count,
                redundant_row_removal=basis.geometry_row_reduction,
                reconstructed_basis_max_residual=residual,
            )
            if args.geometry:
                case["phase"] = "adjacent_geometry"
                write(args.output, report)
                dataset = HighsLAVADataset(
                    original,
                    loaded.dataset.train.contexts,
                    loaded.dataset.train.physical_costs,
                    public_repo=matched.PUBLIC_REPO,
                )
                case.update(
                    adjacent_vertices=len(dataset.adjacent_verts[0]),
                    tnp_retries=dataset.adjacency_tnp_retry_count,
                    tied_anchor_reselections=dataset.anchor_reselection_count,
                    completeness_certified=False,
                    upstream_basis_iteration_cap=250,
                )
            case.update(status="passed", phase="complete")
        except Exception as error:
            case.update(
                status="failed", error_type=type(error).__name__, error=str(error)
            )
        case["wall_seconds"] = time.perf_counter() - start
        write(args.output, report)
        print(json.dumps(case), flush=True)
    if any(case["status"] != "passed" for case in report["cases"]):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
