"""Single-allocation durable ablations; immutable jobs and validation-only selection."""
from __future__ import annotations
import argparse, collections, copy, fcntl, json, math, os, signal, statistics, subprocess, time
from pathlib import Path
from build_whitening_validation_campaign import CPS, clean_job, signature, read, write, digest, sha


def environment(root):
 e=dict(os.environ)
 for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):e[k]='1'
 e.update(PYTHONUNBUFFERED='1',PYTHONPATH=f'{root}/code/scripts:{root}/code/src:{root}/code/vendor/external/src',
   SOLVER_FREE_DFL_REPO=str(root/'code/vendor/public'),DFL_EXTENSIONS_SRC=str(root/'code/vendor/external/src'),
   ATLANTA_SOURCE_MANIFEST=str(root/'source_receipt.json'),CENTRAL_PATH_FROZEN_DATA=str(root/'frozen_data'),
   CP_SPO_GEOMETRY_CACHE=str(root/'policy_geometry_cache'),CP_SPO_GEOMETRY_CACHE_READONLY='1',
   CP_SPO_PREPARATION_CACHE=str(root/'observed_preparation_cache'))
 return e


def provision(job):
 r=job['route'];large=r in ('dys_cfl_500x10','dys_shortest_path_50x50','dys_knapsack_1000x2','lava_random_lp_800x50_released_code')
 return 12.0 if r=='dys_cfl_500x10' or (large and job['method']==CPS) else 6.0 if large else 3.0


def metric(row):
 m=row['validation'];v=m.get('normalized_mean_regret')
 return float(m['mean_regret'] if v is None else v)


def rank(record,final_epoch):
 if record.get('status')!='complete':return None
 assert not record.get('smoke_only') and not record.get('test_access') and not record.get('test_bank_opened')
 assert record.get('summary',{}).get('test') is None
 if final_epoch:
  rows=[r for r in record.get('curve',[]) if r.get('epoch')==300 and r.get('validation')]
  return metric(rows[-1]) if rows else None
 m=record['summary']['best_validation'];v=m.get('normalized_mean_regret')
 return float(m['mean_regret'] if v is None else v)


class Campaign:
 def __init__(self,root):
  self.root=root;self.plan=read(root/'PLAN.json');self.groups=self.plan['groups'];self.known={};self.records={};self.completed={}
  self.used_sources={};self.new_jobs={};self.selection_events=[]
  dev=read(root/'prior/development.json')
  for d in dev.values():self.records[signature(d['job'])]=d
  for member,d in read(root/'prior/controls.json').items():
   a=member.split('/')[0];j=clean_job(d['job'],a)
   self.records[signature(j)]=d
  for p in sorted((root/'jobs').glob('*.json')):
   j=read(p)['jobs'][0];self.new_jobs[j['id']]=j
  for p in (root/'selections').glob('*.json'):
   d=read(p);self.completed[d['group_id']]=d
  self.fixed_gate={g['id'] for g in self.groups if g['kind']=='fixed' and not g['whitening'] and g['rho']==.5}

 def record(self,j):
  key=signature(j)
  if key in self.records:return self.records[key]
  p=self.root/'results/receipts'/(j['id']+'.json')
  if p.exists():
   d=read(p);assert signature(d['job'])==key
   self.records[key]=d;return d
  return None

 def require(self,j,priority,phase):
  d=self.record(j)
  if d is not None:return d
  j=copy.deepcopy(j);j['dispatch_priority']=priority;j['dispatch_phase']=phase
  path=self.root/'jobs'/(j['id']+'.json')
  if j['id'] not in self.new_jobs:
   write(path,{'protocol':self.plan['protocol'],'jobs':[j]});self.new_jobs[j['id']]=j
  self.known[j['id']]=self.new_jobs[j['id']]
  return None

 def source_proof(self,j,d):
  if 'source' in d:return d['source']
  if 'import_source' in d:return d['import_source']
  p=self.root/'results/receipts'/(j['id']+'.json')
  return {'path':str(p.relative_to(self.root)),'sha256':sha(p)}

 def finish(self,g,jobs,selection):
  records=[self.record(j) for j in jobs]
  if any(d is None for d in records):return False
  result={'group_id':g['id'],'kind':g['kind'],'variant':g.get('variant'),'phase':g['phase'],
     'architecture':g['architecture'],'route':g['route'],'method':g['method'],
     'jobs':jobs,'selection':selection,'test_scores_used_for_selection':False,
     'outcomes':[{'job_id':j['id'],'status':d['status'],'source':self.source_proof(j,d)} for j,d in zip(jobs,records)],
     'completed_unix':time.time()}
  write(self.root/'selections'/(digest(g['id'])+'.json'),result);self.completed[g['id']]=result
  return True

 def advance(self):
  self.known={};phase1=all(g['id'] in self.completed for g in self.groups if g['phase']==1)
  for g in self.groups:
   if g['id'] in self.completed or (g['phase']==2 and not phase1):continue
   if g['kind']=='fixed':
    jobs=g['jobs'];priority=0 if not g['whitening'] and g['rho']==.5 else 3
    for j in jobs:self.require(j,priority,g['phase'])
    self.finish(g,jobs,{'rule':'original validation winner and original selected horizon held fixed',
                      'whitening':g['whitening'],'rho':g['rho'],'radius_policy':'geometry_certified'})
    continue
   raw=g['kind']=='retuned_no_whitening'
   if raw and not self.fixed_gate.issubset(self.completed):continue
   a=g['architecture'];phase=g['phase'];final=g.get('variant') in ('final_epoch','final_epoch_one_seed')
   no_refine=g.get('variant') in ('one_seed','final_epoch_one_seed')
   screen=[clean_job(j,a,'screen',whitening=not raw,rho=.5) for j in self.plan['grids'][g['grid_key']]]
   records=[self.require(j,4 if raw else 2,phase) for j in screen]
   if any(d is None for d in records):continue
   eligible=[(rank(d,final),j,d) for j,d in zip(screen,records) if rank(d,final) is not None]
   eligible.sort(key=lambda x:(x[0],x[1]['candidate']))
   unavailable=[{'job_id':j['id'],'status':d['status'],'reason':d.get('error','required epoch absent')}
                for j,d in zip(screen,records) if rank(d,final) is None]
   choice={'rule':'epoch300' if final else 'validation_selected_epoch','refinement_seeds':0 if no_refine else 3,
           'screen_sources':[self.source_proof(j,d) for j,d in zip(screen,records)],
           'unavailable_screen':unavailable,'test_scores_read':False}
   if not eligible:
    self.finish(g,[],{**choice,'reason':'no eligible screen candidate'});continue
   if no_refine:
    score,selected,d=eligible[0];horizon=300 if final else int(d['summary']['best_epoch'])
   else:
    shortlist=eligible[:3];refine=[]
    for _,j,_ in shortlist:
     for i,seed in enumerate(g['seeds']['refinement']):
      q=clean_job(j,a,'refinement',seed,whitening=not raw,rho=.5);q['repeat']=i;refine.append(q)
    rr=[self.require(j,1,phase) for j in refine]
    if any(d is None for d in rr):continue
    winners=[]
    for _,candidate,_ in shortlist:
     pairs=[(j,d) for j,d in zip(refine,rr) if j['candidate']==candidate['candidate']]
     values=[rank(d,final) for _,d in pairs]
     if len(values)==3 and all(v is not None for v in values):
      winners.append((statistics.mean(values),candidate,pairs))
    choice['refinement_sources']=[self.source_proof(j,d) for j,d in zip(refine,rr)]
    choice['shortlist']=[j['candidate'] for _,j,_ in shortlist]
    choice['unavailable_refinement']=[{'job_id':j['id'],'status':d['status'],'reason':d.get('error','required epoch absent')} for j,d in zip(refine,rr) if rank(d,final) is None]
    if not winners:
     self.finish(g,[],{**choice,'reason':'no candidate completed all three refinement seeds'});continue
    score,selected,pairs=min(winners,key=lambda x:(x[0],x[1]['candidate']))
    if final:horizon=300
    else:
     curves=[{int(r['epoch']):metric(r) for r in d['curve'] if r.get('validation') and 'selection_score' in r} for _,d in pairs]
     common=set.intersection(*(set(c) for c in curves));assert common
     mean={e:statistics.mean(c[e] for c in curves) for e in common};horizon=min(common,key=lambda e:(mean[e],e))
     choice['mean_validation_curve']=mean
   choice.update(candidate=selected['candidate'],frozen_horizon=horizon,selection_score=score)
   jobs=[]
   for i,seed in enumerate(g['seeds']['confirmation']):
    j=clean_job(selected,a,'confirmation',seed,horizon,not raw,.5);j['repeat']=i;jobs.append(j);self.require(j,1,phase)
   self.finish(g,jobs,choice)
  return len(self.completed)==len(self.groups)


def terminate(child):
 if child.poll() is None:
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:child.wait(timeout=8)
  except subprocess.TimeoutExpired:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   child.wait(timeout=5)


def execute(root, campaign, *, workers=30, memory_gib=160, maximum_seconds=172200):
 import psutil
 root.mkdir(parents=True,exist_ok=True)
 guard=(root/'driver.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert workers<=30 and int(os.environ.get('SLURM_CPUS_PER_TASK',workers))>=workers
 env=environment(root);active={};stopped=False;started=time.time();deadline=started+maximum_seconds
 if os.environ.get('SLURM_JOB_ID'):
  line=subprocess.check_output(['scontrol','show','job',os.environ['SLURM_JOB_ID'],'-o'],text=True)
  from datetime import datetime
  fields=dict(t.split('=',1) for t in line.split() if '=' in t)
  deadline=min(deadline,datetime.fromisoformat(fields['EndTime']).timestamp()-45)
 def stop(*args):
  nonlocal stopped
  stopped=True
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 write(root/'ALLOCATION.json',{'job_id':os.environ.get('SLURM_JOB_ID'),'cpus':workers,'admission_gib':memory_gib,'deadline_unix':deadline,'started_unix':started})
 try:
  while not stopped and time.time()<deadline:
   complete=campaign.advance()
   now=time.time();total_rss=0;cpu=0
   for jid,item in list(active.items()):
    child,j,opened,log=item
    progress=root/'results/progress'/(jid+'.json');d=read(progress) if progress.exists() else {}
    try:
     processes=[psutil.Process(child.pid),*psutil.Process(child.pid).children(recursive=True)]
     rss=sum(p.memory_info().rss for p in processes)/2**30
     cpu+=sum(sum(p.cpu_times()[:2]) for p in processes)
    except psutil.Error:rss=0
    total_rss+=rss;reason=None
    limits={**campaign.plan['protocol'],**j.get('resource_limits',{})}
    if rss>provision(j)*.9:reason='memory_cap'
    elif d.get('phase') in (None,'imports','preprocessing') and now-opened>limits['preprocessing_cap_seconds']+15:reason='preprocessing_time_cap'
    elif now-opened>limits['job_wall_cap_seconds']+15:reason='wall_time_cap'
    if reason:terminate(child)
    if child.poll() is not None:
     out=root/'results/receipts'/(jid+'.json')
     if not out.exists():
      d.update(job=j,status='censored' if reason else 'failed',error=reason or 'worker_exit_without_receipt',returncode=child.returncode,
               total_wall_seconds=now-opened,finished_unix=now)
      write(out,d)
     log.close();del active[jid]
   if total_rss>memory_gib*.95:raise RuntimeError('aggregate RSS safety guard exceeded')
   if complete and not active:break
   reserved=sum(provision(item[1]) for item in active.values())
   for j in sorted(campaign.known.values(),key=lambda j:(j['dispatch_priority'],j.get('repeat',0),j['route'],j['id'])):
    if len(active)>=workers:break
    if j['id'] in active or campaign.record(j) is not None:continue
    if reserved+provision(j)>memory_gib:continue
    if now+30>=deadline:break
    logpath=root/'results/logs'/(j['id']+'.log');logpath.parent.mkdir(parents=True,exist_ok=True);log=logpath.open('a')
    cmd=[str(root/'venv/bin/python'),str(root/'code/scripts/run_central_path_final.py'),
         '--manifest',str(root/'jobs'/(j['id']+'.json')),'--job-index','0','--output-root',str(root/'results')]
    child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    active[j['id']]=(child,j,time.time(),log);reserved+=provision(j)
   counts=collections.Counter(d['status'] for d in campaign.records.values())
   write(root/'STATUS.json',{'status':'complete' if complete else 'running','updated_unix':time.time(),
     'logical_groups_complete':len(campaign.completed),'logical_groups_total':len(campaign.groups),
     'active_fits':len(active),'active_pids':{k:v[0].pid for k,v in active.items()},'rss_gib':total_rss,
     'active_cumulative_cpu_seconds':cpu,'terminal_records_including_reused':dict(counts),
     'new_jobs_registered':len(campaign.new_jobs),'deadline_unix':deadline,'slurm_job_id':os.environ.get('SLURM_JOB_ID')})
   time.sleep(3)
  return len(campaign.completed)==len(campaign.groups)
 finally:
  for jid,(child,j,opened,log) in active.items():
   terminate(child);log.close()
   write(root/'results/interruptions'/(jid+'.'+str(time.time_ns())+'.json'),
     {'job':j,'status':'interrupted','reason':'allocation_deadline_or_driver_stop','pid':child.pid,
      'started_unix':opened,'ended_unix':time.time()})
  write(root/'ALLOCATION_FINISH.json',{'job_id':os.environ.get('SLURM_JOB_ID'),'finished_unix':time.time(),
      'logical_groups_complete':len(campaign.completed),'logical_groups_total':len(campaign.groups),'live_owned_fits':0})


if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--prepare-only',action='store_true')
 a=p.parse_args();root=a.root.resolve();c=Campaign(root)
 if a.prepare_only:
  c.advance();print(json.dumps({'groups_complete':len(c.completed),'pending_unique':len(c.known),'new_jobs':len(c.new_jobs)}))
 else:
  assert read(root/'preflight/VERIFICATION.json')['status']=='passed'
  complete=execute(root,c)
  if not complete:raise SystemExit(3)
