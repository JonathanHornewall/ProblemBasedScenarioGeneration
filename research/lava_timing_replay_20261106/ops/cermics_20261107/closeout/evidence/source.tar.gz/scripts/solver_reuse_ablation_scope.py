"""The human's one-original-seed amendment; metadata and admission only."""
from __future__ import annotations

import fcntl
import hashlib
from pathlib import Path
import time

from pilot_common import read, write

AMENDMENT = "SCOPE_AMENDMENT_20261024_ONE_SEED.json"


def effective_scope(root):
    path = root / AMENDMENT
    if not path.exists():
        return None
    scope = read(path)
    if (scope.get("status") != "human_authorized" or scope.get("required_triplet_count") != 300
            or scope.get("required_fit_count") != 900
            or len(set(scope["required_triplet_ids"])) != 300
            or len(set(scope["required_fit_ids"])) != 900):
        raise RuntimeError("Invalid one-seed scope amendment; keep admission held")
    return scope


def is_required(scope, triplet):
    return scope is None or triplet["id"] in scope["required_triplet_ids"]


def mode_admission(root, triplet, mode):
    """Runs in every fresh mode child, including children of old supervisors.

    An exclusion is an explicit NOT-RUN receipt, never a scientific completion.
    Before resuming old supervisors, the amendment records all their unstarted
    extra modes: the old loop skips existing receipts before subprocess launch.
    This fresh-child gate also denies any otherwise unexpected extra start.
    """
    scope = effective_scope(root)
    if is_required(scope, triplet):
        return True
    fid = triplet["fit_ids"][mode]
    path = root / "results/receipts" / (fid + ".json")
    with (root / "ops/assignment.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if path.exists():
            return False
        progress = root / "results/progress" / (fid + ".json")
        if progress.exists() and read(progress).get("status") == "running":
            raise RuntimeError("Refuse to replace a running fit with a scope exclusion")
        record = {"fit_id": fid, "triplet_id": triplet["id"], "mode": mode,
                  "status": "scope_excluded", "numerical_fit_started": False,
                  "reason": "Human retained only the first original paired seed",
                  "scope_amendment": AMENDMENT, "recorded_unix": time.time()}
        write(path, record, immutable=True)
    return False


def authorized_scope_outcome(root, identifier, scope=None):
    scope = effective_scope(root) if scope is None else scope
    if scope is None:
        return False
    receipt = root / "results/receipts" / (identifier + ".json")
    if receipt.exists():
        record = read(receipt)
        return (record.get("status") == "scope_excluded"
                and record.get("numerical_fit_started") is False
                and identifier not in scope["required_fit_ids"])
    if identifier not in scope["excluded_triplet_ids"]:
        return False
    manifest = read(root / "MANIFEST.json")
    triplet = next(t for t in manifest["triplets"] if t["id"] == identifier)
    preserved = set(scope["preserved_started_extra_fit_ids"])
    for fid in triplet["fit_ids"].values():
        path = root / "results/receipts" / (fid + ".json")
        if path.exists():
            if read(path)["status"] not in ("complete", "scope_excluded"):
                return False
        elif fid in preserved:
            return False
    return True


def completion_state(scope, manifest, receipts):
    required = set(scope["required_fit_ids"]) if scope else {f["id"] for f in manifest.get("fits", [])}
    extras = set(scope["preserved_started_extra_fit_ids"]) if scope else set()
    required_complete = sum(receipts.get(fid) == "complete" for fid in required)
    extra_unresolved = sorted(fid for fid in extras if receipts.get(fid) not in ("complete", "failed", "censored"))
    return {"expected_fits": len(required),
            "expected_triplets": scope["required_triplet_count"] if scope else len(manifest["triplets"]),
            "required_complete": required_complete,
            "preserved_extra_fit_count": len(extras),
            "preserved_extra_complete": sum(receipts.get(fid) == "complete" for fid in extras),
            "draining_extra_fit_ids": extra_unresolved,
            "draining_extra_fits": len(extra_unresolved),
            "science_terminal": bool(required) and required_complete == len(required) and not extra_unresolved}


def reconcile_legacy_wait_hold(root):
    """One explicit transition repair for an old check-before-wait supervisor.

    Called by the operator after diagnosing this exact hold, not periodically.
    It cannot clear any genuine numerical failure or an unacknowledged outcome.
    """
    path = root / "ops/ADMISSION_HOLD.json"
    with (root / "ops/assignment.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        hold = read(path)
        fid = hold.get("fit_id", "")
        if hold.get("reason") != "failed_or_censored_fit" or not authorized_scope_outcome(root, fid):
            raise RuntimeError("This hold is not the diagnosed legacy NOT-RUN transition")
        receipt = read(root / "results/receipts" / (fid + ".json"))
        outcome = read(root / "ops/triplet_outcomes" / (receipt["triplet_id"] + ".json"))
        if (outcome["returncode"] != 0 or not all(s in ("complete", "scope_excluded") for s in outcome["statuses"].values())
                or not authorized_scope_outcome(root, receipt["triplet_id"])):
            raise RuntimeError("Old supervisor has not cleanly acknowledged the authorized exclusion")
        for directory in ("results/receipts", "results/progress"):
            if any(read(p).get("status") in ("failed", "censored") for p in (root / directory).glob("*.json")):
                raise RuntimeError("A genuine failed/censored fit must keep admission held")
        if any((root / p).exists() for p in ("ops/ATTEMPT_FAILURE.json", "ops/ACCOUNTING_HOLD.json")):
            raise RuntimeError("Unresolved attempt/accounting hold; preserve admission")
        record = {"hold": hold, "not_run_receipt": receipt, "acknowledged_triplet_outcome": outcome,
                  "reason": "Legacy supervisor checked absent receipt before entering the admission wait; fresh child denied numerical execution",
                  "actual_failed_or_censored_records": 0, "scientific_processes_signalled": 0,
                  "resolved_unix": time.time()}
        write(root / "ops/scope_amendment_20261024_one_seed/LEGACY_WAIT_HOLD_RECONCILED.json", record, immutable=True)
        if read(path) != hold:
            raise RuntimeError("Exact hold changed; do not clear it")
        path.unlink()
    return record


def apply_one_seed_amendment(root):
    """Single metadata mutation under the existing admission hold and lock."""
    expected = {"structural": 101, "data": 151101, "initialization": 161101,
                "shuffle": 171101, "perturbation": 181101}
    manifest = read(root / "MANIFEST.json")
    selected = read(root / "SEEDS.json")["bundles"][0]
    if selected != expected or len(manifest["triplets"]) != 3000 or len(manifest["fits"]) != 9000:
        raise RuntimeError("Original seed ordering or manifest cardinality differs")
    manifest_hash = hashlib.sha256((root / "MANIFEST.json").read_bytes()).hexdigest()
    if manifest_hash != read(root / "source_receipt.json")["manifest_sha256"]:
        raise RuntimeError("Original manifest changed")
    required = [t for t in manifest["triplets"] if t["seeds"] == selected]
    required_tids = {t["id"] for t in required}
    required_fids = {fid for t in required for fid in t["fit_ids"].values()}
    if len(required_tids) != 300 or len(required_fids) != 900:
        raise RuntimeError("The first full original bundle must identify300triplets/900modefits")
    history = root / "ops/scope_amendment_20261024_one_seed"
    history.mkdir(parents=True, exist_ok=True)
    with (root / "ops/assignment.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        hold = read(root / "ops/ADMISSION_HOLD.json")
        if hold.get("reason") != "human_authorized_one_original_seed_scope_reduction":
            raise RuntimeError("Exact human scope-reduction admission hold required")
        if (root / AMENDMENT).exists():
            raise RuntimeError("Amendment already exists; reconcile it rather than applying twice")
        receipts = {p.stem: read(p) for p in (root / "results/receipts").glob("*.json")}
        progress = {p.stem: read(p) for p in (root / "results/progress").glob("*.json")}
        started = {**progress, **receipts}
        if not set(started) <= {f["id"] for f in manifest["fits"]}:
            raise RuntimeError("An existing fit is outside the original manifest")
        if any(r["status"] not in ("running", "complete") for r in started.values()):
            raise RuntimeError("A genuine failed/censored/unresolved fit needs separate reconciliation")
        claims = {p.stem: read(p) for p in (root / "ops/triplet_claims").glob("*.json")}
        excluded = [t for t in manifest["triplets"] if t["id"] not in required_tids]
        not_run = [(t, mode) for t in excluded if t["id"] in claims
                   for mode, fid in t["fit_ids"].items() if fid not in started]
        for t, mode in not_run:
            fid = t["fit_ids"][mode]
            if ((root / "ops/fit_locks" / (fid + ".lock")).exists()
                    or (root / "results/attempts" / fid).exists()):
                raise RuntimeError("Unresolved prior start; do not replace with an exclusion: " + fid)
        extra_started = sorted(set(started) - required_fids)
        after_hold = sorted(fid for fid, record in started.items() if record["started_unix"] > hold["unix"])
        scope = {"status": "human_authorized", "amendment_unix": time.time(),
                 "authorization": "Reduce to one original paired seed per configuration across all three regimes; preserve completed/current fits; stop extra seed starts",
                 "selection_rule": "FIRST original full bundle, chosen by original order before results",
                 "seed_bundle": selected, "original_manifest_sha256": manifest_hash,
                 "original_triplet_count": 3000, "original_fit_count": 9000,
                 "required_triplet_count": 300, "required_fit_count": 900,
                 "required_triplet_ids": sorted(required_tids), "required_fit_ids": sorted(required_fids),
                 "excluded_triplet_ids": sorted(t["id"] for t in excluded),
                 "preserved_started_extra_fit_ids": extra_started,
                 "completed_extra_fits_at_amendment": sum(receipts.get(fid, {}).get("status") == "complete" for fid in extra_started),
                 "inflight_extra_fits_at_amendment": sum(fid not in receipts for fid in extra_started),
                 "started_required_fits_at_amendment": len(set(started) & required_fids),
                 "unstarted_extra_modes_excluded": 8100 - len(extra_started),
                 "legacy_not_run_receipt_count": len(not_run),
                 "starts_after_admission_hold": after_hold,
                 "deadline_unix": read(root / "ops/LAUNCH.json")["deadline_unix"],
                 "numerical_code_changed": False}
        state = read(root / "ops/DISPATCH_STATE.json")
        write(history / "ORIGINAL_DISPATCH_STATE.json", state, immutable=True)
        write(history / "STARTED_FITS_AT_AMENDMENT.json", {
            fid: {k: record.get(k) for k in ("triplet_id", "mode", "status", "pid", "host", "started_unix")}
            for fid, record in started.items()}, immutable=True)
        write(root / AMENDMENT, scope, immutable=True)
        for t, mode in not_run:
            fid = t["fit_ids"][mode]
            write(root / "results/receipts" / (fid + ".json"), {
                "fit_id": fid, "triplet_id": t["id"], "mode": mode, "status": "scope_excluded",
                "numerical_fit_started": False, "scope_amendment": AMENDMENT,
                "reason": "Human excluded unstarted extra-seed mode; old supervisor skips this path",
                "recorded_unix": time.time()}, immutable=True)
        state["pending"] = [tid for tid in state["pending"] if tid in required_tids]
        state["scope_amendment"] = AMENDMENT
        write(root / "ops/DISPATCH_STATE.json", state)
        write(history / "APPLY_RECEIPT.json", {"scope": scope,
            "pending_required_triplets": len(state["pending"]), "claimed_triplets_preserved": len(claims),
            "legacy_not_run_fit_ids": [t["fit_ids"][mode] for t, mode in not_run],
            "healthy_processes_signalled": 0, "unix": time.time()}, immutable=True)
    return scope


if __name__ == "__main__":
    import argparse
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    scope = apply_one_seed_amendment(args.root)
    print(json.dumps({k: v for k, v in scope.items() if not k.endswith("_ids")}))
