"""Runtime evidence for the predictor restriction, before optimizer creation."""
import torch


def verify_predictor(job, model):
    layers = [m for m in model.modules() if isinstance(m, torch.nn.Linear)]
    leaves = [m for m in model.modules() if not list(m.children())]
    arm = job['architecture_arm']
    if arm == 'linear':
        assert job['config']['model']['depth'] == 0
        assert len(layers) == 1, 'Affine-only predictor must contain exactly one trainable affine layer'
        assert all(isinstance(m, (torch.nn.Linear,torch.nn.Sequential)) for m in leaves), \
            'Affine-only predictor contains a neural nonlinearity or other leaf module'
        assert not hasattr(model, 'cost_scale') and not hasattr(model, 'cost_mean'), \
            'Unexpected cost-output affine decoder'
        expected = layers[0].in_features * layers[0].out_features + layers[0].out_features
        assert sum(p.numel() for p in model.parameters()) == expected
    else:
        assert arm == 'neural' and len(layers) == job['config']['model']['depth'] + 1
    return {'status':'verified','architecture_arm':arm,'linear_layers':len(layers),
        'leaf_module_types':[type(m).__name__ for m in leaves],
        'trainable_parameters':sum(p.numel() for p in model.parameters() if p.requires_grad),
        'fixed_training_input_standardization':True,'method_components_preserved':True}
