"""Build the targeted Soft-Radial centered-log-barrier experiment.

The Soft-Radial geometry is frozen from the authenticated three-seed
refinement of the barrier-free comparator.  The screen varies only the new
objective schedule and the effective center learning rate.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from build_feasible_policy_campaigns import DESIGNS, DEVELOPMENT_SEEDS, _base

from proximal_spo.artifacts import source_sha256, write_json
from proximal_spo.config import RunSpec

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPO_ROOT / "configs" / "soft_radial_log_barrier"
ANCHOR_SELECTION = (
    REPO_ROOT / "results" / "feasible_policies" / "development_refinement.json"
)
ANCHOR_SELECTION_SHA256 = (
    "2f2a16b8d4fa2f8acf2707af31c3766cee788854d3ef716bb150be044c104c98"
)

FIXED_ALPHAS = (
    0.0,
    1e-5,
    3e-5,
    1e-4,
    3e-4,
    1e-3,
    3e-3,
    1e-2,
    3e-2,
    1e-1,
    3e-1,
    1.0,
)
HOMOTOPY_STARTS = (1.0, 0.3, 0.1, 0.03)
HOMOTOPY_ENDS = (0.03, 0.01, 0.003, 0.001, 0.0003, 0.0001)
EFFECTIVE_LEARNING_RATES = (3e-6, 1e-5, 3e-5, 1e-4, 3e-4)
HARD_BOUNDARY_ALPHAS = (1.0, 3.0, 10.0, 30.0, 100.0)

# Frozen validation winners from ANCHOR_SELECTION.  These are the only
# barrier-free Soft-Radial quantities carried into the new screen.
GEOMETRY_ANCHORS: dict[str, tuple[float, float]] = {
    "cost.assignment10": (0.1, 0.003),
    "cost.facility30x5_relaxation": (1.0, 0.01),
    "cost.grid5": (0.03, 0.01),
    "cost.knapsack50x5": (10.0, 0.01),
    "cost.random_lp100x50": (0.3, 0.05),
    "cost.topk20x5": (1.0, 0.01),
}


def _tag(value: float) -> str:
    if value == 0.0:
        return "0"
    return f"{value:.0e}".replace("-", "m").replace("+", "p")


def _canonical_sha256(payload: Any) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


def _verify_anchor_selection() -> dict[str, Any]:
    encoded = ANCHOR_SELECTION.read_bytes()
    if hashlib.sha256(encoded).hexdigest() != ANCHOR_SELECTION_SHA256:
        raise ValueError("frozen Soft-Radial anchor selection digest changed")
    payload = json.loads(encoded)
    if not isinstance(payload, dict):
        raise ValueError("frozen Soft-Radial anchor selection is malformed")
    observed: dict[str, tuple[float, float]] = {}
    for row in payload.get("selected_arms", []):
        if row.get("method") != "soft_radial_policy":
            continue
        arm = row.get("arm")
        if not isinstance(arm, dict):
            raise ValueError("selected Soft-Radial anchor lacks its arm")
        parameters = arm.get("method_parameters")
        if not isinstance(parameters, dict):
            raise ValueError("selected Soft-Radial anchor lacks parameters")
        observed[str(row["benchmark_id"])] = (
            float(parameters["contraction_scale"]),
            float(parameters["minimum_scale"]),
        )
    if observed != GEOMETRY_ANCHORS:
        raise ValueError("frozen Soft-Radial geometry anchors do not match receipt")
    return payload


def _schedule_rows() -> list[tuple[str, float, float]]:
    rows = [("fixed", alpha, alpha) for alpha in FIXED_ALPHAS]
    for start in HOMOTOPY_STARTS:
        for end in HOMOTOPY_ENDS:
            if start / end < 10.0:
                continue
            rows.append(("geometric", start, end))
            rows.append(("arithmetic", start, end))
    if len(rows) != 54:
        raise AssertionError("unexpected Soft-Radial barrier schedule count")
    return rows


def _variant(
    *,
    design: Any,
    seed: int,
    schedule: str,
    alpha_start: float,
    alpha_end: float,
    effective_learning_rate: float,
) -> dict[str, Any]:
    contraction_scale, minimum_scale = GEOMETRY_ANCHORS[design.benchmark_id]
    row = _base(design, seed)
    row["name"] = (
        f"{design.tag}_s{seed}_softbar_{schedule}_"
        f"a{_tag(alpha_start)}to{_tag(alpha_end)}_"
        f"elr{_tag(effective_learning_rate)}"
    )
    row["method"] = "soft_radial_log_barrier"
    row["training"]["learning_rate"] = effective_learning_rate / minimum_scale
    row["training"]["weight_decay"] = 0.0
    row["method_parameters"] = {
        "contraction": "rational",
        "contraction_scale": contraction_scale,
        "minimum_scale": minimum_scale,
        "alpha_start": alpha_start,
        "alpha_end": alpha_end,
        "schedule": schedule,
        "anneal_fraction": 0.75,
    }
    return row


def _screen_variants() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for design in DESIGNS:
        for seed in DEVELOPMENT_SEEDS:
            for schedule, alpha_start, alpha_end in _schedule_rows():
                for effective_rate in EFFECTIVE_LEARNING_RATES:
                    rows.append(
                        _variant(
                            design=design,
                            seed=seed,
                            schedule=schedule,
                            alpha_start=alpha_start,
                            alpha_end=alpha_end,
                            effective_learning_rate=effective_rate,
                        )
                    )
    if len(rows) != 4_860:
        raise AssertionError("unexpected Soft-Radial barrier screen size")
    return rows


def _hard_boundary_variants() -> list[dict[str, Any]]:
    """Expand the fixed-alpha boundary while preserving barrier-step scale."""

    rows: list[dict[str, Any]] = []
    for design in DESIGNS:
        for seed in DEVELOPMENT_SEEDS:
            for alpha in HARD_BOUNDARY_ALPHAS:
                for barrier_step in EFFECTIVE_LEARNING_RATES:
                    rows.append(
                        _variant(
                            design=design,
                            seed=seed,
                            schedule="fixed",
                            alpha_start=alpha,
                            alpha_end=alpha,
                            effective_learning_rate=barrier_step / alpha,
                        )
                    )
    if len(rows) != 450:
        raise AssertionError("unexpected hard-deployment boundary screen size")
    return rows


def _smoke_variants() -> list[dict[str, Any]]:
    schedules = (
        ("fixed", 0.0, 0.0),
        ("fixed", 0.03, 0.03),
        ("geometric", 0.3, 0.003),
        ("arithmetic", 0.3, 0.003),
    )
    rows: list[dict[str, Any]] = []
    for design in DESIGNS:
        for schedule, start, end in schedules:
            row = _variant(
                design=design,
                seed=DEVELOPMENT_SEEDS[0],
                schedule=schedule,
                alpha_start=start,
                alpha_end=end,
                effective_learning_rate=3e-5,
            )
            row["name"] = f"{row['name']}_smoke"
            row["workers"] = 1
            row["sizes"] = {"train": 64, "validation": 32, "test": 32}
            row["model"].update({"width": 16, "depth": 1})
            row["training"].update(
                {
                    "epochs": 2,
                    "batch_size": 32,
                    "validation_interval": 1,
                    "patience": 2,
                    "torch_threads": 1,
                }
            )
            rows.append(row)
    return rows


def _write(path: Path, *, name: str, run_root: str, rows: list[dict[str, Any]]) -> None:
    _verify_anchor_selection()
    for row in rows:
        RunSpec.from_dict(row)
    payload = {
        "name": name,
        "run_root": run_root,
        "base": _base(DESIGNS[0], DEVELOPMENT_SEEDS[0]),
        "variants": rows,
        "source_sha256_at_generation": source_sha256(REPO_ROOT),
        "selection_protocol": (
            "validation hard regret is recorded under both soft and "
            "hard-recovered-cost deployment; each deployment selects its own arm"
        ),
        "anchor": {
            "selection_path": str(ANCHOR_SELECTION.relative_to(REPO_ROOT)),
            "selection_file_sha256": ANCHOR_SELECTION_SHA256,
            "selection_payload_sha256": _canonical_sha256(
                _verify_anchor_selection()
            ),
        },
    }
    write_json(path, payload)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("smoke", "screen", "hard-boundary"))
    arguments = parser.parse_args()
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    if arguments.stage == "smoke":
        _write(
            CONFIG_ROOT / "smoke.json",
            name="soft_radial_log_barrier_smoke",
            run_root="runs/soft_radial_log_barrier/smoke",
            rows=_smoke_variants(),
        )
    elif arguments.stage == "screen":
        _write(
            CONFIG_ROOT / "development_screen.json",
            name="soft_radial_log_barrier_development_screen",
            run_root="runs/soft_radial_log_barrier/development_screen",
            rows=_screen_variants(),
        )
    else:
        _write(
            CONFIG_ROOT / "hard_boundary.json",
            name="soft_radial_log_barrier_hard_boundary",
            run_root="runs/soft_radial_log_barrier/hard_boundary",
            rows=_hard_boundary_variants(),
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
