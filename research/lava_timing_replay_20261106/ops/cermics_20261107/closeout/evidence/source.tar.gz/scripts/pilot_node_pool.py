from pathlib import Path
import argparse
from pilot_driver import node_pool
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args();node_pool(a.root)
