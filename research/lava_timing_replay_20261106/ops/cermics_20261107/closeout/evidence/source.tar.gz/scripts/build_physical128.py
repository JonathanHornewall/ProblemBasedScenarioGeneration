"""Freeze the authorized physical FY/NCE/LAVA and common-test128 correction."""
import argparse
import copy
import hashlib
import json
from pathlib import Path

from build_central_path_final import read, sha, write
from build_normal_validation32 import ROUTES

REVISION = "physical_head_test128_20260925_v1"
METHODS = ("pfyl", "nce", "lava")
REMOTE = Path("/home/jonathan.hornewall/runs")


def source_key(job):
    c = job["config"]
    identity = {"route": job["route"], "sizes": c["sizes"],
        "original_sizes": job["original_sizes"], "data_seed": c["seeds"]["data"],
        "reference_samples": c["conditional_reference_samples"],
        "external_commit": "f3bdd0cde748f0ecbef85477c9e4caef1096fc2d"}
    return hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()


def bank_entry(source, seeds):
    j = copy.deepcopy(source)
    j["config"]["seeds"] = seeds
    correction = j["original_sizes"]["validation"] != 32
    j["config"]["sizes"]["validation"] = 32
    run = "normal_validation32_20260925" if correction else "canonical_targeted_20260923"
    key = j["route"] + "__data" + str(seeds["data"])
    return {"key": key, "source_job": j,
            "source_bank": str(REMOTE / run / "frozen_data" / (source_key(j) + ".npz"))}


def mapped_attempt(r):
    p = r["attempt_directory"]
    if not p.startswith("/opt/"):
        return p
    host = "hornewall" if "hornewall" in r["host"] else "tito"
    run = "normal_validation32_20260925" if p.startswith("/opt/normal-validation32/") else "canonical_targeted_20260923"
    return str(REMOTE / run / "cloud_retrieved" / host / "results" / p.split("/results/", 1)[1])


def build(archive, previous, out):
    if (out / "screen.json").exists():
        raise ValueError("Refuse to replace a frozen campaign")
    old = read(archive / "additional_screen.json")
    prior_scope = read(previous / "paper_scope.json")
    unavailable = {(x["cell"], x["method"]) for x in prior_scope["unavailable_groups"]}
    jobs, cells, banks = [], {}, {}
    representatives = {}
    for source in old["jobs"]:
        if source["route"] not in ROUTES or source["config"]["sizes"]["train"] != 100:
            continue
        if source["method"] == "central_path_hard_validation":
            representatives.setdefault(source["route"], source)
        if source["method"] not in METHODS or (source["comparison_cell"], source["method"]) in unavailable:
            continue
        j = copy.deepcopy(source)
        j["cell"] = j["comparison_cell"] + "__physical128"
        j.update(physical128_revision=REVISION, validation_experiment=REVISION,
                 validation_costs="single_sample", analytic_validation=False)
        j.pop("normal_validation_revision", None)
        j.pop("paired_exact_candidate", None)
        c = j["config"]
        c.update(sizes={"train": 100, "validation": 32, "test": 128},
                 physical_cost_output=True, cost_coordinate_normalization="none", evaluate_test=False)
        c.pop("name", None)
        j["candidate"] = sha({"source": source["candidate"], "revision": REVISION,
                               "config": c, "parameters": j["parameters"]})[:16]
        j["id"] = f"screen__{j['cell']}__{j['method']}__{j['candidate']}"
        c["name"] = j["id"]
        jobs.append(j)
        cells[j["cell"]] = copy.deepcopy(old["cells"][source["cell"]])
    for route, source in representatives.items():
        info = old["cells"][source["cell"]]
        for seeds in [source["config"]["seeds"], *info["refinement_seeds"], *info["confirmation_seeds"]]:
            entry = bank_entry(source, seeds)
            banks[entry["key"]] = entry
    assert len(representatives) == 16 and len(banks) == 224
    inherited = read(previous / "screen.json")["protocol"]
    protocol = {k: copy.deepcopy(inherited[k]) for k in (
        "preprocessing_cap_seconds", "training_cap_seconds", "job_wall_cap_seconds",
        "refinement", "confirmation", "deployment_domain", "spo_training_domain",
        "per_cell_method_pipeline", "original_seed_bundles_preserved")}
    protocol.update(method_waves=[list(METHODS)],
        validation="32 fixed observed-cost pairs; selection only",
        test="first128 archived held-out pairs, identical across methods",
        training="100 archived observed pairs; no hidden moments or generator bounds",
        parameterization="direct physical-cost output; observed training-mean bias initialization; no fixed output mean/scale layer",
        validation_resize="reuse the completed ordinary-validation32 banks without changing any observed values",
        final_timing="new FY/NCE/LAVA selections only, repeat0, node09, at most8cores; others retained",
        maximum_lava_heavy_per_host=2)
    screen = {"schema": REVISION, "jobs": jobs, "cells": cells, "methods": list(METHODS),
        "cell_methods": {c: sorted({j['method'] for j in jobs if j['cell'] == c}) for c in cells},
        "protocol": protocol}
    write(out / "screen.json", screen)
    evaluations = []
    rows = read(previous / "test_protocol_audit_20260925/evaluation_time_inputs.json")
    source_receipts = out / "original_receipts"
    for row in rows:
        if row["study"] == "main" and row["method"] in METHODS:
            continue
        source_path = Path(row["receipt"])
        original = read(source_path)
        original_sha = hashlib.sha256(source_path.read_bytes()).hexdigest()
        destination = source_receipts / (original["job"]["id"] + ".json")
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists():
            destination.write_bytes(source_path.read_bytes())
        j = copy.deepcopy(original["job"])
        j.update(id="test128__" + row["study"] + "__" + original["job"]["id"],
            stage="reevaluation", physical128_revision=REVISION,
            original_job=original["job"], original_parameter_sha256=original["summary"]["parameter_sha256"],
            original_receipt_sha256=original_sha,
            original_checkpoint=mapped_attempt(original) + "/model.pt",
            original_training_hashes=original["data_hashes"]["train"],
            study=row["study"], comparison_cell=row["cell"])
        j["config"]["sizes"] = {"train": 100, "validation": 32, "test": 128}
        j["config"]["evaluate_test"] = True
        j["config"]["name"] = j["id"]
        j["resource_limits"] = {"preprocessing_cap_seconds": 600, "job_wall_cap_seconds": 1800}
        evaluations.append(j)
    assert len(evaluations) == 2600
    write(out / "reevaluation.json", {"jobs": evaluations, "selection": "none; frozen model states"})
    groups = sorted({(j["cell"], j["method"]) for j in jobs})
    assert len(groups) == 43
    write(out / "execution.json", {**screen, "jobs": jobs + evaluations, "screen_fingerprint": sha(screen)})
    write(out / "bank_plan.json", {"entries": [banks[k] for k in sorted(banks)]})
    write(out / "burst_contract.json", {"run_id": out.name, "groups": groups,
        "job_ids": [j["id"] for j in evaluations], "maximum_workers": 150,
        "maximum_seconds": 43020, "finite_allocation_seconds": 43200,
        "maximum_cloud_workers": {}, "new_fit_methods": list(METHODS)})
    write(out / "paper_scope.json", {"revision": REVISION, "routes": list(ROUTES),
        "sizes": {"train": 100, "validation": 32, "test": 128},
        "new_fit_groups": groups, "geometry_unavailable_groups": prior_scope["unavailable_groups"],
        "reused_hyperparameter_search_grids": True, "selection_uses_test": False,
        "original_seed_bundles": True, "test_subset_chosen_before_new_results": True,
        "main_expected_method_cells": 107, "main_expected_confirmations": 1070,
        "new_confirmation_expected": 430, "frozen_model_reevaluations": len(evaluations),
        "manuscript_integration_remains_on_hold": True})
    return {"screen_fits": len(jobs), "groups": len(groups), "banks": len(banks),
            "reevaluations": len(evaluations)}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--archive", type=Path, required=True)
    p.add_argument("--previous", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    print(build(a.archive, a.previous, a.output))
