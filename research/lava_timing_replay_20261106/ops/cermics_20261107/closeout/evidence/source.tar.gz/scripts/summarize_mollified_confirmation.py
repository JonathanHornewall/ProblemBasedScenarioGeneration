"""Combine the new mollified arm with the frozen PyEPO baselines."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import tempfile
from pathlib import Path
from typing import Any

from scipy.stats import t as student_t
from summarize_mollified_development import _expected_cells, _seed_key
from summarize_mollified_k_sensitivity import _verify_final_selection

from proximal_spo.analysis import render_confirmation_markdown, summarize_confirmation
from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
BASELINE_LABELS = {"mse", "wise", "spo_plus", "anchored_proximal"}
NEW_LABEL = "mollified_anchored_proximal"
EXPECTED_SEEDS = set(range(11, 21))


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected an object at {path}")
    return payload


def _resolve(path: str) -> Path:
    candidate = Path(path)
    return candidate if candidate.is_absolute() else REPO_ROOT / candidate


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _verify_manifest(lock: dict[str, Any]) -> tuple[Path, str]:
    manifest_path = _resolve(str(lock["evidence_manifest"]))
    expected = str(lock["evidence_manifest_sha256"])
    actual = _sha256(manifest_path)
    if actual != expected:
        raise ValueError("frozen baseline manifest digest changed")
    manifest = _object(manifest_path)
    root = manifest_path.parent
    files = manifest.get("files")
    if not isinstance(files, list) or len(files) != manifest.get("file_count"):
        raise ValueError("frozen baseline manifest is malformed")
    for receipt in files:
        if not isinstance(receipt, dict):
            raise ValueError("malformed file receipt in baseline manifest")
        path = root / str(receipt["path"])
        if not path.is_file() or _sha256(path) != receipt.get("sha256"):
            raise ValueError(f"frozen baseline evidence changed: {path}")
    return _resolve(str(lock["evidence_run_root"])), actual


def _paired_mollified_vs_anchored(rows: list[dict[str, Any]]) -> dict[str, Any]:
    by_label = {
        label: {
            int(row["data_seed"]): float(row["test_mean_regret"])
            for row in rows
            if row["label"] == label
        }
        for label in (NEW_LABEL, "anchored_proximal")
    }
    differences = [
        by_label[NEW_LABEL][seed] - by_label["anchored_proximal"][seed]
        for seed in sorted(EXPECTED_SEEDS)
    ]
    mean = sum(differences) / len(differences)
    variance = sum((value - mean) ** 2 for value in differences) / (
        len(differences) - 1
    )
    standard_error = math.sqrt(variance / len(differences))
    radius = float(student_t.ppf(0.975, len(differences) - 1)) * standard_error
    return {
        "method": NEW_LABEL,
        "baseline": "anchored_proximal",
        "mean_paired_regret_difference": mean,
        "standard_error_paired_difference": standard_error,
        "student_t_95_interval": [mean - radius, mean + radius],
        "wins": sum(value < 0.0 for value in differences),
        "ties": sum(value == 0.0 for value in differences),
        "seed_count": len(differences),
    }


def _require_new_base_receipts(summary: dict[str, Any]) -> None:
    rows = summary.get("rows")
    if not isinstance(rows, list):
        raise ValueError("confirmation summary lacks completed rows")
    new_rows = [row for row in rows if row.get("label") == NEW_LABEL]
    if len(new_rows) != len(EXPECTED_SEEDS) or any(
        row.get("embedded_mse_base_parameter_sha256") is None for row in new_rows
    ):
        raise ValueError(
            "every mollified confirmation run must contain its embedded MSE receipt"
        )


def _verify_confirmation_campaign(
    campaign_path: Path, *, final_selection_path: Path, selection: dict[str, Any]
) -> None:
    campaign = _object(campaign_path)
    receipt = campaign.get("frozen_selection_receipt")
    if not isinstance(receipt, dict):
        raise ValueError("confirmation campaign lacks its frozen selection receipt")
    recorded_path = _resolve(str(receipt.get("path")))
    if recorded_path.resolve() != final_selection_path.resolve():
        raise ValueError("confirmation campaign points to a different final receipt")
    if receipt.get("final_selection_sha256") != _sha256(final_selection_path):
        raise ValueError("confirmation campaign final-selection digest is invalid")
    if receipt.get("source_sha256") != selection.get("source_sha256"):
        raise ValueError("confirmation campaign source differs from final selection")
    if receipt.get("selected_arm_sha256") != selection.get(
        "selected_arm_sha256"
    ):
        raise ValueError("confirmation campaign arm differs from final selection")


def _verify_new_campaign_cells(
    summary: dict[str, Any], campaign_path: Path
) -> None:
    expected = _expected_cells([campaign_path])
    rows = [row for row in summary["rows"] if row["label"] == NEW_LABEL]
    actual = {
        (str(row["arm_sha256"]), _seed_key(row["seeds"])) for row in rows
    }
    if actual != expected or len(rows) != len(expected):
        raise ValueError("mollified confirmation runs differ from their campaign")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("new_run_root", type=Path)
    parser.add_argument("--final-selection", type=Path, required=True)
    parser.add_argument("--expected-campaign", type=Path, required=True)
    parser.add_argument(
        "--baseline-lock",
        type=Path,
        default=REPO_ROOT / "configs" / "mollified_pyepo" / "frozen_baselines.json",
    )
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    arguments = parser.parse_args()

    selection = _verify_final_selection(arguments.final_selection)
    _verify_confirmation_campaign(
        arguments.expected_campaign,
        final_selection_path=arguments.final_selection,
        selection=selection,
    )
    selected_arm_sha = selection.get("selected_arm_sha256")
    source = selection.get("source_sha256")
    if not isinstance(selected_arm_sha, str) or not isinstance(source, str):
        raise ValueError("final selection receipt is malformed")

    lock = _object(arguments.baseline_lock)
    baseline_root, manifest_sha = _verify_manifest(lock)
    sources = lock.get("source_sha256_by_label")
    expected_arms = lock.get("expected_arm_sha256_by_label")
    if not isinstance(sources, dict) or set(sources) != BASELINE_LABELS:
        raise ValueError("baseline source lock is malformed")
    if not isinstance(expected_arms, dict) or set(expected_arms) != BASELINE_LABELS:
        raise ValueError("baseline arm lock is malformed")
    source_by_label = {str(key): str(value) for key, value in sources.items()}
    source_by_label[NEW_LABEL] = source

    with tempfile.TemporaryDirectory(prefix="mollified-confirmation-") as temporary:
        combined = Path(temporary)
        for prefix, root in (
            ("baseline", baseline_root),
            ("mollified", arguments.new_run_root),
        ):
            for index, directory in enumerate(
                sorted(path for path in root.iterdir() if path.is_dir())
            ):
                (combined / f"{prefix}_{index:04d}_{directory.name}").symlink_to(
                    directory.resolve(), target_is_directory=True
                )
        summary = summarize_confirmation(
            combined,
            source_sha256_by_label=source_by_label,
            expected_data_seeds=EXPECTED_SEEDS,
            expected_labels={*BASELINE_LABELS, NEW_LABEL},
        )

    aggregate_arms = {
        str(row["label"]): str(row["arm_sha256"])
        for row in summary["aggregates"]
    }
    for label, digest in expected_arms.items():
        if aggregate_arms.get(label) != digest:
            raise ValueError(f"frozen baseline arm changed for {label}")
    if aggregate_arms.get(NEW_LABEL) != selected_arm_sha:
        raise ValueError("confirmation arm differs from the final selection")
    _verify_new_campaign_cells(summary, arguments.expected_campaign)
    _require_new_base_receipts(summary)
    if summary.get("shared_mse_base_verified") is not True:
        raise ValueError("new method did not reuse the frozen per-seed MSE bases")
    summary["paired_comparisons"].append(
        _paired_mollified_vs_anchored(summary["rows"])
    )
    summary["baseline_evidence"] = {
        "lock": str(arguments.baseline_lock),
        "lock_sha256": _sha256(arguments.baseline_lock),
        "manifest": str(lock["evidence_manifest"]),
        "manifest_sha256": manifest_sha,
    }
    summary["final_selection"] = {
        "path": str(arguments.final_selection),
        "sha256": _sha256(arguments.final_selection),
        "selected_arm_sha256": selected_arm_sha,
    }
    summary["confirmation_campaign"] = {
        "path": str(arguments.expected_campaign),
        "sha256": _sha256(arguments.expected_campaign),
    }
    summary["run_root"] = {
        "frozen_baselines": str(baseline_root),
        "mollified": str(arguments.new_run_root),
    }
    arguments.json_output.parent.mkdir(parents=True, exist_ok=True)
    arguments.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.json_output, summary)
    arguments.markdown_output.write_text(
        render_confirmation_markdown(summary), encoding="utf-8"
    )


if __name__ == "__main__":
    main()
