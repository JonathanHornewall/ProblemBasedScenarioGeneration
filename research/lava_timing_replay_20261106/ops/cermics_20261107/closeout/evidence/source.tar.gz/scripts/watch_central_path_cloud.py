#!/usr/bin/env python3
"""Retrieve verified campaign backups and clean only this run's cloud resources."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import tarfile
import time
from pathlib import Path

from build_central_path_final import read, write


def retire_archived_receipts(local, index):
    for name, digest in index.get("retired_files", {}).items():
        if name in index["files"]:
            continue
        path = (local / name).resolve()
        if not path.is_relative_to(local) or not name.startswith("results/receipts/"):
            raise RuntimeError("Unsafe retired receipt path")
        if not path.exists():
            continue
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise RuntimeError("Refusing to retire a receipt with different contents")
        record = read(path)
        if record.get("status") != "censored" or record.get("error") != "memory_cap":
            raise RuntimeError("Only archived memory-capped attempts may be retired")
        archives = local / "results/resource_retries" / path.stem
        if not any(
            hashlib.sha256(p.read_bytes()).hexdigest() == digest
            for p in archives.glob("*.json")
        ):
            raise RuntimeError("Failed attempt archive must be retrieved first")
        path.unlink()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    args = p.parse_args()
    root = args.root.resolve()
    budget = read(root / "budget.json")
    if (root / "CLOUD_CLEANUP.json").exists():
        return
    local = root / "retrieved"
    blobs = root / "batches"
    local.mkdir(exist_ok=True)
    blobs.mkdir(exist_ok=True)
    base = [
        shutil.which("gcloud"),
        "--configuration=jonathan",
        "--project=hornewall-compute",
    ]
    bucket, run_id = budget["bucket"], budget["run_id"]

    def run(*command, check=True):
        return subprocess.run(
            [*base, *command], text=True, capture_output=True, check=check, timeout=180
        )

    def sync():
        copied = run(
            "storage",
            "cp",
            f"gs://{bucket}/backup/index.json",
            str(root / "latest_index.json"),
            check=False,
        )
        if copied.returncode:
            return False
        index = read(root / "latest_index.json")
        by_blob = {}
        for name, info in index["files"].items():
            dest = (local / name).resolve()
            if not dest.is_relative_to(local):
                raise RuntimeError("Unsafe backup path")
            if (
                dest.exists()
                and hashlib.sha256(dest.read_bytes()).hexdigest() == info["sha256"]
            ):
                continue
            by_blob.setdefault(info["blob"], []).append((name, info))
        for blob, entries in by_blob.items():
            archive_path = blobs / Path(blob).name
            if not archive_path.exists():
                run("storage", "cp", f"gs://{bucket}/{blob}", str(archive_path))
            with tarfile.open(archive_path) as archive:
                for name, info in entries:
                    data = archive.extractfile(name).read()
                    if (
                        len(data) != info["size"]
                        or hashlib.sha256(data).hexdigest() != info["sha256"]
                    ):
                        raise RuntimeError(
                            "Backup checksum mismatch; cloud copy retained"
                        )
                    dest = local / name
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(data)
        retire_archived_receipts(local, index)
        return True

    while True:
        try:
            synced = sync()
            instances = json.loads(
                run(
                    "compute",
                    "instances",
                    "list",
                    f"--filter=labels.run_id={run_id}",
                    "--format=json",
                ).stdout
            )
            write(
                root / "cloud_status.json",
                {
                    "synced": synced,
                    "updated_unix": time.time(),
                    "instances": [
                        {k: i.get(k) for k in ("name", "status", "zone", "scheduling")}
                        for i in instances
                    ],
                },
            )
            for instance in instances:
                if not instance["name"].startswith(run_id + "-"):
                    raise RuntimeError("Unexpected run instance")
                if (
                    instance["status"] == "TERMINATED"
                    or time.time() >= budget["deadline_unix"]
                ):
                    run(
                        "compute",
                        "instances",
                        "delete",
                        instance["name"],
                        "--zone=" + instance["zone"].split("/")[-1],
                        "--quiet",
                    )
            if not instances:
                if not synced or not sync():
                    raise RuntimeError("No verified result index yet; storage retained")
                index = read(root / "latest_index.json")
                for name, info in index["files"].items():
                    if (
                        hashlib.sha256((local / name).read_bytes()).hexdigest()
                        != info["sha256"]
                    ):
                        raise RuntimeError("Final artifact verification failed")
                run("storage", "rm", f"gs://{bucket}", "--recursive", "--quiet")
                disks = json.loads(
                    run("compute", "disks", "list", "--format=json").stdout
                )
                owned = [d for d in disks if d["name"] == budget["instance"]]
                for disk in owned:
                    if disk.get("users"):
                        raise RuntimeError("Run disk unexpectedly remains attached")
                    run(
                        "compute",
                        "disks",
                        "delete",
                        disk["name"],
                        "--zone=" + disk["zone"].split("/")[-1],
                        "--quiet",
                    )
                write(
                    root / "CLOUD_CLEANUP.json",
                    {
                        "run_id": run_id,
                        "bucket_deleted": True,
                        "run_instances_remaining": 0,
                        "run_disks_remaining": 0,
                        "verified_files": len(index["files"]),
                        "finished_unix": time.time(),
                        "results": str(local),
                    },
                )
                return
        except Exception as exc:
            write(
                root / "watcher_retry.json",
                {"error_type": type(exc).__name__, "updated_unix": time.time()},
            )
        time.sleep(60)


if __name__ == "__main__":
    main()
