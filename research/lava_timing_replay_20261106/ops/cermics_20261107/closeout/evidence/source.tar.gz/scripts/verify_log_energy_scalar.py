"""Verify log-energy against the analytic central path on ``[0, 1]``."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import minimize

from proximal_spo.artifacts import source_sha256, write_json
from proximal_spo.benchmarks import build_benchmark
from proximal_spo.objectives import LogEnergyPolicyObjective, TrainingBatch
from proximal_spo.problem import PartialCostInterface

REPO_ROOT = Path(__file__).resolve().parents[1]


def verify(mu: float = 1e-4) -> dict[str, Any]:
    if mu <= 0.0:
        raise ValueError("mu must be positive")
    problem = build_benchmark("analytic.scalar_box", structural_seed=101)
    interface = PartialCostInterface.full_cost(problem)
    objective = LogEnergyPolicyObjective(
        interface,
        mu_start=mu,
        mu_end=mu,
        schedule="fixed",
        energy_guard="exact",
    )
    batch = TrainingBatch(
        contexts=np.zeros((1, 1)),
        coefficients=np.ones((1, 1)),
        physical_costs=np.ones((1, 1)),
        target_decisions=np.zeros((1, 1)),
        target_values=np.zeros(1),
    )

    def value(report: np.ndarray) -> float:
        return float(objective.signal(report.reshape(1, 1), batch).values[0])

    def gradient(report: np.ndarray) -> np.ndarray:
        signal = objective.signal(report.reshape(1, 1), batch)
        return signal.output_gradient.reshape(1)

    try:
        result = minimize(
            value,
            np.zeros(1),
            jac=gradient,
            method="L-BFGS-B",
            options={"gtol": 1e-12, "ftol": 1e-15, "maxiter": 200},
        )
        report = np.asarray(result.x, dtype=np.float64).reshape(1, 1)
        mapped = objective.geometry.log_energy(report, guard_mode="exact")
        reference = objective.geometry.log_energy_reference(report)
        analytic_slack = (
            1.0 + 2.0 * mu - np.sqrt(1.0 + 4.0 * mu**2)
        ) / 2.0
        predicted_slack = float(mapped.decisions[0, 0])
        assert mapped.energy_guard_active is not None
        return {
            "mu": mu,
            "optimizer_success": bool(result.success),
            "optimizer_message": str(result.message),
            "optimizer_iterations": int(result.nit),
            "analytic_central_path_slack": analytic_slack,
            "predicted_slack": predicted_slack,
            "absolute_slack_error": abs(predicted_slack - analytic_slack),
            "report": float(report[0, 0]),
            "report_norm": float(np.linalg.norm(report)),
            "guard_activation": bool(mapped.energy_guard_active[0]),
            "optimized_reference_decision_difference": float(
                np.max(np.abs(mapped.decisions - reference.decisions))
            ),
            "terminal_gradient_norm": float(np.linalg.norm(gradient(result.x))),
            "source_sha256": source_sha256(REPO_ROOT),
        }
    finally:
        objective.close()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mu", type=float, default=1e-4)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("results/log_energy_barrier/scalar_verification.json"),
    )
    arguments = parser.parse_args()
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.output, verify(arguments.mu))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
