"""Return only interrupted ownership from verified deleted campaign VMs."""
import argparse
import hashlib
import json
import sqlite3
import time
from pathlib import Path
from build_central_path_final import read, write


def recover(root):
    proof=read(root/'cloud_shutdown_verified.json')
    assert proof['provider_instances_absent'] and proof['provider_disks_absent']
    db=sqlite3.connect(root/'burst.sqlite',timeout=60);db.row_factory=sqlite3.Row
    rows=list(db.execute("SELECT * FROM jobs WHERE status='external'"));changes=[]
    for row in rows:
        host=row['host'];assert host in proof['hosts']
        final=proof['hosts'][host]['relay_cleanup'];assert final['status']=='deleted'
        snapshot=root/'cloud_retrieved'/host
        hashes=read(snapshot/'retrieval_hashes.json')
        receipt=root/'results/receipts'/(row['id']+'.json')
        if receipt.exists():
            changes.append({'id':row['id'],'host':host,'new_status':'terminal'});continue
        relative='results/interruptions/'+row['id']+'.json'
        p=snapshot/relative
        assert relative in hashes and hashlib.sha256(p.read_bytes()).hexdigest()==hashes[relative]
        interrupted=read(p)
        assert interrupted['job']==json.loads(row['payload'])
        changes.append({'id':row['id'],'host':host,'new_status':'pending',
                        'preserved_interruption':str(p),'interruption_sha256':hashes[relative]})
    if not changes:return []
    archive=root/'infrastructure_repairs/cloud_shutdown_20260924'
    if (archive/'recovery.json').exists():raise RuntimeError('Existing recovery must be reconciled explicitly')
    write(archive/'before.json',{'proof':proof,'rows':[dict(x) for x in rows],'changes':changes})
    db.execute('BEGIN IMMEDIATE')
    try:
        for row in changes:
            updated=db.execute("UPDATE jobs SET status=?,host=NULL,worker=NULL,started=NULL,heartbeat=NULL,rss=0 WHERE id=? AND status='external' AND host=?",(row['new_status'],row['id'],row['host'])).rowcount
            if updated!=1:raise RuntimeError('Ownership changed concurrently')
        db.commit()
    except BaseException:db.rollback();raise
    finally:db.close()
    write(archive/'recovery.json',{'updated_unix':time.time(),'changes':changes,
        'no_live_external_leases_released':True,'valid_receipts_untouched':True})
    return changes


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args();print(json.dumps(recover(a.root)))
