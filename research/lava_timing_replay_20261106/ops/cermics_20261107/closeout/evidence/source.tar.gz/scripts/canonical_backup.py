"""Independent local backup; large transfers never block scientific dispatch."""
import argparse
import subprocess
import time
from pathlib import Path
from build_central_path_final import read,write


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args()
    target=a.root/'cluster_retrieved';target.mkdir(exist_ok=True)
    while True:
        try:
            config=read(a.root/'fleet.json')
            base=['rsync','-az','--partial','--partial-dir=.rsync-partial','--timeout=90','-e',"ssh -o BatchMode=yes -o ConnectTimeout=15 -o ControlMaster=no -o ControlPath=none -o 'ProxyCommand=ssh -o ControlMaster=no -o ControlPath=none -o BatchMode=yes -o ConnectTimeout=15 -W %h:%p passerelle_enpc'"]
            endpoints=['shared_cluster:'+config['cluster_root']+'/',str(target)+'/']
            write(a.root/'backup_status.json',{'updated_unix':time.time(),'status':'syncing','phase':'metadata'})
            # Receipts, frozen selections and analytic references must not wait
            # behind gigabytes of model checkpoints and archived attempts.
            metadata=[*base,'--include=/*.json','--include=/results/',
                      '--include=/results/receipts/','--include=/results/receipts/*.json',
                      '--include=/results/selections/','--include=/results/selections/*.json',
                      '--include=/frozen_validation/','--include=/frozen_validation/*.npz',
                      '--exclude=*',*endpoints]
            subprocess.run(metadata,check=True,timeout=1800)
            write(a.root/'backup_status.json',{'updated_unix':time.time(),'status':'syncing','phase':'bulk',
                  'metadata_synced_unix':time.time(),'receipts_retrieved':len(list((target/'results/receipts').glob('*.json')))})
            cmd=[*base,
                 *['--exclude='+x for x in ['code/','venv','external','public','*.sqlite*','*.tar.gz','geometry_cache/','imports/','cloud_retrieved/','cloud_ssh_key','cloud_known_hosts']],
                 '--exclude=pipeline_addition_preflight/',*endpoints]
            subprocess.run(cmd,check=True,timeout=1800)
            write(a.root/'backup_status.json',{'updated_unix':time.time(),'status':'synced'})
        except Exception as e:
            write(a.root/'backup_status.json',{'updated_unix':time.time(),'status':'retrying','error':str(e)})
        time.sleep(30)
