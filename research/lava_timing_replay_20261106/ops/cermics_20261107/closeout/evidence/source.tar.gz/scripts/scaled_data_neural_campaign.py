"""Scientific metadata for nested-data and separately tuned GELU campaigns.

This module never provisions a machine or starts a fit. A fleet operator owns
exclusive placement of READY IDs and returns immutable terminal receipts.
"""
from __future__ import annotations

import argparse
import collections
import copy
import gzip
import math
import os
from pathlib import Path

from pilot_common import CPS, EPOCHS, SMALLEST, digest, family, read, sha, write
import simplified_campaign as linear
import frozen_nonlinear_retuning as nonlinear

REVISION = 'scaled_data_neural_20261021_v1'
PHASES = [
    {'id': 'linear_n500', 'train': 500, 'epochs': 134, 'depth': 0, 'tune': False},
    {'id': 'linear_n1000', 'train': 1000, 'epochs': 95, 'depth': 0, 'tune': False},
    {'id': 'mlp_depth2', 'train': 100, 'epochs': 300, 'depth': 2, 'tune': True},
    {'id': 'mlp_depth1', 'train': 100, 'epochs': 300, 'depth': 1, 'tune': True},
    {'id': 'mlp_depth3', 'train': 100, 'epochs': 300, 'depth': 3, 'tune': True},
]
METHODS = linear.METHODS
DEPTH_SETS = [(0, 2), (0, 2, 3), (0, 1, 2, 3)]
RETUNING_PHASES = [
    {'id': 'linear_retune_n300', 'train': 300, 'epochs': 300, 'depth': 0, 'tune': True},
    {'id': 'linear_retune_n500', 'train': 500, 'epochs': 300, 'depth': 0, 'tune': True},
    {'id': 'linear_retune_n1000', 'train': 1000, 'epochs': 300, 'depth': 0, 'tune': True},
]
RETUNING_VALIDATION_SAMPLES = {300: 96, 500: 160, 1000: 320}


def effective_plan(root, plan=None):
    return nonlinear.extend_plan(root, _linear_effective_plan(root, plan))


def _linear_effective_plan(root, plan=None):
    """Apply the explicit run amendment without rewriting immutable PLAN.json."""
    root = Path(root)
    result = copy.deepcopy(read(root/'PLAN.json') if plan is None else plan)
    path = root/'SCHEDULING_AMENDMENT_20261021.json'
    if not path.exists():
        return result
    amendment = read(path)
    extension = amendment.get('follow_on_larger_data_retuning')
    if extension is None:
        return result
    expected = {'training_samples': [300,500,1000], 'architecture_depth': 0, 'epochs': 300,
        'validation_samples_by_training_size': {str(n):v for n,v in RETUNING_VALIDATION_SAMPLES.items()},
        'test_samples': 100, 'batch_size': 32, 'final_seed_bundles': 10}
    mismatched = [k for k,v in expected.items() if extension.get(k) != v]
    if mismatched or 'validation_samples' in extension:
        # A pending amendment must not stop independent, already-authorized
        # neural work. No new retuning phase is admitted until it is explicit.
        result['deferred_phase_extension'] = {'amendment': path.name,
            'reason': 'Retuning protocol is incomplete or differs from the authorized protocol',
            'mismatched_fields': mismatched + (['validation_samples'] if 'validation_samples' in extension else [])}
        return result
    retained = read(root/'SCOPE_AMENDMENT.json')['retained_methods']
    if set(retained) != set(linear.MAIN):
        raise ValueError('Linear retuning requires the currently retained eight methods')
    existing = {p['id'] for p in result['phases']}
    for phase in RETUNING_PHASES:
        if phase['id'] not in existing:
            result['phases'].append({**phase, 'validation': RETUNING_VALIDATION_SAMPLES[phase['train']],
                'retained_methods': list(retained)})
    result['effective_phase_extension'] = {'amendment': path.name,
        'amendment_id': amendment['id'], 'authority_field': 'follow_on_larger_data_retuning',
        'added_phases': [p['id'] for p in RETUNING_PHASES],
        'validation_samples_by_training_size': expected['validation_samples_by_training_size']}
    return result


def checkpoint_epochs(horizon):
    return sorted({e for e in EPOCHS if e <= horizon} | {horizon})


def make_job(template, method, route, seeds, choices, phase, *, stage='screen'):
    """Keep the maintained losses, coordinate maps and optimizer definitions."""
    j = linear.make_job(template, method, route, seeds, copy.deepcopy(choices), stage=stage)
    c = j['config']
    c.pop('name', None)
    j.pop('linear_scale_revision', None)
    j.update(scaled_data_neural_revision=REVISION, campaign_phase=phase['id'],
             architecture_arm='linear' if phase['depth'] == 0 else 'neural',
             architecture_depth=phase['depth'],
             required_data_key=route + '__data' + str(seeds['data']))
    c['sizes']['train'] = phase['train']
    if 'validation' in phase:
        c['sizes']['validation'] = phase['validation']
    c['model'].update(depth=phase['depth'], width=64, activation='gelu',
                      correction_depth=0, correction_width=64, layer_norm=False)
    c['training'].update(epochs=phase['epochs'], schedule_reference_epochs=phase['epochs'],
        validation_epochs=checkpoint_epochs(phase['epochs']), validation_interval=phase['epochs'],
        patience=phase['epochs'] + 1)
    if phase['id'] in nonlinear.PHASE_IDS:
        j['frozen_nonlinear_retuning_revision'] = nonlinear.REVISION
        j['frozen_depth_choice'] = copy.deepcopy(phase['frozen_depth_choice'])
        j['frozen_nonlinear_runtime_commit'] = phase.get('runtime_source_commit')
    if stage == 'timing':
        j.update(frozen_horizon=phase['epochs'], require_site='cermics',
                 timing_hardware_group=REVISION + '__fixed_cermics_core')
    j['candidate'] = digest({'phase': phase['id'], 'method': j['method'], 'choices': choices,
        'model': c['model'], 'training_sizes': c['sizes']})[:20]
    j['id'] = 'sdn__' + digest(j)[:32]
    c['name'] = j['id']
    return j


def manifest(job):
    return {'protocol': {'scaled_data_neural_revision': REVISION}, 'jobs': [job]}


def environment(root):
    root = Path(root)
    env = linear.environment(root)
    env.update(SCALED_DATA_NEURAL_ROOT=str(root), SIMPLIFIED_ROOT=str(root))
    return env


def validate_execution(job):
    import socket
    if os.environ.get('CFL_PER_SIZE_ROOT'):
        from cfl_per_size_retuning import validate_execution as validate_cfl
        return validate_cfl(job)
    if job.get('scaled_data_neural_revision') != REVISION:
        raise ValueError('Unknown scaled-data/neural revision')
    if job['training_oracle'] != 'continuous_relaxation':
        raise ValueError('New campaign contains no integer training or retuning')
    phase = next((p for p in PHASES if p['id'] == job['campaign_phase']), None)
    if phase is None and job['campaign_phase'] in ({p['id'] for p in RETUNING_PHASES} | nonlinear.PHASE_IDS):
        root = os.environ.get('SCALED_DATA_NEURAL_ROOT')
        if root:
            phase = next((p for p in effective_plan(root,{'phases':PHASES})['phases'] if p['id']==job['campaign_phase']),None)
            if phase is not None and job['method'] not in phase['retained_methods']:
                raise ValueError('Method excluded from the authorized larger-data retuning')
            if phase is not None and phase['id'] in nonlinear.PHASE_IDS:
                phase = nonlinear.resolve_phase(root, phase, job['method'], family(job['route']))
                if (phase is None or job.get('frozen_depth_choice') != phase['frozen_depth_choice']
                        or job.get('frozen_nonlinear_retuning_revision') != nonlinear.REVISION
                        or job.get('frozen_nonlinear_runtime_commit') != phase['runtime_source_commit']):
                    raise ValueError('Missing or changed frozen nonlinear depth choice')
    if phase is None or (job['config']['sizes']['train'], job['config']['sizes']['validation'],
                         job['config']['sizes']['test'], job['config']['training']['epochs'],
                         job['config']['model']['depth']) != (phase['train'], phase.get('validation',32),
                         100, phase['epochs'], phase['depth']):
        raise ValueError('Unregistered sample counts/training horizon/architecture')
    if job['stage'] == 'timing':
        if os.environ.get('SCALED_DATA_NEURAL_SITE') != 'cermics' or not os.environ.get('SLURM_JOB_ID'):
            raise RuntimeError('Controlled timing fits require CERMICS Slurm')
        if hasattr(os, 'sched_getaffinity') and len(os.sched_getaffinity(0)) != 1:
            raise RuntimeError('Controlled timing fit must be bound to one CPU')
        root=Path(os.environ['SCALED_DATA_NEURAL_ROOT'])
        contract=read(root/'ops/TIMING_CONTRACT.json')
        affinity=sorted(os.sched_getaffinity(0))
        host=socket.gethostname().split('.',1)[0]
        if host!=contract['node'].split('.',1)[0] or affinity!=[contract['logical_cpu']]:
            raise RuntimeError('Timing host/CPU differs from fixed CERMICS hardware contract')
        topo=Path('/sys/devices/system/cpu')/f'cpu{affinity[0]}'/'topology'
        return {'site':'cermics','host':socket.gethostname(),'logical_cpu':affinity[0],
            'physical_package_id':(topo/'physical_package_id').read_text().strip(),
            'physical_core_id':(topo/'core_id').read_text().strip(),
            'slurm_job_id':os.environ['SLURM_JOB_ID'],'affinity':affinity,
            'load_average':list(os.getloadavg()),'hardware_group':job['timing_hardware_group'],
            'contract_sha256':sha(root/'ops/TIMING_CONTRACT.json'),
            'claim':'matched hardware and private Slurm core; shared-host contention possible'}
    return {'host':socket.gethostname(),
        'affinity':sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else None,
        'site':os.environ.get('SCALED_DATA_NEURAL_SITE','unspecified'),
        'scientific_training_oracle':'continuous_relaxation'}


def verify_predictor(job, model):
    import torch
    layers = [m for m in model.modules() if isinstance(m, torch.nn.Linear)]
    nonlinear = [m for m in model.modules() if isinstance(m, torch.nn.GELU)]
    depth = job['architecture_depth']
    if len(layers) != depth + 1 or len(nonlinear) != depth:
        raise ValueError('Constructed predictor differs from declared GELU depth')
    if any(m.out_features != 64 for m in layers[:-1]):
        raise ValueError('Every hidden layer must have width64')
    return {'status': 'verified', 'architecture_arm': job['architecture_arm'],
        'hidden_depth': depth, 'hidden_width': 64, 'activation': 'gelu',
        'linear_layers': len(layers), 'gelu_layers': len(nonlinear),
        'trainable_parameters': sum(p.numel() for p in model.parameters() if p.requires_grad),
        'fixed_training_input_standardization': True, 'method_components_preserved': True}


def build(linear_root, scalar_path, root):
    old = read(Path(linear_root) / 'PLAN.json')
    with gzip.open(scalar_path, 'rt') as stream:
        scalars = __import__('json').load(stream)
    if scalars['counts']['finals'] != 2200 or len(scalars['milestones']) != 12:
        raise ValueError('Completed linear scientific input is incomplete')
    selections = {}
    for value in scalars['selections'].values():
        if value['test_scores_read'] or value['selected_template'] is None or value['unavailable']:
            raise ValueError('Linear configuration is not a complete validation-only selection')
        selections[value['method'] + '__' + value['family']] = copy.deepcopy(value)
    if len(selections) != 44:
        raise ValueError('Expected44 distinct applicable method/family selections')
    expected_final = sum(10 for m in METHODS for r in old['routes'] if linear.applicable(m, r))
    expected_screen = sum(len(linear.grid(m)) for m in METHODS for r in SMALLEST.values()
                          if linear.applicable(m, r))
    if (expected_final, expected_screen) != (2200, 14016):
        raise ValueError('Changed method applicability or grid')
    plan = {'revision': REVISION, 'phases': PHASES, 'method_order': linear.MAIN,
        'wise_stage_order': linear.WISE, 'logical_aliases': {'wise_mse': 'wise'},
        'routes': old['routes'], 'cells': old['cells'], 'smallest_routes': SMALLEST,
        'templates': old['templates'], 'bank_keys': old['bank_keys'],
        'linear_selections': selections, 'source_linear_root': str(linear_root),
        'source_linear_plan_sha256': sha(Path(linear_root) / 'PLAN.json'),
        'source_linear_scalar_sha256': sha(scalar_path), 'source_linear_source': scalars['source_receipt'],
        'counts': {'larger_data_finals_per_size': 2200, 'larger_data_screens': 0,
            'neural_screens_per_depth': 14016, 'neural_finals_per_depth': 2200,
            'science_total': 2 * 2200 + 3 * (14016 + 2200), 'timings_per_phase': 220,
            'timings_total': 1100, 'integer_fits': 0},
        'architecture_depth_sets': [list(s) for s in DEPTH_SETS],
        'architecture_selection': 'each method/family: smallest-family observed validation score only; transfer chosen depth across family routes; no test minima',
        'phase_barrier': 'previous science terminal; controlled serial timings never block next science phase',
        'terminal_policy': 'complete/failed/censored immutable, no automatic failed-fit retry',
        'training_data_policy': 'nested500/1000 with exact old100 prefix; fit opens only supplied training-size bank',
        'held_out_policy': 'exact reused observed validation32 and sealed analytic-reference test100',
        'optimizer': old['optimizer'], 'runtime_timing_site': 'cermics'}
    write(Path(root) / 'PLAN.json', plan, immutable=True)
    write(Path(root) / 'BUILD_COUNTS.json', plan['counts'], immutable=True)
    return plan


def successful(record, job):
    s = record.get('summary', {}) if record else {}
    return bool(record and record['status'] == 'complete' and not record.get('smoke_only')
        and s.get('epochs_completed') == job['config']['training']['epochs']
        and not s.get('optimization_cap_reached'))


def development_score(record, job):
    if record and (record.get('test_access') or record.get('test_bank_opened') or record.get('summary', {}).get('test') is not None):
        raise ValueError('Development configuration selection received test information')
    if not successful(record, job):
        return None
    v = float(record['summary']['best_selection_score'])
    return v if math.isfinite(v) else None


class Campaign:
    def __init__(self, root, max_new_manifests=512):
        if max_new_manifests < 1:
            raise ValueError('New manifest admission budget must be positive')
        self.root = Path(root)
        self.plan = effective_plan(self.root)
        self.records = {}
        self.required = {}
        self.science_ready = []
        self.timing_ready = []
        self.selections = {}
        self.max_new_manifests = max_new_manifests
        self.new_manifests = 0
        self.deferred_manifests = set()
        self.waiting_retuning_data = set()
        self.waiting_retuning_validation = set()
        self.retuning_readiness = {}
        self.resolved_phases = {}
        self.waiting_frozen_depths = set()

    def phase_for(self, phase, method, fam):
        if phase['id'] not in nonlinear.PHASE_IDS:
            return phase
        key = (phase['id'], method, fam)
        if key not in self.resolved_phases:
            self.resolved_phases[key] = nonlinear.resolve_phase(
                self.root, phase, method, fam, freeze=True)
        result = self.resolved_phases[key]
        if result is None:
            self.waiting_frozen_depths.add(method + '__' + fam)
        return result

    def retuning_data_ready(self, phase, bank, *, development):
        if phase['id'] not in ({p['id'] for p in RETUNING_PHASES} | nonlinear.PHASE_IDS):
            return True
        key = (phase['id'],bank,development)
        if key in self.retuning_readiness:
            return self.retuning_readiness[key]
        location = self.root/'frozen_data'
        training = location/'retuning_development'/bank if development else location/bank
        receipt = training/'receipt.json'
        stored_n = 500 if phase['train']==300 else phase['train']
        train_ready = receipt.exists() and stored_n in read(receipt).get('available_train_sizes',[])
        if not train_ready:
            self.waiting_retuning_data.add(bank)
        receipt = location/'retuning_validation'/bank/'receipt.json'
        validation_ready = receipt.exists() and phase['validation'] in read(receipt).get('available_validation_sizes',[])
        if not validation_ready:
            self.waiting_retuning_validation.add(bank)
        self.retuning_readiness[key] = train_ready and validation_ready
        return self.retuning_readiness[key]

    def require(self, job):
        path = self.root / 'jobs' / (job['id'] + '.json')
        receipt = self.root / 'results/receipts' / (job['id'] + '.json')
        phase = next((p for p in self.plan['phases'] if p['id']==job['campaign_phase']),None)
        if not receipt.exists() and phase is not None and not self.retuning_data_ready(
                phase,job['required_data_key'],development=job['stage']=='screen'):
            return None
        if not path.exists():
            # Existing terminal evidence is reconciled even at the admission
            # limit. Missing, deferred candidates are neither ready nor terminal.
            if self.new_manifests >= self.max_new_manifests and not receipt.exists():
                self.deferred_manifests.add(job['id'])
                return None
            self.new_manifests += 1
        write(path, manifest(job), immutable=True)
        self.required[job['id']] = job
        if not receipt.exists():
            return None
        if job['id'] not in self.records:
            value = read(receipt)
            if digest(value['job']) != digest(job) or value.get('status') not in ('complete', 'failed', 'censored'):
                raise ValueError('Terminal receipt job identity/status differs: ' + job['id'])
            self.records[job['id']] = value
        return self.records[job['id']]

    def ready(self, job, record):
        if record is None and job['id'] in self.required:
            target = self.timing_ready if job['stage'] == 'timing' else self.science_ready
            target.append({'id': job['id'], 'phase': job['campaign_phase'], 'method': job['method'],
                'stage': job['stage'], 'manifest': 'jobs/' + job['id'] + '.json',
                'memory_gib': linear.provision(job), 'required_data_key': job['required_data_key'],
                'require_site': job.get('require_site')})

    def selected(self, phase, method, fam):
        key = (phase['id'], method, fam)
        if key in self.selections:
            return self.selections[key]
        phase = self.phase_for(phase, method, fam)
        if phase is None:
            self.selections[key] = None
            return None
        if not phase['tune']:
            source = self.plan['linear_selections'][method + '__' + fam]
            selected = {**copy.deepcopy(source), 'phase': phase['id'],
                'selection_origin': 'completed linear smallest-family observed validation',
                'new_screen_fits': 0}
        else:
            route = SMALLEST[fam]
            if phase['id'] in ({p['id'] for p in RETUNING_PHASES} | nonlinear.PHASE_IDS):
                seed = self.plan['cells'][route]['screen']['data']
                bank = route+'__data'+str(seed)
                if not self.retuning_data_ready(phase,bank,development=True):
                    self.selections[key] = None
                    return None
            jobs = [make_job(self.plan['templates'][linear.base_method(method)], method, route,
                self.plan['cells'][route]['screen'], q, phase) for q in linear.grid(method)]
            records = [self.require(j) for j in jobs]
            for j, r in zip(jobs, records):
                self.ready(j, r)
            if any(r is None for r in records):
                self.selections[key] = None
                return None
            eligible = [(development_score(r, j), i, j) for i, (j, r) in enumerate(zip(jobs, records))]
            eligible = sorted((v for v in eligible if v[0] is not None), key=lambda v: (v[0], v[1]))
            selected = {'phase': phase['id'], 'method': method, 'family': fam,
                'selected_template': eligible[0][2] if eligible else None,
                'score': eligible[0][0] if eligible else None, 'screen_fits': len(jobs),
                'test_scores_read': False,
                'unavailable': [{'id': j['id'], 'status': r['status'], 'error': r.get('error')}
                    for j, r in zip(jobs, records) if not successful(r, j)],
                'tie_rule': 'observed validation score then declared Cartesian candidate order',
                'final_checkpoint_rule': 'each refit selects on its own observed validation'+str(phase.get('validation',32))}
        write(self.root / 'selections' / phase['id'] / (method + '__' + fam + '.json'), selected, immutable=True)
        self.selections[key] = selected
        return selected

    def method_group(self, phase, methods):
        terminal = True
        for method in methods:
            if method not in phase.get('retained_methods', METHODS):
                continue
            finals, records, unavailable = [], [], []
            for route in self.plan['routes']:
                if not linear.applicable(method, route):
                    continue
                selection = self.selected(phase, method, family(route))
                if selection is None:
                    terminal = False
                    continue
                template = selection['selected_template']
                if template is None:
                    unavailable.append(route)
                    continue
                for seed in self.plan['cells'][route]['confirmation']:
                    resolved = self.phase_for(phase, method, family(route))
                    job = make_job(template, method, route, seed, template['choices'], resolved, stage='confirmation')
                    record = self.require(job)
                    self.ready(job, record)
                    finals.append(job)
                    records.append(record)
            method_terminal = all(r is not None for r in records) and all(
                self.selected(phase, method, f) is not None for f,r in SMALLEST.items() if linear.applicable(method,r))
            if not method_terminal:
                terminal = False
            else:
                write(self.root / 'milestones' / phase['id'] / (method + '.json'),
                    {'phase': phase['id'], 'method': method, 'final_fits': len(finals),
                     'counts': dict(collections.Counter(r['status'] for r in records)),
                     'unavailable_routes': unavailable, 'fit_ids': [j['id'] for j in finals]}, immutable=True)
        return terminal

    def phase_timings(self, phase):
        for method in METHODS:
            if method not in phase.get('retained_methods', METHODS):
                continue
            for route in self.plan['routes']:
                if not linear.applicable(method, route):
                    continue
                selection = self.selected(phase, method, family(route))
                if selection is None or selection['selected_template'] is None:
                    continue
                t = selection['selected_template']
                j = make_job(t, method, route, self.plan['cells'][route]['confirmation'][0],
                             t['choices'], self.phase_for(phase, method, family(route)), stage='timing')
                self.ready(j, self.require(j))

    def architecture_choices(self):
        for allowed in DEPTH_SETS:
            phase_for_depth = {0: None, 1: 'mlp_depth1', 2: 'mlp_depth2', 3: 'mlp_depth3'}
            choices = []
            ready = True
            for method in METHODS:
                for fam,route in SMALLEST.items():
                    if not linear.applicable(method,route):
                        continue
                    scores = []
                    for depth in allowed:
                        phase_id = phase_for_depth[depth]
                        if depth == 0:
                            s = self.plan['linear_selections'][method + '__' + fam]
                        else:
                            path = self.root/'selections'/phase_id/(method+'__'+fam+'.json')
                            if not path.exists():
                                ready = False
                                break
                            s = read(path)
                        if s['selected_template'] is not None:
                            scores.append((s['score'], depth, s))
                    if len(scores) != len(allowed):
                        ready = False
                        continue
                    best = min(scores, key=lambda row:(row[0],row[1]))
                    choices.append({'method': method, 'family': fam, 'allowed_depths': list(allowed),
                        'selected_depth': best[1], 'score': best[0],
                        'scores': {str(d): v for v,d,s in scores},
                        'selected_phase': phase_for_depth[best[1]] or 'completed_linear_n100',
                        'selected_candidate': best[2]['selected_template']['candidate'],
                        'selection_data': 'smallest-family development observed validation32',
                        'test_scores_read': False})
            if ready:
                write(self.root/'architecture_choices'/('depths_'+'_'.join(map(str,allowed))+'.json'),
                    {'choices': choices, 'applies_to': 'all five family sizes and ten paired final seeds',
                     'tie_rule': 'lower depth on exact validation-score tie', 'test_scores_read': False}, immutable=True)

    def advance(self):
        phases_terminal = []
        active_phases = []
        terminal_phases = []
        for phase in self.plan['phases']:
            main_done = self.method_group(phase, linear.MAIN)
            wise_done = self.method_group(phase, linear.WISE)
            if not (main_done and wise_done):
                active_phases.append(phase['id'])
            else:
                phases_terminal.append(phase['id'])
                terminal_phases.append(phase)
        # Admit science first. Optional timing materialization cannot consume
        # the prefetch budget before later independent scientific phases.
        for phase in terminal_phases:
            self.phase_timings(phase)
        active = active_phases[0] if active_phases else None
        self.architecture_choices()
        nonlinear.write_linear_comparisons(self.root, self.plan)
        phase_order = {p['id']:i for i,p in enumerate(self.plan['phases'])}
        order = lambda r:(phase_order[r['phase']], METHODS.index(r['method']), r['stage']!='confirmation', r['id'])
        self.science_ready.sort(key=order)
        self.timing_ready.sort(key=order)
        ready_phases = list(dict.fromkeys(r['phase'] for r in self.science_ready))
        admission = {'admission_policy': 'priority_ready_v1',
            'active_science_phases': active_phases, 'ready_science_phases': ready_phases,
            'max_new_manifests': self.max_new_manifests,
            'new_manifests': self.new_manifests,
            'deferred_missing_manifests': len(self.deferred_manifests),
            'waiting_retuning_development_banks': sorted(self.waiting_retuning_data),
            'waiting_retuning_validation_banks': sorted(self.waiting_retuning_validation),
            'waiting_frozen_nonlinear_depths': sorted(self.waiting_frozen_depths),
            'effective_nonlinear_phase_extension': self.plan.get('effective_nonlinear_phase_extension'),
            'deferred_nonlinear_phase_extension': self.plan.get('deferred_nonlinear_phase_extension'),
            'effective_phase_extension': self.plan.get('effective_phase_extension'),
            'deferred_phase_extension': self.plan.get('deferred_phase_extension')}
        write(self.root/'READY.json', {'science': self.science_ready, 'timing': self.timing_ready,
            'active_science_phase': active, 'terminal_science_phases': phases_terminal,
            'dispatch_phase_order': [p['id'] for p in self.plan['phases']],
            'dispatch_method_order': list(METHODS),
            **admission,
            'exclusive_assignment_owner': 'fleet operator; one host per fit ID',
            'updated_unix': __import__('time').time()})
        status = {'revision': REVISION, 'active_science_phase': active,
            **admission,
            'terminal_science_phases': phases_terminal,
            'pending_science': len(self.science_ready), 'pending_timing': len(self.timing_ready),
            'registered_jobs': len(self.required),
            'terminal_counts': dict(collections.Counter(r['status'] for r in self.records.values())),
            'science_terminal': active is None and not self.plan.get('deferred_phase_extension')
                and not self.plan.get('deferred_nonlinear_phase_extension'),
            'all_terminal': active is None and not self.timing_ready and not self.deferred_manifests
                and not self.plan.get('deferred_phase_extension')
                and not self.plan.get('deferred_nonlinear_phase_extension'),
            'updated_unix': __import__('time').time()}
        write(self.root/'STATUS.json',status)
        return status


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    b=sub.add_parser('build');b.add_argument('--root',type=Path,required=True)
    b.add_argument('--linear-root',type=Path,required=True);b.add_argument('--linear-scalars',type=Path,required=True)
    a=sub.add_parser('advance');a.add_argument('--root',type=Path,required=True)
    a.add_argument('--max-new-manifests',type=int,default=512)
    args=parser.parse_args()
    if args.command=='build':
        plan=build(args.linear_root,args.linear_scalars,args.root)
        print(__import__('json').dumps(plan['counts']))
    else:
        import fcntl
        with (args.root/'advance.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            print(__import__('json').dumps(Campaign(args.root,args.max_new_manifests).advance()))


if __name__=='__main__':
    main()
