"""Freeze new ablations and original IntOpt against the final archived banks."""
from __future__ import annotations
import argparse
import collections
import copy
import gzip
import hashlib
import json
from pathlib import Path

from build_central_path_final import sha, write

REVISION = "physical_head_test128_20260925_v1"
VARIANTS = {
    "central_path_no_guard": {"report_guard": False},
    "central_path_no_center_scale": {"barrier_cost_scaling": "unit"},
    "central_path_neither": {"report_guard": False, "barrier_cost_scaling": "unit"},
}
MU_CUTOFFS = [1e-1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6]
FULL_CAMPAIGN_METHODS = ["central_path_hard_validation", "mse", "wise", "spo_plus", "pfyl", "nce", "lava", "intopt_original"]


def read(p):
    return json.loads(p.read_text())


def configure(job, method, *, fixed=False):
    job = copy.deepcopy(job)
    previous_id = job["id"]
    job["reference_job_id"] = previous_id
    job["method"] = method
    job["cell"] = job["route"] + "__train100__ablations20260927"
    job["ablation_campaign"] = "cps_intopt_20260927_v1"
    job["physical128_revision"] = REVISION
    job["validation_costs"] = "single_sample"
    job["analytic_validation"] = False
    config = job["config"]
    config["sizes"] = {"train": 100, "validation": 32, "test": 128}
    config["training"]["torch_threads"] = 1
    for k in ("original_checkpoint", "original_job", "original_parameter_sha256", "original_receipt_sha256", "original_training_hashes"):
        job.pop(k, None)
    base_method = method.removesuffix("_fixed")
    if base_method in VARIANTS:
        config["method_parameters"].update(VARIANTS[base_method])
    if fixed:
        job["stage"] = "confirmation"
        job["ablation_selection"] = "original validation-selected configuration and horizon, frozen before ablation"
        config["evaluate_test"] = True
    else:
        job["stage"] = "screen"
        job["repeat"] = 0
        config["evaluate_test"] = False
        job.pop("frozen_horizon", None)
    payload = {"model": config["model"], "training": config["training"],
               "method_parameters": config["method_parameters"], "method": method,
               "parameters": job["parameters"]}
    job["candidate"] = sha(payload)[:16]
    job["id"] = f"{job['stage']}__{job['cell']}__{method}__{job['candidate']}"
    if fixed:
        job["id"] += f"__r{job['repeat']}"
    config["name"] = job["id"]
    return job


def build(bank_package, root):
    group_map = read(bank_package / "FINAL_TUNING_GROUP_MAP.json")
    source = {name: json.loads(gzip.decompress((bank_package/name).read_bytes()))
              for row in group_map for name in row["archives"]}
    originals, group_sources, grids = {}, {}, []
    for row in group_map:
        ids = set(row["screen_job_ids"])
        jobs = [j for name in row["archives"] for j in source[name]["jobs"] if j["id"] in ids]
        assert len(jobs) == len(ids)
        key = (row["route"], row["method"])
        originals[key] = jobs
        group_sources[key] = next(source[name] for name in row["archives"] if any(j["id"] in ids for j in source[name]["jobs"]))
        grids.append({"route": key[0], "method": key[1], "candidate_count": len(jobs),
            "sources": row["archives"], "exact_candidates": [
                {"original_id": j["id"], "method_parameters": j["config"]["method_parameters"],
                 "public_parameters": j["parameters"], "model": j["config"]["model"],
                 "training": j["config"]["training"]} for j in jobs]})
    jobs, cells = [], {}
    for (route, method), templates in sorted(originals.items()):
        if method not in ("mse", "central_path_hard_validation"):
            continue
        for template in templates:
            variants = VARIANTS if method == "central_path_hard_validation" else {"intopt_original": {}}
            for variant in variants:
                parameters = [{}] if variant != "intopt_original" else [{"mu_cutoff": x} for x in MU_CUTOFFS]
                for parameter in parameters:
                    t = copy.deepcopy(template)
                    if variant == "intopt_original":
                        t["config"]["method"] = "intopt_original"
                        t["parameters"] = parameter
                        t["config"]["method_parameters"] = parameter
                        t["config"]["cost_coordinate_normalization"] = "none"
                        t["baseline_protocol"] = "physical_cold_highs_v1"
                        t["resource_limits"] = {"preprocessing_cap_seconds": 3600, "job_wall_cap_seconds": 9000}
                    j = configure(t, variant)
                    info = copy.deepcopy(group_sources[(route,method)]["cells"][template["cell"]])
                    info.update(route=route, train_size=100, validation_size=32, test_size=128)
                    # CPS and MSE use the same complete refinement/confirmation seeds.
                    previous = cells.get(j["cell"])
                    if previous:
                        assert previous["refinement_seeds"] == info["refinement_seeds"]
                        assert previous["confirmation_seeds"] == info["confirmation_seeds"]
                    cells[j["cell"]] = info
                    jobs.append(j)
    jobs.sort(key=lambda j: (j["route"], j["method"], j["candidate"]))
    assert len({j["id"] for j in jobs}) == len(jobs)
    main = read(bank_package / "MAIN_RUN_INDEX.json")
    controls = [row["job"] for row in main if row["job"]["method"] == "central_path_hard_validation"]
    assert len(controls) == 160
    fixed = [configure(j, variant+"_fixed", fixed=True) for j in controls for variant in VARIANTS]
    protocol = {"method_waves": [list(VARIANTS)+["intopt_original"]+[v+"_fixed" for v in VARIANTS]],
        "training": "100 frozen observed context-cost pairs",
        "validation": "32 frozen sampled observed-cost pairs; selection only",
        "test": "128 archived contexts, exact same arrays and complete seed bundles",
        "refinement": "top three candidates, original three complete seed bundles",
        "confirmation": "one validation-selected config/horizon, original ten complete seed bundles",
        "ablation_design": "separate guard removal, center-scale removal and both; each fixed-control and retuned",
        "barrier_scale_removal": "set center-regret multiplier to one; retain inequality-count denominator and physical geometry",
        "intopt_public_source": "JayMan91/NeurIPSIntopt@d2e2f89e57a6ac965920e890043f3e2597144c6b",
        "intopt_mu_cutoffs": MU_CUTOFFS,
        "intopt_mu_semantics": "public thr on raw HSD complementarity, not a fixed physical barrier mu",
        "preprocessing_cap_seconds": 3600, "training_cap_seconds": 3600,
        "job_wall_cap_seconds": 9000,
        "per_cell_method_pipeline": True, "no_population_moments_in_learning": True,
        "test_scores_read_for_selection": False,
        "maximum_workers_first_12_hours": 100, "maximum_workers_after_12_hours": 30}
    screen = {"schema": "cps_intopt_ablations_v1", "protocol": protocol, "cells": cells,
        "methods": list(VARIANTS)+["intopt_original"], "cell_methods": {
            cell: list(VARIANTS)+["intopt_original"] for cell in cells}, "jobs": jobs}
    write(root / "screen.json", screen)
    write(root / "execution.json", {**screen, "jobs": jobs+fixed, "screen_fingerprint": sha(screen)})
    write(root / "initial_execution.json", {**screen, "jobs": jobs+fixed, "screen_fingerprint": sha(screen)})
    for (cell, method), group in __import__('itertools').groupby(sorted(fixed,key=lambda j:(j['cell'],j['method'])),key=lambda j:(j['cell'],j['method'])):
        write(root / "results/selections" / f"confirmation__{cell}__{method}.json",
            {"jobs": list(group), "selection_receipt": {"fixed_ablation": True, "test_scores_read": False}})
    write(root / "burst_contract.json", {"run_id": root.name, "maximum_workers": 100,
        "maximum_seconds": 48*3600, "groups": sorted({(j['cell'],j['method']) for j in jobs+fixed}),
        "downscale_after_seconds": 12*3600, "downscale_workers": 30})
    write(root / "ARCHIVED_TUNING_GRIDS.json", grids)
    write(root / "CONTROL_JOBS.json", controls)
    write(root / "FULL_CAMPAIGN_METHODS.json", {"required_methods":FULL_CAMPAIGN_METHODS,
        "note":"IntOpt is required in subsequent full comparison campaigns; explicit ablation subsets may reuse archived controls."})
    # Verify every future stage's bank exists now, before submission.
    bank_keys = set()
    for j in jobs+fixed:
        seeds = [j['config']['seeds']] if j['stage']=='confirmation' else [j['config']['seeds']]+cells[j['cell']]['refinement_seeds']+cells[j['cell']]['confirmation_seeds']
        for seed in seeds:
            bank_keys.add(j['route']+'__data'+str(seed['data']))
    inventory = []
    for key in sorted(bank_keys):
        directory = bank_package/'frozen_data'/key
        meta = read(directory/'receipt.json')
        assert meta['sizes']=={'train':100,'validation':32,'test':128}
        for name, expected in meta['files_sha256'].items():
            path=directory/name
            actual=hashlib.sha256(path.read_bytes()).hexdigest()
            assert actual==expected, path
        inventory.append({'key':key,'receipt_sha256':hashlib.sha256((directory/'receipt.json').read_bytes()).hexdigest(),'files_sha256':meta['files_sha256']})
    write(root / 'FROZEN_BANK_INVENTORY.json', inventory)
    expected={'screen_fits':len(jobs),'fixed_ablation_fits':len(fixed),'groups':len(cells)*4,
        'maximum_refinement_fits':len(cells)*4*9,'maximum_selected_confirmations':len(cells)*4*10,
        'banks':len(bank_keys),'screen_by_method':dict(collections.Counter(j['method'] for j in jobs)),
        'all_existing_results_immutable':True,'inputs_verified':True}
    write(root/'BUILD_VERIFICATION.json',expected)
    print(json.dumps(expected,indent=2))


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bank-package',type=Path,required=True)
    p.add_argument('--root',type=Path,required=True)
    a=p.parse_args();build(a.bank_package.resolve(),a.root.resolve())
