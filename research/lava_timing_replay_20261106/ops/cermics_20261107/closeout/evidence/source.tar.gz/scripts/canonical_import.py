"""Publish cloud receipts only for exclusively owned, identical jobs."""
import argparse
import hashlib
from pathlib import Path
from build_central_path_final import read, write
from canonical_cluster import connect


def import_receipts(root, host):
    db = connect(root)
    import json
    count = 0
    terminal=[]
    for path in (root/'imports'/host).glob('*.json'):
        record = read(path)
        job = record['job']
        row = db.execute('SELECT payload,host,status FROM jobs WHERE id=?',(job['id'],)).fetchone()
        if row is None or row['host'] != host or json.loads(row['payload']) != job:
            raise ValueError('Cloud receipt has no matching exclusive lease: '+job['id'])
        if record.get('smoke_only') or record['status'] not in ('complete','failed','censored'):
            raise ValueError('Nonterminal or smoke receipt')
        target = root/'results/receipts'/path.name
        if target.exists():
            if read(target) != record:
                raise ValueError('Refusing to replace a different receipt')
        else:
            write(target,record)
            count += 1
        if row['status']=='external':terminal.append(job['id'])
    # Verified receipt publication ends the lease immediately; short cloud fits
    # need not wait through an entire selection pass before their pool refills.
    for start in range(0,len(terminal),32):
        db.executemany("UPDATE jobs SET status='terminal',rss=0 WHERE id=? AND host=? AND status='external'",
                       [(job_id,host) for job_id in terminal[start:start+32]])
        db.commit()
    db.close()
    return {'new_receipts':count,'finished_leases':len(terminal)}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--host',choices=('hornewall','tito'),required=True)
    args=p.parse_args()
    import json
    print(json.dumps(import_receipts(args.root,args.host)))


if __name__ == '__main__':
    main()
