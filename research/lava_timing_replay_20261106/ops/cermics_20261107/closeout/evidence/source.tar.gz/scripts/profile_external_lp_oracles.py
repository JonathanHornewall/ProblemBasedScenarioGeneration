"""Profile keyed HiGHS basis reuse on an Atlas generic-LP route.

This is an implementation profile, not learning evidence.  It simulates
successive training epochs by solving slightly changing objectives under stable
sample keys, exactly the access pattern used by SPO+, PFYL, and SFGE.
"""

from __future__ import annotations

import argparse
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np

from proximal_spo.artifacts import environment_receipt, source_sha256, write_json
from proximal_spo.data import SplitSizes
from proximal_spo.external_benchmarks import load_external_benchmark
from proximal_spo.objectives import sample_keys_for_split
from proximal_spo.oracles import ParallelOracle, PersistentLPSolver


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--benchmark",
        default="lava_random_lp_100x50_released_code",
    )
    parser.add_argument("--samples", type=int, default=800)
    parser.add_argument("--passes", type=int, default=4)
    parser.add_argument("--seed", type=int, default=20260829)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    if arguments.samples <= 0 or arguments.passes < 2:
        parser.error("samples must be positive and passes must be at least two")

    root = Path(__file__).resolve().parents[1]
    loaded = load_external_benchmark(
        arguments.benchmark,
        SplitSizes(arguments.samples, 1, 1),
        data_seed=arguments.seed,
        conditional_reference_samples=1,
    )
    problem = loaded.problem
    base = np.asarray(loaded.dataset.train.physical_costs, dtype=np.float64)
    scales = np.maximum(np.std(base, axis=0, ddof=1), 1e-8)
    keys = sample_keys_for_split("profile_train", len(base))
    random = np.random.Generator(np.random.PCG64(arguments.seed))
    perturbations = [
        np.zeros_like(base),
        *[
            0.02 * epoch * random.normal(size=base.shape) * scales
            for epoch in range(1, arguments.passes)
        ],
    ]

    rows: list[dict[str, Any]] = []
    for maximum_cache_entries in (0, 50_000):
        for workers in (1, 2, 4, 8):
            oracle = ParallelOracle(
                [
                    PersistentLPSolver(
                        problem,
                        random_seed=arguments.seed + worker,
                        maximum_basis_cache_entries=maximum_cache_entries,
                    )
                    for worker in range(workers)
                ]
            )
            passes: list[dict[str, Any]] = []
            try:
                for epoch, perturbation in enumerate(perturbations):
                    started = time.perf_counter()
                    solved = oracle.solve_many(base + perturbation, keys)
                    outer_wall = time.perf_counter() - started
                    passes.append(
                        {
                            "pass": epoch,
                            "outer_wall_seconds": outer_wall,
                            "solves_per_second": len(base) / outer_wall,
                            "oracle_stats": asdict(solved.stats),
                        }
                    )
            finally:
                oracle.close()
            warm_seconds = np.asarray(
                [row["outer_wall_seconds"] for row in passes[1:]],
                dtype=np.float64,
            )
            rows.append(
                {
                    "workers": workers,
                    "maximum_basis_cache_entries": maximum_cache_entries,
                    "passes": passes,
                    "mean_warm_wall_seconds": float(np.mean(warm_seconds)),
                    "mean_warm_solves_per_second": float(
                        len(base) / np.mean(warm_seconds)
                    ),
                }
            )
            print(
                f"cache={maximum_cache_entries:5d} workers={workers} "
                f"warm_rate={len(base) / np.mean(warm_seconds):.0f}/s",
                flush=True,
            )

    write_json(
        arguments.output,
        {
            "kind": "keyed_persistent_lp_implementation_profile",
            "scope": "implementation profile; no model trained",
            "benchmark_id": arguments.benchmark,
            "samples": arguments.samples,
            "passes": arguments.passes,
            "objective_perturbation": (
                "independent Gaussian increments at 0.02 * pass * empirical "
                "per-coordinate cost standard deviation"
            ),
            "raw_objectives_persisted": False,
            "external_provenance": loaded.provenance,
            "source_sha256": source_sha256(root),
            "environment": environment_receipt(root),
            "rows": rows,
        },
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
