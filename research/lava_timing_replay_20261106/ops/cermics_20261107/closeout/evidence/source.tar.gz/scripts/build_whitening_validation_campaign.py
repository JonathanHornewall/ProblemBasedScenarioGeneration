"""Freeze a source-backed whitening, guard and validation ablation campaign."""
from __future__ import annotations
import argparse, collections, copy, csv, gzip, hashlib, json, os, tarfile, time
from pathlib import Path

CPS='central_path_hard_validation'
METHODS=(CPS,'mse','wise','spo_plus')
REVISION='whitening_validation_20260929_v1'


def read(p):
 p=Path(p)
 if not p.exists() and p.with_suffix(p.suffix+'.gz').exists():p=p.with_suffix(p.suffix+'.gz')
 return json.loads(gzip.decompress(p.read_bytes())) if p.suffix=='.gz' else json.loads(p.read_text())
def write(p,d):
 p=Path(p)
 compressed=p.name in ('PLAN.json','controls.json','development.json')
 if compressed:p=p.with_suffix(p.suffix+'.gz')
 p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp')
 data=(json.dumps(d,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
 tmp.write_bytes(gzip.compress(data,compresslevel=6) if compressed else data);tmp.replace(p)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(d):return hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def signature(job):
 """Consumed scientific payload; ignore only names and inert provenance."""
 c=copy.deepcopy(job['config']);c.pop('name',None);c.pop('evaluate_test',None)
 c['sizes']['test']=128
 if job['method']==CPS:
  p=c['method_parameters'];p.setdefault('hessian_whitening',True);p.setdefault('guard_safety_factor',.5)
  if p['hessian_whitening']:p['guard_radius_policy']='geometry_certified'
  else:p.setdefault('guard_radius_policy','geometry_certified')
 if job.get('stage') in ('confirmation','reevaluation'):
  h=job.get('frozen_horizon',c['training']['epochs'])
  c['training'].update(epochs=max(1,h),validation_epochs=[max(1,h)],selection_mode='last',schedule_reference_epochs=300)
 return digest({'config':c,'route':job['route'],'method':job['method'],'parameters':job.get('parameters',{}),
                'baseline_protocol':job.get('baseline_protocol'),'horizon':job.get('frozen_horizon'),
                'validation_costs':job.get('validation_costs'),'phase':'confirmation' if job.get('stage') in ('confirmation','reevaluation') else job['stage']})


def clean_job(source,arm,stage=None,seeds=None,horizon=None,whitening=None,rho=None):
 j=copy.deepcopy(source)
 for k in ('original_job','original_checkpoint','source_receipt','checkpoint_path','reevaluation','original_receipt'):
  j.pop(k,None)
 j.update(whitening_validation_revision=REVISION,architecture_arm=arm,
          linear_scale_revision='linear_scale_20260928_v1',physical128_revision='physical_head_test128_20260925_v1',
          analytic_validation=False,validation_costs='single_sample')
 if stage:j['stage']=stage
 c=j['config'];c['sizes']={'train':100,'validation':32,'test':128};c['workers']=1;c['training']['torch_threads']=1
 c['evaluate_test']=j['stage']=='confirmation'
 if seeds is not None:c['seeds']=copy.deepcopy(seeds)
 if horizon is not None:
  j['frozen_horizon']=horizon;c['training'].update(epochs=max(1,horizon),schedule_reference_epochs=300,
        validation_epochs=[max(1,horizon)],selection_mode='last')
 elif j['stage'] in ('screen','refinement'):
  j.pop('frozen_horizon',None)
 if j['method']==CPS:
  c['method_parameters'].update(hessian_whitening=True if whitening is None else whitening,
       guard_safety_factor=.5 if rho is None else rho,guard_radius_policy='geometry_certified')
 j['id']='wv__'+signature(j)[:24];c['name']=j['id']
 return j


def build(root,previous):
 assert not (root/'PLAN.json').exists() and not (root/'PLAN.json.gz').exists(),'Already frozen'
 base=previous.parent
 report=previous/'reports/experimental_record_20260928'
 archive=previous/'runs/linear_scale_20260928/remote_archive'
 grids=[x for x in read(report/'data/EXACT_MAIN_SCREEN_CANDIDATES.json') if x['method'] in METHODS]
 selected=[x for x in read(report/'data/MAIN_SELECTED_FULL.json') if x['method'] in METHODS]
 cells={}
 for row in csv.DictReader((report/'data/FULL_SEED_SCHEDULE.csv').open()):
  k=row['architecture_arm']+'|'+row['route'];d=cells.setdefault(k,{'refinement':{},'confirmation':{}})
  if row['stage'] in d:d[row['stage']][int(row['repeat'])]={k:int(row[k]) for k in ('data','initialization','perturbation','shuffle','structural')}
 for k,d in cells.items():
  for stage,expected in [('refinement',3),('confirmation',10)]:
   assert sorted(d[stage])==list(range(expected)),(k,stage)
   d[stage]=[d[stage][i] for i in range(expected)]
 manifests={}
 for item in grids:
  k=item['architecture_arm']+'|'+item['route']
  if k in cells:continue
  fn=item['source_manifest']
  if fn not in manifests:
   file=report/'raw'/fn
   manifests[fn]=json.loads(gzip.decompress(file.read_bytes())) if fn.endswith('.gz') else read(file)
  info=manifests[fn]['cells'][item['job']['cell']]
  cells[k]={'refinement':info['refinement_seeds'],'confirmation':info['confirmation_seeds']}
 assert len(cells)==40
 group_grid=collections.defaultdict(list)
 for x in grids:group_grid[(x['architecture_arm'],x['route'],x['method'])].append(x['job'])
 assert len(group_grid)==160
 # Import development receipts by exact identity, including historical compressed metadata.
 desired={j['id']:j for jobs in group_grid.values() for j in jobs}
 # Every selected original refinement can contribute, even if final-epoch ranking changes.
 refinements=set()
 for a,r,m in group_grid:
  for j in group_grid[a,r,m]:
   for i in range(3):refinements.add(f"refinement__{j['cell']}__{m}__{j['candidate']}__r{i}")
 desired_ids=set(desired)|refinements
 found={};sources={};historical=[]
 def accept(raw,location):
  d=json.loads(raw);jid=d.get('job',{}).get('id')
  if jid not in desired_ids:return
  if d.get('smoke_only') or d.get('test_access') or d.get('summary',{}).get('test') is not None:return
  if d.get('test_bank_opened',False):raise ValueError('Development opened test: '+location)
  # CFL500 recovery overrides superseded memory-censored receipts.
  if jid in found and found[jid]['status']=='complete':return
  keep={k:d[k] for k in ('job','status','summary','curve','data_hashes','validation_protocol','test_access','test_bank_opened','error','resource_usage') if k in d}
  keep['source']={'location':location,'sha256':hashlib.sha256(raw).hexdigest()}
  if 'test' in keep.get('data_hashes',{}):keep['data_hashes'].pop('test')
  found[jid]=keep
 roots=[archive/'memory_recovery_cfl500_20260928/production/results/receipts',archive/'results/receipts',
   base/'ProximalSPO-matched-final-20260926/runs/matched_final_20260926/retrieved/cps_matched_integer_20260926/results/receipts',
   base/'ProximalSPO-matched-final-20260926/runs/matched_final_20260926/retrieved/lp150_released_20260926/results/receipts']
 for p in roots:
  for q in sorted(p.glob('*.json')):
   if q.stem in desired_ids:accept(q.read_bytes(),str(q))
 hist=base/'ProximalSPO-matched-final-20260926/runs/matched_final_20260926/cermics_cleanup_20260926'
 hv=read(hist/'HISTORICAL_METADATA_VERIFICATION.json');assert hv['status']=='complete'
 for ar in hv['archives']:
  p=Path(ar['path'])
  members=[n for n in ar['remote_members'] if '/results/receipts/' in n and Path(n).stem in desired_ids]
  if not members:continue
  assert sha(p)==ar['sha256'];sources[str(p)]=ar['sha256']
  with tarfile.open(p,'r:gz') as tar:
   for member in tar:
    if member.isfile() and '/results/receipts/' in member.name and Path(member.name).stem in desired_ids:
     accept(tar.extractfile(member).read(),str(p)+'::'+member.name)
 # Preserve all imported development evidence as data separate from selection outputs.
 write(root/'prior/development.json',found)
 missing=[jid for jid in desired if jid not in found]
 write(root/'PRIOR_IMPORT_CHECK.json',{'status':'passed' if not missing else 'missing_screen_receipts',
   'screens_expected':len(desired),'screens_found':len(desired)-len(missing),'missing_screens':missing,
   'development_receipts':len(found),'compressed_sources':sources})
 # Missing archived validation histories require isolated development replays.
 # They never overwrite historical main-suite fits or use test scores.
 write(root/'DEVELOPMENT_REPLAY_REQUIREMENT.json',{'original_screen_ids':missing,
   'reason':'Complete original development curves absent from retained local receipt archives',
   'same_observations_and_seeds':True,'historical_results_immutable':True})
 # Preserve original confirmation receipts for reporting and exact-payload reuse; no ranking reads them.
 controls={}
 for x in selected:
  a,r,m=x['architecture_arm'],x['route'],x['method']
  for repeat in range(10):
   member=f'{a}/{r}/{m}/repeat_{repeat}.json'
   controls[member]=None
 with tarfile.open(report/'raw/main_confirmation_receipts.tar.gz') as tar:
  for member in tar:
   if member.name in controls:
    raw=tar.extractfile(member).read();d=json.loads(raw);assert d['status']=='complete'
    d['import_source']={'archive':str(report/'raw/main_confirmation_receipts.tar.gz'),'member':member.name,'sha256':hashlib.sha256(raw).hexdigest()}
    controls[member.name]=d
 assert all(x is not None for x in controls.values())
 write(root/'prior/controls.json',controls)
 # Banks are already locally verified. Hard links avoid duplicating valuable storage.
 bank_inventory={}
 for p in sorted((archive/'frozen_data').glob('*/*')):
  if p.name not in ('receipt.json','structure.npz','structure.json','observations.npz','test.npz'):continue
  target=root/'frozen_data'/p.parent.name/p.name;target.parent.mkdir(parents=True,exist_ok=True)
  if not target.exists():os.link(p,target)
  bank_inventory[str(target.relative_to(root))]={'bytes':p.stat().st_size,'sha256':sha(p)}
 assert len(list((root/'frozen_data').iterdir()))==280
 write(root/'INPUT_INVENTORY.json',bank_inventory)
 groups=[]
 for x in selected:
  a,r,m=x['architecture_arm'],x['route'],x['method'];key=f'{a}|{r}|{m}'
  common={'architecture':a,'route':r,'method':m,'phase':2 if m=='spo_plus' else 1,
          'seeds':cells[a+'|'+r],'grid_key':key}
  for variant in ('final_epoch','one_seed','final_epoch_one_seed'):
   groups.append({**common,'id':key+'|validation_'+variant,'kind':'validation','variant':variant})
  if m==CPS:
   for white,rho in ((False,.5),(False,.75),(False,.9),(True,.75),(True,.9)):
    jobs=[clean_job(x['full_job'],a,'confirmation',seed,x['horizon'],white,rho) for seed in common['seeds']['confirmation']]
    for i,j in enumerate(jobs):j['repeat']=i
    groups.append({**common,'id':key+f'|fixed_white{int(white)}_rho{rho}', 'kind':'fixed','whitening':white,'rho':rho,'jobs':jobs})
   groups.append({**common,'id':key+'|retuned_no_whitening','kind':'retuned_no_whitening','whitening':False,'rho':.5})
 assert len(groups)==720
 write(root/'PLAN.json',{'revision':REVISION,'created_unix':time.time(),'groups':groups,'grids':{'|'.join(k):v for k,v in group_grid.items()},
   'resource_policy':{'aggregate_cpus':30,'allocation_memory_gib':176,'admission_gib':160,
                      'rss_fraction':.9,'maximum_allocation_seconds':172800},
   'protocol':{'job_wall_cap_seconds':9000,'preprocessing_cap_seconds':3600},
   'source_study':str(report),'source_grid_sha256':sha(report/'data/EXACT_MAIN_SCREEN_CANDIDATES.json'),
   'logical_groups':720,'ten_seed_outcomes':7200,'validation_groups':480,'fixed_geometry_guard_groups':200,
   'retuned_no_whitening_groups':40,'guard_design':'matched winning configurations only, rho .5/.75/.9; no guard tuning from test scores',
   'held_out_selection':False})
 print(json.dumps({'groups':len(groups),'original_screens':len(desired),'imported_development':len(found),'banks':280}))


if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--previous',type=Path,required=True)
 a=p.parse_args();build(a.root.resolve(),a.previous.resolve())
