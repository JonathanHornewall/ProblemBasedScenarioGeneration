"""Isolated implementation and inference checks before the scientific queue."""
import argparse
import copy
import json
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from build_central_path_final import read, write
from central_path_slurm import environment


def run(root):
    screen = read(root / "screen.json")
    routes = ("dys_shortest_path_10x10", "dys_cfl_50x5", "dys_knapsack_50x2", "lava_random_lp_50x50_released_code")
    jobs = []
    for route in routes:
        for method in ("pfyl", "nce", "lava"):
            if method == "lava" and ("shortest_path" in route or "cfl" in route):
                continue
            j = copy.deepcopy(next(j for j in screen["jobs"] if j["route"] == route and j["method"] == method))
            j["id"] = "diagnostic__" + j["id"]
            j["config"]["name"] = j["id"]
            j["config"]["training"].update(epochs=2, validation_epochs=[1, 2], patience=3,
                maximum_optimization_seconds=60)
            j["resource_limits"] = {"preprocessing_cap_seconds": 120, "job_wall_cap_seconds": 240}
            j["diagnostic_only"] = True
            jobs.append(j)
    old = read(root / "reevaluation.json")["jobs"]
    input_issues = []
    metas = {}
    for j in old:
        key = j["route"] + "__data" + str(j["config"]["seeds"]["data"])
        if key not in metas:
            metas[key] = read(root / "frozen_data" / key / "receipt.json")
        for field in ("contexts", "physical_costs"):
            if metas[key]["array_hashes"]["train"][field] != j["original_training_hashes"][field]:
                input_issues.append({"job": j["id"], "field": field})
    write(root / "preflight/frozen_model_input_verification.json", {
        "checked_models": len(old), "issues": input_issues})
    if input_issues:
        raise ValueError("Frozen-model input mismatch")
    for route in sorted({j["route"] for j in old}):
        j = copy.deepcopy(next(j for j in old if j["route"] == route
                              and j["study"] == "main" and j["method"] == "central_path_hard_validation" and j["repeat"] == 0))
        j.update(id="diagnostic__" + j["id"], diagnostic_only=True)
        jobs.append(j)
    for route in routes:
        for method in ("mse", "wise", "spo_plus"):
            j = copy.deepcopy(next(j for j in old if j["route"] == route
                                  and j["method"] == method and j["repeat"] == 0))
            j.update(id="diagnostic__" + j["id"], diagnostic_only=True)
            jobs.append(j)
    for study in ("direct", "sensitivity"):
        seen = set()
        for original in old:
            key = (original["route"], original["method"])
            if original["study"] != study or key in seen or original["repeat"] != 0:
                continue
            if study == "sensitivity" and original["route"] not in routes:
                continue
            seen.add(key)
            j = copy.deepcopy(original)
            j.update(id="diagnostic__" + j["id"], diagnostic_only=True)
            jobs.append(j)
    path = root / "preflight/diagnostic.json"
    write(path, {**screen, "jobs": jobs})
    output = root / "preflight/results"
    (output / "logs").mkdir(parents=True, exist_ok=True)
    env = environment(root)

    def execute(index):
        job = jobs[index]
        with (output / "logs" / (job["id"] + ".log")).open("w") as log:
            process = subprocess.run([str(root / "venv/bin/python"),
                str(root / "code/scripts/run_central_path_final.py"), "--manifest", str(path),
                "--job-index", str(index), "--output-root", str(output)],
                stdout=log, stderr=subprocess.STDOUT, env=env, timeout=1900)
        receipt = output / "receipts" / (job["id"] + ".json")
        r = read(receipt) if receipt.exists() else {}
        issues = []
        if process.returncode or r.get("status") != "complete":
            issues.append(r.get("error", "nonzero or missing receipt"))
        elif job["stage"] == "reevaluation":
            if r["summary"]["test"]["sample_count"] != 128 or not r["summary"]["model_parameters_unchanged"]:
                issues.append("frozen inference verification failed")
        else:
            if r["test_access"] or r.get("test_bank_opened") or r["summary"]["test"] is not None:
                issues.append("held-out access during development")
            if r["summary"]["output_coordinates"] != "physical_costs_no_fixed_affine_decoder":
                issues.append("wrong output coordinates")
            if not (Path(r["attempt_directory"]) / "model.pt").exists():
                issues.append("model checkpoint missing")
        result = {"job": job["id"], "status": r.get("status"), "issues": issues}
        print(json.dumps(result), flush=True)
        return result
    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(execute, range(len(jobs))))
    issues = [r for r in results if r["issues"]]
    write(root / "preflight/diagnostic_verification.json", {"status": "failed" if issues else "complete",
        "jobs": len(jobs), "issues": issues, "results": results, "scientific_selection_eligible": False})
    if issues:
        raise SystemExit(1)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, required=True)
    run(p.parse_args().root)
