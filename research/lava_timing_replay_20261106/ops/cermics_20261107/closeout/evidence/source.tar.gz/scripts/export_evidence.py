"""Export compact JSON/JSONL run evidence into a trackable snapshot."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected a JSON object at {path}")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=Path("runs"))
    parser.add_argument("--destination", type=Path, default=Path("evidence"))
    arguments = parser.parse_args()
    source = arguments.source.resolve()
    destination = arguments.destination.resolve()
    if not source.is_dir():
        raise ValueError(f"run source does not exist: {source}")
    if destination.exists():
        raise FileExistsError(
            f"evidence destination already exists: {destination}; "
            "remove it explicitly before replacing a frozen snapshot"
        )
    copied_root = destination / "runs"
    copied_root.mkdir(parents=True)
    records: list[dict[str, Any]] = []
    source_hashes: set[str] = set()
    for path in sorted(item for item in source.rglob("*") if item.is_file()):
        if path.name == ".gitkeep":
            continue
        if path.suffix not in {".json", ".jsonl"}:
            raise ValueError(f"refusing unexpected run artefact: {path}")
        relative = path.relative_to(source)
        target = copied_root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        records.append(
            {
                "path": str(Path("runs") / relative),
                "bytes": target.stat().st_size,
                "sha256": _sha256(target),
            }
        )
        if path.name == "environment.json":
            value = _object(path).get("source_sha256")
            if isinstance(value, str) and len(value) == 64:
                source_hashes.add(value)
    write_json(
        destination / "MANIFEST.json",
        {
            "kind": "compact_run_evidence_snapshot",
            "created_at_utc": datetime.now(UTC).isoformat(),
            "source": str(arguments.source),
            "file_count": len(records),
            "total_bytes": sum(int(record["bytes"]) for record in records),
            "source_sha256_values": sorted(source_hashes),
            "raw_data_or_model_weights_included": False,
            "files": records,
        },
    )
    print(
        f"exported {len(records)} files "
        f"({sum(int(record['bytes']) for record in records)} bytes)"
    )


if __name__ == "__main__":
    main()
