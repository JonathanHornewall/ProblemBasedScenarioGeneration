"""Build the paired corrected-mollification sigma--tau screen.

This is deliberately a broad geometry screen rather than a final tuning
campaign.  It holds optimization and Monte Carlo resolution fixed while
mapping the two scientifically central scales on three paired development
seeds.  Hard deployment at the recovered cost is implemented by the method,
not by this campaign builder.
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path
from typing import Any

from proximal_spo.artifacts import write_json

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPO_ROOT / "configs" / "mollified_corrected"

DEVELOPMENT_SEEDS = (1, 2, 3)
SIGMAS = (0.0, 0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0, 30.0)
TAUS = (0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0)
LEARNING_RATE = 0.003
TRAINING_SAMPLES = 8
SCREEN_EPOCHS = 60
REFINEMENT_SIGMA = 0.1
REFINEMENT_TAUS = (0.03, 0.1, 0.3)
REFINEMENT_LEARNING_RATES = (0.001, 0.003, 0.01)
REFINEMENT_EPOCHS = 200

# These cells arrive first so gross behavior at deterministic, central, and
# extreme scales is visible long before the full heatmap completes.
PRIORITY_CELLS = (
    (0.0, 3.0),
    (1.0, 3.0),
    (10.0, 0.1),
    (30.0, 0.01),
)


def _tag(value: float) -> str:
    if value == 0.0:
        return "0"
    return f"{value:.0e}".replace("-", "m").replace("+", "p")


def _seeds(data_seed: int) -> dict[str, int]:
    return {
        "data": data_seed,
        "structural": 101,
        "initialization": 200 + data_seed,
        "shuffle": 300 + data_seed,
        "perturbation": 400 + data_seed,
    }


def _base() -> dict[str, Any]:
    return {
        "name": "base",
        "benchmark_id": "cost.grid5",
        "method": "mollified_anchored_proximal",
        "interface": "full",
        # Two campaign jobs x four solver workers uses a majority of the
        # 14-thread host without monopolizing it.
        "workers": 4,
        "sizes": {"train": 1024, "validation": 256, "test": 512},
        "law": {
            "context_dimension": 5,
            "random_fraction": 1.0,
            "style": "positive",
            "noise": "pyepo_uniform",
            "noise_scale": 0.5,
            "signal_scale": 1.0,
            "polynomial_degree": 6,
        },
        "model": {
            "depth": 2,
            "width": 64,
            "activation": "silu",
            "layer_norm": False,
            "correction_depth": 2,
            "correction_width": 64,
        },
        "training": {
            "epochs": SCREEN_EPOCHS,
            "batch_size": 128,
            "learning_rate": LEARNING_RATE,
            "weight_decay": 0.00001,
            "optimizer": "adamw",
            "gradient_clip": 10.0,
            "validation_interval": 5,
            "patience": 20,
            "minimum_delta": 0.00001,
            "evaluation_batch_size": 512,
            "torch_threads": 2,
            "selection_mode": "validation_regret",
        },
        "seeds": _seeds(DEVELOPMENT_SEEDS[0]),
        "method_parameters": {
            "tau": 1.0,
            "sigma": 0.0,
            "training_samples": TRAINING_SAMPLES,
            # The corrected finite-bank method trains and validates the same
            # canonical report map.  K=64 is no longer used for checkpointing.
            "evaluation_samples": TRAINING_SAMPLES,
            "base_epochs": 200,
            "base_learning_rate": 0.001,
            "base_batch_size": 128,
        },
    }


def _variant(*, seed: int, sigma: float, tau: float) -> dict[str, Any]:
    return {
        "name": (
            f"corr_screen_s{seed}_sig{_tag(sigma)}_tau{_tag(tau)}_"
            f"lr{_tag(LEARNING_RATE)}_k{TRAINING_SAMPLES}"
        ),
        "seeds": _seeds(seed),
        "method_parameters": {"sigma": sigma, "tau": tau},
    }


def ordered_cells() -> list[tuple[float, float]]:
    declared = list(itertools.product(SIGMAS, TAUS))
    priority = list(PRIORITY_CELLS)
    if any(cell not in declared for cell in priority):
        raise ValueError("priority cell lies outside the declared grid")
    return priority + [cell for cell in declared if cell not in priority]


def screen_payload() -> dict[str, Any]:
    variants = [
        _variant(seed=seed, sigma=sigma, tau=tau)
        for sigma, tau in ordered_cells()
        for seed in DEVELOPMENT_SEEDS
    ]
    return {
        "name": "corrected_mollified_sigma_tau_screen",
        "run_root": "runs/mollified_corrected/sigma_tau_screen",
        "base": _base(),
        "variants": variants,
        "design": {
            "purpose": "broad corrected hard-deployment geometry screen",
            "development_seeds": list(DEVELOPMENT_SEEDS),
            "sigmas": list(SIGMAS),
            "taus": list(TAUS),
            "learning_rate": LEARNING_RATE,
            "training_samples": TRAINING_SAMPLES,
            "evaluation_samples": TRAINING_SAMPLES,
            "epochs": SCREEN_EPOCHS,
            "deployment_rule": "hard_optimizer_at_recovered_cost",
            "primary_metric": "paired_validation_regret_minus_embedded_mse",
            "campaign_jobs": 2,
            "solver_workers_per_job": 4,
            "raw_weights_persisted": False,
        },
    }


def refinement_payload() -> dict[str, Any]:
    """Return the focused long-training campaign selected by the broad screen."""

    base = _base()
    base["training"] = {
        **base["training"],
        "epochs": REFINEMENT_EPOCHS,
        # Forty validation checks span the entire 200-epoch run.  This keeps
        # the diagnostic from silently terminating before a late checkpoint.
        "patience": 40,
    }
    variants = []
    for tau, learning_rate, seed in itertools.product(
        REFINEMENT_TAUS,
        REFINEMENT_LEARNING_RATES,
        DEVELOPMENT_SEEDS,
    ):
        variants.append(
            {
                "name": (
                    f"corr_refine_s{seed}_sig{_tag(REFINEMENT_SIGMA)}_"
                    f"tau{_tag(tau)}_lr{_tag(learning_rate)}_"
                    f"k{TRAINING_SAMPLES}_e{REFINEMENT_EPOCHS}"
                ),
                "seeds": _seeds(seed),
                "method_parameters": {
                    "sigma": REFINEMENT_SIGMA,
                    "tau": tau,
                },
                "training": {"learning_rate": learning_rate},
            }
        )
    return {
        "name": "corrected_mollified_optimization_refinement",
        "run_root": "runs/mollified_corrected/optimization_refinement",
        "base": base,
        "variants": variants,
        "design": {
            "purpose": "long-training and learning-rate refinement",
            "selection_basis": (
                "completed 3-seed sigma--tau screen; broad interior basin "
                "centered at sigma=0.1 and tau=0.1"
            ),
            "development_seeds": list(DEVELOPMENT_SEEDS),
            "sigma": REFINEMENT_SIGMA,
            "taus": list(REFINEMENT_TAUS),
            "learning_rates": list(REFINEMENT_LEARNING_RATES),
            "training_samples": TRAINING_SAMPLES,
            "evaluation_samples": TRAINING_SAMPLES,
            "epochs": REFINEMENT_EPOCHS,
            "validation_interval": 5,
            "deployment_rule": "hard_optimizer_at_recovered_cost",
            "primary_metric": "paired_validation_regret_minus_embedded_mse",
            "campaign_jobs": 2,
            "solver_workers_per_job": 4,
            "raw_weights_persisted": False,
        },
    }


def smoke_payload() -> dict[str, Any]:
    base = _base()
    base["workers"] = 2
    base["sizes"] = {"train": 128, "validation": 64, "test": 64}
    base["training"] = {
        **base["training"],
        "epochs": 2,
        "validation_interval": 1,
        "patience": 2,
        "evaluation_batch_size": 64,
        "torch_threads": 2,
    }
    base["method_parameters"] = {
        **base["method_parameters"],
        "base_epochs": 2,
        "base_batch_size": 64,
    }
    return {
        "name": "corrected_mollified_sigma_tau_smoke",
        "run_root": "runs/mollified_corrected/smoke",
        "base": base,
        "variants": [_variant(seed=1, sigma=1.0, tau=3.0)],
        "diagnostic_only": True,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("screen", "refinement", "smoke"))
    arguments = parser.parse_args()
    CONFIG_ROOT.mkdir(parents=True, exist_ok=True)
    if arguments.stage == "screen":
        path = CONFIG_ROOT / "sigma_tau_screen.json"
        payload = screen_payload()
    elif arguments.stage == "refinement":
        path = CONFIG_ROOT / "optimization_refinement.json"
        payload = refinement_payload()
    else:
        path = CONFIG_ROOT / "smoke.json"
        payload = smoke_payload()
    write_json(path, payload)
    print(path.relative_to(REPO_ROOT))


if __name__ == "__main__":
    main()
