"""Freeze paired validation refinement and emit test confirmation runs."""

from __future__ import annotations

import argparse
from pathlib import Path

from proximal_spo.artifacts import write_json
from proximal_spo.development_analysis import completed_validation_rows
from proximal_spo.publication_selection import build_confirmation_campaign


def _benchmark_size(argument: str) -> tuple[str, int]:
    benchmark, separator, raw_size = argument.partition("=")
    if not separator or not benchmark or not raw_size:
        raise argparse.ArgumentTypeError("test-size cap must be BENCHMARK=SIZE")
    try:
        size = int(raw_size)
    except ValueError as error:
        raise argparse.ArgumentTypeError("test-size cap must be an integer") from error
    if size <= 0:
        raise argparse.ArgumentTypeError("test-size cap must be positive")
    return benchmark, size


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", action="append", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--campaign-run-root", required=True)
    parser.add_argument("--required-refinement-seeds", type=int, default=3)
    parser.add_argument("--minimum-test-size", type=int)
    parser.add_argument("--test-to-validation-ratio", type=float)
    parser.add_argument(
        "--benchmark-id",
        action="append",
        help="restrict confirmation to the named benchmark id; may be repeated",
    )
    parser.add_argument(
        "--maximum-test-size",
        action="append",
        type=_benchmark_size,
        default=[],
        metavar="BENCHMARK=SIZE",
        help="cap test size for a fixed released split; may be repeated",
    )
    arguments = parser.parse_args()
    rows = completed_validation_rows(arguments.run_root)
    if arguments.benchmark_id:
        requested = frozenset(arguments.benchmark_id)
        rows = [
            row
            for row in rows
            if row.get("config", {}).get("benchmark_id") in requested
        ]
        found = {
            str(row["config"]["benchmark_id"])
            for row in rows
            if isinstance(row.get("config"), dict)
        }
        missing = requested - found
        if missing:
            raise ValueError(
                "requested benchmarks were not present: "
                + ", ".join(sorted(missing))
            )
    maximum_test_sizes = dict(arguments.maximum_test_size)
    if len(maximum_test_sizes) != len(arguments.maximum_test_size):
        raise ValueError("duplicate maximum-test-size benchmark")
    campaign = build_confirmation_campaign(
        rows,
        run_root=arguments.campaign_run_root,
        required_refinement_seeds=arguments.required_refinement_seeds,
        minimum_test_size=arguments.minimum_test_size,
        test_to_validation_ratio=arguments.test_to_validation_ratio,
        maximum_test_size_by_benchmark=maximum_test_sizes,
    )
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    write_json(arguments.output, campaign)
    print(
        f"wrote {len(campaign['variants'])} paired confirmation runs to "
        f"{arguments.output}"
    )


if __name__ == "__main__":
    main()
