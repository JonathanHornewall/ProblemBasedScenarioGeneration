"""Immutable identities and atomic operational records for the two-step pilot."""
from __future__ import annotations
import copy
import hashlib
import json
import os
from pathlib import Path

REVISION = 'parsimonious_linear_pilot_20261019_v1'
CPS = 'central_path_hard_validation'
METHODS = [CPS, 'wise', 'mse', 'spo_plus', 'nce', 'pfyl', 'lava']
EPOCHS = [5, 10, 20, 40, 80, 120, 180, 240, 300]
ARMS = ['control', 'no_clip_no_decay', 'batch32', 'no_clip_no_decay_batch32']
LARGE = {'dys_shortest_path_50x50', 'dys_cfl_500x10',
         'dys_knapsack_1000x2', 'lava_random_lp_800x50_released_code'}
SMALLEST = {'sp': 'dys_shortest_path_10x10', 'cfl': 'dys_cfl_50x5',
            'kp': 'dys_knapsack_50x2', 'rlp': 'lava_random_lp_50x50_released_code'}

def read(path):
    return json.loads(Path(path).read_text())

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''): h.update(block)
    return h.hexdigest()

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()

def write(path, value, *, immutable=False):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n'
    if immutable and path.exists():
        if path.read_text() != text: raise RuntimeError('Immutable record differs: ' + str(path))
        return
    temporary = path.with_name(path.name + f'.{os.getpid()}.tmp')
    with temporary.open('w') as f:
        f.write(text); f.flush(); os.fsync(f.fileno())
    if immutable:
        try: os.link(temporary, path)
        except FileExistsError:
            if path.read_text() != text: raise RuntimeError('Concurrent immutable record differs: ' + str(path))
        finally: temporary.unlink(missing_ok=True)
    else: temporary.replace(path)

def family(route):
    if 'shortest_path' in route: return 'sp'
    if 'cfl' in route: return 'cfl'
    if 'knapsack' in route: return 'kp'
    if 'random_lp' in route: return 'rlp'
    raise ValueError(route)

def provision(job):
    return 12 if job['route'] == 'dys_cfl_500x10' or (job['route'] in LARGE and job['method'] == CPS) else 6 if job['route'] in LARGE else 3

def environment(root):
    root = Path(root); code = root / 'code'; env = dict(os.environ)
    for k in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'): env[k] = '1'
    env.update(PYTHONUNBUFFERED='1', PYTHONPATH=f'{code}/scripts:{code}/src:{code}/vendor/external/src',
        SOLVER_FREE_DFL_REPO=str(code/'vendor/public'), DFL_EXTENSIONS_SRC=str(code/'vendor/external/src'),
        ATLANTA_SOURCE_MANIFEST=str(root/'source_receipt.json'), CENTRAL_PATH_FROZEN_DATA=str(root/'frozen_data'),
        PILOT_VALIDATION_DATA=str(root/'validation100'), CP_SPO_GEOMETRY_CACHE=str(root/'policy_geometry_cache'),
        CP_SPO_GEOMETRY_CACHE_READONLY='1', CP_SPO_PREPARATION_CACHE=str(root/'observed_preparation_cache'),
        CENTRAL_PATH_GEOMETRY_CACHE=str(root/'lava_geometry_cache'))
    return env

def candidate_payload(job):
    c = copy.deepcopy(job['config'])
    for key in ('name', 'seeds', 'sizes', 'workers', 'evaluate_test', 'benchmark_id'): c.pop(key, None)
    return {'config': c, 'method': job['method'], 'parameters': job.get('parameters', {}),
        'baseline_protocol':job.get('baseline_protocol'), 'spo_training_domain':job.get('spo_training_domain')}

def make_job(template, seeds, *, step, arm='control', stage='confirmation', dual=False, route=None, test_sizes=None):
    source = template; route = route or source['route']
    j = {k: copy.deepcopy(source[k]) for k in ('config', 'parameters', 'method') if k in source}
    for key in ('baseline_protocol','spo_training_domain','matched_integer_revision'):
        if key in source:j[key]=copy.deepcopy(source[key])
    j.update(route=route, architecture_arm='linear', linear_scale_revision=source.get('linear_scale_revision', 'linear_scale_20260928_v1'),
        physical128_revision='physical_head_test128_20260925_v1', validation_costs='single_sample', analytic_validation=False,
        stage=stage, pilot_revision=REVISION, pilot_step=step, pilot_dual_validation=dual)
    c = j['config']; c.update(benchmark_id=route, seeds=copy.deepcopy(seeds), evaluate_test=stage == 'confirmation',
        sizes={'train':100, 'validation':100 if dual else 32, 'test':128})
    c['training'].update(epochs=300, schedule_reference_epochs=300, selection_mode='validation_regret',
        validation_epochs=EPOCHS, patience=301, torch_threads=1,
        maximum_optimization_seconds=3600.0 if j['method']=='lava' else None)
    if arm in ('no_clip_no_decay', 'no_clip_no_decay_batch32'):
        c['training'].update(gradient_clip=None, weight_decay=0.0)
    if arm in ('batch32', 'no_clip_no_decay_batch32'): c['training']['batch_size'] = 32
    if c['model'].get('depth') != 0 or c['model'].get('correction_depth', 0) != 0:
        raise ValueError('Pilot requires an affine predictor')
    j['resource_limits'] = {'preprocessing_cap_seconds':3600 if j['method']=='lava' else None,
        'job_wall_cap_seconds':9000 if j['method']=='lava' else None}
    j['candidate'] = digest(candidate_payload(j))[:20]
    if dual and stage == 'confirmation':
        j['pilot_test_validation_sizes'] = sorted(set(test_sizes or []))
        if not j['pilot_test_validation_sizes']: raise ValueError('Final dual fit requires frozen selected validation views')
    c.pop('name', None)
    j['id'] = 'pilot__' + digest(j)[:32]; c['name'] = j['id']
    return j

def manifest(job):
    return {'protocol': {'pilot_revision':REVISION}, 'jobs':[job]}

def successful(record):
    return (record is not None and record.get('status') == 'complete'
        and not record.get('smoke_only') and record.get('summary', {}).get('epochs_completed') == 300
        and not record.get('summary', {}).get('optimization_cap_reached'))

def validation_choice(record, n):
    if not successful(record): return None
    if record.get('test_access') or record.get('test_bank_opened') or record['summary'].get('test') is not None:
        raise ValueError('Development selection received test access')
    view = record['summary']['validation_variants'][str(n)]
    return float(view['best_selection_score'])
