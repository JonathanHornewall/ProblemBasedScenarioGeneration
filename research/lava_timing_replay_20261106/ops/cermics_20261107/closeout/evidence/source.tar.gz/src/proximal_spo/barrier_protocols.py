"""Hard-validation trajectories and selected-temperature continuation.

This module is intentionally separate from the legacy trainer.  A single run
produces the three model states needed by the validation experiment:

* the terminal scheduled state;
* the best checkpoint under hard recovered-cost deployment; and
* the best hard-validation state after continuing that checkpoint at fixed
  temperature.

Only hashes and metrics leave the process.  Model and optimizer checkpoints
remain in memory.
"""

from __future__ import annotations

import copy
import time
from dataclasses import asdict, dataclass
from typing import Any, cast

import numpy as np
import torch
from torch import nn

from .artifacts import RunRecorder, model_sha256
from .evaluation import EvaluationMetrics, evaluate_model, predict_in_batches
from .models import module_dtype
from .objectives import (
    LearningObjective,
    LogEnergyPolicyObjective,
    PreparedSplit,
    SoftRadialLogBarrierObjective,
)
from .oracles import OracleStats
from .seeds import derive_seed
from .training import (
    TrainingResult,
    TrainingSpec,
    _learning_rate_at_epoch,
    _optimizer,
    _should_validate,
)

DEPLOYMENT_MODES = ("soft", "hard_recovered")
BarrierObjective = SoftRadialLogBarrierObjective | LogEnergyPolicyObjective


@dataclass(frozen=True)
class BarrierProtocolSpec:
    continuation_epochs: int = 60
    continuation_extension_epochs: int = 60
    continuation_late_window: int = 10
    continuation_minimum_delta: float = 1e-6

    def __post_init__(self) -> None:
        if min(
            self.continuation_epochs,
            self.continuation_extension_epochs,
            self.continuation_late_window,
        ) <= 0:
            raise ValueError("continuation horizons must be positive")
        if self.continuation_minimum_delta <= 0.0:
            raise ValueError("continuation minimum delta must be positive")


@dataclass
class _Checkpoint:
    base_epoch: int
    continuation_epoch: int
    objective_state: dict[str, float | str]
    validation: dict[str, EvaluationMetrics]
    model_state: dict[str, torch.Tensor]
    optimizer_state: dict[str, Any]

    @property
    def temperature(self) -> float:
        value = self.objective_state.get("mu")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("barrier checkpoint omitted its temperature")
        if not np.isfinite(value) or value < 0.0:
            raise ValueError("barrier checkpoint temperature is invalid")
        return float(value)


@dataclass(frozen=True)
class BarrierProtocolResult:
    training_result: TrainingResult
    receipt: dict[str, Any]


@dataclass(frozen=True)
class _Workspace:
    training_device: torch.device
    torch_training: bool
    contexts: torch.Tensor | None
    physical_costs: torch.Tensor | None
    target_values: torch.Tensor | None
    policy_reduced_costs: torch.Tensor | None
    policy_center_costs: torch.Tensor | None


def _workspace(
    model: nn.Module,
    objective: LearningObjective,
    train: PreparedSplit,
    spec: TrainingSpec,
) -> _Workspace:
    torch.set_num_threads(spec.torch_threads)
    training_device = getattr(objective, "training_device", torch.device("cpu"))
    if not isinstance(training_device, torch.device):
        training_device = torch.device(str(training_device))
    torch_training = bool(getattr(objective, "torch_training", False))
    model.to(training_device)
    model_dtype = module_dtype(model)
    return _Workspace(
        training_device=training_device,
        torch_training=torch_training,
        contexts=(
            torch.as_tensor(
                train.contexts,
                dtype=model_dtype,
                device=training_device,
            )
            if torch_training
            else None
        ),
        physical_costs=(
            torch.as_tensor(
                train.physical_costs,
                dtype=model_dtype,
                device=training_device,
            )
            if torch_training
            else None
        ),
        target_values=(
            torch.as_tensor(
                train.target_values,
                dtype=model_dtype,
                device=training_device,
            )
            if torch_training
            else None
        ),
        policy_reduced_costs=(
            torch.as_tensor(
                train.policy_reduced_costs,
                dtype=model_dtype,
                device=training_device,
            )
            if torch_training and train.policy_reduced_costs is not None
            else None
        ),
        policy_center_costs=(
            torch.as_tensor(
                train.policy_center_costs,
                dtype=model_dtype,
                device=training_device,
            )
            if torch_training and train.policy_center_costs is not None
            else None
        ),
    )


def _copy_model_state(model: nn.Module) -> dict[str, torch.Tensor]:
    return {
        name: tensor.detach().cpu().clone()
        for name, tensor in model.state_dict().items()
    }


def _capture(
    *,
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    objective: BarrierObjective,
    validation: dict[str, EvaluationMetrics],
    base_epoch: int,
    continuation_epoch: int,
) -> _Checkpoint:
    return _Checkpoint(
        base_epoch=base_epoch,
        continuation_epoch=continuation_epoch,
        objective_state=dict(objective.state()),
        validation=validation,
        model_state=_copy_model_state(model),
        optimizer_state=copy.deepcopy(optimizer.state_dict()),
    )


def _restore(
    checkpoint: _Checkpoint,
    *,
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
) -> None:
    model.load_state_dict(checkpoint.model_state)
    optimizer.load_state_dict(checkpoint.optimizer_state)


def _evaluate_deployments(
    model: nn.Module,
    objective: BarrierObjective,
    split: PreparedSplit,
    *,
    batch_size: int,
) -> dict[str, EvaluationMetrics]:
    previous = objective.selection_deployment
    result: dict[str, EvaluationMetrics] = {}
    try:
        for mode in DEPLOYMENT_MODES:
            objective.set_deployment_mode(mode)
            result[mode] = evaluate_model(
                model,
                objective,
                split,
                batch_size=batch_size,
            )
    finally:
        objective.set_deployment_mode(previous)
    return result


def _diagnostics(
    model: nn.Module,
    objective: BarrierObjective,
    split: PreparedSplit,
    *,
    batch_size: int,
) -> dict[str, float]:
    outputs = predict_in_batches(model, split.contexts, batch_size=batch_size)
    return objective.diagnostics(outputs)


def _checkpoint_receipt(
    checkpoint: _Checkpoint,
    *,
    label: str,
    model: nn.Module,
    objective: BarrierObjective,
    validation: PreparedSplit,
    test: PreparedSplit,
    evaluation_batch_size: int,
) -> dict[str, Any]:
    validation_metrics = _evaluate_deployments(
        model,
        objective,
        validation,
        batch_size=evaluation_batch_size,
    )
    test_metrics = _evaluate_deployments(
        model,
        objective,
        test,
        batch_size=evaluation_batch_size,
    )
    return {
        "label": label,
        "base_epoch": checkpoint.base_epoch,
        "continuation_epoch": checkpoint.continuation_epoch,
        "effective_model_update_count": (
            checkpoint.base_epoch + checkpoint.continuation_epoch
        ),
        "objective_state": checkpoint.objective_state,
        "parameter_sha256": model_sha256(model),
        "validation": {
            mode: metric.to_dict() for mode, metric in validation_metrics.items()
        },
        "test": {mode: metric.to_dict() for mode, metric in test_metrics.items()},
        "validation_diagnostics": _diagnostics(
            model,
            objective,
            validation,
            batch_size=evaluation_batch_size,
        ),
        "test_diagnostics": _diagnostics(
            model,
            objective,
            test,
            batch_size=evaluation_batch_size,
        ),
    }


def _train_epoch(
    *,
    model: nn.Module,
    objective: BarrierObjective,
    train: PreparedSplit,
    spec: TrainingSpec,
    optimizer: torch.optim.Optimizer,
    workspace: _Workspace,
    shuffle_seed: int,
    seed_phase: str,
    epoch: int,
    learning_rate: float,
) -> tuple[dict[str, Any], OracleStats]:
    model.train()
    for parameter_group in optimizer.param_groups:
        parameter_group["lr"] = learning_rate
    generator = np.random.Generator(
        np.random.PCG64(derive_seed(shuffle_seed, seed_phase, epoch))
    )
    order = generator.permutation(len(train.contexts)).astype(np.int64)
    tensor_order = (
        torch.as_tensor(
            order,
            dtype=torch.int64,
            device=workspace.training_device,
        )
        if workspace.torch_training
        else None
    )
    epoch_values: list[np.ndarray] = []
    epoch_components: dict[str, list[np.ndarray]] = {}
    output_gradient_norms: list[np.ndarray] = []
    parameter_gradient_norms: list[float] = []
    clipped_batches = 0
    batch_count = 0
    model_dtype = module_dtype(model)
    trainable_parameters = [
        parameter for parameter in model.parameters() if parameter.requires_grad
    ]
    device_value_sum = torch.zeros(
        (), dtype=model_dtype, device=workspace.training_device
    )
    device_component_sums: dict[str, torch.Tensor] = {}
    device_output_norm_sum = torch.zeros(
        (), dtype=model_dtype, device=workspace.training_device
    )
    device_output_norm_max = torch.zeros(
        (), dtype=model_dtype, device=workspace.training_device
    )
    device_parameter_norm_sum = torch.zeros(
        (), dtype=model_dtype, device=workspace.training_device
    )
    device_parameter_norm_max = torch.zeros(
        (), dtype=model_dtype, device=workspace.training_device
    )
    device_clipped_batches = torch.zeros(
        (), dtype=torch.int64, device=workspace.training_device
    )
    device_sample_count = 0
    device_output_diagnostic_count = 0
    epoch_stats = OracleStats()
    epoch_started = time.perf_counter()
    for start in range(0, len(order), spec.batch_size):
        indices = order[start : start + spec.batch_size]
        if workspace.torch_training:
            if (
                workspace.contexts is None
                or workspace.physical_costs is None
                or workspace.target_values is None
            ):
                raise RuntimeError("Torch protocol tensors were not prepared")
            if tensor_order is None:
                raise RuntimeError("Torch shuffle order was not prepared")
            tensor_indices = tensor_order[start : start + len(indices)]
            contexts = workspace.contexts[tensor_indices]
            batch_physical_costs = workspace.physical_costs[tensor_indices]
            batch_target_values = workspace.target_values[tensor_indices]
            batch_policy_reduced_costs = (
                None
                if workspace.policy_reduced_costs is None
                else workspace.policy_reduced_costs[tensor_indices]
            )
            batch_policy_center_costs = (
                None
                if workspace.policy_center_costs is None
                else workspace.policy_center_costs[tensor_indices]
            )
        else:
            contexts = torch.as_tensor(
                train.contexts[indices],
                dtype=module_dtype(model),
                device=workspace.training_device,
            )
        outputs = model(contexts)
        optimizer.zero_grad(set_to_none=True)
        collect_output_diagnostic = (
            batch_count % spec.gradient_diagnostic_interval == 0
        )
        if workspace.torch_training:
            if collect_output_diagnostic:
                outputs.retain_grad()
            torch_signal = cast(Any, objective).torch_signal(
                outputs,
                batch_physical_costs,
                batch_target_values,
                batch_policy_reduced_costs,
                batch_policy_center_costs,
            )
            torch_signal.values.mean().backward()
            device_value_sum += torch.sum(torch_signal.values.detach())
            device_sample_count += len(indices)
            if collect_output_diagnostic:
                if outputs.grad is None:
                    raise RuntimeError(
                        "Torch objective did not produce output gradients"
                    )
                output_gradient_tensor = outputs.grad.detach() * len(indices)
                output_norms = torch.linalg.vector_norm(output_gradient_tensor, dim=1)
                device_output_norm_sum += torch.sum(output_norms)
                device_output_norm_max = torch.maximum(
                    device_output_norm_max,
                    torch.max(output_norms),
                )
                device_output_diagnostic_count += len(indices)
            if torch_signal.components is not None:
                for name, values in torch_signal.components.items():
                    component_sum = torch.sum(values.detach())
                    device_component_sums[name] = (
                        component_sum
                        if name not in device_component_sums
                        else device_component_sums[name] + component_sum
                    )
            epoch_stats += torch_signal.stats
        else:
            signal = objective.signal(
                outputs.detach().cpu().numpy(), train.subset(indices)
            )
            gradient = torch.as_tensor(
                signal.output_gradient / len(indices),
                dtype=outputs.dtype,
                device=workspace.training_device,
            )
            outputs.backward(gradient=gradient)
            output_gradient = signal.output_gradient
            epoch_values.append(signal.values)
            if signal.components is not None:
                for name, values in signal.components.items():
                    epoch_components.setdefault(name, []).append(values)
            epoch_stats += signal.stats
            if collect_output_diagnostic:
                output_gradient_norms.append(np.linalg.norm(output_gradient, axis=1))
        if spec.gradient_clip is not None:
            gradient_norm = torch.nn.utils.clip_grad_norm_(
                trainable_parameters,
                max_norm=spec.gradient_clip,
            )
            detached_gradient_norm = gradient_norm.detach().to(
                device=workspace.training_device,
                dtype=model_dtype,
            )
        else:
            squared = torch.zeros(
                (), dtype=model_dtype, device=workspace.training_device
            )
            for parameter in trainable_parameters:
                if parameter.grad is not None:
                    squared += torch.sum(parameter.grad.detach().square())
            detached_gradient_norm = torch.sqrt(squared)
        if workspace.torch_training:
            device_parameter_norm_sum += detached_gradient_norm
            device_parameter_norm_max = torch.maximum(
                device_parameter_norm_max,
                detached_gradient_norm,
            )
            if spec.gradient_clip is not None:
                device_clipped_batches += (
                    detached_gradient_norm > spec.gradient_clip
                ).to(torch.int64)
        else:
            norm_value = float(detached_gradient_norm.cpu())
            if spec.gradient_clip is not None and norm_value > spec.gradient_clip:
                clipped_batches += 1
            parameter_gradient_norms.append(norm_value)
        batch_count += 1
        optimizer.step()
    if workspace.torch_training:
        if (
            device_sample_count == 0
            or device_output_diagnostic_count == 0
            or batch_count == 0
        ):
            raise RuntimeError("training epoch contained no samples")
        diagnostic_values = (
            torch.stack(
                (
                    device_value_sum / device_sample_count,
                    device_output_norm_sum / device_output_diagnostic_count,
                    device_output_norm_max,
                    device_parameter_norm_sum / batch_count,
                    device_parameter_norm_max,
                    device_clipped_batches.to(model_dtype) / batch_count,
                )
            )
            .detach()
            .cpu()
            .tolist()
        )
        record = {
            "learning_rate": learning_rate,
            "train_surrogate_mean": diagnostic_values[0],
            "epoch_wall_seconds": time.perf_counter() - epoch_started,
            "training_oracle_stats": asdict(epoch_stats),
            "mean_output_gradient_norm": diagnostic_values[1],
            "maximum_output_gradient_norm": diagnostic_values[2],
            "mean_parameter_gradient_norm": diagnostic_values[3],
            "maximum_parameter_gradient_norm": diagnostic_values[4],
            "gradient_clipped_batch_rate": diagnostic_values[5],
            "output_gradient_diagnostic_batch_interval": (
                spec.gradient_diagnostic_interval
            ),
            "output_gradient_diagnostic_sample_count": (
                device_output_diagnostic_count
            ),
        }
        if device_component_sums:
            names = sorted(device_component_sums)
            means = (
                torch.stack(
                    [
                        device_component_sums[name] / device_sample_count
                        for name in names
                    ]
                )
                .detach()
                .cpu()
                .tolist()
            )
            record["train_surrogate_components"] = dict(
                zip(names, means, strict=True)
            )
    else:
        record = {
            "learning_rate": learning_rate,
            "train_surrogate_mean": float(np.mean(np.concatenate(epoch_values))),
            "epoch_wall_seconds": time.perf_counter() - epoch_started,
            "training_oracle_stats": asdict(epoch_stats),
            "mean_output_gradient_norm": float(
                np.mean(np.concatenate(output_gradient_norms))
            ),
            "maximum_output_gradient_norm": float(
                np.max(np.concatenate(output_gradient_norms))
            ),
            "mean_parameter_gradient_norm": float(np.mean(parameter_gradient_norms)),
            "maximum_parameter_gradient_norm": float(
                np.max(parameter_gradient_norms)
            ),
            "gradient_clipped_batch_rate": (
                0.0 if batch_count == 0 else clipped_batches / batch_count
            ),
            "output_gradient_diagnostic_batch_interval": (
                spec.gradient_diagnostic_interval
            ),
            "output_gradient_diagnostic_sample_count": int(
                sum(len(values) for values in output_gradient_norms)
            ),
        }
        if epoch_components:
            record["train_surrogate_components"] = {
                name: float(np.mean(np.concatenate(values)))
                for name, values in sorted(epoch_components.items())
            }
    return record, epoch_stats


def train_barrier_protocol_suite(
    *,
    model: nn.Module,
    objective: BarrierObjective,
    train: PreparedSplit,
    validation: PreparedSplit,
    test: PreparedSplit,
    spec: TrainingSpec,
    protocol: BarrierProtocolSpec,
    shuffle_seed: int,
    recorder: RunRecorder,
    epoch_callback: Any | None = None,
) -> BarrierProtocolResult:
    """Train one scheduled trajectory and its selected-temperature continuation."""

    objective.set_checkpoint_selection_deployment("hard_recovered")
    workspace = _workspace(model, objective, train, spec)
    optimizer = _optimizer(model, spec)
    total_stats = OracleStats()
    wall_started = time.perf_counter()
    cpu_started = time.process_time()
    continuation_executed = 0
    try:
        initial_validation = _evaluate_deployments(
            model,
            objective,
            validation,
            batch_size=spec.evaluation_batch_size,
        )
        hard_checkpoint = _capture(
            model=model,
            optimizer=optimizer,
            objective=objective,
            validation=initial_validation,
            base_epoch=0,
            continuation_epoch=0,
        )
        recorder.append_curve(
            {
                "epoch": 0,
                "phase": "scheduled_base",
                "phase_epoch": 0,
                "validation": initial_validation["hard_recovered"].to_dict(),
                "validation_deployments": {
                    mode: metric.to_dict()
                    for mode, metric in initial_validation.items()
                },
                "checkpoint_selected_by": "hard_recovered",
                "selected_so_far": True,
                "initialization_checkpoint": True,
                "objective_state": objective.state(),
            }
        )
        for epoch in range(1, spec.epochs + 1):
            objective.set_epoch(epoch, spec.epochs)
            record, stats = _train_epoch(
                model=model,
                objective=objective,
                train=train,
                spec=spec,
                optimizer=optimizer,
                workspace=workspace,
                shuffle_seed=shuffle_seed,
                seed_phase="epoch",
                epoch=epoch,
                learning_rate=_learning_rate_at_epoch(spec, epoch),
            )
            total_stats += stats
            record.update(
                {
                    "epoch": epoch,
                    "phase": "scheduled_base",
                    "phase_epoch": epoch,
                    "objective_state": objective.state(),
                }
            )
            if _should_validate(spec, epoch):
                metrics = _evaluate_deployments(
                    model,
                    objective,
                    validation,
                    batch_size=spec.evaluation_batch_size,
                )
                hard = metrics["hard_recovered"]
                improved = (
                    hard.mean_regret
                    < hard_checkpoint.validation["hard_recovered"].mean_regret
                    - spec.minimum_delta
                )
                if improved:
                    hard_checkpoint = _capture(
                        model=model,
                        optimizer=optimizer,
                        objective=objective,
                        validation=metrics,
                        base_epoch=epoch,
                        continuation_epoch=0,
                    )
                record["validation"] = hard.to_dict()
                record["validation_deployments"] = {
                    mode: metric.to_dict() for mode, metric in metrics.items()
                }
                record["checkpoint_selected_by"] = "hard_recovered"
                record["selected_so_far"] = improved
            recorder.append_curve(record)
            if epoch_callback is not None:
                epoch_callback(record)

        terminal_validation = _evaluate_deployments(
            model,
            objective,
            validation,
            batch_size=spec.evaluation_batch_size,
        )
        terminal = _capture(
            model=model,
            optimizer=optimizer,
            objective=objective,
            validation=terminal_validation,
            base_epoch=spec.epochs,
            continuation_epoch=0,
        )
        terminal_receipt = _checkpoint_receipt(
            terminal,
            label="terminal",
            model=model,
            objective=objective,
            validation=validation,
            test=test,
            evaluation_batch_size=spec.evaluation_batch_size,
        )

        _restore(hard_checkpoint, model=model, optimizer=optimizer)
        objective.freeze_temperature(hard_checkpoint.temperature)
        checkpoint_receipt = _checkpoint_receipt(
            hard_checkpoint,
            label="hard_checkpoint",
            model=model,
            objective=objective,
            validation=validation,
            test=test,
            evaluation_batch_size=spec.evaluation_batch_size,
        )

        continuation_validation = _evaluate_deployments(
            model,
            objective,
            validation,
            batch_size=spec.evaluation_batch_size,
        )
        continuation_best = _capture(
            model=model,
            optimizer=optimizer,
            objective=objective,
            validation=continuation_validation,
            base_epoch=hard_checkpoint.base_epoch,
            continuation_epoch=0,
        )
        recorder.append_curve(
            {
                "epoch": spec.epochs,
                "phase": "selected_mu_continuation",
                "phase_epoch": 0,
                "source_base_epoch": hard_checkpoint.base_epoch,
                "validation": continuation_validation[
                    "hard_recovered"
                ].to_dict(),
                "validation_deployments": {
                    mode: metric.to_dict()
                    for mode, metric in continuation_validation.items()
                },
                "checkpoint_selected_by": "hard_recovered",
                "selected_so_far": True,
                "objective_state": objective.state(),
            }
        )
        initial_horizon = protocol.continuation_epochs
        maximum_horizon = (
            protocol.continuation_epochs + protocol.continuation_extension_epochs
        )
        continuation_horizon = initial_horizon
        continuation_epoch = 0
        while continuation_epoch < continuation_horizon:
            continuation_epoch += 1
            record, stats = _train_epoch(
                model=model,
                objective=objective,
                train=train,
                spec=spec,
                optimizer=optimizer,
                workspace=workspace,
                shuffle_seed=shuffle_seed,
                seed_phase="selected_mu_continuation",
                epoch=continuation_epoch,
                learning_rate=_learning_rate_at_epoch(spec, spec.epochs),
            )
            total_stats += stats
            continuation_executed = continuation_epoch
            record.update(
                {
                    "epoch": spec.epochs + continuation_epoch,
                    "phase": "selected_mu_continuation",
                    "phase_epoch": continuation_epoch,
                    "source_base_epoch": hard_checkpoint.base_epoch,
                    "objective_state": objective.state(),
                }
            )
            if (
                continuation_epoch % spec.validation_interval == 0
                or continuation_epoch == continuation_horizon
            ):
                metrics = _evaluate_deployments(
                    model,
                    objective,
                    validation,
                    batch_size=spec.evaluation_batch_size,
                )
                hard = metrics["hard_recovered"]
                improved = (
                    hard.mean_regret
                    < continuation_best.validation[
                        "hard_recovered"
                    ].mean_regret
                    - protocol.continuation_minimum_delta
                )
                if improved:
                    continuation_best = _capture(
                        model=model,
                        optimizer=optimizer,
                        objective=objective,
                        validation=metrics,
                        base_epoch=hard_checkpoint.base_epoch,
                        continuation_epoch=continuation_epoch,
                    )
                record["validation"] = hard.to_dict()
                record["validation_deployments"] = {
                    mode: metric.to_dict() for mode, metric in metrics.items()
                }
                record["checkpoint_selected_by"] = "hard_recovered"
                record["selected_so_far"] = improved
            recorder.append_curve(record)
            if epoch_callback is not None:
                epoch_callback(record)
            if continuation_epoch == initial_horizon:
                late_threshold = max(
                    0,
                    initial_horizon - protocol.continuation_late_window,
                )
                if continuation_best.continuation_epoch >= late_threshold:
                    continuation_horizon = maximum_horizon

        _restore(continuation_best, model=model, optimizer=optimizer)
        objective.freeze_temperature(continuation_best.temperature)
        continuation_receipt = _checkpoint_receipt(
            continuation_best,
            label="selected_mu_continuation",
            model=model,
            objective=objective,
            validation=validation,
            test=test,
            evaluation_batch_size=spec.evaluation_batch_size,
        )
        hard_validation = cast(
            dict[str, dict[str, Any]], continuation_receipt["validation"]
        )["hard_recovered"]
        hard_test = cast(
            dict[str, dict[str, Any]], continuation_receipt["test"]
        )["hard_recovered"]
        training_result = TrainingResult(
            best_epoch=(
                continuation_best.base_epoch
                + continuation_best.continuation_epoch
            ),
            epochs_completed=spec.epochs + continuation_executed,
            best_validation=EvaluationMetrics(
                **{
                    **hard_validation,
                    "oracle_stats": OracleStats(
                        **cast(dict[str, Any], hard_validation["oracle_stats"])
                    ),
                }
            ),
            test=EvaluationMetrics(
                **{
                    **hard_test,
                    "oracle_stats": OracleStats(
                        **cast(dict[str, Any], hard_test["oracle_stats"])
                    ),
                }
            ),
            training_wall_seconds=time.perf_counter() - wall_started,
            training_cpu_seconds=time.process_time() - cpu_started,
            total_training_oracle_stats=total_stats,
            parameter_sha256=model_sha256(model),
            trainable_parameters=sum(
                parameter.numel()
                for parameter in model.parameters()
                if parameter.requires_grad
            ),
        )
        receipt = {
            "protocol": "hard_checkpoint_fixed_temperature_v1",
            "checkpoint_selection_deployment": "hard_recovered",
            "checkpoint_selection_metric": "validation_mean_regret",
            "soft_validation_selects_epochs": False,
            "base_early_stopping": False,
            "base_executed_epochs": spec.epochs,
            "continuation": {
                **asdict(protocol),
                "selected_temperature": hard_checkpoint.temperature,
                "source_base_epoch": hard_checkpoint.base_epoch,
                "executed_epochs": continuation_executed,
                "extension_activated": continuation_executed > initial_horizon,
                "optimizer_state_preserved": True,
                "shuffle_stream": "selected_mu_continuation",
            },
            "states": {
                "terminal": terminal_receipt,
                "hard_checkpoint": checkpoint_receipt,
                "selected_mu_continuation": continuation_receipt,
            },
            "derived_protocols": {
                "terminal": "rank terminal states across arms",
                "hard_checkpoint": "rank hard_checkpoint states across arms",
                "winner_only_hold": (
                    "rank hard_checkpoint states, then use that arm's "
                    "selected_mu_continuation state"
                ),
                "all_arm_hold": (
                    "rank selected_mu_continuation states across all arms"
                ),
            },
            "weights_or_optimizer_states_persisted": False,
        }
        model.to(torch.device("cpu"))
        recorder.finish(training_result.to_dict())
        return BarrierProtocolResult(training_result, receipt)
    except BaseException as error:
        model.to(torch.device("cpu"))
        recorder.fail(error)
        raise
