"""Torch-resident log-energy chart with an exact analytic first derivative.

The scalar ray inversion is intentionally evaluated without building an
autograd tape.  The returned value is then reattached to the neural graph by a
zero-valued first-order correction whose Jacobian is the exact implicit-map
Jacobian.  This keeps both the reports and their gradients on the selected
device without retaining every safeguarded root iteration.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

import numpy as np
import torch

from .oracles import OracleFailure

if TYPE_CHECKING:
    from .feasible_policies import PolyhedralPolicyGeometry


@dataclass(frozen=True)
class TorchPolicyBatch:
    """Torch policy values used by the device-resident training objective."""

    decisions: torch.Tensor
    reduced_decisions: torch.Tensor
    energy_targets: torch.Tensor
    energy_guard_active: torch.Tensor
    energy_solver_iterations: int


class TorchLogEnergyKernel:
    """Dense Torch implementation of the batched log-energy chart."""

    def __init__(
        self,
        geometry: PolyhedralPolicyGeometry,
        *,
        device: torch.device,
    ) -> None:
        self.device = device
        self.dtype = torch.float64
        self.center = torch.as_tensor(geometry.center, dtype=self.dtype, device=device)
        self.physical_map_transpose = torch.as_tensor(
            geometry.physical_map_transpose,
            dtype=self.dtype,
            device=device,
        )
        self.normalized_inequalities = torch.as_tensor(
            geometry.normalized_inequalities,
            dtype=self.dtype,
            device=device,
        )
        self.normalized_inequalities_transpose = torch.as_tensor(
            geometry.normalized_inequalities_transpose,
            dtype=self.dtype,
            device=device,
        )
        self.intrinsic_dimension = geometry.intrinsic_dimension

    @staticmethod
    def _energy_from_loads(loads: torch.Tensor) -> torch.Tensor:
        terms = torch.log1p(-loads)
        terms.add_(loads)
        return -torch.sum(terms, dim=1)

    def map(
        self,
        reports: torch.Tensor,
        *,
        root_tolerance: float,
        maximum_iterations: int = 80,
        boundary_margin: float = 1e-8,
        safety_energy_gap: float = 0.1,
        guard_mode: Literal["exact", "uncapped", "legacy_capped"] = "uncapped",
    ) -> TorchPolicyBatch:
        """Map reports and attach the exact implicit first derivative."""

        if reports.device != self.device:
            raise ValueError("Torch log-energy reports are on the wrong device")
        if reports.dtype != self.dtype:
            raise ValueError("Torch log-energy reports must use float64")
        if reports.ndim != 2 or reports.shape[1] != self.intrinsic_dimension:
            raise ValueError("Torch log-energy reports have the wrong shape")
        if root_tolerance <= 0.0 or not np.isfinite(root_tolerance):
            raise ValueError("root_tolerance must be finite and positive")
        if maximum_iterations <= 0:
            raise ValueError("maximum_iterations must be positive")
        if not 0.0 < boundary_margin < 1.0:
            raise ValueError("boundary_margin must lie between zero and one")
        if safety_energy_gap <= 0.0 or not np.isfinite(safety_energy_gap):
            raise ValueError("safety_energy_gap must be finite and positive")
        if guard_mode not in {"exact", "uncapped", "legacy_capped"}:
            raise ValueError("unknown log-energy guard mode")

        with torch.no_grad():
            if not bool(torch.isfinite(reports).all()):
                raise ValueError("Torch log-energy reports must be finite")
            norms = torch.linalg.vector_norm(reports, dim=1)
            raw_targets = 0.5 * torch.sum(reports.square(), dim=1)
            reduced = torch.zeros_like(reports)
            gradients = torch.zeros_like(reports)
            scales = torch.ones_like(norms)
            targets = raw_targets.clone()
            target_gradients = reports.clone()
            guard_active = torch.zeros_like(norms, dtype=torch.bool)
            near_center = norms <= 1e-6

            if bool(near_center.any()):
                center_reports = reports[near_center]
                center_loads = center_reports @ self.normalized_inequalities_transpose
                center_slacks = 1.0 - center_loads
                if bool((center_slacks <= 0.0).any()):
                    raise OracleFailure(
                        "Torch log-energy center chart left the interior"
                    )
                reduced[near_center] = center_reports
                gradients[near_center] = (
                    center_loads / center_slacks
                ) @ self.normalized_inequalities

            away = ~near_center
            solver_iterations = 0
            if bool(away.any()):
                away_reports = reports[away]
                away_norms = norms[away]
                directions = away_reports / away_norms[:, None]
                coefficients = directions @ self.normalized_inequalities_transpose
                maximum_load = torch.max(coefficients, dim=1).values
                if bool((maximum_load <= 0.0).any()):
                    raise OracleFailure("polytope is not radially bounded")
                boundaries = 1.0 / maximum_load
                maximum_log_gap = -float(np.log(boundary_margin))
                boundary_fraction = 1.0 - boundary_margin
                upper_radii = boundaries * boundary_fraction
                upper_loads = upper_radii[:, None] * coefficients
                upper_slacks = 1.0 - upper_loads
                caps = self._energy_from_loads(upper_loads)
                if bool((~torch.isfinite(caps) | (caps <= 0.0)).any()):
                    raise OracleFailure(
                        "Torch log-energy direction has no finite energy cap"
                    )
                away_raw_targets = raw_targets[away]
                away_targets = away_raw_targets.clone()
                away_target_gradients = away_reports.clone()
                if guard_mode == "exact":
                    if bool((away_raw_targets > caps).any()):
                        raise OracleFailure(
                            "exact Torch log-energy report exceeds the numerical chart"
                        )
                else:
                    if bool((caps <= safety_energy_gap).any()):
                        raise OracleFailure(
                            "Torch log-energy cap is smaller than its safety gap"
                        )
                    thresholds = caps - safety_energy_gap
                    away_guard = away_raw_targets > thresholds
                    if bool(away_guard.any()):
                        tails = away_raw_targets - thresholds
                        denominators = safety_energy_gap + tails
                        target_derivatives = (safety_energy_gap / denominators).square()
                        guarded_targets = (
                            thresholds + safety_energy_gap * tails / denominators
                        )
                        away_targets = torch.where(
                            away_guard, guarded_targets, away_targets
                        )
                        upper_gradients = (
                            upper_loads / upper_slacks
                        ) @ self.normalized_inequalities
                        active_normals = self.normalized_inequalities[
                            torch.argmax(coefficients, dim=1)
                        ]
                        radial_inner = torch.sum(upper_gradients * directions, dim=1)
                        cap_direction_gradients = (
                            upper_radii[:, None] * upper_gradients
                            - (upper_radii.square() / boundary_fraction * radial_inner)[
                                :, None
                            ]
                            * active_normals
                        )
                        cap_direction_gradients -= (
                            directions
                            * torch.sum(
                                directions * cap_direction_gradients,
                                dim=1,
                            )[:, None]
                        )
                        cap_report_gradients = (
                            cap_direction_gradients / away_norms[:, None]
                        )
                        guarded_target_gradients = (
                            target_derivatives[:, None] * away_reports
                            + (1.0 - target_derivatives)[:, None] * cap_report_gradients
                        )
                        away_target_gradients = torch.where(
                            away_guard[:, None],
                            guarded_target_gradients,
                            away_target_gradients,
                        )
                    guard_active[away] = away_guard

                targets[away] = away_targets
                target_gradients[away] = away_target_gradients
                initial_fraction = torch.minimum(
                    away_norms / boundaries,
                    torch.full_like(away_norms, boundary_fraction),
                )
                log_gaps = -torch.log1p(-initial_fraction)

                boundary_limited = initial_fraction >= boundary_fraction
                if bool(boundary_limited.any()):
                    limited_coefficients = coefficients[boundary_limited]
                    normalized_coefficients = (
                        limited_coefficients / maximum_load[boundary_limited, None]
                    )
                    dominant = normalized_coefficients >= 1.0 - 1e-7
                    regular_terms = torch.zeros_like(normalized_coefficients)
                    regular = ~dominant
                    regular_coefficients = normalized_coefficients[regular]
                    regular_terms[regular] = (
                        -torch.log1p(-regular_coefficients) - regular_coefficients
                    )
                    estimates = 1.0 + (
                        away_targets[boundary_limited] - torch.sum(regular_terms, dim=1)
                    ) / torch.sum(dominant, dim=1)
                    log_gaps[boundary_limited] = torch.clamp(
                        estimates,
                        min=1e-12,
                        max=maximum_log_gap,
                    )

                lower = torch.zeros_like(log_gaps)
                upper = torch.full_like(log_gaps, maximum_log_gap)
                converged = torch.zeros_like(log_gaps, dtype=torch.bool)
                for iteration in range(1, maximum_iterations + 1):
                    solver_iterations = iteration
                    radii = boundaries * -torch.expm1(-log_gaps)
                    ray_loads = radii[:, None] * coefficients
                    ray_slacks = 1.0 - ray_loads
                    if self.device.type == "cpu" and bool(
                        (ray_slacks <= 0.0).any()
                    ):
                        raise OracleFailure("Torch log-energy iterate left its bracket")
                    values = self._energy_from_loads(ray_loads)
                    residuals = values - away_targets
                    converged |= torch.abs(residuals) <= root_tolerance * (
                        1.0 + away_targets
                    )
                    # CPU benefits from immediate termination.  GPU execution
                    # synchronizes only in blocks so host-device latency does
                    # not dominate the scalar inversion.
                    check_now = self.device.type == "cpu" or iteration % 8 == 0
                    if check_now and bool(converged.all()):
                        break
                    lower = torch.where(
                        (residuals < 0.0) & ~converged,
                        log_gaps,
                        lower,
                    )
                    upper = torch.where(
                        (residuals >= 0.0) & ~converged,
                        log_gaps,
                        upper,
                    )
                    radial_derivatives = torch.sum(
                        coefficients * ray_loads / ray_slacks,
                        dim=1,
                    )
                    log_gap_derivatives = radial_derivatives * (boundaries - radii)
                    newton = log_gaps - residuals / log_gap_derivatives
                    midpoint = 0.5 * (lower + upper)
                    bracket_width = upper - lower
                    admissible = (
                        torch.isfinite(newton)
                        & (newton > lower)
                        & (newton < upper)
                        & (torch.abs(newton - log_gaps) <= 0.5 * bracket_width)
                    )
                    candidates = torch.where(admissible, newton, midpoint)
                    log_gaps = torch.where(converged, log_gaps, candidates)
                else:
                    raise OracleFailure("Torch log-energy iteration limit reached")

                radii = boundaries * -torch.expm1(-log_gaps)
                final_loads = radii[:, None] * coefficients
                final_slacks = 1.0 - final_loads
                if bool((final_slacks <= 0.0).any()):
                    raise OracleFailure(
                        "Torch log-energy root left its certified bracket"
                    )
                final_values = self._energy_from_loads(final_loads)
                errors = torch.abs(final_values - away_targets)
                if bool((errors > root_tolerance * (1.0 + away_targets)).any()):
                    raise OracleFailure(
                        "Torch log-energy root failed its energy certificate"
                    )
                reduced[away] = radii[:, None] * directions
                gradients[away] = (
                    final_loads / final_slacks
                ) @ self.normalized_inequalities
                scales[away] = radii / away_norms

            denominators = torch.sum(gradients * reports, dim=1)
            away_denominators = denominators[away]
            if bool((away_denominators <= 0.0).any()):
                raise OracleFailure("Torch log-energy VJP has nonpositive denominator")

        # Reattach the exact implicit Jacobian without retaining the root
        # solver's temporary tensors.  The correction is identically zero in
        # the forward pass and has the required derivative in the backward pass.
        delta = reports - reports.detach()
        jacobian_scales = scales.clone()
        jacobian_vectors = target_gradients - scales[:, None] * gradients
        jacobian_denominators = denominators.clone()
        jacobian_vectors[near_center] = 0.0
        jacobian_denominators[near_center] = 1.0
        linearized_reduced = (
            reduced.detach()
            + jacobian_scales[:, None] * delta
            + reports.detach()
            * (torch.sum(jacobian_vectors * delta, dim=1) / jacobian_denominators)[
                :, None
            ]
        )
        decisions = self.center + linearized_reduced @ self.physical_map_transpose
        linearized_targets = targets.detach() + torch.sum(
            target_gradients * delta, dim=1
        )
        return TorchPolicyBatch(
            decisions=decisions,
            reduced_decisions=linearized_reduced,
            energy_targets=linearized_targets,
            energy_guard_active=guard_active,
            energy_solver_iterations=solver_iterations,
        )
