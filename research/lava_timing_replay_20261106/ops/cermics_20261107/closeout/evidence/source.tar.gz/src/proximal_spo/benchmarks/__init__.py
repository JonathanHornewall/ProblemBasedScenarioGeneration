"""Benchmark registry."""

from .catalog import BENCHMARKS, build_benchmark, list_benchmarks

__all__ = ["BENCHMARKS", "build_benchmark", "list_benchmarks"]
