"""Paired 2x2 analysis of barrier training and hard recovered deployment."""

from __future__ import annotations

import hashlib
import itertools
import json
import math
from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from statistics import fmean, stdev
from typing import Any

from scipy import stats

from .confirmation_analysis import completed_confirmation_rows

CELL_ORDER = (
    "no_barrier_soft",
    "no_barrier_hard",
    "barrier_soft",
    "barrier_hard",
)

CONTRASTS = (
    (
        "barrier_given_soft",
        "barrier_soft",
        "no_barrier_soft",
        "barrier minus no barrier under soft deployment",
    ),
    (
        "barrier_given_hard",
        "barrier_hard",
        "no_barrier_hard",
        "barrier minus no barrier under hard recovered deployment",
    ),
    (
        "hard_given_no_barrier",
        "no_barrier_hard",
        "no_barrier_soft",
        "hard recovered minus soft deployment without the barrier",
    ),
    (
        "hard_given_barrier",
        "barrier_hard",
        "barrier_soft",
        "hard recovered minus soft deployment with the barrier",
    ),
)


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object at {path}")
    return payload


def _mean_interval(values: Sequence[float]) -> dict[str, float | int]:
    if not values:
        raise ValueError("cannot summarize an empty sample")
    mean = fmean(values)
    if len(values) == 1:
        deviation = 0.0
        half_width = 0.0
    else:
        deviation = stdev(values)
        half_width = (
            float(stats.t.ppf(0.975, len(values) - 1))
            * deviation
            / math.sqrt(len(values))
        )
    return {
        "count": len(values),
        "mean": mean,
        "sample_standard_deviation": deviation,
        "ci95_lower": mean - half_width,
        "ci95_upper": mean + half_width,
    }


def _replication_seed_key(
    seed_key: tuple[tuple[str, int], ...],
) -> tuple[tuple[str, int], ...]:
    result = tuple(item for item in seed_key if item[0] != "structural")
    if not result:
        raise ValueError("confirmation seed bundle has no replication seeds")
    return result


def _cell(method_parameters: Mapping[str, Any]) -> str:
    alpha_start = method_parameters.get("alpha_start")
    alpha_end = method_parameters.get("alpha_end")
    if not isinstance(alpha_start, (int, float)) or isinstance(alpha_start, bool):
        raise ValueError("mechanism run lacks numeric alpha_start")
    if not isinstance(alpha_end, (int, float)) or isinstance(alpha_end, bool):
        raise ValueError("mechanism run lacks numeric alpha_end")
    if not math.isfinite(float(alpha_start)) or not math.isfinite(float(alpha_end)):
        raise ValueError("mechanism run has non-finite barrier weight")
    if float(alpha_start) < 0 or float(alpha_end) < 0:
        raise ValueError("mechanism run has a negative barrier weight")
    barrier = float(alpha_start) > 0 or float(alpha_end) > 0
    deployment = method_parameters.get("deployment_mode")
    if deployment == "soft":
        suffix = "soft"
    elif deployment == "hard_recovered":
        suffix = "hard"
    else:
        raise ValueError(f"unsupported mechanism deployment: {deployment!r}")
    return f"{'barrier' if barrier else 'no_barrier'}_{suffix}"


def _exact_sign_flip_pvalue(values: Sequence[float]) -> float:
    """Two-sided exact randomization p-value for a paired mean difference."""

    if not values:
        raise ValueError("cannot test an empty paired sample")
    if len(values) > 20:
        raise ValueError("exact sign-flip enumeration is limited to 20 pairs")
    if all(abs(value) <= 1e-15 for value in values):
        return 1.0
    observed = abs(fmean(values))
    exceedances = 0
    total = 1 << len(values)
    for signs in itertools.product((-1.0, 1.0), repeat=len(values)):
        statistic = abs(
            fmean(
                value * sign
                for value, sign in zip(values, signs, strict=True)
            )
        )
        if statistic >= observed - 1e-15:
            exceedances += 1
    return exceedances / total


def _holm_adjust(records: list[dict[str, Any]], output_key: str) -> None:
    ordered = sorted(enumerate(records), key=lambda item: item[1]["pvalue_raw"])
    running = 0.0
    count = len(ordered)
    for rank, (index, record) in enumerate(ordered):
        adjusted = min(1.0, (count - rank) * float(record["pvalue_raw"]))
        running = max(running, adjusted)
        records[index][output_key] = running


def _paired_contrast(
    left: Mapping[tuple[tuple[str, int], ...], float],
    right: Mapping[tuple[tuple[str, int], ...], float],
    *,
    name: str,
    left_cell: str,
    right_cell: str,
    definition: str,
) -> dict[str, Any]:
    if set(left) != set(right):
        raise ValueError(f"paired seeds differ for contrast {name}")
    differences = [left[seed] - right[seed] for seed in sorted(left)]
    return {
        "contrast": name,
        "left_cell": left_cell,
        "right_cell": right_cell,
        "difference_definition": definition,
        "difference": _mean_interval(differences),
        "left_wins": sum(value < -1e-12 for value in differences),
        "ties": sum(abs(value) <= 1e-12 for value in differences),
        "left_losses": sum(value > 1e-12 for value in differences),
        "pvalue_raw": _exact_sign_flip_pvalue(differences),
        "paired_differences": differences,
    }


def _same_checkpoint_deployment_difference(
    row: Mapping[str, Any], *, expected_selection_mode: str
) -> float:
    """Return hard-minus-soft regret on one fixed trained checkpoint."""

    run_directory = Path(str(row["run_directory"]))
    ablation = _object(run_directory / "deployment_ablation.json")
    geometry = _object(run_directory / "policy_geometry.json")
    if geometry.get("training_checkpoint_selection_deployment") != (
        expected_selection_mode
    ):
        raise ValueError(
            "policy-geometry selection mode disagrees with frozen config: "
            f"{run_directory}"
        )
    deployments = ablation.get("deployments")
    if not isinstance(deployments, Mapping):
        raise ValueError(f"deployment ablation lacks deployments: {run_directory}")
    regrets: dict[str, float] = {}
    for mode in ("soft", "hard_recovered"):
        payload = deployments.get(mode)
        if not isinstance(payload, Mapping):
            raise ValueError(f"deployment ablation lacks {mode}: {run_directory}")
        test = payload.get("test")
        if not isinstance(test, Mapping):
            raise ValueError(f"deployment ablation lacks {mode} test: {run_directory}")
        sample_count = test.get("sample_count")
        if sample_count != row["test_sample_count"]:
            raise ValueError(
                f"deployment ablation test size mismatch for {mode}: {run_directory}"
            )
        regret = test.get("normalized_mean_regret")
        if not isinstance(regret, (int, float)) or isinstance(regret, bool):
            raise ValueError(
                f"deployment ablation lacks finite regret for {mode}: {run_directory}"
            )
        if not math.isfinite(float(regret)):
            raise ValueError(
                f"deployment ablation has non-finite regret for {mode}: {run_directory}"
            )
        regrets[mode] = float(regret)
    if not math.isclose(
        regrets[expected_selection_mode],
        float(row["test_normalized_mean_regret"]),
        rel_tol=1e-12,
        abs_tol=1e-12,
    ):
        raise ValueError(
            "configured-deployment regret disagrees with summary: "
            f"{run_directory}"
        )
    return regrets["hard_recovered"] - regrets["soft"]


def _manifest_identity(
    run_roots: Sequence[Path], manifest_path: Path
) -> dict[str, Any]:
    manifest = _object(manifest_path)
    variants = manifest.get("variants")
    if not isinstance(variants, list) or not variants:
        raise ValueError("mechanism manifest has no variants")
    expected: dict[str, dict[str, Any]] = {}
    for raw in variants:
        if not isinstance(raw, dict):
            raise ValueError("mechanism manifest variant is not an object")
        name = raw.get("name")
        if not isinstance(name, str) or name in expected:
            raise ValueError("mechanism manifest has an invalid or duplicate name")
        expected[name] = raw
    observed: Counter[str] = Counter()
    for root in run_roots:
        for directory in sorted(path for path in root.iterdir() if path.is_dir()):
            config_path = directory / "config.json"
            status_path = directory / "status.json"
            if not config_path.is_file() or not status_path.is_file():
                continue
            if _object(status_path).get("status") != "complete":
                continue
            config = _object(config_path)
            name = config.get("name")
            if not isinstance(name, str) or name not in expected:
                raise ValueError(f"run is absent from frozen manifest: {directory}")
            frozen = dict(expected[name])
            if frozen.pop("evaluate_test", None) is not True:
                raise ValueError(f"frozen confirmation did not enable test: {name}")
            if frozen != config:
                raise ValueError(f"run config differs from frozen manifest: {name}")
            observed[name] += 1
    missing = sorted(set(expected) - set(observed))
    duplicates = sorted(name for name, count in observed.items() if count != 1)
    if missing or duplicates:
        raise ValueError(
            f"manifest identity failed: missing={missing}, duplicates={duplicates}"
        )
    digest = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    design = manifest.get("design")
    if not isinstance(design, dict) or design.get("selection_used_test") is not False:
        raise ValueError("mechanism manifest does not certify test-blind selection")
    return {
        "manifest_path": str(manifest_path.resolve()),
        "manifest_sha256": digest,
        "variant_count": len(variants),
        "selection_used_test": False,
        "source_sha256_at_generation": manifest.get("source_sha256_at_generation"),
    }


def _horizon_audit(
    manifest: Mapping[str, Any], *, fixed_maximum_epoch: int
) -> dict[str, Any]:
    design = manifest.get("design")
    if not isinstance(design, dict):
        raise ValueError("mechanism manifest lacks design metadata")
    cell_designs = design.get("cell_designs")
    if not isinstance(cell_designs, dict):
        raise ValueError("mechanism manifest lacks cell designs")
    selected: list[dict[str, Any]] = []
    for cell, raw_design in sorted(cell_designs.items()):
        if not isinstance(raw_design, dict):
            raise ValueError(f"invalid cell design for {cell}")
        candidates = raw_design.get("selected_candidates")
        if not isinstance(candidates, list):
            raise ValueError(f"cell design lacks selected candidates: {cell}")
        for candidate in candidates:
            if not isinstance(candidate, dict):
                raise ValueError("selected candidate must be an object")
            horizon = candidate.get("selected_horizon")
            if not isinstance(horizon, int) or isinstance(horizon, bool):
                raise ValueError("selected candidate lacks an integer horizon")
            selected.append(
                {
                    "cell": cell,
                    "route_id": candidate.get("route_id"),
                    "selected_horizon": horizon,
                    "at_fixed_maximum": horizon == fixed_maximum_epoch,
                }
            )
    boundary = [row for row in selected if row["at_fixed_maximum"]]
    return {
        "fixed_maximum_epoch": fixed_maximum_epoch,
        "selected_cell_count": len(selected),
        "boundary_selected_cell_count": len(boundary),
        "boundary_selected_cells": boundary,
        "all_selected_cells": selected,
        "extension_policy": (
            "The predeclared 2400-epoch ceiling is final. Remaining boundary "
            "selections are disclosed and were not extended after test access."
        ),
    }


def summarize_barrier_mechanism_confirmation(
    run_roots: Iterable[Path],
    *,
    manifest_path: Path,
    required_seed_count: int = 10,
    fixed_maximum_epoch: int = 2400,
) -> dict[str, Any]:
    """Summarize the independently tuned paired 2x2 mechanism confirmation."""

    roots = [Path(root).resolve() for root in run_roots]
    identity = _manifest_identity(roots, manifest_path.resolve())
    rows = completed_confirmation_rows(roots)
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    route_metadata: dict[str, tuple[str, str]] = {}
    for row in rows:
        if row["method"] != "soft_radial_log_barrier":
            raise ValueError("mechanism confirmation contains another method")
        route = row.get("route_id")
        parameters = row.get("method_parameters")
        if not isinstance(route, str) or not isinstance(parameters, Mapping):
            raise ValueError("mechanism row lacks route or method parameters")
        cell = _cell(parameters)
        grouped[(route, cell)].append(row)
        route_metadata[route] = (str(row["benchmark_id"]), str(row["family_id"]))

    route_cell_regrets: dict[
        str, dict[str, dict[tuple[tuple[str, int], ...], float]]
    ] = defaultdict(dict)
    route_same_checkpoint_deployment: dict[
        str, dict[str, dict[tuple[tuple[str, int], ...], float]]
    ] = defaultdict(dict)
    route_results: list[dict[str, Any]] = []
    winner_counts: Counter[str] = Counter()
    runtime_totals: dict[str, dict[str, float]] = defaultdict(
        lambda: {
            "route_count": 0.0,
            "fit_validation_test_wall_seconds": 0.0,
            "training_oracle_calls": 0.0,
            "validation_oracle_calls": 0.0,
            "test_oracle_calls": 0.0,
            "solver_seconds": 0.0,
        }
    )
    for route in sorted(route_metadata):
        cell_results: list[dict[str, Any]] = []
        for cell in CELL_ORDER:
            cell_rows = grouped.get((route, cell), [])
            seeds = [_replication_seed_key(row["seed_key"]) for row in cell_rows]
            if len(cell_rows) != required_seed_count or len(set(seeds)) != len(seeds):
                raise ValueError(
                    f"incomplete mechanism cell {route}/{cell}: expected "
                    f"{required_seed_count} paired seeds"
                )
            ordered = sorted(
                zip(seeds, cell_rows, strict=True), key=lambda item: item[0]
            )
            regrets = {
                seed: float(row["test_normalized_mean_regret"])
                for seed, row in ordered
            }
            route_cell_regrets[route][cell] = regrets
            selection_mode = "hard_recovered" if cell.endswith("hard") else "soft"
            route_same_checkpoint_deployment[route][cell] = {
                seed: _same_checkpoint_deployment_difference(
                    row,
                    expected_selection_mode=selection_mode,
                )
                for seed, row in ordered
            }
            training = _mean_interval(
                [float(row["training_wall_seconds"]) for _, row in ordered]
            )
            train_calls = _mean_interval(
                [float(row["training_oracle_calls"]) for _, row in ordered]
            )
            validation_calls = _mean_interval(
                [float(row["validation_oracle_calls"]) for _, row in ordered]
            )
            test_calls = _mean_interval(
                [float(row["test_oracle_calls"]) for _, row in ordered]
            )
            solver_seconds = _mean_interval(
                [
                    float(row["training_solver_seconds"])
                    + float(row["validation_solver_seconds"])
                    + float(row["test_solver_seconds"])
                    for _, row in ordered
                ]
            )
            cell_results.append(
                {
                    "cell": cell,
                    "test_sample_count_per_seed": int(
                        ordered[0][1]["test_sample_count"]
                    ),
                    "normalized_regret": _mean_interval(list(regrets.values())),
                    "fit_validation_test_wall_seconds": training,
                    "training_oracle_calls": train_calls,
                    "validation_oracle_calls": validation_calls,
                    "test_oracle_calls": test_calls,
                    "solver_seconds": solver_seconds,
                    "run_directories": [row["run_directory"] for _, row in ordered],
                }
            )
            totals = runtime_totals[cell]
            totals["route_count"] += 1
            totals["fit_validation_test_wall_seconds"] += float(training["mean"])
            totals["training_oracle_calls"] += float(train_calls["mean"])
            totals["validation_oracle_calls"] += float(validation_calls["mean"])
            totals["test_oracle_calls"] += float(test_calls["mean"])
            totals["solver_seconds"] += float(solver_seconds["mean"])
        seed_sets = {
            tuple(sorted(route_cell_regrets[route][cell])) for cell in CELL_ORDER
        }
        if len(seed_sets) != 1:
            raise ValueError(f"mechanism cells are not paired on {route}")
        winner = min(
            cell_results, key=lambda record: float(record["normalized_regret"]["mean"])
        )["cell"]
        winner_counts[str(winner)] += 1
        contrasts = [
            _paired_contrast(
                route_cell_regrets[route][left],
                route_cell_regrets[route][right],
                name=name,
                left_cell=left,
                right_cell=right,
                definition=definition,
            )
            for name, left, right, definition in CONTRASTS
        ]
        same_checkpoint_deployment = []
        for cell in CELL_ORDER:
            deployment_differences = route_same_checkpoint_deployment[route][cell]
            values = [
                deployment_differences[seed]
                for seed in sorted(deployment_differences)
            ]
            same_checkpoint_deployment.append(
                {
                    "training_protocol": cell,
                    "difference_definition": (
                        "hard_recovered_minus_soft_on_the_same_trained_checkpoint"
                    ),
                    "difference": _mean_interval(values),
                    "hard_wins": sum(value < -1e-12 for value in values),
                    "ties": sum(abs(value) <= 1e-12 for value in values),
                    "hard_losses": sum(value > 1e-12 for value in values),
                    "pvalue_raw": _exact_sign_flip_pvalue(values),
                    "paired_differences": values,
                }
            )
        route_results.append(
            {
                "route_id": route,
                "benchmark_id": route_metadata[route][0],
                "family_id": route_metadata[route][1],
                "winner_by_mean_normalized_regret": winner,
                "cells": cell_results,
                "independently_tuned_protocol_contrasts": contrasts,
                "same_checkpoint_deployment_contrasts": same_checkpoint_deployment,
            }
        )

    for name, _, _, _ in CONTRASTS:
        records = [
            next(
                contrast
                for contrast in route["independently_tuned_protocol_contrasts"]
                if contrast["contrast"] == name
            )
            for route in route_results
        ]
        _holm_adjust(records, "pvalue_holm_across_routes_for_contrast")

    common_seed_sets = {
        tuple(sorted(route_cell_regrets[route][CELL_ORDER[0]]))
        for route in route_cell_regrets
    }
    if len(common_seed_sets) != 1:
        raise ValueError("mechanism routes do not share paired replication seeds")
    common_seeds = next(iter(common_seed_sets))
    routes_by_family: dict[str, list[str]] = defaultdict(list)
    for route, (_, family) in route_metadata.items():
        routes_by_family[family].append(route)
    aggregate_protocol_contrasts: list[dict[str, Any]] = []
    for name, left, right, definition in CONTRASTS:
        differences = []
        for seed in common_seeds:
            family_differences = [
                fmean(
                    route_cell_regrets[route][left][seed]
                    - route_cell_regrets[route][right][seed]
                    for route in routes_by_family[family]
                )
                for family in sorted(routes_by_family)
            ]
            differences.append(fmean(family_differences))
        aggregate_protocol_contrasts.append(
            {
                "contrast": name,
                "left_cell": left,
                "right_cell": right,
                "difference_definition": (
                    "equal_family_weighted_" + definition.replace(" ", "_")
                ),
                "family_count": len(routes_by_family),
                "route_count": len(route_metadata),
                "paired_seed_count": len(common_seeds),
                "difference": _mean_interval(differences),
                "left_wins": sum(value < -1e-12 for value in differences),
                "ties": sum(abs(value) <= 1e-12 for value in differences),
                "left_losses": sum(value > 1e-12 for value in differences),
                "pvalue_raw": _exact_sign_flip_pvalue(differences),
            }
        )
    _holm_adjust(
        aggregate_protocol_contrasts,
        "pvalue_holm_across_aggregate_contrasts",
    )

    same_checkpoint_deployment_contrasts: list[dict[str, Any]] = []
    for cell in CELL_ORDER:
        differences = []
        for seed in common_seeds:
            family_differences = [
                fmean(
                    route_same_checkpoint_deployment[route][cell][seed]
                    for route in routes_by_family[family]
                )
                for family in sorted(routes_by_family)
            ]
            differences.append(fmean(family_differences))
        same_checkpoint_deployment_contrasts.append(
            {
                "training_protocol": cell,
                "difference_definition": (
                    "equal_family_weighted_hard_recovered_minus_soft_on_the_"
                    "same_trained_checkpoint"
                ),
                "family_count": len(routes_by_family),
                "route_count": len(route_metadata),
                "paired_seed_count": len(common_seeds),
                "difference": _mean_interval(differences),
                "hard_wins": sum(value < -1e-12 for value in differences),
                "ties": sum(abs(value) <= 1e-12 for value in differences),
                "hard_losses": sum(value > 1e-12 for value in differences),
                "pvalue_raw": _exact_sign_flip_pvalue(differences),
            }
        )
    _holm_adjust(
        same_checkpoint_deployment_contrasts,
        "pvalue_holm_across_training_protocols",
    )

    manifest = _object(manifest_path.resolve())
    commits = sorted(
        {
            str(row["git_commit"])
            for row in rows
            if isinstance(row.get("git_commit"), str)
        }
    )
    sources = sorted({str(row["source_sha256"]) for row in rows})
    return {
        "status": "paired_protocol_and_matched_deployment_confirmation",
        "selection_used_test": False,
        "test_evaluated": True,
        "required_seed_count": required_seed_count,
        "completed_run_count": len(rows),
        "route_count": len(route_results),
        "family_count": len(routes_by_family),
        "cells": list(CELL_ORDER),
        "descriptive_cell_win_counts": dict(sorted(winner_counts.items())),
        "route_results": route_results,
        "aggregate_independently_tuned_protocol_contrasts": (
            aggregate_protocol_contrasts
        ),
        "same_checkpoint_deployment_contrasts": (
            same_checkpoint_deployment_contrasts
        ),
        "cell_runtime_accounting": [
            {
                "cell": cell,
                "route_count": int(runtime_totals[cell]["route_count"]),
                **{
                    key: value
                    for key, value in runtime_totals[cell].items()
                    if key != "route_count"
                },
            }
            for cell in CELL_ORDER
        ],
        "horizon_audit": _horizon_audit(
            manifest, fixed_maximum_epoch=fixed_maximum_epoch
        ),
        "manifest_identity": identity,
        "run_roots": [str(root) for root in roots],
        "git_commits": commits,
        "source_sha256_values": sources,
        "evidence_boundary": [
            (
                "Each of the four endpoint protocols was independently selected "
                "by validation regret before test access. Endpoint contrasts "
                "compare tuned protocols and do not isolate the barrier penalty or "
                "deployment choice from nuisance hyperparameters."
            ),
            (
                "Four of 28 independently selected route-cell configurations hit "
                "the fixed 2400-epoch ceiling. They are reported as boundary "
                "selections and were not extended after confirmation."
            ),
            (
                "A negative contrast favors the left-named cell. Exact two-sided "
                "sign-flip tests are Holm-adjusted across the seven routes for "
                "each protocol contrast and across the four aggregate protocol "
                "contrasts."
            ),
            (
                "The same-checkpoint deployment contrasts reevaluate each fixed "
                "trained checkpoint under both soft and hard-recovered deployment. "
                "They isolate deployment conditional on the learned checkpoint and "
                "are Holm-adjusted across the four validation-selected training "
                "protocols."
            ),
            (
                "The centered barrier penalty was not varied while holding every "
                "nuisance setting fixed in the sealed test campaign. Its causal "
                "contribution therefore remains unidentified."
            ),
            (
                "Legacy deployment_ablation.json files mislabel every selection "
                "metric as hard regret. This analysis derives selection mode from "
                "the frozen config and verifies it against policy_geometry.json; "
                "the stored soft/hard regret values themselves are unaffected."
            ),
            (
                "The seven routes are representative family members, not an "
                "exhaustive independent sample from a benchmark population."
            ),
        ],
    }


def render_barrier_mechanism_markdown(summary: Mapping[str, Any]) -> str:
    """Render the tuned-protocol and same-checkpoint deployment receipt."""

    lines = [
        "# Barrier and deployment protocol study",
        "",
        (
            f"{summary['completed_run_count']} clean test runs across "
            f"{summary['route_count']} prespecified family representatives, "
            f"four independently validation-selected cells, and "
            f"{summary['required_seed_count']} paired confirmation seeds."
        ),
        "",
        (
            "The sealed endpoint cells are independently tuned protocols, so their "
            "cross-cell differences are performance comparisons rather than causal "
            "mechanism effects. A separate same-checkpoint analysis below isolates "
            "deployment and shows that hard recovered-cost deployment improves every "
            "validation-selected training protocol on this panel."
        ),
        "",
        (
            "The centered barrier penalty was not varied with all nuisance settings "
            "held fixed, so its causal contribution remains unidentified. The "
            "zero-penalty runs still recover deployment costs from the centered "
            "log-barrier gradient."
        ),
        "",
        "## Route-level test regret",
        "",
        (
            "| Route | No barrier + soft | No barrier + hard | Barrier + soft | "
            "Barrier + hard | Winner |"
        ),
        "|---|---:|---:|---:|---:|---|",
    ]
    for route in summary["route_results"]:
        by_cell = {cell["cell"]: cell for cell in route["cells"]}
        lines.append(
            f"| {route['route_id']} | "
            f"{by_cell['no_barrier_soft']['normalized_regret']['mean']:.6g} | "
            f"{by_cell['no_barrier_hard']['normalized_regret']['mean']:.6g} | "
            f"{by_cell['barrier_soft']['normalized_regret']['mean']:.6g} | "
            f"{by_cell['barrier_hard']['normalized_regret']['mean']:.6g} | "
            f"{route['winner_by_mean_normalized_regret']} |"
        )
    lines.extend(
        [
            "",
            "## Same-checkpoint deployment contrasts",
            "",
            (
                "Each trained checkpoint is evaluated both ways. Differences are "
                "hard recovered minus soft deployment, so negative values favor "
                "hard deployment."
            ),
            "",
            (
                "| Training protocol | Mean difference | 95% CI | Hard W/T/L | "
                "Exact p | Holm p |"
            ),
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for contrast in summary["same_checkpoint_deployment_contrasts"]:
        difference = contrast["difference"]
        lines.append(
            f"| {contrast['training_protocol']} | {difference['mean']:.6g} | "
            f"[{difference['ci95_lower']:.6g}, {difference['ci95_upper']:.6g}] | "
            f"{contrast['hard_wins']}/{contrast['ties']}/"
            f"{contrast['hard_losses']} | {contrast['pvalue_raw']:.6g} | "
            f"{contrast['pvalue_holm_across_training_protocols']:.6g} |"
        )
    lines.extend(
        [
            "",
            "## Independently tuned endpoint-protocol contrasts",
            "",
            (
                "These comparisons retain the original 2x2 endpoint table, but "
                "each protocol selected its own architecture and optimization "
                "settings. They must not be interpreted as isolated barrier or "
                "deployment effects. Differences are left protocol minus right "
                "protocol."
            ),
            "",
            "| Contrast | Mean difference | 95% CI | W/T/L | Exact p | Holm p |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for contrast in summary["aggregate_independently_tuned_protocol_contrasts"]:
        difference = contrast["difference"]
        lines.append(
            f"| {contrast['contrast']} | {difference['mean']:.6g} | "
            f"[{difference['ci95_lower']:.6g}, {difference['ci95_upper']:.6g}] | "
            f"{contrast['left_wins']}/{contrast['ties']}/"
            f"{contrast['left_losses']} | {contrast['pvalue_raw']:.6g} | "
            f"{contrast['pvalue_holm_across_aggregate_contrasts']:.6g} |"
        )
    lines.extend(
        [
            "",
            "## Fit, validation, and test wall-clock accounting",
            "",
            (
                "Each row sums the runner's fit-through-test wall time per route "
                "for one paired replication. It includes validation and final test "
                "evaluation, excludes data/geometry preparation, and excludes "
                "hyperparameter-search compute."
            ),
            "",
            (
                "| Cell | Routes | Fit+val+test s | Train calls | Validation calls | "
                "Test calls | Solver s |"
            ),
            "|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for row in summary["cell_runtime_accounting"]:
        lines.append(
            f"| {row['cell']} | {row['route_count']} | "
            f"{row['fit_validation_test_wall_seconds']:.3f} | "
            f"{row['training_oracle_calls']:.0f} | "
            f"{row['validation_oracle_calls']:.0f} | "
            f"{row['test_oracle_calls']:.0f} | {row['solver_seconds']:.3f} |"
        )
    audit = summary["horizon_audit"]
    lines.extend(
        [
            "",
            "## Horizon audit",
            "",
            (
                f"{audit['boundary_selected_cell_count']} of "
                f"{audit['selected_cell_count']} independently selected cells hit "
                f"the fixed {audit['fixed_maximum_epoch']}-epoch ceiling."
            ),
            "",
        ]
    )
    for row in audit["boundary_selected_cells"]:
        lines.append(f"- {row['cell']}: {row['route_id']}")
    lines.extend(["", "## Evidence boundary", ""])
    lines.extend(f"- {note}" for note in summary["evidence_boundary"])
    lines.append("")
    return "\n".join(lines)
