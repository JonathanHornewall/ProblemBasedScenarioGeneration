"""Decision-level evaluation independent of training loss."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
import torch
from torch import nn

from .models import module_dtype
from .objectives import LearningObjective, PreparedSplit
from .oracles import OracleStats


@dataclass(frozen=True)
class EvaluationMetrics:
    sample_count: int
    mean_regret: float
    standard_error_regret: float
    median_regret: float
    maximum_regret: float
    positive_regret_rate: float
    normalized_mean_regret: float | None
    mean_realized_cost: float
    oracle_stats: OracleStats

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["oracle_stats"] = asdict(self.oracle_stats)
        return result


def predict_in_batches(
    model: nn.Module,
    contexts: np.ndarray,
    *,
    batch_size: int,
) -> np.ndarray:
    model.eval()
    pieces: list[np.ndarray] = []
    first_parameter = next(model.parameters(), None)
    first_buffer = next(model.buffers(), None)
    reference = first_parameter if first_parameter is not None else first_buffer
    device = torch.device("cpu") if reference is None else reference.device
    dtype = module_dtype(model)
    with torch.no_grad():
        for start in range(0, len(contexts), batch_size):
            tensor = torch.as_tensor(
                contexts[start : start + batch_size],
                dtype=dtype,
                device=device,
            )
            pieces.append(model(tensor).cpu().numpy())
    return np.concatenate(pieces, axis=0)


def evaluate_outputs(
    objective: LearningObjective,
    outputs: np.ndarray,
    split: PreparedSplit,
    *,
    batch_size: int,
    capture: dict[str, Any] | None = None,
) -> EvaluationMetrics:
    regrets: list[np.ndarray] = []
    realized_costs: list[np.ndarray] = []
    total = OracleStats()
    all_decisions = []
    for start in range(0, len(outputs), batch_size):
        stop = start + batch_size
        keyed_deploy = getattr(objective, "deploy_with_sample_keys", None)
        if keyed_deploy is None:
            deployed = objective.deploy(outputs[start:stop])
        else:
            deployed = keyed_deploy(outputs[start:stop], split.sample_keys[start:stop])
        mean_cost = split.conditional_mean_costs[start:stop]
        decisions = deployed.decisions
        if capture is not None:
            all_decisions.append(decisions.copy())
        regrets.append(
            np.sum(mean_cost * decisions, axis=1)
            - split.conditional_target_values[start:stop]
        )
        realized_costs.append(
            np.sum(split.physical_costs[start:stop] * decisions, axis=1)
        )
        total += deployed.stats
    regret = np.concatenate(regrets)
    realized = np.concatenate(realized_costs)
    # Numerical solvers can produce tiny negative gaps; material negatives are
    # an error because the conditional reference was solved independently.
    numerical_tolerance = 5e-7 * (
        1.0
        + np.abs(split.conditional_target_values)
        + np.sum(np.abs(split.conditional_mean_costs), axis=1)
    )
    if np.any(regret < -numerical_tolerance):
        raise RuntimeError(f"materially negative evaluated regret: {regret.min():.3e}")
    regret = np.maximum(regret, 0.0)
    denominator = float(np.mean(np.abs(split.conditional_target_values)))
    normalized = None if denominator < 1e-8 else float(np.mean(regret) / denominator)
    standard_error = (
        float(np.std(regret, ddof=1) / np.sqrt(len(regret))) if len(regret) > 1 else 0.0
    )
    if capture is not None:
        capture.update(network_outputs=outputs, decisions=np.concatenate(all_decisions),
            contexts=split.contexts, regrets=regret, realized_costs=realized,
            reference_objectives=split.conditional_target_values,
            conditional_mean_costs=split.conditional_mean_costs,
            physical_costs=split.physical_costs)
    return EvaluationMetrics(
        sample_count=len(regret),
        mean_regret=float(np.mean(regret)),
        standard_error_regret=standard_error,
        median_regret=float(np.median(regret)),
        maximum_regret=float(np.max(regret)),
        positive_regret_rate=float(np.mean(regret > 1e-8)),
        normalized_mean_regret=normalized,
        mean_realized_cost=float(np.mean(realized)),
        oracle_stats=total,
    )


def evaluate_model(
    model: nn.Module,
    objective: LearningObjective,
    split: PreparedSplit,
    *,
    batch_size: int,
) -> EvaluationMetrics:
    outputs = predict_in_batches(model, split.contexts, batch_size=batch_size)
    return evaluate_outputs(objective, outputs, split, batch_size=batch_size)
