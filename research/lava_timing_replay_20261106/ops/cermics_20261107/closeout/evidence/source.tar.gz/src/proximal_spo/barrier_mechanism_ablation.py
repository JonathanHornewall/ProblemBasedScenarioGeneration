"""Matched barrier-training by deployment-mechanism ablation.

The publication campaign's strongest continuous method combines two choices:

* a centered log-barrier term during Soft-Radial policy training; and
* hard deployment through the cost recovered from the barrier gradient.

This module compares four validation-selected endpoint protocols. Every cell
uses the same implementation and benchmark protocol, but each cell tunes its
nuisance hyperparameters independently. Cross-cell endpoint differences are
therefore protocol comparisons, not isolated mechanism effects. The generated
runs also evaluate both deployments on every fixed checkpoint, enabling a
genuinely matched deployment analysis.
"""

from __future__ import annotations

import copy
import json
import math
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from typing import Any

from .config import RunSpec
from .publication_selection import (
    build_confirmation_campaign,
    build_refinement_campaign,
    candidate_fingerprint,
)

REPRESENTATIVE_BENCHMARKS: tuple[str, ...] = (
    "cave_sp5_degree_4",
    "directional_planted_path_additive_gaussian",
    "directional_random_cost_grid_multiplicative_uniform",
    "dys_shortest_path_5x5",
    "lava_random_lp_100x50_released_code",
    "lava_shortest_path_5x5_released_code",
    "wise_shortest_path_5x5_degree_4",
)

CELL_IDS: tuple[str, ...] = (
    "no_barrier_soft",
    "no_barrier_hard",
    "barrier_soft",
    "barrier_hard",
)

SCREEN_SEEDS: dict[str, int] = {
    "data": 251_001,
    "initialization": 261_001,
    "shuffle": 271_001,
    "perturbation": 281_001,
}

REFINEMENT_SEED_BUNDLES: tuple[dict[str, int], ...] = tuple(
    {
        "data": 251_101 + 2 * index,
        "initialization": 261_101 + 2 * index,
        "shuffle": 271_101 + 2 * index,
        "perturbation": 281_101 + 2 * index,
    }
    for index in range(3)
)

CONFIRMATION_SEED_BUNDLES: tuple[dict[str, int], ...] = tuple(
    {
        "data": 351_101 + 2 * index,
        "initialization": 361_101 + 2 * index,
        "shuffle": 371_101 + 2 * index,
        "perturbation": 381_101 + 2 * index,
    }
    for index in range(10)
)


def _slug(value: object) -> str:
    return str(value).replace(".", "p").replace("-", "_")


def _cell_parts(cell_id: str) -> tuple[bool, str]:
    if cell_id not in CELL_IDS:
        raise ValueError(f"unknown mechanism-ablation cell: {cell_id}")
    barrier = not cell_id.startswith("no_barrier")
    deployment = "hard_recovered" if cell_id.endswith("hard") else "soft"
    return barrier, deployment


def mechanism_cell(config: Mapping[str, Any]) -> str:
    """Return the declared 2x2 cell for one barrier-objective config."""

    if config.get("method") != "soft_radial_log_barrier":
        raise ValueError("mechanism ablation requires soft_radial_log_barrier")
    parameters = config.get("method_parameters")
    if not isinstance(parameters, Mapping):
        raise ValueError("mechanism-ablation config lacks method parameters")
    alpha_start = float(parameters.get("alpha_start", 0.0))
    alpha_end = float(parameters.get("alpha_end", alpha_start))
    if alpha_start < 0.0 or alpha_end < 0.0:
        raise ValueError("barrier parameters must be nonnegative")
    has_barrier = alpha_start > 0.0 or alpha_end > 0.0
    deployment = str(parameters.get("deployment_mode", "soft"))
    if deployment not in {"soft", "hard_recovered"}:
        raise ValueError(f"invalid deployment mode: {deployment}")
    return (
        ("barrier" if has_barrier else "no_barrier")
        + ("_hard" if deployment == "hard_recovered" else "_soft")
    )


def _deduplicate(configs: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for config in configs:
        fingerprint = candidate_fingerprint(config)
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        RunSpec.from_dict(config)
        result.append(config)
    return result


def _validate_seeded_variants(
    configs: Iterable[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Validate emitted runs without collapsing deliberately paired seeds."""

    result = list(configs)
    names: set[str] = set()
    canonical_configs: set[str] = set()
    for config in result:
        spec = RunSpec.from_dict(config)
        if spec.name in names:
            raise ValueError(f"duplicate seeded variant name: {spec.name}")
        names.add(spec.name)
        canonical = json.dumps(config, sort_keys=True, separators=(",", ":"))
        if canonical in canonical_configs:
            raise ValueError(f"duplicate seeded variant config: {spec.name}")
        canonical_configs.add(canonical)
    return result


def _confirmation_anchors(
    confirmation: Mapping[str, Any],
) -> dict[tuple[str, str], dict[str, Any]]:
    variants = confirmation.get("variants")
    if not isinstance(variants, list):
        raise ValueError("continuous confirmation manifest lacks variants")
    result: dict[tuple[str, str], dict[str, Any]] = {}
    for raw in variants:
        if not isinstance(raw, dict):
            raise ValueError("continuous confirmation variant is not an object")
        benchmark = raw.get("benchmark_id")
        method = raw.get("method")
        name = raw.get("name")
        if benchmark not in REPRESENTATIVE_BENCHMARKS or method not in {
            "soft_radial_log_barrier",
            "soft_radial_policy",
        }:
            continue
        if not isinstance(name, str) or not name.endswith("_seed1"):
            continue
        key = (str(benchmark), str(method))
        if key in result:
            raise ValueError(f"duplicate confirmation anchor: {key}")
        result[key] = copy.deepcopy(raw)
    for benchmark in REPRESENTATIVE_BENCHMARKS:
        if (benchmark, "soft_radial_log_barrier") not in result:
            raise ValueError(f"missing target confirmation anchor: {benchmark}")
    return result


def _screen_training(config: dict[str, Any]) -> None:
    training = config["training"]
    horizon = max(
        300,
        int(training.get("schedule_reference_epochs", training["epochs"])),
    )
    training.update(
        {
            "epochs": horizon,
            "patience": horizon + 1,
            "selection_mode": "validation_regret",
            "validation_interval": horizon,
            "validation_epochs": [
                epoch
                for epoch in (20, 40, 80, 120, 180, 240, 300)
                if epoch <= horizon
            ],
            "schedule_reference_epochs": horizon,
            "gradient_diagnostic_interval": 8,
            "torch_threads": 1,
        }
    )


def _as_barrier_objective(
    source: Mapping[str, Any], *, cell_id: str, alpha: float
) -> dict[str, Any]:
    _, deployment = _cell_parts(cell_id)
    config = copy.deepcopy(dict(source))
    config["method"] = "soft_radial_log_barrier"
    config["evaluate_test"] = False
    config["workers"] = min(4, int(config.get("workers", 1)))
    config["seeds"] = {
        **dict(config["seeds"]),
        **SCREEN_SEEDS,
    }
    source_parameters = dict(config.get("method_parameters", {}))
    config["method_parameters"] = {
        "contraction": str(source_parameters.get("contraction", "rational")),
        "contraction_scale": float(
            source_parameters.get("contraction_scale", 1.0)
        ),
        "minimum_scale": float(source_parameters.get("minimum_scale", 0.01)),
        "alpha_start": alpha,
        "alpha_end": alpha,
        "schedule": "fixed",
        "deployment_mode": deployment,
        "kernel_backend": "torch",
        "torch_device": "cpu",
    }
    _screen_training(config)
    return config


def _bounded_factor(value: float, factor: float, *, low: float, high: float) -> float:
    return min(high, max(low, value * factor))


def _neighbor_variants(
    base: dict[str, Any],
    *,
    cell_id: str,
    anchor_tag: str,
) -> list[dict[str, Any]]:
    benchmark = str(base["benchmark_id"])
    barrier, _ = _cell_parts(cell_id)
    parameters = dict(base["method_parameters"])
    alpha = float(parameters["alpha_start"])
    learning_rate = float(base["training"]["learning_rate"])
    contraction_scale = float(parameters["contraction_scale"])
    minimum_scale = float(parameters["minimum_scale"])
    variants: list[dict[str, Any]] = []

    def add(tag: str, update: Mapping[str, Any]) -> None:
        config = copy.deepcopy(base)
        config["name"] = (
            f"mechanism_screen_{cell_id}_{_slug(benchmark)}_"
            f"{anchor_tag}_{tag}"
        )
        for key, value in update.items():
            if key == "learning_rate":
                config["training"][key] = value
            elif key in {"depth", "width"}:
                config["model"][key] = value
            elif key == "batch_size":
                config["training"][key] = value
            else:
                config["method_parameters"][key] = value
        variants.append(config)

    add("anchor", {})
    for factor in (1.0 / 3.0, 3.0):
        add(f"lr_x{_slug(factor)}", {"learning_rate": learning_rate * factor})
        add(
            f"radius_x{_slug(factor)}",
            {
                "contraction_scale": _bounded_factor(
                    contraction_scale, factor, low=0.003, high=10.0
                )
            },
        )
        add(
            f"minimum_x{_slug(factor)}",
            {
                "minimum_scale": _bounded_factor(
                    minimum_scale, factor, low=0.001, high=0.05
                )
            },
        )
        if barrier:
            candidate_alpha = _bounded_factor(alpha, factor, low=0.003, high=30.0)
            add(
                f"alpha_x{_slug(factor)}",
                {"alpha_start": candidate_alpha, "alpha_end": candidate_alpha},
            )
    for contraction in ("rational", "exponential", "hyperbolic"):
        add(f"chart_{contraction}", {"contraction": contraction})
    train_size = int(base["sizes"]["train"])
    for batch_size in sorted({min(128, train_size), min(512, train_size), train_size}):
        add(f"batch_{batch_size}", {"batch_size": batch_size})
    return _deduplicate(variants)


def build_screen_campaign(
    confirmation: Mapping[str, Any], *, run_root: str
) -> dict[str, Any]:
    """Build the validation-only one-seed 2x2 mechanism screen."""

    anchors = _confirmation_anchors(confirmation)
    variants: list[dict[str, Any]] = []
    anchor_receipts: list[dict[str, Any]] = []
    for benchmark in REPRESENTATIVE_BENCHMARKS:
        target = anchors[(benchmark, "soft_radial_log_barrier")]
        positive_alpha = float(target["method_parameters"]["alpha_start"])
        source_anchors = [("target", target)]
        plain = anchors.get((benchmark, "soft_radial_policy"))
        if plain is not None:
            source_anchors.append(("plain_soft_radial", plain))
        for cell_id in CELL_IDS:
            barrier, _ = _cell_parts(cell_id)
            alpha = positive_alpha if barrier else 0.0
            for anchor_tag, source in source_anchors:
                base = _as_barrier_objective(source, cell_id=cell_id, alpha=alpha)
                variants.extend(
                    _neighbor_variants(
                        base, cell_id=cell_id, anchor_tag=anchor_tag
                    )
                )
                anchor_receipts.append(
                    {
                        "benchmark_id": benchmark,
                        "cell_id": cell_id,
                        "anchor_source_method": source["method"],
                        "anchor_source_name": source["name"],
                        "positive_alpha": positive_alpha,
                    }
                )
    variants = _deduplicate(variants)
    observed_cells = {mechanism_cell(config) for config in variants}
    if observed_cells != set(CELL_IDS):
        raise AssertionError("mechanism screen does not cover all four cells")
    return {
        "name": "publication_barrier_mechanism_screen",
        "run_root": run_root,
        "design": {
            "stage": "one_seed_validation_screen",
            "test_blind": True,
            "mechanism": "training barrier absent/present by soft/hard deployment",
            "representative_selection": (
                "one prespecified standard-scale route from each of the seven "
                "continuous confirmation families"
            ),
            "representative_benchmarks": list(REPRESENTATIVE_BENCHMARKS),
            "cells": list(CELL_IDS),
            "selection_metric": "validation_normalized_mean_regret",
            "fixed_maximum_horizon": 300,
            "shared_checkpoint_grid": [20, 40, 80, 120, 180, 240, 300],
            "tuned_factors": [
                "learning_rate",
                "batch_size",
                "network_anchor",
                "chart_family",
                "chart_radius",
                "minimum_contraction",
                "positive_barrier_strength",
            ],
            "anchor_receipts": anchor_receipts,
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def _rows_by_cell(
    rows: Iterable[dict[str, Any]],
) -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = {
        cell_id: [] for cell_id in CELL_IDS
    }
    for row in rows:
        config = row.get("config")
        if not isinstance(config, Mapping):
            raise ValueError("mechanism-ablation row lacks config")
        cell_id = mechanism_cell(config)
        grouped[cell_id].append(row)
    missing = [cell_id for cell_id, values in grouped.items() if not values]
    if missing:
        raise ValueError(f"mechanism-ablation cells have no rows: {missing}")
    return grouped


def build_paired_refinement_campaign(
    rows: Iterable[dict[str, Any]], *, run_root: str, top_k: int = 3
) -> dict[str, Any]:
    """Promote the top candidates independently inside each 2x2 cell."""

    variants: list[dict[str, Any]] = []
    cell_designs: dict[str, Any] = {}
    for cell_id, cell_rows in _rows_by_cell(rows).items():
        campaign = build_refinement_campaign(
            cell_rows,
            run_root=run_root,
            top_k=top_k,
            seed_bundles=REFINEMENT_SEED_BUNDLES,
        )
        variants.extend(campaign["variants"])
        cell_designs[cell_id] = campaign["design"]
    variants = _validate_seeded_variants(variants)
    return {
        "name": "publication_barrier_mechanism_refinement",
        "run_root": run_root,
        "design": {
            "stage": "paired_validation_refinement",
            "test_blind": True,
            "cells_selected_independently": True,
            "top_k_per_benchmark_cell": top_k,
            "paired_seed_count": len(REFINEMENT_SEED_BUNDLES),
            "cell_designs": cell_designs,
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def build_paired_confirmation_campaign(
    rows: Iterable[dict[str, Any]], *, run_root: str
) -> dict[str, Any]:
    """Freeze each cell on validation and emit new ten-seed test runs."""

    variants: list[dict[str, Any]] = []
    cell_designs: dict[str, Any] = {}
    for cell_id, cell_rows in _rows_by_cell(rows).items():
        campaign = build_confirmation_campaign(
            cell_rows,
            run_root=run_root,
            required_refinement_seeds=len(REFINEMENT_SEED_BUNDLES),
            seed_bundles=CONFIRMATION_SEED_BUNDLES,
            minimum_test_size=1_000,
        )
        variants.extend(campaign["variants"])
        cell_designs[cell_id] = campaign["design"]
    variants = _validate_seeded_variants(variants)
    expected = (
        len(REPRESENTATIVE_BENCHMARKS)
        * len(CELL_IDS)
        * len(CONFIRMATION_SEED_BUNDLES)
    )
    if len(variants) != expected:
        raise AssertionError(
            f"expected {expected} mechanism confirmations, found {len(variants)}"
        )
    return {
        "name": "publication_barrier_mechanism_confirmation",
        "run_root": run_root,
        "design": {
            "stage": "paired_test_confirmation",
            "selection_used_test": False,
            "test_evaluation": True,
            "cells_selected_independently": True,
            "paired_confirmation_seed_count": len(CONFIRMATION_SEED_BUNDLES),
            "cell_designs": cell_designs,
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def build_horizon_extension_campaign(
    selected_confirmation: Mapping[str, Any],
    *,
    run_root: str,
    boundary_horizon: int = 300,
    extended_horizon: int = 600,
) -> dict[str, Any]:
    """Extend only validation-selected cells that hit the horizon boundary."""

    if boundary_horizon <= 0 or extended_horizon <= boundary_horizon:
        raise ValueError("require extended_horizon > boundary_horizon > 0")
    raw_variants = selected_confirmation.get("variants")
    if not isinstance(raw_variants, list):
        raise ValueError("selected confirmation manifest lacks variants")
    anchors: dict[tuple[str, str], dict[str, Any]] = {}
    for raw in raw_variants:
        if not isinstance(raw, dict):
            raise ValueError("selected confirmation variant is not an object")
        if int(raw["training"]["epochs"]) != boundary_horizon:
            continue
        key = (str(raw["benchmark_id"]), mechanism_cell(raw))
        incumbent = anchors.get(key)
        if incumbent is None or str(raw["name"]) < str(incumbent["name"]):
            anchors[key] = raw
    if not anchors:
        raise ValueError("no selected cell hit the training-horizon boundary")

    variants: list[dict[str, Any]] = []
    for (benchmark, cell_id), anchor in sorted(anchors.items()):
        structural_seed = int(anchor["seeds"]["structural"])
        for seed_index, bundle in enumerate(REFINEMENT_SEED_BUNDLES, start=1):
            config = copy.deepcopy(anchor)
            config["name"] = (
                f"mechanism_horizon_{cell_id}_{_slug(benchmark)}_"
                f"to{extended_horizon}_seed{seed_index}"
            )
            config["evaluate_test"] = False
            config["seeds"] = {
                **bundle,
                "structural": structural_seed,
            }
            config["training"].update(
                {
                    "epochs": extended_horizon,
                    "schedule_reference_epochs": extended_horizon,
                    "selection_mode": "validation_regret",
                    "validation_interval": extended_horizon,
                    "validation_epochs": [
                        boundary_horizon,
                        (boundary_horizon + extended_horizon) // 2,
                        extended_horizon,
                    ],
                    "patience": extended_horizon + 1,
                }
            )
            variants.append(config)
    variants = _validate_seeded_variants(variants)
    return {
        "name": "publication_barrier_mechanism_horizon_extension",
        "run_root": run_root,
        "design": {
            "stage": "paired_validation_horizon_extension",
            "test_blind": True,
            "boundary_horizon": boundary_horizon,
            "extended_horizon": extended_horizon,
            "extended_cell_count": len(anchors),
            "extended_cells": [
                {"benchmark_id": benchmark, "cell_id": cell_id}
                for benchmark, cell_id in sorted(anchors)
            ],
            "paired_seed_count": len(REFINEMENT_SEED_BUNDLES),
            "selection_metric": "mean_validation_normalized_mean_regret",
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def load_json_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object at {path}")
    return payload


def validate_campaign(payload: Mapping[str, Any]) -> None:
    variants = payload.get("variants")
    if not isinstance(variants, Sequence) or isinstance(variants, (str, bytes)):
        raise ValueError("campaign lacks variants")
    names: set[str] = set()
    for raw in variants:
        if not isinstance(raw, dict):
            raise ValueError("campaign variant is not an object")
        spec = RunSpec.from_dict(raw)
        if spec.name in names:
            raise ValueError(f"duplicate campaign name: {spec.name}")
        names.add(spec.name)
        if mechanism_cell(raw) not in CELL_IDS:
            raise AssertionError("unreachable mechanism cell")
        if not math.isfinite(float(raw["training"]["learning_rate"])):
            raise ValueError("non-finite learning rate")
