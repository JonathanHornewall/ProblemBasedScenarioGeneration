"""HiGHS adapters for the pinned PyEPO and Solver-Free-DFL losses.

Only optimization and extraction of geometry are adapted. The public loss
functions and adjacent-vertex enumeration functions are executed unchanged.
"""

from __future__ import annotations

import ast
import hashlib
from functools import lru_cache
from pathlib import Path
from types import SimpleNamespace

import highspy
import numpy as np
import scipy
import scipy.linalg
import torch
from pyepo.data.dataset import optDataset
from pyepo.model.opt import optModel
from scipy import sparse
from torch.nn.utils.rnn import pad_sequence

from proximal_spo.oracles import _highs_lp
from proximal_spo.problem import LinearProblem


def dispose_highs_model(model):
    """Release native storage and highspy 1.12's Python callback cycles."""
    if model is None:
        return
    try:
        model.disableCallbacks()
        model.clearCallbacks()
    finally:
        try:
            model.callbacks.clear()
        finally:
            model.clear()


class HighsOptModel(optModel):
    """PyEPO's solver interface backed by an independent, single-thread HiGHS LP."""

    def __init__(self, source: LinearProblem, *, presolve: bool = True):
        self.source = source
        self.presolve = presolve
        self.is_ILP = not source.is_continuous
        self._cost = np.zeros(source.variable_count)
        self.solve_count = 0
        super().__init__()

    def _getModel(self):
        model = highspy.Highs()
        options = {
            "output_flag": False,
            "threads": 1,
            "random_seed": 0,
            "primal_feasibility_tolerance": 1e-8,
            "dual_feasibility_tolerance": 1e-8,
            "mip_feasibility_tolerance": 1e-8,
            "mip_rel_gap": 0.0,
            "mip_abs_gap": 0.0,
            "presolve": "on" if self.presolve else "off",
        }
        if self.source.is_continuous:
            options["solver"] = "simplex"
        try:
            for key, value in options.items():
                if model.setOptionValue(key, value) != highspy.HighsStatus.kOk:
                    raise RuntimeError(f"HiGHS rejected option {key}")
            if model.passModel(_highs_lp(self.source)) != highspy.HighsStatus.kOk:
                raise RuntimeError("HiGHS rejected the public benchmark model")
        except BaseException:
            dispose_highs_model(model)
            raise
        return model, np.arange(self.source.variable_count, dtype=np.int32)

    def setObj(self, c):
        c = np.asarray(c, dtype=np.float64)
        if c.shape != (self.num_cost,) or not np.isfinite(c).all():
            raise ValueError("Cost vector has invalid shape or nonfinite entries")
        self._cost = c.copy()
        status = self._model.changeColsCost(self.num_cost, self.x, self._cost)
        if status != highspy.HighsStatus.kOk:
            raise RuntimeError("HiGHS rejected an objective update")

    def solve(self):
        if self.is_ILP:
            self._model.clearSolver()
        status = self._model.run()
        self.solve_count += 1
        if self._model.getModelStatus() == highspy.HighsModelStatus.kUnknown:
            self._model.clearSolver()
            status = self._model.run()
        if (
            status == highspy.HighsStatus.kError
            or self._model.getModelStatus() != highspy.HighsModelStatus.kOptimal
        ):
            raise RuntimeError(
                "HiGHS failed: "
                + self._model.modelStatusToString(self._model.getModelStatus())
            )
        solution = np.asarray(self._model.getSolution().col_value, dtype=np.float64)
        # Match the public Gurobi dictionary model's Python-list return type.
        # PyEPO 1.0.2 infers tensor dtype here; returning a float64 ndarray would
        # promote NCE's float32 solution pool and break its next einsum.
        return solution.tolist(), float(self._cost @ solution)

    def copy(self):
        copied = type(self)(self.source, presolve=self.presolve)
        copied.setObj(self._cost)
        return copied

    def relax(self):
        relaxed = type(self)(
            self.source.continuous_relaxation(), presolve=self.presolve
        )
        relaxed.setObj(self._cost)
        return relaxed


def canonical_rows(problem: LinearProblem):
    """Use exactly the row order and senses of the previous Gurobi adapter."""
    matrix = problem.matrix.tocsr()
    rows, rhs, senses = [], [], []
    for i, (lower, upper) in enumerate(
        zip(problem.row_lower, problem.row_upper, strict=True)
    ):
        row = matrix[[i], :]
        if np.isfinite(lower) and np.isfinite(upper) and abs(lower - upper) <= 1e-10:
            rows.append(row)
            rhs.append(lower)
            senses.append("=")
        else:
            if np.isfinite(lower):
                rows.append(row)
                rhs.append(lower)
                senses.append(">")
            if np.isfinite(upper):
                rows.append(row)
                rhs.append(upper)
                senses.append("<")
    a = (
        sparse.vstack(rows, format="csr")
        if rows
        else sparse.csr_matrix((0, problem.variable_count))
    )
    return a, np.asarray(rhs), np.asarray(senses)


def slack_form(problem: LinearProblem) -> LinearProblem:
    """Public LAVA's explicit nonnegative slack formulation, without Gurobi.

    Its enumeration assumes nonnegative variables with zero lower bounds.
    All fourteen Atlanta configurations meet this contract. Refuse unsupported
    lower bounds rather than silently applying an invalid enumeration.
    """
    if np.any(problem.variable_lower != 0):
        raise ValueError("Public LAVA enumeration requires zero variable lower bounds")
    a, rhs, senses = canonical_rows(problem)
    sign = np.where(senses == ">", -1.0, 1.0)
    a = sparse.diags(sign) @ a
    rhs = sign * rhs
    inequalities = np.flatnonzero(senses != "=")
    upper_indices = np.flatnonzero(np.isfinite(problem.variable_upper))
    m, n = a.shape
    q, u = len(inequalities), len(upper_indices)
    row_slacks = sparse.coo_matrix(
        (np.ones(q), (inequalities, np.arange(q))), shape=(m, q)
    )
    top = sparse.hstack([a, row_slacks, sparse.csr_matrix((m, u))])
    bounds = sparse.hstack(
        [
            sparse.eye(n, format="csr")[upper_indices],
            sparse.csr_matrix((u, q)),
            sparse.eye(u),
        ]
    )
    matrix = sparse.vstack([top, bounds], format="csc")
    b = np.concatenate([rhs, problem.variable_upper[upper_indices]])
    return LinearProblem(
        matrix,
        b,
        b,
        np.zeros(n + q + u),
        np.full(n + q + u, np.inf),
        name=problem.name + ".public_slack",
        metadata={"original_variable_count": n},
    )


def binding_normals(problem: LinearProblem, solution: np.ndarray) -> np.ndarray:
    a, rhs, senses = canonical_rows(problem)
    activity = np.asarray(a @ solution).ravel()
    normals = []
    for i in np.flatnonzero(np.abs(activity - rhs) < 1e-5):
        row = a[[i], :].toarray()[0]
        if senses[i] == "=":
            normals.extend([row, -row])
        else:
            normals.append(-row if senses[i] == ">" else row)
    for i, value in enumerate(solution):
        row = np.zeros(problem.variable_count)
        if value <= problem.variable_lower[i] + 1e-5:
            row[i] = -1
            normals.append(row)
        elif (
            np.isfinite(problem.variable_upper[i])
            and value >= problem.variable_upper[i] - 1e-5
        ):
            row[i] = 1
            normals.append(row)
    return np.asarray(normals, dtype=np.float64).reshape(-1, problem.variable_count)


def coalesce_vertices(vertices: np.ndarray, anchor: np.ndarray, tolerance: float):
    """Numerical duplicate removal, explicitly separate from public behavior.

    Group coordinates on a documented absolute grid, retaining an original
    feasible representative rather than a rounded or averaged point. This
    repairs repeated numerical representations of a vertex, not incomplete
    enumeration. The caller must explicitly select a positive tolerance.
    """
    if not np.isfinite(tolerance) or tolerance <= 0:
        raise ValueError("Vertex coalescing requires a positive finite tolerance")
    scaled = np.rint(np.asarray(vertices, dtype=np.float64) / tolerance)
    if not np.isfinite(scaled).all() or np.max(np.abs(scaled), initial=0) >= 2**63:
        raise ValueError("Vertex coordinates exceed the coalescing grid's range")
    _, indices = np.unique(scaled.astype(np.int64), axis=0, return_index=True)
    unique = np.asarray(vertices)[np.sort(indices)]
    if len(unique) > 1:
        unique = unique[np.max(np.abs(unique - anchor), axis=1) > tolerance]
    return unique


@lru_cache(maxsize=4)
def public_geometry(public_repo: str):
    """Load the unchanged public numerical functions, excluding solver imports.

    The source module also defines Gurobi datasets and imports Gurobi-specific
    TSP models. Selecting its top-level numerical functions lets a HiGHS-only
    environment reuse their exact bodies without that incidental dependency.
    """
    from utils.misc import (
        find_partial_lexipos,
        is_lexicofeasible,
        search_for_transition_column,
    )

    path = Path(public_repo) / "data/dataset_augmented.py"
    source = path.read_bytes()
    wanted = {
        "collate_fn_2",
        "get_adjacent_vertices_non_degenerate_case",
        "get_adjacent_vertices_degenerate_case",
        "get_adjacent_vertices_degenerate_case_helper",
    }
    nodes = [
        node
        for node in ast.parse(source, filename=str(path)).body
        if isinstance(node, ast.FunctionDef) and node.name in wanted
    ]
    if {node.name for node in nodes} != wanted:
        raise RuntimeError("Pinned public geometry functions are missing")
    namespace = {
        "np": np,
        "scipy": scipy,
        "torch": torch,
        "pad_sequence": pad_sequence,
        "find_partial_lexipos": find_partial_lexipos,
        "search_for_transition_column": search_for_transition_column,
        "is_lexicofeasible": is_lexicofeasible,
    }
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), "exec"), namespace)
    return SimpleNamespace(
        **{name: namespace[name] for name in wanted},
        source_sha256=hashlib.sha256(source).hexdigest(),
    )


class HighsBindingDataset(optDataset):
    """The public CaVE dataset fields with binding normals extracted via HiGHS."""

    def __init__(self, model, feats, costs):
        self.model, self.feats, self.costs = model, np.asarray(feats), np.asarray(costs)
        work = model.copy()
        sols, objs, ctrs = [], [], []
        for c in self.costs:
            work.setObj(c)
            sol, obj = work.solve()
            sols.append(sol)
            objs.append([obj])
            ctrs.append(binding_normals(model.source, sol))
        self.sols, self.objs = np.asarray(sols), np.asarray(objs)
        self.relaxed_sols, self.relaxed_objs = self.sols, self.objs
        self.ctrs = ctrs
        self.adjacent_verts = [np.zeros((1, model.num_cost)) for _ in sols]
        self.geometry_row_reduction = False
        self.adjacency_tnp_retry_count = 0

    def __getitem__(self, index):
        return tuple(
            torch.as_tensor(values[index], dtype=torch.float32)
            for values in (
                self.feats,
                self.costs,
                self.sols,
                self.objs,
                self.relaxed_sols,
                self.relaxed_objs,
                self.ctrs,
                self.adjacent_verts,
            )
        )


class HighsLAVADataset(HighsBindingDataset):
    """Supply HiGHS simplex bases to the released LAVA enumeration routines."""

    def __init__(
        self,
        model,
        feats,
        costs,
        *,
        public_repo=None,
        progress=None,
        vertex_tolerance: float = 0.0,
    ):
        import os

        self.model, self.feats, self.costs = model, np.asarray(feats), np.asarray(costs)
        self.public = public_geometry(
            str(public_repo or os.environ["SOLVER_FREE_DFL_REPO"])
        )
        self.slack_problem = slack_form(model.source)
        self.slack_model = HighsOptModel(self.slack_problem, presolve=False)
        self.slack_model_A = self.slack_problem.matrix.toarray()
        self._reduced_rows = None
        self.geometry_row_reduction = False
        self.basis_completion_count = 0
        self.adjacency_tnp_retry_count = 0
        self.anchor_reselection_count = 0
        if not np.isfinite(vertex_tolerance) or vertex_tolerance < 0:
            raise ValueError("Vertex tolerance must be finite and nonnegative")
        self.vertex_tolerance = float(vertex_tolerance)
        self.exact_vertex_counts = []
        exact_counts = {}
        self.adjacent_vertices_cache = {}
        sols, objs, ctrs, neighbours = [], [], [], []
        work = model.copy()
        for i, c in enumerate(self.costs):
            work.setObj(c)
            original_sol, original_obj = work.solve()
            self.slack_model.setObj(
                np.pad(c, (0, self.slack_problem.variable_count - len(c)))
            )
            slack_sol, slack_obj = self.slack_model.solve()
            slack_sol = np.asarray(slack_sol, dtype=np.float64)
            slack_sol[np.abs(slack_sol) < 1e-10] = 0.0
            sol = slack_sol[: model.num_cost].copy()
            tolerance = 1e-7 * (1 + abs(original_obj) + np.abs(c).sum())
            if (
                abs(float(c @ sol) - original_obj) > tolerance
                or abs(slack_obj - original_obj) > tolerance
            ):
                raise RuntimeError("Original and slack LP objective values disagree")
            # At a tied optimum both are legitimate labels. Anchor the geometry
            # and label at the SAME vertex, even if the two LP bases select ties
            # differently. The objective comparison above is mandatory.
            self.anchor_reselection_count += int(
                not np.allclose(original_sol, sol, atol=1e-7, rtol=1e-7)
            )
            key = tuple(sol)
            if key not in self.adjacent_vertices_cache:
                adjacent = self._get_adjacent_vertices(slack_sol)
                projected = [np.asarray(v)[: model.num_cost] for v in adjacent]
                projected = list({tuple(v.tolist()): v for v in projected}.values())
                if len(projected) > 1:
                    projected = [v for v in projected if not np.array_equal(v, sol)]
                vertices = np.asarray(projected).reshape(-1, model.num_cost)
                exact_counts[key] = len(vertices)
                if self.vertex_tolerance:
                    vertices = coalesce_vertices(vertices, sol, self.vertex_tolerance)
                self._validate_vertices(vertices)
                self.adjacent_vertices_cache[key] = vertices
            sols.append(sol)
            objs.append([float(c @ sol)])
            ctrs.append(binding_normals(model.source, sol))
            neighbours.append(self.adjacent_vertices_cache[key])
            self.exact_vertex_counts.append(exact_counts[key])
            if progress:
                progress(i + 1, self)
        self.sols, self.objs = np.asarray(sols), np.asarray(objs)
        self.relaxed_sols, self.relaxed_objs = self.sols, self.objs
        self.ctrs, self.adjacent_verts = ctrs, neighbours

    def _basis(self, solution):
        statuses = self.slack_model._model.getBasis()
        if not statuses.valid:
            raise RuntimeError("HiGHS did not return a valid simplex basis")
        basic = np.flatnonzero(
            [s == highspy.HighsBasisStatus.kBasic for s in statuses.col_status]
        )
        matrix = self.slack_model_A
        if len(basic) != matrix.shape[0]:
            # HiGHS bases can contain fixed logical row variables. They must
            # never be treated as movable LAVA slack columns. Retain independent
            # structural rows and, if needed, complete a structural basis using
            # zero-valued columns at this same vertex.
            if self._reduced_rows is None:
                _, r, pivots = scipy.linalg.qr(matrix.T, mode="economic", pivoting=True)
                rank = int(np.count_nonzero(np.abs(np.diag(r)) > 1e-8))
                self._reduced_rows = np.asarray(pivots[:rank])
            matrix = matrix[self._reduced_rows]
            self.geometry_row_reduction |= (
                len(self._reduced_rows) != self.slack_model_A.shape[0]
            )
            missing = matrix.shape[0] - len(basic)
            if missing < 0:
                raise RuntimeError("HiGHS structural basis exceeds the matrix rank")
            if missing:
                candidates = np.setdiff1d(np.arange(matrix.shape[1]), basic)
                q, _ = scipy.linalg.qr(matrix[:, basic], mode="economic")
                residual = matrix[:, candidates] - q @ (q.T @ matrix[:, candidates])
                _, r, pivots = scipy.linalg.qr(residual, mode="economic", pivoting=True)
                if np.count_nonzero(np.abs(np.diag(r)) > 1e-8) < missing:
                    raise RuntimeError("Could not complete a structural simplex basis")
                basic = np.concatenate([basic, candidates[pivots[:missing]]])
                self.basis_completion_count += 1
        nonbasic = np.setdiff1d(np.arange(matrix.shape[1]), basic)
        if len(nonbasic) and np.max(np.abs(solution[nonbasic])) > 1e-8:
            raise RuntimeError(
                "Nonbasic structural variables must be zero in LAVA slack form"
            )
        residual = self.slack_model_A @ solution - self.slack_problem.row_lower
        if np.max(np.abs(residual), initial=0) > 1e-7 * (
            1 + np.max(np.abs(self.slack_problem.row_lower), initial=0)
        ):
            raise RuntimeError(
                "LAVA slack solution fails original equality constraints"
            )
        if np.min(solution, initial=0) < -1e-8:
            raise RuntimeError("LAVA slack solution is negative")
        return matrix, basic, nonbasic

    def _get_adjacent_vertices(self, solution):
        matrix, basic, nonbasic = self._basis(solution)
        if np.sum(solution[basic] < 1e-10) == 0:
            return self.public.get_adjacent_vertices_non_degenerate_case(
                matrix, basic, nonbasic, solution, True
            )
        try:
            return self.public.get_adjacent_vertices_degenerate_case(
                matrix, basic, nonbasic, solution, True, True
            )
        except AssertionError:
            self.adjacency_tnp_retry_count += 1
            return self.public.get_adjacent_vertices_degenerate_case(
                matrix, basic, nonbasic, solution, True, False
            )

    def _validate_vertices(self, vertices):
        problem = self.model.source
        if not len(vertices) or not np.isfinite(vertices).all():
            raise RuntimeError("Public LAVA produced no finite adjacent vertices")
        activity = np.asarray(problem.matrix @ vertices.T).T
        violations = [
            problem.variable_lower - vertices,
            vertices - problem.variable_upper,
            problem.row_lower - activity,
            activity - problem.row_upper,
        ]
        if max(float(np.max(v, initial=0)) for v in violations) > 1e-6:
            raise RuntimeError("Public LAVA produced an infeasible adjacent vertex")
