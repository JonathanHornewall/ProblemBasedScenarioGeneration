"""Method-specific values and output gradients behind one training contract."""

from __future__ import annotations

import time
import zlib
from dataclasses import dataclass, replace
from typing import Literal, Protocol, cast

import cvxpy as cp
import numpy as np
import torch
from cvxpy.atoms.sum_squares import sum_squares
from cvxpylayers.torch.cvxpylayer import CvxpyLayer
from numpy.typing import NDArray
from scipy.sparse import csc_matrix

from .barrier import LogBarrierOracle, make_log_barrier_oracle
from .feasible_policies import (
    PolicyBatch,
    PolyhedralPolicyGeometry,
    compile_policy_geometry,
)
from .oracles import (
    BatchSolutions,
    LPOracle,
    OracleFailure,
    OracleStats,
    make_lp_oracle,
    make_qp_oracle,
)
from .problem import FloatArray, LinearProblem, PartialCostInterface
from .sensitivity import project_onto_tangent
from .torch_log_energy import TorchLogEnergyKernel
from .torch_soft_radial import TorchSoftRadialKernel

IntArray = NDArray[np.int64]


@dataclass(frozen=True)
class PreparedSplit:
    contexts: FloatArray
    coefficients: FloatArray
    conditional_mean_coefficients: FloatArray
    physical_costs: FloatArray
    conditional_mean_costs: FloatArray
    target_decisions: FloatArray
    target_values: FloatArray
    conditional_target_decisions: FloatArray
    conditional_target_values: FloatArray
    split: str
    preparation_stats: OracleStats
    sample_keys: IntArray
    policy_reduced_costs: FloatArray | None = None
    policy_center_costs: FloatArray | None = None

    def subset(self, indices: IntArray) -> TrainingBatch:
        return TrainingBatch(
            contexts=self.contexts[indices],
            coefficients=self.coefficients[indices],
            physical_costs=self.physical_costs[indices],
            target_decisions=self.target_decisions[indices],
            target_values=self.target_values[indices],
            sample_keys=self.sample_keys[indices],
            policy_reduced_costs=(
                None
                if self.policy_reduced_costs is None
                else self.policy_reduced_costs[indices]
            ),
            policy_center_costs=(
                None
                if self.policy_center_costs is None
                else self.policy_center_costs[indices]
            ),
        )

    def policy_subset(self, indices: IntArray) -> TrainingBatch:
        """Build the minimal batch for a precomputed direct-policy objective."""

        if self.policy_reduced_costs is None or self.policy_center_costs is None:
            raise ValueError("policy cost coordinates were not prepared")
        empty = np.empty((len(indices), 0), dtype=np.float64)
        return TrainingBatch(
            contexts=empty,
            coefficients=empty,
            physical_costs=empty,
            target_decisions=empty,
            target_values=self.target_values[indices],
            sample_keys=None,
            policy_reduced_costs=self.policy_reduced_costs[indices],
            policy_center_costs=self.policy_center_costs[indices],
        )


@dataclass(frozen=True)
class TrainingBatch:
    contexts: FloatArray
    coefficients: FloatArray
    physical_costs: FloatArray
    target_decisions: FloatArray
    target_values: FloatArray
    sample_keys: IntArray | None = None
    policy_reduced_costs: FloatArray | None = None
    policy_center_costs: FloatArray | None = None


@dataclass(frozen=True)
class BatchSignal:
    values: FloatArray
    output_gradient: FloatArray
    stats: OracleStats
    decisions: FloatArray | None = None
    recovered_coefficients: FloatArray | None = None
    components: dict[str, FloatArray] | None = None

    def __post_init__(self) -> None:
        values = np.asarray(self.values, dtype=np.float64)
        gradient = np.asarray(self.output_gradient, dtype=np.float64)
        if values.ndim != 1 or gradient.ndim != 2 or len(values) != len(gradient):
            raise ValueError("values and output gradients must form a batch")
        if not np.all(np.isfinite(values)) or not np.all(np.isfinite(gradient)):
            raise ValueError("batch signal contains non-finite values")
        if self.components is not None:
            for name, component in self.components.items():
                component_value = np.asarray(component, dtype=np.float64)
                if (
                    not name
                    or component_value.shape != values.shape
                    or not np.all(np.isfinite(component_value))
                ):
                    raise ValueError(
                        "batch-signal components must be named finite vectors"
                    )


@dataclass(frozen=True)
class TorchBatchSignal:
    """Device-resident loss values for the Torch training path."""

    values: torch.Tensor
    stats: OracleStats
    decisions: torch.Tensor | None = None
    components: dict[str, torch.Tensor] | None = None


@dataclass(frozen=True)
class Deployment:
    decisions: FloatArray
    recovered_coefficients: FloatArray | None
    stats: OracleStats


def _normalize_decision_equivalent_costs(
    costs: FloatArray,
    *,
    maximum_magnitude: float = 1.0,
) -> FloatArray:
    """Rescale complete LP costs without changing any exact minimizer.

    Barrier gradients can be extremely large near a polytope boundary and
    arbitrarily small near the analytic center. Their positive scale is
    immaterial to a hard linear-program deployment but not to a floating-point
    solver: an objective below the solver's dual tolerance can otherwise be
    treated as zero. Every nonzero row is therefore normalized both upward and
    downward to ``maximum_magnitude``. Zero rows remain zero.
    """

    values = np.asarray(costs, dtype=np.float64)
    if values.ndim != 2 or values.shape[1] == 0:
        raise ValueError("decision-equivalent costs must form a nonempty batch")
    if not np.all(np.isfinite(values)):
        raise OracleFailure("decision-equivalent costs must be finite")
    if maximum_magnitude <= 0.0 or not np.isfinite(maximum_magnitude):
        raise ValueError("maximum_magnitude must be finite and positive")
    maximum = np.max(np.abs(values), axis=1, keepdims=True)
    scales = np.divide(
        maximum,
        maximum_magnitude,
        out=np.ones_like(maximum),
        where=maximum > 0.0,
    )
    return np.ascontiguousarray(values / scales)


def _solve_decision_equivalent_costs(
    costs: FloatArray,
    *,
    oracle: LPOracle,
    interface: PartialCostInterface,
    workers: int,
    random_seed: int,
    sample_keys: IntArray | None = None,
) -> tuple[FloatArray, BatchSolutions, LPOracle]:
    """Solve a hard LP with two mathematically equivalent numerical scales."""

    primary = _normalize_decision_equivalent_costs(costs)
    try:
        solved = (
            oracle.solve_many(primary)
            if sample_keys is None
            else oracle.solve_many(primary, sample_keys)
        )
        return primary, solved, oracle
    except OracleFailure:
        oracle.close()
        replacement = make_lp_oracle(
            interface.problem,
            workers=workers,
            random_seed=random_seed,
        )
        fallback = _normalize_decision_equivalent_costs(
            costs,
            maximum_magnitude=1e4,
        )
        try:
            solved = (
                replacement.solve_many(fallback)
                if sample_keys is None
                else replacement.solve_many(fallback, sample_keys)
            )
        except Exception:
            replacement.close()
            raise
        solved = BatchSolutions(
            solved.decisions,
            solved.objectives,
            solved.stats + OracleStats(retries=1),
        )
        return fallback, solved, replacement


class LearningObjective(Protocol):
    name: str
    output_dimension: int

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal: ...

    def deploy(self, outputs: FloatArray) -> Deployment: ...

    def close(self) -> None: ...


def sample_keys_for_split(split: str, count: int) -> IntArray:
    if count < 0:
        raise ValueError("sample count must be nonnegative")
    namespace = int(zlib.crc32(split.encode("utf-8")) & 0xFFFFF)
    return (namespace << 40) + np.arange(count, dtype=np.int64)


def prepare_split(
    *,
    contexts: FloatArray,
    coefficients: FloatArray,
    conditional_mean_coefficients: FloatArray,
    physical_costs: FloatArray,
    conditional_mean_costs: FloatArray,
    split: str,
    oracle: LPOracle,
) -> PreparedSplit:
    sample_keys = sample_keys_for_split(split, len(contexts))
    targets = oracle.solve_many(physical_costs, sample_keys)
    conditional_targets = oracle.solve_many(conditional_mean_costs, sample_keys)
    return PreparedSplit(
        contexts=np.asarray(contexts, dtype=np.float64),
        coefficients=np.asarray(coefficients, dtype=np.float64),
        conditional_mean_coefficients=np.asarray(
            conditional_mean_coefficients, dtype=np.float64
        ),
        physical_costs=np.asarray(physical_costs, dtype=np.float64),
        conditional_mean_costs=np.asarray(conditional_mean_costs, dtype=np.float64),
        target_decisions=targets.decisions,
        target_values=targets.objectives,
        conditional_target_decisions=conditional_targets.decisions,
        conditional_target_values=conditional_targets.objectives,
        split=split,
        preparation_stats=targets.stats + conditional_targets.stats,
        sample_keys=sample_keys,
    )


def _prepare_policy_cost_coordinates(
    split: PreparedSplit, geometry: PolyhedralPolicyGeometry
) -> PreparedSplit:
    """Cache the fixed affine-chart representation of every training cost."""

    reduced = np.ascontiguousarray(split.physical_costs @ geometry.physical_map)
    center = np.ascontiguousarray(split.physical_costs @ geometry.center)
    return replace(
        split,
        policy_reduced_costs=reduced,
        policy_center_costs=center,
    )


def _policy_cost_and_reduced_cotangent(
    batch: TrainingBatch,
    mapped: PolicyBatch,
    geometry: PolyhedralPolicyGeometry,
) -> tuple[FloatArray, FloatArray]:
    reduced = batch.policy_reduced_costs
    center = batch.policy_center_costs
    if reduced is None or center is None:
        reduced = batch.physical_costs @ geometry.physical_map
        center = batch.physical_costs @ geometry.center
    if reduced.shape != mapped.reduced_decisions.shape or center.shape != (
        len(mapped.decisions),
    ):
        raise ValueError("cached policy-cost coordinates have incompatible shapes")
    decision_cost = center + np.sum(reduced * mapped.reduced_decisions, axis=1)
    return decision_cost, reduced


def _policy_training_batch(
    split: PreparedSplit, indices: IntArray
) -> TrainingBatch:
    if split.policy_reduced_costs is None or split.policy_center_costs is None:
        return split.subset(indices)
    return split.policy_subset(indices)


class CostPredictionObjective:
    """Shared deployment interface for MSE/WISE-like coefficient prediction."""

    name = "mse"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        workers: int,
        random_seed: int,
    ) -> None:
        self.interface = interface
        self.output_dimension = interface.report_dimension
        self._lp = make_lp_oracle(
            interface.problem, workers=workers, random_seed=random_seed
        )

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        residual = np.asarray(outputs, dtype=np.float64) - batch.coefficients
        return BatchSignal(
            values=0.5 * np.sum(residual**2, axis=1),
            output_gradient=residual,
            stats=OracleStats(),
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        return self.deploy_with_sample_keys(outputs, None)

    def deploy_with_sample_keys(
        self, outputs: FloatArray, sample_keys: IntArray | None
    ) -> Deployment:
        physical = self.interface.physical_cost(np.asarray(outputs, dtype=np.float64))
        solutions = self._lp.solve_many(physical, sample_keys)
        return Deployment(solutions.decisions, np.asarray(outputs), solutions.stats)

    def predicted_physical_costs(self, outputs: FloatArray) -> FloatArray:
        """Return the literal physical costs used at deployment."""

        return np.asarray(
            self.interface.physical_cost(np.asarray(outputs, dtype=np.float64)),
            dtype=np.float64,
        )

    def close(self) -> None:
        self._lp.close()


class WISEObjective:
    """Weight Integrated Spherical Error (Wan and Liu, 2026).

    With a nonzero fixed cost, the exact label is ``(1, gamma)`` and the
    associated decision statistic is ``(a'z, Pz)``.  Applying WISE to
    ``gamma`` alone would incorrectly discard the deterministic objective.
    """

    name = "wise"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        workers: int,
        random_seed: int,
        zero_tolerance: float = 1e-12,
    ) -> None:
        self.interface = interface
        self.augmented = bool(np.linalg.norm(interface.fixed_cost) > 1e-12)
        self.output_dimension = interface.report_dimension + int(self.augmented)
        self.zero_tolerance = float(zero_tolerance)
        self._lp = make_lp_oracle(
            interface.problem, workers=workers, random_seed=random_seed
        )

    def labels(self, coefficients: FloatArray) -> FloatArray:
        coefficients = np.asarray(coefficients, dtype=np.float64)
        if not self.augmented:
            return coefficients
        return np.concatenate([np.ones((len(coefficients), 1)), coefficients], axis=1)

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        labels = self.labels(batch.coefficients)
        norms = np.linalg.norm(labels, axis=1)
        safe_norms = np.maximum(norms, self.zero_tolerance)
        directions = labels / safe_norms[:, None]
        residual = np.asarray(outputs, dtype=np.float64) - directions
        active = norms > self.zero_tolerance
        values = np.where(active, norms * np.sum(residual**2, axis=1), 0.0)
        gradient = np.where(active[:, None], 2.0 * norms[:, None] * residual, 0.0)
        return BatchSignal(values, gradient, OracleStats())

    def _physical_cost(self, outputs: FloatArray) -> FloatArray:
        outputs = np.asarray(outputs, dtype=np.float64)
        if self.augmented:
            return (
                outputs[:, :1] * self.interface.fixed_cost
                + outputs[:, 1:] @ self.interface.statistic
            )
        return outputs @ self.interface.statistic

    def deploy(self, outputs: FloatArray) -> Deployment:
        return self.deploy_with_sample_keys(outputs, None)

    def deploy_with_sample_keys(
        self, outputs: FloatArray, sample_keys: IntArray | None
    ) -> Deployment:
        solutions = self._lp.solve_many(self._physical_cost(outputs), sample_keys)
        return Deployment(solutions.decisions, None, solutions.stats)

    def predicted_physical_costs(self, outputs: FloatArray) -> FloatArray:
        return np.asarray(self._physical_cost(outputs), dtype=np.float64)

    def close(self) -> None:
        self._lp.close()


class SPOPlusObjective:
    """SPO+ restricted to the same random-cost coefficient space."""

    name = "spo_plus"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        workers: int,
        random_seed: int,
        deployment_problem: LinearProblem | None = None,
    ) -> None:
        self.interface = interface
        self.output_dimension = interface.report_dimension
        self._training_lp = make_lp_oracle(
            interface.problem, workers=workers, random_seed=random_seed
        )
        hard_problem = (
            interface.problem if deployment_problem is None else deployment_problem
        )
        self.deployment_interface = PartialCostInterface(
            hard_problem,
            interface.fixed_cost,
            interface.statistic,
            name=f"{interface.name}.hard_deployment",
        )
        self._deployment_lp = (
            self._training_lp
            if hard_problem is interface.problem
            else make_lp_oracle(
                hard_problem, workers=workers, random_seed=random_seed
            )
        )

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        outputs = np.asarray(outputs, dtype=np.float64)
        direction_coefficients = 2.0 * outputs - batch.coefficients
        direction_costs = self.interface.physical_cost(direction_coefficients)
        surrogate = self._training_lp.solve_many(direction_costs, batch.sample_keys)
        differences = batch.target_decisions - surrogate.decisions
        values = np.sum(direction_costs * differences, axis=1)
        target_direction_values = np.sum(
            direction_costs * batch.target_decisions, axis=1
        )
        numerical_tolerance = 5e-8 * (
            1.0
            + np.abs(target_direction_values)
            + np.abs(surrogate.objectives)
            + np.sum(np.abs(direction_costs), axis=1)
        )
        if np.any(values < -numerical_tolerance):
            raise RuntimeError(
                f"SPO+ oracle produced materially negative loss {np.min(values):.3e}"
            )
        gradient = 2.0 * (differences @ self.interface.statistic.T)
        return BatchSignal(
            values=np.maximum(values, 0.0),
            output_gradient=gradient,
            stats=surrogate.stats,
            decisions=surrogate.decisions,
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        return self.deploy_with_sample_keys(outputs, None)

    def deploy_with_sample_keys(
        self, outputs: FloatArray, sample_keys: IntArray | None
    ) -> Deployment:
        outputs = np.asarray(outputs, dtype=np.float64)
        solutions = self._deployment_lp.solve_many(
            self.deployment_interface.physical_cost(outputs), sample_keys
        )
        return Deployment(solutions.decisions, outputs, solutions.stats)

    def predicted_physical_costs(self, outputs: FloatArray) -> FloatArray:
        """Expose the ordinary SPO+ cost report for prediction diagnostics."""

        return np.asarray(
            self.deployment_interface.physical_cost(
                np.asarray(outputs, dtype=np.float64)
            ),
            dtype=np.float64,
        )

    def close(self) -> None:
        self._training_lp.close()
        if self._deployment_lp is not self._training_lp:
            self._deployment_lp.close()


class PerturbedFenchelYoungObjective:
    """Gaussian perturbed Fenchel--Young imitation loss for minimization.

    The implementation follows the standard perturbed-optimizer construction
    in coefficient coordinates.  For a report ``c`` and observed optimizer
    ``z*``, its output gradient is

    ``P z* - E[P z(c + epsilon * Z)]``.

    The finite Monte-Carlo objective value is recorded up to the label-only
    Fenchel--Young constant, which has no effect on training.  Unlike SFGE,
    this baseline imitates the observed optimizer and does not estimate the
    gradient of realized decision cost.
    """

    name = "perturbed_fy"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        epsilon: float,
        samples: int,
        workers: int,
        random_seed: int,
    ) -> None:
        if epsilon <= 0.0 or not np.isfinite(epsilon):
            raise ValueError("perturbed-FY epsilon must be finite and positive")
        if samples <= 0:
            raise ValueError("perturbed-FY samples must be positive")
        self.interface = interface
        self.epsilon = float(epsilon)
        self.samples = int(samples)
        self.output_dimension = interface.report_dimension
        self._rng = np.random.Generator(np.random.PCG64(random_seed))
        self._lp = make_lp_oracle(
            interface.problem,
            workers=workers,
            random_seed=random_seed,
        )

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        outputs = np.asarray(outputs, dtype=np.float64)
        count, dimension = outputs.shape
        noise = self._rng.standard_normal((count, self.samples, dimension))
        perturbed_coefficients = (
            outputs[:, None, :] + self.epsilon * noise
        ).reshape(count * self.samples, dimension)
        perturbed_costs = self.interface.physical_cost(perturbed_coefficients)
        sample_keys: IntArray | None = None
        if batch.sample_keys is not None:
            slots = np.arange(self.samples, dtype=np.int64)
            sample_keys = np.bitwise_xor(
                np.repeat(batch.sample_keys, self.samples),
                np.tile(slots + np.int64(0x6A09E667), count),
            )
        solutions = self._lp.solve_many(perturbed_costs, sample_keys)
        perturbed_decisions = solutions.decisions.reshape(
            count, self.samples, -1
        )
        mean_statistics = np.mean(
            perturbed_decisions @ self.interface.statistic.T,
            axis=1,
        )
        target_statistics = batch.target_decisions @ self.interface.statistic.T
        gradient = target_statistics - mean_statistics
        predicted_costs = self.interface.physical_cost(outputs)
        target_term = np.einsum(
            "bn,bn->b", predicted_costs, batch.target_decisions
        )
        perturbed_values = np.einsum(
            "bkn,bkn->bk",
            perturbed_costs.reshape(count, self.samples, -1),
            perturbed_decisions,
        )
        values = target_term - np.mean(perturbed_values, axis=1)
        return BatchSignal(
            values=values,
            output_gradient=gradient,
            stats=solutions.stats,
            decisions=np.mean(perturbed_decisions, axis=1),
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        return self.deploy_with_sample_keys(outputs, None)

    def deploy_with_sample_keys(
        self, outputs: FloatArray, sample_keys: IntArray | None
    ) -> Deployment:
        outputs = np.asarray(outputs, dtype=np.float64)
        solutions = self._lp.solve_many(
            self.interface.physical_cost(outputs), sample_keys
        )
        return Deployment(solutions.decisions, outputs, solutions.stats)

    def predicted_physical_costs(self, outputs: FloatArray) -> FloatArray:
        return np.asarray(
            self.interface.physical_cost(np.asarray(outputs, dtype=np.float64)),
            dtype=np.float64,
        )

    def close(self) -> None:
        self._lp.close()


class ProximalObjective:
    """Raw compatible proximal report ``h``."""

    name = "proximal"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        tau: float,
        workers: int,
        report_scale: float = 1.0,
    ) -> None:
        if not np.isfinite(tau) or tau <= 0.0:
            raise ValueError("tau must be finite and positive")
        if not np.isfinite(report_scale) or report_scale <= 0.0:
            raise ValueError("report_scale must be finite and positive")
        self.interface = interface
        self.tau = float(tau)
        self.report_scale = float(report_scale)
        self.output_dimension = interface.report_dimension
        quadratic = csc_matrix(interface.statistic.T @ interface.statistic / tau)
        self._qp = make_qp_oracle(interface.problem, quadratic, workers=workers)

    def _decode(
        self,
        reports: FloatArray,
        sample_keys: IntArray | None = None,
    ) -> Deployment:
        reports = np.asarray(reports, dtype=np.float64)
        physical_reports = self.report_scale * reports
        linear = (
            self.interface.fixed_cost
            + (physical_reports / self.tau) @ self.interface.statistic
        )
        solutions = self._qp.solve_many(linear, sample_keys)
        statistics = solutions.decisions @ self.interface.statistic.T
        recovered = (physical_reports + statistics) / self.tau
        return Deployment(solutions.decisions, recovered, solutions.stats)

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        decoded = self._decode(outputs, batch.sample_keys)
        assert decoded.recovered_coefficients is not None
        regret = (
            np.sum(batch.physical_costs * decoded.decisions, axis=1)
            - batch.target_values
        )
        residual = decoded.recovered_coefficients - batch.coefficients
        numerical_tolerance = 5e-7 * (
            1.0
            + np.abs(batch.target_values)
            + np.sum(np.abs(batch.physical_costs), axis=1)
        )
        if np.any(regret < -numerical_tolerance):
            raise RuntimeError(
                f"proximal decision regret is materially negative {np.min(regret):.3e}"
            )
        regret = np.maximum(regret, 0.0)
        values = regret + 0.5 * self.tau * np.sum(residual**2, axis=1)
        return BatchSignal(
            values=values,
            output_gradient=self.report_scale * residual,
            stats=decoded.stats,
            decisions=decoded.decisions,
            recovered_coefficients=decoded.recovered_coefficients,
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        return self._decode(outputs)

    def deploy_with_sample_keys(
        self, outputs: FloatArray, sample_keys: IntArray | None
    ) -> Deployment:
        return self._decode(outputs, sample_keys)

    def close(self) -> None:
        self._qp.close()


class AnchoredProximalObjective:
    """MSE-base coefficient ``b`` plus proximal correction/selection ``s``."""

    name = "anchored_proximal"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        tau: float,
        alpha: float,
        workers: int,
        random_seed: int,
        center_on_base_decision: bool = True,
    ) -> None:
        if alpha < 0.0 or not np.isfinite(alpha):
            raise ValueError("alpha must be finite and nonnegative")
        self.interface = interface
        self.tau = float(tau)
        self.alpha = float(alpha)
        self.center_on_base_decision = bool(center_on_base_decision)
        self.output_dimension = 2 * interface.report_dimension
        if tau <= 0.0 or not np.isfinite(tau):
            raise ValueError("tau must be finite and positive")
        quadratic = csc_matrix(interface.statistic.T @ interface.statistic / tau)
        self._qp = make_qp_oracle(interface.problem, quadratic, workers=workers)
        self._base_lp = make_lp_oracle(
            interface.problem, workers=workers, random_seed=random_seed
        )

    def _split(self, outputs: FloatArray) -> tuple[FloatArray, FloatArray]:
        outputs = np.asarray(outputs, dtype=np.float64)
        k = self.interface.report_dimension
        if outputs.ndim != 2 or outputs.shape[1] != 2 * k:
            raise ValueError("anchored output must concatenate b and s")
        return outputs[:, :k], outputs[:, k:]

    def _decode(
        self,
        outputs: FloatArray,
        sample_keys: IntArray | None = None,
    ) -> Deployment:
        base, correction = self._split(outputs)
        stats = OracleStats()
        if self.center_on_base_decision:
            baseline = self._base_lp.solve_many(
                self.interface.physical_cost(base), sample_keys
            )
            center = baseline.decisions @ self.interface.statistic.T + correction
            stats += baseline.stats
        else:
            center = correction
        linear = (
            self.interface.fixed_cost
            + (base - center / self.tau) @ self.interface.statistic
        )
        solutions = self._qp.solve_many(linear, sample_keys)
        statistics = solutions.decisions @ self.interface.statistic.T
        recovered = base + (statistics - center) / self.tau
        return Deployment(solutions.decisions, recovered, stats + solutions.stats)

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        base, _ = self._split(outputs)
        decoded = self._decode(outputs, batch.sample_keys)
        assert decoded.recovered_coefficients is not None
        recovered_residual = decoded.recovered_coefficients - batch.coefficients
        base_residual = base - batch.coefficients
        regret = (
            np.sum(batch.physical_costs * decoded.decisions, axis=1)
            - batch.target_values
        )
        values = (
            regret
            + 0.5 * self.tau * np.sum(recovered_residual**2, axis=1)
            + 0.5 * self.alpha * np.sum(base_residual**2, axis=1)
        )
        grad_base = self.tau * recovered_residual + self.alpha * base_residual
        grad_correction = -recovered_residual
        return BatchSignal(
            values=values,
            output_gradient=np.concatenate([grad_base, grad_correction], axis=1),
            stats=decoded.stats,
            decisions=decoded.decisions,
            recovered_coefficients=decoded.recovered_coefficients,
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        return self._decode(outputs)

    def deploy_with_sample_keys(
        self, outputs: FloatArray, sample_keys: IntArray | None
    ) -> Deployment:
        return self._decode(outputs, sample_keys)

    def close(self) -> None:
        self._qp.close()
        self._base_lp.close()


class ResidualMSEObjective:
    """Frozen cost-MSE base plus a learned coefficient residual.

    This is the structurally matched control for anchored proximal learning:
    both methods use the same base and correction network, but this objective
    trains the correction by ordinary squared coefficient error.
    """

    name = "residual_mse"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        workers: int,
        random_seed: int,
    ) -> None:
        self.interface = interface
        self.output_dimension = 2 * interface.report_dimension
        self._lp = make_lp_oracle(
            interface.problem, workers=workers, random_seed=random_seed
        )

    def _prediction(self, outputs: FloatArray) -> tuple[FloatArray, FloatArray]:
        outputs = np.asarray(outputs, dtype=np.float64)
        k = self.interface.report_dimension
        if outputs.ndim != 2 or outputs.shape[1] != 2 * k:
            raise ValueError("residual MSE output must concatenate base and residual")
        base = outputs[:, :k]
        prediction = base + outputs[:, k:]
        return base, prediction

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        _, prediction = self._prediction(outputs)
        residual = prediction - batch.coefficients
        return BatchSignal(
            values=0.5 * np.sum(residual**2, axis=1),
            output_gradient=np.concatenate([residual, residual], axis=1),
            stats=OracleStats(),
            recovered_coefficients=prediction,
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        return self.deploy_with_sample_keys(outputs, None)

    def deploy_with_sample_keys(
        self, outputs: FloatArray, sample_keys: IntArray | None
    ) -> Deployment:
        _, prediction = self._prediction(outputs)
        solutions = self._lp.solve_many(
            self.interface.physical_cost(prediction), sample_keys
        )
        return Deployment(solutions.decisions, prediction, solutions.stats)

    def close(self) -> None:
        self._lp.close()


class SFGEObjective:
    """Antithetic Gaussian SFGE/REINFORCE estimator of realized decision cost."""

    name = "sfge"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        sigma: float,
        samples: int,
        workers: int,
        random_seed: int,
        deployment_problem: LinearProblem | None = None,
    ) -> None:
        if sigma <= 0.0 or samples <= 0:
            raise ValueError("sigma and samples must be positive")
        self.interface = interface
        self.sigma = float(sigma)
        self.samples = int(samples)
        self.output_dimension = interface.report_dimension
        self._rng = np.random.Generator(np.random.PCG64(random_seed))
        self._training_lp = make_lp_oracle(
            interface.problem, workers=workers, random_seed=random_seed
        )
        hard_problem = (
            interface.problem if deployment_problem is None else deployment_problem
        )
        self.deployment_interface = PartialCostInterface(
            hard_problem,
            interface.fixed_cost,
            interface.statistic,
            name=f"{interface.name}.hard_deployment",
        )
        self._deployment_lp = (
            self._training_lp
            if hard_problem is interface.problem
            else make_lp_oracle(
                hard_problem, workers=workers, random_seed=random_seed
            )
        )

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        outputs = np.asarray(outputs, dtype=np.float64)
        n, k = outputs.shape
        noises = self._rng.standard_normal((n, self.samples, k))
        plus = outputs[:, None, :] + self.sigma * noises
        minus = outputs[:, None, :] - self.sigma * noises
        all_coefficients = np.concatenate(
            [plus.reshape(-1, k), minus.reshape(-1, k)], axis=0
        )
        physical = self.interface.physical_cost(all_coefficients)
        sample_keys: IntArray | None = None
        if batch.sample_keys is not None:
            slots = np.arange(2 * self.samples, dtype=np.int64)
            sample_keys = np.bitwise_xor(
                np.repeat(batch.sample_keys, 2 * self.samples),
                np.tile(slots + np.int64(0x5F3759DF), n),
            )
            # Coefficients are ordered as all plus rows followed by all minus
            # rows, rather than observation-major. Match that exact order.
            plus_keys = sample_keys.reshape(n, 2 * self.samples)[:, : self.samples]
            minus_keys = sample_keys.reshape(n, 2 * self.samples)[:, self.samples :]
            sample_keys = np.concatenate([plus_keys.ravel(), minus_keys.ravel()])
        solutions = self._training_lp.solve_many(physical, sample_keys)
        split = n * self.samples
        plus_decisions = solutions.decisions[:split].reshape(n, self.samples, -1)
        minus_decisions = solutions.decisions[split:].reshape(n, self.samples, -1)
        plus_loss = np.einsum("bn,bmn->bm", batch.physical_costs, plus_decisions)
        minus_loss = np.einsum("bn,bmn->bm", batch.physical_costs, minus_decisions)
        gradient = np.mean(
            (plus_loss - minus_loss)[:, :, None] * noises / (2.0 * self.sigma),
            axis=1,
        )
        values = 0.5 * np.mean(plus_loss + minus_loss, axis=1)
        return BatchSignal(values, gradient, solutions.stats)

    def deploy(self, outputs: FloatArray) -> Deployment:
        return self.deploy_with_sample_keys(outputs, None)

    def deploy_with_sample_keys(
        self, outputs: FloatArray, sample_keys: IntArray | None
    ) -> Deployment:
        outputs = np.asarray(outputs, dtype=np.float64)
        solutions = self._deployment_lp.solve_many(
            self.deployment_interface.physical_cost(outputs), sample_keys
        )
        return Deployment(solutions.decisions, outputs, solutions.stats)

    def close(self) -> None:
        self._training_lp.close()
        if self._deployment_lp is not self._training_lp:
            self._deployment_lp.close()


class ScoreFunctionObjective(SFGEObjective):
    """Backward-compatible name for historical ``score_function`` receipts."""

    name = "score_function"


class QuadraticSmoothingObjective:
    """Direct-regret differentiation through a quadratically smoothed LP."""

    name = "quadratic_smoothing"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        smoothing: float,
        workers: int,
        random_seed: int,
        active_tolerance: float = 2e-5,
    ) -> None:
        if smoothing <= 0.0 or not np.isfinite(smoothing):
            raise ValueError("smoothing must be finite and positive")
        self.interface = interface
        self.smoothing = float(smoothing)
        self.active_tolerance = float(active_tolerance)
        self.output_dimension = interface.report_dimension
        quadratic = csc_matrix(
            np.eye(interface.problem.variable_count) * self.smoothing
        )
        self._qp = make_qp_oracle(interface.problem, quadratic, workers=workers)
        self._lp = make_lp_oracle(
            interface.problem, workers=workers, random_seed=random_seed
        )

    def _smoothed(
        self, outputs: FloatArray, sample_keys: IntArray | None = None
    ) -> BatchSolutions:
        physical = self.interface.physical_cost(np.asarray(outputs, dtype=np.float64))
        return self._qp.solve_many(physical, sample_keys)

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        smoothed = self._smoothed(outputs, batch.sample_keys)
        regret = (
            np.sum(batch.physical_costs * smoothed.decisions, axis=1)
            - batch.target_values
        )
        gradients: list[FloatArray] = []
        for decision, true_cost in zip(
            smoothed.decisions, batch.physical_costs, strict=True
        ):
            tangent_cost = project_onto_tangent(
                self.interface.problem,
                decision,
                true_cost,
                tolerance=self.active_tolerance,
            )
            physical_gradient = -tangent_cost / self.smoothing
            gradients.append(physical_gradient @ self.interface.statistic.T)
        return BatchSignal(
            values=regret,
            output_gradient=np.stack(gradients),
            stats=smoothed.stats,
            decisions=smoothed.decisions,
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        return self.deploy_with_sample_keys(outputs, None)

    def deploy_with_sample_keys(
        self, outputs: FloatArray, sample_keys: IntArray | None
    ) -> Deployment:
        outputs = np.asarray(outputs, dtype=np.float64)
        solutions = self._lp.solve_many(
            self.interface.physical_cost(outputs), sample_keys
        )
        return Deployment(solutions.decisions, outputs, solutions.stats)

    def close(self) -> None:
        self._qp.close()
        self._lp.close()


class SmoothedSCEObjective(QuadraticSmoothingObjective):
    """Mandi et al.'s SCE surrogate differentiated through the QP layer."""

    name = "smoothed_sce"

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        outputs = np.asarray(outputs, dtype=np.float64)
        predicted_costs = self.interface.physical_cost(outputs)
        smoothed = self._qp.solve_many(predicted_costs, batch.sample_keys)
        decision_difference = batch.target_decisions - smoothed.decisions
        cost_difference = predicted_costs - batch.physical_costs
        values = np.sum(cost_difference * decision_difference, axis=1)
        gradients: list[FloatArray] = []
        for decision, direct, cost_residual in zip(
            smoothed.decisions,
            decision_difference,
            cost_difference,
            strict=True,
        ):
            tangent_residual = project_onto_tangent(
                self.interface.problem,
                decision,
                cost_residual,
                tolerance=self.active_tolerance,
            )
            physical_gradient = direct + tangent_residual / self.smoothing
            gradients.append(physical_gradient @ self.interface.statistic.T)
        return BatchSignal(
            values=values,
            output_gradient=np.stack(gradients),
            stats=smoothed.stats,
            decisions=smoothed.decisions,
        )


class DirectProjectionObjective:
    """Direct policy learning through a maintained differentiable QP layer."""

    name = "direct_projection"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        workers: int,
    ) -> None:
        self.interface = interface
        self.output_dimension = interface.problem.variable_count
        self.workers = int(workers)
        self.normalized_problem = interface.problem.row_normalized()
        self.geometry = compile_policy_geometry(self.normalized_problem)
        self.initial_output_bias = self.geometry.center.copy()
        variable = cp.Variable(self.output_dimension)
        report = cp.Parameter(self.output_dimension)
        matrix = self.normalized_problem.osqp_matrix
        lower = self.normalized_problem.osqp_lower
        upper = self.normalized_problem.osqp_upper
        finite_lower = np.isfinite(lower)
        finite_upper = np.isfinite(upper)
        equality = finite_lower & finite_upper & (np.abs(upper - lower) <= 1e-12)
        constraints: list[cp.Constraint] = []
        if np.any(equality):
            constraints.append(matrix[equality] @ variable == upper[equality])
        upper_rows = finite_upper & ~equality
        if np.any(upper_rows):
            constraints.append(matrix[upper_rows] @ variable <= upper[upper_rows])
        lower_rows = finite_lower & ~equality
        if np.any(lower_rows):
            constraints.append(matrix[lower_rows] @ variable >= lower[lower_rows])
        problem = cp.Problem(
            cp.Minimize(0.5 * sum_squares(variable - report)), constraints
        )
        if not problem.is_dpp():
            raise RuntimeError("Euclidean projection layer is not DPP compliant")
        self._solver_args: dict[str, object] = {
            "solve_method": "Clarabel",
            "tol_gap_abs": 1e-12,
            "tol_gap_rel": 1e-12,
            "tol_feas": 1e-12,
            "max_iter": 1_000,
        }
        self._layer = CvxpyLayer(
            problem,
            parameters=[report],
            variables=[variable],
            solver="DIFFCP",
            solver_args=self._solver_args,
        )

    def _project(
        self, outputs: FloatArray, *, needs_gradient: bool
    ) -> tuple[torch.Tensor, torch.Tensor, OracleStats]:
        reports = torch.tensor(
            np.asarray(outputs, dtype=np.float64),
            dtype=torch.float64,
            requires_grad=needs_gradient,
        )
        started = time.perf_counter()
        parallel_args: dict[str, object] = {"n_jobs_forward": self.workers}
        if needs_gradient:
            parallel_args["n_jobs_backward"] = self.workers
        (decisions,) = self._layer(reports, solver_args=parallel_args)
        stats = OracleStats(
            calls=len(reports), wall_seconds=time.perf_counter() - started
        )
        return reports, decisions, stats

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        reports, decisions, stats = self._project(outputs, needs_gradient=True)
        physical_costs = torch.as_tensor(batch.physical_costs, dtype=torch.float64)
        (gradient,) = torch.autograd.grad(
            decisions,
            reports,
            grad_outputs=physical_costs,
            retain_graph=False,
            create_graph=False,
        )
        decision_array = decisions.detach().cpu().numpy()
        regret = (
            np.sum(batch.physical_costs * decision_array, axis=1) - batch.target_values
        )
        return BatchSignal(
            regret,
            gradient.detach().cpu().numpy(),
            stats,
            decisions=decision_array,
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        _, decisions, stats = self._project(outputs, needs_gradient=False)
        return Deployment(decisions.detach().cpu().numpy(), None, stats)

    def close(self) -> None:
        return None

    def receipt(self) -> dict[str, object]:
        return {
            "policy": "euclidean_qp_projection",
            "solver_in_forward_loop": True,
            "differentiation_layer": "cvxpylayers",
            "differentiation_backend": "diffcp",
            "forward_solver": "clarabel",
            "solver_tolerance": 1e-12,
            "workers": self.workers,
            "problem_rows_normalized": True,
            "output_dimension": self.output_dimension,
            **self.geometry.receipt_dict(),
        }


class RayenPolicyObjective:
    """Direct downstream-cost training through the hard RAYEN radial map."""

    name = "rayen_policy"

    def __init__(self, interface: PartialCostInterface) -> None:
        self.interface = interface
        self.geometry = compile_policy_geometry(interface.problem)
        self.output_dimension = self.geometry.intrinsic_dimension

    def prepare_training_split(self, split: PreparedSplit) -> PreparedSplit:
        return _prepare_policy_cost_coordinates(split, self.geometry)

    @staticmethod
    def training_batch(split: PreparedSplit, indices: IntArray) -> TrainingBatch:
        return _policy_training_batch(split, indices)

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        mapped = self.geometry.hard_radial(outputs)
        decision_cost, reduced_cotangent = _policy_cost_and_reduced_cotangent(
            batch, mapped, self.geometry
        )
        regret = decision_cost - batch.target_values
        gradient = self.geometry.hard_radial_vjp_from_reduced(mapped, reduced_cotangent)
        return BatchSignal(regret, gradient, OracleStats(), mapped.decisions)

    def deploy(self, outputs: FloatArray) -> Deployment:
        mapped = self.geometry.hard_radial(outputs)
        return Deployment(mapped.decisions, None, OracleStats())

    def receipt(self) -> dict[str, object]:
        return {
            "policy": "rayen_hard_radial",
            "solver_in_forward_loop": False,
            **self.geometry.receipt_dict(),
        }

    def diagnostics(self, outputs: FloatArray) -> dict[str, float]:
        mapped = self.geometry.hard_radial(outputs)
        return {
            "mean_report_norm": float(np.linalg.norm(mapped.reports, axis=1).mean()),
            "maximum_report_norm": float(
                np.linalg.norm(mapped.reports, axis=1).max(initial=0.0)
            ),
            "boundary_clipping_rate": float(np.mean(mapped.scales < 1.0)),
            "minimum_radial_scale": float(mapped.scales.min(initial=1.0)),
        }

    def close(self) -> None:
        return None


class SoftRadialPolicyObjective:
    """Direct policy learning through Schneider--Kuhn Soft-Radial."""

    name = "soft_radial_policy"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        contraction: str,
        contraction_scale: float,
        minimum_scale: float,
        kernel_backend: str = "numpy",
        torch_device: str = "auto",
        training_dtype: str = "float64",
        report_guard: bool = True,
        hessian_whitening: bool = True,
        guard_safety_factor: float = 0.5,
        guard_radius_policy: str = "legacy_unit",
    ) -> None:
        if contraction not in {"rational", "exponential", "hyperbolic"}:
            raise ValueError(
                "contraction must be rational, exponential, or hyperbolic"
            )
        if contraction_scale <= 0.0:
            raise ValueError("contraction_scale must be positive")
        if not 0.0 < minimum_scale < 1.0:
            raise ValueError("minimum_scale must lie strictly between zero and one")
        self.interface = interface
        self.geometry = compile_policy_geometry(interface.problem, hessian_whitening=hessian_whitening)
        self.output_dimension = self.geometry.intrinsic_dimension
        self.contraction = cast(
            Literal["rational", "exponential", "hyperbolic"], contraction
        )
        self.contraction_scale = float(contraction_scale)
        self.minimum_scale = float(minimum_scale)
        if not isinstance(report_guard, bool):
            raise ValueError("report_guard must be boolean")
        self.report_guard = report_guard
        if training_dtype not in {"float32", "float64"}:
            raise ValueError("Soft-Radial training dtype must be float32 or float64")
        self.training_dtype = training_dtype
        if kernel_backend not in {"auto", "numpy", "torch"}:
            raise ValueError("kernel_backend must be auto, numpy, or torch")
        if torch_device not in {"auto", "cpu", "cuda", "mps"}:
            raise ValueError("torch_device must be auto, cpu, cuda, or mps")
        resolved_kernel = "torch" if kernel_backend == "auto" else kernel_backend
        self.kernel_backend = cast(Literal["numpy", "torch"], resolved_kernel)
        self.torch_training = self.kernel_backend == "torch"
        if self.torch_training:
            if torch_device == "auto":
                if torch.cuda.is_available():
                    resolved_device = "cuda"
                elif torch.backends.mps.is_available():
                    resolved_device = "mps"
                else:
                    resolved_device = "cpu"
            else:
                resolved_device = torch_device
            if resolved_device == "cuda" and not torch.cuda.is_available():
                raise ValueError("CUDA was requested but is unavailable")
            if resolved_device == "mps" and not torch.backends.mps.is_available():
                raise ValueError("MPS was requested but is unavailable")
            self.training_device = torch.device(resolved_device)
        else:
            if torch_device not in {"auto", "cpu"}:
                raise ValueError(
                    "torch_device is only meaningful with the Torch kernel"
                )
            self.training_device = torch.device("cpu")
        self._torch_kernels: dict[
            tuple[str, torch.dtype], TorchSoftRadialKernel
        ] = {}
        # Compose Soft-Radial with a bounded rational report chart. This is an
        # operative part of the parameterization, not an assumed-inactive
        # emergency branch: it prevents the exponential families from entering
        # a numerically zero-derivative tail at arbitrary raw report norms.
        # The real-valued chart is open, but a float32 contraction closer to
        # one than machine resolution can round onto the hard boundary.  The
        # report chart therefore reserves a dtype-aware interior gap.  The
        # factor 32 is amplified by the half-radius construction below, giving
        # at least about 128 ulps of radial slack at the effective norm limit.
        # It is inactive in float64, where the historical 1e-8 certificate is
        # already much larger than machine precision.
        dtype_epsilon = np.finfo(
            np.float32 if training_dtype == "float32" else np.float64
        ).eps
        numerical_gap = max(1e-8, 32.0 * float(dtype_epsilon))
        self.report_chart_numerical_gap = numerical_gap
        residual_mass = 1.0 - self.minimum_scale
        if self.contraction == "rational":
            safe_squared_norm = (
                residual_mass * self.contraction_scale / numerical_gap
                - self.contraction_scale
            )
        elif self.contraction == "exponential":
            safe_squared_norm = self.contraction_scale * np.log(
                residual_mass / numerical_gap
            )
        else:
            safe_squared_norm = self.contraction_scale * np.arctanh(
                1.0 - numerical_gap / residual_mass
            )
        if not 0.0 < guard_safety_factor < 1.0:
            raise ValueError("guard_safety_factor must lie strictly between zero and one")
        if guard_radius_policy not in {"legacy_unit", "geometry_certified"}:
            raise ValueError("unknown guard_radius_policy")
        self.guard_safety_factor = float(guard_safety_factor)
        self.guard_radius_policy = guard_radius_policy
        maximum_row_norm = float(np.linalg.norm(self.geometry.normalized_inequalities, axis=1).max())
        self.geometry_interior_radius = 1.0 / maximum_row_norm
        # Whitening retains the historical certified unit ball exactly. The
        # alternative chart needs its own certified radius, not an assumed unit ball.
        self.guard_floor_radius = (1.0 if guard_radius_policy == "legacy_unit" or hessian_whitening
                                   else self.geometry_interior_radius)
        self.maximum_report_norm = min(
            1_000.0, self.guard_safety_factor * float(np.sqrt(max(safe_squared_norm, self.guard_floor_radius**2)))
        )

    def _torch_kernel(self, reports: torch.Tensor) -> TorchSoftRadialKernel:
        key = (str(reports.device), reports.dtype)
        cached = self._torch_kernels.get(key)
        if cached is None:
            cached = TorchSoftRadialKernel(
                self.geometry,
                device=reports.device,
                dtype=reports.dtype,
                maximum_report_norm=self.maximum_report_norm,
                contraction=self.contraction,
                contraction_scale=self.contraction_scale,
                minimum_scale=self.minimum_scale,
                report_guard=self.report_guard,
            )
            self._torch_kernels[key] = cached
        return cached

    def prepare_training_split(self, split: PreparedSplit) -> PreparedSplit:
        return _prepare_policy_cost_coordinates(split, self.geometry)

    @staticmethod
    def training_batch(split: PreparedSplit, indices: IntArray) -> TrainingBatch:
        return _policy_training_batch(split, indices)

    def _map(self, outputs: FloatArray) -> tuple[PolicyBatch, FloatArray, FloatArray]:
        if self.report_guard:
            bounded, bound_scales = self.geometry.rationally_bound_reports(
                outputs, maximum_norm=self.maximum_report_norm
            )
        else:
            bounded = np.asarray(outputs, dtype=np.float64)
            bound_scales = np.ones(len(bounded))
        mapped = self.geometry.soft_radial(
            bounded,
            family=self.contraction,
            contraction_scale=self.contraction_scale,
            minimum_scale=self.minimum_scale,
        )
        return mapped, bounded, bound_scales

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        raw = np.asarray(outputs, dtype=np.float64)
        mapped, _, bound_scales = self._map(raw)
        decision_cost, reduced_cotangent = _policy_cost_and_reduced_cotangent(
            batch, mapped, self.geometry
        )
        regret = decision_cost - batch.target_values
        bounded_gradient = self.geometry.soft_radial_vjp_from_reduced(
            mapped,
            reduced_cotangent,
            family=self.contraction,
            contraction_scale=self.contraction_scale,
            minimum_scale=self.minimum_scale,
        )
        gradient = self.geometry.rational_bound_vjp(raw, bound_scales, bounded_gradient)
        return BatchSignal(regret, gradient, OracleStats(), mapped.decisions)

    def torch_signal(
        self,
        outputs: torch.Tensor,
        physical_costs: torch.Tensor,
        target_values: torch.Tensor,
        policy_reduced_costs: torch.Tensor | None = None,
        policy_center_costs: torch.Tensor | None = None,
    ) -> TorchBatchSignal:
        """Evaluate the direct policy loss without leaving the Torch device."""

        if not self.torch_training:
            raise RuntimeError("Torch training was not enabled for this objective")
        mapped = self._torch_kernel(outputs).map(outputs)
        if policy_reduced_costs is not None and policy_center_costs is not None:
            decision_cost = policy_center_costs + torch.sum(
                policy_reduced_costs * mapped.reduced_decisions,
                dim=1,
            )
        else:
            decision_cost = torch.sum(physical_costs * mapped.decisions, dim=1)
        regret = decision_cost - target_values
        return TorchBatchSignal(
            values=regret,
            stats=OracleStats(),
            decisions=mapped.decisions,
            components={"linear_regret": regret},
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        mapped, _, _ = self._map(outputs)
        return Deployment(mapped.decisions, None, OracleStats())

    def receipt(self) -> dict[str, object]:
        return {
            "policy": "soft_radial",
            "solver_in_forward_loop": False,
            "contraction": self.contraction,
            "contraction_scale": self.contraction_scale,
            "minimum_scale": self.minimum_scale,
            "report_chart": "rational_open_ball" if self.report_guard else "identity",
            "numerical_report_guard": "rational_open_ball" if self.report_guard else "none",  # legacy receipt key
            "maximum_effective_report_norm": self.maximum_report_norm,
            "kernel_backend": self.kernel_backend,
            "torch_device": str(self.training_device),
            "training_dtype": self.training_dtype,
            "report_chart_numerical_gap": self.report_chart_numerical_gap,
            **self.geometry.receipt_dict(),
        }

    def diagnostics(self, outputs: FloatArray) -> dict[str, float]:
        raw = np.asarray(outputs, dtype=np.float64)
        mapped, bounded, bound_scales = self._map(raw)
        assert mapped.contractions is not None
        _, contraction_derivative = self.geometry._contraction(
            np.sum(bounded**2, axis=1),
            family=self.contraction,
            scale=self.contraction_scale,
            minimum_scale=self.minimum_scale,
        )
        normalized_slacks = (
            1.0 - mapped.reduced_decisions @ self.geometry.normalized_inequalities.T
        )
        return {
            "mean_report_norm": float(np.linalg.norm(raw, axis=1).mean()),
            "maximum_report_norm": float(np.linalg.norm(raw, axis=1).max(initial=0.0)),
            "maximum_effective_report_norm": float(
                np.linalg.norm(bounded, axis=1).max(initial=0.0)
            ),
            "minimum_report_guard_scale": float(bound_scales.min(initial=1.0)),
            "hard_boundary_clipping_rate": float(np.mean(mapped.scales < 1.0)),
            "mean_contraction": float(mapped.contractions.mean()),
            "minimum_contraction": float(mapped.contractions.min(initial=1.0)),
            "maximum_contraction": float(mapped.contractions.max(initial=0.0)),
            "minimum_normalized_slack": float(normalized_slacks.min()),
            "zero_contraction_derivative_rate": float(
                np.mean(contraction_derivative == 0.0)
            ),
        }

    def close(self) -> None:
        return None


def _barrier_cost_scale(
    geometry: PolyhedralPolicyGeometry,
    interface: PartialCostInterface,
    training_physical_costs: FloatArray,
    training_target_values: FloatArray,
) -> float:
    """Return the shared training-only scale for matched barrier objectives."""

    costs = np.asarray(training_physical_costs, dtype=np.float64)
    targets = np.asarray(training_target_values, dtype=np.float64)
    if (
        costs.ndim != 2
        or costs.shape[1] != interface.problem.variable_count
        or targets.shape != (len(costs),)
        or not np.all(np.isfinite(costs))
        or not np.all(np.isfinite(targets))
    ):
        raise ValueError("training costs and targets have incompatible shapes")
    center_regrets = costs @ geometry.center - targets
    numerical_tolerance = 5e-7 * (1.0 + np.abs(targets) + np.sum(np.abs(costs), axis=1))
    if np.any(center_regrets < -numerical_tolerance):
        raise ValueError("analytic-center regret is materially negative")
    center_regrets = np.maximum(center_regrets, 0.0)
    scale = float(np.median(center_regrets))
    if not np.isfinite(scale) or scale <= 1e-12:
        raise ValueError("training-only analytic-center cost scale is degenerate")
    return scale


class SoftRadialLogBarrierObjective(SoftRadialPolicyObjective):
    """Soft-Radial policy learning with a centered log-barrier objective.

    This deliberately leaves :class:`SoftRadialPolicyObjective` unchanged.
    The dimensionless ``alpha`` is converted to the physical barrier weight
    ``mu = alpha * training_cost_scale / inequality_count``.
    """

    name = "soft_radial_log_barrier"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        contraction: str,
        contraction_scale: float,
        minimum_scale: float,
        alpha_start: float,
        alpha_end: float,
        schedule: str,
        anneal_fraction: float,
        workers: int,
        random_seed: int,
        training_physical_costs: FloatArray,
        training_target_values: FloatArray,
        deployment_problem: LinearProblem | None = None,
        kernel_backend: str = "numpy",
        torch_device: str = "auto",
        training_dtype: str = "float64",
        report_guard: bool = True,
        hessian_whitening: bool = True,
        guard_safety_factor: float = 0.5,
        guard_radius_policy: str = "legacy_unit",
        barrier_cost_scaling: str = "training_center_regret",
    ) -> None:
        super().__init__(
            interface,
            contraction=contraction,
            contraction_scale=contraction_scale,
            minimum_scale=minimum_scale,
            kernel_backend=kernel_backend,
            torch_device=torch_device,
            training_dtype=training_dtype,
            report_guard=report_guard,
            hessian_whitening=hessian_whitening,
            guard_safety_factor=guard_safety_factor,
            guard_radius_policy=guard_radius_policy,
        )
        if alpha_start < 0.0 or alpha_end < 0.0 or alpha_end > alpha_start:
            raise ValueError("require alpha_start >= alpha_end >= 0")
        if schedule not in {"fixed", "geometric", "arithmetic"}:
            raise ValueError("schedule must be fixed, geometric, or arithmetic")
        if schedule == "fixed" and alpha_start != alpha_end:
            raise ValueError("fixed schedule requires equal endpoint alphas")
        if schedule == "geometric" and (alpha_start <= 0.0 or alpha_end <= 0.0):
            raise ValueError("geometric schedule requires positive endpoint alphas")
        if not 0.0 < anneal_fraction <= 1.0:
            raise ValueError("anneal_fraction must lie in (0, 1]")

        if barrier_cost_scaling not in {"training_center_regret", "unit"}:
            raise ValueError("unknown barrier_cost_scaling")
        self.barrier_cost_scaling = barrier_cost_scaling
        cost_scale = (_barrier_cost_scale(self.geometry, interface,
                      training_physical_costs, training_target_values)
                      if barrier_cost_scaling == "training_center_regret" else 1.0)

        self.alpha_start = float(alpha_start)
        self.alpha_end = float(alpha_end)
        self.schedule = cast(Literal["fixed", "geometric", "arithmetic"], schedule)
        self.anneal_fraction = float(anneal_fraction)
        self.selection_deployment: Literal["soft", "hard_recovered"] = "soft"
        self.checkpoint_selection_deployment: Literal["soft", "hard_recovered"] = "soft"
        self._frozen_mu: float | None = None
        self.cost_scale = cost_scale
        self.inequality_count = int(self.geometry.receipt.inequality_count)
        if self.inequality_count <= 0:
            raise ValueError("barrier objective requires at least one inequality")
        self.alpha = self.alpha_start
        self.mu = self.alpha * self.cost_scale / self.inequality_count
        self._hard_workers = int(workers)
        self._hard_random_seed = int(random_seed)
        hard_problem = (
            interface.problem if deployment_problem is None else deployment_problem
        )
        if hard_problem.variable_count != interface.problem.variable_count:
            raise ValueError("training relaxation and deployment problem disagree")
        self.deployment_interface = PartialCostInterface(
            hard_problem,
            interface.fixed_cost,
            interface.statistic,
            name=f"{interface.name}.hard_deployment",
        )
        self._hard_oracle = make_lp_oracle(
            hard_problem, workers=workers, random_seed=random_seed
        )

    def set_epoch(self, epoch: int, total_epochs: int) -> None:
        if epoch <= 0 or total_epochs <= 0 or epoch > total_epochs:
            raise ValueError("epoch must lie in the declared training horizon")
        if self._frozen_mu is not None:
            self.mu = self._frozen_mu
            self.alpha = self.mu * self.inequality_count / self.cost_scale
            return
        if self.schedule == "fixed" or total_epochs == 1:
            progress = 1.0
        else:
            progress = min(
                (epoch - 1) / (self.anneal_fraction * (total_epochs - 1)),
                1.0,
            )
        if self.schedule == "geometric":
            self.alpha = (
                self.alpha_start * (self.alpha_end / self.alpha_start) ** progress
            )
        elif self.schedule == "arithmetic":
            self.alpha = (1.0 - progress) * self.alpha_start + progress * self.alpha_end
        else:
            self.alpha = self.alpha_start
        self.mu = self.alpha * self.cost_scale / self.inequality_count

    def state(self) -> dict[str, float | str]:
        return {
            "alpha": self.alpha,
            "mu": self.mu,
            "schedule": self.schedule,
            "temperature_mode": (
                "scheduled" if self._frozen_mu is None else "fixed_continuation"
            ),
        }

    def set_checkpoint_selection_deployment(self, mode: str) -> None:
        if mode not in {"soft", "hard_recovered"}:
            raise ValueError("checkpoint deployment must be soft or hard_recovered")
        self.checkpoint_selection_deployment = cast(
            Literal["soft", "hard_recovered"], mode
        )

    def freeze_temperature(self, mu: float) -> None:
        if not np.isfinite(mu) or mu < 0.0:
            raise ValueError("fixed continuation temperature must be nonnegative")
        self._frozen_mu = float(mu)
        self.mu = self._frozen_mu
        self.alpha = self.mu * self.inequality_count / self.cost_scale

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        raw = np.asarray(outputs, dtype=np.float64)
        mapped, _, bound_scales = self._map(raw)
        decision_cost, reduced_cost = _policy_cost_and_reduced_cotangent(
            batch, mapped, self.geometry
        )
        linear_regret = decision_cost - batch.target_values
        energy, reduced_barrier_gradient = (
            self.geometry.centered_barrier_value_and_reduced_gradient(mapped)
        )
        barrier_contribution = self.mu * energy
        reduced_cotangent = reduced_cost + self.mu * reduced_barrier_gradient
        bounded_gradient = self.geometry.soft_radial_vjp_from_reduced(
            mapped,
            reduced_cotangent,
            family=self.contraction,
            contraction_scale=self.contraction_scale,
            minimum_scale=self.minimum_scale,
        )
        gradient = self.geometry.rational_bound_vjp(raw, bound_scales, bounded_gradient)
        return BatchSignal(
            linear_regret + barrier_contribution,
            gradient,
            OracleStats(),
            mapped.decisions,
            components={
                "linear_regret": linear_regret,
                "barrier_energy": energy,
                "barrier_contribution": barrier_contribution,
            },
        )

    def torch_signal(
        self,
        outputs: torch.Tensor,
        physical_costs: torch.Tensor,
        target_values: torch.Tensor,
        policy_reduced_costs: torch.Tensor | None = None,
        policy_center_costs: torch.Tensor | None = None,
    ) -> TorchBatchSignal:
        """Evaluate the matched Soft-Radial barrier loss on one device."""

        if not self.torch_training:
            raise RuntimeError("Torch training was not enabled for this objective")
        mapped = self._torch_kernel(outputs).map(outputs)
        if policy_reduced_costs is not None and policy_center_costs is not None:
            decision_cost = policy_center_costs + torch.sum(
                policy_reduced_costs * mapped.reduced_decisions,
                dim=1,
            )
        else:
            decision_cost = torch.sum(physical_costs * mapped.decisions, dim=1)
        linear_regret = decision_cost - target_values
        barrier_contribution = float(self.mu) * mapped.barrier_energy
        return TorchBatchSignal(
            values=linear_regret + barrier_contribution,
            stats=OracleStats(),
            decisions=mapped.decisions,
            components={
                "linear_regret": linear_regret,
                "barrier_energy": mapped.barrier_energy,
                "barrier_contribution": barrier_contribution,
            },
        )

    def torch_map_and_recovered_costs(
        self,
        outputs: torch.Tensor,
    ) -> tuple[TorchBatchSignal, torch.Tensor]:
        """Expose the native chart and hard-deployment cost for verification."""

        mapped = self._torch_kernel(outputs).map(outputs)
        signal = TorchBatchSignal(
            values=mapped.barrier_energy,
            stats=OracleStats(),
            decisions=mapped.decisions,
            components={"barrier_energy": mapped.barrier_energy},
        )
        # Positive scale is immaterial at hard deployment; use unit scale so
        # alpha=0 remains a well-defined ablation, exactly as in NumPy deploy.
        return signal, self._torch_kernel(outputs).recovered_costs(mapped, mu=1.0)

    def set_deployment_mode(self, mode: str) -> None:
        if mode not in {"soft", "hard_recovered"}:
            raise ValueError("deployment mode must be soft or hard_recovered")
        self.selection_deployment = cast(Literal["soft", "hard_recovered"], mode)

    def deploy_with_mode(
        self,
        outputs: FloatArray,
        mode: str,
        sample_keys: IntArray | None = None,
    ) -> Deployment:
        raw_outputs = np.asarray(outputs, dtype=np.float64)
        if self.kernel_backend == "torch":
            tensor_outputs = torch.as_tensor(raw_outputs, dtype=torch.float64)
            torch_mapped = self._torch_kernel(tensor_outputs).map(tensor_outputs)
            mapped_decisions = torch_mapped.decisions.detach().cpu().numpy()
        else:
            mapped, _, _ = self._map(raw_outputs)
            mapped_decisions = mapped.decisions
        if mode == "soft":
            return Deployment(mapped_decisions, None, OracleStats())
        if mode != "hard_recovered":
            raise ValueError("deployment mode must be soft or hard_recovered")
        if self.kernel_backend == "torch":
            physical_cost = (
                self._torch_kernel(tensor_outputs)
                .recovered_costs(torch_mapped, mu=1.0)
                .detach()
                .cpu()
                .numpy()
            )
        else:
            _, physical_barrier_gradient = (
                self.geometry.centered_barrier_value_and_physical_gradient(mapped)
            )
            physical_cost = -physical_barrier_gradient
        # Any positive scaling gives the same hard LP decision.  Omitting mu
        # keeps the deployment well defined for the alpha=0 ablation too.
        recovered_cost, solutions, self._hard_oracle = _solve_decision_equivalent_costs(
            physical_cost,
            oracle=self._hard_oracle,
            interface=self.deployment_interface,
            workers=self._hard_workers,
            random_seed=self._hard_random_seed,
            sample_keys=sample_keys,
        )
        return Deployment(
            solutions.decisions,
            recovered_cost,
            solutions.stats,
        )

    def recovered_cost_direction(self, outputs: FloatArray) -> FloatArray:
        """Return the unscaled physical hard-deployment cost direction.

        ``deploy_with_mode(..., "hard_recovered")`` rescales each row before
        passing it to HiGHS.  That numerical normalization is immaterial for
        decisions but inappropriate for measuring predictive accuracy.  This
        method exposes the KKT cost direction before that normalization.
        """

        mapped, _, _ = self._map(np.asarray(outputs, dtype=np.float64))
        _, physical_barrier_gradient = (
            self.geometry.centered_barrier_value_and_physical_gradient(mapped)
        )
        return np.ascontiguousarray(-physical_barrier_gradient)

    def predicted_physical_costs(self, outputs: FloatArray) -> FloatArray:
        return self.recovered_cost_direction(outputs)

    def deploy(self, outputs: FloatArray) -> Deployment:
        return self.deploy_with_mode(outputs, self.selection_deployment)

    def deploy_with_sample_keys(
        self, outputs: FloatArray, sample_keys: IntArray | None
    ) -> Deployment:
        return self.deploy_with_mode(outputs, self.selection_deployment, sample_keys)

    def receipt(self) -> dict[str, object]:
        return {
            "policy": "soft_radial_with_centered_log_barrier",
            "solver_in_forward_loop": False,
            "contraction": self.contraction,
            "contraction_scale": self.contraction_scale,
            "minimum_scale": self.minimum_scale,
            "alpha_start": self.alpha_start,
            "alpha_end": self.alpha_end,
            "schedule": self.schedule,
            "anneal_fraction": self.anneal_fraction,
            "training_checkpoint_selection_deployment": (
                self.checkpoint_selection_deployment
            ),
            "training_cost_scale": self.cost_scale,
            "barrier_inequality_count": self.inequality_count,
            "mu_start": (self.alpha_start * self.cost_scale / self.inequality_count),
            "mu_end": self.alpha_end * self.cost_scale / self.inequality_count,
            "barrier_scaling": "mu=alpha*training_cost_scale/inequality_count",
            "cost_scale_source": ("training-only median analytic-center regret"
                if self.barrier_cost_scaling == "training_center_regret" else "unit ablation"),
            "barrier_cost_scaling": self.barrier_cost_scaling,
            "report_guard_enabled": self.report_guard,
            "guard_safety_factor": self.guard_safety_factor,
            "guard_radius_policy": self.guard_radius_policy,
            "guard_floor_radius": self.guard_floor_radius,
            "geometry_interior_radius": self.geometry_interior_radius,
            "hessian_whitening": self.geometry.receipt.hessian_whitening,
            "selection_metric": (
                "validation hard regret"
                if self.checkpoint_selection_deployment == "hard_recovered"
                else "validation soft-policy regret"
            ),
            "hard_deployment": (
                "solve the registered hard LP/MILP under minus the centered "
                "log-barrier "
                "gradient at the learned Soft-Radial decision, after a "
                "positive infinity-norm rescaling that preserves its argmin"
            ),
            "training_problem_is_continuous_relaxation": bool(
                self.interface.problem.metadata.get("continuous_relaxation", False)
            ),
            "hard_deployment_integer_variable_count": int(
                np.sum(
                    cast(IntArray, self.deployment_interface.problem.integrality)
                )
            ),
            "report_chart": "rational_open_ball" if self.report_guard else "identity",
            "numerical_report_guard": "rational_open_ball" if self.report_guard else "none",  # legacy receipt key
            "maximum_effective_report_norm": self.maximum_report_norm,
            "kernel_backend": self.kernel_backend,
            "torch_device": str(self.training_device),
            "training_dtype": self.training_dtype,
            "report_chart_numerical_gap": self.report_chart_numerical_gap,
            **self.geometry.receipt_dict(),
        }

    def diagnostics(self, outputs: FloatArray) -> dict[str, float]:
        raw = np.asarray(outputs, dtype=np.float64)
        mapped, bounded, bound_scales = self._map(raw)
        if mapped.contractions is None:
            raise RuntimeError("Soft-Radial map omitted contraction values")
        energy, physical_barrier_gradient = (
            self.geometry.centered_barrier_value_and_physical_gradient(mapped)
        )
        normalized_slacks = 1.0 - (
            mapped.reduced_decisions @ self.geometry.normalized_inequalities_transpose
            if mapped.normalized_loads is None
            else mapped.normalized_loads
        )
        if np.any(normalized_slacks <= 0.0):
            raise OracleFailure("barrier diagnostic received nonpositive slack")
        raw_norms = np.linalg.norm(raw, axis=1)
        effective_norms = np.linalg.norm(bounded, axis=1)
        return {
            "mean_report_norm": float(raw_norms.mean()),
            "maximum_report_norm": float(raw_norms.max(initial=0.0)),
            "mean_effective_report_norm": float(effective_norms.mean()),
            "maximum_effective_report_norm": float(effective_norms.max(initial=0.0)),
            "minimum_report_guard_scale": float(bound_scales.min(initial=1.0)),
            "material_report_guard_activation_rate": float(
                np.mean(bound_scales < 0.99)
            ),
            "mean_contraction": float(mapped.contractions.mean()),
            "minimum_contraction": float(mapped.contractions.min(initial=1.0)),
            "maximum_contraction": float(mapped.contractions.max(initial=0.0)),
            "minimum_normalized_slack": float(normalized_slacks.min()),
            "p01_normalized_slack": float(np.quantile(normalized_slacks, 0.01)),
            "median_normalized_slack": float(np.median(normalized_slacks)),
            "mean_centered_barrier_energy": float(energy.mean()),
            "maximum_centered_barrier_energy": float(energy.max(initial=0.0)),
            "mean_recovered_cost_norm": float(
                np.linalg.norm(physical_barrier_gradient, axis=1).mean()
            ),
            "diagnostic_alpha": self.alpha,
            "diagnostic_mu": self.mu,
        }

    def close(self) -> None:
        self._hard_oracle.close()


class LogEnergyPolicyObjective:
    """Matched log-barrier policy objective in barrier-energy coordinates."""

    name = "log_energy_policy"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        mu_start: float | None = None,
        mu_end: float | None = None,
        alpha_start: float | None = None,
        alpha_end: float | None = None,
        schedule: str | None = None,
        anneal_fraction: float = 0.75,
        energy_guard: str = "uncapped",
        training_root_tolerance: float = 1e-6,
        evaluation_root_tolerance: float = 1e-8,
        matrix_backend: str = "auto",
        kernel_backend: str = "numpy",
        torch_device: str = "auto",
        training_physical_costs: FloatArray | None = None,
        training_target_values: FloatArray | None = None,
        workers: int = 1,
        random_seed: int = 0,
    ) -> None:
        self.interface = interface
        self.geometry = compile_policy_geometry(interface.problem)
        self.output_dimension = self.geometry.intrinsic_dimension
        if energy_guard not in {"exact", "uncapped", "legacy_capped"}:
            raise ValueError("unknown log-energy guard mode")
        self.energy_guard = cast(
            Literal["exact", "uncapped", "legacy_capped"], energy_guard
        )
        for tolerance, name in (
            (training_root_tolerance, "training_root_tolerance"),
            (evaluation_root_tolerance, "evaluation_root_tolerance"),
        ):
            if tolerance <= 0.0 or not np.isfinite(tolerance):
                raise ValueError(f"{name} must be finite and positive")
        if evaluation_root_tolerance > training_root_tolerance:
            raise ValueError(
                "evaluation_root_tolerance must not exceed the training tolerance"
            )
        if matrix_backend not in {"auto", "dense", "sparse"}:
            raise ValueError("matrix_backend must be auto, dense, or sparse")
        if kernel_backend not in {"auto", "numpy", "torch"}:
            raise ValueError("kernel_backend must be auto, numpy, or torch")
        if torch_device not in {"auto", "cpu", "cuda", "mps"}:
            raise ValueError("torch_device must be auto, cpu, cuda, or mps")
        self.training_root_tolerance = float(training_root_tolerance)
        self.evaluation_root_tolerance = float(evaluation_root_tolerance)
        self.matrix_backend = cast(Literal["auto", "dense", "sparse"], matrix_backend)
        if kernel_backend == "auto":
            resolved_kernel = "torch" if torch.cuda.is_available() else "numpy"
        else:
            resolved_kernel = kernel_backend
        self.kernel_backend = cast(Literal["numpy", "torch"], resolved_kernel)
        self.torch_training = self.kernel_backend == "torch"
        if self.torch_training:
            if torch_device == "auto":
                resolved_device = "cuda" if torch.cuda.is_available() else "cpu"
            else:
                resolved_device = torch_device
            if resolved_device == "cuda" and not torch.cuda.is_available():
                raise ValueError("CUDA was requested but is unavailable")
            if resolved_device == "mps":
                if not torch.backends.mps.is_available():
                    raise ValueError("MPS was requested but is unavailable")
                raise ValueError(
                    "MPS is not enabled because this experiment uses float64; "
                    "use CPU or CUDA"
                )
            self.training_device = torch.device(resolved_device)
        else:
            if torch_device not in {"auto", "cpu"}:
                raise ValueError(
                    "torch_device is only meaningful with the Torch kernel"
                )
            self.training_device = torch.device("cpu")
        self._torch_kernel = (
            TorchLogEnergyKernel(
                self.geometry,
                device=self.training_device,
            )
            if self.torch_training
            else None
        )

        using_alpha = alpha_start is not None or alpha_end is not None
        using_mu = mu_start is not None or mu_end is not None
        if using_alpha == using_mu:
            raise ValueError("specify exactly one of alpha or mu endpoints")
        self.alpha_start: float | None
        self.alpha_end: float | None
        self.cost_scale: float | None = None
        self.inequality_count = int(self.geometry.receipt.inequality_count)
        if self.inequality_count <= 0:
            raise ValueError("barrier objective requires at least one inequality")
        if using_alpha:
            if alpha_start is None:
                raise ValueError("alpha_start is required")
            if alpha_end is None:
                alpha_end = alpha_start
            if alpha_start < 0.0 or alpha_end < 0.0 or alpha_end > alpha_start:
                raise ValueError("require alpha_start >= alpha_end >= 0")
            if training_physical_costs is None or training_target_values is None:
                raise ValueError("alpha scaling requires the training split")
            self.cost_scale = _barrier_cost_scale(
                self.geometry,
                interface,
                training_physical_costs,
                training_target_values,
            )
            self.alpha_start = float(alpha_start)
            self.alpha_end = float(alpha_end)
            self.mu_start = self.alpha_start * self.cost_scale / self.inequality_count
            self.mu_end = self.alpha_end * self.cost_scale / self.inequality_count
            self.scale_parameterization = "dimensionless_alpha"
        else:
            if mu_start is None:
                raise ValueError("mu_start is required")
            if mu_end is None:
                mu_end = mu_start
            if mu_start <= 0.0 or mu_end <= 0.0 or mu_end > mu_start:
                raise ValueError("require mu_start >= mu_end > 0")
            self.alpha_start = None
            self.alpha_end = None
            self.mu_start = float(mu_start)
            self.mu_end = float(mu_end)
            self.scale_parameterization = "direct_mu"

        if schedule is None:
            schedule = "fixed" if self.mu_start == self.mu_end else "geometric"
        if schedule not in {"fixed", "geometric", "arithmetic"}:
            raise ValueError("schedule must be fixed, geometric, or arithmetic")
        if schedule == "fixed" and self.mu_start != self.mu_end:
            raise ValueError("fixed schedule requires equal endpoint weights")
        if schedule == "geometric" and (self.mu_start <= 0.0 or self.mu_end <= 0.0):
            raise ValueError("geometric schedule requires positive endpoint weights")
        if not 0.0 < anneal_fraction <= 1.0:
            raise ValueError("anneal_fraction must lie in (0, 1]")
        self.schedule = cast(Literal["fixed", "geometric", "arithmetic"], schedule)
        self.anneal_fraction = float(anneal_fraction)
        self.mu = self.mu_start
        self.selection_deployment: Literal["soft", "hard_recovered"] = "soft"
        self.checkpoint_selection_deployment: Literal["soft", "hard_recovered"] = "soft"
        self._frozen_mu: float | None = None
        self._hard_workers = int(workers)
        self._hard_random_seed = int(random_seed)
        self._hard_oracle = make_lp_oracle(
            interface.problem,
            workers=workers,
            random_seed=random_seed,
        )

    def _map(self, outputs: FloatArray, *, training: bool = False) -> PolicyBatch:
        return self.geometry.log_energy(
            np.asarray(outputs, dtype=np.float64),
            guard_mode=self.energy_guard,
            root_tolerance=(
                self.training_root_tolerance
                if training
                else self.evaluation_root_tolerance
            ),
            matrix_backend=self.matrix_backend,
        )

    def prepare_training_split(self, split: PreparedSplit) -> PreparedSplit:
        return _prepare_policy_cost_coordinates(split, self.geometry)

    def training_batch(self, split: PreparedSplit, indices: IntArray) -> TrainingBatch:
        return _policy_training_batch(split, indices)

    def set_epoch(self, epoch: int, total_epochs: int) -> None:
        if epoch <= 0 or total_epochs <= 0 or epoch > total_epochs:
            raise ValueError("epoch must lie in the declared training horizon")
        if self._frozen_mu is not None:
            self.mu = self._frozen_mu
            return
        if self.schedule == "fixed" or total_epochs == 1:
            progress = 1.0
        else:
            progress = min(
                (epoch - 1) / (self.anneal_fraction * (total_epochs - 1)),
                1.0,
            )
        if self.schedule == "geometric":
            self.mu = self.mu_start * (self.mu_end / self.mu_start) ** progress
        elif self.schedule == "arithmetic":
            self.mu = (1.0 - progress) * self.mu_start + progress * self.mu_end
        else:
            self.mu = self.mu_start

    def state(self) -> dict[str, float | str]:
        return {
            "mu": self.mu,
            "schedule": self.schedule,
            "energy_guard": self.energy_guard,
            "temperature_mode": (
                "scheduled" if self._frozen_mu is None else "fixed_continuation"
            ),
        }

    def set_checkpoint_selection_deployment(self, mode: str) -> None:
        if mode not in {"soft", "hard_recovered"}:
            raise ValueError("checkpoint deployment must be soft or hard_recovered")
        self.checkpoint_selection_deployment = cast(
            Literal["soft", "hard_recovered"], mode
        )

    def freeze_temperature(self, mu: float) -> None:
        if not np.isfinite(mu) or mu < 0.0:
            raise ValueError("fixed continuation temperature must be nonnegative")
        self._frozen_mu = float(mu)
        self.mu = self._frozen_mu

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        outputs = np.asarray(outputs, dtype=np.float64)
        mapped = self._map(outputs, training=True)
        if mapped.energy_targets is None or mapped.energy_target_gradients is None:
            raise RuntimeError("log-energy map omitted its energy certificate")
        decision_cost, reduced_cotangent = _policy_cost_and_reduced_cotangent(
            batch, mapped, self.geometry
        )
        regret = decision_cost - batch.target_values
        mapped_energy = mapped.energy_targets
        report_energy = 0.5 * np.sum(outputs**2, axis=1)
        if self.energy_guard == "legacy_capped":
            penalty_energy = mapped_energy
            penalty_gradient = mapped.energy_target_gradients
        else:
            # The uncapped quadratic makes the guarded extension coercive.
            # It is exactly the matched barrier energy whenever the guard is
            # inactive, including every report accepted by exact mode.
            penalty_energy = report_energy
            penalty_gradient = outputs
        barrier_contribution = self.mu * penalty_energy
        gradient = (
            self.geometry.log_energy_vjp_from_reduced(mapped, reduced_cotangent)
            + self.mu * penalty_gradient
        )
        return BatchSignal(
            regret + barrier_contribution,
            gradient,
            OracleStats(),
            mapped.decisions,
            components={
                "linear_regret": regret,
                "mapped_barrier_energy": mapped_energy,
                "report_energy": report_energy,
                "barrier_contribution": barrier_contribution,
            },
        )

    def torch_signal(
        self,
        outputs: torch.Tensor,
        physical_costs: torch.Tensor,
        target_values: torch.Tensor,
        policy_reduced_costs: torch.Tensor | None = None,
        policy_center_costs: torch.Tensor | None = None,
    ) -> TorchBatchSignal:
        """Evaluate the matched objective without leaving the Torch device."""

        if not self.torch_training or self._torch_kernel is None:
            raise RuntimeError("Torch training was not enabled for this objective")
        if (
            physical_costs.device != outputs.device
            or target_values.device != outputs.device
        ):
            raise ValueError("Torch objective tensors must share one device")
        mapped = self._torch_kernel.map(
            outputs,
            root_tolerance=self.training_root_tolerance,
            guard_mode=self.energy_guard,
        )
        if policy_reduced_costs is not None and policy_center_costs is not None:
            decision_cost = policy_center_costs + torch.sum(
                policy_reduced_costs * mapped.reduced_decisions,
                dim=1,
            )
        else:
            decision_cost = torch.sum(physical_costs * mapped.decisions, dim=1)
        regret = decision_cost - target_values
        report_energy = 0.5 * torch.sum(outputs.square(), dim=1)
        penalty_energy = (
            mapped.energy_targets
            if self.energy_guard == "legacy_capped"
            else report_energy
        )
        barrier_contribution = self.mu * penalty_energy
        return TorchBatchSignal(
            values=regret + barrier_contribution,
            stats=OracleStats(),
            decisions=mapped.decisions,
            components={
                "linear_regret": regret,
                "mapped_barrier_energy": mapped.energy_targets,
                "report_energy": report_energy,
                "barrier_contribution": barrier_contribution,
            },
        )

    def set_deployment_mode(self, mode: str) -> None:
        if mode not in {"soft", "hard_recovered"}:
            raise ValueError("deployment mode must be soft or hard_recovered")
        self.selection_deployment = cast(Literal["soft", "hard_recovered"], mode)

    def deploy_with_mode(
        self,
        outputs: FloatArray,
        mode: str,
        sample_keys: IntArray | None = None,
    ) -> Deployment:
        mapped = self._map(outputs, training=False)
        if mode == "soft":
            return Deployment(mapped.decisions, None, OracleStats())
        if mode != "hard_recovered":
            raise ValueError("deployment mode must be soft or hard_recovered")
        recovered_costs, solutions, self._hard_oracle = (
            _solve_decision_equivalent_costs(
                self.geometry.recovered_log_barrier_costs(
                    mapped,
                    mu=1.0,
                ),
                oracle=self._hard_oracle,
                interface=self.interface,
                workers=self._hard_workers,
                random_seed=self._hard_random_seed,
                sample_keys=sample_keys,
            )
        )
        return Deployment(
            solutions.decisions,
            recovered_costs,
            solutions.stats,
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        return self.deploy_with_mode(outputs, self.selection_deployment)

    def deploy_with_sample_keys(
        self, outputs: FloatArray, sample_keys: IntArray | None
    ) -> Deployment:
        return self.deploy_with_mode(outputs, self.selection_deployment, sample_keys)

    def receipt(self) -> dict[str, object]:
        return {
            "policy": "polyhedral_log_barrier_energy",
            "solver_in_forward_loop": False,
            "mu_start": self.mu_start,
            "mu_end": self.mu_end,
            "schedule": self.schedule,
            "anneal_fraction": self.anneal_fraction,
            "scale_parameterization": self.scale_parameterization,
            "alpha_start": self.alpha_start,
            "alpha_end": self.alpha_end,
            "training_cost_scale": self.cost_scale,
            "barrier_inequality_count": self.inequality_count,
            "energy_guard": self.energy_guard,
            "training_root_tolerance": self.training_root_tolerance,
            "evaluation_root_tolerance": self.evaluation_root_tolerance,
            "matrix_backend_requested": self.matrix_backend,
            "matrix_backend_resolved": self.geometry._resolve_matrix_backend(
                self.matrix_backend
            ),
            "kernel_backend": self.kernel_backend,
            "torch_device": str(self.training_device),
            "training_checkpoint_selection_deployment": (
                self.checkpoint_selection_deployment
            ),
            "matched_loss": (
                "physical_cost_plus_mu_times_uncapped_quadratic_report_energy"
                if self.energy_guard != "legacy_capped"
                else "legacy_physical_cost_plus_mu_times_capped_chart_energy"
            ),
            "numerical_energy_guard": {
                "exact": "none; fail beyond normalized-slack numerical chart",
                "uncapped": (
                    "direction-adaptive C1 forward tail; uncapped quadratic "
                    "report energy remains in the objective"
                ),
                "legacy_capped": (
                    "diagnostic direction-adaptive C1 tail with capped objective"
                ),
            }[self.energy_guard],
            "recovered_cost": (
                "negative mu times the centered physical log-barrier gradient, "
                "defined modulo equality-normal costs and positively "
                "infinity-norm rescaled before the hard LP solve"
            ),
            **self.geometry.receipt_dict(),
        }

    def diagnostics(self, outputs: FloatArray) -> dict[str, float]:
        outputs = np.asarray(outputs, dtype=np.float64)
        mapped = self._map(outputs, training=False)
        if (
            mapped.energy_targets is None
            or mapped.energy_caps is None
            or mapped.energy_guard_active is None
        ):
            raise RuntimeError("log-energy map omitted diagnostic certificates")
        energy = self.geometry._barrier_energy(mapped.reduced_decisions)
        target = mapped.energy_targets
        report_energy = 0.5 * np.sum(outputs**2, axis=1)
        normalized_slacks = (
            1.0 - mapped.reduced_decisions @ self.geometry.normalized_inequalities.T
        )
        recovered = self.geometry.recovered_log_barrier_costs(mapped, mu=self.mu)
        return {
            "mean_report_norm": float(np.linalg.norm(outputs, axis=1).mean()),
            "maximum_report_norm": float(
                np.linalg.norm(outputs, axis=1).max(initial=0.0)
            ),
            "energy_guard_activation_rate": float(np.mean(mapped.energy_guard_active)),
            "batched_root_iterations": float(mapped.energy_solver_iterations or 0),
            "mean_uncapped_report_energy": float(report_energy.mean()),
            "maximum_uncapped_report_energy": float(report_energy.max(initial=0.0)),
            "mean_mapped_barrier_energy": float(target.mean()),
            "minimum_energy_cap": float(mapped.energy_caps.min(initial=np.inf)),
            "maximum_target_to_cap_ratio": float(
                np.max(
                    np.divide(
                        target,
                        mapped.energy_caps,
                        out=np.zeros_like(target),
                        where=np.isfinite(mapped.energy_caps),
                    )
                )
            ),
            "minimum_normalized_slack": float(normalized_slacks.min()),
            "maximum_energy_identity_error": float(np.max(np.abs(energy - target))),
            "maximum_uncapped_to_mapped_energy_gap": float(
                np.max(report_energy - target, initial=0.0)
            ),
            "mean_recovered_physical_cost_norm": float(
                np.linalg.norm(recovered, axis=1).mean()
            ),
        }

    def close(self) -> None:
        self._hard_oracle.close()


class LogBarrierSmoothingObjective:
    """Direct decision-loss training on a fixed or geometrically annealed path."""

    name = "log_smoothing"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        mu_start: float,
        mu_end: float,
        workers: int,
        random_seed: int,
    ) -> None:
        if mu_start <= 0.0 or mu_end <= 0.0 or mu_end > mu_start:
            raise ValueError("require mu_start >= mu_end > 0")
        self.interface = interface
        self.mu_start = float(mu_start)
        self.mu_end = float(mu_end)
        self.mu = float(mu_start)
        self.output_dimension = interface.report_dimension
        self._barrier: LogBarrierOracle = make_log_barrier_oracle(
            interface.problem, mu=self.mu, workers=workers
        )
        self._lp = make_lp_oracle(
            interface.problem, workers=workers, random_seed=random_seed
        )

    def set_epoch(self, epoch: int, total_epochs: int) -> None:
        fraction = 1.0 if total_epochs <= 1 else (epoch - 1) / (total_epochs - 1)
        self.mu = self.mu_start * (self.mu_end / self.mu_start) ** fraction
        self._barrier.set_mu(self.mu)

    def state(self) -> dict[str, float]:
        return {"mu": self.mu}

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        outputs = np.asarray(outputs, dtype=np.float64)
        predicted_cost = self.interface.physical_cost(outputs)
        smoothed = self._barrier.solve_many(predicted_cost)
        regret = (
            np.sum(batch.physical_costs * smoothed.decisions, axis=1)
            - batch.target_values
        )
        gradients: list[FloatArray] = []
        for decision, true_cost in zip(
            smoothed.decisions, batch.physical_costs, strict=True
        ):
            inverse_product = self._barrier.geometry.inverse_tangent_product(
                decision, self.mu, true_cost
            )
            physical_gradient = -inverse_product
            gradients.append(physical_gradient @ self.interface.statistic.T)
        return BatchSignal(
            regret,
            np.stack(gradients),
            smoothed.stats,
            decisions=smoothed.decisions,
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        outputs = np.asarray(outputs, dtype=np.float64)
        solutions = self._lp.solve_many(self.interface.physical_cost(outputs))
        return Deployment(solutions.decisions, outputs, solutions.stats)

    def close(self) -> None:
        self._barrier.close()
        self._lp.close()
