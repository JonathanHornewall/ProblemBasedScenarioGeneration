"""Solver-free feasible policy charts for fixed bounded polytopes.

The expensive geometry is compiled once. Every subsequent forward and
vector-Jacobian product uses dense NumPy kernels; the log-energy chart solves
all scalar ray equations in one batched safeguarded Newton--bisection kernel.
Equalities are eliminated before any chart is built, so neural outputs live in
the intrinsic affine-hull dimension.
"""

from __future__ import annotations

import hashlib
import time
from collections import OrderedDict
from dataclasses import asdict, dataclass
from typing import Literal

import numpy as np
from scipy.linalg import solve
from scipy.optimize import brentq
from scipy.sparse import csc_matrix, csr_matrix

from .barrier import BarrierGeometry
from .oracles import OracleFailure
from .problem import FloatArray, LinearProblem

_GEOMETRY_CACHE: OrderedDict[str, PolyhedralPolicyGeometry] = OrderedDict()
_GEOMETRY_CACHE_CAPACITY = 32


@dataclass(frozen=True)
class GeometryReceipt:
    variable_dimension: int
    equality_count: int
    inequality_count: int
    intrinsic_dimension: int
    analytic_center_iterations: int
    analytic_center_convergence: str
    analytic_center_requested_tolerance: float
    analytic_center_projected_gradient_inf: float
    analytic_center_equality_residual_inf: float
    analytic_center_minimum_slack: float
    whitened_hessian_condition: float
    preprocessing_wall_seconds: float
    hessian_whitening: bool = True
    geometry_cache: dict | None = None


@dataclass(frozen=True)
class PolicyBatch:
    """Forward-pass values needed by exact custom VJPs."""

    reports: FloatArray
    reduced_decisions: FloatArray
    decisions: FloatArray
    scales: FloatArray
    active_rows: np.ndarray | None = None
    barrier_gradients: FloatArray | None = None
    contractions: FloatArray | None = None
    energy_targets: FloatArray | None = None
    energy_target_gradients: FloatArray | None = None
    energy_caps: FloatArray | None = None
    energy_guard_active: np.ndarray | None = None
    energy_solver_iterations: int | None = None
    report_norms: FloatArray | None = None
    energy_report_inner: FloatArray | None = None
    normalized_loads: FloatArray | None = None


@dataclass(frozen=True)
class PolyhedralPolicyGeometry:
    """Analytic-centred, Hessian-whitened polyhedral policy geometry."""

    center: FloatArray
    physical_map: FloatArray
    physical_map_transpose: FloatArray
    inequality_matrix: FloatArray
    normalized_inequalities: FloatArray
    normalized_inequalities_transpose: FloatArray
    center_slacks: FloatArray
    barrier_linear_term: FloatArray
    sparse_inequality_matrix: csr_matrix
    receipt: GeometryReceipt

    @property
    def intrinsic_dimension(self) -> int:
        return int(self.physical_map.shape[1])

    @classmethod
    def compile(
        cls,
        problem: LinearProblem,
        *,
        center_tolerance: float = 1e-8,
        maximum_center_iterations: int = 100,
        hessian_whitening: bool = True,
    ) -> PolyhedralPolicyGeometry:
        if not isinstance(hessian_whitening, bool):
            raise ValueError("hessian_whitening must be boolean")
        from .policy_geometry_cache import center_state
        started = time.perf_counter()
        state = center_state(problem, center_tolerance, maximum_center_iterations,
                             _compute_policy_center)
        a, meta = state["arrays"], state["metadata"]
        center, tangent = a["center"], a["tangent"]
        geometry = BarrierGeometry(a["equality_matrix"], a["equality_rhs"],
            a["inequality_matrix"], a["inequality_rhs"], tangent)
        reduced_matrix = geometry.inequality_matrix @ tangent
        iterations = meta["iterations"]
        projected_gradient_norm = meta["projected_gradient_norm"]
        center_convergence = meta["center_convergence"]
        slacks = geometry.slacks(center)
        inverse = 1.0 / slacks
        weighted = reduced_matrix * inverse[:, None]
        reduced_hessian = weighted.T @ weighted
        eigenvalues, eigenvectors = np.linalg.eigh(reduced_hessian)
        if float(eigenvalues.min(initial=np.inf)) <= 1e-12:
            raise OracleFailure("barrier Hessian is singular in the affine hull")
        inverse_root = (eigenvectors / np.sqrt(eigenvalues)) @ eigenvectors.T
        physical_map = tangent @ inverse_root if hessian_whitening else tangent
        normalized = (geometry.inequality_matrix @ physical_map) / slacks[:, None]
        barrier_linear = normalized.T @ np.ones(len(slacks))
        whitened_hessian = normalized.T @ normalized
        condition = float(np.linalg.cond(whitened_hessian))
        equality_residual = geometry.equality_matrix @ center - geometry.equality_rhs
        receipt = GeometryReceipt(
            variable_dimension=problem.variable_count,
            equality_count=len(geometry.equality_rhs),
            inequality_count=len(slacks),
            intrinsic_dimension=physical_map.shape[1],
            analytic_center_iterations=iterations,
            analytic_center_convergence=center_convergence,
            analytic_center_requested_tolerance=float(center_tolerance),
            analytic_center_projected_gradient_inf=projected_gradient_norm,
            analytic_center_equality_residual_inf=float(
                np.linalg.norm(equality_residual, ord=np.inf)
                if len(equality_residual)
                else 0.0
            ),
            analytic_center_minimum_slack=float(slacks.min()),
            whitened_hessian_condition=condition,
            preprocessing_wall_seconds=time.perf_counter() - started,
            hessian_whitening=hessian_whitening,
            geometry_cache=state.get("cache"),
        )
        return cls(
            center=np.ascontiguousarray(center),
            physical_map=np.ascontiguousarray(physical_map),
            physical_map_transpose=np.ascontiguousarray(physical_map.T),
            inequality_matrix=np.ascontiguousarray(geometry.inequality_matrix),
            normalized_inequalities=np.ascontiguousarray(normalized),
            normalized_inequalities_transpose=np.ascontiguousarray(normalized.T),
            center_slacks=np.ascontiguousarray(slacks),
            barrier_linear_term=np.ascontiguousarray(barrier_linear),
            sparse_inequality_matrix=csr_matrix(geometry.inequality_matrix),
            receipt=receipt,
        )

    def receipt_dict(self) -> dict[str, object]:
        return {"geometry": asdict(self.receipt)}

    def _validate_reports(self, reports: FloatArray) -> FloatArray:
        value = np.asarray(reports, dtype=np.float64)
        if value.ndim != 2 or value.shape[1] != self.intrinsic_dimension:
            raise ValueError("policy reports have the wrong shape")
        if not np.all(np.isfinite(value)):
            raise ValueError("policy reports contain non-finite values")
        return value

    def _physical(self, reduced: FloatArray) -> FloatArray:
        return self.center + reduced @ self.physical_map_transpose

    def _resolve_matrix_backend(
        self, backend: Literal["auto", "dense", "sparse"]
    ) -> Literal["dense", "sparse"]:
        if backend not in {"auto", "dense", "sparse"}:
            raise ValueError("matrix_backend must be auto, dense, or sparse")
        if backend != "auto":
            return backend
        # Whitening generally densifies the reduced constraint normals.  A
        # sparse factorization must first map through the dense physical chart,
        # so it needs a large arithmetic advantage before overcoming sparse
        # dispatch overhead.  None of the current benchmark geometries crosses
        # this deliberately conservative threshold.
        rows, variables = self.sparse_inequality_matrix.shape
        reduced = self.intrinsic_dimension
        dense_work = reduced * rows
        factorized_work = reduced * variables + self.sparse_inequality_matrix.nnz
        return "sparse" if 4 * factorized_work < dense_work else "dense"

    def _normalized_loads(
        self,
        reduced: FloatArray,
        *,
        backend: Literal["dense", "sparse"],
    ) -> FloatArray:
        if backend == "dense":
            return np.asarray(
                reduced @ self.normalized_inequalities_transpose,
                dtype=np.float64,
            )
        physical_directions = reduced @ self.physical_map_transpose
        raw_loads = physical_directions @ self.sparse_inequality_matrix.T
        return np.asarray(raw_loads, dtype=np.float64) / self.center_slacks

    def _normalized_gradient(
        self,
        weights: FloatArray,
        *,
        backend: Literal["dense", "sparse"],
    ) -> FloatArray:
        if backend == "dense":
            return np.asarray(
                weights @ self.normalized_inequalities,
                dtype=np.float64,
            )
        physical = (
            weights / self.center_slacks[None, :]
        ) @ self.sparse_inequality_matrix
        return np.asarray(physical @ self.physical_map, dtype=np.float64)

    @staticmethod
    def rationally_bound_reports(
        reports: FloatArray, *, maximum_norm: float
    ) -> tuple[FloatArray, FloatArray]:
        """Smoothly map arbitrary reports into a machine-safe open ball.

        The radial map ``u -> R u / (R + ||u||)`` is total, injective, and has
        polynomially decaying (rather than floating-point-saturating) radial
        derivatives.  It is used only as a numerical chart guard.
        """

        reports = np.asarray(reports, dtype=np.float64)
        if maximum_norm <= 0.0 or not np.isfinite(maximum_norm):
            raise ValueError("maximum_norm must be finite and positive")
        norms = np.linalg.norm(reports, axis=1)
        scales = maximum_norm / (maximum_norm + norms)
        return reports * scales[:, None], scales

    @staticmethod
    def rational_bound_vjp(
        reports: FloatArray, scales: FloatArray, cotangent: FloatArray
    ) -> FloatArray:
        """Exact VJP of :meth:`rationally_bound_reports`."""

        reports = np.asarray(reports, dtype=np.float64)
        scales = np.asarray(scales, dtype=np.float64)
        cotangent = np.asarray(cotangent, dtype=np.float64)
        if reports.shape != cotangent.shape or scales.shape != (len(reports),):
            raise ValueError("rational report-bound VJP shapes are incompatible")
        result = scales[:, None] * cotangent
        squared_norms = np.sum(reports**2, axis=1)
        nonzero = squared_norms > 0.0
        if np.any(nonzero):
            inner = np.sum(reports[nonzero] * cotangent[nonzero], axis=1)
            coefficient = (
                (scales[nonzero] ** 2 - scales[nonzero])
                * inner
                / squared_norms[nonzero]
            )
            result[nonzero] += coefficient[:, None] * reports[nonzero]
        return result

    def hard_radial(self, reports: FloatArray) -> PolicyBatch:
        """RAYEN's ray-to-boundary map with the interior left unchanged."""

        reports = self._validate_reports(reports)
        loads = reports @ self.normalized_inequalities_transpose
        active_rows = np.argmax(loads, axis=1)
        maximum_load = loads[np.arange(len(reports)), active_rows]
        scales = np.ones(len(reports), dtype=np.float64)
        outside = maximum_load > 1.0
        scales[outside] = 1.0 / maximum_load[outside]
        reduced = reports * scales[:, None]
        reduced_loads = loads * scales[:, None]
        return PolicyBatch(
            reports=reports,
            reduced_decisions=reduced,
            decisions=self._physical(reduced),
            scales=scales,
            active_rows=active_rows,
            normalized_loads=reduced_loads,
        )

    def hard_radial_vjp_from_reduced(
        self, batch: PolicyBatch, reduced_cotangent: FloatArray
    ) -> FloatArray:
        """Exact hard-radial VJP when the physical-map product is available."""

        cotangent = np.asarray(reduced_cotangent, dtype=np.float64)
        if cotangent.shape != batch.reports.shape or batch.active_rows is None:
            raise ValueError("radial VJP inputs have incompatible shapes")
        result = batch.scales[:, None] * cotangent
        outside = batch.scales < 1.0
        if np.any(outside):
            active = self.normalized_inequalities[batch.active_rows[outside]]
            inner = np.sum(batch.reports[outside] * cotangent[outside], axis=1)
            result[outside] -= (
                batch.scales[outside, None] ** 2 * active * inner[:, None]
            )
        return result

    def hard_radial_vjp(
        self, batch: PolicyBatch, physical_cotangent: FloatArray
    ) -> FloatArray:
        cotangent = np.asarray(physical_cotangent, dtype=np.float64)
        if cotangent.shape != batch.decisions.shape or batch.active_rows is None:
            raise ValueError("radial VJP inputs have incompatible shapes")
        reduced_cotangent = cotangent @ self.physical_map
        return self.hard_radial_vjp_from_reduced(batch, reduced_cotangent)

    @staticmethod
    def _contraction(
        squared_norm: FloatArray,
        *,
        family: Literal["rational", "exponential", "hyperbolic"],
        scale: float,
        minimum_scale: float,
    ) -> tuple[FloatArray, FloatArray]:
        rho = np.asarray(squared_norm, dtype=np.float64)
        if family == "rational":
            denominator = rho + scale
            value = minimum_scale + (1.0 - minimum_scale) * rho / denominator
            derivative = (1.0 - minimum_scale) * scale / denominator**2
        elif family == "exponential":
            exponential = np.exp(-rho / scale)
            value = minimum_scale + (1.0 - minimum_scale) * (1.0 - exponential)
            derivative = (1.0 - minimum_scale) * exponential / scale
        elif family == "hyperbolic":
            tangent = np.tanh(rho / scale)
            value = minimum_scale + (1.0 - minimum_scale) * tangent
            derivative = (1.0 - minimum_scale) * (1.0 - tangent**2) / scale
        else:
            raise ValueError(f"unknown Soft-Radial contraction {family!r}")
        return value, derivative

    def soft_radial(
        self,
        reports: FloatArray,
        *,
        family: Literal["rational", "exponential", "hyperbolic"],
        contraction_scale: float,
        minimum_scale: float,
    ) -> PolicyBatch:
        hard = self.hard_radial(reports)
        squared_norm = np.sum(hard.reports**2, axis=1)
        contraction, _ = self._contraction(
            squared_norm,
            family=family,
            scale=contraction_scale,
            minimum_scale=minimum_scale,
        )
        reduced = contraction[:, None] * hard.reduced_decisions
        if hard.normalized_loads is None:
            raise RuntimeError("hard-radial map omitted normalized loads")
        normalized_loads = contraction[:, None] * hard.normalized_loads
        normalized_slacks = 1.0 - normalized_loads
        if np.any(normalized_slacks <= 0.0):
            raise OracleFailure(
                "Soft-Radial contraction lost strict interior feasibility"
            )
        return PolicyBatch(
            reports=hard.reports,
            reduced_decisions=reduced,
            decisions=self._physical(reduced),
            scales=hard.scales,
            active_rows=hard.active_rows,
            contractions=contraction,
            normalized_loads=normalized_loads,
        )

    def soft_radial_vjp_from_reduced(
        self,
        batch: PolicyBatch,
        reduced_cotangent: FloatArray,
        *,
        family: Literal["rational", "exponential", "hyperbolic"],
        contraction_scale: float,
        minimum_scale: float,
    ) -> FloatArray:
        """Exact Soft-Radial VJP with a precomputed reduced cotangent."""

        if batch.contractions is None:
            raise ValueError("Soft-Radial batch lacks contraction values")
        reduced_cotangent = np.asarray(reduced_cotangent, dtype=np.float64)
        if reduced_cotangent.shape != batch.reports.shape:
            raise ValueError("reduced cotangent has an incompatible shape")
        hard_batch = PolicyBatch(
            reports=batch.reports,
            reduced_decisions=(batch.reduced_decisions / batch.contractions[:, None]),
            decisions=batch.decisions,
            scales=batch.scales,
            active_rows=batch.active_rows,
        )
        hard_vjp = self.hard_radial_vjp_from_reduced(hard_batch, reduced_cotangent)
        squared_norm = np.sum(batch.reports**2, axis=1)
        contraction, derivative = self._contraction(
            squared_norm,
            family=family,
            scale=contraction_scale,
            minimum_scale=minimum_scale,
        )
        hard_reduced = hard_batch.reduced_decisions
        inner = np.sum(hard_reduced * reduced_cotangent, axis=1)
        return (
            contraction[:, None] * hard_vjp
            + 2.0 * derivative[:, None] * batch.reports * inner[:, None]
        )

    def soft_radial_vjp(
        self,
        batch: PolicyBatch,
        physical_cotangent: FloatArray,
        *,
        family: Literal["rational", "exponential", "hyperbolic"],
        contraction_scale: float,
        minimum_scale: float,
    ) -> FloatArray:
        cotangent = np.asarray(physical_cotangent, dtype=np.float64)
        if cotangent.shape != batch.decisions.shape:
            raise ValueError("physical cotangent has an incompatible shape")
        reduced_cotangent = cotangent @ self.physical_map
        return self.soft_radial_vjp_from_reduced(
            batch,
            reduced_cotangent,
            family=family,
            contraction_scale=contraction_scale,
            minimum_scale=minimum_scale,
        )

    def _barrier_energy(self, reduced: FloatArray) -> FloatArray:
        loads = reduced @ self.normalized_inequalities_transpose
        slacks = 1.0 - loads
        if np.any(slacks <= 0.0):
            raise OracleFailure("log-energy point is not strictly feasible")
        # ``-log(1-load)-load`` is algebraically identical to subtracting the
        # analytic-center linear term, but remains accurate near the center.
        return self._energy_from_loads(loads)

    @staticmethod
    def _energy_from_loads(loads: FloatArray) -> FloatArray:
        """Evaluate centered barrier energy with one temporary allocation."""

        terms = np.log1p(-loads)
        terms += loads
        return -np.sum(terms, axis=1)

    def centered_barrier_value_and_physical_gradient(
        self, batch: PolicyBatch
    ) -> tuple[FloatArray, FloatArray]:
        """Evaluate the centered barrier and one physical-space gradient.

        The value uses the same analytic-center normalization as the
        log-energy chart.  Equality-normal components of the physical gradient
        are immaterial because the policy always lies in the compiled affine
        hull.
        """

        reduced = np.asarray(batch.reduced_decisions, dtype=np.float64)
        loads = (
            reduced @ self.normalized_inequalities_transpose
            if batch.normalized_loads is None
            else np.asarray(batch.normalized_loads, dtype=np.float64)
        )
        slacks = 1.0 - loads
        if np.any(slacks <= 0.0):
            raise OracleFailure("centered log barrier received nonpositive slack")
        values = self._energy_from_loads(loads)
        multipliers = loads / (self.center_slacks[None, :] * slacks)
        gradients = multipliers @ self.inequality_matrix
        if not np.all(np.isfinite(values)) or not np.all(np.isfinite(gradients)):
            raise OracleFailure("centered log barrier produced non-finite values")
        return values, gradients

    def centered_barrier_value_and_reduced_gradient(
        self, batch: PolicyBatch
    ) -> tuple[FloatArray, FloatArray]:
        """Centered barrier value and gradient in whitened affine coordinates."""

        loads = (
            batch.reduced_decisions @ self.normalized_inequalities_transpose
            if batch.normalized_loads is None
            else np.asarray(batch.normalized_loads, dtype=np.float64)
        )
        slacks = 1.0 - loads
        if np.any(slacks <= 0.0):
            raise OracleFailure("centered log barrier received nonpositive slack")
        values = self._energy_from_loads(loads)
        gradients = (loads / slacks) @ self.normalized_inequalities
        if not np.all(np.isfinite(values)) or not np.all(np.isfinite(gradients)):
            raise OracleFailure("centered log barrier produced non-finite values")
        return values, gradients

    def log_energy(
        self,
        reports: FloatArray,
        *,
        root_tolerance: float = 1e-8,
        maximum_iterations: int = 80,
        boundary_margin: float = 1e-8,
        safety_energy_gap: float = 0.1,
        guard_mode: Literal["exact", "uncapped", "legacy_capped"] = "uncapped",
        matrix_backend: Literal["auto", "dense", "sparse"] = "auto",
        compact_converged: bool = True,
        near_boundary_initialization: bool = True,
    ) -> PolicyBatch:
        """Map a batch through the log-energy chart without sample loops.

        The one-dimensional equation on each ray is solved simultaneously in
        log-slack coordinates by safeguarded Newton--bisection.  ``exact``
        rejects reports whose requested energy cannot be represented before
        the declared numerical boundary.  The two guarded modes use the same
        C1 forward extension; they differ only in the objective charged by
        :class:`LogEnergyPolicyObjective`.
        """

        if not 0.0 < boundary_margin < 1.0:
            raise ValueError("boundary_margin must lie between zero and one")
        if safety_energy_gap <= 0.0 or not np.isfinite(safety_energy_gap):
            raise ValueError("safety_energy_gap must be finite and positive")
        if maximum_iterations <= 0:
            raise ValueError("maximum_iterations must be positive")
        if root_tolerance <= 0.0 or not np.isfinite(root_tolerance):
            raise ValueError("root_tolerance must be finite and positive")
        if guard_mode not in {"exact", "uncapped", "legacy_capped"}:
            raise ValueError("unknown log-energy guard mode")
        resolved_backend = self._resolve_matrix_backend(matrix_backend)

        reports = self._validate_reports(reports)
        batch_size = len(reports)
        norms = np.linalg.norm(reports, axis=1)
        raw_targets = 0.5 * np.sum(reports**2, axis=1)
        reduced = np.zeros_like(reports)
        gradients = np.zeros_like(reports)
        scales = np.ones(batch_size, dtype=np.float64)
        targets = raw_targets.copy()
        target_gradients = reports.copy()
        caps = np.full(batch_size, np.inf, dtype=np.float64)
        guard_active = np.zeros(batch_size, dtype=bool)
        solver_iterations = 0

        # In the whitened chart E(u)=||u||^2/2+O(||u||^3).  Returning the
        # identity below this numerical radius is more accurate than solving a
        # nearly flat scalar equation and differs from the exact root only far
        # below the requested certificate tolerance.
        near_center = norms <= 1e-6
        if np.any(near_center):
            center_reports = reports[near_center]
            center_loads = self._normalized_loads(
                center_reports, backend=resolved_backend
            )
            center_slacks = 1.0 - center_loads
            if np.any(center_slacks <= 0.0):
                raise OracleFailure("log-energy center chart left the interior")
            reduced[near_center] = center_reports
            gradients[near_center] = self._normalized_gradient(
                center_loads / center_slacks,
                backend=resolved_backend,
            )

        away = ~near_center
        if np.any(away):
            away_reports = reports[away]
            away_norms = norms[away]
            directions = away_reports / away_norms[:, None]
            ray_loads_per_radius = self._normalized_loads(
                directions,
                backend=resolved_backend,
            )
            maximum_load = np.max(ray_loads_per_radius, axis=1)
            if np.any(maximum_load <= 0.0):
                raise OracleFailure("polytope is not radially bounded")
            boundaries = 1.0 / maximum_load
            maximum_log_gap = -float(np.log(boundary_margin))
            boundary_fraction = 1.0 - boundary_margin
            upper_radii = boundaries * boundary_fraction
            upper_loads = upper_radii[:, None] * ray_loads_per_radius
            upper_slacks = 1.0 - upper_loads
            if np.any(upper_slacks <= 0.0):
                raise OracleFailure("log-energy numerical boundary is infeasible")
            away_caps = self._energy_from_loads(upper_loads)
            if np.any(~np.isfinite(away_caps)) or np.any(away_caps <= 0.0):
                raise OracleFailure("log-energy direction has no finite energy cap")
            caps[away] = away_caps
            away_raw_targets = raw_targets[away]
            away_targets = away_raw_targets.copy()
            away_target_gradients = away_reports.copy()

            if guard_mode == "exact":
                if np.any(away_raw_targets > away_caps):
                    largest_excess = float(
                        np.max(away_raw_targets - away_caps, initial=0.0)
                    )
                    raise OracleFailure(
                        "exact log-energy report exceeds the numerical chart "
                        f"by {largest_excess:.6g} energy units"
                    )
            else:
                if np.any(away_caps <= safety_energy_gap):
                    raise OracleFailure(
                        "log-energy numerical cap is smaller than its safety gap"
                    )
                thresholds = away_caps - safety_energy_gap
                away_guard = away_raw_targets > thresholds
                if np.any(away_guard):
                    tails = away_raw_targets - thresholds
                    denominators = safety_energy_gap + tails
                    target_derivatives = (safety_energy_gap / denominators) ** 2
                    guarded_targets = (
                        thresholds + safety_energy_gap * tails / denominators
                    )
                    away_targets = np.where(away_guard, guarded_targets, away_targets)

                    upper_gradients = self._normalized_gradient(
                        upper_loads / upper_slacks,
                        backend=resolved_backend,
                    )
                    active_normals = self.normalized_inequalities[
                        np.argmax(ray_loads_per_radius, axis=1)
                    ]
                    radial_inner = np.sum(upper_gradients * directions, axis=1)
                    cap_direction_gradients = (
                        upper_radii[:, None] * upper_gradients
                        - (upper_radii**2 / boundary_fraction * radial_inner)[:, None]
                        * active_normals
                    )
                    cap_direction_gradients -= (
                        directions
                        * np.sum(directions * cap_direction_gradients, axis=1)[:, None]
                    )
                    cap_report_gradients = cap_direction_gradients / away_norms[:, None]
                    guarded_target_gradients = (
                        target_derivatives[:, None] * away_reports
                        + (1.0 - target_derivatives)[:, None] * cap_report_gradients
                    )
                    away_target_gradients = np.where(
                        away_guard[:, None],
                        guarded_target_gradients,
                        away_target_gradients,
                    )
                guard_active[away] = away_guard

            targets[away] = away_targets
            target_gradients[away] = away_target_gradients

            # Start at the report's natural radial scale.  Whitened barrier
            # geometry makes this an excellent initial guess near the center;
            # the certified bracket handles every other regime.
            initial_fraction = np.minimum(
                away_norms / boundaries,
                boundary_fraction,
            )
            log_gaps = -np.log1p(-initial_fraction)
            if near_boundary_initialization:
                boundary_limited = initial_fraction >= boundary_fraction
                if np.any(boundary_limited):
                    limited_coefficients = ray_loads_per_radius[boundary_limited]
                    limited_maximum = maximum_load[boundary_limited]
                    normalized_coefficients = (
                        limited_coefficients / limited_maximum[:, None]
                    )
                    dominant = normalized_coefficients >= 1.0 - 1e-7
                    regular_terms = np.zeros_like(normalized_coefficients)
                    regular = ~dominant
                    regular_coefficients = normalized_coefficients[regular]
                    regular_terms[regular] = (
                        -np.log1p(-regular_coefficients) - regular_coefficients
                    )
                    dominant_count = np.sum(dominant, axis=1)
                    estimates = (
                        1.0
                        + (
                            away_targets[boundary_limited]
                            - np.sum(regular_terms, axis=1)
                        )
                        / dominant_count
                    )
                    log_gaps[boundary_limited] = np.clip(
                        estimates,
                        1e-12,
                        maximum_log_gap,
                    )
            lower = np.zeros_like(log_gaps)
            upper = np.full_like(log_gaps, maximum_log_gap)
            converged = np.zeros_like(log_gaps, dtype=bool)
            active_indices: np.ndarray | None = None
            cached_loads: FloatArray | None = None
            cached_slacks: FloatArray | None = None
            cached_radii: FloatArray | None = None
            cached_values: FloatArray | None = None
            away_count = len(log_gaps)
            all_indices = np.arange(away_count, dtype=np.int64)

            for iteration in range(1, maximum_iterations + 1):
                solver_iterations = iteration
                indices = all_indices if active_indices is None else active_indices
                local_gaps = log_gaps[indices]
                local_boundaries = boundaries[indices]
                local_coefficients = ray_loads_per_radius[indices]
                local_targets = away_targets[indices]
                radii = local_boundaries * -np.expm1(-local_gaps)
                ray_loads = radii[:, None] * local_coefficients
                ray_slacks = 1.0 - ray_loads
                if np.any(ray_slacks <= 0.0):
                    raise OracleFailure("log-energy Newton iterate left its bracket")
                values = self._energy_from_loads(ray_loads)
                residuals = values - local_targets
                tolerances = root_tolerance * (1.0 + local_targets)
                newly_converged = np.abs(residuals) <= tolerances
                converged[indices[newly_converged]] = True
                if np.all(converged):
                    if len(indices) == away_count:
                        cached_radii = radii
                        cached_loads = ray_loads
                        cached_slacks = ray_slacks
                        cached_values = values
                    break

                unresolved_local = ~converged[indices]
                unresolved = indices[unresolved_local]
                unresolved_gaps = local_gaps[unresolved_local]
                unresolved_residuals = residuals[unresolved_local]
                negative = unresolved_residuals < 0.0
                lower[unresolved[negative]] = unresolved_gaps[negative]
                upper[unresolved[~negative]] = unresolved_gaps[~negative]
                unresolved_loads = ray_loads[unresolved_local]
                unresolved_slacks = ray_slacks[unresolved_local]
                unresolved_coefficients = local_coefficients[unresolved_local]
                unresolved_radii = radii[unresolved_local]
                radial_derivatives = np.sum(
                    unresolved_coefficients * unresolved_loads / unresolved_slacks,
                    axis=1,
                )
                log_gap_derivatives = radial_derivatives * (
                    boundaries[unresolved] - unresolved_radii
                )
                with np.errstate(divide="ignore", invalid="ignore"):
                    newton = (
                        unresolved_gaps - unresolved_residuals / log_gap_derivatives
                    )
                midpoint = 0.5 * (lower[unresolved] + upper[unresolved])
                # Merely lying inside the bracket is not enough: far from the
                # root, a Newton step can bounce between tiny neighborhoods of
                # the two endpoints without shrinking the interval. Reject a
                # step larger than half the certified bracket; this retains
                # quadratic convergence once the local model is reliable.
                bracket_width = upper[unresolved] - lower[unresolved]
                admissible = (
                    np.isfinite(newton)
                    & (newton > lower[unresolved])
                    & (newton < upper[unresolved])
                    & (np.abs(newton - unresolved_gaps) <= 0.5 * bracket_width)
                )
                candidates = np.where(admissible, newton, midpoint)
                log_gaps[unresolved] = candidates
                if compact_converged and away_count >= 64:
                    active_indices = unresolved
            else:
                raise OracleFailure("batched log-energy Newton iteration limit reached")

            if cached_radii is None:
                radii = boundaries * -np.expm1(-log_gaps)
                final_loads = radii[:, None] * ray_loads_per_radius
                final_slacks = 1.0 - final_loads
            else:
                radii = cached_radii
                if cached_loads is None or cached_slacks is None:
                    raise RuntimeError("incomplete log-energy root cache")
                final_loads = cached_loads
                final_slacks = cached_slacks
            final_values = (
                self._energy_from_loads(final_loads)
                if cached_values is None
                else cached_values
            )
            errors = np.abs(final_values - away_targets)
            if np.any(errors > root_tolerance * (1.0 + away_targets)):
                raise OracleFailure(
                    "log-energy root failed its reconstructed-energy certificate"
                )
            away_reduced = radii[:, None] * directions
            reduced[away] = away_reduced
            final_weights = final_loads / final_slacks
            gradients[away] = self._normalized_gradient(
                final_weights,
                backend=resolved_backend,
            )
            scales[away] = radii / away_norms

        energy_report_inner = np.sum(gradients * reports, axis=1)

        return PolicyBatch(
            reports=reports,
            reduced_decisions=reduced,
            decisions=self._physical(reduced),
            scales=scales,
            barrier_gradients=gradients,
            energy_targets=targets,
            energy_target_gradients=target_gradients,
            energy_caps=caps,
            energy_guard_active=guard_active,
            energy_solver_iterations=solver_iterations,
            report_norms=norms,
            energy_report_inner=energy_report_inner,
        )

    def log_energy_reference(
        self,
        reports: FloatArray,
        *,
        root_tolerance: float = 1e-8,
        maximum_iterations: int = 200,
        boundary_margin: float = 1e-8,
        safety_energy_gap: float = 0.1,
    ) -> PolicyBatch:
        """Map reports to equal barrier-energy points along center rays.

        The raw quadratic target is retained whenever it is safely below the
        direction-specific representable barrier energy. Only reports that
        would require a point beyond the chosen numerical feasibility margin
        enter a C1 rational tail. This avoids a global norm cap that would
        truncate legitimate low-temperature central paths.
        """

        if not 0.0 < boundary_margin < 1.0:
            raise ValueError("boundary_margin must lie between zero and one")
        if safety_energy_gap <= 0.0 or not np.isfinite(safety_energy_gap):
            raise ValueError("safety_energy_gap must be finite and positive")

        reports = self._validate_reports(reports)
        norms = np.linalg.norm(reports, axis=1)
        reduced = np.zeros_like(reports)
        gradients = np.zeros_like(reports)
        scales = np.ones(len(reports), dtype=np.float64)
        targets = np.zeros(len(reports), dtype=np.float64)
        target_gradients = np.zeros_like(reports)
        caps = np.full(len(reports), np.inf, dtype=np.float64)
        guard_active = np.zeros(len(reports), dtype=bool)
        for row_index, (report, norm) in enumerate(zip(reports, norms, strict=True)):
            # In whitened coordinates the centered barrier equals
            # ``||u||^2/2 + O(||u||^3)``.  Below this radius, a scalar root is
            # less accurate than the identity chart; the worst catalog error
            # at the threshold is below 1e-18.
            if norm <= 1e-6:
                reduced[row_index] = report
                point_loads = self.normalized_inequalities @ report
                point_slacks = 1.0 - point_loads
                gradients[row_index] = self.normalized_inequalities_transpose @ (
                    point_loads / point_slacks
                )
                targets[row_index] = 0.5 * norm**2
                target_gradients[row_index] = report
                continue
            direction = report / norm
            beta = self.normalized_inequalities @ direction
            maximum = float(beta.max(initial=-np.inf))
            if maximum <= 0.0:
                raise OracleFailure("polytope is not radially bounded")
            boundary = 1.0 / maximum
            raw_target = 0.5 * norm**2
            boundary_fraction = 1.0 - boundary_margin
            maximum_log_gap = -float(np.log(boundary_margin))

            def radius_from_log_gap(
                log_gap: float, ray_boundary: float = boundary
            ) -> float:
                return ray_boundary * -float(np.expm1(-log_gap))

            upper = radius_from_log_gap(maximum_log_gap)

            def value_derivative(
                radius: float,
                ray_coefficients: FloatArray = beta,
            ) -> tuple[float, float]:
                ray_loads = radius * ray_coefficients
                ray_slacks = 1.0 - ray_loads
                if np.any(ray_slacks <= 0.0):
                    return np.inf, np.inf
                value = float(self._energy_from_loads(ray_loads[None, :])[0])
                derivative = float(np.sum(ray_coefficients * ray_loads / ray_slacks))
                return value, derivative

            cap, _ = value_derivative(upper)
            if not np.isfinite(cap) or cap <= 0.0:
                raise OracleFailure("log-energy direction has no finite energy cap")
            if cap <= safety_energy_gap:
                raise OracleFailure(
                    "log-energy numerical cap is smaller than its safety gap"
                )
            caps[row_index] = cap
            identity_threshold = cap - safety_energy_gap
            if raw_target <= identity_threshold:
                target = raw_target
                target_gradient = report
            else:
                guard_active[row_index] = True
                tail = raw_target - identity_threshold
                denominator = safety_energy_gap + tail
                target_derivative = (safety_energy_gap / denominator) ** 2
                target = identity_threshold + safety_energy_gap * tail / denominator

                cap_point = upper * direction
                cap_loads = self.normalized_inequalities @ cap_point
                cap_slacks = 1.0 - cap_loads
                cap_gradient = self.normalized_inequalities_transpose @ (
                    cap_loads / cap_slacks
                )
                active_normal = self.normalized_inequalities[int(np.argmax(beta))]
                cap_direction_gradient = (
                    upper * cap_gradient
                    - (upper**2 / boundary_fraction)
                    * float(cap_gradient @ direction)
                    * active_normal
                )
                cap_report_gradient = (
                    cap_direction_gradient
                    - direction * float(direction @ cap_direction_gradient)
                ) / norm
                target_gradient = (
                    target_derivative * report
                    + (1.0 - target_derivative) * cap_report_gradient
                )
            targets[row_index] = target
            target_gradients[row_index] = target_gradient

            def root_residual(log_gap: float, target_energy: float = target) -> float:
                return value_derivative(radius_from_log_gap(log_gap))[0] - target_energy

            # A fixed bracket [0, -log(boundary_margin)] is badly scaled near
            # the analytic center: the root is O(||report||) while the upper
            # endpoint is O(10).  Start at the report's natural radial scale
            # and expand only when the barrier energy there is insufficient.
            initial_radius = min(norm, upper)
            initial_log_gap = -float(np.log1p(-initial_radius / boundary))
            lower_log_gap = 0.0
            upper_log_gap = initial_log_gap
            upper_residual = root_residual(upper_log_gap)
            if upper_residual < 0.0:
                lower_log_gap = upper_log_gap
                while upper_residual < 0.0 and upper_log_gap < maximum_log_gap:
                    next_log_gap = min(
                        maximum_log_gap,
                        max(2.0 * upper_log_gap, upper_log_gap + 1e-8),
                    )
                    if next_log_gap <= upper_log_gap:
                        break
                    upper_log_gap = next_log_gap
                    upper_residual = root_residual(upper_log_gap)
            if upper_residual < 0.0:
                raise OracleFailure("log-energy root is not bracketed")
            radius = float(
                radius_from_log_gap(
                    brentq(
                        root_residual,
                        lower_log_gap,
                        upper_log_gap,
                        xtol=1e-14,
                        rtol=1e-12,
                        maxiter=maximum_iterations,
                    ),
                )
            )
            point = radius * direction
            point_loads = self.normalized_inequalities @ point
            point_slacks = 1.0 - point_loads
            reduced[row_index] = point
            gradients[row_index] = self.normalized_inequalities_transpose @ (
                point_loads / point_slacks
            )
            scales[row_index] = radius / norm
            reconstructed_energy = float(self._barrier_energy(point[None, :])[0])
            if abs(reconstructed_energy - target) > root_tolerance * (1.0 + target):
                raise OracleFailure(
                    "log-energy root failed its reconstructed-energy certificate"
                )
        return PolicyBatch(
            reports=reports,
            reduced_decisions=reduced,
            decisions=self._physical(reduced),
            scales=scales,
            barrier_gradients=gradients,
            energy_targets=targets,
            energy_target_gradients=target_gradients,
            energy_caps=caps,
            energy_guard_active=guard_active,
        )

    def log_energy_vjp_from_reduced(
        self, batch: PolicyBatch, reduced_cotangent: FloatArray
    ) -> FloatArray:
        if batch.barrier_gradients is None or batch.energy_target_gradients is None:
            raise ValueError("log-energy batch lacks implicit-map gradients")
        reduced_cotangent = np.asarray(reduced_cotangent, dtype=np.float64)
        if reduced_cotangent.shape != batch.reports.shape:
            raise ValueError("log-energy VJP inputs have incompatible shapes")
        result = np.empty_like(reduced_cotangent)
        norms = (
            np.linalg.norm(batch.reports, axis=1)
            if batch.report_norms is None
            else batch.report_norms
        )
        near_center = norms <= 1e-6
        result[near_center] = reduced_cotangent[near_center]
        away = ~near_center
        if np.any(away):
            reports = batch.reports[away]
            gradients = batch.barrier_gradients[away]
            target_gradients = batch.energy_target_gradients[away]
            scales = batch.scales[away]
            vectors = reduced_cotangent[away]
            denominator = (
                np.sum(gradients * reports, axis=1)
                if batch.energy_report_inner is None
                else batch.energy_report_inner[away]
            )
            if np.any(denominator <= 0.0):
                raise OracleFailure("log-energy VJP has nonpositive denominator")
            inner = np.sum(reports * vectors, axis=1)
            result[away] = (
                scales[:, None] * vectors
                + (target_gradients - scales[:, None] * gradients)
                * (inner / denominator)[:, None]
            )
        return result

    def log_energy_vjp(
        self, batch: PolicyBatch, physical_cotangent: FloatArray
    ) -> FloatArray:
        cotangent = np.asarray(physical_cotangent, dtype=np.float64)
        if cotangent.shape != batch.decisions.shape:
            raise ValueError("log-energy VJP inputs have incompatible shapes")
        return self.log_energy_vjp_from_reduced(batch, cotangent @ self.physical_map)

    def recovered_log_barrier_costs(
        self, batch: PolicyBatch, *, mu: float
    ) -> FloatArray:
        """Return the decision-equivalent cost induced by the barrier gradient.

        The analytic-center gradient is subtracted.  At an exact constrained
        analytic center it lies in the equality-normal space, so this changes
        no feasible decision while making the identity with the centered
        numerical chart exact.
        """

        if mu < 0.0 or not np.isfinite(mu):
            raise ValueError("mu must be finite and nonnegative")
        normalized_slacks = (
            1.0 - batch.reduced_decisions @ self.normalized_inequalities_transpose
        )
        if np.any(normalized_slacks <= 0.0):
            raise OracleFailure("cannot recover a cost outside the interior")
        normalized_loads = 1.0 - normalized_slacks
        inverse_change = normalized_loads / (self.center_slacks * normalized_slacks)
        return -float(mu) * (inverse_change @ self.inequality_matrix)

    def maximum_primal_violation(
        self, problem: LinearProblem, decisions: FloatArray
    ) -> float:
        decisions = np.asarray(decisions, dtype=np.float64)
        activity = decisions @ problem.matrix.T
        return float(
            max(
                np.max(problem.variable_lower - decisions, initial=0.0),
                np.max(decisions - problem.variable_upper, initial=0.0),
                np.max(problem.row_lower - activity, initial=0.0),
                np.max(activity - problem.row_upper, initial=0.0),
            )
        )


def _compute_policy_center(problem, center_tolerance, maximum_center_iterations):
    if not problem.is_continuous:
        raise ValueError("feasible policy charts require a continuous polytope")
    # All chart geometry is invariant to positive row scaling.  Normalize
    # before analytic-centering so its numerical behavior is invariant too.
    problem = problem.row_normalized()
    started = time.perf_counter()
    geometry = BarrierGeometry.compile(problem)
    tangent = geometry.tangent_basis
    if tangent.shape[1] == 0:
        raise ValueError("feasible set has zero intrinsic dimension")
    if geometry.inequality_matrix.shape[0] == 0:
        raise ValueError("feasible policy charts require a bounded polytope")

    center = geometry.strictly_feasible_point()
    reduced_matrix = geometry.inequality_matrix @ tangent
    iterations = 0
    projected_gradient_norm = np.inf
    best_projected_gradient_norm = np.inf
    stalled_iterations = 0
    center_convergence = "requested_tolerance"
    for iteration in range(1, maximum_center_iterations + 1):
        iterations = iteration
        slacks = geometry.slacks(center)
        if np.any(slacks <= 0.0):
            raise OracleFailure("analytic-center iterate left the interior")
        inverse = 1.0 / slacks
        gradient = reduced_matrix.T @ inverse
        projected_gradient_norm = float(np.linalg.norm(gradient, ord=np.inf))
        if projected_gradient_norm <= center_tolerance:
            break
        if projected_gradient_norm < 0.999 * best_projected_gradient_norm:
            best_projected_gradient_norm = projected_gradient_norm
            stalled_iterations = 0
        else:
            stalled_iterations += 1
        # Some redundant bounded formulations reach the floating-point
        # floor of their Newton system just above the strict certificate.
        # The centered barrier below subtracts the gradient at the chosen
        # center exactly, so an interior point at this fallback tolerance
        # preserves the map and recovered-cost identity.
        if stalled_iterations >= 12 and projected_gradient_norm <= 1e-6:
            center_convergence = "floating_point_stagnation_fallback"
            break
        weighted = reduced_matrix * inverse[:, None]
        hessian = weighted.T @ weighted
        direction_reduced = solve(
            hessian, -gradient, assume_a="pos", check_finite=False
        )
        direction = tangent @ direction_reduced
        activity_direction = geometry.inequality_matrix @ direction
        positive = activity_direction > 0.0
        step = 1.0
        if np.any(positive):
            step = min(
                step,
                0.995
                * float(np.min(slacks[positive] / activity_direction[positive])),
            )
        current_value = -float(np.log(slacks).sum())
        directional_derivative = float(gradient @ direction_reduced)
        accepted = False
        for _ in range(60):
            candidate = center + step * direction
            candidate_slacks = geometry.slacks(candidate)
            if (
                np.all(candidate_slacks > 0.0)
                and -float(np.log(candidate_slacks).sum())
                <= current_value + 1e-4 * step * directional_derivative
            ):
                center = candidate
                accepted = True
                break
            step *= 0.5
        if not accepted:
            raise OracleFailure("analytic-center line search failed")
    else:
        raise OracleFailure("analytic-center Newton iteration limit reached")
    return {
        "arrays": {"center": center, "tangent": tangent,
                   "inequality_matrix": geometry.inequality_matrix,
                   "inequality_rhs": geometry.inequality_rhs,
                   "equality_matrix": geometry.equality_matrix,
                   "equality_rhs": geometry.equality_rhs},
        "metadata": {"iterations": iterations, "projected_gradient_norm": projected_gradient_norm,
                     "center_convergence": center_convergence,
                     "center_wall_seconds": time.perf_counter() - started},
    }


def _geometry_cache_key(problem: LinearProblem) -> str:
    digest = hashlib.sha256(b"polyhedral-policy-geometry-v1")
    matrix = csc_matrix(problem.matrix)
    digest.update(np.asarray(matrix.shape, dtype=np.int64).tobytes())
    for value in (
        matrix.data,
        matrix.indices,
        matrix.indptr,
        problem.row_lower,
        problem.row_upper,
        problem.variable_lower,
        problem.variable_upper,
        problem.integrality,
    ):
        array = np.ascontiguousarray(value)
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.view(np.uint8))
    return digest.hexdigest()


def compile_policy_geometry(problem: LinearProblem, *, hessian_whitening: bool = True) -> PolyhedralPolicyGeometry:
    """Reuse immutable geometry across processes when a disk cache is configured."""
    import os
    from .policy_geometry_cache import chart_geometry
    key = (_geometry_cache_key(problem), hessian_whitening,
           os.environ.get("CP_SPO_GEOMETRY_CACHE"),
           os.environ.get("CP_SPO_GEOMETRY_CACHE_READONLY"))
    cached = _GEOMETRY_CACHE.pop(key, None)
    if cached is not None:
        _GEOMETRY_CACHE[key] = cached
        return cached
    compiled = chart_geometry(problem, hessian_whitening)
    _GEOMETRY_CACHE[key] = compiled
    while len(_GEOMETRY_CACHE) > _GEOMETRY_CACHE_CAPACITY:
        _GEOMETRY_CACHE.popitem(last=False)
    return compiled
