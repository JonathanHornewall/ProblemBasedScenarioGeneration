"""One end-to-end Adam loop for all output-gradient objectives."""

from __future__ import annotations

import math
import time
from collections.abc import Callable
from dataclasses import asdict, dataclass
from typing import Any, cast

import numpy as np
import torch
from torch import nn

from .artifacts import RunRecorder, model_sha256
from .evaluation import EvaluationMetrics, evaluate_model
from .models import module_dtype
from .objectives import LearningObjective, PreparedSplit
from .oracles import OracleStats
from .seeds import derive_seed


@dataclass(frozen=True)
class TrainingSpec:
    epochs: int = 100
    schedule_reference_epochs: int | None = None
    batch_size: int = 64
    learning_rate: float = 1e-3
    weight_decay: float = 1e-5
    optimizer: str = "adamw"
    gradient_clip: float | None = 10.0
    validation_interval: int = 1
    patience: int = 20
    minimum_delta: float = 1e-7
    evaluation_batch_size: int = 512
    torch_threads: int = 4
    selection_mode: str = "validation_regret"
    learning_rate_schedule: str = "constant"
    minimum_learning_rate_ratio: float = 0.1
    warmup_fraction: float = 0.0
    validation_epochs: tuple[int, ...] | None = None
    gradient_diagnostic_interval: int = 1
    maximum_optimization_seconds: float | None = None

    def __post_init__(self) -> None:
        if self.epochs <= 0 or self.batch_size <= 0 or self.learning_rate <= 0:
            raise ValueError("epochs, batch size, and learning rate must be positive")
        if (
            self.schedule_reference_epochs is not None
            and self.schedule_reference_epochs < self.epochs
        ):
            raise ValueError(
                "schedule reference horizon must cover the training horizon"
            )
        if self.weight_decay < 0 or self.validation_interval <= 0 or self.patience <= 0:
            raise ValueError("invalid regularization/validation settings")
        if self.optimizer not in {"adam", "adamw"}:
            raise ValueError("optimizer must be adam or adamw")
        if self.selection_mode not in {"validation_regret", "last"}:
            raise ValueError("selection_mode must be validation_regret or last")
        if self.torch_threads <= 0:
            raise ValueError("torch_threads must be positive")
        if self.gradient_diagnostic_interval <= 0:
            raise ValueError("gradient_diagnostic_interval must be positive")
        if self.maximum_optimization_seconds is not None and (
            not math.isfinite(self.maximum_optimization_seconds)
            or self.maximum_optimization_seconds <= 0
        ):
            raise ValueError("maximum_optimization_seconds must be positive and finite")
        if self.learning_rate_schedule not in {
            "constant",
            "cosine",
            "warmup_cosine",
        }:
            raise ValueError("unknown learning-rate schedule")
        if not 0.0 < self.minimum_learning_rate_ratio <= 1.0:
            raise ValueError("minimum_learning_rate_ratio must lie in (0, 1]")
        if not 0.0 <= self.warmup_fraction < 1.0:
            raise ValueError("warmup_fraction must lie in [0, 1)")
        if self.learning_rate_schedule == "warmup_cosine" and self.warmup_fraction == 0:
            raise ValueError("warmup_cosine requires a positive warmup_fraction")
        if self.validation_epochs is not None:
            epochs = tuple(int(value) for value in self.validation_epochs)
            if any(value <= 0 or value > self.epochs for value in epochs):
                raise ValueError("validation epochs must lie in the training horizon")
            # Always observe the final trained model.  This preserves the
            # meaning of selection_mode=last even for a sparse explicit grid.
            object.__setattr__(
                self,
                "validation_epochs",
                tuple(sorted(set((*epochs, self.epochs)))),
            )


@dataclass(frozen=True)
class TrainingResult:
    best_epoch: int
    epochs_completed: int
    best_validation: EvaluationMetrics | None
    test: EvaluationMetrics | None
    training_wall_seconds: float
    training_cpu_seconds: float
    total_training_oracle_stats: OracleStats
    parameter_sha256: str
    trainable_parameters: int
    optimization_wall_seconds: float | None = None
    validation_wall_seconds: float | None = None
    test_evaluation_wall_seconds: float | None = None
    best_selection_score: float | None = None
    selection_metric: str = "unsmoothed_regret"
    optimization_cap_reached: bool = False
    optimization_cpu_seconds: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "best_epoch": self.best_epoch,
            "epochs_completed": self.epochs_completed,
            "best_validation": (
                None if self.best_validation is None else self.best_validation.to_dict()
            ),
            "test": None if self.test is None else self.test.to_dict(),
            "training_wall_seconds": self.training_wall_seconds,
            "training_cpu_seconds": self.training_cpu_seconds,
            "total_training_oracle_stats": asdict(self.total_training_oracle_stats),
            "parameter_sha256": self.parameter_sha256,
            "trainable_parameters": self.trainable_parameters,
            "optimization_wall_seconds": self.optimization_wall_seconds,
            "validation_wall_seconds": self.validation_wall_seconds,
            "test_evaluation_wall_seconds": self.test_evaluation_wall_seconds,
            "best_selection_score": self.best_selection_score,
            "selection_metric": self.selection_metric,
            "optimization_cap_reached": self.optimization_cap_reached,
            "optimization_cpu_seconds": self.optimization_cpu_seconds,
        }


def _optimizer(model: nn.Module, spec: TrainingSpec) -> torch.optim.Optimizer:
    parameters = [
        parameter for parameter in model.parameters() if parameter.requires_grad
    ]
    if not parameters:
        raise ValueError("model has no trainable parameters")
    cls = torch.optim.AdamW if spec.optimizer == "adamw" else torch.optim.Adam
    return cls(
        parameters,
        lr=spec.learning_rate,
        weight_decay=spec.weight_decay,
    )


def _schedule_horizon(spec: TrainingSpec) -> int:
    return spec.schedule_reference_epochs or spec.epochs


def _learning_rate_at_epoch(spec: TrainingSpec, epoch: int) -> float:
    """Return the epoch-level learning rate from a replayable schedule."""

    horizon = _schedule_horizon(spec)
    if spec.learning_rate_schedule == "constant" or horizon == 1:
        return spec.learning_rate
    minimum = spec.minimum_learning_rate_ratio
    if spec.learning_rate_schedule == "warmup_cosine":
        warmup_epochs = max(1, int(round(spec.warmup_fraction * horizon)))
        if epoch <= warmup_epochs:
            return spec.learning_rate * epoch / warmup_epochs
        progress = (epoch - warmup_epochs - 1) / max(
            1,
            horizon - warmup_epochs - 1,
        )
    else:
        progress = (epoch - 1) / max(1, horizon - 1)
    factor = minimum + (1.0 - minimum) * 0.5 * (1.0 + math.cos(math.pi * progress))
    return spec.learning_rate * factor


def _should_validate(spec: TrainingSpec, epoch: int) -> bool:
    if spec.validation_epochs is not None:
        return epoch in spec.validation_epochs
    return epoch % spec.validation_interval == 0 or epoch == spec.epochs


def train_model(
    *,
    model: nn.Module,
    objective: LearningObjective,
    train: PreparedSplit,
    validation: PreparedSplit | None,
    test: PreparedSplit | None,
    spec: TrainingSpec,
    shuffle_seed: int,
    recorder: RunRecorder,
    epoch_callback: Callable[[dict[str, Any]], None] | None = None,
    validation_scorer: Callable[
        [nn.Module, LearningObjective, PreparedSplit], tuple[float, dict[str, Any]]
    ]
    | None = None,
    selection_metric: str = "unsmoothed_regret",
    timing_only: bool = False,
    on_optimizer_ready: Callable[[], None] | None = None,
) -> TrainingResult:
    if timing_only and (
        validation is not None or test is not None or validation_scorer is not None
        or spec.selection_mode != "last" or spec.maximum_optimization_seconds is not None
    ):
        raise ValueError("Timing requires a frozen horizon and no evaluation inputs or optimizer cap")
    torch.set_num_threads(spec.torch_threads)
    training_device = getattr(objective, "training_device", torch.device("cpu"))
    if not isinstance(training_device, torch.device):
        training_device = torch.device(str(training_device))
    torch_training = bool(getattr(objective, "torch_training", False))
    model.to(training_device)
    model_dtype = module_dtype(model)
    optimizer = _optimizer(model, spec)
    trainable_parameters = [
        parameter for parameter in model.parameters() if parameter.requires_grad
    ]
    resident_contexts = (
        torch.as_tensor(
            train.contexts,
            dtype=model_dtype,
            device=training_device,
        )
        if torch_training
        else None
    )
    resident_physical_costs = (
        torch.as_tensor(
            train.physical_costs,
            dtype=model_dtype,
            device=training_device,
        )
        if torch_training
        else None
    )
    resident_target_values = (
        torch.as_tensor(
            train.target_values,
            dtype=model_dtype,
            device=training_device,
        )
        if torch_training
        else None
    )
    resident_target_decisions = (
        torch.as_tensor(train.target_decisions, dtype=model_dtype, device=training_device)
        if torch_training and getattr(objective, "requires_target_decisions", False)
        else None
    )
    resident_policy_reduced_costs = (
        torch.as_tensor(
            train.policy_reduced_costs,
            dtype=model_dtype,
            device=training_device,
        )
        if torch_training and train.policy_reduced_costs is not None
        else None
    )
    resident_policy_center_costs = (
        torch.as_tensor(
            train.policy_center_costs,
            dtype=model_dtype,
            device=training_device,
        )
        if torch_training and train.policy_center_costs is not None
        else None
    )
    best_state: dict[str, torch.Tensor] | None = None
    best_validation: EvaluationMetrics | None = None
    best_epoch = 0
    stale = 0
    total_stats = OracleStats()
    wall_started = time.perf_counter()
    cpu_started = time.process_time()
    epochs_completed = 0
    optimization_wall_seconds = 0.0
    optimization_cpu_seconds = 0.0
    validation_wall_seconds = 0.0
    test_evaluation_wall_seconds = 0.0
    best_selection_score = math.inf
    optimization_cap_reached = False

    def validation_check() -> tuple[float, EvaluationMetrics | None, dict[str, Any]]:
        assert validation is not None
        if validation_scorer is None:
            metrics = evaluate_model(
                model, objective, validation, batch_size=spec.evaluation_batch_size
            )
            return metrics.mean_regret, metrics, {"validation": metrics.to_dict()}
        score, details = validation_scorer(model, objective, validation)
        if not math.isfinite(score):
            raise RuntimeError("non-finite validation selection score")
        return score, None, {"validation_selection_details": details}

    try:
        if on_optimizer_ready is not None:
            on_optimizer_ready()
        if not timing_only:
            validation_started = time.perf_counter()
            initial_score, initial_metrics, initial_details = validation_check()
            initial_validation_wall_seconds = time.perf_counter() - validation_started
            validation_wall_seconds += initial_validation_wall_seconds
            best_validation = initial_metrics
            best_selection_score = initial_score
            best_epoch = 0
            best_state = {
                name: tensor.detach().cpu().clone()
                for name, tensor in model.state_dict().items()
            }
            recorder.append_curve(
                {
                    "epoch": 0,
                    **initial_details,
                    "selection_score": initial_score,
                    "selection_metric": selection_metric,
                    "validation_wall_seconds": initial_validation_wall_seconds,
                    "selected_so_far": True,
                    "initialization_checkpoint": True,
                }
            )
        for epoch in range(1, spec.epochs + 1):
            if timing_only:
                # Same timing boundary as the public trainer: epoch setup,
                # shuffle and every optimizer update; stop before reporting.
                epoch_started = time.perf_counter()
                epoch_cpu_started = time.process_time()
            epoch_learning_rate = _learning_rate_at_epoch(spec, epoch)
            for parameter_group in optimizer.param_groups:
                parameter_group["lr"] = epoch_learning_rate
            set_epoch = getattr(objective, "set_epoch", None)
            if set_epoch is not None:
                set_epoch(epoch, _schedule_horizon(spec))
            model.train()
            generator = np.random.Generator(
                np.random.PCG64(derive_seed(shuffle_seed, "epoch", epoch))
            )
            order = generator.permutation(len(train.contexts)).astype(np.int64)
            tensor_order = (
                torch.as_tensor(order, dtype=torch.int64, device=training_device)
                if torch_training
                else None
            )
            epoch_values: list[np.ndarray] = []
            epoch_components: dict[str, list[np.ndarray]] = {}
            output_gradient_norms: list[np.ndarray] = []
            parameter_gradient_norms: list[float] = []
            clipped_batches = 0
            batch_count = 0
            device_value_sum = torch.zeros(
                (), dtype=model_dtype, device=training_device
            )
            device_component_sums: dict[str, torch.Tensor] = {}
            device_output_norm_sum = torch.zeros(
                (), dtype=model_dtype, device=training_device
            )
            device_output_norm_max = torch.zeros(
                (), dtype=model_dtype, device=training_device
            )
            device_parameter_norm_sum = torch.zeros(
                (), dtype=model_dtype, device=training_device
            )
            device_parameter_norm_max = torch.zeros(
                (), dtype=model_dtype, device=training_device
            )
            device_clipped_batches = torch.zeros(
                (), dtype=torch.int64, device=training_device
            )
            device_sample_count = 0
            device_output_diagnostic_count = 0
            epoch_stats = OracleStats()
            if not timing_only:
                # Preserve the original campaign timer and cap semantics.
                epoch_started = time.perf_counter()
                epoch_cpu_started = time.process_time()
            for start in range(0, len(order), spec.batch_size):
                indices = order[start : start + spec.batch_size]
                if torch_training:
                    if (
                        resident_contexts is None
                        or resident_physical_costs is None
                        or resident_target_values is None
                    ):
                        raise RuntimeError("Torch training tensors were not prepared")
                    if tensor_order is None:
                        raise RuntimeError("Torch shuffle order was not prepared")
                    tensor_indices = tensor_order[start : start + len(indices)]
                    contexts = resident_contexts[tensor_indices]
                    batch_physical_costs = resident_physical_costs[tensor_indices]
                    batch_target_values = resident_target_values[tensor_indices]
                    batch_policy_reduced_costs = (
                        None
                        if resident_policy_reduced_costs is None
                        else resident_policy_reduced_costs[tensor_indices]
                    )
                    batch_policy_center_costs = (
                        None
                        if resident_policy_center_costs is None
                        else resident_policy_center_costs[tensor_indices]
                    )
                else:
                    contexts = torch.as_tensor(
                        train.contexts[indices], dtype=model_dtype
                    )
                outputs = model(contexts)
                optimizer.zero_grad(set_to_none=True)
                collect_output_diagnostic = (
                    batch_count % spec.gradient_diagnostic_interval == 0
                )
                if torch_training:
                    if collect_output_diagnostic:
                        outputs.retain_grad()
                    extra = ({"target_decisions": resident_target_decisions[tensor_indices]}
                             if resident_target_decisions is not None else {})
                    torch_signal = cast(Any, objective).torch_signal(
                        outputs,
                        batch_physical_costs,
                        batch_target_values,
                        batch_policy_reduced_costs,
                        batch_policy_center_costs,
                        **extra,
                    )
                    torch_signal.values.mean().backward()
                    device_value_sum += torch.sum(torch_signal.values.detach())
                    device_sample_count += len(indices)
                    if collect_output_diagnostic:
                        if outputs.grad is None:
                            raise RuntimeError(
                                "Torch objective did not produce output gradients"
                            )
                        output_gradient_tensor = outputs.grad.detach() * len(indices)
                        output_norms = torch.linalg.vector_norm(
                            output_gradient_tensor,
                            dim=1,
                        )
                        device_output_norm_sum += torch.sum(output_norms)
                        device_output_norm_max = torch.maximum(
                            device_output_norm_max,
                            torch.max(output_norms),
                        )
                        device_output_diagnostic_count += len(indices)
                    if torch_signal.components is not None:
                        for name, values in torch_signal.components.items():
                            component_sum = torch.sum(values.detach())
                            device_component_sums[name] = (
                                component_sum
                                if name not in device_component_sums
                                else device_component_sums[name] + component_sum
                            )
                    epoch_stats += torch_signal.stats
                else:
                    training_batch = getattr(objective, "training_batch", None)
                    batch = (
                        train.subset(indices)
                        if training_batch is None
                        else training_batch(train, indices)
                    )
                    signal = objective.signal(outputs.detach().cpu().numpy(), batch)
                    gradient = torch.as_tensor(
                        signal.output_gradient / len(indices),
                        dtype=outputs.dtype,
                        device=outputs.device,
                    )
                    outputs.backward(gradient=gradient)
                    output_gradient = signal.output_gradient
                    epoch_values.append(signal.values)
                    if signal.components is not None:
                        for name, values in signal.components.items():
                            epoch_components.setdefault(name, []).append(values)
                    epoch_stats += signal.stats
                    if collect_output_diagnostic:
                        output_gradient_norms.append(
                            np.linalg.norm(output_gradient, axis=1)
                        )
                if spec.gradient_clip is not None:
                    gradient_norm = torch.nn.utils.clip_grad_norm_(
                        trainable_parameters,
                        max_norm=spec.gradient_clip,
                    )
                    detached_gradient_norm = gradient_norm.detach().to(
                        device=training_device,
                        dtype=model_dtype,
                    )
                else:
                    squared = torch.zeros((), dtype=model_dtype, device=training_device)
                    for parameter in trainable_parameters:
                        if parameter.grad is not None:
                            squared += torch.sum(parameter.grad.detach().square())
                    detached_gradient_norm = torch.sqrt(squared)
                if torch_training:
                    device_parameter_norm_sum += detached_gradient_norm
                    device_parameter_norm_max = torch.maximum(
                        device_parameter_norm_max,
                        detached_gradient_norm,
                    )
                    if spec.gradient_clip is not None:
                        device_clipped_batches += (
                            detached_gradient_norm > spec.gradient_clip
                        ).to(torch.int64)
                else:
                    norm_value = float(detached_gradient_norm.cpu())
                    if (
                        spec.gradient_clip is not None
                        and norm_value > spec.gradient_clip
                    ):
                        clipped_batches += 1
                    parameter_gradient_norms.append(norm_value)
                batch_count += 1
                optimizer.step()
            if timing_only:
                epoch_optimization_wall = time.perf_counter() - epoch_started
                epoch_optimization_cpu = time.process_time() - epoch_cpu_started
            total_stats += epoch_stats
            epochs_completed = epoch
            if torch_training:
                if (
                    device_sample_count == 0
                    or device_output_diagnostic_count == 0
                    or batch_count == 0
                ):
                    raise RuntimeError("training epoch contained no samples")
                # This is the only routine device-to-host synchronization for
                # training diagnostics in an epoch.
                diagnostic_tensor = (
                    torch.stack(
                        (
                            device_value_sum / device_sample_count,
                            device_output_norm_sum / device_output_diagnostic_count,
                            device_output_norm_max,
                            device_parameter_norm_sum / batch_count,
                            device_parameter_norm_max,
                            device_clipped_batches.to(model_dtype) / batch_count,
                        )
                    )
                    .detach()
                    .cpu()
                )
                diagnostic_values = diagnostic_tensor.tolist()
                record = {
                    "epoch": epoch,
                    "learning_rate": epoch_learning_rate,
                    "train_surrogate_mean": diagnostic_values[0],
                    "epoch_wall_seconds": time.perf_counter() - epoch_started,
                    "training_oracle_stats": asdict(epoch_stats),
                    "mean_output_gradient_norm": diagnostic_values[1],
                    "maximum_output_gradient_norm": diagnostic_values[2],
                    "mean_parameter_gradient_norm": diagnostic_values[3],
                    "maximum_parameter_gradient_norm": diagnostic_values[4],
                    "gradient_clipped_batch_rate": diagnostic_values[5],
                    "output_gradient_diagnostic_batch_interval": (
                        spec.gradient_diagnostic_interval
                    ),
                    "output_gradient_diagnostic_sample_count": (
                        device_output_diagnostic_count
                    ),
                }
                if device_component_sums:
                    names = sorted(device_component_sums)
                    component_means = (
                        torch.stack(
                            [
                                device_component_sums[name] / device_sample_count
                                for name in names
                            ]
                        )
                        .detach()
                        .cpu()
                        .tolist()
                    )
                    record["train_surrogate_components"] = dict(
                        zip(names, component_means, strict=True)
                    )
            else:
                record = {
                    "epoch": epoch,
                    "learning_rate": epoch_learning_rate,
                    "train_surrogate_mean": float(
                        np.mean(np.concatenate(epoch_values))
                    ),
                    "epoch_wall_seconds": time.perf_counter() - epoch_started,
                    "training_oracle_stats": asdict(epoch_stats),
                    "mean_output_gradient_norm": float(
                        np.mean(np.concatenate(output_gradient_norms))
                    ),
                    "maximum_output_gradient_norm": float(
                        np.max(np.concatenate(output_gradient_norms))
                    ),
                    "mean_parameter_gradient_norm": float(
                        np.mean(parameter_gradient_norms)
                    ),
                    "maximum_parameter_gradient_norm": float(
                        np.max(parameter_gradient_norms)
                    ),
                    "gradient_clipped_batch_rate": (
                        0.0 if batch_count == 0 else clipped_batches / batch_count
                    ),
                    "output_gradient_diagnostic_batch_interval": (
                        spec.gradient_diagnostic_interval
                    ),
                    "output_gradient_diagnostic_sample_count": int(
                        sum(len(values) for values in output_gradient_norms)
                    ),
                }
                if epoch_components:
                    record["train_surrogate_components"] = {
                        name: float(np.mean(np.concatenate(values)))
                        for name, values in sorted(epoch_components.items())
                    }
            if timing_only:
                record["epoch_wall_seconds"] = epoch_optimization_wall
                record["epoch_optimization_cpu_seconds"] = epoch_optimization_cpu
            else:
                record["epoch_optimization_cpu_seconds"] = time.process_time() - epoch_cpu_started
            optimization_wall_seconds += float(record["epoch_wall_seconds"])
            optimization_cpu_seconds += record["epoch_optimization_cpu_seconds"]
            if timing_only:
                record["optimization_wall_seconds"] = optimization_wall_seconds
                record["optimization_cpu_seconds"] = optimization_cpu_seconds
            objective_state = getattr(objective, "state", None)
            if objective_state is not None:
                record["objective_state"] = objective_state()
            optimization_cap_reached = (
                spec.maximum_optimization_seconds is not None
                and optimization_wall_seconds >= spec.maximum_optimization_seconds
            )
            if not timing_only and (_should_validate(spec, epoch) or optimization_cap_reached):
                validation_started = time.perf_counter()
                score, metrics, details = validation_check()
                checkpoint_validation_wall_seconds = (
                    time.perf_counter() - validation_started
                )
                validation_wall_seconds += checkpoint_validation_wall_seconds
                record.update(details)
                record["selection_score"] = score
                record["selection_metric"] = selection_metric
                record["validation_wall_seconds"] = checkpoint_validation_wall_seconds
                improvement = spec.selection_mode == "last" or (
                    score < best_selection_score - spec.minimum_delta
                )
                if improvement:
                    best_validation = metrics
                    best_selection_score = score
                    best_epoch = epoch
                    best_state = {
                        name: tensor.detach().cpu().clone()
                        for name, tensor in model.state_dict().items()
                    }
                    stale = 0
                else:
                    stale += 1
                record["selected_so_far"] = improvement
            recorder.append_curve(record)
            if epoch_callback is not None:
                epoch_callback(record)
            if optimization_cap_reached:
                break
            if spec.selection_mode == "validation_regret" and stale >= spec.patience:
                break
        if timing_only:
            best_epoch = epochs_completed
        else:
            if best_state is None:
                raise RuntimeError("training ended without a validation evaluation")
            model.load_state_dict(best_state)
        if best_validation is None and not timing_only:
            assert validation is not None
            # Only the retained checkpoint is evaluated for the cross-mu gate.
            # This score never chooses its checkpoint or a within-mu candidate.
            validation_started = time.perf_counter()
            best_validation = evaluate_model(
                model, objective, validation, batch_size=spec.evaluation_batch_size
            )
            validation_wall_seconds += time.perf_counter() - validation_started
        if test is None:
            test_metrics = None
        else:
            test_started = time.perf_counter()
            test_metrics = evaluate_model(
                model, objective, test, batch_size=spec.evaluation_batch_size
            )
            test_evaluation_wall_seconds = time.perf_counter() - test_started
        model.to(torch.device("cpu"))
        result = TrainingResult(
            best_epoch=best_epoch,
            epochs_completed=epochs_completed,
            best_validation=best_validation,
            test=test_metrics,
            training_wall_seconds=time.perf_counter() - wall_started,
            training_cpu_seconds=time.process_time() - cpu_started,
            total_training_oracle_stats=total_stats,
            parameter_sha256=model_sha256(model),
            trainable_parameters=sum(
                parameter.numel()
                for parameter in model.parameters()
                if parameter.requires_grad
            ),
            optimization_wall_seconds=optimization_wall_seconds,
            validation_wall_seconds=validation_wall_seconds,
            test_evaluation_wall_seconds=test_evaluation_wall_seconds,
            best_selection_score=None if timing_only else best_selection_score,
            selection_metric="frozen_horizon_no_evaluation" if timing_only else selection_metric,
            optimization_cap_reached=optimization_cap_reached,
            optimization_cpu_seconds=optimization_cpu_seconds,
        )
        recorder.finish(result.to_dict())
        return result
    except BaseException as error:
        model.to(torch.device("cpu"))
        recorder.fail(error)
        raise
