"""Compact, incremental run receipts; no raw data or model weights."""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import time
from dataclasses import asdict, is_dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast

import numpy as np
import torch
from torch import nn


def _jsonable(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return _jsonable(asdict(cast(Any, value)))
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    return value


def write_json(path: Path, payload: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(_jsonable(payload), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


_ORACLE_STAT_FIELDS = (
    "calls",
    "iterations",
    "failures",
    "solver_seconds",
    "wall_seconds",
    "retries",
)


def with_pipeline_accounting(
    summary: dict[str, Any],
    *,
    nested_training_phases: list[tuple[str, dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    """Add auditable whole-pipeline cost totals to a run summary.

    Parent training summaries intentionally remain phase-local.  This derived
    view preserves them while making nested pretraining impossible to omit from
    headline wall-time or oracle-call accounting.
    """

    result = dict(summary)
    phases = [("main", summary), *(nested_training_phases or [])]
    combined_stats: dict[str, int | float] = {
        "calls": 0,
        "iterations": 0,
        "failures": 0,
        "solver_seconds": 0.0,
        "wall_seconds": 0.0,
        "retries": 0,
    }
    phase_receipts: list[dict[str, Any]] = []
    whole_wall = 0.0
    whole_cpu = 0.0
    for name, phase in phases:
        raw_stats = phase.get("total_training_oracle_stats", {})
        if not isinstance(raw_stats, dict):
            raise ValueError(f"training stats for phase {name!r} are malformed")
        for field in _ORACLE_STAT_FIELDS:
            value = raw_stats.get(field, 0)
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError(f"invalid {field} for phase {name!r}")
            combined_stats[field] += value
        wall = float(phase.get("training_wall_seconds", 0.0))
        cpu = float(phase.get("training_cpu_seconds", 0.0))
        whole_wall += wall
        whole_cpu += cpu
        phase_receipts.append(
            {
                "name": name,
                "training_wall_seconds": wall,
                "training_cpu_seconds": cpu,
                "total_training_oracle_stats": {
                    field: raw_stats.get(field, 0) for field in _ORACLE_STAT_FIELDS
                },
            }
        )
    result["training_phases"] = phase_receipts
    result["whole_pipeline_training_wall_seconds"] = whole_wall
    result["whole_pipeline_training_cpu_seconds"] = whole_cpu
    result["whole_pipeline_training_oracle_stats"] = combined_stats
    return result


def source_sha256(repo_root: Path) -> str:
    """Hash executable project inputs without including run artefacts."""

    candidates = [repo_root / "pyproject.toml", repo_root / "uv.lock"]
    candidates.extend(sorted((repo_root / "src").rglob("*.py")))
    candidates.extend(sorted((repo_root / "scripts").glob("*.py")))
    digest = hashlib.sha256()
    for path in candidates:
        if not path.is_file():
            continue
        digest.update(str(path.relative_to(repo_root)).encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def environment_receipt(repo_root: Path) -> dict[str, Any]:
    packages: dict[str, str] = {}
    for package in (
        "numpy",
        "scipy",
        "torch",
        "osqp",
        "clarabel",
        "highspy",
        "cvxpy",
        "cvxpylayers",
        "diffcp",
    ):
        try:
            packages[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            packages[package] = "not-installed"
    try:
        commit = subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_root,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        commit = "uncommitted"
    try:
        dirty = bool(
            subprocess.check_output(
                ["git", "status", "--porcelain"],
                cwd=repo_root,
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip()
        )
    except (OSError, subprocess.CalledProcessError):
        dirty = True
    return {
        "captured_at_utc": datetime.now(UTC).isoformat(),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpu_count": os.cpu_count(),
        "torch_threads": torch.get_num_threads(),
        "packages": packages,
        "git_commit": commit,
        "git_dirty": dirty,
        "source_sha256": source_sha256(repo_root),
    }


def model_sha256(model: nn.Module) -> str:
    digest = hashlib.sha256()
    for name, tensor in sorted(model.state_dict().items()):
        digest.update(name.encode("utf-8"))
        digest.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


class RunRecorder:
    def __init__(
        self, directory: Path, *, config: dict[str, Any], repo_root: Path,
        curve_fsync_policy: str = "row", curve_fsync_interval_seconds: float = 60.0,
        record_io_timing: bool = False,
    ) -> None:
        if curve_fsync_policy not in {"row", "validation"}:
            raise ValueError("curve_fsync_policy must be row or validation")
        if curve_fsync_interval_seconds <= 0:
            raise ValueError("curve fsync interval must be positive")
        initialized = time.perf_counter() if record_io_timing else None
        self._curve_fsync_policy = curve_fsync_policy
        self._curve_fsync_interval_seconds = curve_fsync_interval_seconds
        self._record_io_timing = record_io_timing
        self._curve_stream = None
        self._curve_last_sync = None
        self.curve_persistence_errors = []
        self._io = {"initialization_wall_seconds": 0.0,
            "append_total_wall_seconds": 0.0, "fsync_wall_seconds": 0.0,
            "terminal_total_wall_seconds": 0.0, "curve_rows": 0, "fsync_calls": 0}
        self.directory = directory
        directory.mkdir(parents=True, exist_ok=False)
        self.curve_path = directory / "learning_curve.jsonl"
        write_json(directory / "config.json", config)
        write_json(directory / "environment.json", environment_receipt(repo_root))
        write_json(
            directory / "status.json",
            {
                "status": "running",
                "started_at_utc": datetime.now(UTC).isoformat(),
            },
        )
        if initialized is not None:
            self._io["initialization_wall_seconds"] = time.perf_counter() - initialized

    def append_curve(self, record: dict[str, Any]) -> None:
        started = time.perf_counter() if self._record_io_timing else None
        try:
            if self._curve_fsync_policy == "row":
                # Preserve the default legacy durability and exact JSONL bytes.
                with self.curve_path.open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps(_jsonable(record), sort_keys=True) + "\n")
                    stream.flush()
                    os.fsync(stream.fileno())
            else:
                now = time.perf_counter()
                if self._curve_stream is None:
                    self._curve_stream = self.curve_path.open("a", encoding="utf-8")
                    self._curve_last_sync = now
                self._curve_stream.write(json.dumps(_jsonable(record), sort_keys=True) + "\n")
                if (record.get("selection_score") is not None or record.get("validation") is not None
                    or now - self._curve_last_sync >= self._curve_fsync_interval_seconds):
                    self.flush_curve()
            if self._record_io_timing:
                self._io["curve_rows"] += 1
        finally:
            if started is not None:
                self._io["append_total_wall_seconds"] += time.perf_counter() - started

    def flush_curve(self, *, close: bool = False) -> None:
        """Make buffered rows durable before a validation/terminal boundary."""
        stream = self._curve_stream
        if stream is None:
            return
        started = time.perf_counter() if self._record_io_timing else None
        original_error = None
        try:
            stream.flush()
            os.fsync(stream.fileno())
            self._curve_last_sync = time.perf_counter()
            if self._record_io_timing:
                self._io["fsync_calls"] += 1
        except Exception as error:
            original_error = error
            self.curve_persistence_errors.append({"operation": "curve_flush_fsync",
                "error_type": type(error).__name__, "error": str(error)})
            raise
        finally:
            if started is not None:
                self._io["fsync_wall_seconds"] += time.perf_counter() - started
            if close:
                try:
                    stream.close()
                except Exception as error:
                    self.curve_persistence_errors.append({"operation": "curve_close",
                        "error_type": type(error).__name__, "error": str(error)})
                    if original_error is None:
                        raise
                finally:
                    self._curve_stream = None

    def io_accounting(self) -> dict[str, Any]:
        return {"curve_fsync_policy": self._curve_fsync_policy,
            "maximum_sync_interval_seconds": self._curve_fsync_interval_seconds,
            **self._io,
            "persistence_errors": list(self.curve_persistence_errors),
            "interval_scope": "evaluated when append callbacks run; no asynchronous training timer",
            "hierarchy": "append_total and terminal_total include their nested fsync time; do not add fsync again"}

    def start_phase(self, phase: str) -> None:
        """Mark a post-training phase as active before doing fallible work."""

        if not phase:
            raise ValueError("phase must be nonempty")
        write_json(
            self.directory / "status.json",
            {
                "status": "running",
                "phase": phase,
                "phase_started_at_utc": datetime.now(UTC).isoformat(),
            },
        )

    def finish(self, summary: dict[str, Any]) -> None:
        started = time.perf_counter() if self._record_io_timing else None
        try:
            self.flush_curve(close=True)
            write_json(self.directory / "summary.json", summary)
            write_json(
                self.directory / "status.json",
                {"status": "complete", "finished_at_utc": datetime.now(UTC).isoformat()},
            )
        finally:
            if started is not None:
                self._io["terminal_total_wall_seconds"] += time.perf_counter() - started

    def fail(self, error: BaseException) -> None:
        started = time.perf_counter() if self._record_io_timing else None
        try:
            try:
                self.flush_curve(close=True)
            except Exception:
                if self._curve_fsync_policy != "validation":
                    raise
                # Keep the original training error; captured persistence errors
                # are also carried into the outer terminal fit receipt.
            write_json(
                self.directory / "status.json",
                {"status": "failed", "failed_at_utc": datetime.now(UTC).isoformat(),
                 "error_type": type(error).__name__, "error": str(error)},
            )
        finally:
            if started is not None:
                self._io["terminal_total_wall_seconds"] += time.perf_counter() - started
