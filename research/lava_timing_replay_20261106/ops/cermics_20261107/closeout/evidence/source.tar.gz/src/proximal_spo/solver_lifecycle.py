"""Instrumented LP lifecycle factor for the matched public-loss ablation.

The installed PyEPO algorithms are unchanged. Only native HiGHS ownership and
reset policy vary. Existing campaign adapters and running snapshots are intact.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from functools import wraps
import hashlib
import time
from types import MethodType
import weakref

import highspy
import numpy as np

from .oracles import _highs_lp
from .public_highs import HighsOptModel, dispose_highs_model

MODES = ("persistent_basis", "persistent_clear", "rebuild")
NATIVE_EVENTS = (
    "model_create", "model_options", "model_load", "model_dispose",
    "solver_reset", "objective_update", "solve", "solution_extract",
)


class LifecycleTelemetry:
    """Aggregate clocks only; no per-call files, basis copies, or RNG calls."""

    def __init__(self):
        self.phase = "preprocessing"
        self.events = defaultdict(lambda: defaultdict(Counter))
        self.logical_solves = Counter()
        self.iterations = Counter()
        self.models = weakref.WeakSet()

    def call(self, event, function, *args, **kwargs):
        phase = self.phase
        wall, cpu = time.perf_counter_ns(), time.process_time_ns()
        failed = False
        try:
            return function(*args, **kwargs)
        except BaseException:
            failed = True
            raise
        finally:
            elapsed_cpu = time.process_time_ns() - cpu
            elapsed_wall = time.perf_counter_ns() - wall
            bucket = self.events[phase][event]
            bucket.update(calls=1, failures=int(failed), wall_ns=elapsed_wall,
                          cpu_ns=elapsed_cpu)

    def close(self):
        self.phase = "finalization"
        for model in list(self.models):
            model.close()

    def receipt(self, optimization_wall=None, optimization_cpu=None):
        phases = {
            phase: {
                event: {"calls": value["calls"], "failures": value["failures"],
                        "wall_seconds": value["wall_ns"] / 1e9,
                        "cpu_seconds": value["cpu_ns"] / 1e9}
                for event, value in events.items()
            }
            for phase, events in self.events.items()
        }
        native = {
            clock: sum(phases.get("optimization", {}).get(event, {}).get(clock, 0.)
                       for event in NATIVE_EVENTS)
            for clock in ("wall_seconds", "cpu_seconds")
        }
        residual = {
            "wall_seconds": None if optimization_wall is None else
                optimization_wall - native["wall_seconds"],
            "cpu_seconds": None if optimization_cpu is None else
                optimization_cpu - native["cpu_seconds"],
            "label": "All other optimization work, including neural/autograd, Python, "
                     "NCE pool scoring and instrumentation; not an isolated pool timer",
        }
        return {"schema": "solver_lifecycle_telemetry_v1", "phases": phases,
                "logical_solve_calls_by_phase": dict(self.logical_solves),
                "simplex_iterations_by_phase": dict(self.iterations),
                "native_training_oracle_total": native,
                "other_optimization_residual": residual,
                "clock": "perf_counter_ns and process_time_ns, aggregate totals",
                "timing_hierarchy": "Native events are mutually exclusive. Public loss "
                    "forward includes native events, and pool_update is inside forward; "
                    "do not sum those overlapping counters with native totals.",
                "basis_introspection_in_fit": False}


class LifecycleHighsOptModel(HighsOptModel):
    """Same continuous model/options/costs; explicit native lifecycle factor."""

    def __init__(self, source, *, mode, telemetry=None, robust=False, presolve=True):
        if mode not in MODES:
            raise ValueError("Unregistered solver lifecycle mode")
        if not source.is_continuous:
            raise ValueError("Solver lifecycle ablation permits continuous LPs only")
        self.mode = mode
        self.telemetry = telemetry if telemetry is not None else LifecycleTelemetry()
        self.robust = robust
        self.recovery_counts = dict(cold_retries=0, scaled_retries=0,
                                    unrecovered=0, unknown_status_retries=0)
        super().__init__(source, presolve=presolve)
        self.telemetry.models.add(self)
        if mode == "rebuild":
            # Establish PyEPO's variable interface, as the existing cold adapter
            # does, but carry no native model into the first optimization call.
            self.close()

    def _getModel(self):
        model = self.telemetry.call("model_create", highspy.Highs)
        options = {
            "output_flag": False, "threads": 1, "random_seed": 0,
            "primal_feasibility_tolerance": 1e-8,
            "dual_feasibility_tolerance": 1e-8,
            "mip_feasibility_tolerance": 1e-8,
            "mip_rel_gap": 0.0, "mip_abs_gap": 0.0,
            "presolve": "on" if self.presolve else "off", "solver": "simplex",
        }

        def configure():
            for key, value in options.items():
                if model.setOptionValue(key, value) != highspy.HighsStatus.kOk:
                    raise RuntimeError(f"HiGHS rejected option {key}")

        def load():
            if model.passModel(_highs_lp(self.source)) != highspy.HighsStatus.kOk:
                raise RuntimeError("HiGHS rejected the public benchmark model")

        try:
            self.telemetry.call("model_options", configure)
            self.telemetry.call("model_load", load)
        except BaseException:
            self.telemetry.call("model_dispose", dispose_highs_model, model)
            raise
        return model, np.arange(self.source.variable_count, dtype=np.int32)

    def _apply_cost(self, cost):
        status = self.telemetry.call("objective_update", self._model.changeColsCost,
                                     self.num_cost, self.x, cost)
        if status != highspy.HighsStatus.kOk:
            raise RuntimeError("HiGHS rejected an objective update")

    def setObj(self, c):
        cost = np.asarray(c, dtype=np.float64)
        if cost.shape != (self.num_cost,) or not np.isfinite(cost).all():
            raise ValueError("Cost vector has invalid shape or nonfinite entries")
        self._cost = cost.copy()
        if self._model is not None:
            self._apply_cost(self._cost)

    def _reset(self):
        status = self.telemetry.call("solver_reset", self._model.clearSolver)
        if status != highspy.HighsStatus.kOk:
            raise RuntimeError("HiGHS rejected clearSolver")

    def _run(self):
        self.solve_count += 1
        return self.telemetry.call("solve", self._model.run)

    def _extract(self):
        def extract():
            solution = np.asarray(self._model.getSolution().col_value, dtype=np.float64)
            info = self._model.getInfo()
            self.telemetry.iterations[self.telemetry.phase] += max(
                0, int(info.simplex_iteration_count))
            return solution, info
        return self.telemetry.call("solution_extract", extract)

    def _base_solve(self):
        if self.mode == "persistent_clear":
            self._reset()
        status = self._run()
        if self._model.getModelStatus() == highspy.HighsModelStatus.kUnknown:
            self.recovery_counts["unknown_status_retries"] += 1
            self._reset()
            status = self._run()
        if (status == highspy.HighsStatus.kError
                or self._model.getModelStatus() != highspy.HighsModelStatus.kOptimal):
            raise RuntimeError("HiGHS failed: " + self._model.modelStatusToString(
                self._model.getModelStatus()))
        solution, _ = self._extract()
        # Keep PyEPO1.0.2's expected list/float32 pool construction semantics.
        return solution.tolist(), float(self._cost @ solution)

    def _replace(self, cost):
        self.close()
        self._model, self.x = self._getModel()
        return self.telemetry.call("objective_update", self._model.changeColsCost,
                                   self.num_cost, self.x, cost)

    def solve(self):
        self.telemetry.logical_solves[self.telemetry.phase] += 1
        try:
            if self._model is None:
                self._model, self.x = self._getModel()
                self._apply_cost(self._cost)
            try:
                return self._base_solve()
            except RuntimeError as initial:
                if not self.robust:
                    raise
                # Preserve NCE's ordered independent cold and positive-cost-
                # scaled recovery. Every replacement disposes the old object.
                scale = max(float(np.max(np.abs(self._cost))), 1.0)
                for scaled in (False, True):
                    key = "scaled_retries" if scaled else "cold_retries"
                    self.recovery_counts[key] += 1
                    objective_status = self._replace(self._cost / scale if scaled else self._cost)
                    if objective_status == highspy.HighsStatus.kError:
                        continue
                    if self.mode == "persistent_clear":
                        self._reset()
                    status = self._run()
                    if (status != highspy.HighsStatus.kError and
                            self._model.getModelStatus() == highspy.HighsModelStatus.kOptimal):
                        solution, info = self._extract()
                        if (np.isfinite(solution).all() and
                                info.max_primal_infeasibility <= 1e-7 and
                                info.max_dual_infeasibility <= 1e-7):
                            return solution.tolist(), float(self._cost @ solution)
                self.recovery_counts["unrecovered"] += 1
                raise RuntimeError("HiGHS failed after independent cold and scaled retries") from initial
        finally:
            if self.mode == "rebuild":
                self.close()

    def copy(self):
        result = type(self)(self.source, mode=self.mode, telemetry=self.telemetry,
                            robust=self.robust, presolve=self.presolve)
        result.setObj(self._cost)
        result.recovery_counts = self.recovery_counts
        return result

    def relax(self):
        return self.copy()  # This adapter rejects integer source models.

    def close(self):
        model = getattr(self, "_model", None)
        self._model = None
        if model is not None:
            self.telemetry.call("model_dispose", dispose_highs_model, model)

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass  # Explicit session.close remains the checked cleanup path.


class LifecycleSession:
    """Common per-method label preprocessing; mode varies for training calls."""

    def __init__(self, method, mode):
        if method not in ("spo_plus", "pfyl", "nce") or mode not in MODES:
            raise ValueError("Only the reviewed three public losses/modes are eligible")
        self.method, self.mode = method, mode
        self.telemetry = LifecycleTelemetry()
        self.owned = []
        self.preprocessing_recoveries = {}
        self.optimization_boundary = None
        self.pretraining_state = None
        self.capture_test_predictions = False

    def preprocessing_model(self, problem):
        mode = "rebuild" if self.method == "spo_plus" else "persistent_basis"
        model = LifecycleHighsOptModel(problem, mode=mode, telemetry=self.telemetry,
                                      robust=self.method == "nce")
        self.owned.append(model)
        return model

    def training_model(self, prior, dataset):
        self.preprocessing_recoveries = dict(prior.recovery_counts)
        prior.recovery_counts = dict.fromkeys(prior.recovery_counts, 0)
        self.telemetry.phase = "training_setup"
        prior.mode = self.mode
        if self.mode == "rebuild":
            prior.close()
        dataset.model = prior  # Existing labels/solutions/pool inputs stay fixed.
        return prior

    def instrument_loss(self, loss):
        telemetry = self.telemetry
        original = type(loss).forward

        @wraps(original)
        def forward(module, *args, **kwargs):
            return telemetry.call("public_loss_forward", original, module, *args, **kwargs)
        loss.forward = MethodType(forward, loss)
        if self.method == "nce":
            update = type(loss)._update_solution_pool

            @wraps(update)
            def pool_update(module, *args, **kwargs):
                return telemetry.call("nce_pool_update", update, module, *args, **kwargs)
            loss._update_solution_pool = MethodType(pool_update, loss)

    def start_optimization(self):
        self.optimization_boundary = self.telemetry.receipt()
        self.telemetry.phase = "optimization"

    def record_pretraining(self, model, dataset, loss):
        from .artifacts import model_sha256

        def array_sha(value):
            array = np.ascontiguousarray(value)
            return hashlib.sha256(array.tobytes()).hexdigest()
        self.pretraining_state = {
            "predictor_parameter_sha256": model_sha256(model),
            "training_solutions_sha256": array_sha(dataset.sols),
            "training_objectives_sha256": array_sha(dataset.objs),
            "solution_pool_sha256": None if getattr(loss, "solpool", None) is None else
                array_sha(loss.solpool.detach().cpu().numpy()),
            "solve_ratio": float(loss.solve_ratio), "loss_class": type(loss).__name__,
            "public_loss_module": type(loss).__module__,
        }

    def close(self):
        self.telemetry.close()

    def receipt(self, optimization_wall=None, optimization_cpu=None):
        return {"method": self.method, "mode": self.mode,
            "preprocessing_policy": "Common original per-method lifecycle for optDataset "
                "labels in all modes; retain model/basis for persistent_basis, "
                "reset before each training solve for persistent_clear, rebuild for rebuild",
            "loss_implementation": "unchanged pinned PyEPO1.0.2",
            "counter_snapshot_after_preparation": self.optimization_boundary,
            "pretraining_state": self.pretraining_state,
            "training_counter_policy": "Optimization phase starts after preparation; "
                "phase counters exclude all values in the stored boundary snapshot",
            "recovery_counts": {"preprocessing": self.preprocessing_recoveries,
                "training": self.owned[-1].recovery_counts if self.owned else {}},
            **self.telemetry.receipt(optimization_wall, optimization_cpu)}
