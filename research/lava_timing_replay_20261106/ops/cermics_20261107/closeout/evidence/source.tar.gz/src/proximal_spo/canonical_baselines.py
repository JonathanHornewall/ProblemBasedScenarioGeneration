"""Audited physical-cost losses and cold HiGHS adapter for the replacement.

Only manifests explicitly opting into this protocol use these components.
SPO+ trains on the continuous relaxation, as explicitly requested by the user.
"""
from __future__ import annotations

import time

import numpy as np
import torch
from pyepo.func import SPOPlus

from .oracles import BatchSolutions, OracleStats
from .public_highs import HighsOptModel, dispose_highs_model


class ColdHighsOptModel(HighsOptModel):
    """Allocate a fresh HiGHS model for EVERY solve, including repeated costs.

    The matrix, bounds, integrality and solver tolerances are unchanged. No
    basis, incumbent or solution crosses an optimization-call boundary. This
    adapter never dispatches to a specialized shortest-path implementation.
    """

    def __init__(self, source, *, presolve=True):
        self.cumulative = OracleStats()
        self.fresh_solve_count = 0
        super().__init__(source, presolve=presolve)
        # PyEPO constructs one model to establish its variable interface. It
        # will never be solved by this cold adapter, so release it immediately.
        self.close()

    def setObj(self, c):
        cost = np.asarray(c, dtype=np.float64)
        if cost.shape != (self.num_cost,) or not np.isfinite(cost).all():
            raise ValueError("Cost vector has invalid shape or nonfinite entries")
        self._cost = cost.copy()

    def solve(self):
        started = time.perf_counter()
        self.close()
        try:
            self._model, self.x = self._getModel()
            self.fresh_solve_count += 1
            # Apply costs only after allocating the fresh solver. The base solve
            # checks optimal status; interrupted/nonoptimal MIPs cannot be successes.
            super().setObj(self._cost)
            result = super().solve()
            iterations = int(self._model.getInfo().simplex_iteration_count)
        finally:
            self.close()
        self.cumulative += OracleStats(
            calls=1,
            iterations=iterations,
            wall_seconds=time.perf_counter() - started,
        )
        return result

    def close(self):
        model = getattr(self, '_model', None)
        self._model = None
        dispose_highs_model(model)

    def relax(self):
        relaxed = type(self)(self.source.continuous_relaxation(), presolve=self.presolve)
        relaxed.setObj(self._cost)
        return relaxed


class ColdHighsBatch:
    """One cold solve per physical objective; sample keys never cache results."""

    def __init__(self, problem):
        self.model = ColdHighsOptModel(problem)

    def solve_many(self, costs, sample_keys=None):
        del sample_keys
        before = self.model.cumulative
        decisions, values = [], []
        for cost in costs:
            self.model.setObj(cost)
            decision, value = self.model.solve()
            decisions.append(decision)
            values.append(value)
        after = self.model.cumulative
        return BatchSolutions(
            np.asarray(decisions), np.asarray(values),
            OracleStats(calls=after.calls-before.calls,
                        iterations=after.iterations-before.iterations,
                        wall_seconds=after.wall_seconds-before.wall_seconds),
        )

    def close(self):
        self.model.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class PhysicalMSELoss(torch.nn.Module):
    """Ordinary Torch MSE on the full physical cost vector, mean reduction."""

    def __init__(self):
        super().__init__()
        self.loss = torch.nn.MSELoss(reduction="mean")

    def forward(self, predicted_cost, physical_cost):
        if predicted_cost.shape != physical_cost.shape:
            raise ValueError("Physical MSE requires the entire physical cost vector")
        return self.loss(predicted_cost, physical_cost)


class PhysicalWISELoss(torch.nn.Module):
    """Wan and Liu (2606.19587v1), Eq. after Proposition 2.2, batch mean.

    No output standardization, augmented constant coordinate or division by
    cost dimension. The paper defines a zero-cost observation's loss as zero.
    This is a direct formula implementation, not an author-code reproduction.
    """

    def forward(self, predicted_cost_direction, physical_cost):
        if predicted_cost_direction.shape != physical_cost.shape:
            raise ValueError("Physical WISE requires the entire physical cost vector")
        norm = torch.linalg.vector_norm(physical_cost, dim=-1)
        safe_norm = torch.where(norm > 0, norm, torch.ones_like(norm))
        target = physical_cost / safe_norm[..., None]
        return (norm * (predicted_cost_direction - target).square().sum(dim=-1)).mean()


def cold_pyepo_spo_plus(problem):
    """Unmodified installed PyEPO loss, original feasible set, no solve cache."""
    return SPOPlus(
        ColdHighsOptModel(problem), processes=1, solve_ratio=1,
        reduction="mean", dataset=None,
    )


from .objectives import CostPredictionObjective, WISEObjective, TorchBatchSignal
from .problem import PartialCostInterface


class PhysicalMSEObjective(CostPredictionObjective):
    torch_training = True

    def __init__(self, problem):
        self.interface = PartialCostInterface.full_cost(problem)
        self.output_dimension = problem.variable_count
        self._lp = ColdHighsBatch(problem)
        self.loss = torch.nn.MSELoss(reduction="none")

    def torch_signal(self, outputs, costs, target_values, *unused):
        return TorchBatchSignal(self.loss(outputs, costs).mean(dim=1), OracleStats())


class PhysicalWISEObjective(WISEObjective):
    torch_training = True

    def __init__(self, problem):
        self.interface = PartialCostInterface.full_cost(problem)
        self.output_dimension = problem.variable_count
        self.augmented = False
        self.zero_tolerance = 1e-12
        self._lp = ColdHighsBatch(problem)

    def torch_signal(self, outputs, costs, target_values, *unused):
        norms = torch.linalg.vector_norm(costs, dim=1)
        denominator = torch.where(norms > 0, norms, torch.ones_like(norms))
        values = norms * (outputs - costs / denominator[:, None]).square().sum(dim=1)
        return TorchBatchSignal(values, OracleStats())


class PhysicalSPOPlusObjective(CostPredictionObjective):
    name = "spo_plus"
    torch_training = True
    requires_target_decisions = True

    def __init__(self, deployment_problem):
        self.interface = PartialCostInterface.full_cost(deployment_problem)
        self.output_dimension = deployment_problem.variable_count
        self._lp = ColdHighsBatch(deployment_problem)
        self.training_problem = deployment_problem.continuous_relaxation()
        self.loss = SPOPlus(ColdHighsOptModel(self.training_problem), processes=1,
                            solve_ratio=1, reduction="none", dataset=None)

    def torch_signal(self, outputs, costs, target_values, *unused, target_decisions):
        before = self.loss.optmodel.cumulative
        values = self.loss(outputs, costs, target_decisions, target_values[:, None])
        after = self.loss.optmodel.cumulative
        return TorchBatchSignal(values.reshape(-1), OracleStats(
            calls=after.calls-before.calls, iterations=after.iterations-before.iterations,
            wall_seconds=after.wall_seconds-before.wall_seconds))
