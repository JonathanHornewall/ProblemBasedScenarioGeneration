"""Canonical fixed-feasible-set LP benchmark constructors."""

from __future__ import annotations

import numpy as np
from scipy.sparse import coo_matrix, csc_matrix

from ..problem import LinearProblem
from ..seeds import rng


def scalar_box() -> LinearProblem:
    return LinearProblem(
        matrix=csc_matrix((0, 1)),
        row_lower=np.empty(0),
        row_upper=np.empty(0),
        variable_lower=np.zeros(1),
        variable_upper=np.ones(1),
        name="scalar_box",
        metadata={"oracle_kind": "scalar_box"},
    )


def top_k_selection(items: int, selected: int) -> LinearProblem:
    """Continuous top-k polytope (whose vertices are binary selections)."""

    if not 0 < selected < items:
        raise ValueError("selected must lie strictly between zero and items")
    return LinearProblem(
        matrix=csc_matrix(np.ones((1, items), dtype=np.float64)),
        row_lower=np.array([float(selected)]),
        row_upper=np.array([float(selected)]),
        variable_lower=np.zeros(items),
        variable_upper=np.ones(items),
        name=f"top_{selected}_of_{items}",
        metadata={
            "items": items,
            "selected": selected,
            "integral_polytope": True,
            "oracle_kind": "top_k",
        },
    )


def assignment(size: int) -> LinearProblem:
    """Bipartite assignment LP with one redundant balance row removed."""

    if size < 2:
        raise ValueError("assignment size must be at least two")
    variables = size * size
    rows: list[int] = []
    columns: list[int] = []
    values: list[float] = []
    # Every left vertex is matched once.
    for left in range(size):
        for right in range(size):
            rows.append(left)
            columns.append(left * size + right)
            values.append(1.0)
    # The final right-vertex equation is implied by the remaining balances.
    for right in range(size - 1):
        for left in range(size):
            rows.append(size + right)
            columns.append(left * size + right)
            values.append(1.0)
    matrix = coo_matrix(
        (values, (rows, columns)), shape=(2 * size - 1, variables)
    ).tocsc()
    rhs = np.ones(2 * size - 1)
    return LinearProblem(
        matrix=matrix,
        row_lower=rhs,
        row_upper=rhs,
        variable_lower=np.zeros(variables),
        variable_upper=np.ones(variables),
        name=f"assignment_{size}x{size}",
        metadata={
            "size": size,
            "integral_polytope": True,
            "oracle_kind": "assignment",
        },
    )


def capacitated_facility_location_relaxation(
    clients: int,
    facilities: int,
    *,
    structural_seed: int,
) -> LinearProblem:
    """Standard capacitated-facility-location LP relaxation.

    Facility-open variables precede facility-major assignment variables.
    """

    if clients < 2 or facilities < 2:
        raise ValueError("facility location needs at least two clients/facilities")
    random = rng(structural_seed, "capacitated_facility_location")
    variables = facilities + facilities * clients
    row_indices: list[int] = []
    column_indices: list[int] = []
    coefficients: list[float] = []
    lower: list[float] = []
    upper: list[float] = []

    # Each client is assigned completely.
    for client in range(clients):
        row = len(lower)
        for facility in range(facilities):
            row_indices.append(row)
            column_indices.append(facilities + facility * clients + client)
            coefficients.append(1.0)
        lower.append(1.0)
        upper.append(1.0)

    # Assignment is possible only at an open facility.
    for facility in range(facilities):
        for client in range(clients):
            row = len(lower)
            row_indices.extend([row, row])
            column_indices.extend([facilities + facility * clients + client, facility])
            coefficients.extend([1.0, -1.0])
            lower.append(-np.inf)
            upper.append(0.0)

    client_weight = random.uniform(0.5, 1.5, size=clients)
    capacity = 1.35 * float(client_weight.sum()) / facilities
    for facility in range(facilities):
        row = len(lower)
        row_indices.append(row)
        column_indices.append(facility)
        coefficients.append(-capacity)
        for client, weight in enumerate(client_weight):
            row_indices.append(row)
            column_indices.append(facilities + facility * clients + client)
            coefficients.append(float(weight))
        lower.append(-np.inf)
        upper.append(0.0)

    matrix = coo_matrix(
        (coefficients, (row_indices, column_indices)),
        shape=(len(lower), variables),
    ).tocsc()
    return LinearProblem(
        matrix=matrix,
        row_lower=np.asarray(lower),
        row_upper=np.asarray(upper),
        variable_lower=np.zeros(variables),
        variable_upper=np.ones(variables),
        name=f"capacitated_facility_location_relaxation_{clients}x{facilities}",
        metadata={
            "clients": clients,
            "facilities": facilities,
            "client_weight": client_weight,
            "capacity": capacity,
            "lp_relaxation": True,
        },
    )


def grid_shortest_path(rows: int, columns: int) -> LinearProblem:
    if rows < 2 or columns < 2:
        raise ValueError("grid dimensions must be at least 2x2")
    nodes = [(r, c) for r in range(rows) for c in range(columns)]
    node_index = {node: i for i, node in enumerate(nodes)}
    edges: list[tuple[tuple[int, int], tuple[int, int]]] = []
    for r, c in nodes:
        if c + 1 < columns:
            edges.append(((r, c), (r, c + 1)))
        if r + 1 < rows:
            edges.append(((r, c), (r + 1, c)))
    incidence = np.zeros((len(nodes), len(edges)), dtype=np.float64)
    for j, (tail, head) in enumerate(edges):
        incidence[node_index[tail], j] = 1.0
        incidence[node_index[head], j] = -1.0
    rhs = np.zeros(len(nodes))
    rhs[0] = 1.0
    rhs[-1] = -1.0
    return LinearProblem(
        matrix=csc_matrix(incidence[:-1]),
        row_lower=rhs[:-1],
        row_upper=rhs[:-1],
        variable_lower=np.zeros(len(edges)),
        variable_upper=np.ones(len(edges)),
        name=f"grid_shortest_path_{rows}x{columns}",
        metadata={
            "rows": rows,
            "columns": columns,
            "edges": edges,
            "oracle_kind": "directed_grid_path",
        },
    )


def continuous_knapsack(
    items: int, constraints: int, *, structural_seed: int
) -> LinearProblem:
    random = rng(structural_seed, "continuous_knapsack")
    weights = random.uniform(3.0, 8.0, size=(constraints, items))
    # Ensure every item can enter while retaining nontrivial competition.
    capacity = 0.30 * weights.sum(axis=1)
    return LinearProblem(
        matrix=csc_matrix(weights),
        row_lower=np.full(constraints, -np.inf),
        row_upper=capacity,
        variable_lower=np.zeros(items),
        variable_upper=np.ones(items),
        name=f"continuous_knapsack_{items}x{constraints}",
        metadata={"weights": weights, "capacity": capacity},
    )


def binary_multidimensional_knapsack(
    items: int, constraints: int, *, structural_seed: int
) -> LinearProblem:
    """Binary knapsack paired with its ordinary non-ideal LP relaxation."""

    relaxation = continuous_knapsack(
        items,
        constraints,
        structural_seed=structural_seed,
    )
    metadata = dict(relaxation.metadata)
    metadata.update(
        {
            "mixed_integer_benchmark": True,
            "hard_variable_type": "binary",
            "training_relaxation": "drop_integrality",
        }
    )
    return LinearProblem(
        matrix=relaxation.matrix,
        row_lower=relaxation.row_lower,
        row_upper=relaxation.row_upper,
        variable_lower=relaxation.variable_lower,
        variable_upper=relaxation.variable_upper,
        integrality=np.ones(items, dtype=np.int64),
        name=f"binary_multidimensional_knapsack_{items}x{constraints}",
        metadata=metadata,
    )


def capacitated_facility_location_mip(
    clients: int,
    facilities: int,
    *,
    structural_seed: int,
) -> LinearProblem:
    """Facility-location MILP with binary opens and continuous assignment."""

    relaxation = capacitated_facility_location_relaxation(
        clients,
        facilities,
        structural_seed=structural_seed,
    )
    integrality = np.zeros(relaxation.variable_count, dtype=np.int64)
    integrality[:facilities] = 1
    metadata = dict(relaxation.metadata)
    metadata.pop("lp_relaxation", None)
    metadata.update(
        {
            "mixed_integer_benchmark": True,
            "binary_open_variable_count": facilities,
            "continuous_assignment_variable_count": facilities * clients,
            "training_relaxation": "drop_integrality",
        }
    )
    return LinearProblem(
        matrix=relaxation.matrix,
        row_lower=relaxation.row_lower,
        row_upper=relaxation.row_upper,
        variable_lower=relaxation.variable_lower,
        variable_upper=relaxation.variable_upper,
        integrality=integrality,
        name=f"capacitated_facility_location_mip_{clients}x{facilities}",
        metadata=metadata,
    )


def planted_random_lp(
    variables: int, constraints: int, *, structural_seed: int
) -> LinearProblem:
    random = rng(structural_seed, "planted_random_lp")
    density = min(1.0, 12.0 / variables)
    mask = random.random((constraints, variables)) < density
    matrix = random.normal(size=(constraints, variables)) * mask
    center = random.uniform(0.25, 0.75, size=variables)
    rhs = matrix @ center + random.uniform(0.2, 1.2, size=constraints)
    return LinearProblem(
        matrix=csc_matrix(matrix),
        row_lower=np.full(constraints, -np.inf),
        row_upper=rhs,
        variable_lower=np.zeros(variables),
        variable_upper=np.ones(variables),
        name=f"planted_random_lp_{variables}x{constraints}",
        metadata={"construction": "DFLExtensionsLab/LAVA-style planted polytope"},
    )
