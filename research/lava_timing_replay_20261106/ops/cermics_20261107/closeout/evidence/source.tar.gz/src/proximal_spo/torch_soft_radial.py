"""Torch-resident Soft-Radial map and centered log-barrier machinery.

The NumPy implementation in :mod:`proximal_spo.feasible_policies` remains the
reference implementation.  This module mirrors its arithmetic while attaching
the exact piecewise-smooth VJP through a custom autograd operator.  Consequently
training does not retain a large map-level autograd tape and never needs to
leave the selected Torch device between the network output and optimizer step.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, cast

import torch

from .oracles import OracleFailure

if TYPE_CHECKING:
    from .feasible_policies import PolyhedralPolicyGeometry

Contraction = Literal["rational", "exponential", "hyperbolic"]


def _device_assert(condition: torch.Tensor, message: str) -> None:
    """Fail immediately on CPU and asynchronously on accelerator devices."""

    scalar = torch.all(condition)
    if scalar.device.type == "cpu":
        if not bool(scalar):
            raise OracleFailure(message)
        return
    # Avoid a host synchronization in every accelerator minibatch.  The error
    # is raised at the next ordinary synchronization if the predicate fails.
    torch._assert_async(scalar, message)


def _contraction_values(
    squared_norms: torch.Tensor,
    *,
    family: Contraction,
    scale: float,
    minimum_scale: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    if family == "rational":
        denominator = squared_norms + scale
        value = minimum_scale + (1.0 - minimum_scale) * squared_norms / denominator
        derivative = (1.0 - minimum_scale) * scale / denominator.square()
    elif family == "exponential":
        exponential = torch.exp(-squared_norms / scale)
        value = minimum_scale + (1.0 - minimum_scale) * (1.0 - exponential)
        derivative = (1.0 - minimum_scale) * exponential / scale
    elif family == "hyperbolic":
        tangent = torch.tanh(squared_norms / scale)
        value = minimum_scale + (1.0 - minimum_scale) * tangent
        derivative = (1.0 - minimum_scale) * (1.0 - tangent.square()) / scale
    else:  # pragma: no cover - protected by objective/config validation
        raise ValueError(f"unknown Soft-Radial contraction {family!r}")
    return value, derivative


class _AnalyticSoftRadialMap(torch.autograd.Function):
    """Bounded-report Soft-Radial map with the exact NumPy-reference VJP."""

    @staticmethod
    def forward(
        ctx: Any,
        reports: torch.Tensor,
        normalized_inequalities: torch.Tensor,
        normalized_inequalities_transpose: torch.Tensor,
        maximum_report_norm: float,
        family: str,
        contraction_scale: float,
        minimum_scale: float,
        report_guard: bool,
    ) -> torch.Tensor:
        if reports.ndim != 2:
            raise ValueError("Torch Soft-Radial reports must form a matrix")
        _device_assert(
            torch.isfinite(reports),
            "Torch Soft-Radial reports contain non-finite values",
        )
        raw_norms = torch.linalg.vector_norm(reports, dim=1)
        guard_scales = (maximum_report_norm / (maximum_report_norm + raw_norms)
                        if report_guard else torch.ones_like(raw_norms))
        bounded = reports * guard_scales[:, None]

        loads = bounded @ normalized_inequalities_transpose
        maximum_loads, active_rows = torch.max(loads, dim=1)
        outside = maximum_loads > 1.0
        safe_maximum_loads = torch.clamp(
            maximum_loads,
            min=torch.finfo(reports.dtype).tiny,
        )
        hard_scales = torch.where(
            outside,
            torch.reciprocal(safe_maximum_loads),
            torch.ones_like(maximum_loads),
        )
        hard_reduced = bounded * hard_scales[:, None]

        squared_norms = torch.sum(bounded.square(), dim=1)
        contraction, contraction_derivative = _contraction_values(
            squared_norms,
            family=cast(Contraction, family),
            scale=contraction_scale,
            minimum_scale=minimum_scale,
        )
        reduced = contraction[:, None] * hard_reduced
        active_normals = normalized_inequalities[active_rows]
        ctx.save_for_backward(
            reports,
            bounded,
            guard_scales,
            hard_scales,
            active_normals,
            contraction,
            contraction_derivative,
            hard_reduced,
        )
        return cast(torch.Tensor, reduced)

    @staticmethod
    def backward(
        ctx: Any, gradient_reduced: torch.Tensor
    ) -> tuple[
        torch.Tensor,
        None,
        None,
        None,
        None,
        None,
        None,
    ]:
        (
            reports,
            bounded,
            guard_scales,
            hard_scales,
            active_normals,
            contraction,
            contraction_derivative,
            hard_reduced,
        ) = ctx.saved_tensors

        # VJP of the hard radial map in the reduced affine coordinates.
        hard_gradient = hard_scales[:, None] * gradient_reduced
        outside = hard_scales < 1.0
        hard_inner = torch.sum(bounded * gradient_reduced, dim=1)
        hard_correction = (
            hard_scales.square()[:, None]
            * active_normals
            * hard_inner[:, None]
        )
        hard_gradient = torch.where(
            outside[:, None],
            hard_gradient - hard_correction,
            hard_gradient,
        )

        contraction_inner = torch.sum(hard_reduced * gradient_reduced, dim=1)
        bounded_gradient = (
            contraction[:, None] * hard_gradient
            + 2.0
            * contraction_derivative[:, None]
            * bounded
            * contraction_inner[:, None]
        )

        # VJP of u -> R u / (R + ||u||), written in the same stable form as
        # the NumPy reference and with an explicit zero-report branch.
        raw_squared_norms = torch.sum(reports.square(), dim=1)
        safe_squared_norms = torch.clamp(
            raw_squared_norms,
            min=torch.finfo(reports.dtype).tiny,
        )
        guard_inner = torch.sum(reports * bounded_gradient, dim=1)
        coefficient = (
            (guard_scales.square() - guard_scales)
            * guard_inner
            / safe_squared_norms
        )
        coefficient = torch.where(
            raw_squared_norms > 0.0,
            coefficient,
            torch.zeros_like(coefficient),
        )
        raw_gradient = (
            guard_scales[:, None] * bounded_gradient
            + coefficient[:, None] * reports
        )
        return raw_gradient, None, None, None, None, None, None, None


@dataclass(frozen=True)
class TorchSoftRadialBatch:
    """Torch-resident forward values shared by loss and recovered-cost code."""

    decisions: torch.Tensor
    reduced_decisions: torch.Tensor
    normalized_loads: torch.Tensor
    normalized_slacks: torch.Tensor
    barrier_energy: torch.Tensor


class TorchSoftRadialKernel:
    """Device/dtype-specific Torch mirror of one compiled policy geometry."""

    def __init__(
        self,
        geometry: PolyhedralPolicyGeometry,
        *,
        device: torch.device,
        dtype: torch.dtype,
        maximum_report_norm: float,
        contraction: Contraction,
        contraction_scale: float,
        minimum_scale: float,
        report_guard: bool = True,
    ) -> None:
        if dtype not in {torch.float32, torch.float64}:
            raise ValueError("Torch Soft-Radial requires float32 or float64")
        if device.type == "mps" and dtype == torch.float64:
            raise ValueError("MPS Soft-Radial requires a float32 model")
        self.device = device
        self.dtype = dtype
        self.maximum_report_norm = float(maximum_report_norm)
        self.contraction = contraction
        self.contraction_scale = float(contraction_scale)
        self.minimum_scale = float(minimum_scale)
        self.report_guard = report_guard
        self.center = torch.as_tensor(geometry.center, dtype=dtype, device=device)
        self.physical_map_transpose = torch.as_tensor(
            geometry.physical_map_transpose,
            dtype=dtype,
            device=device,
        )
        self.normalized_inequalities = torch.as_tensor(
            geometry.normalized_inequalities,
            dtype=dtype,
            device=device,
        )
        self.normalized_inequalities_transpose = torch.as_tensor(
            geometry.normalized_inequalities_transpose,
            dtype=dtype,
            device=device,
        )
        self.center_slacks = torch.as_tensor(
            geometry.center_slacks,
            dtype=dtype,
            device=device,
        )
        self.inequality_matrix = torch.as_tensor(
            geometry.inequality_matrix,
            dtype=dtype,
            device=device,
        )
        self.intrinsic_dimension = int(geometry.intrinsic_dimension)

    def map(self, reports: torch.Tensor) -> TorchSoftRadialBatch:
        if reports.device != self.device or reports.dtype != self.dtype:
            raise ValueError("Torch Soft-Radial reports use the wrong device or dtype")
        if reports.ndim != 2 or reports.shape[1] != self.intrinsic_dimension:
            raise ValueError("Torch Soft-Radial reports have the wrong shape")
        reduced = cast(
            torch.Tensor,
            _AnalyticSoftRadialMap.apply(  # type: ignore[no-untyped-call]
            reports,
            self.normalized_inequalities,
            self.normalized_inequalities_transpose,
            self.maximum_report_norm,
            self.contraction,
            self.contraction_scale,
            self.minimum_scale,
            self.report_guard,
            ),
        )
        normalized_loads = reduced @ self.normalized_inequalities_transpose
        normalized_slacks = 1.0 - normalized_loads
        _device_assert(
            normalized_slacks > 0.0,
            "Torch Soft-Radial map lost strict interior feasibility",
        )
        energy_terms = torch.log1p(-normalized_loads) + normalized_loads
        barrier_energy = -torch.sum(energy_terms, dim=1)
        decisions = self.center + reduced @ self.physical_map_transpose
        _device_assert(
            torch.isfinite(decisions) & torch.isfinite(barrier_energy[:, None]),
            "Torch Soft-Radial map produced non-finite values",
        )
        return TorchSoftRadialBatch(
            decisions=decisions,
            reduced_decisions=reduced,
            normalized_loads=normalized_loads,
            normalized_slacks=normalized_slacks,
            barrier_energy=barrier_energy,
        )

    def recovered_costs(
        self,
        batch: TorchSoftRadialBatch,
        *,
        mu: float = 1.0,
    ) -> torch.Tensor:
        """Return the centered log-gradient cost in physical coordinates."""

        if mu < 0.0:
            raise ValueError("mu must be nonnegative")
        multipliers = batch.normalized_loads / (
            self.center_slacks[None, :] * batch.normalized_slacks
        )
        costs = -float(mu) * (multipliers @ self.inequality_matrix)
        _device_assert(
            torch.isfinite(costs),
            "Torch recovered log-barrier costs are non-finite",
        )
        return costs
