"""Recover transient oracle failures without changing NCE's physical cost units."""

import time

import highspy
import numpy as np

from proximal_spo.oracles import OracleFailure, OracleStats, PersistentLPSolver
from proximal_spo.public_highs import HighsOptModel


class RobustHighsOptModel(HighsOptModel):
    def __init__(self, source, *, presolve=True):
        self.recovery_counts = {
            "cold_retries": 0,
            "scaled_retries": 0,
            "unrecovered": 0,
        }
        super().__init__(source, presolve=presolve)

    def solve(self):
        try:
            return super().solve()
        except RuntimeError as initial:
            # A fresh model drops the basis that caused the transient "Not Set"
            # failure. Only after that fails, try a positive objective rescaling.
            scale = max(float(np.max(np.abs(self._cost))), 1.0)
            for scaled in (False, True):
                self.recovery_counts[
                    "scaled_retries" if scaled else "cold_retries"
                ] += 1
                self._model, self.x = self._getModel()
                solver_cost = self._cost / scale if scaled else self._cost
                status = self._model.changeColsCost(self.num_cost, self.x, solver_cost)
                if status == highspy.HighsStatus.kError:
                    continue
                status = self._model.run()
                self.solve_count += 1
                if (
                    status != highspy.HighsStatus.kError
                    and self._model.getModelStatus()
                    == highspy.HighsModelStatus.kOptimal
                ):
                    solution = np.asarray(
                        self._model.getSolution().col_value, dtype=np.float64
                    )
                    info = self._model.getInfo()
                    if (
                        np.isfinite(solution).all()
                        and info.max_primal_infeasibility <= 1e-7
                        and info.max_dual_infeasibility <= 1e-7
                    ):
                        # Future setObj updates restore original physical units.
                        return solution.tolist(), float(self._cost @ solution)
            self.recovery_counts["unrecovered"] += 1
            raise RuntimeError(
                "HiGHS failed after independent cold and scaled retries"
            ) from initial

    def copy(self):
        result = super().copy()
        result.recovery_counts = self.recovery_counts
        return result

    def relax(self):
        result = super().relax()
        result.recovery_counts = self.recovery_counts
        return result


class RobustEvaluationSolver(PersistentLPSolver):
    """Use the same recovery for NCE validation without altering other methods."""

    def __init__(self, problem, **kwargs):
        super().__init__(problem, **kwargs)
        self.recovery_counts = {"cold_evaluation_retries": 0}

    def solve(self, objective, sample_key=None):
        started = time.perf_counter()
        try:
            return super().solve(objective, sample_key)
        except OracleFailure:
            self.recovery_counts["cold_evaluation_retries"] += 1
            cold = RobustHighsOptModel(self.problem)
            cold.setObj(objective)
            decision, value = cold.solve()
            for key, count in cold.recovery_counts.items():
                self.recovery_counts[key] = self.recovery_counts.get(key, 0) + count
            return (
                np.asarray(decision),
                value,
                OracleStats(
                    calls=1, retries=1, wall_seconds=time.perf_counter() - started
                ),
            )
