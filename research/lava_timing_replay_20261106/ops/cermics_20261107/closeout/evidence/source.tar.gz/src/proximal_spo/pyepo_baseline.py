"""Canonical PyEPO SPO+ baseline backed by its default Gurobi adapter.

This module is intentionally optional and deliberately avoids the project's
HiGHS warm-start, basis-cache, and parallel-oracle machinery. Selecting the
baseline therefore measures the public PyEPO implementation rather than a
second route through :class:`SPOPlusObjective`.
"""

from __future__ import annotations

import importlib.metadata
import time
from dataclasses import asdict
from typing import Any

import numpy as np
import torch
from scipy.sparse import csc_matrix

from .objectives import BatchSignal, Deployment, TrainingBatch
from .oracles import OracleStats
from .problem import FloatArray, LinearProblem, PartialCostInterface


def _canonical_dependencies() -> tuple[Any, Any, Any]:
    """Import the optional public baseline with an actionable error."""

    try:
        import gurobipy as gp
        from gurobipy import GRB
        from pyepo.func import SPOPlus
        from pyepo.model.grb.grbmodel import optGrbModel
    except ImportError as error:  # pragma: no cover - exercised without the extra
        raise RuntimeError(
            "canonical PyEPO SPO+ requires the 'canonical-spo' project extra "
            "and a working Gurobi installation"
        ) from error
    return gp, GRB, (SPOPlus, optGrbModel)


def _ortools_dependencies() -> tuple[Any, Any]:
    """Import PyEPO's public OR-Tools adapter dependencies."""

    try:
        from ortools.linear_solver import pywraplp
        from pyepo.func import SPOPlus
        from pyepo.model.ort.ortmodel import optOrtModel
    except ImportError as error:  # pragma: no cover - exercised without the extra
        raise RuntimeError(
            "PyEPO's OR-Tools SPO+ backend requires the 'ortools' package"
        ) from error
    return pywraplp, (SPOPlus, optOrtModel)


def _stats_difference(after: OracleStats, before: OracleStats) -> OracleStats:
    return OracleStats(
        calls=after.calls - before.calls,
        iterations=after.iterations - before.iterations,
        failures=after.failures - before.failures,
        solver_seconds=after.solver_seconds - before.solver_seconds,
        wall_seconds=after.wall_seconds - before.wall_seconds,
        retries=after.retries - before.retries,
    )


def _make_gurobi_model_class() -> type:
    gp, grb, dependencies = _canonical_dependencies()
    _, opt_grb_model = dependencies

    class MatrixGurobiModel(opt_grb_model):  # type: ignore[misc, valid-type]
        """Translate ``LinearProblem`` into PyEPO's standard Gurobi model."""

        def __init__(self, problem: LinearProblem) -> None:
            # ``problem`` is a reserved optional PyEPO metadata attribute used
            # by ``objective_offset``. Keep the matrix program under a name
            # that cannot be mistaken for that public benchmark wrapper.
            self._linear_problem = problem
            self._cumulative_stats = OracleStats()
            super().__init__()

        def _getModel(self) -> tuple[Any, Any]:  # noqa: N802 - PyEPO API
            problem = self._linear_problem
            model = gp.Model(problem.name)
            model.ModelSense = grb.MINIMIZE
            variable_types = np.where(
                np.asarray(problem.integrality, dtype=np.int64) == 1,
                grb.INTEGER,
                grb.CONTINUOUS,
            )
            variables = model.addMVar(
                problem.variable_count,
                lb=problem.variable_lower,
                ub=problem.variable_upper,
                vtype=variable_types,
                name="z",
            )

            matrix = csc_matrix(problem.matrix)
            lower = problem.row_lower
            upper = problem.row_upper
            equality = np.isfinite(lower) & np.isfinite(upper) & (lower == upper)
            upper_only = np.isfinite(upper) & ~equality
            lower_only = np.isfinite(lower) & ~equality
            if np.any(equality):
                model.addMConstr(matrix[equality], variables, "=", lower[equality])
            if np.any(upper_only):
                model.addMConstr(matrix[upper_only], variables, "<", upper[upper_only])
            if np.any(lower_only):
                model.addMConstr(matrix[lower_only], variables, ">", lower[lower_only])
            model.update()
            return model, variables

        def solve(self) -> tuple[np.ndarray, float]:
            started = time.perf_counter()
            failed = 0
            try:
                solution, objective = super().solve()
            except BaseException:
                failed = 1
                raise
            finally:
                elapsed = time.perf_counter() - started
                solver_seconds = float(getattr(self._model, "Runtime", elapsed))
                simplex_iterations = int(
                    round(float(getattr(self._model, "IterCount", 0.0)))
                )
                node_count = int(round(float(getattr(self._model, "NodeCount", 0.0))))
                self._cumulative_stats += OracleStats(
                    calls=1,
                    iterations=simplex_iterations + node_count,
                    failures=failed,
                    solver_seconds=solver_seconds,
                    wall_seconds=elapsed,
                )
            return np.asarray(solution, dtype=np.float64), float(objective)

        def stats(self) -> OracleStats:
            return self._cumulative_stats

        def dispose(self) -> None:
            self._model.dispose()

    return MatrixGurobiModel


def _make_ortools_model_class() -> type:
    pywraplp, dependencies = _ortools_dependencies()
    _, opt_ort_model = dependencies

    class MatrixORToolsModel(opt_ort_model):  # type: ignore[misc, valid-type]
        """Translate ``LinearProblem`` into PyEPO's public OR-Tools model."""

        def __init__(self, problem: LinearProblem) -> None:
            self._linear_problem = problem
            self._cumulative_stats = OracleStats()
            # Training relaxations use GLOP.  The deployment model is built
            # with SCIP only when the supplied hard problem is integral.
            solver = "scip" if not problem.is_continuous else "glop"
            super().__init__(solver=solver)

        def _getModel(self) -> tuple[Any, dict[int, Any]]:  # noqa: N802
            problem = self._linear_problem
            backend = "SCIP" if not problem.is_continuous else "GLOP"
            model = pywraplp.Solver.CreateSolver(backend)
            if model is None:
                raise RuntimeError(f"OR-Tools solver {backend} is unavailable")
            infinity = model.infinity()
            variables: dict[int, Any] = {}
            for index, (lower, upper, integral) in enumerate(
                zip(
                    problem.variable_lower,
                    problem.variable_upper,
                    problem.integrality,
                    strict=True,
                )
            ):
                lb = -infinity if not np.isfinite(lower) else float(lower)
                ub = infinity if not np.isfinite(upper) else float(upper)
                if int(integral) == 1:
                    variables[index] = model.IntVar(lb, ub, f"z_{index}")
                else:
                    variables[index] = model.NumVar(lb, ub, f"z_{index}")
            matrix = csc_matrix(problem.matrix).tocsr()
            for row_index, (lower, upper) in enumerate(
                zip(problem.row_lower, problem.row_upper, strict=True)
            ):
                lb = -infinity if not np.isfinite(lower) else float(lower)
                ub = infinity if not np.isfinite(upper) else float(upper)
                constraint = model.Constraint(lb, ub)
                row = matrix.getrow(row_index)
                for column, coefficient in zip(
                    row.indices, row.data, strict=True
                ):
                    constraint.SetCoefficient(
                        variables[int(column)], float(coefficient)
                    )
            return model, variables

        def solve(self) -> tuple[np.ndarray, float]:
            started = time.perf_counter()
            failed = 0
            try:
                solution, objective = super().solve()
            except BaseException:
                failed = 1
                raise
            finally:
                elapsed = time.perf_counter() - started
                iterations = int(self._model.iterations())
                nodes = (
                    int(self._model.nodes())
                    if not self._linear_problem.is_continuous
                    else 0
                )
                self._cumulative_stats += OracleStats(
                    calls=1,
                    iterations=max(0, iterations) + max(0, nodes),
                    failures=failed,
                    solver_seconds=elapsed,
                    wall_seconds=elapsed,
                )
            return np.asarray(solution, dtype=np.float64), float(objective)

        def stats(self) -> OracleStats:
            return self._cumulative_stats

        def dispose(self) -> None:
            self._model.Clear()

    return MatrixORToolsModel


class PyEPOSPOPlusObjective:
    """Official PyEPO 2.2.7 SPO+ with its documented exact defaults."""

    name = "pyepo_spo_plus"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        deployment_problem: LinearProblem | None = None,
        solver_backend: str = "gurobi",
    ) -> None:
        if solver_backend == "gurobi":
            _, _, dependencies = _canonical_dependencies()
            spo_plus, _ = dependencies
            model_class = _make_gurobi_model_class()
        elif solver_backend == "ortools":
            _, dependencies = _ortools_dependencies()
            spo_plus, _ = dependencies
            model_class = _make_ortools_model_class()
        else:
            raise ValueError(f"unknown PyEPO solver backend: {solver_backend}")
        self._solver_backend = solver_backend
        self.interface = interface
        self.output_dimension = interface.report_dimension
        self._training_model = model_class(interface.problem)
        # These are PyEPO's documented exact defaults, written explicitly so
        # the experimental contract cannot drift with an upstream release.
        self._loss = spo_plus(
            self._training_model,
            processes=1,
            solve_ratio=1.0,
            reduction="none",
        )
        hard_problem = (
            interface.problem if deployment_problem is None else deployment_problem
        )
        self.deployment_interface = PartialCostInterface(
            hard_problem,
            interface.fixed_cost,
            interface.statistic,
            name=f"{interface.name}.pyepo_hard_deployment",
        )
        self._deployment_model = (
            self._training_model
            if hard_problem is interface.problem
            else model_class(hard_problem)
        )
        self._fixed_cost = torch.as_tensor(interface.fixed_cost, dtype=torch.float64)
        self._statistic = torch.as_tensor(interface.statistic, dtype=torch.float64)

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        output_tensor = torch.tensor(
            np.asarray(outputs, dtype=np.float64),
            dtype=torch.float64,
            requires_grad=True,
        )
        predicted_cost = self._fixed_cost + output_tensor @ self._statistic
        true_cost = torch.as_tensor(batch.physical_costs, dtype=torch.float64)
        true_solution = torch.as_tensor(batch.target_decisions, dtype=torch.float64)
        true_objective = torch.as_tensor(
            batch.target_values[:, None], dtype=torch.float64
        )
        before = self._training_model.stats()
        losses = self._loss(
            predicted_cost,
            true_cost,
            true_solution,
            true_objective,
        )
        gradient = torch.autograd.grad(losses.sum(), output_tensor)[0]
        stats = _stats_difference(self._training_model.stats(), before)
        return BatchSignal(
            values=losses.detach().cpu().numpy(),
            output_gradient=gradient.detach().cpu().numpy(),
            stats=stats,
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        return self.deploy_with_sample_keys(outputs, None)

    def deploy_with_sample_keys(
        self, outputs: FloatArray, sample_keys: np.ndarray | None
    ) -> Deployment:
        del sample_keys  # Canonical PyEPO does not expose keyed solver warm starts.
        costs = self.deployment_interface.physical_cost(outputs)
        before = self._deployment_model.stats()
        decisions = []
        for cost in costs:
            self._deployment_model.setObj(cost)
            decision, _ = self._deployment_model.solve()
            decisions.append(decision)
        stats = _stats_difference(self._deployment_model.stats(), before)
        return Deployment(
            np.asarray(decisions, dtype=np.float64),
            np.asarray(outputs, dtype=np.float64),
            stats,
        )

    def predicted_physical_costs(self, outputs: FloatArray) -> FloatArray:
        """Expose PyEPO's cost report without invoking its solver."""

        return np.asarray(
            self.deployment_interface.physical_cost(
                np.asarray(outputs, dtype=np.float64)
            ),
            dtype=np.float64,
        )

    def receipt(self) -> dict[str, object]:
        receipt: dict[str, object] = {
            "implementation": "official_pyepo_spoplus",
            "pyepo_version": importlib.metadata.version("pyepo"),
            "solver_backend": self._solver_backend,
            "processes": 1,
            "solve_ratio": 1.0,
            "reduction": "none",
            "training_problem": self.interface.problem.name,
            "deployment_problem": self.deployment_interface.problem.name,
            "custom_basis_cache": False,
            "custom_parallel_oracle": False,
            "custom_solver_warm_start": False,
            "statistics_schema": asdict(OracleStats()),
        }
        if self._solver_backend == "gurobi":
            gp, _, _ = _canonical_dependencies()
            receipt.update(
                {
                    "gurobipy_version": importlib.metadata.version("gurobipy"),
                    "gurobi_solver_version": ".".join(
                        map(str, gp.gurobi.version())
                    ),
                    "backend": "pyepo.model.grb.optGrbModel",
                }
            )
        else:
            receipt.update(
                {
                    "ortools_version": importlib.metadata.version("ortools"),
                    "backend": "pyepo.model.ort.optOrtModel",
                    "training_solver": "GLOP",
                }
            )
        return receipt

    def close(self) -> None:
        pool = getattr(self._loss, "pool", None)
        if pool is not None:  # Defensive; canonical processes=1 creates no pool.
            pool.close()
            pool.join()
            pool.clear()
        self._training_model.dispose()
        if self._deployment_model is not self._training_model:
            self._deployment_model.dispose()
