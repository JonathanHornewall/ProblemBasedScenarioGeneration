"""Command-line entry point for independent, incremental experiment runs."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

from .benchmarks import list_benchmarks
from .config import RunSpec
from .runner import diagnose_dataset, run_experiment


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="proximal-spo")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("list-benchmarks")
    diagnose = subparsers.add_parser("diagnose-data")
    diagnose.add_argument("--config", type=Path, required=True)
    diagnose.add_argument("--output", type=Path)
    run = subparsers.add_parser("run")
    run.add_argument("--config", type=Path, required=True)
    run.add_argument("--run-root", type=Path, default=Path("runs"))
    run.add_argument("--run-directory", type=Path)
    run.add_argument("--quiet", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    arguments = _parser().parse_args(argv)
    if arguments.command == "list-benchmarks":
        benchmark_payload = [
            {
                "benchmark_id": item.benchmark_id,
                "tier": item.tier,
                "description": item.description,
            }
            for item in list_benchmarks()
        ]
        print(json.dumps(benchmark_payload, indent=2))
        return 0
    if arguments.command == "diagnose-data":
        spec = RunSpec.load(arguments.config)
        diagnostic_payload = diagnose_dataset(spec)
        encoded = json.dumps(diagnostic_payload, indent=2, sort_keys=True) + "\n"
        if arguments.output is not None:
            arguments.output.parent.mkdir(parents=True, exist_ok=True)
            arguments.output.write_text(encoded, encoding="utf-8")
        print(encoded, end="")
        return 0
    if arguments.command == "run":
        spec = RunSpec.load(arguments.config)
        if arguments.run_directory is None:
            timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
            directory = (
                arguments.run_root
                / spec.benchmark_id
                / spec.method
                / f"{timestamp}_{spec.name}"
            )
        else:
            directory = arguments.run_directory
        repo_root = Path(__file__).resolve().parents[2]
        result = run_experiment(
            spec,
            run_directory=directory,
            repo_root=repo_root,
            progress=not arguments.quiet,
        )
        print(json.dumps(result.to_dict(), indent=2, sort_keys=True))
        return 0
    raise AssertionError(arguments.command)


if __name__ == "__main__":
    sys.exit(main())
