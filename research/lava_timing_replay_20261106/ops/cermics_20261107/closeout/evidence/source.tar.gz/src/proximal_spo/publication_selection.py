"""Test-blind promotion from broad development to paired refinement.

The first development wave deliberately spends one seed on a broad search.
This module promotes several validation-ranked candidates per benchmark and
method into a smaller paired-seed refinement wave.  It never reads test
metrics and validates every emitted run through the strict configuration
schema.
"""

from __future__ import annotations

import copy
import hashlib
import json
import math
from collections import defaultdict
from collections.abc import Collection, Iterable, Mapping, Sequence
from itertools import product
from pathlib import Path
from statistics import fmean, pstdev
from typing import Any

from .config import RunSpec
from .experiment_identity import benchmark_family_id, experimental_route_id

DEVELOPMENT_SEED_BUNDLES: tuple[dict[str, int], ...] = (
    {
        "data": 51_101,
        "initialization": 61_101,
        "shuffle": 71_101,
        "perturbation": 81_101,
    },
    {
        "data": 51_103,
        "initialization": 61_103,
        "shuffle": 71_103,
        "perturbation": 81_103,
    },
    {
        "data": 51_107,
        "initialization": 61_107,
        "shuffle": 71_107,
        "perturbation": 81_107,
    },
)
CONFIRMATION_SEED_BUNDLES: tuple[dict[str, int], ...] = tuple(
    {
        "data": 151_101 + 2 * index,
        "initialization": 161_101 + 2 * index,
        "shuffle": 171_101 + 2 * index,
        "perturbation": 181_101 + 2 * index,
    }
    for index in range(10)
)
CONDITIONAL_CORE_METHODS = frozenset(
    {
        "mse",
        "wise",
        "spo_plus",
        "spo_plus_relaxation",
        "soft_radial_log_barrier",
    }
)
ORIGINAL_DENSE_300_EPOCH_CHECKPOINTS = [
    5,
    10,
    20,
    40,
    80,
    120,
    180,
    240,
    300,
]
SPARSE_300_EPOCH_CHECKPOINTS = [80, 180, 300]
PRACTICAL_MIP_BENCHMARKS = frozenset(
    {
        "cost.binary_knapsack20x5",
        "cost.binary_knapsack50x5",
        "cost.facility15x4_mip",
        "cost.facility30x5_mip",
    }
)


def _slug(value: object) -> str:
    return str(value).replace(".", "p").replace("-", "_")


def candidate_fingerprint(config: dict[str, Any]) -> str:
    """Identify one hyperparameter arm independently of run and RNG seeds."""

    payload = copy.deepcopy(config)
    payload.pop("name", None)
    payload.pop("seeds", None)
    payload.pop("evaluate_test", None)
    canonical = json.dumps(
        payload, sort_keys=True, separators=(",", ":")
    ).encode()
    return hashlib.sha256(canonical).hexdigest()[:12]


def _row_route_id(row: dict[str, Any], config: dict[str, Any]) -> str:
    route = row.get("route_id")
    return str(route) if isinstance(route, str) else experimental_route_id(config)


def _deduplicate_configs(configs: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for config in configs:
        fingerprint = candidate_fingerprint(config)
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        RunSpec.from_dict(config)
        result.append(config)
    return result


def build_integer_accelerated_tail(
    campaign: dict[str, Any],
    *,
    start_index: int,
    run_root: str,
    workers: int,
) -> dict[str, Any]:
    """Reissue an untouched integer-development tail with faster deployment."""

    variants = campaign.get("variants")
    if not isinstance(variants, list) or not variants:
        raise ValueError("source campaign has no variants")
    if not 0 <= start_index < len(variants):
        raise ValueError("start_index lies outside the source campaign")
    if workers <= 0:
        raise ValueError("workers must be positive")
    accelerated: list[dict[str, Any]] = []
    thinned_count = 0
    for original in variants[start_index:]:
        if not isinstance(original, dict):
            raise ValueError("source campaign variant is not an object")
        config = copy.deepcopy(original)
        if bool(config.get("evaluate_test")):
            raise ValueError("integer development tail must remain test-blind")
        config["name"] = f"{config['name']}_w{workers}_sparse"
        config["workers"] = workers
        training = config.get("training")
        if not isinstance(training, dict):
            raise ValueError("source variant lacks training configuration")
        if (
            config.get("method") == "soft_radial_log_barrier"
            and config.get("benchmark_id") in PRACTICAL_MIP_BENCHMARKS
            and training.get("validation_epochs")
            == ORIGINAL_DENSE_300_EPOCH_CHECKPOINTS
        ):
            training["validation_epochs"] = SPARSE_300_EPOCH_CHECKPOINTS
            thinned_count += 1
        RunSpec.from_dict(config)
        accelerated.append(config)
    return {
        "name": "publication_practical_integer_accelerated_tail",
        "run_root": run_root,
        "design": {
            "stage": "integer_development_accelerated_tail",
            "test_blind": True,
            "source_campaign": campaign.get("name"),
            "source_variant_count": len(variants),
            "preserved_completed_prefix_count": start_index,
            "tail_start_index": start_index,
            "tail_variant_count": len(accelerated),
            "workers_override": workers,
            "identical_solver_seed_across_workers": True,
            "hard_validation_checkpoint_change": {
                "from": ORIGINAL_DENSE_300_EPOCH_CHECKPOINTS,
                "to": SPARSE_300_EPOCH_CHECKPOINTS,
                "affected_variant_count": thinned_count,
                "reason": (
                    "immature target reports induced expensive nearly tied "
                    "exact-MIP validations"
                ),
            },
            "incremental_receipts": True,
        },
        "base": {},
        "variants": accelerated,
    }


def build_remaining_campaign(
    campaign: dict[str, Any],
    *,
    completed_names: Iterable[str],
    excluded_names: Iterable[str],
    run_root: str,
    name: str,
) -> dict[str, Any]:
    """Freeze only unfinished, non-gated variants from a campaign."""

    variants = campaign.get("variants")
    if not isinstance(variants, list) or not variants:
        raise ValueError("source campaign has no variants")
    by_name: dict[str, dict[str, Any]] = {}
    for variant in variants:
        if not isinstance(variant, dict) or not isinstance(variant.get("name"), str):
            raise ValueError("source campaign variant lacks a name")
        variant_name = str(variant["name"])
        if variant_name in by_name:
            raise ValueError(f"duplicate source variant name: {variant_name}")
        by_name[variant_name] = variant
    completed = frozenset(completed_names)
    excluded = frozenset(excluded_names)
    unknown = (completed | excluded) - set(by_name)
    if unknown:
        raise ValueError(f"unknown campaign variant names: {sorted(unknown)}")
    overlap = completed & excluded
    if overlap:
        raise ValueError(f"completed variants cannot be excluded: {sorted(overlap)}")
    remaining = [
        copy.deepcopy(variant)
        for variant_name, variant in by_name.items()
        if variant_name not in completed and variant_name not in excluded
    ]
    if not remaining:
        raise ValueError("no campaign variants remain")
    for config in remaining:
        if bool(config.get("evaluate_test")):
            raise ValueError("resumed development campaign must remain test-blind")
        RunSpec.from_dict(config)
    return {
        "name": name,
        "run_root": run_root,
        "design": {
            "stage": "source_filtered_resume",
            "test_blind": True,
            "source_campaign": campaign.get("name"),
            "source_variant_count": len(variants),
            "completed_variant_count": len(completed),
            "runtime_gated_variant_count": len(excluded),
            "runtime_gated_variant_names": sorted(excluded),
            "remaining_variant_count": len(remaining),
            "incremental_receipts": True,
        },
        "base": {},
        "variants": remaining,
    }


def _ranked_factor_values(
    rows: Sequence[dict[str, Any]], key: str, *, limit: int
) -> list[Any]:
    best: dict[str, tuple[float, Any]] = {}
    for row in rows:
        config = row["config"]
        parameters = config.get("method_parameters", {})
        if key not in parameters:
            continue
        value = parameters[key]
        canonical = json.dumps(value, sort_keys=True)
        regret = float(row["validation_normalized_mean_regret"])
        incumbent = best.get(canonical)
        if incumbent is None or regret < incumbent[0]:
            best[canonical] = (regret, value)
    return [value for _, value in sorted(best.values())[:limit]]


def _conditional_barrier_config(
    base: dict[str, Any],
    benchmark: str,
    tag: str,
    updates: dict[str, Any],
) -> dict[str, Any]:
    config = copy.deepcopy(base)
    config["name"] = f"pubconditional_{_slug(benchmark)}_barrier_{tag}"
    config["evaluate_test"] = False
    config["method_parameters"].update(updates)
    return config


def build_conditional_tuning_campaign(
    rows: Iterable[dict[str, Any]],
    *,
    run_root: str,
) -> dict[str, Any]:
    """Retune material factors around each one-seed screening winner."""

    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    source_hashes: set[str] = set()
    existing_fingerprints: set[str] = set()
    for row in rows:
        if bool(row.get("test_evaluated")):
            raise ValueError("conditional tuning cannot consume test results")
        method = row.get("method")
        config = row.get("config")
        source = row.get("source_sha256")
        if not isinstance(config, dict):
            raise ValueError("development row lacks expanded config")
        benchmark = config.get("benchmark_id")
        if not isinstance(benchmark, str) or not isinstance(method, str):
            raise ValueError("development row lacks benchmark or method")
        route = _row_route_id(row, config)
        if not isinstance(source, str) or len(source) != 64:
            raise ValueError("development row lacks source hash")
        if method in CONDITIONAL_CORE_METHODS:
            grouped[(route, method)].append(row)
            existing_fingerprints.add(candidate_fingerprint(config))
        source_hashes.add(source)
    variants: list[dict[str, Any]] = []
    winners: list[dict[str, Any]] = []
    for (route, method), method_rows in sorted(grouped.items()):
        winner = min(
            method_rows,
            key=lambda row: (
                float(row["validation_normalized_mean_regret"]),
                str(row.get("run_directory", "")),
            ),
        )
        base = copy.deepcopy(winner["config"])
        benchmark = str(base["benchmark_id"])
        winners.append(
            {
                "benchmark_id": benchmark,
                "route_id": route,
                "family_id": benchmark_family_id(base),
                "method": method,
                "source_run_directory": winner.get("run_directory"),
                "source_validation_normalized_mean_regret": float(
                    winner["validation_normalized_mean_regret"]
                ),
                "source_candidate_fingerprint": candidate_fingerprint(base),
            }
        )
        train_size = int(base["sizes"]["train"])
        rate = float(base["training"]["learning_rate"])
        schedules = {
            str(base["training"].get("learning_rate_schedule", "constant")),
            "constant",
            "cosine",
        }
        for candidate_rate, batch, schedule in product(
            (rate / 3.0, rate, rate * 3.0),
            sorted({min(128, train_size), min(512, train_size), train_size}),
            sorted(schedules),
        ):
            config = copy.deepcopy(base)
            config["name"] = (
                f"pubconditional_{_slug(route)}_{_slug(method)}_optim_"
                f"lr{_slug(f'{candidate_rate:.8g}')}_b{batch}_{schedule}"
            )
            config["evaluate_test"] = False
            config["training"].update(
                {
                    "learning_rate": candidate_rate,
                    "batch_size": batch,
                    "learning_rate_schedule": schedule,
                }
            )
            variants.append(config)

        if method != "soft_radial_log_barrier":
            continue
        parameters = base["method_parameters"]

        alpha_grid = (0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0)
        scale_grid = (0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0)
        contraction_grid = ("rational", "exponential", "hyperbolic")
        minimum_grid = (0.001, 0.01, 0.05)
        for alpha in alpha_grid:
            variants.append(
                _conditional_barrier_config(
                    base,
                    route,
                    f"alpha{_slug(alpha)}",
                    {
                        "alpha_start": alpha,
                        "alpha_end": alpha,
                        "schedule": "fixed",
                    },
                )
            )
        for scale in scale_grid:
            variants.append(
                _conditional_barrier_config(
                    base,
                    route,
                    f"radius{_slug(scale)}",
                    {"contraction_scale": scale},
                )
            )
        for contraction in contraction_grid:
            variants.append(
                _conditional_barrier_config(
                    base,
                    route,
                    f"chart_{contraction}",
                    {"contraction": contraction},
                )
            )
        for minimum in minimum_grid:
            variants.append(
                _conditional_barrier_config(
                    base,
                    route,
                    f"minimum{_slug(minimum)}",
                    {"minimum_scale": minimum},
                )
            )

        top_alphas = _ranked_factor_values(method_rows, "alpha_start", limit=2)
        top_scales = _ranked_factor_values(
            method_rows, "contraction_scale", limit=2
        )
        top_contractions = _ranked_factor_values(
            method_rows, "contraction", limit=2
        )
        top_minima = _ranked_factor_values(
            method_rows, "minimum_scale", limit=2
        )
        for alpha, scale, contraction, minimum in product(
            top_alphas or [parameters["alpha_start"]],
            top_scales or [parameters["contraction_scale"]],
            top_contractions or [parameters["contraction"]],
            top_minima or [parameters["minimum_scale"]],
        ):
            variants.append(
                _conditional_barrier_config(
                    base,
                    route,
                    (
                        f"interaction_a{_slug(alpha)}_r{_slug(scale)}_"
                        f"{contraction}_m{_slug(minimum)}"
                    ),
                    {
                        "alpha_start": alpha,
                        "alpha_end": alpha,
                        "schedule": "fixed",
                        "contraction_scale": scale,
                        "contraction": contraction,
                        "minimum_scale": minimum,
                    },
                )
            )
        for start, end in product((1.0, 3.0, 10.0), (0.03, 0.1)):
            variants.append(
                _conditional_barrier_config(
                    base,
                    route,
                    f"homotopy{_slug(start)}to{_slug(end)}",
                    {
                        "alpha_start": start,
                        "alpha_end": end,
                        "schedule": "geometric",
                        "anneal_fraction": 0.75,
                    },
                )
            )
    variants = [
        config
        for config in _deduplicate_configs(variants)
        if candidate_fingerprint(config) not in existing_fingerprints
    ]
    if not variants:
        raise ValueError("no conditional tuning candidates were supplied")
    return {
        "name": "publication_conditional_validation_tuning",
        "run_root": run_root,
        "design": {
            "stage": "conditional_validation_tuning",
            "test_blind": True,
            "selection_metric": "validation_normalized_mean_regret",
            "optimizer_grid_centered_on_screening_winner": True,
            "barrier_factor_grid_uses_winning_optimizer": True,
            "barrier_top_two_factor_interactions": True,
            "source_sha256_values": sorted(source_hashes),
            "screening_winners": winners,
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def build_refinement_campaign(
    rows: Iterable[dict[str, Any]],
    *,
    run_root: str,
    top_k: int = 3,
    seed_bundles: Sequence[dict[str, int]] = DEVELOPMENT_SEED_BUNDLES,
    workers_override: int | None = None,
    preserve_data_seed_benchmarks: Collection[str] = (),
) -> dict[str, Any]:
    """Promote the top validation arms into a paired multi-seed campaign."""

    if top_k <= 0:
        raise ValueError("top_k must be positive")
    if not seed_bundles:
        raise ValueError("at least one refinement seed is required")
    if workers_override is not None and workers_override <= 0:
        raise ValueError("workers_override must be positive")
    fixed_data_benchmarks = frozenset(preserve_data_seed_benchmarks)
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    source_hashes: set[str] = set()
    for row in rows:
        if bool(row.get("test_evaluated")):
            raise ValueError("development promotion cannot consume test results")
        method = row.get("method")
        config = row.get("config")
        regret = row.get("validation_normalized_mean_regret")
        source_hash = row.get("source_sha256")
        if not isinstance(config, dict):
            raise ValueError("development row lacks expanded config")
        benchmark = config.get("benchmark_id")
        if not isinstance(benchmark, str) or not isinstance(method, str):
            raise ValueError("development row lacks benchmark or method")
        route = _row_route_id(row, config)
        if not isinstance(regret, (int, float)) or isinstance(regret, bool):
            raise ValueError("development row lacks validation regret")
        if not isinstance(source_hash, str) or len(source_hash) != 64:
            raise ValueError("development row lacks source hash")
        source_hashes.add(source_hash)
        grouped[(route, method)].append(row)

    variants: list[dict[str, Any]] = []
    promoted: list[dict[str, Any]] = []
    encountered_benchmarks: set[str] = set()
    for (route, method), candidates in sorted(grouped.items()):
        unique: dict[str, dict[str, Any]] = {}
        for candidate in candidates:
            fingerprint = candidate_fingerprint(candidate["config"])
            incumbent = unique.get(fingerprint)
            if incumbent is None or float(
                candidate["validation_normalized_mean_regret"]
            ) < float(incumbent["validation_normalized_mean_regret"]):
                unique[fingerprint] = candidate
        ordered = sorted(
            unique.values(),
            key=lambda row: (
                float(row["validation_normalized_mean_regret"]),
                str(row.get("run_directory", "")),
            ),
        )[:top_k]
        for rank, row in enumerate(ordered, start=1):
            base = copy.deepcopy(row["config"])
            benchmark = str(base["benchmark_id"])
            encountered_benchmarks.add(benchmark)
            fingerprint = candidate_fingerprint(base)
            promoted.append(
                {
                    "benchmark_id": benchmark,
                    "route_id": route,
                    "family_id": benchmark_family_id(base),
                    "method": method,
                    "candidate_rank": rank,
                    "candidate_fingerprint": fingerprint,
                    "screening_validation_normalized_mean_regret": float(
                        row["validation_normalized_mean_regret"]
                    ),
                    "source_run_directory": row.get("run_directory"),
                    "source_sha256": row["source_sha256"],
                }
            )
            structural_seed = int(base["seeds"]["structural"])
            for seed_index, bundle in enumerate(seed_bundles, start=1):
                config = copy.deepcopy(base)
                config["name"] = (
                    f"pubrefine_{_slug(route)}_{_slug(method)}_"
                    f"c{rank}_{fingerprint}_seed{seed_index}"
                )
                config["evaluate_test"] = False
                if workers_override is not None:
                    config["workers"] = workers_override
                config["seeds"] = {
                    "data": (
                        int(base["seeds"]["data"])
                        if benchmark in fixed_data_benchmarks
                        else int(bundle["data"])
                    ),
                    "structural": structural_seed,
                    "initialization": int(bundle["initialization"]),
                    "shuffle": int(bundle["shuffle"]),
                    "perturbation": int(bundle["perturbation"]),
                }
                RunSpec.from_dict(config)
                variants.append(config)
    unknown_fixed = fixed_data_benchmarks - encountered_benchmarks
    if unknown_fixed:
        raise ValueError(
            "preserve-data-seed benchmarks were not present: "
            + ", ".join(sorted(unknown_fixed))
        )
    if not variants:
        raise ValueError("no development candidates were supplied")
    return {
        "name": "publication_paired_validation_refinement",
        "run_root": run_root,
        "design": {
            "stage": "paired_validation_refinement",
            "test_blind": True,
            "top_k_per_benchmark_method": top_k,
            "paired_seed_count": len(seed_bundles),
            "selection_metric": "mean_validation_normalized_mean_regret",
            "source_sha256_values": sorted(source_hashes),
            "workers_override": workers_override,
            "preserve_data_seed_benchmarks": sorted(fixed_data_benchmarks),
            "promoted_candidates": promoted,
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def _validation_curve(run_directory: Path) -> dict[int, float]:
    path = run_directory / "learning_curve.jsonl"
    if not path.is_file():
        raise FileNotFoundError(path)
    result: dict[int, float] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        record = json.loads(line)
        validation = record.get("validation")
        epoch = record.get("epoch")
        if not isinstance(validation, dict) or not isinstance(epoch, int):
            continue
        value = validation.get("normalized_mean_regret")
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise ValueError(f"invalid validation record in {path}")
        if not math.isfinite(float(value)):
            raise ValueError(f"non-finite validation record in {path}")
        result[epoch] = float(value)
    if not result:
        raise ValueError(f"no validation curve in {path}")
    return result


def _aggregate_horizon(
    rows: Sequence[dict[str, Any]],
) -> tuple[int | None, list[dict[str, Any]]]:
    curves = [
        _validation_curve(Path(str(row["run_directory"]))) for row in rows
    ]
    common = set(curves[0])
    for curve in curves[1:]:
        common &= set(curve)
    common.discard(0)
    if not common:
        return None, []
    aggregates = [
        {
            "epoch": epoch,
            "mean_validation_normalized_mean_regret": fmean(
                curve[epoch] for curve in curves
            ),
            "population_standard_deviation": pstdev(
                curve[epoch] for curve in curves
            ),
        }
        for epoch in sorted(common)
    ]
    selected = min(
        aggregates,
        key=lambda row: (
            float(row["mean_validation_normalized_mean_regret"]),
            int(row["epoch"]),
        ),
    )
    return int(selected["epoch"]), aggregates


def build_confirmation_campaign(
    rows: Iterable[dict[str, Any]],
    *,
    run_root: str,
    required_refinement_seeds: int = 3,
    seed_bundles: Sequence[dict[str, int]] = CONFIRMATION_SEED_BUNDLES,
    minimum_test_size: int | None = None,
    test_to_validation_ratio: float | None = None,
    maximum_test_size_by_benchmark: Mapping[str, int] | None = None,
) -> dict[str, Any]:
    """Freeze validation-selected arms and emit paired test confirmations."""

    if required_refinement_seeds <= 0:
        raise ValueError("required refinement seeds must be positive")
    if not seed_bundles:
        raise ValueError("at least one confirmation seed is required")
    if minimum_test_size is not None and minimum_test_size <= 0:
        raise ValueError("minimum test size must be positive")
    if test_to_validation_ratio is not None and test_to_validation_ratio <= 0.0:
        raise ValueError("test-to-validation ratio must be positive")
    test_size_caps = dict(maximum_test_size_by_benchmark or {})
    if any(value <= 0 for value in test_size_caps.values()):
        raise ValueError("maximum test sizes must be positive")
    grouped: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    source_hashes: set[str] = set()
    for row in rows:
        if bool(row.get("test_evaluated")):
            raise ValueError("confirmation selection cannot consume test results")
        config = row.get("config")
        method = row.get("method")
        source_hash = row.get("source_sha256")
        if not isinstance(config, dict):
            raise ValueError("refinement row lacks expanded config")
        benchmark = config.get("benchmark_id")
        if not isinstance(benchmark, str) or not isinstance(method, str):
            raise ValueError("refinement row lacks benchmark or method")
        if not isinstance(source_hash, str) or len(source_hash) != 64:
            raise ValueError("refinement row lacks source hash")
        fingerprint = candidate_fingerprint(config)
        route = _row_route_id(row, config)
        grouped[(route, method, fingerprint)].append(row)
        source_hashes.add(source_hash)
    if not grouped:
        raise ValueError("no refinement candidates were supplied")

    candidates_by_method: dict[
        tuple[str, str], list[dict[str, Any]]
    ] = defaultdict(list)
    paired_seed_sets: dict[
        str, set[tuple[tuple[tuple[str, int], ...], ...]]
    ] = defaultdict(set)
    for (route, method, fingerprint), candidate_rows in sorted(grouped.items()):
        seed_keys = {
            tuple(
                sorted(
                    (str(key), int(value))
                    for key, value in dict(row["config"]["seeds"]).items()
                )
            )
            for row in candidate_rows
        }
        if (
            len(candidate_rows) != required_refinement_seeds
            or len(seed_keys) != required_refinement_seeds
        ):
            raise ValueError(
                f"incomplete refinement candidate {route}/{method}/{fingerprint}: "
                f"expected {required_refinement_seeds} distinct seeds, "
                f"found {len(seed_keys)}"
            )
        paired_seed_sets[route].add(tuple(sorted(seed_keys)))
        regrets = [
            float(row["validation_normalized_mean_regret"])
            for row in candidate_rows
        ]
        if not all(math.isfinite(value) for value in regrets):
            raise ValueError("non-finite refinement validation regret")
        base_config = candidate_rows[0]["config"]
        candidates_by_method[(route, method)].append(
            {
                "benchmark_id": base_config["benchmark_id"],
                "route_id": route,
                "family_id": benchmark_family_id(base_config),
                "method": method,
                "candidate_fingerprint": fingerprint,
                "mean_validation_normalized_mean_regret": fmean(regrets),
                "population_standard_deviation": pstdev(regrets),
                "rows": candidate_rows,
            }
        )
    for route, seed_sets in paired_seed_sets.items():
        if len(seed_sets) != 1:
            raise ValueError(
                f"refinement candidates are not paired on {route}"
            )

    variants: list[dict[str, Any]] = []
    selections: list[dict[str, Any]] = []
    encountered_benchmarks: set[str] = set()
    for (route, method), candidates in sorted(candidates_by_method.items()):
        winner = min(
            candidates,
            key=lambda candidate: (
                float(candidate["mean_validation_normalized_mean_regret"]),
                str(candidate["candidate_fingerprint"]),
            ),
        )
        winner_rows = list(winner["rows"])
        selected_horizon, horizon_curve = _aggregate_horizon(winner_rows)
        base = copy.deepcopy(winner_rows[0]["config"])
        benchmark = str(base["benchmark_id"])
        encountered_benchmarks.add(benchmark)
        refinement_data_seeds = {
            int(row["config"]["seeds"]["data"]) for row in winner_rows
        }
        preserve_data_seed = len(refinement_data_seeds) == 1
        structural_seed = int(base["seeds"]["structural"])
        original_horizon = int(base["training"]["epochs"])
        selections.append(
            {key: value for key, value in winner.items() if key != "rows"}
            | {
                "selected_horizon": selected_horizon,
                "schedule_reference_horizon": original_horizon,
                "preserve_refinement_data_seed": preserve_data_seed,
                "horizon_validation_curve": horizon_curve,
                "source_run_directories": sorted(
                    str(row["run_directory"]) for row in winner_rows
                ),
            }
        )
        for seed_index, bundle in enumerate(seed_bundles, start=1):
            config = copy.deepcopy(base)
            config["name"] = (
                f"pubconfirm_{_slug(route)}_{_slug(method)}_"
                f"{winner['candidate_fingerprint']}_seed{seed_index}"
            )
            config["evaluate_test"] = True
            config["seeds"] = {
                "data": (
                    int(base["seeds"]["data"])
                    if preserve_data_seed
                    else int(bundle["data"])
                ),
                "structural": structural_seed,
                "initialization": int(bundle["initialization"]),
                "shuffle": int(bundle["shuffle"]),
                "perturbation": int(bundle["perturbation"]),
            }
            sizes = config["sizes"]
            confirmation_test_size = int(sizes["test"])
            if minimum_test_size is not None:
                confirmation_test_size = max(
                    confirmation_test_size, minimum_test_size
                )
            if test_to_validation_ratio is not None:
                confirmation_test_size = max(
                    confirmation_test_size,
                    math.ceil(
                        test_to_validation_ratio * int(sizes["validation"])
                    ),
                )
            if benchmark in test_size_caps:
                confirmation_test_size = min(
                    confirmation_test_size, test_size_caps[benchmark]
                )
            sizes["test"] = confirmation_test_size
            if selected_horizon is not None:
                training = config["training"]
                training["epochs"] = selected_horizon
                training["schedule_reference_epochs"] = original_horizon
                training["selection_mode"] = "last"
                training["validation_interval"] = selected_horizon
                training["validation_epochs"] = [selected_horizon]
                training["patience"] = selected_horizon + 1
            RunSpec.from_dict(config)
            variants.append(config)
    unknown_caps = set(test_size_caps) - encountered_benchmarks
    if unknown_caps:
        raise ValueError(
            "maximum-test-size benchmarks were not present: "
            + ", ".join(sorted(unknown_caps))
        )
    return {
        "name": "publication_paired_test_confirmation",
        "run_root": run_root,
        "design": {
            "stage": "paired_test_confirmation",
            "selection_used_test": False,
            "test_evaluation": True,
            "paired_confirmation_seed_count": len(seed_bundles),
            "required_refinement_seed_count": required_refinement_seeds,
            "fixed_training_horizons": True,
            "schedule_paths_preserved": True,
            "minimum_test_size": minimum_test_size,
            "test_to_validation_ratio": test_to_validation_ratio,
            "maximum_test_size_by_benchmark": dict(sorted(test_size_caps.items())),
            "source_sha256_values": sorted(source_hashes),
            "selected_candidates": selections,
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }
