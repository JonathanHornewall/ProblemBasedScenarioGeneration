"""Raw-regret protocol for the zero-scale analytic skew stress test.

The analytic scalar box has zero Bayes/reference regret, so normalized regret
is undefined by construction.  This module keeps that route separate from the
ordinary publication selector: it uses final-epoch *raw* validation regret,
freezes ``selection_mode=last``, and reports raw test regret without inventing
an arbitrary normalizer.  The last-epoch rule is essential because the stress
test is about the population behavior of the trained surrogate; validation
early stopping at the initialization checkpoint would merely recover the
initial policy and hide the known SPO+ inconsistency.
"""

from __future__ import annotations

import copy
import json
import math
from collections import defaultdict
from collections.abc import Iterable, Sequence
from pathlib import Path
from statistics import fmean, median, pstdev, stdev
from typing import Any

from scipy import stats

from .config import RunSpec
from .experiment_identity import benchmark_family_id, experimental_route_id
from .publication_selection import (
    CONFIRMATION_SEED_BUNDLES,
    DEVELOPMENT_SEED_BUNDLES,
    candidate_fingerprint,
)

SKEW_BENCHMARK_ID = "analytic.scalar_box"
SKEW_NOISE = "skewed_failure"


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object at {path}")
    return payload


def _is_frozen_skew(config: dict[str, Any]) -> bool:
    law = config.get("law")
    return (
        config.get("benchmark_id") == SKEW_BENCHMARK_ID
        and isinstance(law, dict)
        and law.get("noise") == SKEW_NOISE
    )


def _clean_environment(
    directory: Path,
    *,
    required_sources: frozenset[str] | None,
) -> str | None:
    environment = _object(directory / "environment.json")
    if environment.get("git_dirty") is not False:
        raise ValueError(f"run was not clean: {directory}")
    source = environment.get("source_sha256")
    if not isinstance(source, str) or len(source) != 64:
        raise ValueError(f"run lacks source hash: {directory}")
    if required_sources is not None and source not in required_sources:
        return None
    return source


def _final_validation(directory: Path, expected_epoch: int) -> dict[str, Any]:
    path = directory / "learning_curve.jsonl"
    if not path.is_file():
        raise FileNotFoundError(path)
    records: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        payload = json.loads(line)
        if (
            isinstance(payload, dict)
            and isinstance(payload.get("epoch"), int)
            and isinstance(payload.get("validation"), dict)
        ):
            records.append(payload)
    if not records:
        raise ValueError(f"no validation records in {path}")
    record = max(records, key=lambda item: int(item["epoch"]))
    if int(record["epoch"]) != expected_epoch:
        raise ValueError(
            f"final validation epoch mismatch in {path}: expected "
            f"{expected_epoch}, found {record['epoch']}"
        )
    validation = record["validation"]
    regret = validation.get("mean_regret")
    if (
        not isinstance(regret, (int, float))
        or isinstance(regret, bool)
        or not math.isfinite(float(regret))
    ):
        raise ValueError(f"invalid raw validation regret in {path}")
    if validation.get("normalized_mean_regret") is not None:
        raise ValueError(f"analytic zero-scale route unexpectedly normalized: {path}")
    return {
        "epoch": int(record["epoch"]),
        "mean_regret": float(regret),
        "sample_count": int(validation["sample_count"]),
    }


def completed_frozen_skew_development_rows(
    run_roots: Iterable[Path],
    *,
    required_source_sha256: Iterable[str] | None = None,
) -> list[dict[str, Any]]:
    """Read clean development runs using final-epoch raw validation regret."""

    required_sources = (
        None if required_source_sha256 is None else frozenset(required_source_sha256)
    )
    if required_sources is not None and (
        not required_sources or any(len(source) != 64 for source in required_sources)
    ):
        raise ValueError("required sources must be nonempty SHA-256 strings")
    rows: list[dict[str, Any]] = []
    seen: set[Path] = set()
    for root in run_roots:
        resolved_root = Path(root).resolve()
        if not resolved_root.is_dir():
            raise FileNotFoundError(resolved_root)
        for directory in sorted(
            path for path in resolved_root.iterdir() if path.is_dir()
        ):
            resolved = directory.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            required = [
                directory / "status.json",
                directory / "config.json",
                directory / "environment.json",
                directory / "summary.json",
                directory / "learning_curve.jsonl",
            ]
            if not all(path.is_file() for path in required):
                continue
            status = _object(directory / "status.json")
            if status.get("status") != "complete":
                continue
            config = _object(directory / "config.json")
            if not _is_frozen_skew(config):
                continue
            source = _clean_environment(directory, required_sources=required_sources)
            if source is None:
                continue
            summary = _object(directory / "summary.json")
            if summary.get("test") is not None:
                raise ValueError(f"development run evaluated test: {directory}")
            expected_epoch = (
                0 if config["method"] == "knn" else int(config["training"]["epochs"])
            )
            final = _final_validation(directory, expected_epoch)
            rows.append(
                {
                    "benchmark_id": config["benchmark_id"],
                    "route_id": experimental_route_id(config),
                    "family_id": benchmark_family_id(config),
                    "method": config["method"],
                    "config": config,
                    "candidate_fingerprint": candidate_fingerprint(config),
                    "final_validation_mean_regret": final["mean_regret"],
                    "final_validation_epoch": final["epoch"],
                    "training_wall_seconds": float(
                        summary.get(
                            "whole_pipeline_training_wall_seconds",
                            summary["training_wall_seconds"],
                        )
                    ),
                    "run_directory": str(directory),
                    "source_sha256": source,
                }
            )
    if not rows:
        raise ValueError("no completed frozen-skew development runs found")
    routes = {str(row["route_id"]) for row in rows}
    if len(routes) != 1:
        raise ValueError(f"expected one frozen-skew route, found {sorted(routes)}")
    return rows


def _last_epoch_config(config: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(config)
    epochs = int(result["training"]["epochs"])
    result["training"].update(
        {
            "selection_mode": "last",
            "validation_interval": epochs,
            "validation_epochs": [epochs],
            "patience": epochs + 1,
        }
    )
    return result


def build_frozen_skew_refinement_campaign(
    rows: Iterable[dict[str, Any]],
    *,
    run_root: str,
    top_k: int = 3,
    seed_bundles: Sequence[dict[str, int]] = DEVELOPMENT_SEED_BUNDLES,
) -> dict[str, Any]:
    """Promote final-epoch raw-regret candidates to paired validation."""

    if top_k <= 0 or not seed_bundles:
        raise ValueError("top_k and seed bundles must be nonempty")
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    source_hashes: set[str] = set()
    for row in rows:
        method = row.get("method")
        if not isinstance(method, str):
            raise ValueError("frozen-skew row lacks method")
        grouped[method].append(row)
        source_hashes.add(str(row["source_sha256"]))
    variants: list[dict[str, Any]] = []
    promoted: list[dict[str, Any]] = []
    for method, candidates in sorted(grouped.items()):
        ordered = sorted(
            candidates,
            key=lambda row: (
                float(row["final_validation_mean_regret"]),
                str(row["candidate_fingerprint"]),
            ),
        )[:top_k]
        for rank, row in enumerate(ordered, start=1):
            base = _last_epoch_config(row["config"])
            emitted_fingerprint = candidate_fingerprint(base)
            promoted.append(
                {
                    "method": method,
                    "rank": rank,
                    "source_candidate_fingerprint": row["candidate_fingerprint"],
                    "emitted_candidate_fingerprint": emitted_fingerprint,
                    "source_final_validation_mean_regret": row[
                        "final_validation_mean_regret"
                    ],
                    "source_run_directory": row["run_directory"],
                }
            )
            for seed_index, bundle in enumerate(seed_bundles, start=1):
                config = copy.deepcopy(base)
                config["name"] = (
                    f"pubskewrefine_{method}_c{rank}_{emitted_fingerprint}_"
                    f"seed{seed_index}"
                )
                config["evaluate_test"] = False
                config["seeds"] = {
                    "data": int(bundle["data"]),
                    "structural": int(base["seeds"]["structural"]),
                    "initialization": int(bundle["initialization"]),
                    "shuffle": int(bundle["shuffle"]),
                    "perturbation": int(bundle["perturbation"]),
                }
                RunSpec.from_dict(config)
                variants.append(config)
    if not variants:
        raise ValueError("no frozen-skew refinement variants were emitted")
    return {
        "name": "publication_frozen_skew_paired_refinement",
        "run_root": run_root,
        "design": {
            "stage": "paired_validation_refinement",
            "test_blind": True,
            "selection_metric": "final_validation_mean_regret",
            "normalization": "none_zero_reference_scale",
            "selection_mode": "last",
            "top_k_per_method": top_k,
            "paired_seed_count": len(seed_bundles),
            "source_sha256_values": sorted(source_hashes),
            "promoted_candidates": promoted,
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def _completed_frozen_skew_refinement_rows(
    run_roots: Iterable[Path],
) -> list[dict[str, Any]]:
    rows = completed_frozen_skew_development_rows(run_roots)
    for row in rows:
        config = row["config"]
        if config["training"].get("selection_mode") != "last":
            raise ValueError("frozen-skew refinement must use selection_mode=last")
        summary = _object(Path(str(row["run_directory"])) / "summary.json")
        expected_epoch = (
            0 if config["method"] == "knn" else int(config["training"]["epochs"])
        )
        if int(summary["best_epoch"]) != expected_epoch:
            raise ValueError("frozen-skew refinement did not retain final epoch")
    return rows


def build_frozen_skew_confirmation_campaign(
    run_roots: Iterable[Path],
    *,
    run_root: str,
    required_refinement_seeds: int = 3,
    seed_bundles: Sequence[dict[str, int]] = CONFIRMATION_SEED_BUNDLES,
    test_size: int = 16_384,
) -> dict[str, Any]:
    """Freeze paired raw-regret winners and emit final test runs."""

    if required_refinement_seeds <= 0 or not seed_bundles or test_size <= 0:
        raise ValueError("invalid confirmation protocol")
    rows = _completed_frozen_skew_refinement_rows(run_roots)
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    source_hashes: set[str] = set()
    for row in rows:
        grouped[(str(row["method"]), str(row["candidate_fingerprint"]))].append(row)
        source_hashes.add(str(row["source_sha256"]))
    by_method: dict[str, list[dict[str, Any]]] = defaultdict(list)
    common_seed_sets: set[tuple[tuple[tuple[str, int], ...], ...]] = set()
    for (method, fingerprint), candidate_rows in sorted(grouped.items()):
        seed_keys = {
            tuple(
                sorted(
                    (str(key), int(value))
                    for key, value in row["config"]["seeds"].items()
                )
            )
            for row in candidate_rows
        }
        if (
            len(candidate_rows) != required_refinement_seeds
            or len(seed_keys) != required_refinement_seeds
        ):
            raise ValueError(f"incomplete frozen-skew candidate {method}/{fingerprint}")
        common_seed_sets.add(tuple(sorted(seed_keys)))
        regrets = [float(row["final_validation_mean_regret"]) for row in candidate_rows]
        by_method[method].append(
            {
                "method": method,
                "candidate_fingerprint": fingerprint,
                "mean_validation_mean_regret": fmean(regrets),
                "population_standard_deviation": pstdev(regrets),
                "rows": candidate_rows,
            }
        )
    if len(common_seed_sets) != 1:
        raise ValueError("frozen-skew refinement candidates are not paired")
    variants: list[dict[str, Any]] = []
    selections: list[dict[str, Any]] = []
    for method, candidates in sorted(by_method.items()):
        winner = min(
            candidates,
            key=lambda candidate: (
                float(candidate["mean_validation_mean_regret"]),
                str(candidate["candidate_fingerprint"]),
            ),
        )
        winner_rows = list(winner["rows"])
        base = _last_epoch_config(winner_rows[0]["config"])
        selections.append(
            {key: value for key, value in winner.items() if key != "rows"}
            | {
                "training_horizon": int(base["training"]["epochs"]),
                "source_run_directories": sorted(
                    str(row["run_directory"]) for row in winner_rows
                ),
            }
        )
        for seed_index, bundle in enumerate(seed_bundles, start=1):
            config = copy.deepcopy(base)
            config["name"] = (
                f"pubskewconfirm_{method}_{winner['candidate_fingerprint']}_"
                f"seed{seed_index}"
            )
            config["evaluate_test"] = True
            config["sizes"]["test"] = int(test_size)
            config["seeds"] = {
                "data": int(bundle["data"]),
                "structural": int(base["seeds"]["structural"]),
                "initialization": int(bundle["initialization"]),
                "shuffle": int(bundle["shuffle"]),
                "perturbation": int(bundle["perturbation"]),
            }
            RunSpec.from_dict(config)
            variants.append(config)
    return {
        "name": "publication_frozen_skew_paired_test_confirmation",
        "run_root": run_root,
        "design": {
            "stage": "paired_test_confirmation",
            "selection_used_test": False,
            "test_evaluation": True,
            "selection_metric": "mean_final_validation_mean_regret",
            "reporting_metric": "test_mean_regret",
            "normalization": "none_zero_reference_scale",
            "selection_mode": "last",
            "fixed_training_horizons": True,
            "required_refinement_seed_count": required_refinement_seeds,
            "paired_confirmation_seed_count": len(seed_bundles),
            "test_size": test_size,
            "source_sha256_values": sorted(source_hashes),
            "selected_candidates": selections,
            "incremental_receipts": True,
        },
        "base": {},
        "variants": variants,
    }


def _mean_interval(values: Sequence[float]) -> dict[str, float | int]:
    if not values:
        raise ValueError("cannot summarize empty values")
    deviation = 0.0 if len(values) == 1 else stdev(values)
    half_width = (
        0.0
        if len(values) == 1
        else float(stats.t.ppf(0.975, len(values) - 1))
        * deviation
        / math.sqrt(len(values))
    )
    mean = fmean(values)
    return {
        "count": len(values),
        "mean": mean,
        "median": median(values),
        "sample_standard_deviation": deviation,
        "ci95_lower": mean - half_width,
        "ci95_upper": mean + half_width,
    }


def summarize_frozen_skew_confirmation(
    run_roots: Iterable[Path],
    *,
    target_method: str = "soft_radial_log_barrier",
    required_seed_count: int = 10,
) -> dict[str, Any]:
    """Summarize the sealed skew test using paired raw regret."""

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    source_hashes: set[str] = set()
    for root in run_roots:
        resolved_root = Path(root).resolve()
        if not resolved_root.is_dir():
            raise FileNotFoundError(resolved_root)
        for directory in sorted(
            path for path in resolved_root.iterdir() if path.is_dir()
        ):
            required = [
                directory / "status.json",
                directory / "config.json",
                directory / "environment.json",
                directory / "summary.json",
            ]
            if not all(path.is_file() for path in required):
                continue
            if _object(directory / "status.json").get("status") != "complete":
                continue
            config = _object(directory / "config.json")
            if not _is_frozen_skew(config):
                continue
            if config["training"].get("selection_mode") != "last":
                raise ValueError("skew confirmation did not freeze final epoch")
            source = _clean_environment(directory, required_sources=None)
            assert source is not None
            source_hashes.add(source)
            summary = _object(directory / "summary.json")
            test = summary.get("test")
            if not isinstance(test, dict):
                raise ValueError(f"skew confirmation lacks test: {directory}")
            if test.get("normalized_mean_regret") is not None:
                raise ValueError("skew confirmation unexpectedly has a normalizer")
            regret = test.get("mean_regret")
            if (
                not isinstance(regret, (int, float))
                or isinstance(regret, bool)
                or not math.isfinite(float(regret))
            ):
                raise ValueError(f"invalid skew test regret: {directory}")
            if int(test["sample_count"]) != int(config["sizes"]["test"]):
                raise ValueError(f"skew test size mismatch: {directory}")
            method = str(config["method"])
            oracle = summary.get(
                "whole_pipeline_training_oracle_stats",
                summary.get("total_training_oracle_stats", {}),
            )
            grouped[method].append(
                {
                    "seed_key": tuple(
                        sorted(
                            (str(key), int(value))
                            for key, value in config["seeds"].items()
                        )
                    ),
                    "regret": float(regret),
                    "training_wall_seconds": float(
                        summary.get(
                            "whole_pipeline_training_wall_seconds",
                            summary["training_wall_seconds"],
                        )
                    ),
                    "training_oracle_calls": float(oracle.get("calls", 0)),
                    "run_directory": str(directory),
                }
            )
    if not grouped:
        raise ValueError("no complete frozen-skew confirmation runs found")
    seed_sets: set[tuple[tuple[tuple[str, int], ...], ...]] = set()
    methods: list[dict[str, Any]] = []
    raw_by_method: dict[str, list[float]] = {}
    for method, rows in sorted(grouped.items()):
        keys = [row["seed_key"] for row in rows]
        if len(rows) != required_seed_count or len(set(keys)) != required_seed_count:
            raise ValueError(f"incomplete skew confirmation for {method}")
        ordered = sorted(rows, key=lambda row: row["seed_key"])
        seed_sets.add(tuple(row["seed_key"] for row in ordered))
        regrets = [float(row["regret"]) for row in ordered]
        raw_by_method[method] = regrets
        methods.append(
            {
                "method": method,
                "raw_mean_regret": _mean_interval(regrets),
                "training_wall_seconds": _mean_interval(
                    [float(row["training_wall_seconds"]) for row in ordered]
                ),
                "training_oracle_calls": _mean_interval(
                    [float(row["training_oracle_calls"]) for row in ordered]
                ),
                "run_directories": [row["run_directory"] for row in ordered],
            }
        )
    if len(seed_sets) != 1:
        raise ValueError("skew confirmation methods are not paired")
    methods.sort(
        key=lambda row: (float(row["raw_mean_regret"]["mean"]), str(row["method"]))
    )
    comparisons: list[dict[str, Any]] = []
    target = raw_by_method.get(target_method)
    if target is not None:
        for method, values in sorted(raw_by_method.items()):
            if method == target_method:
                continue
            differences = [
                left - right for left, right in zip(target, values, strict=True)
            ]
            pvalue = (
                1.0
                if all(abs(value) <= 1e-15 for value in differences)
                else float(stats.wilcoxon(differences, zero_method="pratt").pvalue)
            )
            comparisons.append(
                {
                    "target_method": target_method,
                    "comparator_method": method,
                    "difference_definition": "target_minus_comparator",
                    "difference": _mean_interval(differences),
                    "target_wins": sum(value < -1e-12 for value in differences),
                    "ties": sum(abs(value) <= 1e-12 for value in differences),
                    "target_losses": sum(value > 1e-12 for value in differences),
                    "pvalue_raw": pvalue,
                }
            )
    holm_order = sorted(
        enumerate(comparisons), key=lambda item: float(item[1]["pvalue_raw"])
    )
    running = 0.0
    for rank, (index, comparison) in enumerate(holm_order):
        adjusted = min(
            1.0,
            (len(holm_order) - rank) * float(comparison["pvalue_raw"]),
        )
        running = max(running, adjusted)
        comparisons[index]["pvalue_holm"] = running
    return {
        "status": "paired_test_confirmation",
        "benchmark_id": SKEW_BENCHMARK_ID,
        "route_id": experimental_route_id(
            _object(Path(methods[0]["run_directories"][0]) / "config.json")
        ),
        "selection_used_test": False,
        "selection_metric": "final_validation_mean_regret",
        "reporting_metric": "test_mean_regret",
        "normalization": "none_zero_reference_scale",
        "selection_mode": "last",
        "required_seed_count": required_seed_count,
        "completed_run_count": sum(len(rows) for rows in grouped.values()),
        "source_sha256_values": sorted(source_hashes),
        "winner_by_mean_raw_regret": methods[0]["method"],
        "methods": methods,
        "paired_target_comparisons": comparisons,
    }


def render_frozen_skew_markdown(summary: dict[str, Any]) -> str:
    lines = [
        "# Frozen analytic skew confirmation",
        "",
        (
            f"{summary['completed_run_count']} clean test runs with "
            f"{summary['required_seed_count']} paired seeds per method. Raw regret "
            "is reported because the Bayes/reference regret scale is zero."
        ),
        "",
        "| Rank | Method | Mean raw regret | 95% CI | Train s | Oracle calls |",
        "|---:|---|---:|---:|---:|---:|",
    ]
    for rank, method in enumerate(summary["methods"], start=1):
        regret = method["raw_mean_regret"]
        lines.append(
            "| {rank} | {method} | {mean:.6g} | [{lower:.6g}, {upper:.6g}] | "
            "{seconds:.3f} | {calls:.1f} |".format(
                rank=rank,
                method=method["method"],
                mean=regret["mean"],
                lower=regret["ci95_lower"],
                upper=regret["ci95_upper"],
                seconds=method["training_wall_seconds"]["mean"],
                calls=method["training_oracle_calls"]["mean"],
            )
        )
    lines.extend(
        [
            "",
            "## Evidence boundary",
            "",
            "- Candidate selection used final-epoch raw validation regret only.",
            "- Training horizons and last-epoch deployment were frozen before test.",
            "- No arbitrary normalization was introduced for the zero-scale route.",
            "",
        ]
    )
    return "\n".join(lines)
