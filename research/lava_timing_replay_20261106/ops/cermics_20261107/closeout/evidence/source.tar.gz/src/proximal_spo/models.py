"""Small, explicit neural predictors used by every method."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
from torch import nn


@dataclass(frozen=True)
class ModelSpec:
    width: int = 64
    depth: int = 2
    activation: str = "silu"
    layer_norm: bool = False
    correction_width: int | None = None
    correction_depth: int | None = None
    dtype: str = "float64"

    def __post_init__(self) -> None:
        if self.width <= 0 or self.depth < 0:
            raise ValueError("width must be positive and depth nonnegative")
        if self.correction_width is not None and self.correction_width <= 0:
            raise ValueError("correction_width must be positive")
        if self.correction_depth is not None and self.correction_depth < 0:
            raise ValueError("correction_depth must be nonnegative")
        if self.activation not in {"relu", "silu", "tanh", "gelu"}:
            raise ValueError("unsupported activation")
        if self.dtype not in {"float32", "float64"}:
            raise ValueError("dtype must be float32 or float64")


def torch_dtype(name: str) -> torch.dtype:
    if name == "float32":
        return torch.float32
    if name == "float64":
        return torch.float64
    raise ValueError(f"unsupported floating dtype {name!r}")


def module_dtype(model: nn.Module) -> torch.dtype:
    """Return the floating dtype expected by a model's inputs."""

    for tensor in (*model.parameters(), *model.buffers()):
        if tensor.is_floating_point():
            return tensor.dtype
    return torch.float64


def _activation(name: str) -> nn.Module:
    if name == "relu":
        return nn.ReLU()
    if name == "silu":
        return nn.SiLU()
    if name == "tanh":
        return nn.Tanh()
    if name == "gelu":
        return nn.GELU()
    raise ValueError(name)


class StandardizedMLP(nn.Module):
    """MLP with train-split input normalization and calibrated output bias."""

    input_mean: torch.Tensor
    input_scale: torch.Tensor
    feature_network: nn.Sequential
    output_layer: nn.Linear

    def __init__(
        self,
        input_dimension: int,
        output_dimension: int,
        spec: ModelSpec,
        *,
        input_mean: np.ndarray,
        input_scale: np.ndarray,
        output_bias: np.ndarray | None = None,
    ) -> None:
        super().__init__()
        dtype = torch_dtype(spec.dtype)
        mean = torch.as_tensor(input_mean, dtype=dtype)
        scale = torch.as_tensor(input_scale, dtype=dtype)
        if mean.shape != (input_dimension,) or scale.shape != (input_dimension,):
            raise ValueError("input normalization has the wrong shape")
        if torch.any(scale <= 0):
            raise ValueError("input scale must be positive")
        self.register_buffer("input_mean", mean)
        self.register_buffer("input_scale", scale)
        layers: list[nn.Module] = []
        previous = input_dimension
        for _ in range(spec.depth):
            linear = nn.Linear(previous, spec.width, dtype=dtype)
            nn.init.kaiming_uniform_(linear.weight, nonlinearity="relu")
            nn.init.zeros_(linear.bias)
            layers.append(linear)
            if spec.layer_norm:
                layers.append(nn.LayerNorm(spec.width, dtype=dtype))
            layers.append(_activation(spec.activation))
            previous = spec.width
        final = nn.Linear(previous, output_dimension, dtype=dtype)
        # Starting from a context-independent statistical policy is much more
        # stable than a random cost/report field and is shared by every method.
        nn.init.zeros_(final.weight)
        if output_bias is None:
            nn.init.zeros_(final.bias)
        else:
            bias = torch.as_tensor(output_bias, dtype=dtype)
            if bias.shape != (output_dimension,):
                raise ValueError("output_bias has the wrong shape")
            with torch.no_grad():
                final.bias.copy_(bias)
        self.feature_network = nn.Sequential(*layers)
        self.output_layer = final
        self.feature_dimension = previous

    def features(self, contexts: torch.Tensor) -> torch.Tensor:
        standardized = (contexts - self.input_mean) / self.input_scale
        features = self.feature_network(standardized)
        assert isinstance(features, torch.Tensor)
        return features

    def forward(self, contexts: torch.Tensor) -> torch.Tensor:
        outputs = self.output_layer(self.features(contexts))
        assert isinstance(outputs, torch.Tensor)
        return outputs


class AnchoredModel(nn.Module):
    """MSE base plus a correction network that can use both context and base."""

    def __init__(
        self,
        base: StandardizedMLP,
        correction: StandardizedMLP,
        *,
        freeze_base: bool,
    ) -> None:
        super().__init__()
        self.base = base
        self.correction = correction
        self.freeze_base = bool(freeze_base)
        if freeze_base:
            for parameter in self.base.parameters():
                parameter.requires_grad_(False)

    def forward(self, contexts: torch.Tensor) -> torch.Tensor:
        if self.freeze_base:
            with torch.no_grad():
                base = self.base(contexts)
        else:
            base = self.base(contexts)
        correction_input = torch.cat([contexts, base], dim=1)
        correction = self.correction(correction_input)
        return torch.cat([base, correction], dim=1)


class KNNRegressor(nn.Module):
    """Deterministic k-nearest-neighbor conditional-mean estimator."""

    train_contexts: torch.Tensor
    train_targets: torch.Tensor
    input_mean: torch.Tensor
    input_scale: torch.Tensor

    def __init__(
        self,
        train_contexts: np.ndarray,
        train_targets: np.ndarray,
        *,
        neighbors: int,
        distance_weighted: bool,
    ) -> None:
        super().__init__()
        if neighbors <= 0 or neighbors > len(train_contexts):
            raise ValueError("neighbors must lie between one and the train size")
        mean, scale = input_statistics(train_contexts)
        standardized = (np.asarray(train_contexts) - mean) / scale
        self.register_buffer(
            "train_contexts", torch.as_tensor(standardized, dtype=torch.float64)
        )
        self.register_buffer(
            "train_targets", torch.as_tensor(train_targets, dtype=torch.float64)
        )
        self.register_buffer("input_mean", torch.as_tensor(mean, dtype=torch.float64))
        self.register_buffer("input_scale", torch.as_tensor(scale, dtype=torch.float64))
        self.neighbors = int(neighbors)
        self.distance_weighted = bool(distance_weighted)

    def forward(self, contexts: torch.Tensor) -> torch.Tensor:
        standardized = (contexts - self.input_mean) / self.input_scale
        distances = torch.cdist(standardized, self.train_contexts)
        values, indices = torch.topk(
            distances, self.neighbors, dim=1, largest=False, sorted=True
        )
        neighbors = self.train_targets[indices]
        if not self.distance_weighted:
            return neighbors.mean(dim=1)
        weights = 1.0 / torch.clamp(values, min=1e-8)
        weights = weights / weights.sum(dim=1, keepdim=True)
        return torch.sum(neighbors * weights[:, :, None], dim=1)


def input_statistics(contexts: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    contexts = np.asarray(contexts, dtype=np.float64)
    mean = contexts.mean(axis=0)
    scale = contexts.std(axis=0, ddof=0)
    scale = np.where(scale < 1e-8, 1.0, scale)
    return mean, scale


def parameter_count(model: nn.Module, *, trainable_only: bool = False) -> int:
    parameters = (
        parameter
        for parameter in model.parameters()
        if not trainable_only or parameter.requires_grad
    )
    return int(sum(parameter.numel() for parameter in parameters))
