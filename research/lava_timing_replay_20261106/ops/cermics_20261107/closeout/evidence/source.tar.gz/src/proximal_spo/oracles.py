"""Persistent, auditable optimization oracles.

Every worker owns its solver instance.  Batch parallelism is deterministic:
contiguous chunks are always assigned to workers in index order, while each
solver reuses its previous basis/factorization within that stream.
"""

from __future__ import annotations

import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Generic, Protocol, Self, TypeVar

import clarabel
import highspy
import numpy as np
import osqp
from scipy.optimize import linear_sum_assignment
from scipy.sparse import csc_matrix, triu, vstack

from .problem import FloatArray, LinearProblem

# Clarabel certifies feasibility in equilibrated coordinates. On the
# rank-deficient product QPs used by the mollified decoder, mapping the solution
# back to the original coordinates can amplify a certified residual by roughly
# one decimal place. Keep OSQP's fast-path gate at 1e-8, but allow the robust
# fallback this still-stringent final tolerance in the original coordinates.
_CLARABEL_PRIMAL_FEASIBILITY_TOLERANCE = 1e-7
_HIGHS_MIP_FEASIBILITY_TOLERANCE = 1e-8
_HIGHS_MIP_RELATIVE_GAP = 0.0
_HIGHS_MIP_ABSOLUTE_GAP = 0.0


@dataclass(frozen=True)
class OracleStats:
    calls: int = 0
    iterations: int = 0
    failures: int = 0
    solver_seconds: float = 0.0
    wall_seconds: float = 0.0
    retries: int = 0

    def __add__(self, other: OracleStats) -> OracleStats:
        return OracleStats(
            calls=self.calls + other.calls,
            iterations=self.iterations + other.iterations,
            failures=self.failures + other.failures,
            solver_seconds=self.solver_seconds + other.solver_seconds,
            wall_seconds=self.wall_seconds + other.wall_seconds,
            retries=self.retries + other.retries,
        )


@dataclass(frozen=True)
class BatchSolutions:
    decisions: FloatArray
    objectives: FloatArray
    stats: OracleStats


class OracleFailure(RuntimeError):
    pass


class _ChunkSolver(Protocol):
    problem: LinearProblem

    def solve_many(
        self,
        objectives: FloatArray,
        sample_keys: np.ndarray | None = None,
    ) -> BatchSolutions: ...


class LPOracle(Protocol):
    problem: LinearProblem

    def solve_many(
        self,
        objectives: FloatArray,
        sample_keys: np.ndarray | None = None,
    ) -> BatchSolutions: ...

    def close(self) -> None: ...

    def __enter__(self) -> Self: ...

    def __exit__(self, *_: object) -> None: ...


def _highs_lp(problem: LinearProblem) -> highspy.HighsLp:
    matrix = csc_matrix(problem.matrix)
    lp = highspy.HighsLp()
    lp.num_col_ = problem.variable_count
    lp.num_row_ = problem.constraint_count
    lp.col_cost_ = np.zeros(problem.variable_count)
    lp.col_lower_ = problem.variable_lower
    lp.col_upper_ = problem.variable_upper
    lp.row_lower_ = problem.row_lower
    lp.row_upper_ = problem.row_upper
    sparse = highspy.HighsSparseMatrix()
    sparse.num_col_ = problem.variable_count
    sparse.num_row_ = problem.constraint_count
    sparse.format_ = highspy.MatrixFormat.kColwise
    sparse.start_ = matrix.indptr.astype(np.int32)
    sparse.index_ = matrix.indices.astype(np.int32)
    sparse.value_ = matrix.data
    lp.a_matrix_ = sparse
    if not problem.is_continuous:
        assert problem.integrality is not None
        lp.integrality_ = [
            highspy.HighsVarType.kInteger if flag else highspy.HighsVarType.kContinuous
            for flag in problem.integrality
        ]
    return lp


class PersistentLPSolver:
    """HiGHS model with objective updates and keyed basis reuse.

    Mini-batch shuffling makes the immediately preceding LP a poor warm start
    for the next observation.  Stable sample keys let the solver restore the
    basis last seen for that observation instead.
    """

    def __init__(
        self,
        problem: LinearProblem,
        *,
        random_seed: int = 0,
        maximum_basis_cache_entries: int = 50_000,
    ) -> None:
        if maximum_basis_cache_entries < 0:
            raise ValueError("maximum_basis_cache_entries must be nonnegative")
        self.problem = problem
        self.maximum_basis_cache_entries = int(maximum_basis_cache_entries)
        self._solver = highspy.Highs()  # type: ignore[no-untyped-call]
        self._solver.setOptionValue("output_flag", False)
        self._solver.setOptionValue("threads", 1)
        self._solver.setOptionValue("random_seed", int(random_seed % 2_147_483_647))
        self._solver.setOptionValue("primal_feasibility_tolerance", 1e-8)
        self._solver.setOptionValue("dual_feasibility_tolerance", 1e-8)
        if problem.is_continuous:
            self._solver.setOptionValue("solver", "simplex")
        else:
            self._solver.setOptionValue(
                "mip_feasibility_tolerance", _HIGHS_MIP_FEASIBILITY_TOLERANCE
            )
            self._solver.setOptionValue("mip_rel_gap", _HIGHS_MIP_RELATIVE_GAP)
            self._solver.setOptionValue("mip_abs_gap", _HIGHS_MIP_ABSOLUTE_GAP)
        status = self._solver.passModel(_highs_lp(problem))
        if status != highspy.HighsStatus.kOk:
            raise OracleFailure(f"HiGHS rejected model {problem.name}: {status}")
        self._indices = np.arange(problem.variable_count, dtype=np.int32)
        self._basis_cache: OrderedDict[int, highspy.HighsBasis] = OrderedDict()
        # Do not reuse MIP incumbents through ``Highs.setSolution`` after an
        # objective update.  In highspy 1.11.0 this can leave the model status
        # at ``Optimal`` without re-establishing optimality for the new cost.
        # A live campaign caught a 0.4469 objective error on SFGE KP50.  LP
        # basis reuse below is unaffected and remains enabled.
        self.maximum_mip_start_cache_entries = 0
        self._mip_start_cache: OrderedDict[int, FloatArray] = OrderedDict()

    @property
    def basis_cache_size(self) -> int:
        return len(self._basis_cache)

    @property
    def mip_start_cache_size(self) -> int:
        return len(self._mip_start_cache)

    def _restore_basis(self, sample_key: int | None) -> None:
        if sample_key is None:
            return
        if not self.problem.is_continuous:
            return
        basis = self._basis_cache.pop(sample_key, None)
        if basis is None:
            return
        self._basis_cache[sample_key] = basis
        if self._solver.setBasis(basis) != highspy.HighsStatus.kOk:
            # A cached basis is only a performance hint.  A rejected hint must
            # never change correctness or stop the solve.
            self._basis_cache.pop(sample_key, None)

    def _remember_basis(
        self, sample_key: int | None, decision: FloatArray | None = None
    ) -> None:
        if sample_key is not None and not self.problem.is_continuous:
            return
        if (
            sample_key is None
            or self.maximum_basis_cache_entries == 0
        ):
            return
        self._basis_cache.pop(sample_key, None)
        self._basis_cache[sample_key] = self._solver.getBasis()
        while len(self._basis_cache) > self.maximum_basis_cache_entries:
            self._basis_cache.popitem(last=False)

    def solve(
        self,
        objective: FloatArray,
        sample_key: int | None = None,
    ) -> tuple[FloatArray, float, OracleStats]:
        objective = np.asarray(objective, dtype=np.float64)
        if objective.shape != (self.problem.variable_count,):
            raise ValueError("LP objective has the wrong shape")
        started = time.perf_counter()
        if not self.problem.is_continuous:
            clear_status = self._solver.clearSolver()
            if clear_status != highspy.HighsStatus.kOk:
                raise OracleFailure(
                    f"HiGHS failed to clear stale MIP state: {clear_status}"
                )
        status = self._solver.changeColsCost(
            self.problem.variable_count, self._indices, objective
        )
        if status != highspy.HighsStatus.kOk:
            raise OracleFailure(f"HiGHS rejected objective update: {status}")
        self._restore_basis(sample_key)
        status = self._solver.run()
        model_status = self._solver.getModelStatus()
        retries = 0
        if model_status == highspy.HighsModelStatus.kUnknown:
            # A warm-started HiGHS LP can very rarely return kUnknown even when
            # the same finite objective is solved successfully from a cold
            # state.  Retry once without the cached basis.  Genuine
            # infeasible/unbounded certificates are never retried or masked.
            if sample_key is not None:
                self._basis_cache.pop(sample_key, None)
            clear_status = self._solver.clearSolver()
            if clear_status == highspy.HighsStatus.kOk:
                update_status = self._solver.changeColsCost(
                    self.problem.variable_count, self._indices, objective
                )
                if update_status == highspy.HighsStatus.kOk:
                    retries = 1
                    status = self._solver.run()
                    model_status = self._solver.getModelStatus()
        wall = time.perf_counter() - started
        if (
            status != highspy.HighsStatus.kOk
            or model_status != highspy.HighsModelStatus.kOptimal
        ):
            message = self._solver.modelStatusToString(model_status)
            raise OracleFailure(f"HiGHS solve failed: {message}")
        solution = self._solver.getSolution()
        decision = np.asarray(solution.col_value, dtype=np.float64)
        self._remember_basis(sample_key, decision)
        info = self._solver.getInfo()
        iterations = int(info.simplex_iteration_count)
        if not self.problem.is_continuous:
            iterations += int(max(0, info.mip_node_count))
        solver_seconds = float(getattr(info, "run_time", wall))
        return (
            decision,
            float(objective @ decision),
            OracleStats(1, iterations, 0, solver_seconds, wall, retries),
        )

    def solve_many(
        self,
        objectives: FloatArray,
        sample_keys: np.ndarray | None = None,
    ) -> BatchSolutions:
        objectives = np.asarray(objectives, dtype=np.float64)
        if objectives.ndim != 2 or objectives.shape[1] != self.problem.variable_count:
            raise ValueError("LP objective batch has the wrong shape")
        keys = None if sample_keys is None else np.asarray(sample_keys, dtype=np.int64)
        if keys is not None and keys.shape != (len(objectives),):
            raise ValueError("sample keys must align with the objective batch")
        decisions: list[FloatArray] = []
        values: list[float] = []
        total = OracleStats()
        for row, objective in enumerate(objectives):
            try:
                decision, value, stats = self.solve(
                    objective,
                    None if keys is None else int(keys[row]),
                )
            except Exception:
                total += OracleStats(calls=1, failures=1)
                raise
            decisions.append(decision)
            values.append(value)
            total += stats
        return BatchSolutions(
            np.stack(decisions)
            if decisions
            else np.empty((0, self.problem.variable_count)),
            np.asarray(values, dtype=np.float64),
            total,
        )


class PersistentClarabelQPSolver:
    """Robust interior-point QP fallback with objective-only updates."""

    def __init__(self, problem: LinearProblem, quadratic: csc_matrix) -> None:
        self.problem = problem
        matrix = problem.osqp_matrix
        lower = problem.osqp_lower
        upper = problem.osqp_upper
        finite_lower = np.isfinite(lower)
        finite_upper = np.isfinite(upper)
        equal = finite_lower & finite_upper & (np.abs(lower - upper) <= 1e-12)
        upper_only = finite_upper & ~equal
        lower_only = finite_lower & ~equal
        matrices: list[csc_matrix] = []
        right_hand_sides: list[FloatArray] = []
        cones: list[object] = []
        if np.any(equal):
            matrices.append(csc_matrix(matrix[equal]))
            right_hand_sides.append(upper[equal])
            cones.append(clarabel.ZeroConeT(int(np.sum(equal))))
        inequality_count = int(np.sum(upper_only) + np.sum(lower_only))
        if inequality_count:
            matrices.extend(
                [csc_matrix(matrix[upper_only]), csc_matrix(-matrix[lower_only])]
            )
            right_hand_sides.extend([upper[upper_only], -lower[lower_only]])
            cones.append(clarabel.NonnegativeConeT(inequality_count))
        constraint_matrix = csc_matrix(
            vstack(matrices, format="csc")
            if matrices
            else csc_matrix((0, problem.variable_count))
        )
        right_hand_side = (
            np.concatenate(right_hand_sides)
            if right_hand_sides
            else np.empty(0, dtype=np.float64)
        )
        settings = clarabel.DefaultSettings()
        settings.verbose = False
        settings.presolve_enable = False
        settings.max_threads = 1
        settings.max_iter = 200
        settings.tol_feas = 1e-9
        settings.tol_gap_abs = 1e-9
        settings.tol_gap_rel = 1e-9
        self._solver = clarabel.DefaultSolver(
            triu(quadratic, format="csc"),
            np.zeros(problem.variable_count),
            constraint_matrix,
            right_hand_side,
            cones,
            settings,
        )

    def _primal_violation(self, decision: FloatArray) -> float:
        activity = np.asarray(self.problem.matrix @ decision, dtype=np.float64)
        return float(
            max(
                np.max(self.problem.variable_lower - decision, initial=0.0),
                np.max(decision - self.problem.variable_upper, initial=0.0),
                np.max(self.problem.row_lower - activity, initial=0.0),
                np.max(activity - self.problem.row_upper, initial=0.0),
            )
        )

    def solve(self, linear: FloatArray) -> tuple[FloatArray, float, OracleStats]:
        linear = np.asarray(linear, dtype=np.float64)
        started = time.perf_counter()
        self._solver.update(q=linear)
        solution = self._solver.solve()
        wall = time.perf_counter() - started
        if solution.status != clarabel.SolverStatus.Solved:
            raise OracleFailure(f"Clarabel QP solve failed: {solution.status}")
        decision = np.asarray(solution.x, dtype=np.float64)
        violation = self._primal_violation(decision)
        if violation > _CLARABEL_PRIMAL_FEASIBILITY_TOLERANCE:
            raise OracleFailure(
                "Clarabel QP solution violates primal feasibility: "
                f"{violation:.3g} > "
                f"{_CLARABEL_PRIMAL_FEASIBILITY_TOLERANCE:.3g}"
            )
        return (
            decision,
            float(solution.obj_val),
            OracleStats(
                calls=1,
                iterations=int(solution.iterations),
                solver_seconds=float(solution.solve_time),
                wall_seconds=wall,
            ),
        )


class PersistentQPSolver:
    """Fast OSQP decoder with automatic persistent Clarabel fallback."""

    def __init__(
        self,
        problem: LinearProblem,
        quadratic: csc_matrix | FloatArray,
        *,
        eps_abs: float = 1e-6,
        eps_rel: float = 1e-6,
        maximum_state_cache_entries: int = 50_000,
    ) -> None:
        if not problem.is_continuous:
            raise ValueError("OSQP decoder requires a continuous feasible set")
        quadratic = csc_matrix(quadratic, dtype=np.float64)
        if quadratic.shape != (problem.variable_count, problem.variable_count):
            raise ValueError("quadratic matrix has the wrong shape")
        asymmetry = quadratic - quadratic.T
        if asymmetry.nnz and np.max(np.abs(asymmetry.data)) > 1e-9:
            raise ValueError("quadratic matrix must be symmetric")
        self.problem = problem
        self.maximum_state_cache_entries = int(maximum_state_cache_entries)
        if self.maximum_state_cache_entries < 0:
            raise ValueError("maximum_state_cache_entries must be nonnegative")
        self._state_cache: OrderedDict[int, tuple[FloatArray, FloatArray]] = (
            OrderedDict()
        )
        self._fallback = PersistentClarabelQPSolver(problem, quadratic)
        self._use_fallback = False
        self._solver = osqp.OSQP()
        self._solver.setup(
            P=triu(quadratic, format="csc"),
            q=np.zeros(problem.variable_count),
            A=problem.osqp_matrix,
            l=problem.osqp_lower,
            u=problem.osqp_upper,
            verbose=False,
            eps_abs=eps_abs,
            eps_rel=eps_rel,
            max_iter=20_000,
            polishing=False,
            adaptive_rho=True,
            check_termination=10,
            warm_starting=True,
        )

    def _primal_violation(self, decision: FloatArray) -> float:
        activity = np.asarray(self.problem.matrix @ decision, dtype=np.float64)
        violations = [
            np.max(self.problem.variable_lower - decision, initial=0.0),
            np.max(decision - self.problem.variable_upper, initial=0.0),
            np.max(self.problem.row_lower - activity, initial=0.0),
            np.max(activity - self.problem.row_upper, initial=0.0),
        ]
        return float(max(violations))

    def solve(
        self,
        linear: FloatArray,
        sample_key: int | None = None,
    ) -> tuple[FloatArray, float, OracleStats]:
        linear = np.asarray(linear, dtype=np.float64)
        if linear.shape != (self.problem.variable_count,):
            raise ValueError("QP linear objective has the wrong shape")
        if self._use_fallback:
            return self._fallback.solve(linear)
        started = time.perf_counter()
        self._solver.update(q=linear)
        if sample_key is not None:
            state = self._state_cache.pop(sample_key, None)
            if state is not None:
                self._state_cache[sample_key] = state
                self._solver.warm_start(x=state[0], y=state[1])
        result = self._solver.solve(raise_error=False)
        osqp_acceptable = (
            result.x is not None
            and int(result.info.status_val) == 1
            and self._primal_violation(np.asarray(result.x, dtype=np.float64)) <= 1e-8
        )
        if not osqp_acceptable:
            # Rank-deficient proximal Hessians can be difficult for ADMM on
            # degenerate polytopes.  Switch this worker permanently to Clarabel;
            # repeated failed warm starts would otherwise dominate runtime.
            self._use_fallback = True
            decision, value, fallback_stats = self._fallback.solve(linear)
            wall = time.perf_counter() - started
            return (
                decision,
                value,
                OracleStats(
                    calls=1,
                    iterations=int(result.info.iter) + fallback_stats.iterations,
                    failures=0,
                    solver_seconds=float(result.info.run_time)
                    + fallback_stats.solver_seconds,
                    wall_seconds=wall,
                    retries=1,
                ),
            )
        wall = time.perf_counter() - started
        decision = np.asarray(result.x, dtype=np.float64)
        if (
            sample_key is not None
            and result.y is not None
            and self.maximum_state_cache_entries > 0
        ):
            self._state_cache.pop(sample_key, None)
            self._state_cache[sample_key] = (
                decision.copy(),
                np.asarray(result.y, dtype=np.float64).copy(),
            )
            while len(self._state_cache) > self.maximum_state_cache_entries:
                self._state_cache.popitem(last=False)
        return (
            decision,
            float(result.info.obj_val),
            OracleStats(
                calls=1,
                iterations=int(result.info.iter),
                failures=0,
                solver_seconds=float(result.info.run_time),
                wall_seconds=wall,
            ),
        )

    def solve_many(
        self,
        objectives: FloatArray,
        sample_keys: np.ndarray | None = None,
    ) -> BatchSolutions:
        objectives = np.asarray(objectives, dtype=np.float64)
        if objectives.ndim != 2 or objectives.shape[1] != self.problem.variable_count:
            raise ValueError("QP linear-objective batch has the wrong shape")
        if sample_keys is not None and np.asarray(sample_keys).shape != (
            len(objectives),
        ):
            raise ValueError("sample keys must align with the objective batch")
        decisions: list[FloatArray] = []
        values: list[float] = []
        total = OracleStats()
        keys = None if sample_keys is None else np.asarray(sample_keys, dtype=np.int64)
        for row, objective in enumerate(objectives):
            try:
                decision, value, stats = self.solve(
                    objective,
                    None if keys is None else int(keys[row]),
                )
            except Exception:
                total += OracleStats(calls=1, failures=1)
                raise
            decisions.append(decision)
            values.append(value)
            total += stats
        return BatchSolutions(
            np.stack(decisions)
            if decisions
            else np.empty((0, self.problem.variable_count)),
            np.asarray(values, dtype=np.float64),
            total,
        )


S = TypeVar("S", bound=_ChunkSolver)


class ParallelOracle(Generic[S]):
    """A deterministic fixed pool of independent persistent solvers."""

    def __init__(self, solvers: list[S]) -> None:
        if not solvers:
            raise ValueError("at least one solver is required")
        self.solvers = solvers
        self.problem = solvers[0].problem
        self._executor = (
            ThreadPoolExecutor(max_workers=len(solvers), thread_name_prefix="oracle")
            if len(solvers) > 1
            else None
        )

    def close(self) -> None:
        if self._executor is not None:
            self._executor.shutdown(wait=True, cancel_futures=False)

    def __enter__(self) -> ParallelOracle[S]:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def solve_many(
        self,
        objectives: FloatArray,
        sample_keys: np.ndarray | None = None,
    ) -> BatchSolutions:
        objectives = np.asarray(objectives, dtype=np.float64)
        if objectives.ndim != 2:
            raise ValueError("objectives must be a matrix")
        keys = None if sample_keys is None else np.asarray(sample_keys, dtype=np.int64)
        if keys is not None and keys.shape != (len(objectives),):
            raise ValueError("sample keys must align with the objective batch")
        if objectives.shape[0] == 0:
            if keys is None:
                return self.solvers[0].solve_many(objectives)
            return self.solvers[0].solve_many(objectives, keys)

        if keys is None:
            assignments = [
                (worker, indices)
                for worker, indices in enumerate(
                    np.array_split(
                        np.arange(len(objectives), dtype=np.int64),
                        len(self.solvers),
                    )
                )
                if len(indices)
            ]
        else:
            worker_ids = np.mod(keys, len(self.solvers))
            assignments = [
                (worker, np.flatnonzero(worker_ids == worker).astype(np.int64))
                for worker in range(len(self.solvers))
            ]
            assignments = [item for item in assignments if len(item[1])]

        started = time.perf_counter()
        if self._executor is None:
            worker, indices = assignments[0]
            pieces = [
                (
                    indices,
                    (
                        self.solvers[worker].solve_many(objectives[indices])
                        if keys is None
                        else self.solvers[worker].solve_many(
                            objectives[indices], keys[indices]
                        )
                    ),
                )
            ]
        else:
            futures = [
                (
                    indices,
                    (
                        self._executor.submit(
                            self.solvers[worker].solve_many,
                            objectives[indices],
                        )
                        if keys is None
                        else self._executor.submit(
                            self.solvers[worker].solve_many,
                            objectives[indices],
                            keys[indices],
                        )
                    ),
                )
                for worker, indices in assignments
            ]
            pieces = [(indices, future.result()) for indices, future in futures]
        wall = time.perf_counter() - started
        stats = OracleStats(wall_seconds=wall)
        decisions = np.empty(
            (len(objectives), self.solvers[0].problem.variable_count),
            dtype=np.float64,
        )
        values = np.empty(len(objectives), dtype=np.float64)
        for indices, piece in pieces:
            decisions[indices] = piece.decisions
            values[indices] = piece.objectives
            stats += OracleStats(
                calls=piece.stats.calls,
                iterations=piece.stats.iterations,
                failures=piece.stats.failures,
                solver_seconds=piece.stats.solver_seconds,
                # Batch wall is recorded once above, not summed across workers.
                wall_seconds=0.0,
                retries=piece.stats.retries,
            )
        return BatchSolutions(
            decisions,
            values,
            stats,
        )


class SpecializedLPOracle:
    """Exact batch algorithms for common integral LP polytopes.

    These routines solve the same linear optimization problem as HiGHS but
    avoid general-purpose solver overhead.  They are selected only when the
    benchmark constructor explicitly certifies a compatible structure.
    """

    def __init__(self, problem: LinearProblem, kind: str) -> None:
        self.problem = problem
        self.kind = kind
        metadata = problem.metadata
        if kind == "top_k":
            self._selected = int(metadata["selected"])
        elif kind == "assignment":
            self._assignment_size = int(metadata["size"])
        elif kind == "directed_grid_path":
            self._grid_rows = int(metadata["rows"])
            self._grid_columns = int(metadata["columns"])
            edges = list(metadata["edges"])

            def node(value: tuple[int, int]) -> int:
                return int(value[0]) * self._grid_columns + int(value[1])

            self._edge_tails = np.asarray(
                [node(edge[0]) for edge in edges], dtype=np.int64
            )
            self._edge_heads = np.asarray(
                [node(edge[1]) for edge in edges], dtype=np.int64
            )
            self._incoming = {
                head: np.flatnonzero(self._edge_heads == head).astype(np.int64)
                for head in range(self._grid_rows * self._grid_columns)
            }
        elif kind != "scalar_box":
            raise ValueError(f"unknown specialized LP oracle kind: {kind}")

    def close(self) -> None:
        return None

    def __enter__(self) -> SpecializedLPOracle:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _scalar_box(self, objectives: FloatArray) -> FloatArray:
        return (objectives < 0.0).astype(np.float64)

    def _top_k(self, objectives: FloatArray) -> FloatArray:
        decisions = np.zeros_like(objectives)
        selected = np.argpartition(objectives, kth=self._selected - 1, axis=1)[
            :, : self._selected
        ]
        decisions[np.arange(len(objectives))[:, None], selected] = 1.0
        return decisions

    def _assignment(self, objectives: FloatArray) -> FloatArray:
        size = self._assignment_size
        decisions = np.zeros_like(objectives)
        for row, objective in enumerate(objectives):
            left, right = linear_sum_assignment(objective.reshape(size, size))
            decisions[row, left * size + right] = 1.0
        return decisions

    def _directed_grid_path(self, objectives: FloatArray) -> FloatArray:
        batch = len(objectives)
        node_count = self._grid_rows * self._grid_columns
        distances = np.full((batch, node_count), np.inf, dtype=np.float64)
        predecessor = np.full((batch, node_count), -1, dtype=np.int64)
        distances[:, 0] = 0.0
        row_indices = np.arange(batch)
        for head in range(1, node_count):
            incoming = self._incoming[head]
            candidate = (
                distances[:, self._edge_tails[incoming]] + objectives[:, incoming]
            )
            choice = np.argmin(candidate, axis=1)
            distances[:, head] = candidate[row_indices, choice]
            predecessor[:, head] = incoming[choice]
        decisions = np.zeros_like(objectives)
        current = np.full(batch, node_count - 1, dtype=np.int64)
        for _ in range(self._grid_rows + self._grid_columns - 2):
            edge = predecessor[row_indices, current]
            if np.any(edge < 0):
                raise OracleFailure("directed-grid dynamic program lost a predecessor")
            decisions[row_indices, edge] = 1.0
            current = self._edge_tails[edge]
        return decisions

    def solve_many(
        self,
        objectives: FloatArray,
        sample_keys: np.ndarray | None = None,
    ) -> BatchSolutions:
        objectives = np.asarray(objectives, dtype=np.float64)
        if objectives.ndim != 2 or objectives.shape[1] != self.problem.variable_count:
            raise ValueError("LP objective batch has the wrong shape")
        if sample_keys is not None and np.asarray(sample_keys).shape != (
            len(objectives),
        ):
            raise ValueError("sample keys must align with the objective batch")
        started = time.perf_counter()
        if self.kind == "scalar_box":
            decisions = self._scalar_box(objectives)
        elif self.kind == "top_k":
            decisions = self._top_k(objectives)
        elif self.kind == "assignment":
            decisions = self._assignment(objectives)
        else:
            decisions = self._directed_grid_path(objectives)
        wall = time.perf_counter() - started
        return BatchSolutions(
            decisions=np.ascontiguousarray(decisions),
            objectives=np.einsum("bn,bn->b", objectives, decisions),
            stats=OracleStats(
                calls=len(objectives),
                iterations=0,
                failures=0,
                solver_seconds=wall,
                wall_seconds=wall,
            ),
        )


def make_lp_oracle(
    problem: LinearProblem,
    *,
    workers: int,
    random_seed: int,
    use_specialized: bool = True,
) -> LPOracle:
    if workers <= 0:
        raise ValueError("workers must be positive")
    kind = problem.metadata.get("oracle_kind") if use_specialized else None
    if isinstance(kind, str):
        return SpecializedLPOracle(problem, kind)
    return ParallelOracle(
        [
            # Worker count is an execution parameter, not part of the
            # mathematical decision rule. Give independent solvers the same
            # seed so tied objectives select the same optimizer regardless of
            # which contiguous worker chunk receives a sample.
            PersistentLPSolver(problem, random_seed=random_seed)
            for _ in range(workers)
        ]
    )


def make_qp_oracle(
    problem: LinearProblem,
    quadratic: csc_matrix | FloatArray,
    *,
    workers: int,
) -> ParallelOracle[PersistentQPSolver]:
    if workers <= 0:
        raise ValueError("workers must be positive")
    return ParallelOracle(
        [PersistentQPSolver(problem, quadratic) for _ in range(workers)]
    )
