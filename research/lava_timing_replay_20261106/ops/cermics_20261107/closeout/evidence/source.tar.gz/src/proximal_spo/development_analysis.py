"""Candid validation-only summaries for staged development campaigns."""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from .experiment_identity import benchmark_family_id, experimental_route_id


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected a JSON object at {path}")
    return payload


def _completed_validation_receipts(
    run_roots: Iterable[Path],
    *,
    required_source_sha256: Iterable[str] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Load rankable receipts and quarantine undefined-normalizer routes."""

    required_sources = (
        None
        if required_source_sha256 is None
        else frozenset(required_source_sha256)
    )
    if required_sources is not None and (
        not required_sources
        or any(len(value) != 64 for value in required_sources)
    ):
        raise ValueError("required source hashes must be nonempty SHA-256 strings")
    rows: list[dict[str, Any]] = []
    exclusions: list[dict[str, Any]] = []
    seen_directories: set[Path] = set()
    for root in run_roots:
        resolved_root = root.resolve()
        if not resolved_root.is_dir():
            raise FileNotFoundError(resolved_root)
        directories = sorted(
            path for path in resolved_root.iterdir() if path.is_dir()
        )
        for directory in directories:
            resolved = directory.resolve()
            if resolved in seen_directories:
                continue
            seen_directories.add(resolved)
            paths = {
                "status": directory / "status.json",
                "config": directory / "config.json",
                "environment": directory / "environment.json",
                "summary": directory / "summary.json",
            }
            if not all(path.is_file() for path in paths.values()):
                continue
            status = _object(paths["status"])
            if status.get("status") != "complete":
                continue
            config = _object(paths["config"])
            environment = _object(paths["environment"])
            summary = _object(paths["summary"])
            validation = summary.get("best_validation")
            if not isinstance(validation, dict):
                raise ValueError(f"missing validation receipt in {directory}")
            if "normalized_mean_regret" not in validation:
                raise ValueError(f"missing normalized validation regret in {directory}")
            normalized = validation.get("normalized_mean_regret")
            mean_regret = validation.get("mean_regret")
            if not isinstance(mean_regret, (int, float)) or isinstance(
                mean_regret, bool
            ):
                raise ValueError(f"missing mean validation regret in {directory}")
            source = environment.get("source_sha256")
            if not isinstance(source, str) or len(source) != 64:
                raise ValueError(f"missing executable source digest in {directory}")
            if required_sources is not None and source not in required_sources:
                continue
            shared = {
                "benchmark_id": config.get("benchmark_id"),
                "route_id": experimental_route_id(config),
                "family_id": benchmark_family_id(config),
                "method": config.get("method"),
                "name": config.get("name"),
                "run_directory": str(directory),
                "source_sha256": source,
                "validation_mean_regret": float(mean_regret),
                "test_evaluated": summary.get("test") is not None,
                "config": config,
            }
            if normalized is None:
                exclusions.append(
                    {
                        **shared,
                        "reason": "undefined_normalized_regret_zero_reference_scale",
                    }
                )
                continue
            if not isinstance(normalized, (int, float)) or isinstance(
                normalized, bool
            ):
                raise ValueError(f"missing normalized validation regret in {directory}")
            rows.append(
                {
                    **shared,
                    "validation_normalized_mean_regret": float(normalized),
                    "best_epoch": summary.get("best_epoch"),
                    "training_wall_seconds": float(
                        summary.get(
                            "whole_pipeline_training_wall_seconds",
                            summary["training_wall_seconds"],
                        )
                    ),
                }
            )
    if not rows and not exclusions:
        raise ValueError("no completed validation runs found")
    return rows, exclusions


def completed_validation_rows(
    run_roots: Iterable[Path],
    *,
    required_source_sha256: Iterable[str] | None = None,
) -> list[dict[str, Any]]:
    """Load completed receipts that have a defined normalized regret."""

    rows, _ = _completed_validation_receipts(
        run_roots, required_source_sha256=required_source_sha256
    )
    if not rows:
        raise ValueError("no nondegenerate completed validation runs found")
    return rows


def summarize_development(
    run_roots: Iterable[Path],
    *,
    required_source_sha256: Iterable[str] | None = None,
) -> dict[str, Any]:
    """Select each method by validation only and rank within each route."""

    roots = [Path(root) for root in run_roots]
    required_sources = (
        None
        if required_source_sha256 is None
        else tuple(required_source_sha256)
    )
    rows, exclusions = _completed_validation_receipts(
        roots, required_source_sha256=required_sources
    )
    if not rows:
        raise ValueError("no nondegenerate completed validation runs found")
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        route = row["route_id"]
        method = row["method"]
        if not isinstance(route, str) or not isinstance(method, str):
            raise ValueError("completed config lacks route_id or method")
        grouped[(route, method)].append(row)

    selected: list[dict[str, Any]] = []
    for (route, method), candidates in sorted(grouped.items()):
        winner = min(
            candidates,
            key=lambda row: (
                float(row["validation_normalized_mean_regret"]),
                str(row["run_directory"]),
            ),
        )
        selected.append(
            {
                **winner,
                "candidate_count": len(candidates),
                "route_id": route,
                "method": method,
            }
        )

    rankings: list[dict[str, Any]] = []
    winners: Counter[str] = Counter()
    by_route: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in selected:
        by_route[str(row["route_id"])].append(row)
    for route, candidates in sorted(by_route.items()):
        ordered = sorted(
            candidates,
            key=lambda row: (
                float(row["validation_normalized_mean_regret"]),
                str(row["method"]),
            ),
        )
        winners[str(ordered[0]["method"])] += 1
        best = float(ordered[0]["validation_normalized_mean_regret"])
        rankings.append(
            {
                "route_id": route,
                "benchmark_id": ordered[0]["benchmark_id"],
                "family_id": ordered[0]["family_id"],
                "methods": [
                    {
                        "rank": rank,
                        "method": row["method"],
                        "validation_normalized_mean_regret": row[
                            "validation_normalized_mean_regret"
                        ],
                        "ratio_to_best": (
                            float(row["validation_normalized_mean_regret"]) / best
                            if best > 0.0
                            else 1.0
                        ),
                        "training_wall_seconds": row["training_wall_seconds"],
                        "best_epoch": row["best_epoch"],
                        "candidate_count": row["candidate_count"],
                        "run_directory": row["run_directory"],
                        "source_sha256": row["source_sha256"],
                    }
                    for rank, row in enumerate(ordered, start=1)
                ],
            }
        )

    excluded_by_route: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in exclusions:
        excluded_by_route[str(row["route_id"])].append(row)
    excluded_routes = [
        {
            "route_id": route,
            "benchmark_id": route_rows[0]["benchmark_id"],
            "family_id": route_rows[0]["family_id"],
            "reason": route_rows[0]["reason"],
            "completed_run_count": len(route_rows),
            "methods": sorted({str(row["method"]) for row in route_rows}),
        }
        for route, route_rows in sorted(excluded_by_route.items())
    ]
    all_receipts = rows + exclusions
    return {
        "status": "development_only",
        "selection_metric": "validation_normalized_mean_regret",
        "selection_used_test": False,
        "test_evaluated_in_any_input_run": any(
            bool(row["test_evaluated"]) for row in all_receipts
        ),
        "seed_count_per_arm": 1,
        "confirmation_required": True,
        "run_roots": [str(root.resolve()) for root in roots],
        "required_source_sha256_values": (
            None if required_sources is None else sorted(required_sources)
        ),
        "completed_run_count": len(all_receipts),
        "ranked_completed_run_count": len(rows),
        "excluded_run_count": len(exclusions),
        "excluded_route_count": len(excluded_routes),
        "excluded_routes": excluded_routes,
        "benchmark_count": len(by_route),
        "native_benchmark_count": len(
            {str(row["benchmark_id"]) for row in rows}
        ),
        "family_count": len({str(row["family_id"]) for row in rows}),
        "method_win_counts": dict(sorted(winners.items())),
        "source_sha256_values": sorted(
            {str(row["source_sha256"]) for row in all_receipts}
        ),
        "rankings": rankings,
        "selected_arms": selected,
    }


def render_development_markdown(summary: dict[str, Any]) -> str:
    """Render a compact human-readable view without overstating development data."""

    lines = [
        "# Validation-only development summary",
        "",
        (
            f"{summary['ranked_completed_run_count']} rankable completed runs across "
            f"{summary['benchmark_count']} routes in {summary['family_count']} "
            "families. Hyperparameters and model "
            "capacity were selected using validation normalized regret only. "
            "Every arm currently has one seed; this is not confirmation evidence."
        ),
        "",
        "## Method wins",
        "",
        "| Method | Validation wins |",
        "|---|---:|",
    ]
    for method, count in summary["method_win_counts"].items():
        lines.append(f"| {method} | {count} |")
    lines.extend(
        [
            "",
            "## Per-route ranking",
            "",
            (
                "| Route | Rank | Method | Normalized regret | "
                "Ratio to best | Train s |"
            ),
            "|---|---:|---|---:|---:|---:|",
        ]
    )
    for benchmark in summary["rankings"]:
        for row in benchmark["methods"]:
            lines.append(
                "| {benchmark} | {rank} | {method} | {regret:.6g} | "
                "{ratio:.3f} | {seconds:.2f} |".format(
                    benchmark=benchmark["route_id"],
                    rank=row["rank"],
                    method=row["method"],
                    regret=row["validation_normalized_mean_regret"],
                    ratio=row["ratio_to_best"],
                    seconds=row["training_wall_seconds"],
                )
            )
    if summary["excluded_routes"]:
        lines.extend(
            [
                "",
                "## Quarantined zero-scale routes",
                "",
                (
                    f"{summary['excluded_run_count']} completed arms from "
                    f"{summary['excluded_route_count']} routes have undefined "
                    "normalized regret because their reference regret scale is zero. "
                    "They are retained as diagnostics but excluded from ranking and "
                    "promotion."
                ),
                "",
                "| Route | Completed arms | Reason |",
                "|---|---:|---|",
            ]
        )
        for row in summary["excluded_routes"]:
            lines.append(
                f"| {row['route_id']} | {row['completed_run_count']} | "
                f"{row['reason']} |"
            )
    lines.extend(
        [
            "",
            "## Evidence boundary",
            "",
            (
                "- Development split only; test evaluation was disabled for these "
                "campaigns."
            ),
            "- One seed per hyperparameter arm.",
            (
                "- The selected configurations require a paired multi-seed "
                "confirmation run."
            ),
            (
                "- Source hashes and winning run directories are retained in the "
                "JSON receipt."
            ),
            (
                "- Related routes are assigned an explicit family ID and must not "
                "be interpreted as independent benchmark families."
            ),
            "",
        ]
    )
    return "\n".join(lines)
