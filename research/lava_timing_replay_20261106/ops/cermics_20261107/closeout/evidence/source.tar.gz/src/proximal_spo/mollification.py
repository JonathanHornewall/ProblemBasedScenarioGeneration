"""Common-noise mollified proximal reports for continuous cost-learning LPs.

The implementation uses the exact finite-sample Fenchel--Young construction.
For a fixed antithetic perturbation bank ``delta[k]``, the coupled decoder is

    min  mean_k (a + T.T @ delta[k]).T z[k]
         + ||h + mean_k T z[k]||^2 / (2 tau).

It is solved as one sparse product-space QP.  The MSE base and the coupled
decoder share the same perturbations, which is essential for the zero-residual
calibration property.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Literal

import numpy as np
from scipy.sparse import block_diag, csc_matrix, eye, hstack, vstack

from .objectives import BatchSignal, Deployment, TrainingBatch
from .oracles import (
    LPOracle,
    OracleStats,
    ParallelOracle,
    PersistentQPSolver,
    make_lp_oracle,
    make_qp_oracle,
)
from .problem import FloatArray, LinearProblem, PartialCostInterface
from .seeds import derive_seed

BankRole = Literal["training", "evaluation"]


def antithetic_gaussian_bank(
    *, samples: int, dimension: int, random_seed: int, role: str
) -> FloatArray:
    """Return a deterministic bank of paired standard-normal perturbations."""

    if samples <= 0 or samples % 2:
        raise ValueError("samples must be a positive even integer")
    if dimension <= 0:
        raise ValueError("dimension must be positive")
    generator = np.random.Generator(
        # Do not include ``samples`` in the stream identity.  Larger banks are
        # prefix extensions of smaller ones, so the K=16 sensitivity changes
        # Monte Carlo resolution without silently replacing the K=8 draw.
        np.random.PCG64(derive_seed(random_seed, "mollifier", role))
    )
    positive = generator.standard_normal((samples // 2, dimension))
    # Interleaving pairs keeps every prefix ending at an even index antithetic.
    bank = np.empty((samples, dimension), dtype=np.float64)
    bank[0::2] = positive
    bank[1::2] = -positive
    return bank


def _bank_sha256(bank: FloatArray) -> str:
    contiguous = np.ascontiguousarray(bank, dtype=np.float64)
    digest = hashlib.sha256()
    digest.update(str(contiguous.shape).encode("ascii"))
    digest.update(contiguous.tobytes())
    return digest.hexdigest()


def _product_problem(interface: PartialCostInterface, samples: int) -> LinearProblem:
    problem = interface.problem
    assert problem.integrality is not None
    cell_matrix = block_diag([problem.matrix] * samples, format="csc")
    report_dimension = interface.report_dimension
    zero_columns = csc_matrix((cell_matrix.shape[0], report_dimension))
    average_equality = hstack(
        [
            csc_matrix(-np.tile(interface.statistic / samples, (1, samples))),
            eye(report_dimension, format="csc"),
        ],
        format="csc",
    )
    matrix = vstack(
        [hstack([cell_matrix, zero_columns], format="csc"), average_equality],
        format="csc",
    )
    return LinearProblem(
        matrix=matrix,
        row_lower=np.concatenate(
            [np.tile(problem.row_lower, samples), np.zeros(report_dimension)]
        ),
        row_upper=np.concatenate(
            [np.tile(problem.row_upper, samples), np.zeros(report_dimension)]
        ),
        variable_lower=np.concatenate(
            [
                np.tile(problem.variable_lower, samples),
                np.full(report_dimension, -np.inf),
            ]
        ),
        variable_upper=np.concatenate(
            [
                np.tile(problem.variable_upper, samples),
                np.full(report_dimension, np.inf),
            ]
        ),
        integrality=np.concatenate(
            [
                np.tile(problem.integrality, samples),
                np.zeros(report_dimension, dtype=np.int64),
            ]
        ),
        name=f"{problem.name}_product_{samples}",
        metadata={"base_problem": problem.name, "product_cells": samples},
    )


def _cache_key(row: FloatArray) -> bytes:
    # A frozen MSE model can produce roundoff-level differences when evaluated
    # in different outer batch sizes.  Twelve decimals are far below the QP
    # tolerances while making the cache independent of that batching detail.
    return np.ascontiguousarray(np.round(row, decimals=12)).tobytes()


@dataclass(frozen=True)
class MollifiedDecodeDetails:
    deployment: Deployment
    cell_decisions: FloatArray
    base_statistics: FloatArray
    average_statistics: FloatArray
    reports: FloatArray
    decision_residuals: FloatArray
    perturbations: FloatArray


class _ProductDecoder:
    """One persistent product-space QP for a fixed perturbation bank."""

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        tau: float,
        perturbations: FloatArray,
        workers: int,
    ) -> None:
        if not interface.problem.is_continuous:
            raise ValueError(
                "mollified product decoder currently requires a continuous LP"
            )
        self.interface = interface
        self.tau = float(tau)
        self.perturbations = np.ascontiguousarray(perturbations, dtype=np.float64)
        if (
            self.perturbations.ndim != 2
            or self.perturbations.shape[1] != interface.report_dimension
        ):
            raise ValueError("perturbation bank has the wrong shape")
        self.samples = int(len(self.perturbations))
        if self.samples <= 0:
            raise ValueError("perturbation bank cannot be empty")
        self.product_problem = _product_problem(interface, self.samples)
        # We multiply the entire decoder objective by K.  This leaves its
        # minimizers unchanged and avoids a poorly scaled 1/K linear term.
        quadratic = block_diag(
            [
                csc_matrix(
                    (
                        self.samples * interface.problem.variable_count,
                        self.samples * interface.problem.variable_count,
                    )
                ),
                eye(interface.report_dimension, format="csc")
                * (self.samples / self.tau),
            ],
            format="csc",
        )
        self._qp: ParallelOracle[PersistentQPSolver] = make_qp_oracle(
            self.product_problem, quadratic, workers=workers
        )
        perturbed_physical = (
            interface.fixed_cost[None, :] + self.perturbations @ interface.statistic
        )
        self._cell_linear_offset = np.ascontiguousarray(
            perturbed_physical.reshape(-1), dtype=np.float64
        )

    def decode(self, reports: FloatArray) -> tuple[FloatArray, FloatArray, OracleStats]:
        reports = np.asarray(reports, dtype=np.float64)
        if reports.ndim != 2 or reports.shape[1] != self.interface.report_dimension:
            raise ValueError("reports have the wrong shape")
        cell_linear = np.tile(self._cell_linear_offset, (len(reports), 1))
        average_linear = (self.samples / self.tau) * reports
        linear = np.concatenate([cell_linear, average_linear], axis=1)
        solutions = self._qp.solve_many(linear)
        cell_variable_count = self.samples * self.interface.problem.variable_count
        cells = solutions.decisions[:, :cell_variable_count].reshape(
            len(reports), self.samples, self.interface.problem.variable_count
        )
        averages = cells.mean(axis=1)
        reported_average = solutions.decisions[:, cell_variable_count:]
        computed_average = averages @ self.interface.statistic.T
        if not np.allclose(reported_average, computed_average, atol=2e-7):
            raise RuntimeError("product decoder violated its average equality")
        return cells, averages, solutions.stats

    def close(self) -> None:
        self._qp.close()


class MollifiedAnchoredProximalObjective:
    """Frozen-MSE-base, common-noise mollified residual proximal loss."""

    name = "mollified_anchored_proximal"

    def __init__(
        self,
        interface: PartialCostInterface,
        *,
        tau: float,
        sigma: float,
        residual_scale: FloatArray,
        training_samples: int,
        evaluation_samples: int,
        workers: int,
        random_seed: int,
        training_standard_bank: FloatArray | None = None,
        evaluation_standard_bank: FloatArray | None = None,
    ) -> None:
        if not np.isfinite(tau) or tau <= 0.0:
            raise ValueError("tau must be finite and positive")
        if not np.isfinite(sigma) or sigma < 0.0:
            raise ValueError("sigma must be finite and nonnegative")
        if not interface.problem.is_continuous:
            raise ValueError("mollified deployment averages require a continuous LP")
        self.interface = interface
        self.tau = float(tau)
        self.sigma = float(sigma)
        self.output_dimension = 2 * interface.report_dimension
        scale = np.asarray(residual_scale, dtype=np.float64)
        if (
            scale.shape != (interface.report_dimension,)
            or not np.all(np.isfinite(scale))
            or np.any(scale < 0.0)
        ):
            raise ValueError("residual_scale must be a finite nonnegative vector")
        self.residual_scale = np.ascontiguousarray(scale)
        training_standard = (
            antithetic_gaussian_bank(
                samples=training_samples,
                dimension=interface.report_dimension,
                random_seed=random_seed,
                role="training",
            )
            if training_standard_bank is None
            else np.asarray(training_standard_bank, dtype=np.float64)
        )
        if evaluation_standard_bank is not None:
            evaluation_standard = np.asarray(evaluation_standard_bank, dtype=np.float64)
        elif evaluation_samples == training_samples:
            # A fixed finite perturbation bank defines one canonical report map.
            # Reusing it at validation/deployment evaluates the map that was
            # actually trained, rather than silently replacing it with a new
            # Monte Carlo approximation.
            evaluation_standard = training_standard.copy()
        else:
            evaluation_standard = antithetic_gaussian_bank(
                samples=evaluation_samples,
                dimension=interface.report_dimension,
                random_seed=random_seed,
                role="evaluation",
            )
        for name, bank, expected in (
            ("training", training_standard, training_samples),
            ("evaluation", evaluation_standard, evaluation_samples),
        ):
            if bank.shape != (expected, interface.report_dimension):
                raise ValueError(f"{name} standard bank has the wrong shape")
            if not np.all(np.isfinite(bank)):
                raise ValueError(f"{name} standard bank contains non-finite values")
            if not np.allclose(bank.mean(axis=0), 0.0, atol=1e-12):
                raise ValueError(f"{name} perturbations must be antithetic")
        self.training_standard_bank = np.ascontiguousarray(training_standard)
        self.evaluation_standard_bank = np.ascontiguousarray(evaluation_standard)
        self.training_perturbations = np.ascontiguousarray(
            self.sigma * self.training_standard_bank * self.residual_scale
        )
        self.evaluation_perturbations = np.ascontiguousarray(
            self.sigma * self.evaluation_standard_bank * self.residual_scale
        )
        self._base_lp: LPOracle = make_lp_oracle(
            interface.problem, workers=workers, random_seed=random_seed
        )
        deterministic_quadratic = csc_matrix(
            interface.statistic.T @ interface.statistic / self.tau
        )
        self._deterministic_qp: ParallelOracle[PersistentQPSolver] = make_qp_oracle(
            interface.problem, deterministic_quadratic, workers=workers
        )
        self._training_decoder = (
            None
            if self.sigma == 0.0
            else _ProductDecoder(
                interface,
                tau=self.tau,
                perturbations=self.training_perturbations,
                workers=workers,
            )
        )
        self._evaluation_decoder = (
            None
            if self.sigma == 0.0
            else _ProductDecoder(
                interface,
                tau=self.tau,
                perturbations=self.evaluation_perturbations,
                workers=workers,
            )
        )
        self._base_cache: dict[tuple[BankRole, bytes], FloatArray] = {}
        self._target_cache: dict[bytes, FloatArray] = {}
        self._baseline_cache: dict[bytes, FloatArray] = {}

    def _split(self, outputs: FloatArray) -> tuple[FloatArray, FloatArray]:
        outputs = np.asarray(outputs, dtype=np.float64)
        dimension = self.interface.report_dimension
        if outputs.ndim != 2 or outputs.shape[1] != 2 * dimension:
            raise ValueError("mollified output must concatenate base and residual")
        return outputs[:, :dimension], outputs[:, dimension:]

    def _perturbations(self, role: BankRole) -> FloatArray:
        return (
            self.training_perturbations
            if role == "training"
            else self.evaluation_perturbations
        )

    def _base_statistics(
        self, base: FloatArray, *, role: BankRole
    ) -> tuple[FloatArray, OracleStats]:
        base = np.asarray(base, dtype=np.float64)
        keys = [_cache_key(row) for row in base]
        missing_positions = [
            index
            for index, key in enumerate(keys)
            if (role, key) not in self._base_cache
        ]
        stats = OracleStats()
        if missing_positions:
            unique: dict[bytes, FloatArray] = {}
            for index in missing_positions:
                unique.setdefault(keys[index], base[index])
            perturbations = self._perturbations(role)
            rows = list(unique.values())
            coefficients = np.concatenate(
                [row[None, :] + perturbations for row in rows], axis=0
            )
            solved = self._base_lp.solve_many(
                self.interface.physical_cost(coefficients)
            )
            statistics = solved.decisions @ self.interface.statistic.T
            statistics = statistics.reshape(len(rows), len(perturbations), -1).mean(
                axis=1
            )
            for key, statistic in zip(unique, statistics, strict=True):
                self._base_cache[(role, key)] = statistic.copy()
            stats += solved.stats
        return np.stack([self._base_cache[(role, key)] for key in keys]), stats

    def _training_target_values(
        self, coefficients: FloatArray
    ) -> tuple[FloatArray, OracleStats]:
        coefficients = np.asarray(coefficients, dtype=np.float64)
        keys = [_cache_key(row) for row in coefficients]
        missing_positions = [
            index for index, key in enumerate(keys) if key not in self._target_cache
        ]
        stats = OracleStats()
        if missing_positions:
            unique: dict[bytes, FloatArray] = {}
            for index in missing_positions:
                unique.setdefault(keys[index], coefficients[index])
            rows = list(unique.values())
            perturbed = np.concatenate(
                [row[None, :] + self.training_perturbations for row in rows], axis=0
            )
            solved = self._base_lp.solve_many(self.interface.physical_cost(perturbed))
            values = solved.objectives.reshape(
                len(rows), len(self.training_perturbations)
            )
            for key, row_values in zip(unique, values, strict=True):
                self._target_cache[key] = row_values.copy()
            stats += solved.stats
        return np.stack([self._target_cache[key] for key in keys]), stats

    def prime_base_cache(self, base: FloatArray, *, role: BankRole) -> OracleStats:
        """Precompute frozen-base mollified statistics for one split role."""

        _, stats = self._base_statistics(base, role=role)
        return stats

    def prime_training_targets(self, coefficients: FloatArray) -> OracleStats:
        """Precompute perturbed true-value terms used by the compatible loss."""

        if self.sigma == 0.0:
            return OracleStats()
        _, stats = self._training_target_values(coefficients)
        return stats

    def _deterministic_base_decisions(
        self, base: FloatArray
    ) -> tuple[FloatArray, OracleStats]:
        base = np.asarray(base, dtype=np.float64)
        keys = [_cache_key(row) for row in base]
        missing_positions = [
            index for index, key in enumerate(keys) if key not in self._baseline_cache
        ]
        stats = OracleStats()
        if missing_positions:
            unique: dict[bytes, FloatArray] = {}
            for index in missing_positions:
                unique.setdefault(keys[index], base[index])
            rows = np.stack(list(unique.values()))
            solved = self._base_lp.solve_many(self.interface.physical_cost(rows))
            for key, decision in zip(unique, solved.decisions, strict=True):
                self._baseline_cache[key] = decision.copy()
            stats += solved.stats
        return np.stack([self._baseline_cache[key] for key in keys]), stats

    def _deterministic_details(
        self, base: FloatArray, residual: FloatArray
    ) -> MollifiedDecodeDetails:
        baseline, base_stats = self._deterministic_base_decisions(base)
        base_statistics = baseline @ self.interface.statistic.T
        reports = self.tau * base - base_statistics - residual
        linear = (
            self.interface.fixed_cost + (reports / self.tau) @ self.interface.statistic
        )
        solved = self._deterministic_qp.solve_many(linear)
        statistics = solved.decisions @ self.interface.statistic.T
        recovered = (reports + statistics) / self.tau
        deployment = Deployment(solved.decisions, recovered, base_stats + solved.stats)
        return MollifiedDecodeDetails(
            deployment=deployment,
            cell_decisions=solved.decisions[:, None, :],
            base_statistics=base_statistics,
            average_statistics=statistics,
            reports=reports,
            decision_residuals=statistics - base_statistics - residual,
            perturbations=np.zeros((1, self.interface.report_dimension)),
        )

    def decode_details(
        self, outputs: FloatArray, *, role: BankRole = "evaluation"
    ) -> MollifiedDecodeDetails:
        base, residual = self._split(outputs)
        if self.sigma == 0.0:
            return self._deterministic_details(base, residual)
        base_statistics, base_stats = self._base_statistics(base, role=role)
        reports = self.tau * base - base_statistics - residual
        decoder = (
            self._training_decoder if role == "training" else self._evaluation_decoder
        )
        assert decoder is not None
        cells, averages, decoder_stats = decoder.decode(reports)
        statistics = averages @ self.interface.statistic.T
        recovered = (reports + statistics) / self.tau
        deployment = Deployment(averages, recovered, base_stats + decoder_stats)
        return MollifiedDecodeDetails(
            deployment=deployment,
            cell_decisions=cells,
            base_statistics=base_statistics,
            average_statistics=statistics,
            reports=reports,
            decision_residuals=statistics - base_statistics - residual,
            perturbations=self._perturbations(role),
        )

    def deterministic_details(self, outputs: FloatArray) -> MollifiedDecodeDetails:
        base, residual = self._split(outputs)
        return self._deterministic_details(base, residual)

    def baseline_deployment(self, outputs: FloatArray) -> Deployment:
        """Deploy the frozen MSE coefficient predictor without correction."""

        base, _ = self._split(outputs)
        decisions, stats = self._deterministic_base_decisions(base)
        return Deployment(decisions, base, stats)

    def signal(self, outputs: FloatArray, batch: TrainingBatch) -> BatchSignal:
        base, _ = self._split(outputs)
        details = self.decode_details(outputs, role="training")
        recovered = details.deployment.recovered_coefficients
        assert recovered is not None
        recovered_residual = recovered - batch.coefficients
        if self.sigma == 0.0:
            regret = (
                np.sum(batch.physical_costs * details.deployment.decisions, axis=1)
                - batch.target_values
            )
            target_stats = OracleStats()
        else:
            target_values, target_stats = self._training_target_values(
                batch.coefficients
            )
            perturbed_coefficients = (
                batch.coefficients[:, None, :] + self.training_perturbations[None, :, :]
            )
            perturbed_physical = (
                self.interface.fixed_cost[None, None, :]
                + perturbed_coefficients @ self.interface.statistic
            )
            cell_costs = np.einsum(
                "bkn,bkn->bk", perturbed_physical, details.cell_decisions
            )
            regret = np.mean(cell_costs - target_values, axis=1)
        if self.sigma == 0.0:
            tolerance = 5e-7 * (
                1.0
                + np.abs(batch.target_values)
                + np.sum(np.abs(batch.physical_costs), axis=1)
            )
        else:
            tolerance = 5e-7 * (
                1.0
                + np.mean(np.abs(target_values), axis=1)
                + np.mean(np.abs(cell_costs), axis=1)
            )
        if np.any(regret < -tolerance):
            raise RuntimeError(
                "mollified compatible regret is materially negative: "
                f"{np.min(regret):.3e}"
            )
        regret = np.maximum(regret, 0.0)
        values = regret + 0.5 * self.tau * np.sum(recovered_residual**2, axis=1)
        # The MSE base is frozen.  Since h=tau*b-u_sigma(b)-r, the residual
        # gradient is gamma-lambda.  We deliberately do not differentiate the
        # piecewise-constant cached base statistic.
        gradient = np.concatenate([np.zeros_like(base), -recovered_residual], axis=1)
        return BatchSignal(
            values=values,
            output_gradient=gradient,
            stats=details.deployment.stats + target_stats,
            decisions=details.deployment.decisions,
            recovered_coefficients=recovered,
        )

    def deploy(self, outputs: FloatArray) -> Deployment:
        details = self.decode_details(outputs, role="evaluation")
        if self.sigma == 0.0:
            return details.deployment
        recovered = details.deployment.recovered_coefficients
        if recovered is None:
            raise RuntimeError("mollified decoder did not recover coefficients")
        # The mollified cells define a smooth, decision-sufficient cost report.
        # Deployment is the feasible hard optimizer at that recovered cost;
        # averaging the perturbed cell decisions changes the decision problem
        # and can produce a severely biased policy.
        hard = self._base_lp.solve_many(self.interface.physical_cost(recovered))
        return Deployment(
            hard.decisions,
            recovered,
            details.deployment.stats + hard.stats,
        )

    def state(self) -> dict[str, float | int | str]:
        return {
            "tau": self.tau,
            "sigma": self.sigma,
            "training_samples": len(self.training_perturbations),
            "evaluation_samples": len(self.evaluation_perturbations),
            "training_bank_sha256": _bank_sha256(self.training_standard_bank),
            "evaluation_bank_sha256": _bank_sha256(self.evaluation_standard_bank),
            "shared_training_evaluation_bank": bool(
                np.array_equal(
                    self.training_standard_bank, self.evaluation_standard_bank
                )
            ),
            "deployment_rule": "hard_optimizer_at_recovered_cost",
        }

    def receipt(self) -> dict[str, object]:
        return {
            **self.state(),
            "residual_scale": self.residual_scale.tolist(),
            "scaled_training_bank_sha256": _bank_sha256(self.training_perturbations),
            "scaled_evaluation_bank_sha256": _bank_sha256(
                self.evaluation_perturbations
            ),
            "common_noise": True,
            "raw_perturbations_persisted": False,
        }

    def close(self) -> None:
        self._base_lp.close()
        self._deterministic_qp.close()
        if self._training_decoder is not None:
            self._training_decoder.close()
        if self._evaluation_decoder is not None:
            self._evaluation_decoder.close()
