"""Seed-independent identities for experimental routes and related families."""

from __future__ import annotations

import hashlib
import importlib
import json
from typing import Any


def _slug(value: object) -> str:
    return str(value).replace(".", "p").replace("-", "_")


def experimental_route_id(config: dict[str, Any]) -> str:
    """Distinguish data/decision routes that share a native benchmark ID."""

    benchmark = config.get("benchmark_id")
    if not isinstance(benchmark, str) or not benchmark:
        raise ValueError("config lacks benchmark_id")
    source = str(config.get("benchmark_source", "local"))
    if source != "local":
        return benchmark
    law = config.get("law", {})
    if not isinstance(law, dict):
        raise ValueError("config law must be an object")
    contract = {
        "benchmark_id": benchmark,
        "benchmark_source": source,
        "interface": config.get("interface", "partial"),
        "law": law,
    }
    digest = hashlib.sha256(
        json.dumps(contract, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()[:8]
    return (
        f"{benchmark}__{config.get('interface', 'partial')}__"
        f"rf{_slug(law.get('random_fraction', 'na'))}__"
        f"{_slug(law.get('noise', 'na'))}__{digest}"
    )


def physical_dataset_id(config: dict[str, Any]) -> str:
    """Identify one physical data law independently of its report interface.

    Full- and partial-coordinate routes are representation ablations of the
    same contextual learning problem.  They must not receive independent
    weight in family-level inference merely because they expose different
    predictor coordinates.
    """

    benchmark = config.get("benchmark_id")
    if not isinstance(benchmark, str) or not benchmark:
        raise ValueError("config lacks benchmark_id")
    source = str(config.get("benchmark_source", "local"))
    if source != "local":
        return benchmark
    law = config.get("law", {})
    if not isinstance(law, dict):
        raise ValueError("config law must be an object")
    contract = {
        "benchmark_id": benchmark,
        "benchmark_source": source,
        "law": law,
    }
    digest = hashlib.sha256(
        json.dumps(contract, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()[:8]
    return (
        f"{benchmark}__rf{_slug(law.get('random_fraction', 'na'))}__"
        f"{_slug(law.get('noise', 'na'))}__{digest}"
    )


def benchmark_family_id(config: dict[str, Any]) -> str:
    """Return a conservative family label for non-independent route grouping."""

    benchmark = config.get("benchmark_id")
    if not isinstance(benchmark, str) or not benchmark:
        raise ValueError("config lacks benchmark_id")
    source = str(config.get("benchmark_source", "local"))
    if source == "dfl_extensions_lab":
        try:
            registry = importlib.import_module(
                "dfl_extensions_lab.benchmarks.native_factory_registry"
            )
            return str(registry.get_native_factory_route(benchmark).family)
        except (ImportError, KeyError):
            # Keep the paper's frozen DYS family grouping available when the
            # optional benchmark package is not installed in a release-only
            # environment. Unknown external routes remain explicitly unresolved.
            dys_families = {
                "dys_shortest_path_": "dys_shortest_path",
                "dys_knapsack_": "dys_knapsack",
                "dys_cfl_": "dys_facility_location",
            }
            for prefix, family in dys_families.items():
                if benchmark.startswith(prefix):
                    return family
            return f"external_unresolved::{benchmark}"
    if benchmark.startswith("cost.binary_knapsack"):
        return "local_binary_knapsack"
    if benchmark.startswith("cost.knapsack"):
        return "local_continuous_knapsack"
    if benchmark.startswith("cost.facility"):
        return "local_facility_location"
    if benchmark.startswith("cost.random_lp"):
        return "local_random_lp"
    if benchmark.startswith("cost.assignment"):
        return "local_assignment"
    if benchmark.startswith("cost.grid"):
        return "local_grid_shortest_path"
    if benchmark.startswith("cost.topk"):
        return "local_topk"
    if benchmark == "analytic.scalar_box":
        return "analytic_scalar_box_skew"
    return f"local_other::{benchmark}"
