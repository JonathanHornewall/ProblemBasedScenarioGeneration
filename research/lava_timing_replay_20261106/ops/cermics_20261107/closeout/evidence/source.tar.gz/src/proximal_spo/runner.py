"""Assemble data, solvers, model, and incremental artefacts for one run."""

from __future__ import annotations

import fcntl
import hashlib
import importlib.metadata
import json
import os
import tempfile
import time
from collections import OrderedDict
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, cast

import numpy as np
import torch
from scipy.sparse import csc_matrix
from torch import nn

from .artifacts import (
    RunRecorder,
    model_sha256,
    source_sha256,
    with_pipeline_accounting,
    write_json,
)
from .barrier_protocols import (
    BarrierProtocolSpec,
    train_barrier_protocol_suite,
)
from .benchmarks import build_benchmark
from .config import RunSpec
from .data import DatasetBundle, generate_dataset
from .evaluation import evaluate_model, evaluate_outputs, predict_in_batches
from .exact_head import (
    solve_exact_proximal_head,
    solve_exact_proximal_head_decomposed,
)
from .external_benchmarks import load_external_benchmark
from .models import (
    AnchoredModel,
    KNNRegressor,
    ModelSpec,
    StandardizedMLP,
    input_statistics,
    module_dtype,
)
from .mollification import MollifiedAnchoredProximalObjective
from .neural_prediction_correction import (
    NeuralCorrectionSplit,
    fit_neural_prediction_corrections,
    fit_pair_mse_network,
    mse_network_arrays,
)
from .objectives import (
    AnchoredProximalObjective,
    CostPredictionObjective,
    DirectProjectionObjective,
    LearningObjective,
    LogBarrierSmoothingObjective,
    LogEnergyPolicyObjective,
    PerturbedFenchelYoungObjective,
    PreparedSplit,
    ProximalObjective,
    QuadraticSmoothingObjective,
    RayenPolicyObjective,
    ResidualMSEObjective,
    ScoreFunctionObjective,
    SFGEObjective,
    SmoothedSCEObjective,
    SoftRadialLogBarrierObjective,
    SoftRadialPolicyObjective,
    SPOPlusObjective,
    WISEObjective,
    prepare_split,
    sample_keys_for_split,
)
from .oracles import OracleStats, make_lp_oracle
from .prediction_correction import (
    CorrectionSplit,
    DecisionInvariantGeometry,
    fit_prediction_corrections,
    prediction_metrics,
)
from .problem import LinearProblem, PartialCostInterface
from .training import TrainingResult, train_model

_PREPARED_CACHE_SCHEMA = "prepared-reference-v2-keyed-specialized-oracles"
_POLICY_RELAXATION_CACHE_SCHEMA = "policy-relaxation-reference-v1"
_DATASET_CACHE: OrderedDict[str, tuple[Any, DatasetBundle, dict[str, Any]]] = (
    OrderedDict()
)


@dataclass(frozen=True)
class CoefficientTransform:
    mode: str
    mean: np.ndarray
    scale: np.ndarray
    constant_coordinate_count: int = 0

    def apply(self, coefficients: np.ndarray) -> np.ndarray:
        values = np.asarray(coefficients, dtype=np.float64)
        return np.ascontiguousarray((values - self.mean) / self.scale)

    def interface(self, base: PartialCostInterface) -> PartialCostInterface:
        fixed = base.fixed_cost + self.mean @ base.statistic
        statistic = self.scale[:, None] * base.statistic
        return PartialCostInterface(
            base.problem,
            fixed,
            statistic,
            name=f"{base.name}.{self.mode}",
        )

    def receipt(self) -> dict[str, Any]:
        def digest(value: np.ndarray) -> str:
            return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()

        return {
            "mode": self.mode,
            "dimension": len(self.mean),
            "mean_sha256": digest(self.mean),
            "scale_sha256": digest(self.scale),
            "mean_minimum": float(np.min(self.mean)),
            "mean_maximum": float(np.max(self.mean)),
            "scale_minimum": float(np.min(self.scale)),
            "scale_median": float(np.median(self.scale)),
            "scale_maximum": float(np.max(self.scale)),
            "constant_coordinate_count": self.constant_coordinate_count,
            "unit_scale_coordinate_count": int(np.sum(self.scale == 1.0)),
            "physical_cost_identity": (
                "c = (a + mean^T P) + beta^T diag(scale) P; "
                "beta = (gamma - mean) / scale"
            ),
            "raw_statistics_persisted": False,
        }


def _coefficient_transform(
    spec: RunSpec,
    dataset: DatasetBundle,
    base_interface: PartialCostInterface,
) -> tuple[PartialCostInterface, CoefficientTransform]:
    coefficients, _ = dataset.coefficients(dataset.train, spec.interface)
    dimension = coefficients.shape[1]
    if spec.cost_coordinate_normalization == "none":
        transform = CoefficientTransform(
            mode="none",
            mean=np.zeros(dimension, dtype=np.float64),
            scale=np.ones(dimension, dtype=np.float64),
            constant_coordinate_count=0,
        )
    else:
        mean = np.mean(coefficients, axis=0)
        raw_scale = np.std(coefficients, axis=0)
        positive = raw_scale[raw_scale > 0.0]
        floor = max(
            1e-12,
            (float(np.median(positive)) * 1e-6 if positive.size else 1e-12),
        )
        scale = np.where(raw_scale > floor, raw_scale, 1.0)
        transform = CoefficientTransform(
            "standardize",
            mean,
            scale,
            constant_coordinate_count=int(np.sum(raw_scale <= floor)),
        )
    interface = transform.interface(base_interface)
    reconstructed = interface.physical_cost(transform.apply(coefficients))
    if not np.allclose(
        reconstructed, dataset.train.physical_costs, rtol=2e-10, atol=2e-10
    ):
        raise RuntimeError("cost-coordinate transform changed physical costs")
    return interface, transform


def _digest_array(digest: Any, value: np.ndarray) -> None:
    array = np.ascontiguousarray(value)
    digest.update(str(array.dtype).encode("ascii"))
    digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
    digest.update(array.view(np.uint8))


def _prepared_cache_key(
    dataset: DatasetBundle,
    interface: PartialCostInterface,
    interface_mode: str,
) -> str:
    digest = hashlib.sha256()
    digest.update(_PREPARED_CACHE_SCHEMA.encode("utf-8"))
    # Reference decisions include solver tie-breaking and specialized-oracle
    # behavior. Bind the cache to the executable tree so an implementation
    # change cannot silently reuse decisions prepared by older code.
    digest.update(source_sha256(Path(__file__).resolve().parents[2]).encode("ascii"))
    for package in ("highspy", "numpy", "scipy"):
        digest.update(package.encode("ascii"))
        digest.update(importlib.metadata.version(package).encode("ascii"))
    digest.update(dataset.benchmark_id.encode("utf-8"))
    digest.update(interface_mode.encode("utf-8"))
    problem = interface.problem
    matrix = csc_matrix(problem.matrix)
    for array in (
        matrix.data,
        matrix.indices,
        matrix.indptr,
        problem.row_lower,
        problem.row_upper,
        problem.variable_lower,
        problem.variable_upper,
        problem.integrality,
        interface.fixed_cost,
        interface.statistic,
    ):
        _digest_array(digest, np.asarray(array))
    for split in (dataset.train, dataset.validation, dataset.test):
        digest.update(split.split.encode("utf-8"))
        for array in (
            split.contexts,
            split.physical_costs,
            split.conditional_mean_costs,
        ):
            _digest_array(digest, array)
    return digest.hexdigest()


def _prepared_cache_directory() -> Path:
    configured = os.environ.get("PROXIMAL_SPO_PREPARED_CACHE_DIR")
    if configured:
        return Path(configured).expanduser().resolve()
    return Path(tempfile.gettempdir()) / "proximal_spo_prepared_cache_v2"


@contextmanager
def _exclusive_cache_lock(path: Path) -> Iterator[None]:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+b") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _objective(
    spec: RunSpec,
    interface: PartialCostInterface,
    train: PreparedSplit | None = None,
    *,
    deployment_problem: LinearProblem | None = None,
) -> LearningObjective:
    parameters = spec.method_parameters
    if spec.method == "intopt_original":
        from .intopt_original import OriginalIntOptObjective
        return OriginalIntOptObjective(
            interface.problem if deployment_problem is None else deployment_problem,
            mu_cutoff=float(parameters.get("mu_cutoff", 1e-3)))
    if spec.method in {"mse", "knn"}:
        return CostPredictionObjective(
            interface, workers=spec.workers, random_seed=spec.seeds.structural
        )
    if spec.method == "wise":
        return WISEObjective(
            interface, workers=spec.workers, random_seed=spec.seeds.structural
        )
    if spec.method in {"spo_plus", "spo_plus_relaxation"}:
        return SPOPlusObjective(
            interface,
            workers=spec.workers,
            random_seed=spec.seeds.structural,
            deployment_problem=deployment_problem,
        )
    if spec.method in {"pyepo_spo_plus", "pyepo_spo_plus_relaxation"}:
        # Keep the commercial-solver baseline optional for users who only run
        # the open-source experiment stack.
        from .pyepo_baseline import PyEPOSPOPlusObjective

        return PyEPOSPOPlusObjective(
            interface,
            deployment_problem=deployment_problem,
            solver_backend=str(parameters.get("solver_backend", "gurobi")),
        )
    if spec.method == "perturbed_fy":
        return PerturbedFenchelYoungObjective(
            interface,
            epsilon=float(parameters.get("epsilon", 1.0)),
            samples=int(parameters.get("samples", 3)),
            workers=spec.workers,
            random_seed=spec.seeds.perturbation,
        )
    if spec.method == "proximal":
        tau = float(parameters.get("tau", 0.3))
        parameterization = str(parameters.get("parameterization", "raw"))
        if parameterization not in {"raw", "normalized"}:
            raise ValueError("proximal parameterization must be raw or normalized")
        return ProximalObjective(
            interface,
            tau=tau,
            workers=spec.workers,
            report_scale=tau if parameterization == "normalized" else 1.0,
        )
    if spec.method == "anchored_proximal":
        return AnchoredProximalObjective(
            interface,
            tau=float(parameters.get("tau", 0.3)),
            alpha=float(parameters.get("alpha", 1.0)),
            workers=spec.workers,
            random_seed=spec.seeds.structural,
            center_on_base_decision=bool(
                parameters.get("center_on_base_decision", True)
            ),
        )
    if spec.method == "residual_mse":
        return ResidualMSEObjective(
            interface,
            workers=spec.workers,
            random_seed=spec.seeds.structural,
        )
    if spec.method == "score_function":
        return ScoreFunctionObjective(
            interface,
            sigma=float(parameters.get("sigma", 0.1)),
            samples=int(parameters.get("samples", 8)),
            workers=spec.workers,
            random_seed=spec.seeds.perturbation,
        )
    if spec.method in {"sfge", "sfge_relaxation"}:
        return SFGEObjective(
            interface,
            sigma=float(parameters.get("sigma", 0.1)),
            samples=int(parameters.get("samples", 8)),
            workers=spec.workers,
            random_seed=spec.seeds.perturbation,
            deployment_problem=deployment_problem,
        )
    if spec.method == "quadratic_smoothing":
        return QuadraticSmoothingObjective(
            interface,
            smoothing=float(parameters.get("smoothing", 0.1)),
            workers=spec.workers,
            random_seed=spec.seeds.structural,
        )
    if spec.method == "smoothed_sce":
        return SmoothedSCEObjective(
            interface,
            smoothing=float(parameters.get("smoothing", 0.1)),
            workers=spec.workers,
            random_seed=spec.seeds.structural,
        )
    if spec.method == "direct_projection":
        return DirectProjectionObjective(
            interface,
            workers=spec.workers,
        )
    if spec.method == "rayen_policy":
        return RayenPolicyObjective(interface)
    if spec.method == "soft_radial_policy":
        return SoftRadialPolicyObjective(
            interface,
            contraction=str(parameters.get("contraction", "rational")),
            contraction_scale=float(parameters.get("contraction_scale", 1.0)),
            minimum_scale=float(parameters.get("minimum_scale", 0.01)),
            kernel_backend=str(parameters.get("kernel_backend", "numpy")),
            torch_device=str(parameters.get("torch_device", "auto")),
            training_dtype=spec.model.dtype,
        )
    if spec.method == "soft_radial_log_barrier":
        if train is None:
            raise ValueError(
                "soft-radial log-barrier scaling requires the training split"
            )
        return SoftRadialLogBarrierObjective(
            interface,
            contraction=str(parameters.get("contraction", "rational")),
            contraction_scale=float(parameters.get("contraction_scale", 1.0)),
            minimum_scale=float(parameters.get("minimum_scale", 0.01)),
            alpha_start=float(parameters.get("alpha_start", 0.0)),
            alpha_end=float(
                parameters.get("alpha_end", parameters.get("alpha_start", 0.0))
            ),
            schedule=str(parameters.get("schedule", "fixed")),
            anneal_fraction=float(parameters.get("anneal_fraction", 0.75)),
            workers=spec.workers,
            random_seed=spec.seeds.structural,
            training_physical_costs=train.physical_costs,
            training_target_values=train.target_values,
            deployment_problem=deployment_problem,
            kernel_backend=str(parameters.get("kernel_backend", "numpy")),
            torch_device=str(parameters.get("torch_device", "auto")),
            training_dtype=spec.model.dtype,
            report_guard=parameters.get("report_guard", True),
            hessian_whitening=parameters.get("hessian_whitening", True),
            guard_safety_factor=float(parameters.get("guard_safety_factor", 0.5)),
            guard_radius_policy=str(parameters.get("guard_radius_policy", "legacy_unit")),
            barrier_cost_scaling=str(parameters.get("barrier_cost_scaling", "training_center_regret")),
        )
    if spec.method == "log_energy_policy":
        alpha_start = parameters.get("alpha_start")
        if alpha_start is not None and train is None:
            raise ValueError("log-energy alpha scaling requires the training split")
        return LogEnergyPolicyObjective(
            interface,
            mu_start=(
                None
                if alpha_start is not None
                else float(parameters.get("mu_start", 0.3))
            ),
            mu_end=(
                None
                if alpha_start is not None
                else float(parameters.get("mu_end", parameters.get("mu_start", 0.3)))
            ),
            alpha_start=(None if alpha_start is None else float(alpha_start)),
            alpha_end=(
                None
                if alpha_start is None
                else float(parameters.get("alpha_end", alpha_start))
            ),
            schedule=(
                None if "schedule" not in parameters else str(parameters["schedule"])
            ),
            anneal_fraction=float(parameters.get("anneal_fraction", 0.75)),
            energy_guard=str(parameters.get("energy_guard", "uncapped")),
            training_root_tolerance=float(
                parameters.get("training_root_tolerance", 1e-6)
            ),
            evaluation_root_tolerance=float(
                parameters.get("evaluation_root_tolerance", 1e-8)
            ),
            matrix_backend=str(parameters.get("matrix_backend", "auto")),
            kernel_backend=str(parameters.get("kernel_backend", "numpy")),
            torch_device=str(parameters.get("torch_device", "auto")),
            training_physical_costs=(None if train is None else train.physical_costs),
            training_target_values=(None if train is None else train.target_values),
            workers=spec.workers,
            random_seed=spec.seeds.structural,
        )
    if spec.method == "log_smoothing":
        return LogBarrierSmoothingObjective(
            interface,
            mu_start=float(parameters.get("mu_start", 0.3)),
            mu_end=float(parameters.get("mu_end", parameters.get("mu_start", 0.3))),
            workers=spec.workers,
            random_seed=spec.seeds.structural,
        )
    raise AssertionError(spec.method)


def _problem_and_dataset(
    spec: RunSpec,
) -> tuple[Any, DatasetBundle, dict[str, Any]]:
    cache_payload = {
        "benchmark_source": spec.benchmark_source,
        "benchmark_id": spec.benchmark_id,
        "sizes": asdict(spec.sizes),
        "data_seed": spec.seeds.data,
        "structural_seed": spec.seeds.structural,
        "law": asdict(spec.law),
        "conditional_reference_samples": spec.conditional_reference_samples,
    }
    cache_key = hashlib.sha256(
        json.dumps(cache_payload, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    cached = _DATASET_CACHE.pop(cache_key, None)
    if cached is not None:
        _DATASET_CACHE[cache_key] = cached
        provenance = dict(cached[2])
        provenance["in_process_dataset_cache"] = {
            "hit": True,
            "key": cache_key,
            "raw_data_persisted": False,
        }
        return cached[0], cached[1], provenance

    if spec.benchmark_source == "dfl_extensions_lab":
        loaded = load_external_benchmark(
            spec.benchmark_id,
            spec.sizes,
            data_seed=spec.seeds.data,
            conditional_reference_samples=spec.conditional_reference_samples,
        )
        provenance = dict(loaded.provenance)
        provenance["run_spec_law_ignored"] = True
        problem, dataset = loaded.problem, loaded.dataset
    else:
        problem = build_benchmark(
            spec.benchmark_id, structural_seed=spec.seeds.structural
        )
        dataset = generate_dataset(
            problem,
            spec.benchmark_id,
            spec.sizes,
            data_seed=spec.seeds.data,
            structural_seed=spec.seeds.structural,
            law=spec.law,
        )
        provenance = {
            "benchmark_source": "local",
            "benchmark_id": spec.benchmark_id,
            "structural_seed": spec.seeds.structural,
        }
    capacity = int(os.environ.get("PROXIMAL_SPO_DATASET_CACHE_ENTRIES", "3"))
    if capacity < 0:
        raise ValueError("PROXIMAL_SPO_DATASET_CACHE_ENTRIES must be nonnegative")
    if capacity:
        _DATASET_CACHE[cache_key] = (problem, dataset, dict(provenance))
        while len(_DATASET_CACHE) > capacity:
            _DATASET_CACHE.popitem(last=False)
    provenance["in_process_dataset_cache"] = {
        "hit": False,
        "key": cache_key,
        "capacity": capacity,
        "raw_data_persisted": False,
    }
    return problem, dataset, provenance


def _prepare(
    spec: RunSpec,
    dataset: DatasetBundle,
    interface: PartialCostInterface,
    transform: CoefficientTransform,
) -> tuple[
    PreparedSplit,
    PreparedSplit,
    PreparedSplit,
    OracleStats,
    dict[str, Any],
]:
    cache_key = _prepared_cache_key(dataset, interface, spec.interface)
    cache_directory = _prepared_cache_directory()
    cache_path = cache_directory / f"{cache_key}.npz"
    cache_enabled = os.environ.get("PROXIMAL_SPO_DISABLE_PREPARED_CACHE") != "1"

    def cached_split(
        split: Any,
        archive: Any,
    ) -> PreparedSplit:
        raw_coefficients, raw_means = dataset.coefficients(split, spec.interface)
        coefficients = transform.apply(raw_coefficients)
        means = transform.apply(raw_means)
        prefix = split.split
        target_decisions = np.asarray(
            archive[f"{prefix}_target_decisions"], dtype=np.float64
        )
        target_values = np.asarray(archive[f"{prefix}_target_values"], dtype=np.float64)
        conditional_decisions = np.asarray(
            archive[f"{prefix}_conditional_target_decisions"], dtype=np.float64
        )
        conditional_values = np.asarray(
            archive[f"{prefix}_conditional_target_values"], dtype=np.float64
        )
        expected_decision_shape = (
            split.size,
            interface.problem.variable_count,
        )
        if (
            target_decisions.shape != expected_decision_shape
            or conditional_decisions.shape != expected_decision_shape
            or target_values.shape != (split.size,)
            or conditional_values.shape != (split.size,)
        ):
            raise ValueError("prepared-reference cache has incompatible shapes")
        return PreparedSplit(
            contexts=split.contexts,
            coefficients=coefficients,
            conditional_mean_coefficients=means,
            physical_costs=split.physical_costs,
            conditional_mean_costs=split.conditional_mean_costs,
            target_decisions=target_decisions,
            target_values=target_values,
            conditional_target_decisions=conditional_decisions,
            conditional_target_values=conditional_values,
            split=split.split,
            preparation_stats=OracleStats(),
            sample_keys=sample_keys_for_split(split.split, split.size),
        )

    def read_cache() -> tuple[PreparedSplit, PreparedSplit, PreparedSplit] | None:
        if not cache_path.is_file():
            return None
        try:
            with np.load(cache_path, allow_pickle=False) as archive:
                if str(archive["schema"].item()) != _PREPARED_CACHE_SCHEMA:
                    return None
                prepared = tuple(
                    cached_split(split, archive)
                    for split in (dataset.train, dataset.validation, dataset.test)
                )
        except (OSError, KeyError, ValueError):
            return None
        return prepared  # type: ignore[return-value]

    if cache_enabled:
        cache_directory.mkdir(parents=True, exist_ok=True)
        lock_path = cache_directory / f"{cache_key}.lock"
        with _exclusive_cache_lock(lock_path):
            cached = read_cache()
            if cached is not None:
                return (
                    cached[0],
                    cached[1],
                    cached[2],
                    OracleStats(),
                    {
                        "enabled": True,
                        "hit": True,
                        "key": cache_key,
                        "schema": _PREPARED_CACHE_SCHEMA,
                        "cached_contexts": False,
                        "cached_cost_scenarios": False,
                        "cached_reference_solutions": True,
                    },
                )

            prepared, total = _solve_prepared_splits(
                spec, dataset, interface, transform
            )
            temporary_path: Path | None = None
            try:
                with tempfile.NamedTemporaryFile(
                    mode="w+b",
                    prefix=f"{cache_key}.",
                    suffix=".tmp",
                    dir=cache_directory,
                    delete=False,
                ) as handle:
                    temporary_path = Path(handle.name)
                    payload: dict[str, Any] = {
                        "schema": np.asarray(_PREPARED_CACHE_SCHEMA),
                    }
                    for item in prepared:
                        payload[f"{item.split}_target_decisions"] = (
                            item.target_decisions
                        )
                        payload[f"{item.split}_target_values"] = item.target_values
                        payload[f"{item.split}_conditional_target_decisions"] = (
                            item.conditional_target_decisions
                        )
                        payload[f"{item.split}_conditional_target_values"] = (
                            item.conditional_target_values
                        )
                    np.savez(handle, **payload)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary_path, cache_path)
                temporary_path = None
            finally:
                if temporary_path is not None:
                    temporary_path.unlink(missing_ok=True)
            return (
                prepared[0],
                prepared[1],
                prepared[2],
                total,
                {
                    "enabled": True,
                    "hit": False,
                    "key": cache_key,
                    "schema": _PREPARED_CACHE_SCHEMA,
                    "cached_contexts": False,
                    "cached_cost_scenarios": False,
                    "cached_reference_solutions": True,
                },
            )

    prepared, total = _solve_prepared_splits(spec, dataset, interface, transform)
    return (
        prepared[0],
        prepared[1],
        prepared[2],
        total,
        {
            "enabled": False,
            "hit": False,
            "key": cache_key,
            "schema": _PREPARED_CACHE_SCHEMA,
            "cached_reference_solutions": False,
        },
    )


def _solve_prepared_splits(
    spec: RunSpec,
    dataset: DatasetBundle,
    interface: PartialCostInterface,
    transform: CoefficientTransform,
) -> tuple[tuple[PreparedSplit, PreparedSplit, PreparedSplit], OracleStats]:
    problem = interface.problem
    total = OracleStats()
    with make_lp_oracle(
        problem, workers=spec.workers, random_seed=spec.seeds.structural
    ) as oracle:
        prepared: list[PreparedSplit] = []
        for split in (dataset.train, dataset.validation, dataset.test):
            raw_coefficients, raw_means = dataset.coefficients(split, spec.interface)
            coefficients = transform.apply(raw_coefficients)
            means = transform.apply(raw_means)
            item = prepare_split(
                contexts=split.contexts,
                coefficients=coefficients,
                conditional_mean_coefficients=means,
                physical_costs=split.physical_costs,
                conditional_mean_costs=split.conditional_mean_costs,
                split=split.split,
                oracle=oracle,
            )
            prepared.append(item)
            total += item.preparation_stats
    return (prepared[0], prepared[1], prepared[2]), total


def _relaxation_policy_training_data(
    spec: RunSpec,
    dataset: DatasetBundle,
    hard_interface: PartialCostInterface,
    train: PreparedSplit,
    validation: PreparedSplit,
    test: PreparedSplit,
) -> tuple[PartialCostInterface, PreparedSplit, OracleStats, dict[str, Any]]:
    """Pair a continuous training chart with true hard-MIP references.

    Only the observed training optimum is replaced, because it is the
    label-only constant in the matched barrier/FY loss.  Conditional validation
    and test references remain the original MIP optima.  Relaxation optima for
    all conditional panels are nevertheless cached and reported so a claimed
    mixed-integer experiment cannot accidentally be an ideal formulation.
    """

    hard_problem = hard_interface.problem
    if hard_problem.is_continuous:
        return (
            hard_interface,
            train,
            OracleStats(),
            {
                "active": False,
                "reason": "deployment problem is continuous",
            },
        )
    relaxed_problem = hard_problem.continuous_relaxation()
    relaxed_interface = PartialCostInterface(
        relaxed_problem,
        hard_interface.fixed_cost,
        hard_interface.statistic,
        name=f"{hard_interface.name}.continuous_relaxation",
    )
    key = _prepared_cache_key(dataset, hard_interface, spec.interface)
    cache_path = _prepared_cache_directory() / f"{key}.policy_relaxation.npz"
    cache_enabled = os.environ.get("PROXIMAL_SPO_DISABLE_PREPARED_CACHE") != "1"

    def read_cache() -> dict[str, np.ndarray] | None:
        if not cache_path.is_file():
            return None
        try:
            with np.load(cache_path, allow_pickle=False) as archive:
                if str(archive["schema"].item()) != _POLICY_RELAXATION_CACHE_SCHEMA:
                    return None
                values = {
                    "train_decisions": np.asarray(
                        archive["train_decisions"], dtype=np.float64
                    ),
                    "train_values": np.asarray(
                        archive["train_values"], dtype=np.float64
                    ),
                    "train_conditional_values": np.asarray(
                        archive["train_conditional_values"], dtype=np.float64
                    ),
                    "validation_conditional_values": np.asarray(
                        archive["validation_conditional_values"], dtype=np.float64
                    ),
                    "test_conditional_values": np.asarray(
                        archive["test_conditional_values"], dtype=np.float64
                    ),
                }
        except (OSError, KeyError, ValueError):
            return None
        if values["train_decisions"].shape != train.target_decisions.shape:
            return None
        expected = {
            "train_values": (len(train.contexts),),
            "train_conditional_values": (len(train.contexts),),
            "validation_conditional_values": (len(validation.contexts),),
            "test_conditional_values": (len(test.contexts),),
        }
        if any(values[name].shape != shape for name, shape in expected.items()):
            return None
        return values

    values: dict[str, np.ndarray] | None = None
    cache_hit = False
    total = OracleStats()
    if cache_enabled:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        lock_path = cache_path.with_suffix(".lock")
        with _exclusive_cache_lock(lock_path):
            values = read_cache()
            cache_hit = values is not None
            if values is None:
                with make_lp_oracle(
                    relaxed_problem,
                    workers=spec.workers,
                    random_seed=spec.seeds.structural,
                ) as oracle:
                    observed = oracle.solve_many(
                        train.physical_costs, train.sample_keys
                    )
                    train_conditional = oracle.solve_many(
                        train.conditional_mean_costs, train.sample_keys
                    )
                    validation_conditional = oracle.solve_many(
                        validation.conditional_mean_costs,
                        validation.sample_keys,
                    )
                    test_conditional = oracle.solve_many(
                        test.conditional_mean_costs, test.sample_keys
                    )
                total = (
                    observed.stats
                    + train_conditional.stats
                    + validation_conditional.stats
                    + test_conditional.stats
                )
                values = {
                    "train_decisions": observed.decisions,
                    "train_values": observed.objectives,
                    "train_conditional_values": train_conditional.objectives,
                    "validation_conditional_values": (
                        validation_conditional.objectives
                    ),
                    "test_conditional_values": test_conditional.objectives,
                }
                temporary_path: Path | None = None
                try:
                    with tempfile.NamedTemporaryFile(
                        mode="w+b",
                        prefix=f"{key}.policy_relaxation.",
                        suffix=".tmp",
                        dir=cache_path.parent,
                        delete=False,
                    ) as handle:
                        temporary_path = Path(handle.name)
                        np.savez(
                            handle,
                            schema=np.asarray(_POLICY_RELAXATION_CACHE_SCHEMA),
                            **cast(dict[str, Any], values),
                        )
                        handle.flush()
                        os.fsync(handle.fileno())
                    os.replace(temporary_path, cache_path)
                    temporary_path = None
                finally:
                    if temporary_path is not None:
                        temporary_path.unlink(missing_ok=True)
    if values is None:
        with make_lp_oracle(
            relaxed_problem,
            workers=spec.workers,
            random_seed=spec.seeds.structural,
        ) as oracle:
            observed = oracle.solve_many(train.physical_costs, train.sample_keys)
            train_conditional = oracle.solve_many(
                train.conditional_mean_costs, train.sample_keys
            )
            validation_conditional = oracle.solve_many(
                validation.conditional_mean_costs, validation.sample_keys
            )
            test_conditional = oracle.solve_many(
                test.conditional_mean_costs, test.sample_keys
            )
        total = (
            observed.stats
            + train_conditional.stats
            + validation_conditional.stats
            + test_conditional.stats
        )
        values = {
            "train_decisions": observed.decisions,
            "train_values": observed.objectives,
            "train_conditional_values": train_conditional.objectives,
            "validation_conditional_values": validation_conditional.objectives,
            "test_conditional_values": test_conditional.objectives,
        }

    def gap_receipt(
        hard_values: np.ndarray, relaxation_values: np.ndarray
    ) -> dict[str, float]:
        gap = np.asarray(hard_values) - np.asarray(relaxation_values)
        tolerance = 5e-7 * (1.0 + np.abs(hard_values) + np.abs(relaxation_values))
        if np.any(gap < -tolerance):
            raise RuntimeError(
                "continuous relaxation is materially worse than its hard MIP"
            )
        gap = np.maximum(gap, 0.0)
        denominator = max(float(np.mean(np.abs(hard_values))), 1e-12)
        return {
            "mean_absolute_objective_gap": float(np.mean(gap)),
            "maximum_absolute_objective_gap": float(np.max(gap, initial=0.0)),
            "positive_gap_rate": float(np.mean(gap > tolerance)),
            "normalized_mean_gap": float(np.mean(gap) / denominator),
        }

    relaxed_train = replace(
        train,
        target_decisions=values["train_decisions"],
        target_values=values["train_values"],
    )
    receipt = {
        "active": True,
        "training_problem": relaxed_problem.name,
        "deployment_problem": hard_problem.name,
        "hard_integer_variable_count": int(
            np.sum(cast(np.ndarray[Any, np.dtype[np.int64]], hard_problem.integrality))
        ),
        "training_integer_variable_count": 0,
        "training_reference": "continuous-relaxation optimum",
        "validation_and_test_reference": "hard-MIP optimum",
        "deployment": "hard-MIP solve under recovered cost",
        "cache": {
            "enabled": cache_enabled,
            "hit": cache_hit,
            "key": key,
            "schema": _POLICY_RELAXATION_CACHE_SCHEMA,
        },
        "observed_train_integrality_gap": gap_receipt(
            train.target_values, values["train_values"]
        ),
        "conditional_integrality_gap": {
            "train": gap_receipt(
                train.conditional_target_values,
                values["train_conditional_values"],
            ),
            "validation": gap_receipt(
                validation.conditional_target_values,
                values["validation_conditional_values"],
            ),
            "test": gap_receipt(
                test.conditional_target_values,
                values["test_conditional_values"],
            ),
        },
    }
    return relaxed_interface, relaxed_train, total, receipt


def _global_reference(
    spec: RunSpec,
    train: PreparedSplit,
    interface: PartialCostInterface,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    mean_coefficient = np.mean(train.coefficients, axis=0)
    mean_physical = interface.physical_cost(mean_coefficient[None, :])
    with make_lp_oracle(
        interface.problem, workers=1, random_seed=spec.seeds.structural
    ) as oracle:
        decision = oracle.solve_many(mean_physical).decisions[0]
    statistic = interface.statistic @ decision
    return mean_coefficient, statistic, decision


def _split_diagnostics(
    split: PreparedSplit, static_decision: np.ndarray
) -> dict[str, Any]:
    rounded = np.round(split.conditional_target_decisions, decimals=7)
    _, counts = np.unique(rounded, axis=0, return_counts=True)
    static_regret = (
        split.conditional_mean_costs @ static_decision - split.conditional_target_values
    )
    return {
        "samples": len(split.contexts),
        "unique_conditional_decisions": int(len(counts)),
        "dominant_conditional_decision_rate": float(counts.max() / counts.sum()),
        "mean_static_policy_regret": float(np.mean(np.maximum(static_regret, 0.0))),
        "positive_static_policy_regret_rate": float(np.mean(static_regret > 1e-8)),
        "conditional_cost_coordinate_std_mean": float(
            np.std(split.conditional_mean_costs, axis=0).mean()
        ),
    }


def diagnose_dataset(spec: RunSpec) -> dict[str, Any]:
    """Regenerate a configured dataset and measure contextual decision richness.

    This deliberately stops before model construction or training.  It uses the
    same benchmark, data, interface, and preparation path as ``run_experiment``
    so that a diagnostic receipt describes the exact proposed experiment.
    """

    problem, dataset, benchmark_provenance = _problem_and_dataset(spec)
    base_interface = dataset.interface(spec.interface, problem)
    interface, transform = _coefficient_transform(spec, dataset, base_interface)
    train, validation, test, preparation_stats, preparation_cache = _prepare(
        spec, dataset, interface, transform
    )
    _, _, static_decision = _global_reference(spec, train, interface)
    return {
        "benchmark_id": spec.benchmark_id,
        "interface": spec.interface,
        "seeds": spec.to_dict()["seeds"],
        "train": _split_diagnostics(train, static_decision),
        "validation": _split_diagnostics(validation, static_decision),
        "test": _split_diagnostics(test, static_decision),
        "preparation_oracle_stats": {
            "calls": preparation_stats.calls,
            "iterations": preparation_stats.iterations,
            "failures": preparation_stats.failures,
            "solver_seconds": preparation_stats.solver_seconds,
            "wall_seconds": preparation_stats.wall_seconds,
        },
        "prepared_reference_cache": preparation_cache,
        "benchmark_provenance": benchmark_provenance,
        "cost_coordinate_transform": transform.receipt(),
        "raw_data_persisted": False,
    }


def _standard_model(
    spec: RunSpec,
    train: PreparedSplit,
    objective: LearningObjective,
    mean_coefficient: np.ndarray,
    mean_statistic: np.ndarray,
) -> StandardizedMLP:
    input_mean, input_scale = input_statistics(train.contexts)
    if spec.method == "proximal":
        tau = float(spec.method_parameters.get("tau", 0.3))
        scale = float(getattr(objective, "report_scale", 1.0))
        output_bias = (tau * mean_coefficient - mean_statistic) / scale
    elif spec.method == "wise":
        assert isinstance(objective, WISEObjective)
        labels = objective.labels(train.coefficients)
        output_bias = labels.sum(axis=0) / max(
            float(np.linalg.norm(labels, axis=1).sum()), 1e-12
        )
    elif spec.method == "direct_projection":
        assert isinstance(objective, DirectProjectionObjective)
        output_bias = objective.initial_output_bias
    elif spec.method in {
        "rayen_policy",
        "soft_radial_policy",
        "soft_radial_log_barrier",
        "log_energy_policy",
    }:
        output_bias = np.zeros(objective.output_dimension, dtype=np.float64)
    else:
        output_bias = mean_coefficient
    return StandardizedMLP(
        train.contexts.shape[1],
        objective.output_dimension,
        spec.model,
        input_mean=input_mean,
        input_scale=input_scale,
        output_bias=output_bias,
    )


def _anchored_model(
    *,
    spec: RunSpec,
    run_directory: Path,
    train: PreparedSplit,
    validation: PreparedSplit,
    interface: PartialCostInterface,
    mean_coefficient: np.ndarray,
    mean_statistic: np.ndarray,
    repo_root: Path,
) -> AnchoredModel:
    input_mean, input_scale = input_statistics(train.contexts)
    base_method = str(spec.method_parameters.get("base_method", "mse"))
    if base_method == "mse":
        base_objective: LearningObjective = CostPredictionObjective(
            interface, workers=spec.workers, random_seed=spec.seeds.structural
        )
        base_bias = mean_coefficient
    elif base_method == "spo_plus":
        base_objective = SPOPlusObjective(
            interface, workers=spec.workers, random_seed=spec.seeds.structural
        )
        base_bias = mean_coefficient
    elif base_method == "wise":
        base_objective = WISEObjective(
            interface, workers=spec.workers, random_seed=spec.seeds.structural
        )
        if base_objective.output_dimension != interface.report_dimension:
            base_objective.close()
            raise ValueError(
                "WISE-anchored proximal requires a zero fixed cost so that its "
                "output is a cost coefficient in the proximal report space"
            )
        labels = base_objective.labels(train.coefficients)
        base_bias = labels.sum(axis=0) / max(
            float(np.linalg.norm(labels, axis=1).sum()), 1e-12
        )
    else:
        raise ValueError("anchored base_method must be mse, spo_plus, or wise")
    torch.manual_seed(spec.seeds.initialization)
    base = StandardizedMLP(
        train.contexts.shape[1],
        interface.report_dimension,
        spec.model,
        input_mean=input_mean,
        input_scale=input_scale,
        output_bias=base_bias,
    )
    base_epochs = int(spec.method_parameters.get("base_epochs", 60))
    base_training = replace(
        spec.training,
        epochs=base_epochs,
        batch_size=int(
            spec.method_parameters.get("base_batch_size", spec.training.batch_size)
        ),
        learning_rate=float(
            spec.method_parameters.get(
                "base_learning_rate", spec.training.learning_rate
            )
        ),
        patience=min(spec.training.patience, max(5, base_epochs // 3)),
    )
    base_recorder = RunRecorder(
        run_directory / "base_pretrain",
        config={
            "phase": f"{base_method}_base_pretrain",
            "training": base_training,
            "parent_run": spec.to_dict(),
        },
        repo_root=repo_root,
    )
    try:
        train_model(
            model=base,
            objective=base_objective,
            train=train,
            validation=validation,
            test=None,
            spec=base_training,
            shuffle_seed=spec.seeds.shuffle,
            recorder=base_recorder,
        )
    finally:
        base_objective.close()
    base_train_outputs = predict_in_batches(
        base,
        train.contexts,
        batch_size=spec.training.evaluation_batch_size,
    )
    correction_inputs = np.concatenate([train.contexts, base_train_outputs], axis=1)
    correction_mean, correction_scale = input_statistics(correction_inputs)
    correction_spec = replace(
        spec.model,
        width=spec.model.correction_width or spec.model.width,
        depth=(
            spec.model.correction_depth
            if spec.model.correction_depth is not None
            else spec.model.depth
        ),
    )
    torch.manual_seed(spec.seeds.initialization + 1)
    correction = StandardizedMLP(
        correction_inputs.shape[1],
        interface.report_dimension,
        correction_spec,
        input_mean=correction_mean,
        input_scale=correction_scale,
        output_bias=np.zeros_like(mean_statistic),
    )
    return AnchoredModel(
        base,
        correction,
        freeze_base=bool(spec.method_parameters.get("freeze_base", True)),
    )


def _hidden_features(
    model: StandardizedMLP, contexts: np.ndarray, *, batch_size: int
) -> np.ndarray:
    pieces: list[np.ndarray] = []
    model.eval()
    with torch.no_grad():
        for start in range(0, len(contexts), batch_size):
            tensor = torch.as_tensor(
                contexts[start : start + batch_size], dtype=module_dtype(model)
            )
            pieces.append(model.features(tensor).cpu().numpy())
    features = np.concatenate(pieces, axis=0)
    return np.column_stack([features, np.ones(len(features))])


def _correction_hidden_features(
    model: AnchoredModel,
    contexts: np.ndarray,
    base_outputs: np.ndarray,
    *,
    batch_size: int,
) -> np.ndarray:
    correction_inputs = np.concatenate([contexts, base_outputs], axis=1)
    return _hidden_features(
        model.correction,
        correction_inputs,
        batch_size=batch_size,
    )


def _linear_context_features(
    train_contexts: np.ndarray, contexts: np.ndarray
) -> np.ndarray:
    mean, scale = input_statistics(train_contexts)
    standardized = (np.asarray(contexts, dtype=np.float64) - mean) / scale
    return np.column_stack([standardized, np.ones(len(standardized))])


def _record_embedded_mse_base(
    *,
    run_directory: Path,
    model: nn.Module,
    validation_outputs: np.ndarray,
    test_outputs: np.ndarray,
    validation: PreparedSplit,
    test: PreparedSplit,
    interface: PartialCostInterface,
    spec: RunSpec,
) -> None:
    """Record the decision quality and digest of an embedded MSE base.

    The receipt makes a correction comparable to the exact MSE policy from
    which it starts.  These validation/test evaluations are diagnostic only;
    they are never read by either the neural or exact-head optimizer.
    """

    objective = CostPredictionObjective(
        interface,
        workers=spec.workers,
        random_seed=spec.seeds.structural,
    )
    try:
        validation_metrics = evaluate_outputs(
            objective,
            validation_outputs,
            validation,
            batch_size=spec.training.evaluation_batch_size,
        )
        test_metrics = evaluate_outputs(
            objective,
            test_outputs,
            test,
            batch_size=spec.training.evaluation_batch_size,
        )
    finally:
        objective.close()
    write_json(
        run_directory / "embedded_mse_base.json",
        {
            "parameter_sha256": model_sha256(model),
            "validation": validation_metrics.to_dict(),
            "test": test_metrics.to_dict(),
            "used_for_correction_selection": False,
            "weights_persisted": False,
        },
    )


def _parameter_digest(*arrays: np.ndarray, model: nn.Module | None = None) -> str:
    digest = hashlib.sha256()
    if model is not None:
        digest.update(model_sha256(model).encode("ascii"))
    for array in arrays:
        contiguous = np.ascontiguousarray(array, dtype=np.float64)
        digest.update(str(contiguous.shape).encode("ascii"))
        digest.update(contiguous.tobytes())
    return digest.hexdigest()


def _compress_exact_features(
    features: tuple[np.ndarray, np.ndarray, np.ndarray],
    *,
    maximum_nonconstant_dimension: int | None,
) -> tuple[tuple[np.ndarray, np.ndarray, np.ndarray], dict[str, Any]]:
    """Fit one deterministic train-only PCA map while retaining an intercept."""

    train, validation, test = features
    compatible = all(
        matrix.ndim == 2 and matrix.shape[1] == train.shape[1] for matrix in features
    )
    if not compatible:
        raise ValueError("exact-head feature matrices are incompatible")
    if not np.allclose(train[:, -1], 1.0):
        raise ValueError("exact-head feature matrices must end in an intercept")
    original_dimension = train.shape[1]
    nonconstant_dimension = original_dimension - 1
    if (
        maximum_nonconstant_dimension is None
        or nonconstant_dimension <= maximum_nonconstant_dimension
    ):
        return features, {
            "original_feature_dimension_with_intercept": original_dimension,
            "feature_dimension_with_intercept": original_dimension,
            "pca_applied": False,
            "retained_training_variance_ratio": 1.0,
        }
    mean = train[:, :-1].mean(axis=0)
    centered = train[:, :-1] - mean
    _, singular_values, right = np.linalg.svd(centered, full_matrices=False)
    rank = min(maximum_nonconstant_dimension, len(singular_values))
    components = right[:rank].T

    def transform(matrix: np.ndarray) -> np.ndarray:
        projected = (matrix[:, :-1] - mean) @ components
        return np.column_stack([projected, np.ones(len(projected))])

    total_variance = float(np.sum(singular_values**2))
    retained = float(np.sum(singular_values[:rank] ** 2))
    ratio = 1.0 if total_variance == 0.0 else retained / total_variance
    compressed = (transform(train), transform(validation), transform(test))
    return compressed, {
        "original_feature_dimension_with_intercept": original_dimension,
        "feature_dimension_with_intercept": compressed[0].shape[1],
        "pca_applied": True,
        "retained_training_variance_ratio": ratio,
    }


def _augment_run_accounting(
    *,
    run_directory: Path,
    preparation_stats: OracleStats,
    additional_training_phases: list[tuple[str, dict[str, Any]]] | None = None,
) -> None:
    summary_path = run_directory / "summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    summary["data_preparation_oracle_stats"] = {
        "calls": preparation_stats.calls,
        "iterations": preparation_stats.iterations,
        "failures": preparation_stats.failures,
        "solver_seconds": preparation_stats.solver_seconds,
        "wall_seconds": preparation_stats.wall_seconds,
    }
    nested: list[tuple[str, dict[str, Any]]] = []
    base_summary_path = run_directory / "base_pretrain" / "summary.json"
    if base_summary_path.is_file():
        base_summary = json.loads(base_summary_path.read_text(encoding="utf-8"))
        if not isinstance(base_summary, dict):
            raise ValueError("nested base-pretraining summary is malformed")
        nested.append(("base_pretrain", base_summary))
    nested.extend(additional_training_phases or [])
    summary = with_pipeline_accounting(
        summary,
        nested_training_phases=nested,
    )
    write_json(summary_path, summary)


def _coordinate_summary(values: np.ndarray) -> dict[str, Any]:
    values = np.asarray(values, dtype=np.float64)
    return {
        "dimension": values.shape[1],
        "mean": values.mean(axis=0).tolist(),
        "standard_deviation": values.std(axis=0).tolist(),
        "minimum": values.min(axis=0).tolist(),
        "maximum": values.max(axis=0).tolist(),
    }


def _prediction_diagnostics(
    model: torch.nn.Module,
    objective: LearningObjective,
    test: PreparedSplit,
    *,
    batch_size: int,
) -> dict[str, Any]:
    outputs = predict_in_batches(model, test.contexts, batch_size=batch_size)
    decisions: list[np.ndarray] = []
    recovered: list[np.ndarray] = []
    stats = OracleStats()
    for start in range(0, len(outputs), batch_size):
        deployed = objective.deploy(outputs[start : start + batch_size])
        decisions.append(deployed.decisions)
        if deployed.recovered_coefficients is not None:
            recovered.append(deployed.recovered_coefficients)
        stats += deployed.stats
    result: dict[str, Any] = {
        "network_outputs": _coordinate_summary(outputs),
        "deployed_decisions": _coordinate_summary(np.concatenate(decisions)),
        "diagnostic_oracle_stats": {
            "calls": stats.calls,
            "iterations": stats.iterations,
            "failures": stats.failures,
            "solver_seconds": stats.solver_seconds,
            "wall_seconds": stats.wall_seconds,
        },
        "raw_outputs_persisted": False,
    }
    if recovered:
        result["recovered_coefficients"] = _coordinate_summary(
            np.concatenate(recovered)
        )
    physical_predictor = getattr(objective, "predicted_physical_costs", None)
    if physical_predictor is not None:
        physical_prediction = np.asarray(physical_predictor(outputs), dtype=np.float64)
        conditional_error = physical_prediction - test.conditional_mean_costs
        scenario_error = physical_prediction - test.physical_costs
        result["physical_cost_prediction"] = {
            "conditional_mse_per_coordinate": float(np.mean(conditional_error**2)),
            "conditional_mse_per_vector": float(
                np.mean(np.sum(conditional_error**2, axis=1))
            ),
            "scenario_mse_per_coordinate": float(np.mean(scenario_error**2)),
            "scenario_mse_per_vector": float(
                np.mean(np.sum(scenario_error**2, axis=1))
            ),
            "conditional_mae_per_coordinate": float(np.mean(np.abs(conditional_error))),
            "prediction_norm_mean": float(
                np.mean(np.linalg.norm(physical_prediction, axis=1))
            ),
            "raw_predictions_persisted": False,
        }
    policy_diagnostics = getattr(objective, "diagnostics", None)
    if policy_diagnostics is not None:
        result["policy_diagnostics"] = policy_diagnostics(outputs)
    return result


def _model_hidden_features(
    model: StandardizedMLP, contexts: np.ndarray, *, batch_size: int
) -> np.ndarray:
    """Evaluate the frozen nonlinear backbone without its affine head."""

    pieces: list[np.ndarray] = []
    dtype = module_dtype(model)
    model.eval()
    with torch.no_grad():
        for start in range(0, len(contexts), batch_size):
            tensor = torch.as_tensor(contexts[start : start + batch_size], dtype=dtype)
            pieces.append(model.features(tensor).cpu().numpy())
    return np.ascontiguousarray(np.concatenate(pieces, axis=0))


def _normalized_complete_costs(costs: np.ndarray) -> np.ndarray:
    values = np.asarray(costs, dtype=np.float64)
    maximum = np.max(np.abs(values), axis=1, keepdims=True)
    return np.ascontiguousarray(values / np.maximum(maximum, 1.0))


def _run_prediction_correction_suite(
    *,
    model: StandardizedMLP,
    objective: SoftRadialLogBarrierObjective,
    train: PreparedSplit,
    validation: PreparedSplit,
    test: PreparedSplit,
    interface: PartialCostInterface,
    spec: RunSpec,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Fit every cheap decision-preserving prediction sidecar.

    The corrected cost is explanatory: deployment continues to use the base
    policy's uncorrected direction.  Re-solving with corrected costs is only a
    bounded audit of the geometric decision-invariance certificate and is not
    counted as training or deployment work.
    """

    started = time.perf_counter()
    cpu_started = time.process_time()
    batch_size = spec.training.evaluation_batch_size
    geometry = DecisionInvariantGeometry.compile(
        interface.problem,
        tangent_map=objective.geometry.physical_map,
    )

    include_cone = bool(spec.method_parameters.get("prediction_correction_cone", True))
    named_splits = (("train", train), ("validation", validation), ("test", test))
    correction_splits: list[CorrectionSplit] = []
    base_stats: dict[str, OracleStats] = {}
    feature_wall: dict[str, float] = {}
    feature_cpu: dict[str, float] = {}
    decision_wall: dict[str, float] = {}
    decision_cpu: dict[str, float] = {}
    for split_name, split in named_splits:
        feature_started = time.perf_counter()
        feature_cpu_started = time.process_time()
        outputs = predict_in_batches(model, split.contexts, batch_size=batch_size)
        hidden = _model_hidden_features(model, split.contexts, batch_size=batch_size)
        directions = objective.recovered_cost_direction(outputs)
        if bool(
            spec.method_parameters.get(
                "prediction_correction_mu_normalize_directions", False
            )
        ):
            directions = objective.mu * directions
        feature_wall[split_name] = time.perf_counter() - feature_started
        feature_cpu[split_name] = time.process_time() - feature_cpu_started

        decision_started = time.perf_counter()
        decision_cpu_started = time.process_time()
        if include_cone or split_name == "test":
            deployed = objective.deploy_with_mode(outputs, "hard_recovered")
            decisions = deployed.decisions
            base_stats[split_name] = deployed.stats
        else:
            decisions = np.zeros(
                (len(split.contexts), interface.problem.variable_count),
                dtype=np.float64,
            )
            base_stats[split_name] = OracleStats()
        decision_wall[split_name] = time.perf_counter() - decision_started
        decision_cpu[split_name] = time.process_time() - decision_cpu_started
        correction_splits.append(
            CorrectionSplit(
                contexts=split.contexts,
                hidden_features=hidden,
                base_directions=directions,
                base_decisions=decisions,
                observed_costs=split.physical_costs,
                conditional_mean_costs=split.conditional_mean_costs,
                conditional_target_values=split.conditional_target_values,
            )
        )
    correction_train, correction_validation, correction_test = correction_splits
    ridge_grid = tuple(
        float(value)
        for value in spec.method_parameters.get(
            "prediction_correction_ridges", [1e-8, 1e-5, 1e-3, 1e-1]
        )
    )
    fit_started = time.perf_counter()
    fit_cpu_started = time.process_time()
    minimum_scale = float(
        spec.method_parameters.get("prediction_correction_minimum_scale", 1e-6)
    )
    predictions: dict[str, Any] = {}
    fit_receipt: dict[str, Any] = {
        "legacy_pair_only_suite_included": False,
        "conditional_means_used_for_fitting_or_selection": False,
        "timing": {"pair_only_suite_wall_seconds": 0.0},
    }
    if bool(spec.method_parameters.get("prediction_correction_legacy", True)):
        legacy_predictions, legacy_receipt = fit_prediction_corrections(
            train=correction_train,
            validation=correction_validation,
            test=correction_test,
            geometry=geometry,
            mu=objective.mu,
            ridge_grid=ridge_grid,
            minimum_scale=minimum_scale,
            include_cone=include_cone,
        )
        predictions.update(legacy_predictions)
        fit_receipt = legacy_receipt
        fit_receipt["legacy_pair_only_suite_included"] = True

    mse_receipt: dict[str, Any] | None = None
    neural_receipt: dict[str, Any] | None = None
    if bool(spec.method_parameters.get("prediction_correction_neural", False)):
        mse_model, mse_receipt = fit_pair_mse_network(
            train_contexts=train.contexts,
            train_coefficients=train.coefficients,
            validation_contexts=validation.contexts,
            validation_coefficients=validation.coefficients,
            model_spec=spec.model,
            learning_rate=float(
                spec.method_parameters.get(
                    "prediction_correction_mse_learning_rate", 1e-3
                )
            ),
            epochs=int(
                spec.method_parameters.get("prediction_correction_mse_epochs", 120)
            ),
            batch_size=spec.training.batch_size,
            patience=spec.training.patience,
            weight_decay=spec.training.weight_decay,
            initialization_seed=spec.seeds.initialization + 70_001,
            shuffle_seed=spec.seeds.shuffle + 70_001,
        )
        neural_splits: list[NeuralCorrectionSplit] = []
        for split, correction in zip(
            (train, validation, test), correction_splits, strict=True
        ):
            _, mse_hidden, mse_physical = mse_network_arrays(
                mse_model,
                split.contexts,
                interface,
                batch_size=batch_size,
            )
            neural_splits.append(
                NeuralCorrectionSplit(
                    correction=correction,
                    mse_hidden_features=mse_hidden,
                    mse_physical_costs=mse_physical,
                )
            )
        neural_model_spec = ModelSpec(
            width=int(
                spec.method_parameters.get(
                    "prediction_correction_neural_width", spec.model.width
                )
            ),
            depth=int(
                spec.method_parameters.get(
                    "prediction_correction_neural_depth", spec.model.depth
                )
            ),
            activation=spec.model.activation,
            layer_norm=spec.model.layer_norm,
        )
        neural_predictions, neural_receipt = fit_neural_prediction_corrections(
            train=neural_splits[0],
            validation=neural_splits[1],
            test=neural_splits[2],
            geometry=geometry,
            model_spec=neural_model_spec,
            learning_rates=tuple(
                float(value)
                for value in spec.method_parameters.get(
                    "prediction_correction_neural_learning_rates",
                    [3e-4, 1e-3],
                )
            ),
            epochs=int(
                spec.method_parameters.get("prediction_correction_neural_epochs", 80)
            ),
            patience=int(
                spec.method_parameters.get("prediction_correction_neural_patience", 4)
            ),
            batch_size=spec.training.batch_size,
            weight_decay=spec.training.weight_decay,
            minimum_scale=minimum_scale,
            initialization_seed=spec.seeds.initialization + 80_001,
            shuffle_seed=spec.seeds.shuffle + 80_001,
            include_full_cone=include_cone,
            include_projected_head=bool(
                spec.method_parameters.get(
                    "prediction_correction_include_projected_head", True
                )
            ),
            include_neural_heads=not bool(
                spec.method_parameters.get("prediction_correction_exact_only", False)
            ),
        )
        predictions.update(neural_predictions)
        fit_receipt["paired_mse_network"] = mse_receipt
        fit_receipt["neural_pair_only_suite"] = neural_receipt
    fit_call_wall = time.perf_counter() - fit_started
    fit_call_cpu = time.process_time() - fit_cpu_started

    base_decisions = correction_test.base_decisions
    base_regret = _regret_vector(base_decisions, test)
    method_rows: dict[str, Any] = {}
    for name, prediction in predictions.items():
        method_rows[name] = {
            "prediction": prediction_metrics(
                prediction.physical_costs, correction_test, geometry
            ),
            "deployed_base_decision_mean_regret": float(np.mean(base_regret)),
            "corrected_cost_used_for_deployment": False,
            "decision_regret_change_by_design": 0.0,
            "selected_candidate_fit_and_prediction_wall_seconds": (
                prediction.fitting_wall_seconds
            ),
            "selected_ridge": prediction.selected_ridge,
            "validation_scenario_mse_per_coordinate": (
                prediction.validation_scenario_mse_per_coordinate
            ),
            "metadata": prediction.metadata,
            "raw_costs_persisted": False,
        }

    audit_size = min(
        len(test.contexts),
        int(spec.method_parameters.get("prediction_correction_replay_audit_size", 8)),
    )
    audit_stats = OracleStats()
    audit_started = time.perf_counter()
    if audit_size > 0:
        audit_indices = np.unique(
            np.linspace(0, len(test.contexts) - 1, audit_size, dtype=np.int64)
        )
        with make_lp_oracle(
            interface.problem,
            workers=spec.workers,
            random_seed=spec.seeds.structural,
        ) as oracle:
            for name, prediction in predictions.items():
                replay = oracle.solve_many(
                    _normalized_complete_costs(prediction.physical_costs[audit_indices])
                )
                audit_stats += replay.stats
                decision_distance = np.linalg.norm(
                    replay.decisions - base_decisions[audit_indices], axis=1
                )
                method_rows[name]["decision_invariance_audit"] = {
                    "sample_size": int(len(audit_indices)),
                    "base_decision_match_rate": float(
                        np.mean(decision_distance <= 1e-7)
                    ),
                    "maximum_decision_distance": float(
                        np.max(decision_distance, initial=0.0)
                    ),
                    "solver_replay_is_validation_only": True,
                }
    audit_wall = time.perf_counter() - audit_started

    wall = time.perf_counter() - started
    cpu = time.process_time() - cpu_started
    training_base_stats = OracleStats()
    training_base_stats += base_stats["train"]
    training_base_stats += base_stats["validation"]
    incremental_training_wall = (
        feature_wall["train"]
        + feature_wall["validation"]
        + decision_wall["train"]
        + decision_wall["validation"]
        + fit_call_wall
    )
    incremental_training_cpu = (
        feature_cpu["train"]
        + feature_cpu["validation"]
        + decision_cpu["train"]
        + decision_cpu["validation"]
        + fit_call_cpu
    )
    phase = {
        "training_wall_seconds": incremental_training_wall,
        "training_cpu_seconds": incremental_training_cpu,
        "total_training_oracle_stats": asdict(training_base_stats),
    }
    payload = {
        "status": "development",
        "base_method": "soft_radial_log_barrier_hard_recovered",
        "base_direction_scale": (
            "mu_times_recovered_direction"
            if bool(
                spec.method_parameters.get(
                    "prediction_correction_mu_normalize_directions", False
                )
            )
            else "unscaled_recovered_direction"
        ),
        "operational_role": (
            "post-decision prediction and interpretability sidecar; the corrected "
            "cost is not used to choose the deployed decision"
        ),
        "base_decision_test_mean_regret": float(np.mean(base_regret)),
        "fit_receipt": fit_receipt,
        "methods": method_rows,
        "timing": {
            "incremental_pair_only_training_wall_seconds": (incremental_training_wall),
            "incremental_pair_only_training_cpu_seconds": (incremental_training_cpu),
            "frozen_base_feature_evaluation_wall_seconds": feature_wall,
            "base_decision_solve_wall_seconds": decision_wall,
            "correction_fit_call_wall_seconds": fit_call_wall,
            "correction_fit_call_cpu_seconds": fit_call_cpu,
            "paired_mse_network_training": mse_receipt,
            "neural_correction_training": neural_receipt,
            "decision_invariance_audit_wall_seconds": audit_wall,
            "whole_exploratory_suite_wall_seconds": wall,
            "whole_exploratory_suite_cpu_seconds": cpu,
            "deployment_correction_solver_calls": 0,
            "note": (
                "Test base-decision solves are part of base-policy deployment; "
                "corrected-cost solver replays are audit-only and excluded from "
                "training and deployment cost."
            ),
        },
        "base_decision_oracle_stats_by_split": {
            name: asdict(stats) for name, stats in base_stats.items()
        },
        "decision_invariance_audit": {
            "requested_sample_size_per_method": audit_size,
            "wall_seconds": audit_wall,
            "oracle_stats": asdict(audit_stats),
            "counted_as_training_or_deployment_cost": False,
        },
        "test_conditional_means_used_for_fitting_or_selection": False,
        "raw_training_or_test_data_persisted": False,
    }
    return payload, phase


def _maximum_primal_violation(
    decisions: np.ndarray, interface: PartialCostInterface
) -> float:
    decisions = np.asarray(decisions, dtype=np.float64)
    activity = decisions @ interface.problem.matrix.T
    return float(
        max(
            np.max(interface.problem.variable_lower - decisions, initial=0.0),
            np.max(decisions - interface.problem.variable_upper, initial=0.0),
            np.max(interface.problem.row_lower - activity, initial=0.0),
            np.max(activity - interface.problem.row_upper, initial=0.0),
        )
    )


def _regret_vector(decisions: np.ndarray, split: PreparedSplit) -> np.ndarray:
    regret = (
        np.sum(split.conditional_mean_costs * decisions, axis=1)
        - split.conditional_target_values
    )
    tolerance = 5e-7 * (
        1.0
        + np.abs(split.conditional_target_values)
        + np.sum(np.abs(split.conditional_mean_costs), axis=1)
    )
    if np.any(regret < -tolerance):
        raise RuntimeError(
            f"mollification diagnostic has negative regret {regret.min():.3e}"
        )
    return np.maximum(regret, 0.0)


def _decision_diversity(cell_decisions: np.ndarray) -> dict[str, float]:
    cells = np.asarray(cell_decisions, dtype=np.float64)
    averages = cells.mean(axis=1, keepdims=True)
    dispersion = np.mean(np.sum((cells - averages) ** 2, axis=2), axis=1)
    entropies: list[float] = []
    unique_counts: list[int] = []
    dominant_rates: list[float] = []
    for sample in cells:
        _, counts = np.unique(np.round(sample, decimals=7), axis=0, return_counts=True)
        probabilities = counts / counts.sum()
        entropy = -float(np.sum(probabilities * np.log(probabilities)))
        denominator = np.log(len(sample)) if len(sample) > 1 else 1.0
        entropies.append(entropy / denominator)
        unique_counts.append(len(counts))
        dominant_rates.append(float(np.max(probabilities)))
    return {
        "mean_cell_squared_dispersion": float(np.mean(dispersion)),
        "mean_normalized_cell_entropy": float(np.mean(entropies)),
        "mean_unique_cell_decisions": float(np.mean(unique_counts)),
        "mean_dominant_cell_rate": float(np.mean(dominant_rates)),
    }


def _mollification_diagnostics(
    *,
    model: nn.Module,
    objective: MollifiedAnchoredProximalObjective,
    split: PreparedSplit,
    batch_size: int,
) -> dict[str, Any]:
    outputs = predict_in_batches(model, split.contexts, batch_size=batch_size)
    dimension = objective.interface.report_dimension
    residual = outputs[:, dimension:]
    mollified = objective.decode_details(outputs, role="evaluation")
    hard = objective.deploy(outputs)
    deterministic = objective.deterministic_details(outputs)
    baseline = objective.baseline_deployment(outputs)
    hard_regret = _regret_vector(hard.decisions, split)
    averaged_regret = _regret_vector(mollified.deployment.decisions, split)
    deterministic_regret = _regret_vector(deterministic.deployment.decisions, split)
    baseline_regret = _regret_vector(baseline.decisions, split)
    changed = np.linalg.norm(hard.decisions - baseline.decisions, axis=1) > 1e-8
    baseline_wrong = baseline_regret > 1e-8
    mollified_wrong = hard_regret > 1e-8
    recovered = hard.recovered_coefficients
    if recovered is None:
        raise RuntimeError("mollified deployment did not recover coefficients")

    def conditional_rate(mask: np.ndarray, event: np.ndarray) -> float | None:
        return None if not np.any(mask) else float(np.mean(event[mask]))

    return {
        "split": split.split,
        "sample_count": len(outputs),
        "network_outputs": _coordinate_summary(outputs),
        "mollified_deployed_decisions": _coordinate_summary(hard.decisions),
        "averaged_cell_decisions": _coordinate_summary(mollified.deployment.decisions),
        "recovered_coefficients": _coordinate_summary(recovered),
        "mollified_mean_regret": float(np.mean(hard_regret)),
        "hard_deployment_mean_regret": float(np.mean(hard_regret)),
        "averaged_cell_mean_regret": float(np.mean(averaged_regret)),
        "deterministic_mean_regret": float(np.mean(deterministic_regret)),
        "mse_base_mean_regret": float(np.mean(baseline_regret)),
        "recovered_cost_mse_to_conditional_mean": float(
            np.mean(
                np.sum(
                    (recovered - split.conditional_mean_coefficients) ** 2,
                    axis=1,
                )
            )
        ),
        "recovered_cost_mse_to_realized_scenario": float(
            np.mean(np.sum((recovered - split.coefficients) ** 2, axis=1))
        ),
        "mean_residual_norm": float(np.mean(np.linalg.norm(residual, axis=1))),
        "mean_mollified_decision_residual_norm": float(
            np.mean(np.linalg.norm(mollified.decision_residuals, axis=1))
        ),
        "changed_mse_decision_rate": float(np.mean(changed)),
        "mse_wrong_to_corrected_rate": conditional_rate(
            baseline_wrong, ~mollified_wrong
        ),
        "mse_correct_to_damaged_rate": conditional_rate(
            ~baseline_wrong, mollified_wrong
        ),
        "mse_wrong_count": int(np.sum(baseline_wrong)),
        "mse_correct_count": int(np.sum(~baseline_wrong)),
        "mollified_maximum_primal_violation": _maximum_primal_violation(
            hard.decisions, objective.interface
        ),
        "cell_maximum_primal_violation": _maximum_primal_violation(
            mollified.cell_decisions.reshape(-1, mollified.cell_decisions.shape[-1]),
            objective.interface,
        ),
        "cell_diversity": _decision_diversity(mollified.cell_decisions),
        "diagnostic_oracle_stats": asdict(
            mollified.deployment.stats
            + hard.stats
            + deterministic.deployment.stats
            + baseline.stats
        ),
        "raw_outputs_persisted": False,
        "raw_cell_decisions_persisted": False,
    }


def _exact_output_diagnostics(
    *,
    physical_reports: np.ndarray,
    objective: ProximalObjective,
    split: PreparedSplit,
    batch_size: int,
) -> dict[str, Any]:
    decisions: list[np.ndarray] = []
    recovered: list[np.ndarray] = []
    stats = OracleStats()
    for start in range(0, len(physical_reports), batch_size):
        deployed = objective.deploy(physical_reports[start : start + batch_size])
        decisions.append(deployed.decisions)
        if deployed.recovered_coefficients is not None:
            recovered.append(deployed.recovered_coefficients)
        stats += deployed.stats
    result: dict[str, Any] = {
        "network_outputs": _coordinate_summary(physical_reports),
        "deployed_decisions": _coordinate_summary(np.concatenate(decisions)),
        "diagnostic_oracle_stats": {
            "calls": stats.calls,
            "iterations": stats.iterations,
            "failures": stats.failures,
            "solver_seconds": stats.solver_seconds,
            "wall_seconds": stats.wall_seconds,
        },
        "raw_outputs_persisted": False,
    }
    if recovered:
        result["recovered_coefficients"] = _coordinate_summary(
            np.concatenate(recovered)
        )
    return result


def _canonical_adam_offsets(
    *,
    model: nn.Module,
    objective: ProximalObjective,
    split: PreparedSplit,
    head_tau: float,
    batch_size: int,
) -> tuple[np.ndarray, OracleStats]:
    """Re-express the Adam decisions as canonical reports at ``head_tau``."""

    outputs = predict_in_batches(model, split.contexts, batch_size=batch_size)
    offsets: list[np.ndarray] = []
    stats = OracleStats()
    for start in range(0, len(outputs), batch_size):
        deployed = objective.deploy(outputs[start : start + batch_size])
        if deployed.recovered_coefficients is None:
            raise RuntimeError("proximal deployment did not recover coefficients")
        statistics = deployed.decisions @ objective.interface.statistic.T
        offsets.append(head_tau * deployed.recovered_coefficients - statistics)
        stats += deployed.stats
    return np.concatenate(offsets), stats


def _solve_and_record_exact_only(
    *,
    spec: RunSpec,
    recorder: RunRecorder,
    run_directory: Path,
    train: PreparedSplit,
    validation: PreparedSplit,
    test: PreparedSplit,
    interface: PartialCostInterface,
    features: tuple[np.ndarray, np.ndarray, np.ndarray],
    offsets: tuple[np.ndarray, np.ndarray, np.ndarray],
    model_for_digest: nn.Module | None,
    training_stats: OracleStats,
    evaluation_stats: OracleStats,
    training_started: float,
    training_cpu_started: float,
) -> TrainingResult:
    tau = float(spec.method_parameters["tau"])
    ridge = float(spec.method_parameters.get("exact_head_ridge", 1e-8))
    features, feature_receipt = _compress_exact_features(
        features,
        maximum_nonconstant_dimension=(
            int(spec.method_parameters["exact_head_feature_dimension"])
            if "exact_head_feature_dimension" in spec.method_parameters
            else None
        ),
    )
    train_features, validation_features, test_features = features
    train_offset, validation_offset, test_offset = offsets
    exact_solver = (
        solve_exact_proximal_head_decomposed
        if train_features.shape[1] > 16
        else solve_exact_proximal_head
    )
    exact = exact_solver(
        features=train_features,
        coefficients=train.coefficients,
        interface=interface,
        tau=tau,
        report_offset=train_offset,
        ridge=ridge,
        **(
            {"workers": spec.workers}
            if exact_solver is solve_exact_proximal_head_decomposed
            else {}
        ),
    )
    objective = ProximalObjective(
        interface,
        tau=tau,
        workers=spec.workers,
        report_scale=1.0,
    )
    try:
        validation_reports = validation_offset + validation_features @ exact.weights
        test_reports = test_offset + test_features @ exact.weights
        validation_metrics = evaluate_outputs(
            objective,
            validation_reports,
            validation,
            batch_size=spec.training.evaluation_batch_size,
        )
        test_metrics = evaluate_outputs(
            objective,
            test_reports,
            test,
            batch_size=spec.training.evaluation_batch_size,
        )
        recorder.append_curve(
            {
                "epoch": 0,
                "exact_head_tau": tau,
                "validation": validation_metrics.to_dict(),
                "selected_so_far": True,
            }
        )
        result = TrainingResult(
            best_epoch=0,
            epochs_completed=0,
            best_validation=validation_metrics,
            test=test_metrics,
            training_wall_seconds=time.perf_counter() - training_started,
            training_cpu_seconds=time.process_time() - training_cpu_started,
            total_training_oracle_stats=training_stats + exact.stats,
            parameter_sha256=_parameter_digest(
                exact.weights,
                model=model_for_digest,
            ),
            trainable_parameters=exact.weights.size,
        )
        recorder.finish(result.to_dict())
        write_json(
            run_directory / "exact_head.json",
            {
                **exact.receipt(),
                "mode": spec.method,
                "head_tau": tau,
                "ridge": ridge,
                "validation": validation_metrics.to_dict(),
                "test": test_metrics.to_dict(),
                **feature_receipt,
                "report_offset_used": bool(np.any(train_offset != 0.0)),
                "offset_training_oracle_stats": asdict(training_stats),
                "offset_evaluation_oracle_stats": asdict(evaluation_stats),
                "weights_persisted": False,
            },
        )
        write_json(
            run_directory / "prediction_diagnostics.json",
            _exact_output_diagnostics(
                physical_reports=test_reports,
                objective=objective,
                split=test,
                batch_size=spec.training.evaluation_batch_size,
            ),
        )
        return result
    finally:
        objective.close()


def _run_exact_only(
    *,
    spec: RunSpec,
    recorder: RunRecorder,
    run_directory: Path,
    repo_root: Path,
    train: PreparedSplit,
    validation: PreparedSplit,
    test: PreparedSplit,
    interface: PartialCostInterface,
    mean_coefficient: np.ndarray,
    mean_statistic: np.ndarray,
) -> TrainingResult:
    started = time.perf_counter()
    cpu_started = time.process_time()
    zeros = (
        np.zeros((len(train.contexts), interface.report_dimension), dtype=np.float64),
        np.zeros(
            (len(validation.contexts), interface.report_dimension), dtype=np.float64
        ),
        np.zeros((len(test.contexts), interface.report_dimension), dtype=np.float64),
    )
    if spec.method == "exact_proximal_linear":
        features = (
            _linear_context_features(train.contexts, train.contexts),
            _linear_context_features(train.contexts, validation.contexts),
            _linear_context_features(train.contexts, test.contexts),
        )
        return _solve_and_record_exact_only(
            spec=spec,
            recorder=recorder,
            run_directory=run_directory,
            train=train,
            validation=validation,
            test=test,
            interface=interface,
            features=features,
            offsets=zeros,
            model_for_digest=None,
            training_stats=OracleStats(),
            evaluation_stats=OracleStats(),
            training_started=started,
            training_cpu_started=cpu_started,
        )
    if spec.method != "exact_proximal_mse_base":
        raise AssertionError(spec.method)
    model = _anchored_model(
        spec=spec,
        run_directory=run_directory,
        train=train,
        validation=validation,
        interface=interface,
        mean_coefficient=mean_coefficient,
        mean_statistic=mean_statistic,
        repo_root=repo_root,
    )
    batch_size = spec.training.evaluation_batch_size
    base_outputs = tuple(
        predict_in_batches(model.base, split.contexts, batch_size=batch_size)
        for split in (train, validation, test)
    )
    _record_embedded_mse_base(
        run_directory=run_directory,
        model=model.base,
        validation_outputs=base_outputs[1],
        test_outputs=base_outputs[2],
        validation=validation,
        test=test,
        interface=interface,
        spec=spec,
    )
    exact_started = time.perf_counter()
    exact_cpu_started = time.process_time()
    feature_list = tuple(
        _correction_hidden_features(
            model,
            split.contexts,
            outputs,
            batch_size=batch_size,
        )
        for split, outputs in zip(
            (train, validation, test),
            base_outputs,
            strict=True,
        )
    )
    features = (feature_list[0], feature_list[1], feature_list[2])
    tau = float(spec.method_parameters["tau"])
    center_on_base = bool(spec.method_parameters.get("center_on_base_decision", True))
    baseline_training_stats = OracleStats()
    baseline_evaluation_stats = OracleStats()
    offsets_list: list[np.ndarray] = []
    with make_lp_oracle(
        interface.problem,
        workers=spec.workers,
        random_seed=spec.seeds.structural,
    ) as oracle:
        for split_index, outputs in enumerate(base_outputs):
            offset = tau * outputs
            if center_on_base:
                solutions = oracle.solve_many(interface.physical_cost(outputs))
                statistic = solutions.decisions @ interface.statistic.T
                offset = offset - statistic
                if split_index == 0:
                    baseline_training_stats += solutions.stats
                else:
                    baseline_evaluation_stats += solutions.stats
            offsets_list.append(offset)
    return _solve_and_record_exact_only(
        spec=spec,
        recorder=recorder,
        run_directory=run_directory,
        train=train,
        validation=validation,
        test=test,
        interface=interface,
        features=features,
        offsets=(offsets_list[0], offsets_list[1], offsets_list[2]),
        model_for_digest=model.base,
        training_stats=baseline_training_stats,
        evaluation_stats=baseline_evaluation_stats,
        training_started=exact_started,
        training_cpu_started=exact_cpu_started,
    )


def run_experiment(
    spec: RunSpec,
    *,
    run_directory: Path,
    repo_root: Path,
    progress: bool = True,
) -> TrainingResult:
    torch.manual_seed(spec.seeds.initialization)
    np.random.seed(spec.seeds.initialization)
    problem, dataset, benchmark_provenance = _problem_and_dataset(spec)
    base_interface = dataset.interface(spec.interface, problem)
    interface, transform = _coefficient_transform(spec, dataset, base_interface)
    train, validation, test, preparation_stats, preparation_cache = _prepare(
        spec, dataset, interface, transform
    )
    evaluation_test = test if spec.evaluate_test else None
    mean_coefficient, mean_statistic, static_decision = _global_reference(
        spec, train, interface
    )
    objective_interface = interface
    deployment_problem: LinearProblem | None = None
    relaxation_receipt: dict[str, Any] = {
        "active": False,
        "reason": "method does not use relaxation-trained hard deployment",
    }
    if (
        spec.method
        in {
            "soft_radial_log_barrier",
            "spo_plus_relaxation",
            "pyepo_spo_plus_relaxation",
            "sfge_relaxation",
        }
        and not interface.problem.is_continuous
    ):
        (
            objective_interface,
            train,
            relaxation_stats,
            relaxation_receipt,
        ) = _relaxation_policy_training_data(
            spec,
            dataset,
            interface,
            train,
            validation,
            test,
        )
        preparation_stats += relaxation_stats
        deployment_problem = interface.problem
    recorder = RunRecorder(run_directory, config=spec.to_dict(), repo_root=repo_root)
    write_json(
        run_directory / "data_diagnostics.json",
        {
            "train": _split_diagnostics(train, static_decision),
            "validation": _split_diagnostics(validation, static_decision),
            "test": _split_diagnostics(test, static_decision),
            "prepared_reference_cache": preparation_cache,
            "benchmark_provenance": benchmark_provenance,
            "cost_coordinate_transform": transform.receipt(),
            "relaxation_trained_hard_deployment": relaxation_receipt,
            "raw_data_persisted": False,
        },
    )
    if spec.method in {"exact_proximal_linear", "exact_proximal_mse_base"}:
        try:
            result = _run_exact_only(
                spec=spec,
                recorder=recorder,
                run_directory=run_directory,
                repo_root=repo_root,
                train=train,
                validation=validation,
                test=test,
                interface=interface,
                mean_coefficient=mean_coefficient,
                mean_statistic=mean_statistic,
            )
            _augment_run_accounting(
                run_directory=run_directory,
                preparation_stats=preparation_stats,
            )
            return result
        except BaseException as error:
            recorder.fail(error)
            raise
    objective: LearningObjective | None = None
    additional_training_phases: list[tuple[str, dict[str, Any]]] = []
    prediction_diagnostics_written = False
    try:
        model: nn.Module
        if spec.method == "mollified_anchored_proximal":
            anchored_model = _anchored_model(
                spec=spec,
                run_directory=run_directory,
                train=train,
                validation=validation,
                interface=interface,
                mean_coefficient=mean_coefficient,
                mean_statistic=mean_statistic,
                repo_root=repo_root,
            )
            model = anchored_model
            base_outputs = tuple(
                predict_in_batches(
                    anchored_model.base,
                    split.contexts,
                    batch_size=spec.training.evaluation_batch_size,
                )
                for split in (train, validation, test)
            )
            _record_embedded_mse_base(
                run_directory=run_directory,
                model=anchored_model.base,
                validation_outputs=base_outputs[1],
                test_outputs=base_outputs[2],
                validation=validation,
                test=test,
                interface=interface,
                spec=spec,
            )
            residual_scale = np.sqrt(
                np.mean((base_outputs[0] - train.coefficients) ** 2, axis=0)
            )
            parameters = spec.method_parameters
            objective = MollifiedAnchoredProximalObjective(
                interface,
                tau=float(parameters.get("tau", 300.0)),
                sigma=float(parameters.get("sigma", 0.0)),
                residual_scale=residual_scale,
                training_samples=int(parameters.get("training_samples", 8)),
                evaluation_samples=int(parameters.get("evaluation_samples", 64)),
                workers=spec.workers,
                random_seed=spec.seeds.perturbation,
            )
            training_cache_started = time.perf_counter()
            training_cache_cpu_started = time.process_time()
            training_cache_stats = OracleStats()
            if objective.sigma > 0.0:
                training_cache_stats += objective.prime_base_cache(
                    base_outputs[0], role="training"
                )
                training_cache_stats += objective.prime_training_targets(
                    train.coefficients
                )
            training_cache_phase = {
                "training_wall_seconds": (time.perf_counter() - training_cache_started),
                "training_cpu_seconds": (
                    time.process_time() - training_cache_cpu_started
                ),
                "total_training_oracle_stats": asdict(training_cache_stats),
            }
            evaluation_cache_started = time.perf_counter()
            evaluation_cache_cpu_started = time.process_time()
            evaluation_cache_stats = OracleStats()
            if objective.sigma > 0.0:
                evaluation_base = np.concatenate(base_outputs[1:], axis=0)
                evaluation_cache_stats += objective.prime_base_cache(
                    evaluation_base, role="evaluation"
                )
            evaluation_cache_phase = {
                "wall_seconds": time.perf_counter() - evaluation_cache_started,
                "cpu_seconds": time.process_time() - evaluation_cache_cpu_started,
                "oracle_stats": asdict(evaluation_cache_stats),
            }
            additional_training_phases.append(
                ("mollifier_training_cache", training_cache_phase)
            )
            write_json(
                run_directory / "mollifier_cache.json",
                {
                    **objective.receipt(),
                    "training_cache_oracle_stats": asdict(training_cache_stats),
                    "evaluation_cache_oracle_stats": asdict(evaluation_cache_stats),
                    "training_phase": training_cache_phase,
                    "evaluation_phase": evaluation_cache_phase,
                    "training_examples": len(train.contexts),
                    "evaluation_examples": len(validation.contexts)
                    + len(test.contexts),
                },
            )
        else:
            objective_started = time.perf_counter()
            objective_cpu_started = time.process_time()
            objective = _objective(
                spec,
                objective_interface,
                train,
                deployment_problem=deployment_problem,
            )
            if spec.method in {
                "rayen_policy",
                "soft_radial_policy",
                "soft_radial_log_barrier",
                "log_energy_policy",
            }:
                objective_phase = {
                    "training_wall_seconds": time.perf_counter() - objective_started,
                    "training_cpu_seconds": time.process_time() - objective_cpu_started,
                    "total_training_oracle_stats": asdict(OracleStats()),
                }
                additional_training_phases.append(
                    ("objective_initialization", objective_phase)
                )
                write_json(
                    run_directory / "objective_initialization.json",
                    objective_phase,
                )
            if bool(spec.method_parameters.get("validation_protocol_suite", False)):
                if not isinstance(
                    objective,
                    (SoftRadialLogBarrierObjective, LogEnergyPolicyObjective),
                ):
                    raise ValueError(
                        "validation protocol suite requires a barrier policy objective"
                    )
                objective.set_checkpoint_selection_deployment("hard_recovered")
            if isinstance(
                objective,
                (SoftRadialLogBarrierObjective, LogEnergyPolicyObjective),
            ):
                deployment_mode = (
                    "hard_recovered"
                    if bool(
                        spec.method_parameters.get("validation_protocol_suite", False)
                    )
                    else str(spec.method_parameters.get("deployment_mode", "soft"))
                )
                objective.set_deployment_mode(deployment_mode)
                objective.set_checkpoint_selection_deployment(deployment_mode)
            receipt = getattr(objective, "receipt", None)
            if receipt is not None:
                write_json(run_directory / "policy_geometry.json", receipt())
            prepare_training_split = getattr(objective, "prepare_training_split", None)
            if (
                prepare_training_split is not None
                and os.environ.get("PROXIMAL_SPO_DISABLE_POLICY_COST_CACHE") != "1"
            ):
                cache_started = time.perf_counter()
                cache_cpu_started = time.process_time()
                train = prepare_training_split(train)
                cached_arrays = (
                    train.policy_reduced_costs,
                    train.policy_center_costs,
                )
                cached_bytes = sum(
                    0 if value is None else int(value.nbytes) for value in cached_arrays
                )
                cache_phase = {
                    "training_wall_seconds": time.perf_counter() - cache_started,
                    "training_cpu_seconds": time.process_time() - cache_cpu_started,
                    "total_training_oracle_stats": asdict(OracleStats()),
                    "cache_bytes": cached_bytes,
                    "training_examples": len(train.contexts),
                    "raw_costs_or_weights_persisted": False,
                }
                additional_training_phases.append(
                    ("policy_cost_coordinate_cache", cache_phase)
                )
                write_json(
                    run_directory / "policy_cost_coordinate_cache.json",
                    cache_phase,
                )
        if spec.method == "knn":
            model = KNNRegressor(
                train.contexts,
                train.coefficients,
                neighbors=int(spec.method_parameters.get("neighbors", 10)),
                distance_weighted=bool(
                    spec.method_parameters.get("distance_weighted", False)
                ),
            )
            started = time.perf_counter()
            validation_started = time.perf_counter()
            validation_metrics = evaluate_model(
                model,
                objective,
                validation,
                batch_size=spec.training.evaluation_batch_size,
            )
            validation_wall_seconds = time.perf_counter() - validation_started
            recorder.append_curve(
                {
                    "epoch": 0,
                    "validation": validation_metrics.to_dict(),
                    "validation_wall_seconds": validation_wall_seconds,
                }
            )
            if evaluation_test is None:
                test_metrics = None
                test_evaluation_wall_seconds = 0.0
            else:
                test_started = time.perf_counter()
                test_metrics = evaluate_model(
                    model,
                    objective,
                    evaluation_test,
                    batch_size=spec.training.evaluation_batch_size,
                )
                test_evaluation_wall_seconds = time.perf_counter() - test_started
            result = TrainingResult(
                best_epoch=0,
                epochs_completed=0,
                best_validation=validation_metrics,
                test=test_metrics,
                training_wall_seconds=time.perf_counter() - started,
                training_cpu_seconds=0.0,
                total_training_oracle_stats=OracleStats(),
                parameter_sha256=model_sha256(model),
                trainable_parameters=0,
                optimization_wall_seconds=0.0,
                validation_wall_seconds=validation_wall_seconds,
                test_evaluation_wall_seconds=test_evaluation_wall_seconds,
            )
            recorder.finish(result.to_dict())
        elif spec.method in {"anchored_proximal", "residual_mse"}:
            anchored_model = _anchored_model(
                spec=spec,
                run_directory=run_directory,
                train=train,
                validation=validation,
                interface=interface,
                mean_coefficient=mean_coefficient,
                mean_statistic=mean_statistic,
                repo_root=repo_root,
            )
            model = anchored_model
            embedded_base_outputs = tuple(
                predict_in_batches(
                    anchored_model.base,
                    split.contexts,
                    batch_size=spec.training.evaluation_batch_size,
                )
                for split in (validation, test)
            )
            _record_embedded_mse_base(
                run_directory=run_directory,
                model=anchored_model.base,
                validation_outputs=embedded_base_outputs[0],
                test_outputs=embedded_base_outputs[1],
                validation=validation,
                test=test,
                interface=interface,
                spec=spec,
            )
        elif spec.method != "mollified_anchored_proximal":
            torch.manual_seed(spec.seeds.initialization)
            model = _standard_model(
                spec,
                train,
                objective,
                mean_coefficient,
                mean_statistic,
            )

        def callback(record: dict[str, Any]) -> None:
            if not progress or "validation" not in record:
                return
            validation_record = record["validation"]
            print(
                f"epoch={record['epoch']:04d} "
                f"train={record['train_surrogate_mean']:.6g} "
                f"val_regret={validation_record['mean_regret']:.6g}",
                flush=True,
            )

        protocol_suite = bool(
            spec.method_parameters.get("validation_protocol_suite", False)
        )
        if spec.method != "knn":
            if protocol_suite:
                if not isinstance(
                    objective,
                    (SoftRadialLogBarrierObjective, LogEnergyPolicyObjective),
                ):
                    raise ValueError(
                        "validation protocol suite requires a barrier policy objective"
                    )
                if evaluation_test is None:
                    raise ValueError(
                        "validation protocol suite requires test evaluation"
                    )
                protocol_result = train_barrier_protocol_suite(
                    model=model,
                    objective=objective,
                    train=train,
                    validation=validation,
                    test=evaluation_test,
                    spec=spec.training,
                    protocol=BarrierProtocolSpec(
                        continuation_epochs=int(
                            spec.method_parameters.get("continuation_epochs", 60)
                        ),
                        continuation_extension_epochs=int(
                            spec.method_parameters.get(
                                "continuation_extension_epochs", 60
                            )
                        ),
                        continuation_late_window=int(
                            spec.method_parameters.get("continuation_late_window", 10)
                        ),
                        continuation_minimum_delta=float(
                            spec.method_parameters.get(
                                "continuation_minimum_delta", 1e-6
                            )
                        ),
                    ),
                    shuffle_seed=spec.seeds.shuffle,
                    recorder=recorder,
                    epoch_callback=callback,
                )
                result = protocol_result.training_result
                write_json(
                    run_directory / "validation_protocols.json",
                    protocol_result.receipt,
                )
            else:
                result = train_model(
                    model=model,
                    objective=objective,
                    train=train,
                    validation=validation,
                    test=evaluation_test,
                    spec=spec.training,
                    shuffle_seed=spec.seeds.shuffle,
                    recorder=recorder,
                    epoch_callback=callback,
                )
        if (
            isinstance(
                objective,
                (SoftRadialLogBarrierObjective, LogEnergyPolicyObjective),
            )
            and not protocol_suite
        ):
            deployment_interface = (
                objective.deployment_interface
                if isinstance(objective, SoftRadialLogBarrierObjective)
                else objective.interface
            )
            hard_problem_is_integer = bool(
                np.any(deployment_interface.problem.integrality)
            )
            selected_deployment = str(
                spec.method_parameters.get("deployment_mode", "soft")
            )
            if selected_deployment not in {"soft", "hard_recovered"}:
                raise ValueError(
                    f"invalid checkpoint-selection deployment: {selected_deployment}"
                )
            deployment_ablation: dict[str, Any] = {
                "checkpoint_selected_by": (
                    f"validation {selected_deployment} deployment regret"
                ),
                "selection_metric": (
                    f"validation {selected_deployment} deployment regret"
                ),
                "deployments": {},
            }
            try:
                for mode in ("soft", "hard_recovered"):
                    if mode == "soft" and hard_problem_is_integer:
                        deployment_ablation["deployments"][mode] = {
                            "status": "not_applicable",
                            "reason": (
                                "the training decision lies in the continuous "
                                "relaxation and can outperform the hard MILP optimum; "
                                "it is not a feasible deployment for integer problems"
                            ),
                        }
                        continue
                    objective.set_deployment_mode(mode)
                    mode_metrics: dict[str, Any] = {
                        "validation": evaluate_model(
                            model,
                            objective,
                            validation,
                            batch_size=spec.training.evaluation_batch_size,
                        ).to_dict(),
                    }
                    if evaluation_test is not None:
                        mode_metrics["test"] = evaluate_model(
                            model,
                            objective,
                            evaluation_test,
                            batch_size=spec.training.evaluation_batch_size,
                        ).to_dict()
                    deployment_ablation["deployments"][mode] = mode_metrics
            finally:
                objective.set_deployment_mode(selected_deployment)
            write_json(
                run_directory / "deployment_ablation.json",
                deployment_ablation,
            )
        if bool(spec.method_parameters.get("prediction_correction", False)):
            if not isinstance(
                objective, SoftRadialLogBarrierObjective
            ) or not isinstance(model, StandardizedMLP):
                raise ValueError(
                    "prediction correction currently requires a standard "
                    "Soft-Radial log-barrier model"
                )
            recorder.start_phase("prediction_correction")
            correction_payload, correction_phase = _run_prediction_correction_suite(
                model=model,
                objective=objective,
                train=train,
                validation=validation,
                test=test,
                interface=interface,
                spec=spec,
            )
            write_json(run_directory / "prediction_correction.json", correction_payload)
            additional_training_phases.append(
                ("prediction_correction", correction_phase)
            )
            recorder.finish(result.to_dict())
        if bool(spec.method_parameters.get("exact_head", False)):
            if (
                spec.method != "proximal"
                or not isinstance(model, StandardizedMLP)
                or not isinstance(objective, ProximalObjective)
            ):
                raise ValueError(
                    "exact_head is currently defined for raw proximal runs"
                )
            recorder.start_phase("post_adam_exact_head")
            exact_started = time.perf_counter()
            exact_cpu_started = time.process_time()
            adam_result = result
            training_tau = float(spec.method_parameters.get("tau", 0.3))
            head_tau = float(spec.method_parameters.get("exact_head_tau", training_tau))
            feature_batch = spec.training.evaluation_batch_size
            train_features = _hidden_features(
                model, train.contexts, batch_size=feature_batch
            )
            validation_features = _hidden_features(
                model, validation.contexts, batch_size=feature_batch
            )
            test_features = _hidden_features(
                model, test.contexts, batch_size=feature_batch
            )
            (
                (train_features, validation_features, test_features),
                feature_receipt,
            ) = _compress_exact_features(
                (train_features, validation_features, test_features),
                maximum_nonconstant_dimension=(
                    int(spec.method_parameters["exact_head_feature_dimension"])
                    if "exact_head_feature_dimension" in spec.method_parameters
                    else None
                ),
            )
            center_on_adam = bool(
                spec.method_parameters.get("exact_head_center_on_adam", False)
            )
            offsets = (
                np.zeros(
                    (len(train.contexts), interface.report_dimension),
                    dtype=np.float64,
                ),
                np.zeros(
                    (len(validation.contexts), interface.report_dimension),
                    dtype=np.float64,
                ),
                np.zeros(
                    (len(test.contexts), interface.report_dimension),
                    dtype=np.float64,
                ),
            )
            canonicalization_training_stats = OracleStats()
            canonicalization_evaluation_stats = OracleStats()
            if center_on_adam:
                offset_rows: list[np.ndarray] = []
                for split_index, split in enumerate((train, validation, test)):
                    offset, offset_stats = _canonical_adam_offsets(
                        model=model,
                        objective=objective,
                        split=split,
                        head_tau=head_tau,
                        batch_size=feature_batch,
                    )
                    offset_rows.append(offset)
                    if split_index == 0:
                        canonicalization_training_stats += offset_stats
                    else:
                        canonicalization_evaluation_stats += offset_stats
                offsets = (offset_rows[0], offset_rows[1], offset_rows[2])
            exact_solver = (
                solve_exact_proximal_head_decomposed
                if train_features.shape[1] > 16
                else solve_exact_proximal_head
            )
            exact = exact_solver(
                features=train_features,
                coefficients=train.coefficients,
                interface=interface,
                tau=head_tau,
                report_scale=1.0,
                report_offset=offsets[0],
                ridge=float(spec.method_parameters.get("exact_head_ridge", 1e-8)),
                **(
                    {"workers": spec.workers}
                    if exact_solver is solve_exact_proximal_head_decomposed
                    else {}
                ),
            )
            exact_objective = ProximalObjective(
                interface,
                tau=head_tau,
                workers=spec.workers,
                report_scale=1.0,
            )
            try:
                validation_reports = offsets[1] + validation_features @ exact.weights
                test_reports = offsets[2] + test_features @ exact.weights
                exact_validation = evaluate_outputs(
                    exact_objective,
                    validation_reports,
                    validation,
                    batch_size=feature_batch,
                )
                exact_test = evaluate_outputs(
                    exact_objective,
                    test_reports,
                    test,
                    batch_size=feature_batch,
                )
            finally:
                exact_objective.close()
            exact_stage_stats = exact.stats + canonicalization_training_stats
            exact_phase = {
                "training_wall_seconds": time.perf_counter() - exact_started,
                "training_cpu_seconds": time.process_time() - exact_cpu_started,
                "total_training_oracle_stats": asdict(exact_stage_stats),
            }
            additional_training_phases.append(("post_adam_exact_head", exact_phase))
            write_json(
                run_directory / "exact_head.json",
                {
                    **exact.receipt(),
                    "mode": "post_adam",
                    "training_tau": training_tau,
                    "head_tau": head_tau,
                    "centered_on_adam": center_on_adam,
                    "canonicalization_training_oracle_stats": asdict(
                        canonicalization_training_stats
                    ),
                    "canonicalization_evaluation_oracle_stats": asdict(
                        canonicalization_evaluation_stats
                    ),
                    "pre_exact_head_validation": adam_result.best_validation.to_dict(),
                    "pre_exact_head_test": (
                        None if adam_result.test is None else adam_result.test.to_dict()
                    ),
                    "validation": exact_validation.to_dict(),
                    "test": exact_test.to_dict(),
                    "training_phase": exact_phase,
                    **feature_receipt,
                    "weights_persisted": False,
                },
            )
            result = replace(
                adam_result,
                best_validation=exact_validation,
                test=exact_test,
                parameter_sha256=_parameter_digest(exact.weights, model=model),
            )
            recorder.finish(result.to_dict())
            exact_diagnostics_objective = ProximalObjective(
                interface,
                tau=head_tau,
                workers=spec.workers,
                report_scale=1.0,
            )
            try:
                write_json(
                    run_directory / "prediction_diagnostics.json",
                    _exact_output_diagnostics(
                        physical_reports=test_reports,
                        objective=exact_diagnostics_objective,
                        split=test,
                        batch_size=spec.training.evaluation_batch_size,
                    ),
                )
            finally:
                exact_diagnostics_objective.close()
            prediction_diagnostics_written = True
        if isinstance(objective, MollifiedAnchoredProximalObjective):
            mollification_receipt = {
                **objective.receipt(),
                "validation": _mollification_diagnostics(
                    model=model,
                    objective=objective,
                    split=validation,
                    batch_size=spec.training.evaluation_batch_size,
                ),
                "test": _mollification_diagnostics(
                    model=model,
                    objective=objective,
                    split=test,
                    batch_size=spec.training.evaluation_batch_size,
                ),
            }
            write_json(
                run_directory / "mollification_diagnostics.json",
                mollification_receipt,
            )
            write_json(
                run_directory / "prediction_diagnostics.json",
                mollification_receipt["test"],
            )
            prediction_diagnostics_written = True
        if not prediction_diagnostics_written:
            diagnostic_split = test if spec.evaluate_test else validation
            write_json(
                run_directory / "prediction_diagnostics.json",
                {
                    "split": "test" if spec.evaluate_test else "validation",
                    **_prediction_diagnostics(
                        model,
                        objective,
                        diagnostic_split,
                        batch_size=spec.training.evaluation_batch_size,
                    ),
                },
            )
        # Add immutable data-preparation accounting without rewriting the
        # already flushed curve.  The summary is augmented atomically.
        _augment_run_accounting(
            run_directory=run_directory,
            preparation_stats=preparation_stats,
            additional_training_phases=additional_training_phases,
        )
        return result
    except BaseException as error:
        # train_model already records training failures; this covers assembly
        # and base-pretraining failures.
        if not (run_directory / "status.json").exists():
            raise
        recorder.fail(error)
        raise
    finally:
        if objective is not None:
            objective.close()
