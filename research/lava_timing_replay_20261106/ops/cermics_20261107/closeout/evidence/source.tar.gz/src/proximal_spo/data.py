"""Regenerable one-context/one-cost-pair datasets."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np

from .problem import (
    FloatArray,
    LinearProblem,
    PartialCostInterface,
    has_full_row_rank,
)
from .seeds import derive_seed, rng

CostStyle = Literal["positive", "negative", "signed"]
NoiseKind = Literal["gaussian", "lognormal", "pyepo_uniform", "skewed_failure"]


@dataclass(frozen=True)
class SplitSizes:
    train: int
    validation: int
    test: int

    def __post_init__(self) -> None:
        if min(self.train, self.validation, self.test) <= 0:
            raise ValueError("all split sizes must be positive")


@dataclass(frozen=True)
class PhysicalCostSplit:
    contexts: FloatArray
    physical_costs: FloatArray
    conditional_mean_costs: FloatArray
    split: str
    seed: int
    coefficients: FloatArray | None = None
    conditional_mean_coefficients: FloatArray | None = None

    def __post_init__(self) -> None:
        contexts = np.asarray(self.contexts, dtype=np.float64)
        costs = np.asarray(self.physical_costs, dtype=np.float64)
        means = np.asarray(self.conditional_mean_costs, dtype=np.float64)
        if contexts.ndim != 2 or costs.ndim != 2 or means.shape != costs.shape:
            raise ValueError("dataset arrays have incompatible shapes")
        if contexts.shape[0] != costs.shape[0] or not all(
            np.all(np.isfinite(array)) for array in (contexts, costs, means)
        ):
            raise ValueError("dataset arrays must align and be finite")
        coefficients = self.coefficients
        conditional_coefficients = self.conditional_mean_coefficients
        if (coefficients is None) != (conditional_coefficients is None):
            raise ValueError("coefficient arrays must be supplied together")
        if coefficients is not None and conditional_coefficients is not None:
            coefficients = np.asarray(coefficients, dtype=np.float64)
            conditional_coefficients = np.asarray(
                conditional_coefficients, dtype=np.float64
            )
            if (
                coefficients.ndim != 2
                or conditional_coefficients.shape != coefficients.shape
                or coefficients.shape[0] != contexts.shape[0]
                or not np.all(np.isfinite(coefficients))
                or not np.all(np.isfinite(conditional_coefficients))
            ):
                raise ValueError("explicit coefficient arrays are incompatible")
            object.__setattr__(
                self, "coefficients", np.ascontiguousarray(coefficients).copy()
            )
            object.__setattr__(
                self,
                "conditional_mean_coefficients",
                np.ascontiguousarray(conditional_coefficients).copy(),
            )
        object.__setattr__(self, "contexts", np.ascontiguousarray(contexts).copy())
        object.__setattr__(self, "physical_costs", np.ascontiguousarray(costs).copy())
        object.__setattr__(
            self, "conditional_mean_costs", np.ascontiguousarray(means).copy()
        )

    @property
    def size(self) -> int:
        return int(self.contexts.shape[0])


@dataclass(frozen=True)
class DatasetBundle:
    train: PhysicalCostSplit
    validation: PhysicalCostSplit
    test: PhysicalCostSplit
    fixed_anchor: FloatArray
    random_indices: np.ndarray
    benchmark_id: str
    master_seed: int
    law: str
    cost_statistic: FloatArray | None = None

    def __post_init__(self) -> None:
        n = self.train.physical_costs.shape[1]
        if (
            self.validation.physical_costs.shape[1] != n
            or self.test.physical_costs.shape[1] != n
        ):
            raise ValueError("split cost dimensions disagree")
        anchor = np.asarray(self.fixed_anchor, dtype=np.float64)
        indices = np.asarray(self.random_indices, dtype=np.int64)
        if anchor.shape != (n,) or indices.ndim != 1 or indices.size == 0:
            raise ValueError("invalid fixed anchor or random indices")
        statistic = self.cost_statistic
        if statistic is not None:
            statistic = np.asarray(statistic, dtype=np.float64)
            if (
                statistic.ndim != 2
                or statistic.shape[1] != n
                or not np.all(np.isfinite(statistic))
                or not has_full_row_rank(statistic)
            ):
                raise ValueError("cost statistic must have independent finite rows")
            if np.any(indices < 0) or np.any(indices >= statistic.shape[0]):
                raise ValueError("random coefficient index outside cost statistic")
            for split in (self.train, self.validation, self.test):
                if (
                    split.coefficients is None
                    or split.conditional_mean_coefficients is None
                    or split.coefficients.shape[1] != statistic.shape[0]
                ):
                    raise ValueError(
                        "explicit cost statistic requires matching split coefficients"
                    )
                reconstructed = anchor + split.coefficients @ statistic
                reconstructed_mean = (
                    anchor + split.conditional_mean_coefficients @ statistic
                )
                if not np.allclose(
                    reconstructed, split.physical_costs, rtol=1e-9, atol=1e-9
                ) or not np.allclose(
                    reconstructed_mean,
                    split.conditional_mean_costs,
                    rtol=1e-9,
                    atol=1e-9,
                ):
                    raise ValueError(
                        "cost statistic does not reconstruct physical split costs"
                    )
            object.__setattr__(self, "cost_statistic", np.ascontiguousarray(statistic))
        object.__setattr__(self, "fixed_anchor", anchor)
        object.__setattr__(self, "random_indices", indices)

    def interface(
        self, mode: Literal["partial", "full"], problem: LinearProblem
    ) -> PartialCostInterface:
        if self.cost_statistic is not None:
            if mode != "full":
                raise ValueError(
                    "partial coordinates are not defined for an external cost exposure"
                )
            return PartialCostInterface(
                problem,
                self.fixed_anchor,
                self.cost_statistic,
                name="external_cost_exposure",
            )
        if mode == "full":
            return PartialCostInterface.full_cost(problem)
        if mode == "partial":
            return PartialCostInterface.selected_coordinates(
                problem, self.fixed_anchor, self.random_indices
            )
        raise ValueError(f"unknown interface mode: {mode}")

    def coefficients(
        self, split: PhysicalCostSplit, mode: Literal["partial", "full"]
    ) -> tuple[FloatArray, FloatArray]:
        if split.coefficients is not None:
            if mode != "full" or split.conditional_mean_coefficients is None:
                raise ValueError(
                    "partial coordinates are not defined for explicit coefficients"
                )
            return split.coefficients, split.conditional_mean_coefficients
        if mode == "full":
            return split.physical_costs, split.conditional_mean_costs
        return (
            split.physical_costs[:, self.random_indices],
            split.conditional_mean_costs[:, self.random_indices],
        )


@dataclass(frozen=True)
class CostLawSpec:
    context_dimension: int = 5
    random_fraction: float = 1.0
    style: CostStyle = "positive"
    noise: NoiseKind = "gaussian"
    noise_scale: float = 0.25
    signal_scale: float = 0.30
    polynomial_degree: int = 2

    def __post_init__(self) -> None:
        if self.context_dimension <= 0:
            raise ValueError("context_dimension must be positive")
        if not 0.0 < self.random_fraction <= 1.0:
            raise ValueError("random_fraction must lie in (0,1]")
        if self.noise_scale < 0.0 or self.signal_scale < 0.0:
            raise ValueError("noise and signal scales must be nonnegative")
        if self.polynomial_degree <= 0:
            raise ValueError("polynomial_degree must be positive")


def default_cost_style(benchmark_id: str) -> CostStyle:
    if "knapsack" in benchmark_id:
        return "negative"
    if "random_lp" in benchmark_id:
        return "signed"
    return "positive"


def _fixed_anchor(
    variables: int, style: CostStyle, *, structural_seed: int
) -> FloatArray:
    random = rng(structural_seed, "fixed_cost_anchor")
    magnitude = random.uniform(0.75, 1.25, size=variables)
    if style == "positive":
        return magnitude
    if style == "negative":
        return -magnitude
    signs = random.choice(np.array([-1.0, 1.0]), size=variables)
    return np.asarray(magnitude * signs, dtype=np.float64)


def _random_coordinates(
    variables: int, fraction: float, *, structural_seed: int
) -> np.ndarray:
    count = max(1, min(variables, int(round(fraction * variables))))
    random = rng(structural_seed, "random_cost_coordinates")
    return np.sort(random.choice(variables, size=count, replace=False)).astype(np.int64)


def _context_signal(
    contexts: FloatArray,
    output_dimension: int,
    *,
    structural_seed: int,
    degree: int,
) -> FloatArray:
    parameter_rng = rng(structural_seed, "context_parameters", output_dimension)
    coefficient = parameter_rng.normal(
        size=(output_dimension, contexts.shape[1])
    ) / np.sqrt(contexts.shape[1])
    linear = contexts @ coefficient.T
    polynomial = np.sign(linear) * np.abs(linear) ** degree
    # Saturation avoids the heavy numerical tails of raw high-degree powers
    # while preserving the nonlinear polynomial ordering used in DFL tests.
    return np.asarray(np.tanh(polynomial), dtype=np.float64)


def _sample_split(
    *,
    count: int,
    split: str,
    benchmark_id: str,
    data_seed: int,
    fixed_anchor: FloatArray,
    random_indices: np.ndarray,
    law: CostLawSpec,
    structural_seed: int,
) -> PhysicalCostSplit:
    split_seed = derive_seed(data_seed, benchmark_id, split, "context_cost_pairs")
    random = rng(split_seed, "draws")
    if law.noise == "pyepo_uniform":
        contexts = random.normal(size=(count, law.context_dimension))
    else:
        contexts = random.uniform(-1.0, 1.0, size=(count, law.context_dimension))
    costs = np.repeat(fixed_anchor[None, :], count, axis=0)
    means = costs.copy()
    selected_anchor = fixed_anchor[random_indices]

    if law.noise == "skewed_failure":
        if random_indices.size != 1:
            raise ValueError("skewed_failure law is defined for one random coordinate")
        shift = law.signal_scale * np.tanh(contexts[:, 0])
        rare = random.random(count) >= 0.9
        component_mean = np.where(rare, 20.0, -1.0) + shift
        observed = component_mean + random.normal(0.0, law.noise_scale, size=count)
        conditional_mean = 1.1 + shift
        costs[:, random_indices[0]] = observed
        means[:, random_indices[0]] = conditional_mean
    elif law.noise == "pyepo_uniform":
        if law.noise_scale > 1.0:
            raise ValueError("pyepo_uniform noise_scale must not exceed one")
        parameter_rng = rng(
            structural_seed, "pyepo_context_parameters", len(fixed_anchor)
        )
        coefficient = parameter_rng.binomial(
            1, 0.5, size=(random_indices.size, contexts.shape[1])
        ).astype(np.float64)
        linear = contexts @ coefficient.T / np.sqrt(contexts.shape[1])
        conditional_mean = ((linear + 3.0) ** law.polynomial_degree + 1.0) / (
            3.5**law.polynomial_degree
        )
        if law.style == "negative":
            conditional_mean = -conditional_mean
        elif law.style == "signed":
            conditional_mean *= np.sign(selected_anchor)[None, :]
        multiplier = random.uniform(
            1.0 - law.noise_scale,
            1.0 + law.noise_scale,
            size=conditional_mean.shape,
        )
        observed = conditional_mean * multiplier
        costs[:, random_indices] = observed
        means[:, random_indices] = conditional_mean
    else:
        signal = _context_signal(
            contexts,
            random_indices.size,
            structural_seed=structural_seed,
            degree=law.polynomial_degree,
        )
        conditional_mean = selected_anchor[None, :] * (1.0 + law.signal_scale * signal)
        if law.noise == "gaussian":
            scale = law.noise_scale * np.maximum(0.25, np.abs(selected_anchor))[None, :]
            observed = (
                conditional_mean + random.normal(size=conditional_mean.shape) * scale
            )
        elif law.noise == "lognormal":
            sigma = law.noise_scale
            multiplier = random.lognormal(
                mean=-0.5 * sigma**2, sigma=sigma, size=conditional_mean.shape
            )
            observed = conditional_mean * multiplier
        else:
            raise ValueError(f"unknown noise law: {law.noise}")
        costs[:, random_indices] = observed
        means[:, random_indices] = conditional_mean
    return PhysicalCostSplit(contexts, costs, means, split, split_seed)


def generate_dataset(
    problem: LinearProblem,
    benchmark_id: str,
    sizes: SplitSizes,
    *,
    data_seed: int,
    structural_seed: int,
    law: CostLawSpec,
) -> DatasetBundle:
    if benchmark_id == "analytic.scalar_box" and law.noise != "skewed_failure":
        raise ValueError("analytic.scalar_box requires the skewed_failure law")
    anchor = _fixed_anchor(
        problem.variable_count, law.style, structural_seed=structural_seed
    )
    indices = _random_coordinates(
        problem.variable_count, law.random_fraction, structural_seed=structural_seed
    )
    if law.noise == "skewed_failure":
        anchor = np.zeros(problem.variable_count)
        indices = np.array([0], dtype=np.int64)
    return DatasetBundle(
        train=_sample_split(
            count=sizes.train,
            split="train",
            benchmark_id=benchmark_id,
            data_seed=data_seed,
            fixed_anchor=anchor,
            random_indices=indices,
            law=law,
            structural_seed=structural_seed,
        ),
        validation=_sample_split(
            count=sizes.validation,
            split="validation",
            benchmark_id=benchmark_id,
            data_seed=data_seed,
            fixed_anchor=anchor,
            random_indices=indices,
            law=law,
            structural_seed=structural_seed,
        ),
        test=_sample_split(
            count=sizes.test,
            split="test",
            benchmark_id=benchmark_id,
            data_seed=data_seed,
            fixed_anchor=anchor,
            random_indices=indices,
            law=law,
            structural_seed=structural_seed,
        ),
        fixed_anchor=anchor,
        random_indices=indices,
        benchmark_id=benchmark_id,
        master_seed=data_seed,
        law=law.noise,
    )
