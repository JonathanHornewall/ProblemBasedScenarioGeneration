"""Small-to-standard benchmark catalog used by the staged pilot."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from ..problem import LinearProblem
from .linear import (
    assignment,
    binary_multidimensional_knapsack,
    capacitated_facility_location_mip,
    capacitated_facility_location_relaxation,
    continuous_knapsack,
    grid_shortest_path,
    planted_random_lp,
    scalar_box,
    top_k_selection,
)


@dataclass(frozen=True)
class BenchmarkEntry:
    benchmark_id: str
    tier: str
    description: str
    builder: Callable[[int], LinearProblem]


BENCHMARKS: dict[str, BenchmarkEntry] = {
    "analytic.scalar_box": BenchmarkEntry(
        "analytic.scalar_box",
        "toy",
        "One-variable LP with an analytically wrong SPO+ population decision",
        lambda seed: scalar_box(),
    ),
    "cost.grid5": BenchmarkEntry(
        "cost.grid5",
        "small",
        "5x5 directed-grid shortest-path LP relaxation (40 arcs)",
        lambda seed: grid_shortest_path(5, 5),
    ),
    "cost.topk20x5": BenchmarkEntry(
        "cost.topk20x5",
        "small",
        "Top-5-of-20 selection LP (integral polytope)",
        lambda seed: top_k_selection(20, 5),
    ),
    "cost.assignment10": BenchmarkEntry(
        "cost.assignment10",
        "realistic_nonlarge",
        "10-by-10 bipartite assignment LP (integral polytope)",
        lambda seed: assignment(10),
    ),
    "cost.knapsack20x5": BenchmarkEntry(
        "cost.knapsack20x5",
        "small",
        "20-item, 5-resource continuous multidimensional knapsack",
        lambda seed: continuous_knapsack(20, 5, structural_seed=seed),
    ),
    "cost.knapsack50x5": BenchmarkEntry(
        "cost.knapsack50x5",
        "realistic_nonlarge",
        "50-item, 5-resource continuous multidimensional knapsack",
        lambda seed: continuous_knapsack(50, 5, structural_seed=seed),
    ),
    "cost.binary_knapsack20x5": BenchmarkEntry(
        "cost.binary_knapsack20x5",
        "small",
        "20-item, 5-resource binary multidimensional knapsack",
        lambda seed: binary_multidimensional_knapsack(
            20, 5, structural_seed=seed
        ),
    ),
    "cost.binary_knapsack50x5": BenchmarkEntry(
        "cost.binary_knapsack50x5",
        "realistic_nonlarge",
        "50-item, 5-resource binary multidimensional knapsack",
        lambda seed: binary_multidimensional_knapsack(
            50, 5, structural_seed=seed
        ),
    ),
    "cost.facility30x5_relaxation": BenchmarkEntry(
        "cost.facility30x5_relaxation",
        "standard",
        "30-client, 5-facility capacitated-facility-location LP relaxation",
        lambda seed: capacitated_facility_location_relaxation(
            30, 5, structural_seed=seed
        ),
    ),
    "cost.facility15x4_mip": BenchmarkEntry(
        "cost.facility15x4_mip",
        "small",
        "15-client, 4-facility capacitated facility-location MILP",
        lambda seed: capacitated_facility_location_mip(
            15, 4, structural_seed=seed
        ),
    ),
    "cost.facility30x5_mip": BenchmarkEntry(
        "cost.facility30x5_mip",
        "realistic_nonlarge",
        "30-client, 5-facility capacitated facility-location MILP",
        lambda seed: capacitated_facility_location_mip(
            30, 5, structural_seed=seed
        ),
    ),
    "cost.random_lp60x30": BenchmarkEntry(
        "cost.random_lp60x30",
        "realistic_nonlarge",
        "60-variable, 30-row sparse planted-feasible random LP",
        lambda seed: planted_random_lp(60, 30, structural_seed=seed),
    ),
    "cost.random_lp100x50": BenchmarkEntry(
        "cost.random_lp100x50",
        "standard",
        "100-variable, 50-row LAVA-style sparse random LP",
        lambda seed: planted_random_lp(100, 50, structural_seed=seed),
    ),
}


def list_benchmarks() -> tuple[BenchmarkEntry, ...]:
    return tuple(BENCHMARKS[key] for key in sorted(BENCHMARKS))


def build_benchmark(benchmark_id: str, *, structural_seed: int) -> LinearProblem:
    try:
        entry = BENCHMARKS[benchmark_id]
    except KeyError as exc:
        raise KeyError(f"unknown benchmark {benchmark_id!r}") from exc
    return entry.builder(structural_seed)
