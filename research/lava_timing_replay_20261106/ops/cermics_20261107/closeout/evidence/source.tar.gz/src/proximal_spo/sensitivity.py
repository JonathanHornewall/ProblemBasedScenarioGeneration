"""Active-face Jacobian products for strongly convex quadratic layers."""

from __future__ import annotations

import numpy as np
from scipy.sparse import csc_matrix

from .problem import FloatArray, LinearProblem


def active_constraint_matrix(
    problem: LinearProblem,
    decision: FloatArray,
    *,
    tolerance: float = 2e-5,
) -> FloatArray:
    """Return rows whose equalities/faces determine the local tangent space."""

    decision = np.asarray(decision, dtype=np.float64)
    rows: list[FloatArray] = []
    matrix = np.asarray(csc_matrix(problem.matrix).toarray(), dtype=np.float64)
    activity = matrix @ decision
    for row, value, lower, upper in zip(
        matrix,
        activity,
        problem.row_lower,
        problem.row_upper,
        strict=True,
    ):
        equality = (
            np.isfinite(lower)
            and np.isfinite(upper)
            and abs(upper - lower) <= tolerance
        )
        lower_active = np.isfinite(lower) and abs(value - lower) <= tolerance
        upper_active = np.isfinite(upper) and abs(value - upper) <= tolerance
        if equality or lower_active or upper_active:
            rows.append(row)
    for index, value in enumerate(decision):
        lower_active = (
            np.isfinite(problem.variable_lower[index])
            and abs(value - problem.variable_lower[index]) <= tolerance
        )
        upper_active = (
            np.isfinite(problem.variable_upper[index])
            and abs(value - problem.variable_upper[index]) <= tolerance
        )
        if lower_active or upper_active:
            row = np.zeros(problem.variable_count)
            row[index] = 1.0
            rows.append(row)
    if not rows:
        return np.empty((0, problem.variable_count))
    return np.stack(rows)


def project_onto_tangent(
    problem: LinearProblem,
    decision: FloatArray,
    vector: FloatArray,
    *,
    tolerance: float = 2e-5,
) -> FloatArray:
    """Orthogonally project ``vector`` onto the current active-face tangent."""

    vector = np.asarray(vector, dtype=np.float64)
    active = active_constraint_matrix(problem, decision, tolerance=tolerance)
    if active.shape[0] == 0:
        return vector.copy()
    gram = active @ active.T
    multipliers = np.linalg.lstsq(gram, active @ vector, rcond=1e-10)[0]
    projection = vector - active.T @ multipliers
    # Remove numerical remnants in directions declared normal.
    if np.linalg.norm(active @ projection, ord=np.inf) > 1e-5 * max(
        1.0, np.linalg.norm(vector)
    ):
        raise RuntimeError("active-set tangent projection is numerically inconsistent")
    return projection
