"""Strict JSON configuration schema for one independently replayable run."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any, Literal, TypeVar, cast

from .data import CostLawSpec, SplitSizes
from .models import ModelSpec
from .training import TrainingSpec

T = TypeVar("T")


_METHOD_PARAMETERS: dict[str, frozenset[str]] = {
    "mse": frozenset(),
    "intopt_original": frozenset({"mu_cutoff"}),
    "wise": frozenset(),
    "spo_plus": frozenset(),
    "pyepo_spo_plus": frozenset({"solver_backend"}),
    "pyepo_spo_plus_relaxation": frozenset({"solver_backend"}),
    "spo_plus_relaxation": frozenset(),
    "perturbed_fy": frozenset({"epsilon", "samples"}),
    "direct_projection": frozenset(),
    "rayen_policy": frozenset(),
    "soft_radial_policy": frozenset(
        {
            "contraction",
            "contraction_scale",
            "minimum_scale",
            "kernel_backend",
            "torch_device",
        }
    ),
    "soft_radial_log_barrier": frozenset(
        {
            "report_guard",
            "hessian_whitening",
            "guard_safety_factor",
            "guard_radius_policy",
            "barrier_cost_scaling",
            "contraction",
            "contraction_scale",
            "minimum_scale",
            "alpha_start",
            "alpha_end",
            "schedule",
            "anneal_fraction",
            "validation_protocol_suite",
            "continuation_epochs",
            "continuation_extension_epochs",
            "continuation_late_window",
            "continuation_minimum_delta",
            "deployment_mode",
            "kernel_backend",
            "torch_device",
            "prediction_correction",
            "prediction_correction_cone",
            "prediction_correction_minimum_scale",
            "prediction_correction_ridges",
            "prediction_correction_replay_audit_size",
            "prediction_correction_neural",
            "prediction_correction_exact_only",
            "prediction_correction_legacy",
            "prediction_correction_mse_learning_rate",
            "prediction_correction_mse_epochs",
            "prediction_correction_neural_learning_rates",
            "prediction_correction_neural_epochs",
            "prediction_correction_neural_patience",
            "prediction_correction_neural_width",
            "prediction_correction_neural_depth",
            "prediction_correction_mu_normalize_directions",
            "prediction_correction_include_projected_head",
        }
    ),
    "log_energy_policy": frozenset(
        {
            "mu_start",
            "mu_end",
            "alpha_start",
            "alpha_end",
            "schedule",
            "anneal_fraction",
            "energy_guard",
            "training_root_tolerance",
            "evaluation_root_tolerance",
            "matrix_backend",
            "kernel_backend",
            "torch_device",
            "validation_protocol_suite",
            "continuation_epochs",
            "continuation_extension_epochs",
            "continuation_late_window",
            "continuation_minimum_delta",
            "deployment_mode",
        }
    ),
    "knn": frozenset({"neighbors", "distance_weighted"}),
    "proximal": frozenset(
        {
            "tau",
            "parameterization",
            "exact_head",
            "exact_head_tau",
            "exact_head_ridge",
            "exact_head_feature_dimension",
            "exact_head_center_on_adam",
        }
    ),
    "anchored_proximal": frozenset(
        {
            "tau",
            "alpha",
            "base_method",
            "base_epochs",
            "base_learning_rate",
            "base_batch_size",
            "freeze_base",
            "center_on_base_decision",
        }
    ),
    "residual_mse": frozenset(
        {
            "base_method",
            "base_epochs",
            "base_learning_rate",
            "base_batch_size",
            "freeze_base",
        }
    ),
    "mollified_anchored_proximal": frozenset(
        {
            "tau",
            "sigma",
            "training_samples",
            "evaluation_samples",
            "base_epochs",
            "base_learning_rate",
            "base_batch_size",
        }
    ),
    "exact_proximal_linear": frozenset(
        {"tau", "exact_head_ridge", "exact_head_feature_dimension"}
    ),
    "exact_proximal_mse_base": frozenset(
        {
            "tau",
            "base_epochs",
            "base_learning_rate",
            "center_on_base_decision",
            "exact_head_ridge",
            "exact_head_feature_dimension",
        }
    ),
    "score_function": frozenset({"sigma", "samples"}),
    "sfge": frozenset({"sigma", "samples"}),
    "sfge_relaxation": frozenset({"sigma", "samples"}),
    "quadratic_smoothing": frozenset({"smoothing"}),
    "smoothed_sce": frozenset({"smoothing"}),
    "log_smoothing": frozenset({"mu_start", "mu_end"}),
}


def _positive_number(value: Any, name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0:
        raise ValueError(f"{name} must be a positive number")


def _nonnegative_number(value: Any, name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0:
        raise ValueError(f"{name} must be a nonnegative number")


def _construct(cls: type[T], payload: dict[str, Any]) -> T:
    permitted = {item.name for item in fields(cast(Any, cls))}
    unknown = set(payload) - permitted
    if unknown:
        raise ValueError(f"unknown {cls.__name__} fields: {sorted(unknown)}")
    return cls(**payload)


@dataclass(frozen=True)
class SeedSpec:
    data: int = 1
    structural: int = 101
    initialization: int = 201
    shuffle: int = 301
    perturbation: int = 401

    def __post_init__(self) -> None:
        if min(asdict(self).values()) < 0:
            raise ValueError("seeds must be nonnegative")


@dataclass(frozen=True)
class RunSpec:
    name: str
    benchmark_id: str
    method: str
    benchmark_source: Literal["local", "dfl_extensions_lab"] = "local"
    conditional_reference_samples: int = 128
    cost_coordinate_normalization: Literal["none", "standardize"] = "none"
    evaluate_test: bool = True
    interface: Literal["partial", "full"] = "partial"
    workers: int = 1
    sizes: SplitSizes = field(default_factory=lambda: SplitSizes(256, 128, 256))
    law: CostLawSpec = field(default_factory=CostLawSpec)
    model: ModelSpec = field(default_factory=ModelSpec)
    training: TrainingSpec = field(default_factory=TrainingSpec)
    seeds: SeedSpec = field(default_factory=SeedSpec)
    method_parameters: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.name or not self.benchmark_id:
            raise ValueError("name and benchmark_id are required")
        if self.benchmark_source not in {"local", "dfl_extensions_lab"}:
            raise ValueError("unknown benchmark source")
        if self.cost_coordinate_normalization not in {"none", "standardize"}:
            raise ValueError("unknown cost-coordinate normalization")
        if not isinstance(self.evaluate_test, bool):
            raise ValueError("evaluate_test must be boolean")
        if (
            isinstance(self.conditional_reference_samples, bool)
            or self.conditional_reference_samples <= 0
        ):
            raise ValueError("conditional_reference_samples must be positive")
        if self.benchmark_source == "dfl_extensions_lab" and self.interface != "full":
            raise ValueError(
                "DFL Extensions Lab cost exposures currently require interface=full"
            )
        if self.method not in {
            "intopt_original",
            "mse",
            "wise",
            "spo_plus",
            "pyepo_spo_plus",
            "pyepo_spo_plus_relaxation",
            "spo_plus_relaxation",
            "perturbed_fy",
            "proximal",
            "anchored_proximal",
            "residual_mse",
            "mollified_anchored_proximal",
            "exact_proximal_linear",
            "exact_proximal_mse_base",
            "score_function",
            "sfge",
            "sfge_relaxation",
            "quadratic_smoothing",
            "smoothed_sce",
            "direct_projection",
            "rayen_policy",
            "soft_radial_policy",
            "soft_radial_log_barrier",
            "log_energy_policy",
            "log_smoothing",
            "knn",
        }:
            raise ValueError(f"unknown method {self.method!r}")
        if self.interface not in {"partial", "full"}:
            raise ValueError("interface must be partial or full")
        if self.workers <= 0:
            raise ValueError("workers must be positive")
        permitted = _METHOD_PARAMETERS[self.method]
        unknown = set(self.method_parameters) - permitted
        if unknown:
            raise ValueError(
                f"unknown {self.method} method parameters: {sorted(unknown)}"
            )
        for key in (
            "tau",
            "exact_head_tau",
            "smoothing",
            "mu_start",
            "mu_end",
            "base_learning_rate",
            "contraction_scale",
            "epsilon",
            "training_root_tolerance",
            "evaluation_root_tolerance",
            "continuation_minimum_delta",
        ):
            if key in self.method_parameters:
                _positive_number(self.method_parameters[key], key)
        if "sigma" in self.method_parameters:
            if self.method == "mollified_anchored_proximal":
                _nonnegative_number(self.method_parameters["sigma"], "sigma")
            else:
                _positive_number(self.method_parameters["sigma"], "sigma")
        for key in ("alpha", "alpha_start", "alpha_end", "exact_head_ridge"):
            if key in self.method_parameters:
                _nonnegative_number(self.method_parameters[key], key)
        if "minimum_scale" in self.method_parameters:
            value = self.method_parameters["minimum_scale"]
            _positive_number(value, "minimum_scale")
            if float(value) >= 1.0:
                raise ValueError("minimum_scale must be smaller than one")
        if self.method == "intopt_original":
            _positive_number(self.method_parameters.get("mu_cutoff", 1e-3), "mu_cutoff")
            if self.model.dtype != "float32":
                raise ValueError("Original IntOpt uses float32 backward arithmetic")
        if self.method == "soft_radial_log_barrier":
            if not isinstance(self.method_parameters.get("hessian_whitening", True), bool):
                raise ValueError("hessian_whitening must be boolean")
            if not 0.0 < float(self.method_parameters.get("guard_safety_factor", 0.5)) < 1.0:
                raise ValueError("guard_safety_factor must lie strictly between zero and one")
            if self.method_parameters.get("guard_radius_policy", "legacy_unit") not in {"legacy_unit", "geometry_certified"}:
                raise ValueError("unknown guard_radius_policy")
            if not isinstance(self.method_parameters.get("report_guard", True), bool):
                raise ValueError("report_guard must be boolean")
            if self.method_parameters.get("barrier_cost_scaling", "training_center_regret") not in {"training_center_regret", "unit"}:
                raise ValueError("unknown barrier_cost_scaling")
            start = float(self.method_parameters.get("alpha_start", 0.0))
            end = float(self.method_parameters.get("alpha_end", start))
            if end > start:
                raise ValueError("alpha_end must not exceed alpha_start")
            schedule = self.method_parameters.get("schedule", "fixed")
            if schedule not in {"fixed", "geometric", "arithmetic"}:
                raise ValueError(
                    "soft-radial barrier schedule must be fixed, geometric, "
                    "or arithmetic"
                )
            if schedule == "fixed" and end != start:
                raise ValueError("fixed schedule requires alpha_start == alpha_end")
            if schedule == "geometric" and (start <= 0.0 or end <= 0.0):
                raise ValueError("geometric schedule requires positive alphas")
            anneal_fraction = self.method_parameters.get("anneal_fraction", 0.75)
            _positive_number(anneal_fraction, "anneal_fraction")
            if float(anneal_fraction) > 1.0:
                raise ValueError("anneal_fraction must not exceed one")
        if self.method in {"soft_radial_policy", "soft_radial_log_barrier"}:
            kernel_backend = self.method_parameters.get("kernel_backend", "numpy")
            torch_device = self.method_parameters.get("torch_device", "auto")
            if kernel_backend not in {"auto", "numpy", "torch"}:
                raise ValueError("kernel_backend must be auto, numpy, or torch")
            if torch_device not in {"auto", "cpu", "cuda", "mps"}:
                raise ValueError("torch_device must be auto, cpu, cuda, or mps")
            if kernel_backend == "numpy" and torch_device not in {"auto", "cpu"}:
                raise ValueError(
                    "torch_device is only meaningful with the Torch kernel"
                )
            if self.model.dtype == "float64" and torch_device == "mps":
                raise ValueError("MPS Soft-Radial requires a float32 model")
        for key in (
            "neighbors",
            "samples",
            "training_samples",
            "evaluation_samples",
            "base_epochs",
            "base_batch_size",
            "exact_head_feature_dimension",
            "continuation_epochs",
            "continuation_extension_epochs",
            "continuation_late_window",
        ):
            if key in self.method_parameters:
                value = self.method_parameters[key]
                if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                    raise ValueError(f"{key} must be a positive integer")
        if "validation_protocol_suite" in self.method_parameters and not isinstance(
            self.method_parameters["validation_protocol_suite"], bool
        ):
            raise ValueError("validation_protocol_suite must be boolean")
        if self.method_parameters.get("deployment_mode", "soft") not in {
            "soft",
            "hard_recovered",
        }:
            raise ValueError("deployment_mode must be soft or hard_recovered")
        if not self.evaluate_test and (
            self.method
            in {
                "anchored_proximal",
                "residual_mse",
                "mollified_anchored_proximal",
                "exact_proximal_linear",
                "exact_proximal_mse_base",
            }
            or bool(self.method_parameters.get("exact_head", False))
            or bool(self.method_parameters.get("validation_protocol_suite", False))
        ):
            raise ValueError(
                "validation-only runs are not supported by embedded-base, exact-head, "
                "or continuation protocols"
            )
        if (
            self.model.dtype == "float32"
            and self.method == "log_energy_policy"
            and self.method_parameters.get("kernel_backend", "numpy")
            in {
                "auto",
                "torch",
            }
        ):
            raise ValueError(
                "the Torch log-energy kernel currently requires a float64 model"
            )
        if self.method == "mollified_anchored_proximal":
            for key in ("training_samples", "evaluation_samples"):
                default = 8 if key == "training_samples" else 64
                value = int(self.method_parameters.get(key, default))
                if value % 2:
                    raise ValueError(f"{key} must be even for antithetic sampling")
        for key in (
            "distance_weighted",
            "exact_head",
            "exact_head_center_on_adam",
            "freeze_base",
            "center_on_base_decision",
            "prediction_correction",
            "prediction_correction_cone",
            "prediction_correction_neural",
            "prediction_correction_exact_only",
            "prediction_correction_legacy",
            "prediction_correction_mu_normalize_directions",
            "prediction_correction_include_projected_head",
        ):
            if key in self.method_parameters and not isinstance(
                self.method_parameters[key], bool
            ):
                raise ValueError(f"{key} must be boolean")
        if "prediction_correction_minimum_scale" in self.method_parameters:
            _positive_number(
                self.method_parameters["prediction_correction_minimum_scale"],
                "prediction_correction_minimum_scale",
            )
        if "prediction_correction_ridges" in self.method_parameters:
            values = self.method_parameters["prediction_correction_ridges"]
            if not isinstance(values, list) or not values:
                raise ValueError("prediction_correction_ridges must be nonempty")
            for index, value in enumerate(values):
                _nonnegative_number(value, f"prediction_correction_ridges[{index}]")
        if "prediction_correction_neural_learning_rates" in self.method_parameters:
            values = self.method_parameters[
                "prediction_correction_neural_learning_rates"
            ]
            if not isinstance(values, list) or not values:
                raise ValueError(
                    "prediction_correction_neural_learning_rates must be nonempty"
                )
            for index, value in enumerate(values):
                _positive_number(
                    value,
                    f"prediction_correction_neural_learning_rates[{index}]",
                )
        if "prediction_correction_mse_learning_rate" in self.method_parameters:
            _positive_number(
                self.method_parameters["prediction_correction_mse_learning_rate"],
                "prediction_correction_mse_learning_rate",
            )
        for key in (
            "prediction_correction_mse_epochs",
            "prediction_correction_neural_epochs",
            "prediction_correction_neural_patience",
            "prediction_correction_neural_width",
        ):
            if key in self.method_parameters:
                value = self.method_parameters[key]
                if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                    raise ValueError(f"{key} must be a positive integer")
        if "prediction_correction_neural_depth" in self.method_parameters:
            value = self.method_parameters["prediction_correction_neural_depth"]
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(
                    "prediction_correction_neural_depth must be a nonnegative integer"
                )
        if "prediction_correction_replay_audit_size" in self.method_parameters:
            value = self.method_parameters["prediction_correction_replay_audit_size"]
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(
                    "prediction_correction_replay_audit_size must be a "
                    "nonnegative integer"
                )
        if self.method_parameters.get("parameterization", "raw") not in {
            "raw",
            "normalized",
        }:
            raise ValueError("parameterization must be raw or normalized")
        if self.method_parameters.get("base_method", "mse") not in {
            "mse",
            "wise",
            "spo_plus",
        }:
            raise ValueError("base_method must be mse, wise, or spo_plus")
        if self.method_parameters.get("contraction", "rational") not in {
            "rational",
            "exponential",
            "hyperbolic",
        }:
            raise ValueError("contraction must be rational, exponential, or hyperbolic")
        if self.method == "log_smoothing":
            start = float(self.method_parameters.get("mu_start", 0.3))
            end = float(self.method_parameters.get("mu_end", start))
            if end > start:
                raise ValueError("mu_end must not exceed mu_start")
        if self.method == "log_energy_policy":
            has_alpha = any(
                key in self.method_parameters for key in ("alpha_start", "alpha_end")
            )
            has_mu = any(
                key in self.method_parameters for key in ("mu_start", "mu_end")
            )
            if has_alpha and has_mu:
                raise ValueError("log-energy cannot mix alpha and mu endpoints")
            if has_alpha:
                if "alpha_start" not in self.method_parameters:
                    raise ValueError("alpha_start is required")
                start = float(self.method_parameters["alpha_start"])
                end = float(self.method_parameters.get("alpha_end", start))
                if end > start:
                    raise ValueError("alpha_end must not exceed alpha_start")
            else:
                start = float(self.method_parameters.get("mu_start", 0.3))
                end = float(self.method_parameters.get("mu_end", start))
                if end > start:
                    raise ValueError("mu_end must not exceed mu_start")
            schedule = self.method_parameters.get(
                "schedule", "fixed" if start == end else "geometric"
            )
            if schedule not in {"fixed", "geometric", "arithmetic"}:
                raise ValueError(
                    "log-energy schedule must be fixed, geometric, or arithmetic"
                )
            if schedule == "fixed" and end != start:
                raise ValueError("fixed schedule requires equal endpoints")
            if schedule == "geometric" and (start <= 0.0 or end <= 0.0):
                raise ValueError("geometric schedule requires positive endpoints")
            anneal_fraction = self.method_parameters.get("anneal_fraction", 0.75)
            _positive_number(anneal_fraction, "anneal_fraction")
            if float(anneal_fraction) > 1.0:
                raise ValueError("anneal_fraction must not exceed one")
            if self.method_parameters.get("energy_guard", "uncapped") not in {
                "exact",
                "uncapped",
                "legacy_capped",
            }:
                raise ValueError("unknown log-energy guard mode")
            training_tolerance = float(
                self.method_parameters.get("training_root_tolerance", 1e-6)
            )
            evaluation_tolerance = float(
                self.method_parameters.get("evaluation_root_tolerance", 1e-8)
            )
            if evaluation_tolerance > training_tolerance:
                raise ValueError(
                    "evaluation_root_tolerance must not exceed the training tolerance"
                )
            if self.method_parameters.get("matrix_backend", "auto") not in {
                "auto",
                "dense",
                "sparse",
            }:
                raise ValueError("unknown log-energy matrix backend")
            if self.method_parameters.get("kernel_backend", "numpy") not in {
                "auto",
                "numpy",
                "torch",
            }:
                raise ValueError("unknown log-energy kernel backend")
            if self.method_parameters.get("torch_device", "auto") not in {
                "auto",
                "cpu",
                "cuda",
                "mps",
            }:
                raise ValueError("unknown log-energy Torch device")
            if self.method_parameters.get(
                "kernel_backend", "numpy"
            ) == "numpy" and self.method_parameters.get("torch_device", "auto") not in {
                "auto",
                "cpu",
            }:
                raise ValueError(
                    "torch_device is only meaningful with the Torch kernel"
                )

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> RunSpec:
        permitted = {item.name for item in fields(cls)}
        unknown = set(payload) - permitted
        if unknown:
            raise ValueError(f"unknown RunSpec fields: {sorted(unknown)}")
        converted = dict(payload)
        for key, child in (
            ("sizes", SplitSizes),
            ("law", CostLawSpec),
            ("model", ModelSpec),
            ("training", TrainingSpec),
            ("seeds", SeedSpec),
        ):
            if key in converted:
                if not isinstance(converted[key], dict):
                    raise ValueError(f"{key} must be an object")
                converted[key] = _construct(child, converted[key])
        return cls(**converted)

    @classmethod
    def load(cls, path: Path) -> RunSpec:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("run configuration must be a JSON object")
        return cls.from_dict(payload)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        # Preserve the canonical digest of every legacy local experiment. New
        # adapter fields enter receipts only when they change that experiment.
        if self.benchmark_source == "local":
            payload.pop("benchmark_source")
            payload.pop("conditional_reference_samples")
        if self.cost_coordinate_normalization == "none":
            payload.pop("cost_coordinate_normalization")
        if self.evaluate_test:
            payload.pop("evaluate_test")
        model_payload = payload.get("model")
        if isinstance(model_payload, dict) and self.model.dtype == "float64":
            model_payload.pop("dtype")
        training_payload = payload.get("training")
        if isinstance(training_payload, dict):
            if self.training.learning_rate_schedule == "constant":
                training_payload.pop("learning_rate_schedule")
            if self.training.schedule_reference_epochs is None:
                training_payload.pop("schedule_reference_epochs")
            if self.training.minimum_learning_rate_ratio == 0.1:
                training_payload.pop("minimum_learning_rate_ratio")
            if self.training.warmup_fraction == 0.0:
                training_payload.pop("warmup_fraction")
            if self.training.validation_epochs is None:
                training_payload.pop("validation_epochs")
            if self.training.gradient_diagnostic_interval == 1:
                training_payload.pop("gradient_diagnostic_interval")
        return payload
