"""Stable, named pseudo-random streams.

The implementation never relies on Python's process-randomized ``hash``.  A
run can therefore regenerate data exactly from its compact seed receipt.
"""

from __future__ import annotations

import hashlib

import numpy as np


def derive_seed(master_seed: int, *labels: object) -> int:
    if master_seed < 0:
        raise ValueError("master_seed must be nonnegative")
    payload = "|".join([str(master_seed), *(str(label) for label in labels)])
    digest = hashlib.sha256(payload.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "little") % (2**32 - 1)


def rng(master_seed: int, *labels: object) -> np.random.Generator:
    return np.random.Generator(np.random.PCG64(derive_seed(master_seed, *labels)))
