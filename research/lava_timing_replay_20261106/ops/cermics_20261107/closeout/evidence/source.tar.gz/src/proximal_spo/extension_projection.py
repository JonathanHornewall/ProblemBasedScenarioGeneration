"""Bound QP-layer working memory without changing the optimizer batch."""

from dataclasses import fields, replace

import numpy as np

from proximal_spo.objectives import BatchSignal, Deployment, DirectProjectionObjective
from proximal_spo.oracles import OracleStats


class ChunkedDirectProjectionObjective(DirectProjectionObjective):
    projection_chunk_size = 32

    def signal(self, outputs, batch):
        pieces = []
        for start in range(0, len(outputs), self.projection_chunk_size):
            stop = start + self.projection_chunk_size
            subset = replace(
                batch,
                **{
                    field.name: getattr(batch, field.name)[start:stop]
                    for field in fields(batch)
                    if getattr(batch, field.name) is not None
                },
            )
            # Finish each independent QP VJP before freeing its native factors.
            pieces.append(super().signal(outputs[start:stop], subset))
        return BatchSignal(
            values=np.concatenate([p.values for p in pieces]),
            output_gradient=np.concatenate([p.output_gradient for p in pieces]),
            stats=sum((p.stats for p in pieces), OracleStats()),
            decisions=np.concatenate([p.decisions for p in pieces]),
        )

    def deploy(self, outputs):
        pieces = [
            super(ChunkedDirectProjectionObjective, self).deploy(
                outputs[start : start + self.projection_chunk_size]
            )
            for start in range(0, len(outputs), self.projection_chunk_size)
        ]
        return Deployment(
            np.concatenate([p.decisions for p in pieces]),
            None,
            sum((p.stats for p in pieces), OracleStats()),
        )

    def receipt(self):
        return {
            **super().receipt(),
            "projection_chunk_size": self.projection_chunk_size,
            "optimizer_batch_unchanged": True,
        }
