"""Receipt-derived benchmark provenance for the publication campaign."""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

from .experiment_identity import (
    benchmark_family_id,
    experimental_route_id,
    physical_dataset_id,
)


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object at {path}")
    return payload


def _local_problem_class(benchmark_id: str) -> str:
    if "binary_knapsack" in benchmark_id or benchmark_id.endswith("_mip"):
        return "milp"
    return "lp"


def _reference_contract(
    provenance: Mapping[str, Any], *, source: str
) -> dict[str, Any]:
    if source == "local":
        return {
            "kind": "exact_analytic",
            "estimators": ["analytic conditional mean stored by local generator"],
            "samples_per_context": 0,
        }
    conditional = provenance.get("conditional_reference")
    if not isinstance(conditional, Mapping):
        raise ValueError("external benchmark lacks conditional-reference provenance")
    splits = conditional.get("splits")
    if not isinstance(splits, list) or not splits:
        raise ValueError("external conditional-reference receipt has no splits")
    estimators = sorted(
        {
            str(split.get("estimator"))
            for split in splits
            if isinstance(split, Mapping)
        }
    )
    samples = {
        int(split.get("samples_per_context", 0))
        for split in splits
        if isinstance(split, Mapping)
    }
    if len(samples) != 1:
        raise ValueError("conditional-reference sample count differs across splits")
    samples_per_context = samples.pop()
    return {
        "kind": "monte_carlo" if samples_per_context > 0 else "exact",
        "estimators": estimators,
        "samples_per_context": samples_per_context,
    }


def _stable_contract(config: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "benchmark_id": config.get("benchmark_id"),
        "benchmark_source": config.get("benchmark_source", "local"),
        "interface": config.get("interface", "partial"),
        "law": config.get("law", {}),
        "sizes": config.get("sizes", {}),
        "conditional_reference_samples": config.get(
            "conditional_reference_samples"
        ),
        "cost_coordinate_normalization": config.get(
            "cost_coordinate_normalization"
        ),
    }


def collect_benchmark_provenance(
    panel_roots: Mapping[str, Iterable[Path]],
) -> dict[str, Any]:
    """Collect route provenance from the sealed confirmation run directories."""

    route_runs: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    resolved_roots: dict[str, list[str]] = {}
    for panel, raw_roots in sorted(panel_roots.items()):
        roots = [Path(root).resolve() for root in raw_roots]
        resolved_roots[panel] = [str(root) for root in roots]
        for root in roots:
            if not root.is_dir():
                raise FileNotFoundError(root)
            for directory in sorted(path for path in root.iterdir() if path.is_dir()):
                required = {
                    name: directory / f"{name}.json"
                    for name in ("status", "config", "environment")
                }
                diagnostics_path = directory / "data_diagnostics.json"
                if not all(path.is_file() for path in required.values()):
                    continue
                status = _object(required["status"])
                if status.get("status") != "complete":
                    continue
                if not diagnostics_path.is_file():
                    raise ValueError(
                        f"complete run lacks data diagnostics: {directory}"
                    )
                config = _object(required["config"])
                environment = _object(required["environment"])
                diagnostics = _object(diagnostics_path)
                if environment.get("git_dirty") is not False:
                    raise ValueError(f"provenance run is dirty: {directory}")
                route = experimental_route_id(config)
                route_runs[(panel, route)].append(
                    {
                        "config": config,
                        "environment": environment,
                        "diagnostics": diagnostics,
                        "directory": str(directory),
                    }
                )
    if not route_runs:
        raise ValueError("no completed confirmation runs found")

    routes: list[dict[str, Any]] = []
    for (panel, route), runs in sorted(route_runs.items()):
        contracts = {
            json.dumps(
                _stable_contract(run["config"]),
                sort_keys=True,
                separators=(",", ":"),
            )
            for run in runs
        }
        if len(contracts) != 1:
            raise ValueError(f"benchmark contract differs across runs: {panel}/{route}")
        config = runs[0]["config"]
        contract = _stable_contract(config)
        benchmark_id = contract["benchmark_id"]
        if not isinstance(benchmark_id, str):
            raise ValueError(f"route lacks benchmark id: {panel}/{route}")
        source = str(contract["benchmark_source"] or "local")
        provenance_objects = [
            run["diagnostics"].get("benchmark_provenance") for run in runs
        ]
        if any(not isinstance(item, Mapping) for item in provenance_objects):
            raise ValueError(f"route lacks benchmark provenance: {panel}/{route}")
        provenance = provenance_objects[0]
        assert isinstance(provenance, Mapping)
        spec = provenance.get("benchmark_spec", {})
        factory = provenance.get("factory", {})
        if not isinstance(spec, Mapping) or not isinstance(factory, Mapping):
            raise ValueError(f"invalid external provenance: {panel}/{route}")
        source_metadata = spec.get("source", {})
        if not isinstance(source_metadata, Mapping):
            source_metadata = {}
        prefix = provenance.get("canonical_source_prefix", {})
        if not isinstance(prefix, Mapping):
            prefix = {}
        methods = sorted({str(run["config"].get("method")) for run in runs})
        method_seed_counts = Counter(
            str(run["config"].get("method")) for run in runs
        )
        data_seeds = {
            int(run["config"]["seeds"]["data"])
            for run in runs
            if isinstance(run["config"].get("seeds"), Mapping)
        }
        initialization_seeds = {
            int(run["config"]["seeds"]["initialization"])
            for run in runs
            if isinstance(run["config"].get("seeds"), Mapping)
        }
        fixed_dataset = len(data_seeds) == 1 and len(initialization_seeds) > 1
        relaxation_methods = sorted(
            {
                str(run["config"].get("method"))
                for run in runs
                if isinstance(
                    run["diagnostics"].get("relaxation_trained_hard_deployment"),
                    Mapping,
                )
                and run["diagnostics"]["relaxation_trained_hard_deployment"].get(
                    "active"
                )
                is True
            }
        )
        sizes = contract["sizes"]
        if not isinstance(sizes, Mapping):
            raise ValueError(f"route lacks split sizes: {panel}/{route}")
        reference = _reference_contract(provenance, source=source)
        problem_class = (
            str(spec.get("problem_class"))
            if source != "local"
            else _local_problem_class(benchmark_id)
        )
        routes.append(
            {
                "panel": panel,
                "route_id": route,
                "physical_dataset_id": physical_dataset_id(config),
                "family_id": benchmark_family_id(config),
                "benchmark_id": benchmark_id,
                "problem_class": problem_class,
                "benchmark_source": source,
                "execution_relationship": (
                    "project-native synthetic geometry and analytic data law"
                    if source == "local"
                    else str(source_metadata.get("relationship", "unspecified"))
                ),
                "citation": (
                    "project-native benchmark"
                    if source == "local"
                    else str(source_metadata.get("citation", "unspecified"))
                ),
                "source_url": (
                    None if source == "local" else source_metadata.get("url")
                ),
                "data_fidelity": (
                    "project_native"
                    if source == "local"
                    else factory.get("data_fidelity")
                ),
                "oracle_fidelity": (
                    "exact project formulation"
                    if source == "local"
                    else factory.get("oracle_fidelity")
                ),
                "known_deviations": (
                    [] if source == "local" else factory.get("known_deviations", [])
                ),
                "split_sizes": {
                    key: int(sizes[key]) for key in ("train", "validation", "test")
                },
                "conditional_reference": reference,
                "cost_coordinate_normalization": contract[
                    "cost_coordinate_normalization"
                ],
                "interface": contract["interface"],
                "method_count": len(methods),
                "methods": methods,
                "method_run_counts": dict(sorted(method_seed_counts.items())),
                "data_seed_count": len(data_seeds),
                "initialization_seed_count": len(initialization_seeds),
                "fixed_dataset_across_confirmation_seeds": fixed_dataset,
                "canonical_source_prefix": dict(prefix),
                "relaxation_trained_hard_deployment_methods": relaxation_methods,
                "external_adapter_git_sha": provenance.get("git_sha"),
                "external_adapter_git_dirty": provenance.get("git_dirty"),
                "run_source_sha256_values": sorted(
                    {
                        str(run["environment"].get("source_sha256"))
                        for run in runs
                    }
                ),
            }
        )

    panel_summaries = []
    for panel in sorted(panel_roots):
        panel_routes = [row for row in routes if row["panel"] == panel]
        reference_counts = Counter(
            str(row["conditional_reference"]["kind"]) for row in panel_routes
        )
        panel_summaries.append(
            {
                "panel": panel,
                "route_count": len(panel_routes),
                "native_benchmark_count": len(
                    {str(row["benchmark_id"]) for row in panel_routes}
                ),
                "family_count": len({str(row["family_id"]) for row in panel_routes}),
                "external_route_count": sum(
                    row["benchmark_source"] == "dfl_extensions_lab"
                    for row in panel_routes
                ),
                "project_native_route_count": sum(
                    row["benchmark_source"] == "local" for row in panel_routes
                ),
                "fixed_dataset_route_count": sum(
                    bool(row["fixed_dataset_across_confirmation_seeds"])
                    for row in panel_routes
                ),
                "reference_kind_counts": dict(sorted(reference_counts.items())),
                "external_adapter_git_sha_values": sorted(
                    {
                        str(row["external_adapter_git_sha"])
                        for row in panel_routes
                        if row["external_adapter_git_sha"] is not None
                    }
                ),
                "external_adapter_git_dirty_values": sorted(
                    {
                        bool(row["external_adapter_git_dirty"])
                        for row in panel_routes
                        if row["external_adapter_git_dirty"] is not None
                    }
                ),
                "run_source_sha256_values": sorted(
                    {
                        str(source)
                        for row in panel_routes
                        for source in row["run_source_sha256_values"]
                    }
                ),
            }
        )

    source_groups: dict[tuple[str, str, str], dict[str, Any]] = {}
    for route_record in routes:
        key = (
            str(route_record["citation"]),
            str(route_record["execution_relationship"]),
            str(route_record["data_fidelity"]),
        )
        group = source_groups.setdefault(
            key,
            {
                "citation": route_record["citation"],
                "source_url": route_record["source_url"],
                "execution_relationship": route_record["execution_relationship"],
                "data_fidelity": route_record["data_fidelity"],
                "route_ids": [],
                "known_deviations": set(),
            },
        )
        group["route_ids"].append(route_record["route_id"])
        group["known_deviations"].update(route_record["known_deviations"])
    compact_source_groups = []
    for group in source_groups.values():
        compact_source_groups.append(
            {
                **{
                    key: value
                    for key, value in group.items()
                    if key != "known_deviations"
                },
                "route_count": len(group["route_ids"]),
                "route_ids": sorted(group["route_ids"]),
                "known_deviations": sorted(group["known_deviations"]),
            }
        )
    return {
        "status": "receipt_derived_benchmark_provenance",
        "panels": panel_summaries,
        "routes": routes,
        "source_groups": sorted(
            compact_source_groups,
            key=lambda row: (
                str(row["citation"]),
                str(row["execution_relationship"]),
                str(row["data_fidelity"]),
            ),
        ),
        "run_roots": resolved_roots,
        "global_disclosures": [
            (
                "All neural reports, including MSE, WISE, SFGE perturbations, "
                "and direct-policy coordinates, use standardized random-cost "
                "coordinates. WISE and SFGE are therefore faithful to their "
                "declared standardized metric, not raw-coordinate invariant."
            ),
            (
                "Local routes are project-native source-inspired synthetic "
                "benchmarks; they are not claimed as bit-for-bit literature "
                "reproductions. External routes use the pinned DFL Extensions "
                "Lab adapter and retain its source relationship and deviation "
                "receipts."
            ),
            (
                "On integer routes, the target, SPO+, and SFGE decision-focused "
                "updates use continuous relaxations when their recorded method "
                "contract says so, followed by exact hard MIP deployment."
            ),
            (
                "A fixed-dataset route has one data seed but multiple "
                "initialization/shuffle seeds. Its ten confirmations quantify "
                "optimization randomness conditional on one maintained source "
                "dataset, not ten independent dataset draws."
            ),
        ],
    }


def render_benchmark_provenance_markdown(summary: Mapping[str, Any]) -> str:
    """Render a compact benchmark and source-fidelity disclosure."""

    lines = [
        "# Publication benchmark provenance",
        "",
        "This report is generated from the sealed confirmation run configs,",
        "environment receipts, and data diagnostics. It distinguishes benchmark",
        "registry coverage from source fidelity and reference-policy precision.",
        "",
        "## Panel audit",
        "",
        (
            "| Panel | Routes | Native benchmarks | Families | External | "
            "Project-native | Fixed dataset | Reference kinds |"
        ),
        "|---|---:|---:|---:|---:|---:|---:|---|",
    ]
    for panel in summary["panels"]:
        kinds = ", ".join(
            f"{key}: {value}"
            for key, value in panel["reference_kind_counts"].items()
        )
        lines.append(
            f"| {panel['panel']} | {panel['route_count']} | "
            f"{panel['native_benchmark_count']} | {panel['family_count']} | "
            f"{panel['external_route_count']} | "
            f"{panel['project_native_route_count']} | "
            f"{panel['fixed_dataset_route_count']} | {kinds} |"
        )
    lines.extend(["", "## Interpretation rules", ""])
    lines.extend(f"- {item}" for item in summary["global_disclosures"])
    lines.extend(
        [
            "",
            "## Executable and adapter snapshots",
            "",
            "| Panel | Run source SHA-256 | External adapter commit | Dirty |",
            "|---|---|---|---|",
        ]
    )
    for panel in summary["panels"]:
        sources = ", ".join(panel["run_source_sha256_values"]) or "n/a"
        adapters = ", ".join(panel["external_adapter_git_sha_values"]) or "n/a"
        dirty = (
            ", ".join(
                str(value).lower()
                for value in panel["external_adapter_git_dirty_values"]
            )
            or "n/a"
        )
        lines.append(
            f"| {panel['panel']} | `{sources}` | `{adapters}` | {dirty} |"
        )
    lines.extend(
        [
            "",
            "## Route-level execution and reference contract",
            "",
            (
                "| Panel | Route | Family | Class | Source / fidelity | Split "
                "(train/val/test) | Reference | Fixed data | Relaxation-trained "
                "DFL methods |"
            ),
            "|---|---|---|---|---|---:|---|---:|---|",
        ]
    )
    for route in summary["routes"]:
        sizes = route["split_sizes"]
        reference = route["conditional_reference"]
        reference_label = str(reference["kind"])
        if int(reference["samples_per_context"]) > 0:
            reference_label += f" ({reference['samples_per_context']}/context)"
        source = f"{route['benchmark_source']} / {route['data_fidelity']}"
        relaxation = ", ".join(
            route["relaxation_trained_hard_deployment_methods"]
        ) or "none"
        lines.append(
            f"| {route['panel']} | {route['route_id']} | {route['family_id']} | "
            f"{route['problem_class']} | {source} | "
            f"{sizes['train']}/{sizes['validation']}/{sizes['test']} | "
            f"{reference_label} | "
            f"{'yes' if route['fixed_dataset_across_confirmation_seeds'] else 'no'} | "
            f"{relaxation} |"
        )
    lines.extend(
        [
            "",
            "## Source relationship groups",
            "",
            "| Citation/source | Routes | Fidelity | Execution relationship |",
            "|---|---:|---|---|",
        ]
    )
    for group in summary["source_groups"]:
        citation = str(group["citation"])
        if group.get("source_url"):
            citation = f"[{citation}]({group['source_url']})"
        lines.append(
            f"| {citation} | {group['route_count']} | {group['data_fidelity']} | "
            f"{group['execution_relationship']} |"
        )
    lines.extend(["", "### Recorded source deviations", ""])
    for group in summary["source_groups"]:
        if not group["known_deviations"]:
            continue
        deviations = "; ".join(str(item) for item in group["known_deviations"])
        lines.append(
            f"- **{group['citation']} ({group['data_fidelity']}):** {deviations}."
        )
    lines.extend(
        [
            "",
            "## Evidence boundary",
            "",
            (
                "- An exact conditional-mean reference certifies the target "
                "objective for the generated law; it does not make a clean-room "
                "benchmark a bit-for-bit source reproduction."
            ),
            (
                "- Monte Carlo references use independent conditional-cost draws "
                "at the recorded count. The integer panel remains provisional "
                "until its rankings are stable to higher-precision references."
            ),
            (
                "- Source URLs and relationships are inherited from the pinned "
                "benchmark registry receipts; no new source-fidelity claim is "
                "introduced by this report."
            ),
            "",
        ]
    )
    return "\n".join(lines)
