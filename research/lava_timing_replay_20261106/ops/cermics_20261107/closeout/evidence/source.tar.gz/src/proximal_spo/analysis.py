"""Validation-only model selection over compact experiment receipts."""

from __future__ import annotations

import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any

from scipy.stats import t as student_t

_SEED_FIELDS = (
    "structural",
    "data",
    "initialization",
    "shuffle",
    "perturbation",
)


def _seed_key(row: dict[str, Any]) -> tuple[object, ...]:
    seeds = row["seeds"]
    if not isinstance(seeds, dict):
        raise ValueError("candidate lacks a seed object")
    return tuple(seeds.get(field) for field in _SEED_FIELDS)


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected a JSON object at {path}")
    return payload


def _number(value: object, *, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field} must be numeric")
    return float(value)


def _standard_error(values: list[float]) -> float:
    if len(values) <= 1:
        return 0.0
    mean = sum(values) / len(values)
    variance = sum((value - mean) ** 2 for value in values) / (len(values) - 1)
    return math.sqrt(variance / len(values))


def _student_t_interval(values: list[float]) -> tuple[float, float]:
    mean = sum(values) / len(values)
    if len(values) <= 1:
        return mean, mean
    radius = float(student_t.ppf(0.975, len(values) - 1)) * _standard_error(values)
    return mean - radius, mean + radius


def _arm_identity(config: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    """Return a seed- and name-independent hyperparameter-arm identity."""

    arm = {key: value for key, value in config.items() if key not in {"name", "seeds"}}
    serialized = json.dumps(arm, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest(), arm


def _gradient_summary(path: Path) -> dict[str, float | int] | None:
    """Return a compact audit receipt for an epoch-wise gradient curve."""

    if not path.is_file():
        return None
    mean_output: list[float] = []
    maximum_output: list[float] = []
    clipped_rates: list[float] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        record = json.loads(line)
        if not isinstance(record, dict):
            raise ValueError(f"malformed curve row in {path}")
        mean_value = record.get("mean_output_gradient_norm")
        maximum_value = record.get("maximum_output_gradient_norm")
        clipped_value = record.get("gradient_clipped_batch_rate")
        if isinstance(mean_value, (int, float)) and not isinstance(mean_value, bool):
            mean_output.append(float(mean_value))
        if isinstance(maximum_value, (int, float)) and not isinstance(
            maximum_value, bool
        ):
            maximum_output.append(float(maximum_value))
        if isinstance(clipped_value, (int, float)) and not isinstance(
            clipped_value, bool
        ):
            clipped_rates.append(float(clipped_value))
    if not mean_output:
        return None
    return {
        "epoch_count": len(mean_output),
        "first_mean_output_gradient_norm": mean_output[0],
        "last_mean_output_gradient_norm": mean_output[-1],
        "mean_output_gradient_norm": sum(mean_output) / len(mean_output),
        "minimum_mean_output_gradient_norm": min(mean_output),
        "maximum_mean_output_gradient_norm": max(mean_output),
        "maximum_output_gradient_norm": (
            max(maximum_output) if maximum_output else max(mean_output)
        ),
        "mean_gradient_clipped_batch_rate": (
            sum(clipped_rates) / len(clipped_rates) if clipped_rates else 0.0
        ),
    }


def summarize_validation_selection(
    run_root: Path, *, source_sha256: str | None = None
) -> dict[str, Any]:
    """Select one shared hyperparameter arm per method across paired seeds.

    Selection uses validation regret only.  Although each pilot receipt already
    contains its test metric, the summary ranks arms before attaching test
    values to the selected output, preventing this utility from silently
    selecting on the test split.
    """

    candidates: list[dict[str, Any]] = []
    for directory in sorted(path for path in run_root.iterdir() if path.is_dir()):
        required = [
            directory / "status.json",
            directory / "config.json",
            directory / "environment.json",
            directory / "summary.json",
        ]
        if not all(path.is_file() for path in required):
            continue
        status, config, environment, summary = map(_object, required)
        if status.get("status") != "complete" or summary.get("test") is None:
            continue
        seeds = config.get("seeds")
        validation = summary.get("best_validation")
        test = summary.get("test")
        if not all(isinstance(value, dict) for value in (seeds, validation, test)):
            raise ValueError(f"malformed completed receipt in {directory}")
        assert isinstance(seeds, dict)
        assert isinstance(validation, dict)
        assert isinstance(test, dict)
        validation_normalized = validation.get(
            "normalized_mean_regret", validation.get("mean_regret")
        )
        test_normalized = test.get(
            "normalized_mean_regret", test.get("mean_regret")
        )
        source = environment.get("source_sha256")
        if not isinstance(source, str) or len(source) != 64:
            # Legacy exploratory receipts predate executable-source hashing.
            # They may coexist with a later source-bound rerun in the same
            # append-only campaign directory.  An explicit digest selects the
            # auditable rerun and deliberately ignores those legacy records;
            # without an explicit digest we continue to fail closed.
            if source_sha256 is not None:
                continue
            raise ValueError(f"malformed source digest in {directory}")
        if source_sha256 is not None and source != source_sha256:
            continue
        arm_sha256, arm = _arm_identity(config)
        candidates.append(
            {
                "run_directory": str(directory),
                "name": config.get("name"),
                "benchmark_id": config.get("benchmark_id"),
                "interface": config.get("interface"),
                "method": config.get("method"),
                "seeds": seeds,
                "arm_sha256": arm_sha256,
                "arm": arm,
                "source_sha256": source,
                "best_epoch": summary.get("best_epoch"),
                "validation_mean_regret": float(validation["mean_regret"]),
                "validation_normalized_mean_regret": _number(
                    validation_normalized,
                    field="validation normalized mean regret",
                ),
                "test_mean_regret": float(test["mean_regret"]),
                "test_normalized_mean_regret": _number(
                    test_normalized,
                    field="test normalized mean regret",
                ),
                "training_wall_seconds": float(summary["training_wall_seconds"]),
                "training_oracle_stats": summary.get("total_training_oracle_stats"),
                "status": "complete",
                "gradient_summary": _gradient_summary(
                    directory / "learning_curve.jsonl"
                ),
            }
        )
    if not candidates:
        raise ValueError(f"no completed runs found below {run_root}")

    sources = {str(row["source_sha256"]) for row in candidates}
    if len(sources) != 1:
        raise ValueError(
            "campaign receipts contain multiple executable source hashes; "
            "pass source_sha256 explicitly instead of mixing implementations"
        )

    study_arms: dict[tuple[Any, Any, Any], dict[str, list[dict[str, Any]]]] = (
        defaultdict(lambda: defaultdict(list))
    )
    for row in candidates:
        study = (row["benchmark_id"], row["interface"], row["method"])
        study_arms[study][str(row["arm_sha256"])].append(row)

    selected: list[dict[str, Any]] = []
    selected_arm_receipts: list[dict[str, Any]] = []
    study_seed_sets: dict[tuple[Any, Any, Any], set[tuple[object, ...]]] = {}
    for study, arms in sorted(study_arms.items()):
        seed_sets: list[set[tuple[object, ...]]] = []
        for rows in arms.values():
            keys = [_seed_key(row) for row in rows]
            if len(keys) != len(set(keys)):
                raise ValueError(f"duplicate arm x seed receipt for study {study}")
            seed_sets.append(set(keys))
        if any(seeds != seed_sets[0] for seeds in seed_sets[1:]):
            raise ValueError(
                f"incomplete hyperparameter arm across paired seeds for study {study}"
            )
        study_seed_sets[study] = seed_sets[0]
        ranked = sorted(
            arms.items(),
            key=lambda item: (
                sum(float(row["validation_mean_regret"]) for row in item[1])
                / len(item[1]),
                item[0],
            ),
        )
        winning_sha, winning_rows = ranked[0]
        selected.extend(sorted(winning_rows, key=lambda row: str(row["name"])))
        selected_arm_receipts.append(
            {
                "benchmark_id": study[0],
                "interface": study[1],
                "method": study[2],
                "arm_sha256": winning_sha,
                "arm": winning_rows[0]["arm"],
                "mean_validation_regret": sum(
                    float(row["validation_mean_regret"]) for row in winning_rows
                )
                / len(winning_rows),
                "candidate_arm_count": len(arms),
            }
        )
    comparison_seed_sets: dict[tuple[Any, Any], list[set[tuple[object, ...]]]] = (
        defaultdict(list)
    )
    for (benchmark_id, interface, _method), seeds in study_seed_sets.items():
        comparison_seed_sets[(benchmark_id, interface)].append(seeds)
    for comparison, seed_sets in comparison_seed_sets.items():
        if any(seeds != seed_sets[0] for seeds in seed_sets[1:]):
            raise ValueError(
                "methods do not share all five paired seed streams for "
                f"benchmark/interface {comparison}"
            )
    aggregate_rows: dict[tuple[object, ...], list[dict[str, Any]]] = defaultdict(list)
    for row in selected:
        aggregate_rows[(row["benchmark_id"], row["interface"], row["method"])].append(
            row
        )
    aggregates: list[dict[str, Any]] = []
    for (benchmark_id, interface, method), rows in sorted(aggregate_rows.items()):
        regrets = [float(row["test_mean_regret"]) for row in rows]
        normalized_regrets = [
            float(row["test_normalized_mean_regret"]) for row in rows
        ]
        aggregates.append(
            {
                "benchmark_id": benchmark_id,
                "interface": interface,
                "method": method,
                "seed_count": len(rows),
                "mean_test_regret": sum(regrets) / len(regrets),
                "standard_error_test_regret": _standard_error(regrets),
                "mean_normalized_test_regret": sum(normalized_regrets)
                / len(normalized_regrets),
                "standard_error_normalized_test_regret": _standard_error(
                    normalized_regrets
                ),
                "selected_names": [row["name"] for row in rows],
            }
        )
    return {
        "selection_rule": (
            "one shared hyperparameter arm per benchmark x interface x method, "
            "minimizing mean validation regret across paired seeds"
        ),
        "run_root": str(run_root),
        "source_sha256": next(iter(sources)),
        "selected_arms": selected_arm_receipts,
        "selected": selected,
        "aggregates": aggregates,
        "candidate_rows": sorted(candidates, key=lambda row: str(row["name"])),
    }


def summarize_exact_head_selection(
    run_root: Path, *, source_sha256: str | None = None
) -> dict[str, Any]:
    """Select a post-Adam exact head by validation regret across paired seeds.

    The Adam checkpoint is chosen inside each run by its own validation path;
    this second level compares only ``exact_head.json`` validation metrics and
    never ranks candidates by their stored test metrics.
    """

    candidates: list[dict[str, Any]] = []
    for directory in sorted(path for path in run_root.iterdir() if path.is_dir()):
        required = [
            directory / "status.json",
            directory / "config.json",
            directory / "environment.json",
            directory / "exact_head.json",
            directory / "summary.json",
        ]
        if not all(path.is_file() for path in required):
            continue
        status, config, environment, exact, summary = map(_object, required)
        if status.get("status") != "complete":
            continue
        validation = exact.get("validation")
        test = exact.get("test")
        seeds = config.get("seeds")
        if not all(isinstance(value, dict) for value in (validation, test, seeds)):
            raise ValueError(f"malformed exact-head receipt in {directory}")
        assert isinstance(validation, dict)
        assert isinstance(test, dict)
        assert isinstance(seeds, dict)
        source = environment.get("source_sha256")
        if not isinstance(source, str) or len(source) != 64:
            raise ValueError(f"malformed source digest in {directory}")
        if source_sha256 is not None and source != source_sha256:
            continue
        arm_sha256, arm = _arm_identity(config)
        candidates.append(
            {
                "run_directory": str(directory),
                "name": config.get("name"),
                "method": "post_adam_exact_proximal",
                "seeds": seeds,
                "arm_sha256": arm_sha256,
                "arm": arm,
                "source_sha256": source,
                "training_tau": exact.get("training_tau"),
                "head_tau": exact.get("head_tau"),
                "validation_mean_regret": float(validation["mean_regret"]),
                "test_mean_regret": float(test["mean_regret"]),
                "training_wall_seconds": float(
                    summary["whole_pipeline_training_wall_seconds"]
                ),
                "training_oracle_stats": summary.get(
                    "whole_pipeline_training_oracle_stats"
                ),
                "status": "complete",
                "gradient_summary": _gradient_summary(
                    directory / "learning_curve.jsonl"
                ),
            }
        )
    if not candidates:
        raise ValueError(f"no completed exact-head runs found below {run_root}")
    sources = {str(row["source_sha256"]) for row in candidates}
    if len(sources) != 1:
        raise ValueError(
            "exact-head receipts contain multiple executable source hashes; "
            "pass source_sha256 explicitly"
        )
    arms: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in candidates:
        arms[str(row["arm_sha256"])].append(row)
    seed_sets: list[set[tuple[object, ...]]] = []
    for rows in arms.values():
        keys = [_seed_key(row) for row in rows]
        if len(keys) != len(set(keys)):
            raise ValueError("duplicate exact-head arm x seed receipt")
        seed_sets.append(set(keys))
    if any(seeds != seed_sets[0] for seeds in seed_sets[1:]):
        raise ValueError("incomplete exact-head arm across paired seeds")
    ranked = sorted(
        arms.items(),
        key=lambda item: (
            sum(float(row["validation_mean_regret"]) for row in item[1]) / len(item[1]),
            item[0],
        ),
    )
    winning_sha, winning_rows = ranked[0]
    regrets = [float(row["test_mean_regret"]) for row in winning_rows]
    return {
        "selection_rule": (
            "one post-Adam exact-head arm minimizing mean validation regret "
            "across all five paired seed streams"
        ),
        "run_root": str(run_root),
        "source_sha256": next(iter(sources)),
        "selected_arm": {
            "method": "post_adam_exact_proximal",
            "arm_sha256": winning_sha,
            "arm": winning_rows[0]["arm"],
            "mean_validation_regret": sum(
                float(row["validation_mean_regret"]) for row in winning_rows
            )
            / len(winning_rows),
            "candidate_arm_count": len(arms),
        },
        "selected": sorted(winning_rows, key=lambda row: str(row["name"])),
        "candidate_rows": sorted(candidates, key=lambda row: str(row["name"])),
        "aggregate": {
            "method": "post_adam_exact_proximal",
            "seed_count": len(winning_rows),
            "mean_test_regret": sum(regrets) / len(regrets),
            "standard_error_test_regret": _standard_error(regrets),
        },
    }


def _confirmation_label(config: dict[str, Any]) -> str:
    method = str(config.get("method"))
    parameters = config.get("method_parameters")
    if not isinstance(parameters, dict):
        raise ValueError("confirmation config lacks method_parameters")
    if method == "proximal" and parameters.get("exact_head") is True:
        if parameters.get("exact_head_center_on_adam") is True:
            return "post_adam_centered_exact_proximal"
        return "post_adam_exact_proximal"
    return method


def summarize_confirmation(
    run_root: Path,
    *,
    source_sha256: str | None = None,
    source_sha256_by_label: dict[str, str] | None = None,
    expected_data_seeds: set[int] | None = None,
    expected_labels: set[str] | None = None,
    censored_labels: set[str] | None = None,
) -> dict[str, Any]:
    """Summarize frozen confirmation arms without doing model selection.

    A label may be declared censored when its frozen numerical certificate can
    fail.  Every planned label-by-seed attempt must still be present; failures
    are reported rather than deleted.  Per-label source digests allow a single
    pre-specified method to be rerun after an implementation-preserving tuning
    repair without silently mixing duplicate receipts.
    """

    if source_sha256 is not None and source_sha256_by_label is not None:
        raise ValueError(
            "pass either source_sha256 or source_sha256_by_label, not both"
        )
    censored = censored_labels or set()
    if expected_labels is not None and not censored <= expected_labels:
        raise ValueError("censored labels must belong to expected_labels")

    rows: list[dict[str, Any]] = []
    attempts: list[dict[str, Any]] = []
    for directory in sorted(path for path in run_root.iterdir() if path.is_dir()):
        common = [
            directory / "status.json",
            directory / "config.json",
            directory / "environment.json",
        ]
        if not all(path.is_file() for path in common):
            continue
        status, config, environment = map(_object, common)
        label = _confirmation_label(config)
        if expected_labels is not None and label not in expected_labels:
            continue
        source = environment.get("source_sha256")
        if not isinstance(source, str) or len(source) != 64:
            raise ValueError(f"malformed source digest in {directory}")
        expected_source = source_sha256
        if source_sha256_by_label is not None:
            expected_source = source_sha256_by_label.get(label)
            if expected_source is None:
                raise ValueError(f"no source digest declared for label {label}")
        if expected_source is not None and source != expected_source:
            continue
        seeds = config.get("seeds")
        if not isinstance(seeds, dict):
            raise ValueError(f"malformed seed receipt in {directory}")
        data_seed = seeds.get("data")
        if isinstance(data_seed, bool) or not isinstance(data_seed, int):
            raise ValueError(f"invalid confirmation data seed in {directory}")
        arm_sha256, arm = _arm_identity(config)
        attempt = {
            "label": label,
            "run_directory": str(directory),
            "source_sha256": source,
            "data_seed": data_seed,
            "seeds": seeds,
            "arm_sha256": arm_sha256,
            "arm": arm,
            "status": status.get("status"),
            "error_type": status.get("error_type"),
            "error": status.get("error"),
            "failed_at_utc": status.get("failed_at_utc"),
        }
        attempts.append(attempt)
        if status.get("status") != "complete":
            continue
        summary_path = directory / "summary.json"
        if not summary_path.is_file():
            raise ValueError(f"completed run lacks summary in {directory}")
        summary = _object(summary_path)
        test = summary.get("test")
        stats = summary.get("whole_pipeline_training_oracle_stats")
        if not isinstance(test, dict) or not isinstance(stats, dict):
            raise ValueError(f"malformed confirmation receipt in {directory}")
        embedded_base_path = directory / "embedded_mse_base.json"
        embedded_base = (
            _object(embedded_base_path) if embedded_base_path.is_file() else None
        )
        if embedded_base is not None:
            base_test = embedded_base.get("test")
            base_validation = embedded_base.get("validation")
            base_digest = embedded_base.get("parameter_sha256")
            if (
                not isinstance(base_test, dict)
                or not isinstance(base_validation, dict)
                or not isinstance(base_digest, str)
                or len(base_digest) != 64
            ):
                raise ValueError(f"malformed embedded MSE base in {directory}")
        rows.append(
            {
                "label": label,
                "name": config.get("name"),
                "run_directory": str(directory),
                "source_sha256": source,
                "data_seed": data_seed,
                "seeds": seeds,
                "arm_sha256": arm_sha256,
                "arm": arm,
                "parameter_sha256": summary.get("parameter_sha256"),
                "test_mean_regret": float(test["mean_regret"]),
                "test_normalized_mean_regret": float(test["normalized_mean_regret"]),
                "test_positive_regret_rate": float(test["positive_regret_rate"]),
                "whole_pipeline_training_wall_seconds": float(
                    summary["whole_pipeline_training_wall_seconds"]
                ),
                "whole_pipeline_training_oracle_calls": int(stats["calls"]),
                "embedded_mse_base_parameter_sha256": (
                    None if embedded_base is None else embedded_base["parameter_sha256"]
                ),
                "embedded_mse_base_validation_regret": (
                    None
                    if embedded_base is None
                    else float(embedded_base["validation"]["mean_regret"])
                ),
                "embedded_mse_base_test_regret": (
                    None
                    if embedded_base is None
                    else float(embedded_base["test"]["mean_regret"])
                ),
            }
        )
    if not attempts:
        raise ValueError(f"no confirmation attempts found below {run_root}")
    attempts_by_label: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for attempt in attempts:
        attempts_by_label[str(attempt["label"])].append(attempt)
    if expected_labels is not None and set(attempts_by_label) != expected_labels:
        missing = sorted(expected_labels - set(attempts_by_label))
        unexpected = sorted(set(attempts_by_label) - expected_labels)
        raise ValueError(
            "confirmation label set differs from the frozen protocol: "
            f"missing={missing}, unexpected={unexpected}"
        )
    expected = expected_data_seeds or {
        int(row["data_seed"]) for row in next(iter(attempts_by_label.values()))
    }
    for label, label_attempts in attempts_by_label.items():
        seeds = [int(row["data_seed"]) for row in label_attempts]
        if len(seeds) != len(set(seeds)) or set(seeds) != expected:
            raise ValueError(f"incomplete or duplicate confirmation seeds for {label}")
        if len({str(row["arm_sha256"]) for row in label_attempts}) != 1:
            raise ValueError(f"confirmation label {label} contains multiple arms")
        failures = [row for row in label_attempts if row["status"] != "complete"]
        if failures and label not in censored:
            raise ValueError(f"uncensored confirmation label {label} contains failures")
        if any(row["status"] not in {"complete", "failed"} for row in label_attempts):
            raise ValueError(f"confirmation label {label} contains unfinished attempts")

    by_label: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_label[str(row["label"])].append(row)
    censored_methods: list[dict[str, Any]] = []
    for label in sorted(censored):
        label_attempts = attempts_by_label.get(label, [])
        failures = [row for row in label_attempts if row["status"] == "failed"]
        if not failures:
            continue
        completed = sorted(
            by_label.pop(label, []), key=lambda row: int(row["data_seed"])
        )
        censored_methods.append(
            {
                "label": label,
                "status": "censored_due_to_strict_numerical_failures",
                "planned_seed_count": len(expected),
                "completed_seed_count": len(completed),
                "failed_seed_count": len(failures),
                "completed_seed_mean_test_regret": (
                    sum(float(row["test_mean_regret"]) for row in completed)
                    / len(completed)
                    if completed
                    else None
                ),
                "completed_rows": [
                    {
                        "data_seed": row["data_seed"],
                        "run_directory": row["run_directory"],
                        "test_mean_regret": row["test_mean_regret"],
                    }
                    for row in completed
                ],
                "failures": [
                    {
                        "data_seed": row["data_seed"],
                        "run_directory": row["run_directory"],
                        "status": row["status"],
                        "error_type": row["error_type"],
                        "error": row["error"],
                        "failed_at_utc": row["failed_at_utc"],
                    }
                    for row in sorted(failures, key=lambda row: int(row["data_seed"]))
                ],
            }
        )

    reference_seed_maps = [
        {int(row["data_seed"]): _seed_key(row) for row in label_attempts}
        for label_attempts in attempts_by_label.values()
    ]
    if any(seed_map != reference_seed_maps[0] for seed_map in reference_seed_maps[1:]):
        raise ValueError("confirmation methods do not share all five seed streams")
    shared_mse_base_verified = False
    if "mse" in by_label:
        mse_digests = {
            int(row["data_seed"]): str(row["parameter_sha256"])
            for row in by_label["mse"]
        }
        embedded_rows = [
            row for row in rows if row["embedded_mse_base_parameter_sha256"] is not None
        ]
        for row in embedded_rows:
            seed = int(row["data_seed"])
            if row["embedded_mse_base_parameter_sha256"] != mse_digests[seed]:
                raise ValueError(
                    "embedded MSE base does not match the standalone MSE "
                    f"checkpoint for seed {seed}"
                )
        shared_mse_base_verified = bool(embedded_rows)

    aggregates: list[dict[str, Any]] = []
    for label, label_rows in sorted(by_label.items()):
        ordered = sorted(label_rows, key=lambda row: int(row["data_seed"]))
        regrets = [float(row["test_mean_regret"]) for row in ordered]
        lower, upper = _student_t_interval(regrets)
        aggregate: dict[str, Any] = {
            "label": label,
            "seed_count": len(ordered),
            "mean_test_regret": sum(regrets) / len(regrets),
            "standard_error_test_regret": _standard_error(regrets),
            "student_t_95_interval": [lower, upper],
            "mean_normalized_test_regret": sum(
                float(row["test_normalized_mean_regret"]) for row in ordered
            )
            / len(ordered),
            "mean_positive_regret_rate": sum(
                float(row["test_positive_regret_rate"]) for row in ordered
            )
            / len(ordered),
            "mean_whole_pipeline_training_wall_seconds": sum(
                float(row["whole_pipeline_training_wall_seconds"]) for row in ordered
            )
            / len(ordered),
            "mean_whole_pipeline_training_oracle_calls": sum(
                int(row["whole_pipeline_training_oracle_calls"]) for row in ordered
            )
            / len(ordered),
            "arm_sha256": ordered[0]["arm_sha256"],
        }
        embedded_regrets = [row["embedded_mse_base_test_regret"] for row in ordered]
        if all(value is not None for value in embedded_regrets):
            base_regrets = [float(value) for value in embedded_regrets]
            correction_differences = [
                regret - base
                for regret, base in zip(regrets, base_regrets, strict=True)
            ]
            correction_lower, correction_upper = _student_t_interval(
                correction_differences
            )
            aggregate.update(
                {
                    "mean_embedded_mse_base_test_regret": sum(base_regrets)
                    / len(base_regrets),
                    "mean_correction_regret_difference": sum(correction_differences)
                    / len(correction_differences),
                    "correction_regret_difference_t_95_interval": [
                        correction_lower,
                        correction_upper,
                    ],
                    "correction_wins": sum(
                        difference < -1e-12 for difference in correction_differences
                    ),
                }
            )
        aggregates.append(aggregate)
    baselines = [label for label in ("mse", "wise", "spo_plus") if label in by_label]
    methods = sorted(label for label in by_label if label not in baselines)
    paired: list[dict[str, Any]] = []
    for method in methods:
        method_by_seed = {
            int(row["data_seed"]): float(row["test_mean_regret"])
            for row in by_label[method]
        }
        for baseline in baselines:
            baseline_by_seed = {
                int(row["data_seed"]): float(row["test_mean_regret"])
                for row in by_label[baseline]
            }
            differences = [
                method_by_seed[seed] - baseline_by_seed[seed]
                for seed in sorted(expected)
            ]
            lower, upper = _student_t_interval(differences)
            paired.append(
                {
                    "method": method,
                    "baseline": baseline,
                    "mean_paired_regret_difference": sum(differences)
                    / len(differences),
                    "standard_error_paired_difference": _standard_error(differences),
                    "student_t_95_interval": [lower, upper],
                    "wins": sum(difference < 0.0 for difference in differences),
                    "ties": sum(difference == 0.0 for difference in differences),
                    "seed_count": len(differences),
                }
            )
    return {
        "rule": (
            "no confirmation-time selection; summarize the single development-"
            "selected arm for each labeled method on all paired seeds"
        ),
        "run_root": str(run_root),
        "source_sha256": (
            next(iter({str(row["source_sha256"]) for row in attempts}))
            if len({str(row["source_sha256"]) for row in attempts}) == 1
            else None
        ),
        "source_sha256_by_label": {
            label: next(iter({str(row["source_sha256"]) for row in label_attempts}))
            for label, label_attempts in sorted(attempts_by_label.items())
        },
        "shared_mse_base_verified": shared_mse_base_verified,
        "data_seeds": sorted(expected),
        "aggregates": aggregates,
        "censored_methods": censored_methods,
        "paired_comparisons": paired,
        "rows": sorted(rows, key=lambda row: (str(row["label"]), row["data_seed"])),
    }


def render_confirmation_markdown(summary: dict[str, Any]) -> str:
    aggregates = summary.get("aggregates")
    paired = summary.get("paired_comparisons")
    if not isinstance(aggregates, list) or not isinstance(paired, list):
        raise ValueError("confirmation summary is malformed")
    lines = [
        "# PyEPO small-tau paired confirmation",
        "",
        f"Rule: {summary['rule']}.",
        "",
        "| Method | Seeds | Mean regret | 95% t interval | Normalized | "
        "Positive rate | Wall s | Training oracle calls |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for row in aggregates:
        interval = row["student_t_95_interval"]
        lines.append(
            "| {label} | {seed_count} | {mean_test_regret:.8g} | "
            "[{lower:.8g}, {upper:.8g}] | {mean_normalized_test_regret:.8g} | "
            "{mean_positive_regret_rate:.3%} | "
            "{mean_whole_pipeline_training_wall_seconds:.3f} | "
            "{mean_whole_pipeline_training_oracle_calls:.1f} |".format(
                lower=interval[0], upper=interval[1], **row
            )
        )
    correction_rows = [
        row for row in aggregates if "mean_correction_regret_difference" in row
    ]
    if correction_rows:
        lines.extend(
            [
                "",
                "## Correction relative to the identical embedded MSE base",
                "",
                f"Shared checkpoint digests verified: "
                f"{summary.get('shared_mse_base_verified')!s}.",
                "",
                "| Method | Embedded-base regret | Correction difference | "
                "95% t interval | Wins |",
                "| --- | ---: | ---: | ---: | ---: |",
            ]
        )
        for row in correction_rows:
            interval = row["correction_regret_difference_t_95_interval"]
            lines.append(
                "| {label} | {mean_embedded_mse_base_test_regret:.8g} | "
                "{mean_correction_regret_difference:.8g} | "
                "[{lower:.8g}, {upper:.8g}] | "
                "{correction_wins}/{seed_count} |".format(
                    lower=interval[0], upper=interval[1], **row
                )
            )
    lines.extend(
        [
            "",
            "## Paired differences (method minus baseline)",
            "",
            "| Method | Baseline | Mean difference | 95% t interval | Wins |",
            "| --- | --- | ---: | ---: | ---: |",
        ]
    )
    for row in paired:
        interval = row["student_t_95_interval"]
        lines.append(
            "| {method} | {baseline} | {mean_paired_regret_difference:.8g} | "
            "[{lower:.8g}, {upper:.8g}] | {wins}/{seed_count} |".format(
                lower=interval[0], upper=interval[1], **row
            )
        )
    censored_methods = summary.get("censored_methods", [])
    if not isinstance(censored_methods, list):
        raise ValueError("confirmation censored-method receipt is malformed")
    for method in censored_methods:
        completed_mean = method.get("completed_seed_mean_test_regret")
        mean_text = (
            "unavailable" if completed_mean is None else f"{float(completed_mean):.8g}"
        )
        lines.extend(
            [
                "",
                f"## Censored method: {method['label']}",
                "",
                f"Completed {method['completed_seed_count']}/"
                f"{method['planned_seed_count']} frozen seeds; the completed-seed "
                f"mean regret is {mean_text}. This is not promoted as a paired "
                "comparison.",
                "",
                "| Seed | Status | Detail |",
                "| ---: | --- | --- |",
            ]
        )
        for row in method["completed_rows"]:
            lines.append(
                f"| {row['data_seed']} | complete | regret "
                f"{float(row['test_mean_regret']):.8g} |"
            )
        for row in method["failures"]:
            lines.append(
                f"| {row['data_seed']} | failed | {row.get('error') or 'unknown'} |"
            )
    lines.extend(
        [
            "",
            "All hyperparameters were frozen on development seeds before these "
            "confirmation runs were generated.",
            "",
        ]
    )
    return "\n".join(lines)


def render_markdown(summary: dict[str, Any]) -> str:
    lines = [
        "# Validation-selected campaign summary",
        "",
        f"Selection rule: {summary['selection_rule']}.",
        "",
        "| Benchmark | Interface | Method | Seeds | Mean test regret | SE |",
        "| --- | --- | --- | ---: | ---: | ---: |",
    ]
    aggregates = summary.get("aggregates")
    if not isinstance(aggregates, list):
        raise ValueError("summary lacks aggregate rows")
    for row in aggregates:
        lines.append(
            "| {benchmark_id} | {interface} | {method} | {seed_count} | "
            "{mean_test_regret:.8g} | {standard_error_test_regret:.3g} |".format(**row)
        )
    lines.extend(["", "Test values were never used to select an arm.", ""])
    return "\n".join(lines)
