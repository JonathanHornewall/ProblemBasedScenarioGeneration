"""Equality-aware logarithmic central-path oracle for bounded LPs."""

from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
from scipy.linalg import null_space, solve
from scipy.optimize import linprog
from scipy.sparse import csc_matrix

from .oracles import BatchSolutions, OracleFailure, OracleStats, ParallelOracle
from .problem import FloatArray, LinearProblem


@dataclass(frozen=True)
class BarrierGeometry:
    equality_matrix: FloatArray
    equality_rhs: FloatArray
    inequality_matrix: FloatArray
    inequality_rhs: FloatArray
    tangent_basis: FloatArray

    @classmethod
    def compile(
        cls, problem: LinearProblem, *, equality_tolerance: float = 1e-10
    ) -> BarrierGeometry:
        equalities: list[FloatArray] = []
        equality_rhs: list[float] = []
        inequalities: list[FloatArray] = []
        inequality_rhs: list[float] = []
        matrix = np.asarray(csc_matrix(problem.matrix).toarray(), dtype=np.float64)
        for row, lower, upper in zip(
            matrix, problem.row_lower, problem.row_upper, strict=True
        ):
            equality = (
                np.isfinite(lower)
                and np.isfinite(upper)
                and abs(upper - lower) <= equality_tolerance
            )
            if equality:
                equalities.append(row)
                equality_rhs.append(0.5 * (lower + upper))
                continue
            if np.isfinite(upper):
                inequalities.append(row)
                inequality_rhs.append(float(upper))
            if np.isfinite(lower):
                inequalities.append(-row)
                inequality_rhs.append(float(-lower))
        for index in range(problem.variable_count):
            unit = np.zeros(problem.variable_count)
            unit[index] = 1.0
            if np.isfinite(problem.variable_upper[index]):
                inequalities.append(unit)
                inequality_rhs.append(float(problem.variable_upper[index]))
            if np.isfinite(problem.variable_lower[index]):
                inequalities.append(-unit)
                inequality_rhs.append(float(-problem.variable_lower[index]))
        equality = (
            np.stack(equalities)
            if equalities
            else np.empty((0, problem.variable_count))
        )
        inequality = (
            np.stack(inequalities)
            if inequalities
            else np.empty((0, problem.variable_count))
        )
        tangent = (
            null_space(equality)
            if equality.shape[0]
            else np.eye(problem.variable_count)
        )
        return cls(
            equality,
            np.asarray(equality_rhs, dtype=np.float64),
            inequality,
            np.asarray(inequality_rhs, dtype=np.float64),
            tangent,
        )

    def slacks(self, decision: FloatArray) -> FloatArray:
        return self.inequality_rhs - self.inequality_matrix @ decision

    def gradient_hessian(
        self, decision: FloatArray, objective: FloatArray, mu: float
    ) -> tuple[FloatArray, FloatArray]:
        slacks = self.slacks(decision)
        if np.any(slacks <= 0.0):
            raise OracleFailure("log-barrier point is not strictly feasible")
        inverse = 1.0 / slacks
        gradient = objective + mu * (self.inequality_matrix.T @ inverse)
        weighted = self.inequality_matrix * inverse[:, None]
        hessian = mu * (weighted.T @ weighted)
        return gradient, hessian

    def kkt_solve(
        self, hessian: FloatArray, primal_rhs: FloatArray, equality_rhs: FloatArray
    ) -> tuple[FloatArray, FloatArray]:
        n = hessian.shape[0]
        m = self.equality_matrix.shape[0]
        if m == 0:
            direction = solve(
                hessian,
                primal_rhs,
                assume_a="sym",
                check_finite=False,
            )
            return direction, np.empty(0)
        if np.linalg.norm(equality_rhs, ord=np.inf) <= 1e-10:
            basis = self.tangent_basis
            if basis.shape[1] == 0:
                return np.zeros(n), np.zeros(m)
            reduced_hessian = basis.T @ hessian @ basis
            reduced_rhs = basis.T @ primal_rhs
            reduced_direction = solve(
                reduced_hessian,
                reduced_rhs,
                assume_a="pos",
                check_finite=False,
            )
            direction = basis @ reduced_direction
            multiplier = np.linalg.lstsq(
                self.equality_matrix.T,
                primal_rhs - hessian @ direction,
                rcond=None,
            )[0]
            return direction, multiplier
        kkt = np.block(
            [
                [hessian, self.equality_matrix.T],
                [self.equality_matrix, np.zeros((m, m))],
            ]
        )
        rhs = np.concatenate([primal_rhs, equality_rhs])
        solution = solve(kkt, rhs, assume_a="sym", check_finite=False)
        return solution[:n], solution[n:]

    def inverse_tangent_product(
        self,
        decision: FloatArray,
        mu: float,
        vector: FloatArray,
    ) -> FloatArray:
        _, hessian = self.gradient_hessian(decision, np.zeros_like(vector), mu)
        product, _ = self.kkt_solve(
            hessian,
            np.asarray(vector, dtype=np.float64),
            np.zeros(len(self.equality_rhs)),
        )
        return product

    def strictly_feasible_point(self) -> FloatArray:
        n = self.inequality_matrix.shape[1]
        if self.inequality_matrix.shape[0] == 0:
            if self.equality_matrix.shape[0] == 0:
                return np.zeros(n)
            return np.linalg.lstsq(self.equality_matrix, self.equality_rhs, rcond=None)[
                0
            ]
        row_scale = np.maximum(1.0, np.linalg.norm(self.inequality_matrix, axis=1))
        a_ub = np.column_stack([self.inequality_matrix, row_scale])
        c = np.concatenate([np.zeros(n), [-1.0]])
        if self.equality_matrix.shape[0]:
            a_eq = np.column_stack(
                [self.equality_matrix, np.zeros(len(self.equality_rhs))]
            )
            b_eq = self.equality_rhs
        else:
            a_eq = None
            b_eq = None
        result = linprog(
            c,
            A_ub=a_ub,
            b_ub=self.inequality_rhs,
            A_eq=a_eq,
            b_eq=b_eq,
            bounds=[(None, None)] * n + [(None, 1e3)],
            method="highs",
        )
        if not result.success or result.x is None:
            raise OracleFailure(
                f"failed to find a strict barrier start: {result.message}"
            )
        decision = np.asarray(result.x[:n], dtype=np.float64)
        if self.slacks(decision).min(initial=np.inf) <= 1e-8:
            raise OracleFailure("feasible set has no numerically detectable interior")
        return decision


class PersistentLogBarrierSolver:
    def __init__(
        self,
        problem: LinearProblem,
        *,
        mu: float,
        tolerance: float = 5e-8,
        maximum_iterations: int = 120,
    ) -> None:
        if not problem.is_continuous:
            raise ValueError("log-barrier solver requires a continuous feasible set")
        self.problem = problem
        self.geometry = BarrierGeometry.compile(problem)
        self.mu = float(mu)
        self.tolerance = float(tolerance)
        self.maximum_iterations = int(maximum_iterations)
        self._center = self.geometry.strictly_feasible_point()
        self._last = self._center.copy()

    def set_mu(self, mu: float) -> None:
        if mu <= 0.0 or not np.isfinite(mu):
            raise ValueError("mu must be finite and positive")
        self.mu = float(mu)

    def _objective(self, decision: FloatArray, objective: FloatArray) -> float:
        slacks = self.geometry.slacks(decision)
        if np.any(slacks <= 0.0):
            return np.inf
        return float(objective @ decision - self.mu * np.log(slacks).sum())

    def _newton(
        self, objective: FloatArray, initial: FloatArray
    ) -> tuple[FloatArray, int] | None:
        decision = initial.copy()
        for iteration in range(1, self.maximum_iterations + 1):
            gradient, hessian = self.geometry.gradient_hessian(
                decision, objective, self.mu
            )
            projected_gradient = self.geometry.tangent_basis.T @ gradient
            projected_objective = self.geometry.tangent_basis.T @ objective
            gradient_tolerance = self.tolerance * (
                1.0 + np.linalg.norm(projected_objective, ord=np.inf)
            )
            if np.linalg.norm(projected_gradient, ord=np.inf) <= gradient_tolerance:
                return decision, iteration
            equality_residual = (
                self.geometry.equality_matrix @ decision - self.geometry.equality_rhs
            )
            direction, _ = self.geometry.kkt_solve(
                hessian, -gradient, -equality_residual
            )
            if np.linalg.norm(direction) <= self.tolerance * (
                1.0 + np.linalg.norm(decision)
            ):
                return decision, iteration
            g_direction = self.geometry.inequality_matrix @ direction
            positive = g_direction > 0.0
            step = 1.0
            if np.any(positive):
                step = min(
                    step,
                    0.995
                    * float(
                        np.min(
                            self.geometry.slacks(decision)[positive]
                            / g_direction[positive]
                        )
                    ),
                )
            current = self._objective(decision, objective)
            directional = float(gradient @ direction)
            while step > 1e-12:
                candidate = decision + step * direction
                if (
                    self._objective(candidate, objective)
                    <= current + 1e-4 * step * directional
                ):
                    decision = candidate
                    break
                step *= 0.5
            else:
                return None
        return None

    def solve(self, objective: FloatArray) -> tuple[FloatArray, float, OracleStats]:
        objective = np.asarray(objective, dtype=np.float64)
        if objective.shape != (self.problem.variable_count,):
            raise ValueError("barrier objective has the wrong shape")
        started = time.perf_counter()
        starts = [self._last]
        if (
            self.geometry.slacks(self._last).min(initial=np.inf) <= 0.0
            or np.linalg.norm(self._last - self._center) > 1e-12
        ):
            starts.append(self._center)
        solved: tuple[FloatArray, int] | None = None
        iterations = 0
        for initial in starts:
            candidate = self._newton(objective, initial)
            if candidate is not None:
                solved = candidate
                break
            iterations += self.maximum_iterations
        if solved is None:
            raise OracleFailure(
                "log-barrier Newton failed from warm and strict-center starts"
            )
        decision, final_iterations = solved
        iterations += final_iterations
        self._last = decision.copy()
        wall = time.perf_counter() - started
        return (
            decision,
            float(objective @ decision),
            OracleStats(1, iterations, 0, wall, wall),
        )

    def solve_many(
        self,
        objectives: FloatArray,
        sample_keys: np.ndarray | None = None,
    ) -> BatchSolutions:
        objectives = np.asarray(objectives, dtype=np.float64)
        if sample_keys is not None and np.asarray(sample_keys).shape != (
            len(objectives),
        ):
            raise ValueError("sample keys must align with the objective batch")
        decisions: list[FloatArray] = []
        values: list[float] = []
        total = OracleStats()
        for objective in objectives:
            try:
                decision, value, stats = self.solve(objective)
            except Exception:
                total += OracleStats(calls=1, failures=1)
                raise
            decisions.append(decision)
            values.append(value)
            total += stats
        return BatchSolutions(
            np.stack(decisions), np.asarray(values, dtype=np.float64), total
        )


class LogBarrierOracle(ParallelOracle[PersistentLogBarrierSolver]):
    @property
    def geometry(self) -> BarrierGeometry:
        return self.solvers[0].geometry

    def set_mu(self, mu: float) -> None:
        for solver in self.solvers:
            solver.set_mu(mu)


def make_log_barrier_oracle(
    problem: LinearProblem, *, mu: float, workers: int
) -> LogBarrierOracle:
    return LogBarrierOracle(
        [PersistentLogBarrierSolver(problem, mu=mu) for _ in range(workers)]
    )
