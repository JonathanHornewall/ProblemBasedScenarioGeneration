"""Atomic, checked geometry-only cache shared by CP-SPO fit processes.

No costs, observations, seed labels, or evaluation arrays are accepted here.
Center entries are independent of the chart (whitened or unwhitened).
"""
from __future__ import annotations

import fcntl
import hashlib
import json
import os
import platform
import time
from contextlib import contextmanager
from dataclasses import asdict, replace
from pathlib import Path

import numpy as np
import scipy
from scipy.sparse import csr_matrix


def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(2**20), b""):
            h.update(chunk)
    return h.hexdigest()


def cache_identity(problem, tolerance=1e-8, maximum_iterations=100):
    from .feasible_policies import _geometry_cache_key
    base = Path(__file__).parent
    declaration = {"schema": "cp-policy-center-chart-v1", "problem": _geometry_cache_key(problem),
        "tolerance": tolerance, "maximum_iterations": maximum_iterations,
        "numpy": np.__version__, "scipy": scipy.__version__,
        "algorithm_files": {name: sha_file(base/name) for name in
                            ("feasible_policies.py", "barrier.py", "problem.py", "policy_geometry_cache.py")}}
    key = hashlib.sha256(json.dumps(declaration, sort_keys=True).encode()).hexdigest()
    return key, declaration


@contextmanager
def entry_lock(root, key):
    locks = root/"locks"
    locks.mkdir(parents=True, exist_ok=True)
    with (locks/(key+".lock")).open("a") as f:
        fcntl.flock(f, fcntl.LOCK_EX)
        yield


def save_entry(path, arrays, metadata):
    # A failed producer leaves evidence; it never exposes an incomplete entry.
    pending = path.with_name(path.name+f".incomplete.{time.time_ns()}.{os.getpid()}")
    pending.mkdir(parents=True, exist_ok=False)
    files = {}
    for name, value in arrays.items():
        target = pending/(name+".npy")
        with target.open("wb") as f:
            np.save(f, np.ascontiguousarray(value), allow_pickle=False)
            f.flush(); os.fsync(f.fileno())
        files[name] = {"sha256": sha_file(target), "bytes": target.stat().st_size}
    record = {"metadata": metadata, "arrays": files, "created_unix": time.time(),
              "producer_pid": os.getpid(), "producer_host": platform.node()}
    target = pending/"manifest.json"
    with target.open("w") as f:
        json.dump(record, f, sort_keys=True, indent=2); f.write("\n"); f.flush(); os.fsync(f.fileno())
    pending.rename(path)


def load_entry(path):
    record = json.loads((path/"manifest.json").read_text())
    arrays = {}
    for name, info in record["arrays"].items():
        if not name.isidentifier():
            raise ValueError("invalid cache array name")
        target = path/(name+".npy")
        if target.stat().st_size != info["bytes"] or sha_file(target) != info["sha256"]:
            raise ValueError("geometry cache integrity failure: "+str(target))
        # Read-only memory maps share physical pages between fits on one node.
        arrays[name] = np.load(target, allow_pickle=False, mmap_mode="r")
    return {"arrays": arrays, "metadata": record["metadata"],
            "cache": {"entry": str(path), "manifest_sha256": sha_file(path/"manifest.json"),
                      "producer_pid": record["producer_pid"], "producer_host": record["producer_host"],
                      "created_unix": record["created_unix"]}}


def center_state(problem, tolerance, maximum_iterations, factory):
    directory = os.environ.get("CP_SPO_GEOMETRY_CACHE")
    if not directory:
        return factory(problem, tolerance, maximum_iterations)
    root = Path(directory)
    key, declaration = cache_identity(problem, tolerance, maximum_iterations)
    path = root/"centers"/key
    with entry_lock(root, "center-"+key):
        hit = path.exists()
        if not hit:
            if os.environ.get("CP_SPO_GEOMETRY_CACHE_READONLY") == "1":
                raise RuntimeError("precomputed analytic center missing: "+key)
            state = factory(problem, tolerance, maximum_iterations)
            save_entry(path, state["arrays"], {**state["metadata"], "identity": declaration})
        result = load_entry(path)
        if result["metadata"]["identity"] != declaration:
            raise ValueError("analytic center identity mismatch")
        result["cache"].update(center_key=key, center_cache_hit=hit,
                               center_computations_this_call=0 if hit else 1)
        return result


def chart_geometry(problem, whitening):
    from .feasible_policies import PolyhedralPolicyGeometry, GeometryReceipt
    directory = os.environ.get("CP_SPO_GEOMETRY_CACHE")
    if not directory:
        return PolyhedralPolicyGeometry.compile(problem, hessian_whitening=whitening)
    started = time.perf_counter()
    root = Path(directory)
    key, declaration = cache_identity(problem)
    path = root/"charts"/(key+("-white" if whitening else "-raw"))
    with entry_lock(root, "chart-"+path.name):
        hit = path.exists()
        if not hit:
            if os.environ.get("CP_SPO_GEOMETRY_CACHE_READONLY") == "1":
                raise RuntimeError("precomputed policy chart missing: "+path.name)
            geometry = PolyhedralPolicyGeometry.compile(problem, hessian_whitening=whitening)
            save_entry(path, {name: getattr(geometry,name) for name in
                ("center", "physical_map", "physical_map_transpose", "inequality_matrix", "normalized_inequalities",
                 "normalized_inequalities_transpose", "center_slacks", "barrier_linear_term")},
                {"identity": declaration, "receipt": asdict(geometry.receipt)})
            del geometry
        state = load_entry(path)
        if state["metadata"]["identity"] != declaration:
            raise ValueError("chart identity mismatch")
        receipt = GeometryReceipt(**state["metadata"]["receipt"])
        if receipt.hessian_whitening != whitening:
            raise ValueError("chart whitening mismatch")
        receipt = replace(receipt, geometry_cache={**(receipt.geometry_cache or {}),
            "chart_entry": str(path), "chart_manifest_sha256": state["cache"]["manifest_sha256"],
            "chart_cache_hit": hit, "center_computations_this_call": 0 if hit else
            (receipt.geometry_cache or {}).get("center_computations_this_call", 0),
            "cache_load_wall_seconds": time.perf_counter()-started})
        a=state["arrays"]
        return PolyhedralPolicyGeometry(center=a["center"], physical_map=a["physical_map"],
            physical_map_transpose=a["physical_map_transpose"],
            inequality_matrix=a["inequality_matrix"],
            normalized_inequalities=a["normalized_inequalities"],
            normalized_inequalities_transpose=a["normalized_inequalities_transpose"],
            center_slacks=a["center_slacks"], barrier_linear_term=a["barrier_linear_term"],
            sparse_inequality_matrix=csr_matrix(a["inequality_matrix"]), receipt=receipt)
