"""Solve the convex affine report-head QP with numerical KKT checks."""

from __future__ import annotations

import time
from dataclasses import asdict, dataclass

import numpy as np
import osqp
from scipy.sparse import block_diag, csc_matrix, eye, hstack, kron, vstack

from .oracles import OracleStats, make_qp_oracle
from .problem import FloatArray, PartialCostInterface


@dataclass(frozen=True)
class ExactHeadResult:
    weights: FloatArray
    reports: FloatArray
    physical_reports: FloatArray
    decisions: FloatArray
    objective: float
    stats: OracleStats
    variables: int
    constraints: int
    nonzeros: int
    solver_status: str
    primal_residual: float
    dual_residual: float
    maximum_constraint_violation: float
    certificate_tolerance: float
    backend: str = "monolithic_osqp"
    outer_iterations: int = 1

    def receipt(self) -> dict[str, object]:
        return {
            "objective": self.objective,
            "stats": asdict(self.stats),
            "variables": self.variables,
            "constraints": self.constraints,
            "nonzeros": self.nonzeros,
            "solver_status": self.solver_status,
            "primal_residual": self.primal_residual,
            "dual_residual": self.dual_residual,
            "maximum_constraint_violation": self.maximum_constraint_violation,
            "certificate_tolerance": self.certificate_tolerance,
            "backend": self.backend,
            "outer_iterations": self.outer_iterations,
        }


def _maximum_primal_violation(
    decisions: FloatArray, interface: PartialCostInterface
) -> float:
    problem = interface.problem
    activity = np.asarray(decisions @ problem.matrix.T, dtype=np.float64)
    return float(
        max(
            np.max(problem.variable_lower - decisions, initial=0.0),
            np.max(decisions - problem.variable_upper, initial=0.0),
            np.max(problem.row_lower - activity, initial=0.0),
            np.max(activity - problem.row_upper, initial=0.0),
        )
    )


def solve_exact_proximal_head_decomposed(
    *,
    features: FloatArray,
    coefficients: FloatArray,
    interface: PartialCostInterface,
    tau: float,
    report_scale: float = 1.0,
    report_offset: FloatArray | None = None,
    ridge: float = 1e-8,
    workers: int = 1,
    maximum_outer_iterations: int = 5_000,
    certificate_tolerance: float = 1e-6,
) -> ExactHeadResult:
    """Globally solve the convex head QP by exact block decomposition.

    For fixed head weights, all sample decisions are independent proximal QPs.
    For fixed decisions, the affine head is one shared linear system with all
    report coordinates as right-hand sides.  Exact cyclic minimization of this
    jointly convex objective converges to its global solution.  We stop only
    when the sample blocks are optimal for the reported head and the remaining
    head-gradient KKT residual satisfies ``certificate_tolerance``.
    """

    features = np.asarray(features, dtype=np.float64)
    coefficients = np.asarray(coefficients, dtype=np.float64)
    if features.ndim != 2 or coefficients.ndim != 2:
        raise ValueError("features and coefficients must be matrices")
    if len(features) != len(coefficients):
        raise ValueError("features and coefficients must share their rows")
    if coefficients.shape[1] != interface.report_dimension:
        raise ValueError("coefficient dimension disagrees with interface")
    if (
        tau <= 0.0
        or report_scale <= 0.0
        or ridge < 0.0
        or workers <= 0
        or maximum_outer_iterations <= 0
        or certificate_tolerance <= 0.0
    ):
        raise ValueError("invalid decomposed exact-head parameter")
    sample_count, feature_dimension = features.shape
    report_dimension = interface.report_dimension
    if report_offset is None:
        offset = np.zeros((sample_count, report_dimension), dtype=np.float64)
    else:
        offset = np.asarray(report_offset, dtype=np.float64)
        if offset.shape != (sample_count, report_dimension):
            raise ValueError("report_offset has the wrong shape")
        if not np.all(np.isfinite(offset)):
            raise ValueError("report_offset must be finite")

    normal_matrix = (
        (report_scale**2 / (tau * sample_count)) * (features.T @ features)
        + ridge * np.eye(feature_dimension)
    )
    try:
        cholesky = np.linalg.cholesky(normal_matrix)

        def solve_head(right_hand_side: FloatArray) -> FloatArray:
            intermediate = np.linalg.solve(cholesky, right_hand_side)
            return np.linalg.solve(cholesky.T, intermediate)

    except np.linalg.LinAlgError:

        def solve_head(right_hand_side: FloatArray) -> FloatArray:
            return np.asarray(
                np.linalg.lstsq(
                    normal_matrix, right_hand_side, rcond=None
                )[0],
                dtype=np.float64,
            )

    coefficient_term = (
        report_scale * (features.T @ coefficients) / sample_count
    )
    quadratic = csc_matrix(
        interface.statistic.T @ interface.statistic / tau
    )
    weights = np.zeros((feature_dimension, report_dimension), dtype=np.float64)
    total_stats = OracleStats()
    started = time.perf_counter()
    decisions = np.empty((sample_count, interface.problem.variable_count))
    reports = features @ weights
    physical_reports = offset + report_scale * reports
    objective = float("inf")
    gradient_norm = float("inf")
    outer_iteration = 0
    with make_qp_oracle(
        interface.problem, quadratic, workers=workers
    ) as oracle:
        for _outer_iteration in range(1, maximum_outer_iterations + 1):
            outer_iteration = _outer_iteration
            reports = features @ weights
            physical_reports = offset + report_scale * reports
            linear = (
                interface.fixed_cost
                + (physical_reports / tau) @ interface.statistic
            )
            solved = oracle.solve_many(linear)
            decisions = solved.decisions
            total_stats += solved.stats
            statistics = decisions @ interface.statistic.T
            residual = physical_reports + statistics
            head_gradient = (
                ridge * weights
                + report_scale
                * (features.T @ residual)
                / (tau * sample_count)
                - coefficient_term
            )
            gradient_norm = float(np.max(np.abs(head_gradient), initial=0.0))
            objective = float(
                0.5 * ridge * np.sum(weights**2)
                + np.mean(decisions @ interface.fixed_cost)
                + 0.5 * np.mean(np.sum(residual**2, axis=1)) / tau
                - np.mean(
                    np.sum(coefficients * (report_scale * reports), axis=1)
                )
            )
            if gradient_norm <= certificate_tolerance:
                break
            right_hand_side = coefficient_term - (
                report_scale
                * (features.T @ (offset + statistics))
                / (tau * sample_count)
            )
            weights = solve_head(right_hand_side)
        else:
            raise RuntimeError(
                "decomposed exact head did not reach its KKT tolerance: "
                f"gradient={gradient_norm:.3g}, "
                f"iterations={maximum_outer_iterations}"
            )

    wall = time.perf_counter() - started
    maximum_constraint_violation = _maximum_primal_violation(
        decisions, interface
    )
    if maximum_constraint_violation > certificate_tolerance:
        raise RuntimeError(
            "decomposed exact-head primal certificate exceeds tolerance: "
            f"{maximum_constraint_violation:.3g} > {certificate_tolerance:.3g}"
        )
    decision_dimension = interface.problem.variable_count
    head_variables = feature_dimension * report_dimension
    decision_variables = sample_count * decision_dimension
    residual_variables = sample_count * report_dimension
    decision_matrix = interface.problem.osqp_matrix
    statistic_nonzeros = csc_matrix(interface.statistic).nnz
    nonzeros = (
        head_variables
        + residual_variables
        + sample_count * decision_matrix.nnz
        + report_dimension * np.count_nonzero(features)
        + sample_count * statistic_nonzeros
        + residual_variables
    )
    return ExactHeadResult(
        weights=weights,
        reports=reports,
        physical_reports=physical_reports,
        decisions=decisions,
        objective=objective,
        stats=OracleStats(
            calls=total_stats.calls,
            iterations=total_stats.iterations,
            failures=total_stats.failures,
            solver_seconds=total_stats.solver_seconds,
            wall_seconds=wall,
            retries=total_stats.retries,
        ),
        variables=head_variables + decision_variables + residual_variables,
        constraints=(
            sample_count * decision_matrix.shape[0] + residual_variables
        ),
        nonzeros=int(nonzeros),
        solver_status="decomposed_coordinate_optimal",
        primal_residual=maximum_constraint_violation,
        dual_residual=gradient_norm,
        maximum_constraint_violation=maximum_constraint_violation,
        certificate_tolerance=certificate_tolerance,
        backend="decomposed_exact_blocks",
        outer_iterations=outer_iteration,
    )


def solve_exact_proximal_head(
    *,
    features: FloatArray,
    coefficients: FloatArray,
    interface: PartialCostInterface,
    tau: float,
    report_scale: float = 1.0,
    report_offset: FloatArray | None = None,
    ridge: float = 1e-8,
    maximum_variables: int = 250_000,
    certificate_tolerance: float = 1e-6,
) -> ExactHeadResult:
    """Solve the frozen-feature empirical proximal loss as one sparse QP.

    Auxiliary residuals preserve the block-angular sparsity instead of forming
    the dense normal-equation Hessian.
    """

    features = np.asarray(features, dtype=np.float64)
    coefficients = np.asarray(coefficients, dtype=np.float64)
    if features.ndim != 2 or coefficients.ndim != 2:
        raise ValueError("features and coefficients must be matrices")
    if len(features) != len(coefficients):
        raise ValueError("feature and coefficient sample counts disagree")
    if coefficients.shape[1] != interface.report_dimension:
        raise ValueError("coefficient dimension disagrees with interface")
    if (
        tau <= 0.0
        or report_scale <= 0.0
        or ridge < 0.0
        or certificate_tolerance <= 0.0
    ):
        raise ValueError("tau/report_scale must be positive and ridge nonnegative")
    sample_count, feature_dimension = features.shape
    report_dimension = interface.report_dimension
    if report_offset is None:
        offset = np.zeros((sample_count, report_dimension), dtype=np.float64)
    else:
        offset = np.asarray(report_offset, dtype=np.float64)
        if offset.shape != (sample_count, report_dimension):
            raise ValueError("report_offset has the wrong shape")
        if not np.all(np.isfinite(offset)):
            raise ValueError("report_offset must be finite")
    decision_dimension = interface.problem.variable_count
    head_variables = feature_dimension * report_dimension
    decision_variables = sample_count * decision_dimension
    residual_variables = sample_count * report_dimension
    variable_count = head_variables + decision_variables + residual_variables
    if variable_count > maximum_variables:
        raise ValueError(
            f"exact head has {variable_count} variables; guard is {maximum_variables}"
        )

    # Flatten W by feature blocks, so kron(Phi, I_k) maps vec(W) to reports.
    report_map = kron(csc_matrix(features), eye(report_dimension), format="csc")
    physical_report_map = report_scale * report_map
    statistic_map = kron(
        eye(sample_count), csc_matrix(interface.statistic), format="csc"
    )
    decision_map = kron(eye(sample_count), interface.problem.osqp_matrix, format="csc")
    residual_identity = eye(residual_variables, format="csc")
    zero_decision_head = csc_matrix((decision_map.shape[0], head_variables))
    zero_decision_residual = csc_matrix((decision_map.shape[0], residual_variables))
    decision_constraints = hstack(
        [zero_decision_head, decision_map, zero_decision_residual], format="csc"
    )
    residual_constraints = hstack(
        [-physical_report_map, -statistic_map, residual_identity], format="csc"
    )
    constraint_matrix = vstack(
        [decision_constraints, residual_constraints], format="csc"
    )
    lower = np.concatenate(
        [
            np.tile(interface.problem.osqp_lower, sample_count),
            offset.reshape(-1),
        ]
    )
    upper = np.concatenate(
        [
            np.tile(interface.problem.osqp_upper, sample_count),
            offset.reshape(-1),
        ]
    )
    quadratic = block_diag(
        [
            eye(head_variables, format="csc") * ridge,
            csc_matrix((decision_variables, decision_variables)),
            eye(residual_variables, format="csc") / (tau * sample_count),
        ],
        format="csc",
    )
    coefficient_flat = coefficients.reshape(-1)
    linear_head = -(physical_report_map.T @ coefficient_flat) / sample_count
    linear_decisions = np.tile(interface.fixed_cost, sample_count) / sample_count
    linear = np.concatenate(
        [linear_head, linear_decisions, np.zeros(residual_variables)]
    )

    solver = osqp.OSQP()
    solver.setup(
        P=quadratic,
        q=linear,
        A=constraint_matrix,
        l=lower,
        u=upper,
        eps_abs=1e-8,
        eps_rel=1e-8,
        max_iter=100_000,
        verbose=False,
        polishing=True,
        adaptive_rho=True,
    )
    started = time.perf_counter()
    result = solver.solve(raise_error=False)
    wall = time.perf_counter() - started
    if result.x is None or int(result.info.status_val) != 1:
        raise RuntimeError(f"exact-head OSQP failed: {result.info.status}")
    vector = np.asarray(result.x, dtype=np.float64)
    constraint_values = np.asarray(constraint_matrix @ vector).reshape(-1)
    maximum_constraint_violation = float(
        max(
            np.max(np.maximum(lower - constraint_values, 0.0), initial=0.0),
            np.max(np.maximum(constraint_values - upper, 0.0), initial=0.0),
        )
    )
    primal_residual = float(result.info.prim_res)
    dual_residual = float(result.info.dual_res)
    if max(
        primal_residual,
        dual_residual,
        maximum_constraint_violation,
    ) > certificate_tolerance:
        raise RuntimeError(
            "exact-head OSQP certificate exceeds tolerance: "
            f"primal={primal_residual:.3g}, dual={dual_residual:.3g}, "
            f"constraint={maximum_constraint_violation:.3g}, "
            f"tolerance={certificate_tolerance:.3g}"
        )
    head = vector[:head_variables].reshape(feature_dimension, report_dimension)
    decision_start = head_variables
    decisions = vector[decision_start : decision_start + decision_variables].reshape(
        sample_count, decision_dimension
    )
    reports = features @ head
    physical_reports = offset + report_scale * reports
    stats = OracleStats(
        calls=1,
        iterations=int(result.info.iter),
        failures=0,
        solver_seconds=float(result.info.run_time),
        wall_seconds=wall,
    )
    return ExactHeadResult(
        weights=head,
        reports=reports,
        physical_reports=physical_reports,
        decisions=decisions,
        objective=float(result.info.obj_val),
        stats=stats,
        variables=variable_count,
        constraints=constraint_matrix.shape[0],
        nonzeros=constraint_matrix.nnz + quadratic.nnz,
        solver_status=str(result.info.status),
        primal_residual=primal_residual,
        dual_residual=dual_residual,
        maximum_constraint_violation=maximum_constraint_violation,
        certificate_tolerance=certificate_tolerance,
    )
