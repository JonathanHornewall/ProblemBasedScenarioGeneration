"""Paired statistical analysis for frozen publication confirmation runs."""

from __future__ import annotations

import hashlib
import json
import math
from collections import Counter, defaultdict
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path
from statistics import fmean, median, stdev
from typing import Any

from scipy import stats

from .experiment_identity import (
    benchmark_family_id,
    experimental_route_id,
    physical_dataset_id,
)


def _object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object at {path}")
    return payload


def _validation_oracle_totals(path: Path) -> dict[str, float | int]:
    """Aggregate every validation solve recorded during one frozen run."""

    if not path.is_file():
        raise FileNotFoundError(path)
    calls = 0
    failures = 0
    solver_seconds = 0.0
    checkpoints = 0
    for line in path.read_text(encoding="utf-8").splitlines():
        record = json.loads(line)
        validation = record.get("validation")
        if not isinstance(validation, dict):
            continue
        oracle = validation.get("oracle_stats")
        if not isinstance(oracle, dict):
            raise ValueError(f"validation receipt lacks oracle stats: {path}")
        checkpoints += 1
        calls += int(oracle.get("calls", 0))
        failures += int(oracle.get("failures", 0))
        solver_seconds += float(oracle.get("solver_seconds", 0.0))
    if checkpoints == 0:
        raise ValueError(f"confirmation run has no validation checkpoint: {path}")
    return {
        "checkpoints": checkpoints,
        "calls": calls,
        "failures": failures,
        "solver_seconds": solver_seconds,
    }


def _is_fixed_split_size_replacement(
    original: Mapping[str, Any], replacement: Mapping[str, Any]
) -> bool:
    """Accept only the archived fixed-source replay's test-size repair.

    The provider rejected an unavailable 128-row fixed test split before any
    evaluation.  Its frozen replay changes that request to the released 50-row
    split and leaves every other field byte-for-byte equivalent.
    """

    original_sizes = original.get("sizes")
    replacement_sizes = replacement.get("sizes")
    if not isinstance(original_sizes, Mapping) or not isinstance(
        replacement_sizes, Mapping
    ):
        return False
    original_test = original_sizes.get("test")
    replacement_test = replacement_sizes.get("test")
    if (
        not isinstance(original_test, int)
        or isinstance(original_test, bool)
        or not isinstance(replacement_test, int)
        or isinstance(replacement_test, bool)
        or original_test != 128
        or replacement_test != 50
    ):
        return False
    normalized_original = dict(original)
    normalized_replacement = dict(replacement)
    normalized_original["sizes"] = {
        key: value for key, value in original_sizes.items() if key != "test"
    }
    normalized_replacement["sizes"] = {
        key: value for key, value in replacement_sizes.items() if key != "test"
    }
    return normalized_original == normalized_replacement


def verify_confirmation_manifests(
    run_roots: Iterable[Path],
    manifest_paths: Iterable[Path],
    *,
    allowed_replaced_variant_count: int = 0,
) -> dict[str, Any]:
    """Bind completed receipts to configs frozen before test access.

    A replacement manifest is allowed to supersede a bounded number of variants
    from an earlier manifest only when the sole config change is the requested
    fixed test-split size. This covers the archived 128-to-50-row provider repair
    while preserving the original provider rejections.
    """

    roots = [Path(root).resolve() for root in run_roots]
    manifests = [Path(path).resolve() for path in manifest_paths]
    if not manifests:
        raise ValueError("at least one frozen confirmation manifest is required")
    if allowed_replaced_variant_count < 0:
        raise ValueError("allowed replacement count must be nonnegative")

    expected: dict[str, dict[str, Any]] = {}
    superseded: list[dict[str, Any]] = []
    manifest_records: list[dict[str, Any]] = []
    for path in manifests:
        manifest = _object(path)
        design = manifest.get("design")
        variants = manifest.get("variants")
        if not isinstance(design, Mapping):
            raise ValueError(f"confirmation manifest lacks design metadata: {path}")
        if design.get("selection_used_test") is not False:
            raise ValueError(f"confirmation manifest is not test blind: {path}")
        if design.get("test_evaluation") is not True:
            raise ValueError(f"confirmation manifest does not enable test: {path}")
        if not isinstance(variants, list) or not variants:
            raise ValueError(f"confirmation manifest has no variants: {path}")
        names: list[str] = []
        for raw in variants:
            if not isinstance(raw, dict):
                raise ValueError(f"manifest variant is not an object: {path}")
            name = raw.get("name")
            if not isinstance(name, str):
                raise ValueError(f"invalid frozen run name: {name!r}")
            frozen = dict(raw)
            if frozen.pop("evaluate_test", None) is not True:
                raise ValueError(f"frozen variant does not enable test: {name}")
            prior = expected.get(name)
            if prior is not None:
                if not _is_fixed_split_size_replacement(
                    prior["config"], frozen
                ):
                    raise ValueError(
                        "duplicate frozen name is not the fixed-split size "
                        f"repair: {name}"
                    )
                superseded.append(
                    {
                        "missing_original_name": name,
                        "replacement_name": name,
                        "original_manifest_path": prior["manifest_path"],
                        "replacement_manifest_path": str(path),
                    }
                )
            expected[name] = {
                "config": frozen,
                "manifest_path": str(path),
            }
            names.append(name)
        manifest_records.append(
            {
                "path": str(path),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "variant_count": len(variants),
                "source_sha256_at_generation": manifest.get(
                    "source_sha256_at_generation"
                ),
                "selection_used_test": False,
                "test_evaluation": True,
                "variant_names": names,
            }
        )

    observed: dict[str, dict[str, Any]] = {}
    for root in roots:
        if not root.is_dir():
            raise FileNotFoundError(root)
        for directory in sorted(path for path in root.iterdir() if path.is_dir()):
            config_path = directory / "config.json"
            status_path = directory / "status.json"
            if not config_path.is_file() or not status_path.is_file():
                continue
            config = _object(config_path)
            status = _object(status_path)
            name = config.get("name")
            if not isinstance(name, str) or name not in expected:
                raise ValueError(
                    f"receipt is absent from frozen manifests: {directory}"
                )
            if name in observed:
                raise ValueError(f"duplicate frozen receipt name: {name}")
            if config != expected[name]["config"]:
                raise ValueError(f"receipt differs from frozen config: {name}")
            if status.get("status") != "complete":
                raise ValueError(
                    f"included confirmation receipt is not complete: {name}"
                )
            summary_path = directory / "summary.json"
            if not summary_path.is_file() or not isinstance(
                _object(summary_path).get("test"), Mapping
            ):
                raise ValueError(f"completed frozen receipt lacks test metrics: {name}")
            observed[name] = {
                "config": config,
                "run_directory": str(directory),
                "manifest_path": expected[name]["manifest_path"],
            }

    missing = sorted(set(expected) - set(observed))
    replacements: list[dict[str, Any]] = list(superseded)
    if missing:
        raise ValueError(
            "frozen manifest variants lack completed receipts: "
            + ", ".join(missing[:5])
        )

    if len(replacements) != allowed_replaced_variant_count:
        raise ValueError(
            "frozen manifest coverage mismatch: "
            f"expected {allowed_replaced_variant_count} replaced variants, "
            f"found {len(replacements)}"
        )

    for record in manifest_records:
        record["completed_variant_count"] = sum(
            name in observed
            and expected[name]["manifest_path"] == record["path"]
            for name in record.pop("variant_names")
        )
        record["replaced_variant_count"] = record["variant_count"] - record[
            "completed_variant_count"
        ]
    return {
        "status": "verified_frozen_manifest_identity",
        "selection_used_test": False,
        "run_root_count": len(roots),
        "manifest_count": len(manifests),
        "frozen_variant_count": sum(
            int(record["variant_count"]) for record in manifest_records
        ),
        "unique_frozen_run_name_count": len(expected),
        "completed_run_count": len(observed),
        "replaced_variant_count": len(replacements),
        "manifests": manifest_records,
        "replacements": replacements,
    }


def completed_confirmation_rows(
    run_roots: Iterable[Path],
) -> list[dict[str, Any]]:
    """Load only clean, complete runs containing a sealed test evaluation."""

    rows: list[dict[str, Any]] = []
    seen: set[Path] = set()
    for root in run_roots:
        resolved_root = root.resolve()
        if not resolved_root.is_dir():
            raise FileNotFoundError(resolved_root)
        directories = sorted(path for path in resolved_root.iterdir() if path.is_dir())
        for directory in directories:
            resolved = directory.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            paths = {
                name: directory / f"{name}.json"
                for name in ("status", "config", "environment", "summary")
            }
            paths["curve"] = directory / "learning_curve.jsonl"
            if not all(path.is_file() for path in paths.values()):
                continue
            status = _object(paths["status"])
            if status.get("status") != "complete":
                continue
            config = _object(paths["config"])
            environment = _object(paths["environment"])
            summary = _object(paths["summary"])
            if environment.get("git_dirty") is not False:
                raise ValueError(f"confirmation run was not clean: {directory}")
            test = summary.get("test")
            if not isinstance(test, dict):
                raise ValueError(f"confirmation run lacks test metrics: {directory}")
            regret = test.get("normalized_mean_regret")
            if not isinstance(regret, (int, float)) or isinstance(regret, bool):
                raise ValueError(
                    f"confirmation run lacks normalized regret: {directory}"
                )
            if not math.isfinite(float(regret)):
                raise ValueError(f"confirmation run has non-finite regret: {directory}")
            seeds = config.get("seeds")
            if not isinstance(seeds, dict):
                raise ValueError(f"confirmation run lacks seeds: {directory}")
            sizes = config.get("sizes")
            if not isinstance(sizes, dict):
                raise ValueError(f"confirmation run lacks split sizes: {directory}")
            configured_test_size = sizes.get("test")
            sample_count = test.get("sample_count")
            if (
                not isinstance(configured_test_size, int)
                or isinstance(configured_test_size, bool)
                or not isinstance(sample_count, int)
                or isinstance(sample_count, bool)
                or sample_count != configured_test_size
            ):
                raise ValueError(
                    f"confirmation test sample count disagrees with config: {directory}"
                )
            source = environment.get("source_sha256")
            if not isinstance(source, str) or len(source) != 64:
                raise ValueError(f"confirmation run lacks source hash: {directory}")
            oracle = summary.get(
                "whole_pipeline_training_oracle_stats",
                summary.get("total_training_oracle_stats", {}),
            )
            validation_oracle = _validation_oracle_totals(paths["curve"])
            test_oracle = test.get("oracle_stats")
            if not isinstance(test_oracle, dict):
                raise ValueError(f"confirmation test lacks oracle stats: {directory}")
            timing = {
                key: None if summary.get(key) is None else float(summary[key])
                for key in (
                    "optimization_wall_seconds",
                    "validation_wall_seconds",
                    "test_evaluation_wall_seconds",
                )
            }
            rows.append(
                {
                    "benchmark_id": config.get("benchmark_id"),
                    "route_id": experimental_route_id(config),
                    "physical_dataset_id": physical_dataset_id(config),
                    "family_id": benchmark_family_id(config),
                    "method": config.get("method"),
                    "method_parameters": config.get("method_parameters", {}),
                    "git_commit": environment.get("git_commit"),
                    "seed_key": tuple(
                        sorted((str(key), int(value)) for key, value in seeds.items())
                    ),
                    "test_normalized_mean_regret": float(regret),
                    "test_mean_regret": float(test["mean_regret"]),
                    "test_sample_count": sample_count,
                    "training_wall_seconds": float(
                        summary.get(
                            "whole_pipeline_training_wall_seconds",
                            summary["training_wall_seconds"],
                        )
                    ),
                    "training_oracle_calls": int(oracle.get("calls", 0)),
                    "training_solver_seconds": float(oracle.get("solver_seconds", 0.0)),
                    "validation_checkpoint_count": int(
                        validation_oracle["checkpoints"]
                    ),
                    "validation_oracle_calls": int(validation_oracle["calls"]),
                    "validation_oracle_failures": int(
                        validation_oracle["failures"]
                    ),
                    "validation_solver_seconds": float(
                        validation_oracle["solver_seconds"]
                    ),
                    "test_oracle_calls": int(test_oracle.get("calls", 0)),
                    "test_oracle_failures": int(test_oracle.get("failures", 0)),
                    "test_solver_seconds": float(
                        test_oracle.get("solver_seconds", 0.0)
                    ),
                    **timing,
                    "run_directory": str(directory),
                    "source_sha256": source,
                }
            )
    if not rows:
        raise ValueError("no completed confirmation runs found")
    return rows


def _mean_interval(values: Sequence[float]) -> dict[str, float | int | None]:
    if not values:
        raise ValueError("cannot summarize an empty sample")
    mean = fmean(values)
    if len(values) == 1:
        deviation = 0.0
        lower = upper = None
    else:
        deviation = stdev(values)
        half_width = (
            float(stats.t.ppf(0.975, len(values) - 1))
            * deviation
            / math.sqrt(len(values))
        )
        lower = mean - half_width
        upper = mean + half_width
    return {
        "count": len(values),
        "mean": mean,
        "median": median(values),
        "sample_standard_deviation": deviation,
        "ci95_lower": lower,
        "ci95_upper": upper,
    }


def _optional_mean_interval(
    values: Sequence[float | None],
) -> dict[str, float | int | None] | None:
    """Summarize a timing field only when every paired receipt records it."""

    if all(value is None for value in values):
        return None
    if any(value is None for value in values):
        raise ValueError("timing instrumentation differs across paired seeds")
    return _mean_interval([float(value) for value in values if value is not None])


def _wilcoxon_pvalue(differences: Sequence[float]) -> float:
    if not differences or all(abs(value) <= 1e-15 for value in differences):
        return 1.0
    return float(
        stats.wilcoxon(
            differences,
            alternative="two-sided",
            zero_method="pratt",
        ).pvalue
    )


def _replication_seed_key(
    seed_key: tuple[tuple[str, int], ...],
) -> tuple[tuple[str, int], ...]:
    """Drop route-defining structure while retaining paired replication RNGs."""

    result = tuple(item for item in seed_key if item[0] != "structural")
    if not result:
        raise ValueError("confirmation seed bundle has no replication seeds")
    return result


def _holm_adjust(
    comparisons: list[dict[str, Any]], *, output_key: str
) -> None:
    ordered = sorted(
        enumerate(comparisons), key=lambda item: float(item[1]["pvalue_raw"])
    )
    running = 0.0
    count = len(ordered)
    for rank, (index, comparison) in enumerate(ordered):
        adjusted = min(1.0, (count - rank) * float(comparison["pvalue_raw"]))
        running = max(running, adjusted)
        comparisons[index][output_key] = running


def _family_paired_target_comparisons(
    route_seed_regrets: dict[str, dict[str, dict[tuple[tuple[str, int], ...], float]]],
    route_metadata: dict[str, tuple[str, str, str]],
    *,
    target_method: str,
) -> list[dict[str, Any]]:
    """Aggregate paired route regrets without treating ladders as independent.

    Each shared seed first averages representation variants within one physical
    data law and then gives every data law equal family weight. Inference is
    performed over those paired seed-level family averages. Comparator coverage
    is explicit because expensive controls are intentionally absent on some
    routes.
    """

    routes_by_family: dict[str, list[str]] = defaultdict(list)
    for route, (_, family, _) in route_metadata.items():
        routes_by_family[family].append(route)
    families: list[dict[str, Any]] = []
    for family, routes in sorted(routes_by_family.items()):
        comparator_methods = sorted(
            {
                method
                for route in routes
                for method in route_seed_regrets[route]
                if method != target_method
            }
        )
        comparisons: list[dict[str, Any]] = []
        for comparator_method in comparator_methods:
            common_routes = sorted(
                route
                for route in routes
                if target_method in route_seed_regrets[route]
                and comparator_method in route_seed_regrets[route]
            )
            if not common_routes:
                continue
            seed_sets = {
                tuple(sorted(route_seed_regrets[route][method]))
                for route in common_routes
                for method in (target_method, comparator_method)
            }
            if len(seed_sets) != 1:
                raise ValueError(
                    f"confirmation seeds differ within family {family} for "
                    f"{target_method}/{comparator_method}"
                )
            seed_keys = next(iter(seed_sets))
            routes_by_physical_dataset: dict[str, list[str]] = defaultdict(list)
            for route in common_routes:
                routes_by_physical_dataset[route_metadata[route][2]].append(route)
            physical_datasets = sorted(routes_by_physical_dataset)

            def _seed_average(
                method: str,
                seed: tuple[tuple[str, int], ...],
                routes_by_dataset: dict[str, list[str]] = routes_by_physical_dataset,
                datasets: list[str] = physical_datasets,
            ) -> float:
                return fmean(
                    fmean(
                        route_seed_regrets[route][method][seed]
                        for route in routes_by_dataset[dataset]
                    )
                    for dataset in datasets
                )

            target_values = [
                _seed_average(target_method, seed) for seed in seed_keys
            ]
            comparator_values = [
                _seed_average(comparator_method, seed) for seed in seed_keys
            ]
            differences = [
                target - comparator
                for target, comparator in zip(
                    target_values, comparator_values, strict=True
                )
            ]
            comparisons.append(
                {
                    "target_method": target_method,
                    "comparator_method": comparator_method,
                    "difference_definition": (
                        "equal_physical_dataset_weighted_family_target_minus_comparator"
                    ),
                    "common_route_count": len(common_routes),
                    "common_route_ids": common_routes,
                    "common_physical_dataset_count": len(physical_datasets),
                    "common_physical_dataset_ids": physical_datasets,
                    "paired_seed_count": len(seed_keys),
                    "target_normalized_regret": _mean_interval(target_values),
                    "comparator_normalized_regret": _mean_interval(comparator_values),
                    "difference": _mean_interval(differences),
                    "target_wins": sum(value < -1e-12 for value in differences),
                    "ties": sum(abs(value) <= 1e-12 for value in differences),
                    "target_losses": sum(value > 1e-12 for value in differences),
                    "pvalue_raw": _wilcoxon_pvalue(differences),
                }
            )
        _holm_adjust(
            comparisons, output_key="pvalue_holm_within_family_comparators"
        )
        families.append(
            {
                "family_id": family,
                "route_count": len(routes),
                "route_ids": sorted(routes),
                "physical_dataset_count": len(
                    {route_metadata[route][2] for route in routes}
                ),
                "paired_target_comparisons": comparisons,
            }
        )
    by_comparator: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for family_record in families:
        for comparison in family_record["paired_target_comparisons"]:
            by_comparator[str(comparison["comparator_method"])].append(comparison)
    for comparisons in by_comparator.values():
        _holm_adjust(
            comparisons,
            output_key="pvalue_holm_across_families_for_comparator",
        )
    return families


def summarize_confirmation(
    run_roots: Iterable[Path],
    *,
    target_method: str = "soft_radial_log_barrier",
    required_seed_count: int = 10,
    manifest_paths: Iterable[Path] | None = None,
    allowed_replaced_variant_count: int = 0,
) -> dict[str, Any]:
    """Produce benchmark-level estimates and paired target comparisons."""

    roots = [Path(root) for root in run_roots]
    manifest_identity = None
    if manifest_paths is not None:
        manifest_identity = verify_confirmation_manifests(
            roots,
            manifest_paths,
            allowed_replaced_variant_count=allowed_replaced_variant_count,
        )
    rows = completed_confirmation_rows(roots)
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        route = row["route_id"]
        method = row["method"]
        if not isinstance(route, str) or not isinstance(method, str):
            raise ValueError("confirmation config lacks route or method")
        grouped[(route, method)].append(row)

    by_route: dict[str, list[dict[str, Any]]] = defaultdict(list)
    route_seed_regrets: dict[
        str, dict[str, dict[tuple[tuple[str, int], ...], float]]
    ] = defaultdict(dict)
    route_metadata: dict[str, tuple[str, str, str]] = {}
    for (route, method), method_rows in sorted(grouped.items()):
        seed_keys = [row["seed_key"] for row in method_rows]
        if (
            len(method_rows) != required_seed_count
            or len(set(seed_keys)) != required_seed_count
        ):
            raise ValueError(
                f"incomplete confirmation {route}/{method}: expected "
                f"{required_seed_count} distinct paired seeds"
            )
        ordered = sorted(method_rows, key=lambda row: row["seed_key"])
        sample_counts = {int(row["test_sample_count"]) for row in ordered}
        if len(sample_counts) != 1:
            raise ValueError(
                f"confirmation test sizes differ across seeds on {route}/{method}"
            )
        route_metadata[route] = (
            str(ordered[0]["benchmark_id"]),
            str(ordered[0]["family_id"]),
            str(ordered[0]["physical_dataset_id"]),
        )
        route_seed_regrets[route][method] = {
            _replication_seed_key(row["seed_key"]): row["test_normalized_mean_regret"]
            for row in ordered
        }
        if len(route_seed_regrets[route][method]) != len(ordered):
            raise ValueError(
                f"replication seeds are not unique after removing structural "
                f"seed on {route}/{method}"
            )
        timing_summaries = {
            key: _optional_mean_interval([row[key] for row in ordered])
            for key in (
                "optimization_wall_seconds",
                "validation_wall_seconds",
                "test_evaluation_wall_seconds",
            )
        }
        by_route[route].append(
            {
                "method": method,
                "test_sample_count_per_seed": sample_counts.pop(),
                "seed_keys": [row["seed_key"] for row in ordered],
                "regrets": [row["test_normalized_mean_regret"] for row in ordered],
                "normalized_regret": _mean_interval(
                    [row["test_normalized_mean_regret"] for row in ordered]
                ),
                "training_wall_seconds": _mean_interval(
                    [row["training_wall_seconds"] for row in ordered]
                ),
                "training_oracle_calls": _mean_interval(
                    [float(row["training_oracle_calls"]) for row in ordered]
                ),
                "training_solver_seconds": _mean_interval(
                    [row["training_solver_seconds"] for row in ordered]
                ),
                "validation_checkpoint_count": _mean_interval(
                    [float(row["validation_checkpoint_count"]) for row in ordered]
                ),
                "validation_oracle_calls": _mean_interval(
                    [float(row["validation_oracle_calls"]) for row in ordered]
                ),
                "validation_oracle_failures": _mean_interval(
                    [float(row["validation_oracle_failures"]) for row in ordered]
                ),
                "validation_solver_seconds": _mean_interval(
                    [row["validation_solver_seconds"] for row in ordered]
                ),
                "test_oracle_calls": _mean_interval(
                    [float(row["test_oracle_calls"]) for row in ordered]
                ),
                "test_oracle_failures": _mean_interval(
                    [float(row["test_oracle_failures"]) for row in ordered]
                ),
                "test_solver_seconds": _mean_interval(
                    [row["test_solver_seconds"] for row in ordered]
                ),
                **{
                    key: value
                    for key, value in timing_summaries.items()
                    if value is not None
                },
                "run_directories": [row["run_directory"] for row in ordered],
            }
        )

    results: list[dict[str, Any]] = []
    wins: Counter[str] = Counter()
    family_routes: dict[str, list[str]] = defaultdict(list)
    for route, methods in sorted(by_route.items()):
        seed_sets = {tuple(row["seed_keys"]) for row in methods}
        if len(seed_sets) != 1:
            raise ValueError(f"confirmation methods are not paired on {route}")
        ordered_methods = sorted(
            methods,
            key=lambda row: (
                float(row["normalized_regret"]["mean"]),
                str(row["method"]),
            ),
        )
        winner = str(ordered_methods[0]["method"])
        wins[winner] += 1
        target = next((row for row in methods if row["method"] == target_method), None)
        comparisons: list[dict[str, Any]] = []
        if target is not None:
            for comparator in sorted(methods, key=lambda row: str(row["method"])):
                if comparator is target:
                    continue
                differences = [
                    float(target_value) - float(comparator_value)
                    for target_value, comparator_value in zip(
                        target["regrets"], comparator["regrets"], strict=True
                    )
                ]
                comparisons.append(
                    {
                        "target_method": target_method,
                        "comparator_method": comparator["method"],
                        "difference_definition": "target_minus_comparator",
                        "difference": _mean_interval(differences),
                        "target_wins": sum(value < -1e-12 for value in differences),
                        "ties": sum(abs(value) <= 1e-12 for value in differences),
                        "target_losses": sum(value > 1e-12 for value in differences),
                        "pvalue_raw": _wilcoxon_pvalue(differences),
                    }
                )
            _holm_adjust(
                comparisons, output_key="pvalue_holm_within_benchmark"
            )
        for row in ordered_methods:
            row.pop("regrets")
            row.pop("seed_keys")
        results.append(
            {
                "route_id": route,
                "benchmark_id": route_metadata[route][0],
                "family_id": route_metadata[route][1],
                "physical_dataset_id": route_metadata[route][2],
                "winner_by_mean_normalized_regret": winner,
                "methods": ordered_methods,
                "paired_target_comparisons": comparisons,
            }
        )
        family_routes[route_metadata[route][1]].append(route)

    family_comparisons = _family_paired_target_comparisons(
        route_seed_regrets,
        route_metadata,
        target_method=target_method,
    )
    method_coverage = [
        {
            "method": method,
            "route_count": sum(
                method in route_methods for route_methods in route_seed_regrets.values()
            ),
            "family_count": len(
                {
                    route_metadata[route][1]
                    for route, route_methods in route_seed_regrets.items()
                    if method in route_methods
                }
            ),
            "route_ids": sorted(
                route
                for route, route_methods in route_seed_regrets.items()
                if method in route_methods
            ),
        }
        for method in sorted(
            {
                method
                for route_methods in route_seed_regrets.values()
                for method in route_methods
            }
        )
    ]
    runtime_by_method: dict[str, dict[str, float]] = defaultdict(
        lambda: {
            "route_count": 0.0,
            "fit_validation_test_wall_seconds": 0.0,
            "optimization_wall_seconds": 0.0,
            "optimization_wall_seconds_route_count": 0.0,
            "validation_wall_seconds": 0.0,
            "validation_wall_seconds_route_count": 0.0,
            "test_evaluation_wall_seconds": 0.0,
            "test_evaluation_wall_seconds_route_count": 0.0,
            "training_oracle_calls": 0.0,
            "validation_oracle_calls": 0.0,
            "test_oracle_calls": 0.0,
            "training_solver_seconds": 0.0,
            "validation_solver_seconds": 0.0,
            "test_solver_seconds": 0.0,
        }
    )
    for benchmark in results:
        for method in benchmark["methods"]:
            aggregate = runtime_by_method[str(method["method"])]
            aggregate["route_count"] += 1.0
            aggregate["fit_validation_test_wall_seconds"] += float(
                method["training_wall_seconds"]["mean"]
            )
            for key in (
                "optimization_wall_seconds",
                "validation_wall_seconds",
                "test_evaluation_wall_seconds",
            ):
                timing = method.get(key)
                if isinstance(timing, Mapping):
                    aggregate[key] += float(timing["mean"])
                    aggregate[f"{key}_route_count"] += 1.0
            for key in (
                "training_oracle_calls",
                "validation_oracle_calls",
                "test_oracle_calls",
                "training_solver_seconds",
                "validation_solver_seconds",
                "test_solver_seconds",
            ):
                aggregate[key] += float(method[key]["mean"])
    method_runtime_accounting = [
        {
            "method": method,
            "route_count": int(values["route_count"]),
            **{
                key: (
                    None
                    if key
                    in {
                        "optimization_wall_seconds",
                        "validation_wall_seconds",
                        "test_evaluation_wall_seconds",
                    }
                    and values[f"{key}_route_count"] != values["route_count"]
                    else value
                )
                for key, value in values.items()
                if key != "route_count" and not key.endswith("_route_count")
            },
        }
        for method, values in sorted(runtime_by_method.items())
    ]

    return {
        "status": "paired_test_confirmation",
        "selection_used_test": (
            False if manifest_identity is not None else None
        ),
        "test_evaluated": True,
        "target_method": target_method,
        "required_seed_count": required_seed_count,
        "benchmark_count": len(results),
        "native_benchmark_count": len({str(row["benchmark_id"]) for row in rows}),
        "family_count": len(family_routes),
        "family_routes": dict(sorted(family_routes.items())),
        "completed_run_count": len(rows),
        "descriptive_method_win_counts": dict(sorted(wins.items())),
        "source_sha256_values": sorted({row["source_sha256"] for row in rows}),
        "run_roots": [str(root.resolve()) for root in roots],
        "manifest_identity": manifest_identity,
        "benchmarks": results,
        "method_coverage": method_coverage,
        "method_runtime_accounting": method_runtime_accounting,
        "family_paired_target_comparisons": family_comparisons,
        "evidence_boundary": (
            "Win counts across related benchmark variants are descriptive, not "
            "independent-family hypothesis tests. Route-level paired inference "
            "is reported within each benchmark; family-level comparisons first "
            "average representation routes within each physical data law and "
            "then average physical laws within each paired seed."
        ),
    }


def render_confirmation_markdown(summary: dict[str, Any]) -> str:
    def seconds(value: Any) -> str:
        return "n/a" if value is None else f"{float(value):.3f}"

    lines = [
        "# Paired publication confirmation",
        "",
        (
            f"{summary['completed_run_count']} clean test runs across "
            f"{summary['benchmark_count']} benchmarks, with "
            f"{summary['required_seed_count']} paired seeds per method."
        ),
    ]
    notes = summary.get("additional_evidence_notes", [])
    if notes:
        lines.extend(["", "## Panel-specific evidence notes", ""])
        lines.extend(f"- {note}" for note in notes)
    lines.extend(
        [
            "",
            (
            "| Benchmark | Rank | Method | Test n/seed | "
            "Mean normalized regret | 95% CI | Fit+validation+test s |"
            ),
            "|---|---:|---|---:|---:|---:|---:|",
        ]
    )
    for benchmark in summary["benchmarks"]:
        for rank, method in enumerate(benchmark["methods"], start=1):
            regret = method["normalized_regret"]
            lower = regret["ci95_lower"]
            upper = regret["ci95_upper"]
            interval = (
                "n/a"
                if lower is None or upper is None
                else f"[{lower:.6g}, {upper:.6g}]"
            )
            lines.append(
                f"| {benchmark['route_id']} | {rank} | {method['method']} | "
                f"{method['test_sample_count_per_seed']} | "
                f"{regret['mean']:.6g} | {interval} | "
                f"{method['training_wall_seconds']['mean']:.3f} |"
            )
    lines.extend(
        [
            "",
            "## Family-clustered target comparisons",
            "",
            (
                "Each row first averages representation routes within each "
                "physical data law, then gives every physical data law equal "
                "weight within the family for each paired seed."
            ),
            "",
            (
                "| Family | Comparator | Physical laws / routes | "
                "Target - comparator | 95% CI | W/T/L | "
                "Within-family comparator-Holm p | Across-family Holm p |"
            ),
            "|---|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for family in summary["family_paired_target_comparisons"]:
        for comparison in family["paired_target_comparisons"]:
            difference = comparison["difference"]
            lower = difference["ci95_lower"]
            upper = difference["ci95_upper"]
            interval = (
                "n/a"
                if lower is None or upper is None
                else f"[{lower:.6g}, {upper:.6g}]"
            )
            lines.append(
                f"| {family['family_id']} | {comparison['comparator_method']} | "
                f"{comparison['common_physical_dataset_count']} / "
                f"{comparison['common_route_count']} | "
                f"{difference['mean']:.6g} | {interval} | "
                f"{comparison['target_wins']}/{comparison['ties']}/"
                f"{comparison['target_losses']} | "
                f"{comparison['pvalue_holm_within_family_comparators']:.6g} | "
                f"{comparison['pvalue_holm_across_families_for_comparator']:.6g} |"
            )
    lines.extend(
        [
            "",
            "## Method coverage",
            "",
            "| Method | Routes | Families |",
            "|---|---:|---:|",
        ]
    )
    for coverage in summary["method_coverage"]:
        lines.append(
            f"| {coverage['method']} | {coverage['route_count']} | "
            f"{coverage['family_count']} |"
        )
    lines.extend(
        [
            "",
            "## Runtime and oracle accounting",
            "",
            (
                "Each row sums per-route means for one representative paired "
                "replication. The total wall clock begins at fitting and includes "
                "checkpoint validation plus final test evaluation; it excludes "
                "data/geometry preparation and hyperparameter-search compute. "
                "Component timers are reported separately. Route counts differ "
                "for runtime-gated controls."
            ),
            "",
            (
                "| Method | Routes | Fit+val+test s | Optimization s | "
                "Validation s | Test s | Train calls | Validation calls | "
                "Test calls | Solver s |"
            ),
            "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for accounting in summary["method_runtime_accounting"]:
        total_solver_seconds = sum(
            float(accounting[key])
            for key in (
                "training_solver_seconds",
                "validation_solver_seconds",
                "test_solver_seconds",
            )
        )
        lines.append(
            f"| {accounting['method']} | {accounting['route_count']} | "
            f"{accounting['fit_validation_test_wall_seconds']:.3f} | "
            f"{seconds(accounting['optimization_wall_seconds'])} | "
            f"{seconds(accounting['validation_wall_seconds'])} | "
            f"{seconds(accounting['test_evaluation_wall_seconds'])} | "
            f"{accounting['training_oracle_calls']:.0f} | "
            f"{accounting['validation_oracle_calls']:.0f} | "
            f"{accounting['test_oracle_calls']:.0f} | "
            f"{total_solver_seconds:.3f} |"
        )
    lines.extend(
        [
            "",
            "## Evidence boundary",
            "",
            f"- {summary['evidence_boundary']}",
            (
                "- Every included config is bound byte-for-byte (after removal of "
                "the runner-only `evaluate_test` flag) to the frozen manifests "
                "listed in `manifest_identity`."
                if summary.get("manifest_identity") is not None
                else "- Frozen-manifest identity was not verified for this receipt."
            ),
            (
                "- This means the final candidate builder did not read confirmation "
                "test metrics; it is not a claim of pristine first exposure to all "
                "benchmark families during the broader research process."
            ),
            "- All included runs record a clean git worktree and executable hash.",
            "",
        ]
    )
    return "\n".join(lines)
