"""Fixed-feasible-set LPs and partial random-cost interfaces."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, cast

import numpy as np
from numpy.typing import NDArray
from scipy.sparse import csc_matrix, diags, eye, vstack

FloatArray = NDArray[np.float64]
IntArray = NDArray[np.int64]


def _finite_vector(value: Any, size: int, name: str) -> FloatArray:
    result = np.asarray(value, dtype=np.float64)
    if result.shape != (size,) or not np.all(np.isfinite(result)):
        raise ValueError(f"{name} must be a finite vector of shape {(size,)}")
    return np.ascontiguousarray(result)


def has_full_row_rank(value: Any) -> bool:
    """Check row independence without factorizing coordinate selectors.

    Benchmark cost exposures are commonly identities, scaled identities, or
    coordinate selectors.  Recognizing those first avoids a dense SVD of, for
    example, a 1,200 by 1,200 identity during every configuration build.
    """

    matrix = np.asarray(value, dtype=np.float64)
    if matrix.ndim != 2 or matrix.shape[0] == 0:
        return False
    rows, columns = matrix.shape
    if rows > columns or not np.all(np.isfinite(matrix)):
        return False
    nonzero = matrix != 0.0
    if np.all(np.count_nonzero(nonzero, axis=1) == 1):
        support = np.argmax(nonzero, axis=1)
        return bool(np.unique(support).size == rows)
    return bool(np.linalg.matrix_rank(matrix) == rows)


@dataclass(frozen=True)
class LinearProblem:
    """A fixed feasible set ``lower <= A z <= upper`` plus variable bounds."""

    matrix: csc_matrix | FloatArray
    row_lower: FloatArray
    row_upper: FloatArray
    variable_lower: FloatArray
    variable_upper: FloatArray
    integrality: IntArray | None = None
    name: str = "linear_problem"
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        matrix = csc_matrix(self.matrix, dtype=np.float64)
        if matrix.ndim != 2 or matrix.shape[1] == 0:
            raise ValueError("matrix must have a positive number of columns")
        if matrix.data.size and not np.all(np.isfinite(matrix.data)):
            raise ValueError("matrix contains non-finite entries")
        m, n = matrix.shape
        row_lower = np.asarray(self.row_lower, dtype=np.float64)
        row_upper = np.asarray(self.row_upper, dtype=np.float64)
        variable_lower = np.asarray(self.variable_lower, dtype=np.float64)
        variable_upper = np.asarray(self.variable_upper, dtype=np.float64)
        if row_lower.shape != (m,) or row_upper.shape != (m,):
            raise ValueError("row bounds do not match matrix")
        if variable_lower.shape != (n,) or variable_upper.shape != (n,):
            raise ValueError("variable bounds do not match matrix")
        for name, vector in (
            ("row_lower", row_lower),
            ("row_upper", row_upper),
            ("variable_lower", variable_lower),
            ("variable_upper", variable_upper),
        ):
            if np.any(np.isnan(vector)):
                raise ValueError(f"{name} contains NaN")
        if np.any(row_lower > row_upper):
            raise ValueError("row lower bound exceeds upper bound")
        if np.any(variable_lower > variable_upper):
            raise ValueError("variable lower bound exceeds upper bound")
        if self.integrality is None:
            integrality = np.zeros(n, dtype=np.int64)
        else:
            integrality = np.asarray(self.integrality, dtype=np.int64)
            if integrality.shape != (n,) or not np.all(np.isin(integrality, (0, 1))):
                raise ValueError("integrality must be a length-n 0/1 vector")
        object.__setattr__(self, "matrix", matrix)
        object.__setattr__(self, "row_lower", row_lower)
        object.__setattr__(self, "row_upper", row_upper)
        object.__setattr__(self, "variable_lower", variable_lower)
        object.__setattr__(self, "variable_upper", variable_upper)
        object.__setattr__(self, "integrality", integrality)
        object.__setattr__(self, "metadata", MappingProxyType(dict(self.metadata)))

    @property
    def variable_count(self) -> int:
        return int(self.matrix.shape[1])

    @property
    def constraint_count(self) -> int:
        return int(self.matrix.shape[0])

    @property
    def is_continuous(self) -> bool:
        return not np.any(self.integrality)

    def continuous_relaxation(self, *, name: str | None = None) -> LinearProblem:
        """Drop integrality while preserving the complete linear formulation."""

        metadata = dict(self.metadata)
        metadata.update(
            {
                "continuous_relaxation": True,
                "relaxed_integer_variable_count": int(
                    np.sum(cast(IntArray, self.integrality))
                ),
                "hard_problem_name": self.name,
            }
        )
        return LinearProblem(
            matrix=self.matrix,
            row_lower=self.row_lower,
            row_upper=self.row_upper,
            variable_lower=self.variable_lower,
            variable_upper=self.variable_upper,
            integrality=np.zeros(self.variable_count, dtype=np.int64),
            name=name or f"{self.name}.continuous_relaxation",
            metadata=metadata,
        )

    @property
    def osqp_matrix(self) -> csc_matrix:
        """Constraints including variable bounds, in OSQP form."""

        return csc_matrix(vstack([self.matrix, eye(self.variable_count, format="csc")]))

    @property
    def osqp_lower(self) -> FloatArray:
        return np.concatenate([self.row_lower, self.variable_lower])

    @property
    def osqp_upper(self) -> FloatArray:
        return np.concatenate([self.row_upper, self.variable_upper])

    def row_normalized(self) -> LinearProblem:
        """Return an exactly equivalent problem with unit-norm nonzero rows."""

        matrix = csc_matrix(self.matrix)
        squared = np.asarray(matrix.power(2).sum(axis=1)).reshape(-1)
        norms = np.sqrt(squared)
        scales = np.where(norms > 1e-14, norms, 1.0)
        inverse = diags(1.0 / scales, format="csc")
        metadata = dict(self.metadata)
        nonzero = norms[norms > 1e-14]
        metadata["row_normalization"] = {
            "minimum_nonzero_norm": (float(np.min(nonzero)) if nonzero.size else None),
            "maximum_norm": float(np.max(norms)) if norms.size else 0.0,
            "zero_rows": int(np.sum(norms <= 1e-14)),
        }
        return LinearProblem(
            matrix=inverse @ matrix,
            row_lower=self.row_lower / scales,
            row_upper=self.row_upper / scales,
            variable_lower=self.variable_lower,
            variable_upper=self.variable_upper,
            integrality=self.integrality,
            name=f"{self.name}.row_normalized",
            metadata=metadata,
        )


@dataclass(frozen=True)
class PartialCostInterface:
    """Physical costs ``c = fixed_cost + statistic.T @ coefficient``."""

    problem: LinearProblem
    fixed_cost: FloatArray
    statistic: FloatArray
    name: str = "partial_cost"

    def __post_init__(self) -> None:
        n = self.problem.variable_count
        fixed = _finite_vector(self.fixed_cost, n, "fixed_cost")
        statistic = np.asarray(self.statistic, dtype=np.float64)
        if statistic.ndim != 2 or statistic.shape[1] != n:
            raise ValueError("statistic must have shape (report_dimension, n)")
        if statistic.shape[0] == 0 or not np.all(np.isfinite(statistic)):
            raise ValueError("statistic must be finite with at least one row")
        if not has_full_row_rank(statistic):
            raise ValueError("statistic rows must be linearly independent")
        object.__setattr__(self, "fixed_cost", fixed)
        object.__setattr__(self, "statistic", np.ascontiguousarray(statistic))

    @property
    def report_dimension(self) -> int:
        return int(self.statistic.shape[0])

    def physical_cost(self, coefficient: FloatArray) -> FloatArray:
        coefficient = np.asarray(coefficient, dtype=np.float64)
        if coefficient.shape[-1] != self.report_dimension:
            raise ValueError("coefficient has the wrong trailing dimension")
        return self.fixed_cost + coefficient @ self.statistic

    @classmethod
    def full_cost(cls, problem: LinearProblem) -> PartialCostInterface:
        return cls(
            problem=problem,
            fixed_cost=np.zeros(problem.variable_count),
            statistic=np.eye(problem.variable_count),
            name="full_cost",
        )

    @classmethod
    def selected_coordinates(
        cls,
        problem: LinearProblem,
        fixed_physical_cost: FloatArray,
        random_indices: NDArray[np.int64] | list[int],
    ) -> PartialCostInterface:
        indices = np.asarray(random_indices, dtype=np.int64)
        if (
            indices.ndim != 1
            or indices.size == 0
            or len(set(indices.tolist())) != indices.size
        ):
            raise ValueError("random_indices must be a nonempty unique vector")
        if np.any(indices < 0) or np.any(indices >= problem.variable_count):
            raise ValueError("random index outside physical cost")
        fixed = _finite_vector(
            fixed_physical_cost, problem.variable_count, "fixed_physical_cost"
        ).copy()
        fixed[indices] = 0.0
        statistic = np.eye(problem.variable_count)[indices]
        return cls(problem, fixed, statistic, name=f"selected_{indices.size}")
