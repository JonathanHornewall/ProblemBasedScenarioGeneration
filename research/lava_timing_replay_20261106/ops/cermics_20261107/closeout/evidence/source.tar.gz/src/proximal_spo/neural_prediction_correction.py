"""Neural decision-preserving cost correction over frozen DFL decisions.

The module deliberately separates three objects:

* a DFL model chooses the deployed decision and is never changed here;
* an ordinary MSE network estimates the statistically meaningful cost;
* a correction map returns the closest useful cost inside the selected
  decision's normal cone.

The corrected cost is an explanatory sidecar.  It is not fed back to the
deployed optimizer.  All fitted models use context--scenario pairs only and
are selected by validation scenario MSE.
"""

from __future__ import annotations

import copy
import math
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, cast

import numpy as np
import torch
from scipy.optimize import nnls
from torch import nn

from .models import (
    ModelSpec,
    StandardizedMLP,
    input_statistics,
    module_dtype,
    torch_dtype,
)
from .prediction_correction import (
    CorrectionPrediction,
    CorrectionSplit,
    DecisionInvariantGeometry,
)
from .problem import FloatArray, PartialCostInterface


@dataclass(frozen=True)
class NeuralCorrectionSplit:
    correction: CorrectionSplit
    mse_hidden_features: FloatArray
    mse_physical_costs: FloatArray

    def __post_init__(self) -> None:
        rows = len(self.correction.contexts)
        if (
            np.asarray(self.mse_hidden_features).ndim != 2
            or len(self.mse_hidden_features) != rows
        ):
            raise ValueError("MSE hidden features have the wrong shape")
        expected = (rows, self.correction.observed_costs.shape[1])
        if np.asarray(self.mse_physical_costs).shape != expected:
            raise ValueError("MSE physical costs have the wrong shape")


def _state(model: nn.Module) -> dict[str, torch.Tensor]:
    return {
        name: value.detach().cpu().clone() for name, value in model.state_dict().items()
    }


def _batches(rows: int, batch_size: int, seed: int) -> list[np.ndarray]:
    order = np.random.Generator(np.random.PCG64(seed)).permutation(rows)
    return [order[start : start + batch_size] for start in range(0, rows, batch_size)]


def fit_pair_mse_network(
    *,
    train_contexts: FloatArray,
    train_coefficients: FloatArray,
    validation_contexts: FloatArray,
    validation_coefficients: FloatArray,
    model_spec: ModelSpec,
    learning_rate: float,
    epochs: int,
    batch_size: int,
    patience: int,
    weight_decay: float,
    initialization_seed: int,
    shuffle_seed: int,
) -> tuple[StandardizedMLP, dict[str, Any]]:
    """Fit a conventional MSE cost network without any solver calls."""

    started = time.perf_counter()
    cpu_started = time.process_time()
    mean, scale = input_statistics(train_contexts)
    torch.manual_seed(initialization_seed)
    model = StandardizedMLP(
        np.asarray(train_contexts).shape[1],
        np.asarray(train_coefficients).shape[1],
        model_spec,
        input_mean=mean,
        input_scale=scale,
        output_bias=np.asarray(train_coefficients).mean(axis=0),
    )
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=learning_rate, weight_decay=weight_decay
    )
    dtype = torch_dtype(model_spec.dtype)
    x_train = torch.as_tensor(train_contexts, dtype=dtype)
    y_train = torch.as_tensor(train_coefficients, dtype=dtype)
    x_validation = torch.as_tensor(validation_contexts, dtype=dtype)
    y_validation = torch.as_tensor(validation_coefficients, dtype=dtype)

    best_state = _state(model)
    best_epoch = 0
    with torch.no_grad():
        best_validation = float(
            torch.mean((model(x_validation) - y_validation) ** 2).item()
        )
    stale = 0
    epochs_completed = 0
    curve: list[dict[str, float | int]] = [
        {"epoch": 0, "validation_scenario_mse_per_coordinate": best_validation}
    ]
    for epoch in range(1, epochs + 1):
        model.train()
        for indices in _batches(len(x_train), batch_size, shuffle_seed + epoch):
            batch = torch.as_tensor(indices, dtype=torch.long)
            optimizer.zero_grad(set_to_none=True)
            residual = model(x_train[batch]) - y_train[batch]
            loss = 0.5 * torch.mean(torch.sum(residual**2, dim=1))
            loss.backward()  # type: ignore[no-untyped-call]
            torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0)
            optimizer.step()
        epochs_completed = epoch
        if epoch % 5 != 0 and epoch != epochs:
            continue
        model.eval()
        with torch.no_grad():
            value = float(torch.mean((model(x_validation) - y_validation) ** 2).item())
        curve.append({"epoch": epoch, "validation_scenario_mse_per_coordinate": value})
        if value < best_validation - 1e-9:
            best_validation = value
            best_epoch = epoch
            best_state = _state(model)
            stale = 0
        else:
            stale += 1
            if stale >= patience:
                break
    model.load_state_dict(best_state)
    return model, {
        "selection": "validation scenario coefficient MSE",
        "best_epoch": best_epoch,
        "epochs_completed": epochs_completed,
        "best_validation_scenario_mse_per_coordinate": best_validation,
        "learning_rate": learning_rate,
        "training_wall_seconds": time.perf_counter() - started,
        "training_cpu_seconds": time.process_time() - cpu_started,
        "training_solver_calls": 0,
        "curve": curve,
    }


def mse_network_arrays(
    model: StandardizedMLP,
    contexts: FloatArray,
    interface: PartialCostInterface,
    *,
    batch_size: int,
) -> tuple[FloatArray, FloatArray, FloatArray]:
    outputs: list[np.ndarray] = []
    features: list[np.ndarray] = []
    dtype = module_dtype(model)
    model.eval()
    with torch.no_grad():
        for start in range(0, len(contexts), batch_size):
            x = torch.as_tensor(contexts[start : start + batch_size], dtype=dtype)
            features.append(model.features(x).cpu().numpy())
            outputs.append(model(x).cpu().numpy())
    coefficients = np.ascontiguousarray(np.concatenate(outputs, axis=0))
    hidden = np.ascontiguousarray(np.concatenate(features, axis=0))
    physical = np.ascontiguousarray(interface.physical_cost(coefficients))
    return coefficients, hidden, physical


def _combined_features(
    split: NeuralCorrectionSplit, geometry: DecisionInvariantGeometry
) -> FloatArray:
    correction = split.correction
    tangent = geometry.tangent_coordinates(correction.base_directions)
    norm = np.linalg.norm(tangent, axis=1)
    unit = tangent / np.maximum(norm[:, None], 1e-12)
    mask = geometry.active_mask(correction.base_decisions).astype(np.float64)
    return np.ascontiguousarray(
        np.column_stack(
            [
                correction.contexts,
                correction.hidden_features,
                split.mse_hidden_features,
                split.mse_physical_costs,
                correction.base_decisions,
                unit,
                np.log(np.maximum(norm, 1e-12)),
                mask,
            ]
        )
    )


class _ExactConeProjection(torch.autograd.Function):
    """Exact NNLS forward map with its a.e. active-face Jacobian."""

    @staticmethod
    def forward(
        ctx: Any,
        targets: torch.Tensor,
        masks: torch.Tensor,
        generator_rows: torch.Tensor,
    ) -> torch.Tensor:
        target_np = targets.detach().cpu().numpy()
        mask_np = masks.detach().cpu().numpy().astype(bool)
        generators_np = generator_rows.detach().cpu().numpy()
        outputs = np.zeros_like(target_np)
        jacobians = np.zeros(
            (len(target_np), target_np.shape[1], target_np.shape[1]),
            dtype=np.float64,
        )
        cache: dict[tuple[int, ...], np.ndarray] = {}
        for row, (target, mask) in enumerate(zip(target_np, mask_np, strict=True)):
            active = np.flatnonzero(mask)
            if len(active) == 0:
                continue
            matrix = generators_np[active].T
            keep = np.linalg.norm(matrix, axis=0) > 1e-12
            matrix = matrix[:, keep]
            if matrix.shape[1] == 0:
                continue
            coefficients, _ = nnls(
                matrix, target, maxiter=max(3 * matrix.shape[1], 100)
            )
            outputs[row] = matrix @ coefficients
            threshold = 1e-9 * max(float(np.max(coefficients, initial=0.0)), 1.0)
            positive = np.flatnonzero(coefficients > threshold)
            if len(positive) == 0:
                continue
            selected = matrix[:, positive]
            key = tuple(active[np.flatnonzero(keep)[positive]].tolist())
            jacobian = cache.get(key)
            if jacobian is None:
                jacobian = selected @ np.linalg.pinv(selected, rcond=1e-10)
                cache[key] = jacobian
            jacobians[row] = jacobian
        jacobian_tensor = torch.as_tensor(
            jacobians, dtype=targets.dtype, device=targets.device
        )
        ctx.save_for_backward(jacobian_tensor)
        return torch.as_tensor(outputs, dtype=targets.dtype, device=targets.device)

    @staticmethod
    def backward(ctx: Any, gradient: torch.Tensor) -> tuple[torch.Tensor, None, None]:
        (jacobians,) = ctx.saved_tensors
        target_gradient = torch.einsum("bij,bj->bi", jacobians, gradient)
        return target_gradient, None, None


class _CorrectionHead(nn.Module):
    def forward_costs(
        self,
        features: torch.Tensor,
        base_tangent: torch.Tensor,
        masks: torch.Tensor,
        mse_costs: torch.Tensor,
    ) -> torch.Tensor:
        raise NotImplementedError


class _RayGaugeHead(_CorrectionHead):
    tangent_basis: torch.Tensor
    normal_basis: torch.Tensor

    def __init__(
        self,
        *,
        input_dimension: int,
        model_spec: ModelSpec,
        input_mean: FloatArray,
        input_scale: FloatArray,
        geometry: DecisionInvariantGeometry,
        initial_scale: float,
        initial_gauge: FloatArray,
        minimum_scale: float,
    ) -> None:
        super().__init__()
        # DFL cost directions are scale-free and may be normalized extremely
        # differently from literal costs.  Learn the scale in log coordinates
        # so a perfectly benign ray projection cannot overflow initialization.
        raw_scale = math.log(max(initial_scale, 1e-12))
        bias = np.concatenate([[raw_scale], np.asarray(initial_gauge)])
        self.core = StandardizedMLP(
            input_dimension,
            1 + geometry.normal_dimension,
            model_spec,
            input_mean=input_mean,
            input_scale=input_scale,
            output_bias=bias,
        )
        self.register_buffer(
            "tangent_basis",
            torch.as_tensor(geometry.tangent_basis, dtype=torch.float64),
        )
        self.register_buffer(
            "normal_basis", torch.as_tensor(geometry.normal_basis, dtype=torch.float64)
        )
        self.minimum_scale = float(minimum_scale)

    def forward_costs(
        self,
        features: torch.Tensor,
        base_tangent: torch.Tensor,
        masks: torch.Tensor,
        mse_costs: torch.Tensor,
    ) -> torch.Tensor:
        del masks, mse_costs
        output = self.core(features)
        scales = torch.exp(torch.clamp(output[:, :1], min=-30.0, max=30.0))
        scales = scales + self.minimum_scale
        tangent = scales * base_tangent
        physical = tangent @ self.tangent_basis.T
        if self.normal_basis.shape[1] > 0:
            physical = physical + output[:, 1:] @ self.normal_basis.T
        return physical


class _ConeCoordinateHead(_CorrectionHead):
    generator_rows: torch.Tensor
    tangent_basis: torch.Tensor
    normal_basis: torch.Tensor

    def __init__(
        self,
        *,
        input_dimension: int,
        model_spec: ModelSpec,
        input_mean: FloatArray,
        input_scale: FloatArray,
        geometry: DecisionInvariantGeometry,
        initial_gauge: FloatArray,
        minimum_scale: float,
    ) -> None:
        super().__init__()
        generator_count = len(geometry.inequality_normals)
        bias = np.concatenate(
            [
                np.full(generator_count, -7.0),
                np.array([-7.0]),
                np.asarray(initial_gauge),
            ]
        )
        self.core = StandardizedMLP(
            input_dimension,
            generator_count + 1 + geometry.normal_dimension,
            model_spec,
            input_mean=input_mean,
            input_scale=input_scale,
            output_bias=bias,
        )
        generator_rows = -(geometry.inequality_normals @ geometry.tangent_basis)
        self.register_buffer(
            "generator_rows", torch.as_tensor(generator_rows, dtype=torch.float64)
        )
        self.register_buffer(
            "tangent_basis",
            torch.as_tensor(geometry.tangent_basis, dtype=torch.float64),
        )
        self.register_buffer(
            "normal_basis", torch.as_tensor(geometry.normal_basis, dtype=torch.float64)
        )
        self.generator_count = generator_count
        self.minimum_scale = float(minimum_scale)

    def forward_costs(
        self,
        features: torch.Tensor,
        base_tangent: torch.Tensor,
        masks: torch.Tensor,
        mse_costs: torch.Tensor,
    ) -> torch.Tensor:
        del mse_costs
        output = self.core(features)
        coefficients = (
            torch.nn.functional.softplus(output[:, : self.generator_count]) * masks
        )
        tangent = coefficients @ self.generator_rows
        ray_scale = (
            torch.nn.functional.softplus(
                output[:, self.generator_count : self.generator_count + 1]
            )
            + self.minimum_scale
        )
        tangent = tangent + ray_scale * base_tangent
        physical = tangent @ self.tangent_basis.T
        if self.normal_basis.shape[1] > 0:
            gauge = output[:, self.generator_count + 1 :]
            physical = physical + gauge @ self.normal_basis.T
        return physical


class _ProjectedTargetHead(_CorrectionHead):
    generator_rows: torch.Tensor
    tangent_basis: torch.Tensor
    normal_basis: torch.Tensor

    def __init__(
        self,
        *,
        input_dimension: int,
        physical_dimension: int,
        model_spec: ModelSpec,
        input_mean: FloatArray,
        input_scale: FloatArray,
        geometry: DecisionInvariantGeometry,
        minimum_scale: float,
        anchor_weight: float,
    ) -> None:
        super().__init__()
        self.core = StandardizedMLP(
            input_dimension,
            physical_dimension,
            model_spec,
            input_mean=input_mean,
            input_scale=input_scale,
            output_bias=np.zeros(physical_dimension),
        )
        generator_rows = -(geometry.inequality_normals @ geometry.tangent_basis)
        self.register_buffer(
            "generator_rows", torch.as_tensor(generator_rows, dtype=torch.float64)
        )
        self.register_buffer(
            "tangent_basis",
            torch.as_tensor(geometry.tangent_basis, dtype=torch.float64),
        )
        self.register_buffer(
            "normal_basis", torch.as_tensor(geometry.normal_basis, dtype=torch.float64)
        )
        self.minimum_scale = float(minimum_scale)
        self.anchor_weight = float(anchor_weight)

    def forward_costs(
        self,
        features: torch.Tensor,
        base_tangent: torch.Tensor,
        masks: torch.Tensor,
        mse_costs: torch.Tensor,
    ) -> torch.Tensor:
        target = mse_costs + self.core(features)
        target_tangent = target @ self.tangent_basis
        projected = cast(
            torch.Tensor,
            _ExactConeProjection.apply(  # type: ignore[no-untyped-call]
                target_tangent, masks, self.generator_rows
            ),
        )
        base_norm = torch.linalg.vector_norm(base_tangent, dim=1, keepdim=True)
        target_norm = torch.linalg.vector_norm(target_tangent, dim=1, keepdim=True)
        scale = torch.clamp(
            target_norm / torch.clamp(base_norm, min=1e-12),
            min=self.minimum_scale,
        )
        tangent = (1.0 - self.anchor_weight) * projected
        tangent = tangent + self.anchor_weight * scale * base_tangent
        physical = tangent @ self.tangent_basis.T
        if self.normal_basis.shape[1] > 0:
            physical = physical + (target @ self.normal_basis) @ self.normal_basis.T
        return physical


@dataclass(frozen=True)
class _TensorSplit:
    features: torch.Tensor
    base_tangent: torch.Tensor
    masks: torch.Tensor
    mse_costs: torch.Tensor
    observed_costs: torch.Tensor


def _tensor_split(
    split: NeuralCorrectionSplit,
    features: FloatArray,
    geometry: DecisionInvariantGeometry,
) -> _TensorSplit:
    correction = split.correction
    return _TensorSplit(
        features=torch.as_tensor(features, dtype=torch.float64),
        base_tangent=torch.as_tensor(
            geometry.tangent_coordinates(correction.base_directions),
            dtype=torch.float64,
        ),
        masks=torch.as_tensor(
            geometry.active_mask(correction.base_decisions), dtype=torch.float64
        ),
        mse_costs=torch.as_tensor(split.mse_physical_costs, dtype=torch.float64),
        observed_costs=torch.as_tensor(correction.observed_costs, dtype=torch.float64),
    )


def _predict_head(model: _CorrectionHead, split: _TensorSplit) -> FloatArray:
    model.eval()
    with torch.no_grad():
        result = model.forward_costs(
            split.features, split.base_tangent, split.masks, split.mse_costs
        )
    return np.ascontiguousarray(result.cpu().numpy())


def _fit_head(
    *,
    factory: Callable[[int], _CorrectionHead],
    train: _TensorSplit,
    validation: _TensorSplit,
    test: _TensorSplit,
    learning_rates: tuple[float, ...],
    epochs: int,
    patience: int,
    batch_size: int,
    weight_decay: float,
    initialization_seed: int,
    shuffle_seed: int,
) -> tuple[FloatArray, dict[str, Any]]:
    method_started = time.perf_counter()
    candidates: list[dict[str, Any]] = []
    best_model: _CorrectionHead | None = None
    best_value = math.inf
    best_learning_rate = math.nan
    best_epoch = 0
    for candidate_index, learning_rate in enumerate(learning_rates):
        model = factory(initialization_seed + candidate_index)
        optimizer = torch.optim.AdamW(
            model.parameters(), lr=learning_rate, weight_decay=weight_decay
        )
        state = _state(model)
        with torch.no_grad():
            value = float(
                torch.mean(
                    (
                        model.forward_costs(
                            validation.features,
                            validation.base_tangent,
                            validation.masks,
                            validation.mse_costs,
                        )
                        - validation.observed_costs
                    )
                    ** 2
                ).item()
            )
        candidate_best = value
        candidate_epoch = 0
        stale = 0
        completed = 0
        for epoch in range(1, epochs + 1):
            model.train()
            for indices in _batches(
                len(train.features), batch_size, shuffle_seed + 1009 * epoch
            ):
                batch = torch.as_tensor(indices, dtype=torch.long)
                optimizer.zero_grad(set_to_none=True)
                prediction = model.forward_costs(
                    train.features[batch],
                    train.base_tangent[batch],
                    train.masks[batch],
                    train.mse_costs[batch],
                )
                loss = 0.5 * torch.mean(
                    torch.sum((prediction - train.observed_costs[batch]) ** 2, dim=1)
                )
                loss.backward()  # type: ignore[no-untyped-call]
                torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0)
                optimizer.step()
            completed = epoch
            if epoch % 5 != 0 and epoch != epochs:
                continue
            model.eval()
            with torch.no_grad():
                value = float(
                    torch.mean(
                        (
                            model.forward_costs(
                                validation.features,
                                validation.base_tangent,
                                validation.masks,
                                validation.mse_costs,
                            )
                            - validation.observed_costs
                        )
                        ** 2
                    ).item()
                )
            if value < candidate_best - 1e-9:
                candidate_best = value
                candidate_epoch = epoch
                state = _state(model)
                stale = 0
            else:
                stale += 1
                if stale >= patience:
                    break
        model.load_state_dict(state)
        candidates.append(
            {
                "learning_rate": learning_rate,
                "validation_scenario_mse_per_coordinate": candidate_best,
                "best_epoch": candidate_epoch,
                "epochs_completed": completed,
            }
        )
        if candidate_best < best_value:
            best_value = candidate_best
            best_model = copy.deepcopy(model)
            best_learning_rate = learning_rate
            best_epoch = candidate_epoch
    if best_model is None:
        raise RuntimeError("no neural correction candidate was fitted")
    return _predict_head(best_model, test), {
        "selection": "validation scenario physical-cost MSE",
        "selected_learning_rate": best_learning_rate,
        "best_epoch": best_epoch,
        "validation_scenario_mse_per_coordinate": best_value,
        "fitting_wall_seconds": time.perf_counter() - method_started,
        "training_solver_calls": 0,
        "candidates": candidates,
    }


def fit_neural_prediction_corrections(
    *,
    train: NeuralCorrectionSplit,
    validation: NeuralCorrectionSplit,
    test: NeuralCorrectionSplit,
    geometry: DecisionInvariantGeometry,
    model_spec: ModelSpec,
    learning_rates: tuple[float, ...],
    epochs: int,
    patience: int,
    batch_size: int,
    weight_decay: float,
    minimum_scale: float,
    initialization_seed: int,
    shuffle_seed: int,
    include_full_cone: bool = True,
    include_projected_head: bool = True,
    include_neural_heads: bool = True,
) -> tuple[dict[str, CorrectionPrediction], dict[str, Any]]:
    """Fit the requested paired-MSE decision-preserving corrections."""

    started = time.perf_counter()
    raw_train = _combined_features(train, geometry)
    raw_validation = _combined_features(validation, geometry)
    raw_test = _combined_features(test, geometry)
    feature_mean, feature_scale = input_statistics(raw_train)
    tensor_train = _tensor_split(train, raw_train, geometry)
    tensor_validation = _tensor_split(validation, raw_validation, geometry)
    tensor_test = _tensor_split(test, raw_test, geometry)

    predictions: dict[str, CorrectionPrediction] = {}
    methods: dict[str, Any] = {}
    predictions["paired_mse_raw"] = CorrectionPrediction(
        name="paired_mse_raw",
        physical_costs=np.ascontiguousarray(test.mse_physical_costs),
        fitting_wall_seconds=0.0,
        selected_ridge=None,
        validation_scenario_mse_per_coordinate=float(
            np.mean(
                (validation.mse_physical_costs - validation.correction.observed_costs)
                ** 2
            )
        ),
        metadata={
            "role": "paired unprojected MSE-network reference",
            "decision_preserving_correction": False,
        },
    )
    deterministic_started = time.perf_counter()
    ray, ray_scales = geometry.ray_project(
        test.mse_physical_costs,
        test.correction.base_directions,
        minimum_scale=minimum_scale,
    )
    validation_ray, _ = geometry.ray_project(
        validation.mse_physical_costs,
        validation.correction.base_directions,
        minimum_scale=minimum_scale,
    )
    predictions["paired_mse_exact_ray_gauge"] = CorrectionPrediction(
        name="paired_mse_exact_ray_gauge",
        physical_costs=ray,
        fitting_wall_seconds=time.perf_counter() - deterministic_started,
        selected_ridge=None,
        validation_scenario_mse_per_coordinate=float(
            np.mean((validation_ray - validation.correction.observed_costs) ** 2)
        ),
        metadata={"mean_test_scale": float(np.mean(ray_scales))},
    )
    if include_full_cone:
        cone_started = time.perf_counter()
        validation_cone, validation_cone_receipt = geometry.cone_project(
            validation.mse_physical_costs,
            validation.correction.base_decisions,
            validation.correction.base_directions,
            minimum_scale=minimum_scale,
            anchor_weight=1e-4,
        )
        cone, cone_receipt = geometry.cone_project(
            test.mse_physical_costs,
            test.correction.base_decisions,
            test.correction.base_directions,
            minimum_scale=minimum_scale,
            anchor_weight=1e-4,
        )
        predictions["paired_mse_exact_full_cone"] = CorrectionPrediction(
            name="paired_mse_exact_full_cone",
            physical_costs=cone,
            fitting_wall_seconds=time.perf_counter() - cone_started,
            selected_ridge=None,
            validation_scenario_mse_per_coordinate=float(
                np.mean(
                    (validation_cone - validation.correction.observed_costs) ** 2
                )
            ),
            metadata={
                "validation_projection": validation_cone_receipt,
                "test_projection": cone_receipt,
            },
        )

    initial_ray, initial_scales = geometry.ray_project(
        train.mse_physical_costs,
        train.correction.base_directions,
        minimum_scale=minimum_scale,
    )
    del initial_ray
    initial_gauge = geometry.normal_coordinates(train.mse_physical_costs).mean(axis=0)

    factories: dict[str, Callable[[int], _CorrectionHead]] = {}
    if include_neural_heads:
        factories = {
            "neural_ray_gauge": lambda seed: _seeded(
                seed,
                lambda: _RayGaugeHead(
                    input_dimension=raw_train.shape[1],
                    model_spec=model_spec,
                    input_mean=feature_mean,
                    input_scale=feature_scale,
                    geometry=geometry,
                    initial_scale=float(np.mean(initial_scales)),
                    initial_gauge=initial_gauge,
                    minimum_scale=minimum_scale,
                ),
            ),
            "neural_cone_coordinates": lambda seed: _seeded(
                seed,
                lambda: _ConeCoordinateHead(
                    input_dimension=raw_train.shape[1],
                    model_spec=model_spec,
                    input_mean=feature_mean,
                    input_scale=feature_scale,
                    geometry=geometry,
                    initial_gauge=initial_gauge,
                    minimum_scale=minimum_scale,
                ),
            ),
        }
    if include_neural_heads and include_projected_head:
        factories["neural_end_to_end_exact_cone_projection"] = lambda seed: _seeded(
            seed,
            lambda: _ProjectedTargetHead(
                input_dimension=raw_train.shape[1],
                physical_dimension=geometry.variable_dimension,
                model_spec=model_spec,
                input_mean=feature_mean,
                input_scale=feature_scale,
                geometry=geometry,
                minimum_scale=minimum_scale,
                anchor_weight=1e-4,
            ),
        )
    for method_index, (name, factory) in enumerate(factories.items()):
        costs, receipt = _fit_head(
            factory=factory,
            train=tensor_train,
            validation=tensor_validation,
            test=tensor_test,
            learning_rates=learning_rates,
            epochs=epochs,
            patience=patience,
            batch_size=batch_size,
            weight_decay=weight_decay,
            initialization_seed=initialization_seed + 10_000 * method_index,
            shuffle_seed=shuffle_seed + 10_000 * method_index,
        )
        methods[name] = receipt
        predictions[name] = CorrectionPrediction(
            name=name,
            physical_costs=costs,
            fitting_wall_seconds=float(receipt["fitting_wall_seconds"]),
            selected_ridge=None,
            validation_scenario_mse_per_coordinate=float(
                receipt["validation_scenario_mse_per_coordinate"]
            ),
            metadata=receipt,
        )
    return predictions, {
        "supervision": "context-scenario pairs only",
        "selection": "validation scenario physical-cost MSE",
        "conditional_means_used": False,
        "projected_scenario_label_regression_included": False,
        "end_to_end_projected_head_included": include_projected_head,
        "neural_heads_included": include_neural_heads,
        "methods": methods,
        "whole_neural_suite_wall_seconds": time.perf_counter() - started,
    }


def _seeded(seed: int, factory: Callable[[], _CorrectionHead]) -> _CorrectionHead:
    torch.manual_seed(seed)
    return factory()
