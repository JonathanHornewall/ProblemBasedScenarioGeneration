"""Cross-panel accounting for the single-stage publication campaign.

Panel-level confirmation receipts remain the source of inferential detail.
This module deliberately produces only descriptive cross-panel accounting: a
benchmark ladder must not silently become a collection of independent studies.
"""

from __future__ import annotations

import json
import math
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any


def load_object(path: Path) -> dict[str, Any]:
    """Load one JSON-object receipt."""

    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected a JSON object at {path}")
    return payload


def _finite_mean(comparison: Mapping[str, Any]) -> float:
    interval = comparison.get("difference")
    if not isinstance(interval, Mapping):
        raise ValueError("paired comparison lacks a difference interval")
    value = interval.get("mean")
    if (
        not isinstance(value, (int, float))
        or isinstance(value, bool)
        or not math.isfinite(float(value))
    ):
        raise ValueError("paired comparison lacks a finite mean difference")
    return float(value)


def _direction(value: float, *, tolerance: float = 1e-12) -> str:
    if value < -tolerance:
        return "win"
    if value > tolerance:
        return "loss"
    return "tie"


def _comparison_accounting(
    groups: Sequence[Mapping[str, Any]],
    *,
    comparison_key: str,
    adjusted_pvalue_key: str,
) -> list[dict[str, Any]]:
    by_comparator: dict[str, dict[str, Any]] = {}
    for group in groups:
        comparisons = group.get(comparison_key)
        if not isinstance(comparisons, list):
            raise ValueError(f"confirmation group lacks {comparison_key}")
        for raw in comparisons:
            if not isinstance(raw, Mapping):
                raise ValueError("paired comparison must be an object")
            comparator = raw.get("comparator_method")
            if not isinstance(comparator, str):
                raise ValueError("paired comparison lacks comparator method")
            bucket = by_comparator.setdefault(
                comparator,
                {
                    "comparator_method": comparator,
                    "comparison_count": 0,
                    "target_mean_wins": 0,
                    "mean_ties": 0,
                    "target_mean_losses": 0,
                    "adjusted_significant_target_wins": 0,
                    "adjusted_significant_target_losses": 0,
                },
            )
            direction = _direction(_finite_mean(raw))
            bucket["comparison_count"] += 1
            bucket[
                {
                    "win": "target_mean_wins",
                    "tie": "mean_ties",
                    "loss": "target_mean_losses",
                }[direction]
            ] += 1
            adjusted = raw.get(adjusted_pvalue_key)
            if (
                isinstance(adjusted, (int, float))
                and not isinstance(adjusted, bool)
                and math.isfinite(float(adjusted))
                and float(adjusted) <= 0.05
            ):
                if direction == "win":
                    bucket["adjusted_significant_target_wins"] += 1
                elif direction == "loss":
                    bucket["adjusted_significant_target_losses"] += 1
    return [by_comparator[key] for key in sorted(by_comparator)]


def summarize_confirmation_panel(
    name: str, receipt: Mapping[str, Any]
) -> dict[str, Any]:
    """Build compact accounting from one sealed confirmation receipt."""

    if receipt.get("status") != "paired_test_confirmation":
        raise ValueError(f"{name}: receipt is not a paired test confirmation")
    if receipt.get("selection_used_test") is not False:
        raise ValueError(f"{name}: confirmation selection is not test blind")
    if receipt.get("test_evaluated") is not True:
        raise ValueError(f"{name}: confirmation does not contain test results")
    target = receipt.get("target_method")
    if not isinstance(target, str):
        raise ValueError(f"{name}: confirmation lacks a target method")
    benchmarks = receipt.get("benchmarks")
    families = receipt.get("family_paired_target_comparisons")
    wins = receipt.get("descriptive_method_win_counts")
    runtime = receipt.get("method_runtime_accounting")
    manifest_identity = receipt.get("manifest_identity")
    if not isinstance(benchmarks, list) or not isinstance(families, list):
        raise ValueError(f"{name}: confirmation lacks route or family detail")
    if not isinstance(wins, Mapping) or not isinstance(runtime, list):
        raise ValueError(f"{name}: confirmation lacks wins or runtime detail")
    if (
        not isinstance(manifest_identity, Mapping)
        or manifest_identity.get("status")
        != "verified_frozen_manifest_identity"
        or manifest_identity.get("selection_used_test") is not False
        or int(manifest_identity.get("completed_run_count", -1))
        != int(receipt["completed_run_count"])
    ):
        raise ValueError(f"{name}: confirmation lacks verified manifest identity")
    return {
        "name": name,
        "target_method": target,
        "completed_run_count": int(receipt["completed_run_count"]),
        "route_count": int(receipt["benchmark_count"]),
        "family_count": int(receipt["family_count"]),
        "paired_seed_count": int(receipt["required_seed_count"]),
        "descriptive_method_win_counts": dict(sorted(wins.items())),
        "route_target_comparisons": _comparison_accounting(
            benchmarks,
            comparison_key="paired_target_comparisons",
            adjusted_pvalue_key="pvalue_holm_within_benchmark",
        ),
        "family_target_comparisons": _comparison_accounting(
            families,
            comparison_key="paired_target_comparisons",
            adjusted_pvalue_key="pvalue_holm_across_families_for_comparator",
        ),
        "method_runtime_accounting": runtime,
        "manifest_identity": manifest_identity,
        "source_sha256_values": receipt.get("source_sha256_values", []),
    }


def summarize_skew_receipt(receipt: Mapping[str, Any]) -> dict[str, Any]:
    """Retain the compact, analytically frozen skew-stress result."""

    if receipt.get("status") != "paired_test_confirmation":
        raise ValueError("skew receipt is not a paired test confirmation")
    if receipt.get("selection_used_test") is not False:
        raise ValueError("skew confirmation selection is not test blind")
    methods = receipt.get("methods")
    comparisons = receipt.get("paired_target_comparisons")
    if not isinstance(methods, list) or not isinstance(comparisons, list):
        raise ValueError("skew receipt lacks method or comparison results")
    compact_methods = []
    for method in methods:
        if not isinstance(method, Mapping):
            raise ValueError("skew method result must be an object")
        regret = method.get("raw_mean_regret")
        if not isinstance(regret, Mapping):
            raise ValueError("skew method result lacks raw regret")
        compact_methods.append(
            {
                "method": method["method"],
                "raw_mean_regret": regret["mean"],
                "ci95_lower": regret["ci95_lower"],
                "ci95_upper": regret["ci95_upper"],
            }
        )
    return {
        "route_id": receipt["route_id"],
        "completed_run_count": int(receipt["completed_run_count"]),
        "paired_seed_count": int(receipt["required_seed_count"]),
        "methods": sorted(compact_methods, key=lambda row: row["raw_mean_regret"]),
        "paired_target_comparisons": comparisons,
        "source_sha256_values": receipt.get("source_sha256_values", []),
    }


def summarize_mechanism_receipt(receipt: Mapping[str, Any]) -> dict[str, Any]:
    """Retain tuned-protocol and same-checkpoint deployment results."""

    if receipt.get("status") != (
        "paired_protocol_and_matched_deployment_confirmation"
    ):
        raise ValueError("mechanism receipt lacks the matched deployment analysis")
    if receipt.get("selection_used_test") is not False:
        raise ValueError("mechanism confirmation selection is not test blind")
    if receipt.get("test_evaluated") is not True:
        raise ValueError("mechanism confirmation lacks test results")
    protocol_contrasts = receipt.get(
        "aggregate_independently_tuned_protocol_contrasts"
    )
    deployment_contrasts = receipt.get("same_checkpoint_deployment_contrasts")
    audit = receipt.get("horizon_audit")
    if (
        not isinstance(protocol_contrasts, list)
        or not isinstance(deployment_contrasts, list)
        or not isinstance(audit, Mapping)
    ):
        raise ValueError("mechanism confirmation lacks contrasts or horizon audit")
    return {
        "completed_run_count": int(receipt["completed_run_count"]),
        "route_count": int(receipt["route_count"]),
        "family_count": int(receipt["family_count"]),
        "paired_seed_count": int(receipt["required_seed_count"]),
        "descriptive_cell_win_counts": dict(
            sorted(receipt["descriptive_cell_win_counts"].items())
        ),
        "aggregate_independently_tuned_protocol_contrasts": protocol_contrasts,
        "same_checkpoint_deployment_contrasts": deployment_contrasts,
        "boundary_selected_cell_count": int(
            audit["boundary_selected_cell_count"]
        ),
        "selected_cell_count": int(audit["selected_cell_count"]),
        "fixed_maximum_epoch": int(audit["fixed_maximum_epoch"]),
        "source_sha256_values": receipt.get("source_sha256_values", []),
        "git_commits": receipt.get("git_commits", []),
    }


def build_program_summary(
    panels: Mapping[str, Mapping[str, Any]],
    *,
    skew: Mapping[str, Any] | None = None,
    mechanism: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a cross-panel receipt without pooling dependent benchmark routes."""

    if not panels:
        raise ValueError("at least one confirmation panel is required")
    compact = [
        summarize_confirmation_panel(name, receipt)
        for name, receipt in sorted(panels.items())
    ]
    program_gates = [
        {
            "gate": "native Torch engineering",
            "status": "passed",
            "report": "results/engineering/TORCH_SOFT_RADIAL_OPTIMIZATION.md",
            "conclusion": (
                "Strict reference equivalence and representative end-to-end "
                "speedups of 3.37x to 15.49x without regret degradation."
            ),
        },
        {
            "gate": "continuous numerical audit",
            "status": "passed",
            "report": (
                "results/confirmation/"
                "PUBLICATION_CONTINUOUS_NUMERICAL_AUDIT.md"
            ),
            "conclusion": (
                "All 250 confirmed target runs were valid; large raw report "
                "norms were bounded by the intentional rational chart."
            ),
        },
        {
            "gate": "benchmark provenance and reference audit",
            "status": "passed with fidelity classes disclosed",
            "report": (
                "results/confirmation/"
                "PUBLICATION_BENCHMARK_PROVENANCE.md"
            ),
            "conclusion": (
                "Every confirmed route records its source relationship, split, "
                "conditional-reference precision, fixed-dataset semantics, "
                "standardized coordinate metric, and relaxation-deployment "
                "contract."
            ),
        },
        {
            "gate": "exact-QP projection control",
            "status": "validation-pruned negative control",
            "report": "results/development/PUBLICATION_EXACT_QP_GATE.md",
            "conclusion": (
                "Paired refinement remained materially slower and worse; the "
                "predeclared rule therefore excluded test confirmation."
            ),
        },
        {
            "gate": "exact-integer solver-loop control",
            "status": "runtime-gated after bounded pilots",
            "report": "results/development/PUBLICATION_EXACT_INTEGER_GATE.md",
            "conclusion": (
                "Thirty bounded exact-integer pilots completed, but projected "
                "full tuning cost justified relaxation training followed by "
                "exact hard deployment."
            ),
        },
        {
            "gate": "integer reference precision",
            "status": "provisional descriptive evidence",
            "report": (
                "results/confirmation/"
                "PUBLICATION_INTEGER_CONFIRMATION.md"
            ),
            "conclusion": (
                "Fifteen of 28 routes use 64-draw Monte Carlo conditional-"
                "mean references, and eleven fixed-source routes vary only "
                "optimization randomness. Integer rankings are therefore "
                "descriptive pending a higher-precision stability audit."
            ),
        },
        {
            "gate": "fixed-source integer refinement",
            "status": "repaired with failures preserved",
            "report": (
                "results/development/"
                "PUBLICATION_INTEGER_FIXED_SOURCE_REPLAY.md"
            ),
            "conclusion": (
                "The final refinement has 1,512 clean validation-only runs; "
                "the original 594 provider rejections remain provenance."
            ),
        },
        {
            "gate": "fixed-split integer confirmation",
            "status": "repaired with failures preserved",
            "report": (
                "results/confirmation/"
                "PUBLICATION_INTEGER_CONFIRMATION_REPLAY.md"
            ),
            "conclusion": (
                "The combined confirmation has 1,680 clean test runs; the "
                "original 60 pre-evaluation split rejections remain provenance."
            ),
        },
    ]
    if mechanism is not None:
        program_gates.append(
            {
                "gate": "same-checkpoint deployment mechanism",
                "status": "passed; barrier effect left unidentified",
                "report": (
                    "results/confirmation/"
                    "PUBLICATION_BARRIER_MECHANISM_ABLATION.md"
                ),
                "conclusion": (
                    "Reevaluating every fixed checkpoint under both deployments "
                    "shows a large hard-recovery gain in all four training-protocol "
                    "groups. Independently tuned endpoint cells do not identify "
                    "the centered barrier penalty's causal contribution."
                ),
            }
        )
    return {
        "status": "cross_panel_descriptive_accounting",
        "selection_used_test": False,
        "pooling_across_panels": False,
        "panels": compact,
        "frozen_skew_stress": (
            None if skew is None else summarize_skew_receipt(skew)
        ),
        "barrier_deployment_mechanism": (
            None if mechanism is None else summarize_mechanism_receipt(mechanism)
        ),
        "program_gates": program_gates,
        "evidence_boundary": [
            (
                "Final per-panel candidates and horizons were selected without "
                "reading their confirmation test metrics."
            ),
            (
                "Earlier exploratory runs used test splits on related or reused "
                "benchmark families; this is not a preregistered first-exposure "
                "claim."
            ),
            (
                "Route and family counts are descriptive; no cross-panel "
                "independence is assumed."
            ),
            "Inferential details remain in the individual confirmation receipts.",
        ],
    }


def _fmt(value: Any) -> str:
    if value is None:
        return "n/a"
    if isinstance(value, float):
        return f"{value:.6g}"
    return str(value)


def _comparison_row(
    panel: Mapping[str, Any], level: str, comparator: str
) -> Mapping[str, Any] | None:
    key = f"{level}_target_comparisons"
    rows = panel.get(key)
    if not isinstance(rows, list):
        return None
    for row in rows:
        if (
            isinstance(row, Mapping)
            and row.get("comparator_method") == comparator
        ):
            return row
    return None


def _readout_line(
    panel: Mapping[str, Any], comparator: str, label: str
) -> str | None:
    row = _comparison_row(panel, "route", comparator)
    if row is None:
        return None
    return (
        f"against {label}: {row['target_mean_wins']}/"
        f"{row['mean_ties']}/{row['target_mean_losses']} mean route W/T/L"
    )


def render_program_markdown(summary: Mapping[str, Any]) -> str:
    """Render the compact cross-panel receipt as Markdown."""

    panels = summary.get("panels")
    if not isinstance(panels, list) or not panels:
        raise ValueError("program summary lacks panels")
    lines = [
        "# Log-gradient recovered-cost Soft-Radial publication campaign",
        "",
        "This is compact cross-panel accounting. Individual confirmation reports",
        "remain authoritative for estimates, tests, runtimes, and oracle counts.",
        "",
        (
            "**Method identity.** The confirmed target is a Soft-Radial direct "
            "policy with hard deployment through its recovered cost. The frozen "
            "target included a centered log-barrier penalty. Same-checkpoint "
            "reevaluation identifies a large gain from recovered-cost deployment; "
            "the independently tuned endpoint cells do not identify the training "
            "penalty's causal contribution. The deployment cost is recovered from "
            "the log-barrier gradient. This is not the Proximal SPO `h`-report "
            "decoder."
        ),
        "",
        "## Sealed confirmation panels",
        "",
        "| Panel | Routes | Families | Seeds/method | Runs | Target route wins |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for panel in panels:
        wins = panel["descriptive_method_win_counts"]
        lines.append(
            "| {name} | {routes} | {families} | {seeds} | {runs} | {wins} |".format(
                name=panel["name"],
                routes=panel["route_count"],
                families=panel["family_count"],
                seeds=panel["paired_seed_count"],
                runs=panel["completed_run_count"],
                wins=wins.get(panel["target_method"], 0),
            )
        )
    by_name = {panel["name"]: panel for panel in panels}
    skew = summary.get("frozen_skew_stress")
    mechanism = summary.get("barrier_deployment_mechanism")
    lines.extend(["", "## Campaign-level scientific readout", ""])
    continuous = by_name.get("continuous")
    if isinstance(continuous, Mapping):
        spo = _readout_line(continuous, "spo_plus", "SPO+")
        mse = _readout_line(continuous, "mse", "MSE")
        if spo is not None and mse is not None:
            target_wins = continuous["descriptive_method_win_counts"].get(
                continuous["target_method"], 0
            )
            lines.append(
                "- **Continuous panel:** the target wins "
                f"{target_wins} "
                f"of {continuous['route_count']} routes; {spo}; {mse}."
            )
    integer = by_name.get("integer")
    if isinstance(integer, Mapping):
        spo = _readout_line(
            integer, "spo_plus_relaxation", "relaxation-trained SPO+"
        )
        mse = _readout_line(integer, "mse", "MSE")
        if spo is not None and mse is not None:
            target_wins = integer["descriptive_method_win_counts"].get(
                integer["target_method"], 0
            )
            lines.append(
                "- **Integer panel:** the target wins "
                f"{target_wins} "
                f"of {integer['route_count']} routes; {spo}; {mse}. The aggregate "
                "result is mixed rather than general integer dominance."
            )
    local = by_name.get("local")
    if isinstance(local, Mapping):
        spo = _readout_line(local, "spo_plus", "SPO+")
        mse = _readout_line(local, "mse", "MSE")
        if spo is not None and mse is not None:
            target_wins = local["descriptive_method_win_counts"].get(
                local["target_method"], 0
            )
            lines.append(
                "- **Local conventional panel:** the target wins "
                f"{target_wins} "
                f"of {local['route_count']} routes; {spo}; {mse}. This is the "
                "campaign's principal negative-control result."
            )
    if isinstance(skew, Mapping):
        zero_methods = [
            row["method"]
            for row in skew["methods"]
            if abs(float(row["raw_mean_regret"])) <= 1e-12
        ]
        lines.append(
            "- **Frozen skew stress:** zero regret was achieved by "
            + ", ".join(zero_methods)
            + ". The target avoids the SPO+/perturbed-FY pathology, but the "
            "result is not unique to the target."
        )
    if isinstance(mechanism, Mapping):
        contrasts = mechanism["same_checkpoint_deployment_contrasts"]
        least_improvement = max(
            contrasts,
            key=lambda row: float(row["difference"]["mean"]),
        )
        greatest_improvement = min(
            contrasts,
            key=lambda row: float(row["difference"]["mean"]),
        )
        maximum_adjusted_pvalue = max(
            float(row["pvalue_holm_across_training_protocols"])
            for row in contrasts
        )
        lines.append(
            "- **Same-checkpoint deployment analysis:** hard recovered minus soft "
            "deployment ranges from "
            f"{least_improvement['difference']['mean']:.6g} to "
            f"{greatest_improvement['difference']['mean']:.6g} across the four "
            "validation-selected training-protocol groups; every paired seed favors "
            "hard deployment and every Holm-adjusted p-value is at most "
            f"{maximum_adjusted_pvalue:.6g}. "
            "The barrier penalty itself is not causally identified."
        )
    lines.extend(
        [
            "",
            "Route wins are descriptive. Related routes are grouped into explicit "
            "families and are not counted as independent studies.",
            "",
            "## Target comparisons",
            "",
            (
                "| Panel | Level | Comparator | Comparisons | Mean W/T/L | "
                "Adjusted significant W/L |"
            ),
            "|---|---|---|---:|---:|---:|",
        ]
    )
    for panel in panels:
        for level, key in (
            ("route", "route_target_comparisons"),
            ("family", "family_target_comparisons"),
        ):
            for row in panel[key]:
                lines.append(
                    (
                        "| {panel} | {level} | {method} | {count} | "
                        "{wins}/{ties}/{losses} | {sig_wins}/{sig_losses} |"
                    ).format(
                        panel=panel["name"],
                        level=level,
                        method=row["comparator_method"],
                        count=row["comparison_count"],
                        wins=row["target_mean_wins"],
                        ties=row["mean_ties"],
                        losses=row["target_mean_losses"],
                        sig_wins=row["adjusted_significant_target_wins"],
                        sig_losses=row["adjusted_significant_target_losses"],
                    )
                )
    lines.extend(
        [
            "",
            (
                "At route level, adjustment is across comparators within a route. "
                "At family level, adjustment is across family hypotheses for each "
                "comparator; interface variants are first averaged within one "
                "physical data law."
            ),
        ]
    )
    if isinstance(skew, Mapping):
        lines.extend(
            [
                "",
                "## Analytically frozen skew stress",
                "",
                "| Method | Mean raw regret | 95% CI |",
                "|---|---:|---:|",
            ]
        )
        for row in skew["methods"]:
            lines.append(
                f"| {row['method']} | {_fmt(row['raw_mean_regret'])} | "
                f"[{_fmt(row['ci95_lower'])}, {_fmt(row['ci95_upper'])}] |"
            )
    if isinstance(mechanism, Mapping):
        lines.extend(
            [
                "",
                "## Same-checkpoint deployment mechanism",
                "",
                (
                    "Each fixed trained checkpoint is evaluated under both "
                    "deployments. Differences are hard recovered minus soft; "
                    "negative values favor hard deployment."
                ),
                "",
                "| Training protocol | Mean difference | 95% CI | Exact p | Holm p |",
                "|---|---:|---:|---:|---:|",
            ]
        )
        for row in mechanism["same_checkpoint_deployment_contrasts"]:
            difference = row["difference"]
            lines.append(
                f"| {row['training_protocol']} | {_fmt(difference['mean'])} | "
                f"[{_fmt(difference['ci95_lower'])}, "
                f"{_fmt(difference['ci95_upper'])}] | "
                f"{_fmt(row['pvalue_raw'])} | "
                f"{_fmt(row['pvalue_holm_across_training_protocols'])} |"
            )
        lines.extend(
            [
                "",
                (
                    "The original four endpoint cells were independently tuned. "
                    "Their descriptive protocol contrasts remain in the mechanism "
                    "receipt, but they do not isolate the barrier penalty."
                ),
            ]
        )
        lines.extend(
            [
                "",
                (
                    f"{mechanism['boundary_selected_cell_count']} of "
                    f"{mechanism['selected_cell_count']} route-cell selections "
                    f"hit the fixed {mechanism['fixed_maximum_epoch']}-epoch "
                    "ceiling; they were disclosed without extending after test "
                    "access."
                ),
            ]
        )
    lines.extend(
        [
            "",
            "## Runtime and training-oracle synopsis",
            "",
            (
                "Fit+validation+test time is the sum of per-route mean wall times "
                "for one representative paired replication. It starts at fitting, "
                "includes checkpoint validation and final test evaluation, and "
                "excludes data/geometry preparation and hyperparameter search. "
                "Coverage differs where expensive controls were runtime-gated."
            ),
            "",
            (
                "| Panel | Method | Routes | Fit+val+test s | Optimization s | "
                "Validation s | Test s | Training oracle calls | Training solver s |"
            ),
            "|---|---|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    retained = {
        "mse",
        "sfge",
        "sfge_relaxation",
        "soft_radial_log_barrier",
        "spo_plus",
        "spo_plus_relaxation",
    }
    for panel in panels:
        for row in panel["method_runtime_accounting"]:
            if row["method"] not in retained:
                continue
            lines.append(
                "| {panel} | {method} | {routes} | {wall} | {optimization} | "
                "{validation} | {test} | {calls} | {solver} |".format(
                    panel=panel["name"],
                    method=row["method"],
                    routes=row["route_count"],
                    wall=_fmt(row["fit_validation_test_wall_seconds"]),
                    optimization=_fmt(row["optimization_wall_seconds"]),
                    validation=_fmt(row["validation_wall_seconds"]),
                    test=_fmt(row["test_evaluation_wall_seconds"]),
                    calls=_fmt(row["training_oracle_calls"]),
                    solver=_fmt(row["training_solver_seconds"]),
                )
            )
    lines.extend(["", "## Protocol and engineering gates", ""])
    for gate in summary.get("program_gates", []):
        lines.append(
            f"- **{gate['gate']} — {gate['status']}.** {gate['conclusion']} "
            f"See `{gate['report']}`."
        )
    lines.extend(["", "## Evidence boundary", ""])
    lines.extend(f"- {item}" for item in summary["evidence_boundary"])
    return "\n".join(lines) + "\n"
