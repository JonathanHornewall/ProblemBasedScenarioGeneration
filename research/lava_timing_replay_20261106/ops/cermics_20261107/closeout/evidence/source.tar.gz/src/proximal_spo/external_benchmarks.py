"""Adapter for the provenance-first DFL Extensions Lab benchmark suite.

The benchmark database remains an independent package and source of truth.
This module only translates its immutable LP/data contracts into ProximalSPO's
training contracts while recording the exact external source revision.
"""

from __future__ import annotations

import importlib
import math
import random
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
from scipy.sparse import csc_matrix, issparse, vstack

from .data import DatasetBundle, PhysicalCostSplit, SplitSizes
from .problem import FloatArray, LinearProblem
from .seeds import derive_seed


@dataclass(frozen=True)
class ExternalBenchmarkLoad:
    problem: LinearProblem
    dataset: DatasetBundle
    provenance: dict[str, Any]


@dataclass(frozen=True)
class _ExternalSplitView:
    contexts: FloatArray
    scenarios: Any
    split: str
    seed: int


class _MeanNoiseRNG:
    """Deterministic expectation oracle for certified affine-noise generators."""

    @staticmethod
    def uniform(
        low: Any = 0.0,
        high: Any = 1.0,
        size: Any = None,
    ) -> FloatArray:
        value = (
            np.asarray(low, dtype=np.float64) + np.asarray(high, dtype=np.float64)
        ) / 2.0
        if size is None:
            return np.asarray(value, dtype=np.float64).copy()
        return np.asarray(np.broadcast_to(value, size), dtype=np.float64).copy()

    @staticmethod
    def normal(
        loc: Any = 0.0,
        scale: Any = 1.0,
        size: Any = None,
    ) -> FloatArray:
        del scale
        if size is None:
            return np.asarray(loc, dtype=np.float64).copy()
        return np.asarray(
            np.broadcast_to(np.asarray(loc, dtype=np.float64), size),
            dtype=np.float64,
        ).copy()

    @staticmethod
    def exponential(scale: Any = 1.0, size: Any = None) -> FloatArray:
        if size is None:
            return np.asarray(scale, dtype=np.float64).copy()
        return np.asarray(
            np.broadcast_to(np.asarray(scale, dtype=np.float64), size),
            dtype=np.float64,
        ).copy()


def _has_certified_exact_conditional_mean(benchmark: Any) -> bool:
    generator = benchmark.generator.scenario_generator
    generator_type = type(generator)
    if (
        generator_type.__name__ == "PublishedPolynomialCostGenerator"
        and generator_type.__module__.endswith(".published_single_stage")
        and not bool(getattr(generator, "ceiling", False))
    ):
        return True
    benchmark_id = str(benchmark.spec.benchmark_id)
    return benchmark_id.startswith("directional_") or benchmark_id.startswith(
        "cave_sp5_"
    )


def _git_receipt(module_file: str) -> dict[str, Any]:
    path = Path(module_file).resolve()
    root: Path | None = None
    for candidate in (path.parent, *path.parents):
        if (candidate / ".git").exists():
            root = candidate
            break
    if root is None:
        return {"git_sha": None, "git_dirty": None, "source_root": str(path.parent)}

    def git(*arguments: str) -> str:
        completed = subprocess.run(
            ["git", *arguments],
            cwd=root,
            check=True,
            capture_output=True,
            text=True,
        )
        return completed.stdout.strip()

    return {
        "git_sha": git("rev-parse", "HEAD"),
        "git_dirty": bool(git("status", "--short")),
        "source_root": str(root),
    }


def _physical_costs(
    coefficients: FloatArray,
    exposure: Any,
    fixed_cost: FloatArray,
) -> FloatArray:
    coefficients = np.asarray(coefficients, dtype=np.float64)
    if issparse(exposure):
        random_cost = (exposure.T @ coefficients.T).T
    else:
        random_cost = coefficients @ np.asarray(exposure, dtype=np.float64)
    return np.ascontiguousarray(
        np.asarray(fixed_cost, dtype=np.float64)[None, :] + random_cost
    )


def _coordinate_grid_edges(
    metadata: dict[str, Any],
) -> list[tuple[tuple[int, int], tuple[int, int]]]:
    """Normalize atlas grid arcs stored either as node ids or coordinates."""

    columns = int(metadata["columns"])

    def coordinate(node: Any) -> tuple[int, int]:
        if isinstance(node, (tuple, list, np.ndarray)) and len(node) == 2:
            return int(node[0]), int(node[1])
        return divmod(int(node), columns)

    return [(coordinate(tail), coordinate(head)) for tail, head in metadata["arcs"]]


def _conditional_means(
    benchmark: Any,
    contexts: FloatArray,
    *,
    samples: int,
    seed: int,
    split: str,
    block_contexts: int = 128,
) -> tuple[FloatArray, dict[str, Any]]:
    if samples <= 0:
        raise ValueError("conditional reference samples must be positive")
    generator = getattr(benchmark, "generator", None)
    scenario_generator = getattr(generator, "scenario_generator", None)
    if scenario_generator is None:
        return _fixed_provider_conditional_means(
            generator,
            contexts,
            samples=samples,
            seed=seed,
            split=split,
            benchmark_id=str(benchmark.spec.benchmark_id),
            block_contexts=block_contexts,
        )
    if _has_certified_exact_conditional_mean(benchmark):
        fields = scenario_generator(contexts, _MeanNoiseRNG())
        costs = np.asarray(fields["cost"], dtype=np.float64)
        if costs.ndim != 2 or costs.shape[0] != len(contexts):
            raise ValueError(
                "certified conditional-mean generator returned incompatible costs"
            )
        return np.ascontiguousarray(costs), {
            "estimator": "exact certified conditional expectation",
            "samples_per_context": 0,
            "requested_monte_carlo_samples": samples,
            "noise_expectation": (
                "uniform midpoint or Gaussian mean evaluated in a generator whose "
                "cost is affine in the sampled noise"
            ),
        }
    random = np.random.Generator(
        np.random.PCG64(
            derive_seed(
                seed,
                benchmark.spec.benchmark_id,
                split,
                "conditional_reference",
                samples,
            )
        )
    )
    means: list[FloatArray] = []
    for start in range(0, len(contexts), block_contexts):
        block = np.asarray(contexts[start : start + block_contexts], dtype=np.float64)
        repeated = np.repeat(block, samples, axis=0)
        fields = scenario_generator(repeated, random)
        costs = np.asarray(fields["cost"], dtype=np.float64)
        if costs.ndim != 2 or costs.shape[0] != len(block) * samples:
            raise ValueError(
                "external conditional simulator returned incompatible costs"
            )
        means.append(costs.reshape(len(block), samples, -1).mean(axis=1))
    return np.ascontiguousarray(np.concatenate(means, axis=0)), {
        "estimator": "independent Monte Carlo conditional cost mean",
        "samples_per_context": samples,
        "requested_monte_carlo_samples": samples,
        "block_contexts": block_contexts,
    }


def _fixed_provider_conditional_means(
    provider: Any,
    contexts: FloatArray,
    *,
    samples: int,
    seed: int,
    split: str,
    benchmark_id: str,
    block_contexts: int,
) -> tuple[FloatArray, dict[str, Any]]:
    """Evaluate conditional means for maintained fixed-stream generators.

    The adjacent benchmark package intentionally refuses to invent a second
    random stream for its exact released pair tables.  For decision-regret
    evaluation we need the population cost at the observed contexts, so this
    adapter evaluates the *published generator equation* with an independent,
    receipt-bound Monte Carlo panel.  It never resamples or alters the released
    train/validation/test pairs.
    """

    provider_name = type(provider).__name__
    contexts = np.asarray(contexts, dtype=np.float64)
    random_generator = np.random.Generator(
        np.random.PCG64(
            derive_seed(
                seed,
                benchmark_id,
                split,
                "fixed_provider_conditional_reference",
                samples,
            )
        )
    )

    if provider_name == "PredictiveCOCubicTopKProvider":
        costs = -np.asarray(provider._labels(contexts), dtype=np.float64)
        return np.ascontiguousarray(costs), {
            "estimator": "exact deterministic released cost equation",
            "samples_per_context": 0,
            "requested_monte_carlo_samples": samples,
            "provider": provider_name,
        }

    if provider_name in {"PyEPOMDKPProvider", "PredictiveCOKnapsackProvider"}:
        if provider_name == "PyEPOMDKPProvider":
            _, coefficient, _ = provider._structure()
            dimension = int(provider.context_dimension)
            degree = int(provider.degree)
            noise_width = float(provider.noise_width)
        else:
            coefficient = np.asarray(provider.coefficient, dtype=np.float64)
            dimension = int(provider.context_dimension)
            degree = int(provider.polynomial_degree)
            noise_width = float(provider.noise_width)
        base = ((contexts @ coefficient.T / math.sqrt(dimension) + 3.0) ** degree + 1.0)
        base *= 5.0 / (3.5**degree)
        if noise_width == 0.0:
            costs = -np.ceil(base)
        else:
            means: list[FloatArray] = []
            for start in range(0, len(contexts), block_contexts):
                block = base[start : start + block_contexts]
                noise = random_generator.uniform(
                    1.0 - noise_width,
                    1.0 + noise_width,
                    size=(len(block), samples, block.shape[1]),
                )
                values = np.ceil(block[:, None, :] * noise)
                if provider_name == "PredictiveCOKnapsackProvider":
                    values = values.astype(np.float32).astype(np.float64)
                means.append(-values.mean(axis=1))
            costs = np.concatenate(means, axis=0)
        return np.ascontiguousarray(costs), {
            "estimator": (
                "exact released cost equation"
                if noise_width == 0.0
                else "independent Monte Carlo over released cost equation"
            ),
            "samples_per_context": 0 if noise_width == 0.0 else samples,
            "requested_monte_carlo_samples": samples,
            "provider": provider_name,
        }

    if provider_name in {"PyEPOTSPProvider", "CaveGraphProvider"}:
        if provider_name == "PyEPOTSPProvider":
            baseline, coefficient, _ = provider._structure()
        else:
            legacy = np.random.RandomState(int(provider.source_seed))
            nodes = int(provider.nodes)
            half = nodes // 2
            coordinates = np.concatenate(
                [
                    legacy.uniform(-2.0, 2.0, size=(half, 2)),
                    legacy.normal(0.0, 1.0, size=(nodes - half, 2)),
                ]
            )
            differences = coordinates[:, None, :] - coordinates[None, :, :]
            distances = np.linalg.norm(differences, axis=2)
            edges = tuple((i, j) for i in range(nodes) for j in range(i + 1, nodes))
            baseline = np.asarray([distances[i, j] for i, j in edges])
            coefficient = legacy.binomial(
                1, 0.5, size=(len(edges), int(provider.context_dimension))
            ) * legacy.uniform(
                -2.0,
                2.0,
                size=(len(edges), int(provider.context_dimension)),
            )
        dimension = int(provider.context_dimension)
        degree = int(provider.degree)
        noise_width = float(provider.noise_width)
        polynomial = (
            (contexts @ coefficient.T / math.sqrt(dimension) + 3.0) ** degree
        ) / (3.0 ** (degree - 1))
        means = []
        for start in range(0, len(contexts), block_contexts):
            block = polynomial[start : start + block_contexts]
            if noise_width == 0.0:
                values = baseline[None, :] + block
                means.append(np.around(values, decimals=4))
            else:
                noise = random_generator.uniform(
                    1.0 - noise_width,
                    1.0 + noise_width,
                    size=(len(block), samples, block.shape[1]),
                )
                values = baseline[None, None, :] + block[:, None, :] * noise
                means.append(np.around(values, decimals=4).mean(axis=1))
        costs = np.concatenate(means, axis=0)
        return np.ascontiguousarray(costs), {
            "estimator": (
                "exact released cost equation"
                if noise_width == 0.0
                else "independent Monte Carlo over released graph-cost equation"
            ),
            "samples_per_context": 0 if noise_width == 0.0 else samples,
            "requested_monte_carlo_samples": samples,
            "provider": provider_name,
        }

    if provider_name == "SFGEKnapsackProvider":
        numpy_rng = np.random.RandomState(int(provider.source_seed))
        weights = numpy_rng.uniform(0.0, 1.0, size=int(provider.items))
        python_rng = random.Random(int(provider.source_seed))
        coefficient = np.asarray(
            [
                [
                    1.0 if python_rng.random() <= 0.5 else 0.0
                    for _ in range(int(provider.context_dimension))
                ]
                for _ in range(int(provider.items))
            ],
            dtype=np.float64,
        )
        signal = contexts @ coefficient.T
        base = 1.0 + (
            signal / math.sqrt(int(provider.context_dimension)) + 3.0
        ) ** int(provider.degree)
        base *= weights[None, :]
        means = []
        for start in range(0, len(contexts), block_contexts):
            block = base[start : start + block_contexts]
            noise = random_generator.uniform(
                1.0 - float(provider.multiplicative_noise),
                1.0 + float(provider.multiplicative_noise),
                size=(len(block), samples, block.shape[1]),
            )
            values = np.round(
                block[:, None, :] * noise + float(provider.additive_constant),
                decimals=5,
            )
            means.append(-values.mean(axis=1))
        return np.ascontiguousarray(np.concatenate(means, axis=0)), {
            "estimator": "independent Monte Carlo over released SFGE cost equation",
            "samples_per_context": samples,
            "requested_monte_carlo_samples": samples,
            "provider": provider_name,
        }

    sample_given_context = getattr(provider, "sample_given_context", None)
    if sample_given_context is not None:
        panels: list[FloatArray] = []
        for index, context in enumerate(contexts):
            panel = sample_given_context(
                context,
                samples,
                seed=derive_seed(seed, benchmark_id, split, index),
            )
            fields = panel.fields if hasattr(panel, "fields") else panel
            panels.append(np.asarray(fields["cost"], dtype=np.float64).mean(axis=0))
        return np.ascontiguousarray(np.stack(panels)), {
            "estimator": "provider conditional-panel Monte Carlo",
            "samples_per_context": samples,
            "requested_monte_carlo_samples": samples,
            "provider": provider_name,
        }

    raise ValueError(
        f"external fixed provider {provider_name} has no registered conditional "
        "cost equation"
    )


def _linear_problem(benchmark: Any) -> LinearProblem:
    model = benchmark.feasible_model
    integrality = np.asarray(model.integrality, dtype=np.int64)
    if not np.all(np.isin(integrality, (0, 1))):
        raise ValueError(
            f"{benchmark.spec.benchmark_id} uses semi-integer or semi-continuous "
            "variables, which the local HiGHS contract does not yet expose"
        )
    equality = csc_matrix(model.A_eq)
    inequality = csc_matrix(model.A_ub)
    matrix = csc_matrix(vstack([equality, inequality], format="csc"))
    row_lower = np.concatenate(
        [
            np.asarray(model.b_eq, dtype=np.float64),
            np.full(inequality.shape[0], -np.inf),
        ]
    )
    row_upper = np.concatenate(
        [
            np.asarray(model.b_eq, dtype=np.float64),
            np.asarray(model.b_ub, dtype=np.float64),
        ]
    )
    metadata = dict(model.metadata)
    if {"rows", "columns", "edges"}.issubset(metadata):
        metadata["oracle_kind"] = "directed_grid_path"
    elif {"rows", "columns", "arcs"}.issubset(metadata):
        metadata["edges"] = _coordinate_grid_edges(metadata)
        metadata["oracle_kind"] = "directed_grid_path"
    elif str(model.name).startswith("top_"):
        selected = int(round(float(np.asarray(model.b_eq)[0])))
        metadata.update(
            {
                "items": model.variable_count,
                "selected": selected,
                "oracle_kind": "top_k",
            }
        )
    elif str(model.name).startswith("assignment_"):
        size = int(round(np.sqrt(model.variable_count)))
        if size * size != model.variable_count:
            raise ValueError("assignment model has a nonsquare variable count")
        metadata.update({"size": size, "oracle_kind": "assignment"})
    metadata.update(
        {
            "external_factory_id": benchmark.spec.benchmark_id,
            "external_problem_class": benchmark.spec.problem_class.value,
            "mip_incumbent_warm_start": False,
            "mip_incumbent_warm_start_reason": (
                "disabled because highspy setSolution after objective updates "
                "did not reliably re-establish MIP optimality"
            ),
            "mip_relative_gap": 0.0,
            "mip_absolute_gap": 0.0,
            "mip_feasibility_tolerance": 1e-8,
            "external_source": benchmark.spec.source.summary()
            if hasattr(benchmark.spec.source, "summary")
            else {
                "citation": benchmark.spec.source.citation,
                "url": benchmark.spec.source.url,
                "relationship": benchmark.spec.source.relationship,
                "notes": benchmark.spec.source.notes,
            },
        }
    )
    return LinearProblem(
        matrix=matrix,
        row_lower=row_lower,
        row_upper=row_upper,
        variable_lower=np.asarray(model.lower, dtype=np.float64),
        variable_upper=np.asarray(model.upper, dtype=np.float64),
        integrality=integrality,
        name=benchmark.spec.benchmark_id,
        metadata=metadata,
    )


def load_external_benchmark(
    factory_id: str,
    sizes: SplitSizes,
    *,
    data_seed: int,
    conditional_reference_samples: int,
) -> ExternalBenchmarkLoad:
    try:
        package = importlib.import_module("dfl_extensions_lab.benchmarks")
    except ModuleNotFoundError as error:
        raise RuntimeError(
            "The DFL Extensions Lab package is required for an external benchmark. "
            "Install the adjacent benchmark worktree in this environment."
        ) from error
    # The maintained benchmark package has had two compatible public catalog
    # APIs over its lifetime.  Newer snapshots expose native factory routes;
    # the archived source used for the paper exposes ``get_benchmark``.  Keep
    # the adapter source-compatible with both instead of silently falling back
    # to a clean-room local generator.
    route = None
    if factory_id in {"lava_random_lp_150x50_released_code", "lava_random_lp_800x50_released_code"}:
        # Explicit new route; preserve the historical Appendix construction.
        # This is the same pinned factory/mode used by the other released LP sizes.
        from dfl_extensions_lab.benchmarks.families.published_single_stage import make_lava_random_lp
        variables = 800 if factory_id == "lava_random_lp_800x50_released_code" else 150
        benchmark = make_lava_random_lp(variables=variables, constraints=50, source_mode="released_code")
    elif factory_id == "dys_shortest_path_50x50":
        from dfl_extensions_lab.benchmarks.families.published_single_stage import make_dys_shortest_path
        benchmark = make_dys_shortest_path(grid_size=50)
    elif factory_id == "dys_knapsack_1000x2":
        from dfl_extensions_lab.benchmarks.families.published_single_stage import make_dys_two_dimensional_knapsack
        benchmark = make_dys_two_dimensional_knapsack(items=1000)
    elif factory_id == "dys_cfl_500x10":
        from dfl_extensions_lab.benchmarks.families.published_single_stage import make_dys_capacitated_facility_location
        benchmark = make_dys_capacitated_facility_location(customers=500, facilities=10)
    elif hasattr(package, "get_native_factory_route"):
        route = package.get_native_factory_route(factory_id)
        benchmark = route.build()
    elif hasattr(package, "get_benchmark"):
        benchmark = package.get_benchmark(factory_id)
    else:
        raise RuntimeError(
            "The DFL Extensions Lab package exposes neither the native route "
            "nor the benchmark catalog API"
        )
    problem = _linear_problem(benchmark)
    external_sizes = package.SplitSizes(
        train=sizes.train,
        validation=sizes.validation,
        test=sizes.test,
    )
    canonical_prefix_receipt: dict[str, Any] = {"active": False}
    try:
        sampled = benchmark.sample(external_sizes, seed=data_seed)
    except ValueError as error:
        message = str(error)
        if "require" not in message or "split" not in message:
            raise
        declared_split = getattr(benchmark.generator, "required_split", None)
        if declared_split is None:
            declared_split = benchmark.spec.metadata.get("released_split")
        if declared_split is None or len(declared_split) != 3:
            raise
        canonical_sizes = tuple(int(value) for value in declared_split)
        requested_sizes = (sizes.train, sizes.validation, sizes.test)
        if any(
            requested > available
            for requested, available in zip(
                requested_sizes, canonical_sizes, strict=True
            )
        ):
            raise
        full = benchmark.sample(
            package.SplitSizes(
                train=canonical_sizes[0],
                validation=canonical_sizes[1],
                test=canonical_sizes[2],
            ),
            seed=data_seed,
        )

        def prefix(split_data: Any, count: int) -> _ExternalSplitView:
            fields = {
                name: np.asarray(value)[:count]
                for name, value in split_data.scenarios.fields.items()
            }
            return _ExternalSplitView(
                contexts=np.asarray(split_data.contexts)[:count],
                scenarios=fields,
                split=str(split_data.split),
                seed=int(split_data.seed),
            )

        sampled = type(
            "ExternalDatasetPrefix",
            (),
            {
                "train": prefix(full.train, sizes.train),
                "validation": prefix(full.validation, sizes.validation),
                "test": prefix(full.test, sizes.test),
            },
        )()
        canonical_prefix_receipt = {
            "active": True,
            "canonical_split_generated": list(canonical_sizes),
            "requested_prefix_split": list(requested_sizes),
            "semantics": (
                "deterministic prefixes of the maintained canonical source split"
            ),
        }
    # Older catalog snapshots expose a full objective cost directly in the
    # scenario batch and do not carry the newer ``cost_exposure`` attribute.
    # A direct cost is exactly the identity exposure; preserving that meaning
    # lets the same downstream contract serve both snapshots.
    legacy_catalog = not hasattr(benchmark, "cost_exposure")
    exposure = (
        np.eye(int(benchmark.feasible_model.variable_count), dtype=np.float64)
        if legacy_catalog
        else benchmark.cost_exposure
    )
    fixed_cost = np.asarray(benchmark.feasible_model.c, dtype=np.float64)
    dense_exposure = (
        np.asarray(exposure.toarray(), dtype=np.float64)
        if issparse(exposure)
        else np.asarray(exposure, dtype=np.float64)
    )

    converted: list[PhysicalCostSplit] = []
    conditional_receipts: list[dict[str, Any]] = []
    for split in (sampled.train, sampled.validation, sampled.test):
        observed_coefficients = np.asarray(split.scenarios["cost"], dtype=np.float64)
        conditional_coefficients, conditional_receipt = _conditional_means(
            benchmark,
            split.contexts,
            samples=conditional_reference_samples,
            seed=data_seed,
            split=split.split,
        )
        conditional_receipts.append({"split": split.split, **conditional_receipt})
        converted.append(
            PhysicalCostSplit(
                contexts=np.asarray(split.contexts, dtype=np.float64),
                physical_costs=_physical_costs(
                    observed_coefficients, exposure, fixed_cost
                ),
                conditional_mean_costs=_physical_costs(
                    conditional_coefficients, exposure, fixed_cost
                ),
                split=split.split,
                seed=int(split.seed),
                coefficients=observed_coefficients,
                conditional_mean_coefficients=conditional_coefficients,
            )
        )

    if package.__file__ is None:
        raise RuntimeError("DFL Extensions Lab package has no filesystem source")
    module_file = str(Path(package.__file__).resolve())
    provenance = {
        "benchmark_source": "dfl_extensions_lab",
        "factory": (
            route.summary()
            if route is not None
            else {
                "factory_id": factory_id,
                "benchmark_spec": benchmark.spec.summary(),
                "api": "get_benchmark",
            }
        ),
        "benchmark_spec": benchmark.spec.summary(),
        "conditional_reference": {
            "seed": data_seed,
            "splits": conditional_receipts,
        },
        "canonical_source_prefix": canonical_prefix_receipt,
        **_git_receipt(module_file),
    }
    dataset = DatasetBundle(
        train=converted[0],
        validation=converted[1],
        test=converted[2],
        fixed_anchor=fixed_cost,
        random_indices=np.arange(dense_exposure.shape[0], dtype=np.int64),
        benchmark_id=factory_id,
        master_seed=data_seed,
        law=(
            f"dfl_extensions_lab:{route.data_fidelity.value}"
            if route is not None and hasattr(route, "data_fidelity")
            else "dfl_extensions_lab:catalog_direct_cost"
        ),
        cost_statistic=dense_exposure,
    )
    return ExternalBenchmarkLoad(problem, dataset, provenance)
