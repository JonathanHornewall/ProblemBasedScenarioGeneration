"""Original Mandi--Guns IntOpt code, pinned and called without a solver rewrite.

The tuned mu cutoff is the release's ``thr`` (raw HSD complementarity).
It is not a fixed physical barrier coefficient. Integer benchmarks train on
their continuous relaxation and deploy the same physical LP/MIP as controls.
"""
from __future__ import annotations

import functools
import hashlib
import json
from pathlib import Path
import sys
import time
import types

import numpy as np
import torch

from .canonical_baselines import ColdHighsBatch
from .objectives import CostPredictionObjective, TorchBatchSignal
from .oracles import OracleStats
from .problem import PartialCostInterface


@functools.lru_cache(maxsize=1)
def source_module():
    directory = Path(__file__).resolve().parents[2] / "vendor/intopt_original"
    receipt = json.loads((directory / "SOURCE.json").read_text())
    for name, sha in receipt["files"].items():
        if hashlib.sha256((directory / name).read_bytes()).hexdigest() != sha:
            raise ValueError("IntOpt pinned source changed: " + name)
    module_name = "_proximal_intopt_original_redundancy"
    redundancy = types.ModuleType(module_name)
    redundancy.__file__ = str(directory / "remove_redundancy.py")
    exec(compile(Path(redundancy.__file__).read_text(), redundancy.__file__, "exec"), redundancy.__dict__)
    sys.modules[module_name] = redundancy
    module = types.ModuleType("_proximal_intopt_original")
    module.__file__ = str(directory / "ip_model_whole.py")
    source = Path(module.__file__).read_text()
    # Eleven occurrences of the removed alias, without altering float32/64.
    source = source.replace("np.float,", "float,").replace("np.float)", "float)")
    source = source.replace("from remove_redundancy import ", f"from {module_name} import ")
    source = source.replace("np.min([1, alpha_x, alpha_tau, alpha_t, alpha_kappa])",
        "min(float(np.asarray(v).item()) for v in (1, alpha_x, alpha_tau, alpha_t, alpha_kappa))")
    print_options = np.get_printoptions()
    try:
        exec(compile(source, module.__file__, "exec"), module.__dict__)
    finally:
        np.set_printoptions(**print_options)
    original_indicators = module._indicators
    def observe_indicators(*args, **kwargs):
        result = original_indicators(*args, **kwargs)
        module.last_indicators = tuple(float(np.asarray(x).item()) for x in result)
        return result
    module._indicators = observe_indicators
    module.source_receipt = receipt
    return module


def source_constraints(problem):
    """Lossless two-sided-row conversion; no geometric or cost rescaling."""
    matrix = problem.matrix.toarray()
    lo, hi = problem.row_lower, problem.row_upper
    equality = np.isfinite(lo) & np.isfinite(hi) & (lo == hi)
    upper = np.isfinite(hi) & ~equality
    lower = np.isfinite(lo) & ~equality
    a = matrix[equality]
    b = lo[equality]
    g = np.concatenate((matrix[upper], -matrix[lower]), axis=0)
    h = np.concatenate((hi[upper], -lo[lower]))
    bounds = [(float(l) if np.isfinite(l) else None,
               float(u) if np.isfinite(u) else None)
              for l, u in zip(problem.variable_lower, problem.variable_upper)]
    return {"A": torch.as_tensor(a, dtype=torch.float64),
            "b": torch.as_tensor(b, dtype=torch.float64),
            "G": torch.as_tensor(g, dtype=torch.float64),
            "h": torch.as_tensor(h, dtype=torch.float64), "bounds": bounds}


class OriginalIntOptObjective(CostPredictionObjective):
    name = "intopt_original"
    torch_training = True
    training_device = torch.device("cpu")

    def __init__(self, problem, *, mu_cutoff: float):
        if not np.isfinite(mu_cutoff) or mu_cutoff <= 0:
            raise ValueError("mu_cutoff must be finite and positive")
        self.interface = PartialCostInterface.full_cost(problem)
        self.output_dimension = problem.variable_count
        self._lp = ColdHighsBatch(problem)
        self.mu_cutoff = float(mu_cutoff)
        self.training_problem = problem.continuous_relaxation()
        self.source = source_module()
        self.constraints = source_constraints(self.training_problem)
        self.solve = self.source.IPOfunc(**self.constraints, thr=self.mu_cutoff,
            damping=1e-2, tol=1e-8, max_iter=1000, presolve=True,
            A_eq_rr=True, method=1, init_val=None)

    def torch_signal(self, outputs, costs, target_values, *unused):
        if outputs.device.type != "cpu" or outputs.dtype != torch.float32:
            raise ValueError("The original IntOpt backward uses CPU float32")
        started = time.perf_counter()
        # Apply the released single-instance operation independently. This
        # preserves the common minibatch and gradient accumulation semantics.
        pieces, values, gradients = [], [], []
        for index, row in enumerate(outputs):
            # The public operation materializes a dense HSD Jacobian. Release
            # each sample's graph immediately while preserving the full batch
            # mean and exactly the public first-order cost gradient.
            with torch.enable_grad():
                c = row.detach().requires_grad_(True)
                self.source.last_indicators = None
                decision = self.solve(c)
                diagnostic = self.source.last_indicators
                if diagnostic is None:
                    raise ValueError("IntOpt presolve returned without differentiable HSD state")
                rho_p, rho_d, rho_a, _, _, mu, _ = diagnostic
                if not np.isfinite(diagnostic).all() or (mu > self.mu_cutoff and max(rho_p, rho_d, rho_a) > 1e-8):
                    raise ValueError("IntOpt did not reach its public convergence or mu cutoff criterion")
                value = (decision * costs[index].detach()).sum() - target_values[index]
                gradient, = torch.autograd.grad(value, c)
            if not torch.isfinite(decision).all() or not torch.isfinite(gradient).all():
                raise ValueError("Original IntOpt produced nonfinite decisions or gradients")
            pieces.append(decision.detach())
            values.append(value.detach())
            gradients.append(gradient.detach())
        # A VJP bridge: no changed solver, no approximate replacement gradient.
        values = torch.stack(values) + ((outputs - outputs.detach()) * torch.stack(gradients)).sum(dim=1)
        return TorchBatchSignal(values, OracleStats(calls=len(outputs),
            wall_seconds=time.perf_counter()-started), decisions=torch.stack(pieces))

    def receipt(self):
        return {"method": self.name, "source": self.source.source_receipt,
            "mu_cutoff": self.mu_cutoff, "public_parameter_name": "thr",
            "cutoff_semantics": "raw HSD complementarity, not fixed physical mu",
            "backward_damping": 1e-2, "tolerance": 1e-8, "max_iterations": 1000,
            "training_domain": "continuous LP relaxation",
            "deployment": "cold physical LP/MIP", "physical_output_head": True,
            "output_affine_standardization": False,
            "minibatch_execution": "serial public per-sample VJP; unchanged batch mean"}
