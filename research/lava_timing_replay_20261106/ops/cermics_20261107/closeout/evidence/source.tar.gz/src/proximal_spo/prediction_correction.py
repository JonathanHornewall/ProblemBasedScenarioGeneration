"""Fast decision-preserving prediction correction for fixed-polytope DFL.

The base policy supplies a cost direction whose hard LP optimizer is the
deployed decision.  This module improves the statistical meaning of that cost
without changing the selected decision.  It implements two nested correction
families:

* the ray plus affine-normal gauge ``alpha * P_L r + P_perp m``;
* projection onto the full normal cone of the base decision.

All learned variants use ordinary context--scenario squared error.  Conditional
mean costs are accepted only by the diagnostic functions and are never read by
the fitting routines.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import cvxpy as cp
import numpy as np
from cvxpy.atoms.affine.binary_operators import multiply
from cvxpy.atoms.affine.reshape import reshape
from cvxpy.atoms.sum_squares import sum_squares
from numpy.typing import NDArray
from scipy.optimize import nnls
from scipy.sparse import csc_matrix

from .problem import FloatArray, LinearProblem


@dataclass(frozen=True)
class CorrectionSplit:
    contexts: FloatArray
    hidden_features: FloatArray
    base_directions: FloatArray
    base_decisions: FloatArray
    observed_costs: FloatArray
    conditional_mean_costs: FloatArray
    conditional_target_values: FloatArray

    def __post_init__(self) -> None:
        rows = len(self.contexts)
        arrays = (
            self.hidden_features,
            self.base_directions,
            self.base_decisions,
            self.observed_costs,
            self.conditional_mean_costs,
        )
        if any(np.asarray(value).ndim != 2 or len(value) != rows for value in arrays):
            raise ValueError("correction split arrays must share a row dimension")
        if np.asarray(self.conditional_target_values).shape != (rows,):
            raise ValueError("conditional target values have the wrong shape")


@dataclass(frozen=True)
class CorrectionPrediction:
    name: str
    physical_costs: FloatArray
    fitting_wall_seconds: float
    selected_ridge: float | None
    validation_scenario_mse_per_coordinate: float | None
    metadata: dict[str, Any]


@dataclass(frozen=True)
class _FeatureTransform:
    mean: FloatArray
    scale: FloatArray

    @classmethod
    def fit(cls, raw: FloatArray) -> _FeatureTransform:
        raw = np.asarray(raw, dtype=np.float64)
        mean = raw.mean(axis=0)
        scale = raw.std(axis=0, ddof=0)
        scale = np.where(scale < 1e-9, 1.0, scale)
        return cls(mean, scale)

    def apply(self, raw: FloatArray) -> FloatArray:
        standardized = (np.asarray(raw, dtype=np.float64) - self.mean) / self.scale
        return np.ascontiguousarray(
            np.column_stack([standardized, np.ones(len(standardized))])
        )


@dataclass(frozen=True)
class DecisionInvariantGeometry:
    """Affine-hull and active-normal-cone geometry for one fixed polytope."""

    tangent_basis: FloatArray
    normal_basis: FloatArray
    inequality_normals: FloatArray
    inequality_rhs: FloatArray

    @classmethod
    def compile(
        cls,
        problem: LinearProblem,
        *,
        tangent_map: FloatArray,
        rank_tolerance: float = 1e-10,
    ) -> DecisionInvariantGeometry:
        physical_map = np.asarray(tangent_map, dtype=np.float64)
        if physical_map.ndim != 2 or physical_map.shape[0] != problem.variable_count:
            raise ValueError("tangent map has the wrong shape")
        left, singular, _ = np.linalg.svd(physical_map, full_matrices=True)
        threshold = (
            rank_tolerance * max(physical_map.shape) * float(singular.max(initial=1.0))
        )
        rank = int(np.sum(singular > threshold))
        if rank == 0:
            raise ValueError("polytope has no nontrivial tangent space")
        tangent = np.ascontiguousarray(left[:, :rank])
        normal = np.ascontiguousarray(left[:, rank:])

        rows: list[np.ndarray] = []
        rhs: list[float] = []
        matrix = np.asarray(csc_matrix(problem.matrix).toarray(), dtype=np.float64)
        for row, lower, upper in zip(
            matrix, problem.row_lower, problem.row_upper, strict=True
        ):
            if (
                np.isfinite(lower)
                and np.isfinite(upper)
                and np.isclose(lower, upper, atol=1e-10, rtol=1e-10)
            ):
                continue
            if np.isfinite(upper):
                rows.append(np.asarray(row, dtype=np.float64))
                rhs.append(float(upper))
            if np.isfinite(lower):
                rows.append(np.asarray(-row, dtype=np.float64))
                rhs.append(float(-lower))
        identity = np.eye(problem.variable_count)
        for index, (lower, upper) in enumerate(
            zip(problem.variable_lower, problem.variable_upper, strict=True)
        ):
            if (
                np.isfinite(lower)
                and np.isfinite(upper)
                and np.isclose(lower, upper, atol=1e-10, rtol=1e-10)
            ):
                continue
            if np.isfinite(upper):
                rows.append(identity[index])
                rhs.append(float(upper))
            if np.isfinite(lower):
                rows.append(-identity[index])
                rhs.append(float(-lower))
        if not rows:
            raise ValueError("normal-cone correction requires inequalities")
        inequalities = np.asarray(rows, dtype=np.float64)
        bounds = np.asarray(rhs, dtype=np.float64)
        norms = np.linalg.norm(inequalities, axis=1)
        nonzero = norms > 1e-14
        inequalities = inequalities[nonzero] / norms[nonzero, None]
        bounds = bounds[nonzero] / norms[nonzero]
        return cls(tangent, normal, inequalities, bounds)

    @property
    def variable_dimension(self) -> int:
        return int(self.tangent_basis.shape[0])

    @property
    def tangent_dimension(self) -> int:
        return int(self.tangent_basis.shape[1])

    @property
    def normal_dimension(self) -> int:
        return int(self.normal_basis.shape[1])

    def tangent_coordinates(self, values: FloatArray) -> FloatArray:
        return np.asarray(values, dtype=np.float64) @ self.tangent_basis

    def normal_coordinates(self, values: FloatArray) -> FloatArray:
        return np.asarray(values, dtype=np.float64) @ self.normal_basis

    def from_tangent(self, coordinates: FloatArray) -> FloatArray:
        return np.asarray(coordinates, dtype=np.float64) @ self.tangent_basis.T

    def from_normal(self, coordinates: FloatArray) -> FloatArray:
        if self.normal_dimension == 0:
            return np.zeros(
                (len(np.asarray(coordinates)), self.variable_dimension),
                dtype=np.float64,
            )
        return np.asarray(coordinates, dtype=np.float64) @ self.normal_basis.T

    def ray_project(
        self,
        targets: FloatArray,
        base_directions: FloatArray,
        *,
        minimum_scale: float,
    ) -> tuple[FloatArray, FloatArray]:
        target_tangent = self.tangent_coordinates(targets)
        base_tangent = self.tangent_coordinates(base_directions)
        denominator = np.sum(base_tangent**2, axis=1)
        nondegenerate = denominator > 1e-16
        scales = np.full(len(denominator), minimum_scale, dtype=np.float64)
        scales[nondegenerate] = (
            np.sum(
                target_tangent[nondegenerate] * base_tangent[nondegenerate], axis=1
            )
            / denominator[nondegenerate]
        )
        # A mathematically positive but machine-tiny tangent cost can disappear
        # after a large affine-normal gauge is passed to an LP solver.  Retain
        # a small relative tangent margin in addition to the absolute floor.
        relative_floor = np.zeros(len(denominator), dtype=np.float64)
        relative_floor[nondegenerate] = (
            1e-4
            * np.maximum(np.linalg.norm(targets[nondegenerate], axis=1), 1.0)
            / np.sqrt(denominator[nondegenerate])
        )
        scales = np.maximum(scales, np.maximum(minimum_scale, relative_floor))
        costs = self.from_tangent(scales[:, None] * base_tangent)
        costs += self.from_normal(self.normal_coordinates(targets))
        return np.ascontiguousarray(costs), np.ascontiguousarray(scales)

    def active_mask(
        self, decisions: FloatArray, *, tolerance: float = 2e-6
    ) -> NDArray[np.bool_]:
        decisions = np.asarray(decisions, dtype=np.float64)
        slack = self.inequality_rhs[None, :] - decisions @ self.inequality_normals.T
        return np.asarray(
            slack <= tolerance * (1.0 + np.abs(self.inequality_rhs))[None, :],
            dtype=bool,
        )

    def cone_project(
        self,
        targets: FloatArray,
        decisions: FloatArray,
        base_directions: FloatArray,
        *,
        minimum_scale: float,
        anchor_weight: float = 1e-3,
    ) -> tuple[FloatArray, dict[str, Any]]:
        """Project costs onto selected-decision cones using active-set NNLS.

        A tiny convex blend with the positive base-cost ray preserves the base
        optimizer when it is unique, even if the Euclidean projection lands on
        the boundary of its normal cone.
        """

        started = time.perf_counter()
        targets = np.asarray(targets, dtype=np.float64)
        base = np.asarray(base_directions, dtype=np.float64)
        target_tangent = self.tangent_coordinates(targets)
        target_normal = self.from_normal(self.normal_coordinates(targets))
        masks = self.active_mask(decisions)
        projected_tangent = np.empty_like(target_tangent)
        residuals = np.empty(len(targets), dtype=np.float64)
        active_counts = np.sum(masks, axis=1)
        generator_counts = np.zeros(len(targets), dtype=np.int64)
        cache: dict[tuple[int, ...], np.ndarray] = {}
        for index, (target, mask) in enumerate(zip(target_tangent, masks, strict=True)):
            key = tuple(np.flatnonzero(mask).tolist())
            generators = cache.get(key)
            if generators is None:
                active = self.inequality_normals[np.asarray(key, dtype=np.int64)]
                # For g(z)<=0, minimization KKT gives c=-g'lambda+normal.
                generator_rows = -(active @ self.tangent_basis)
                keep = np.linalg.norm(generator_rows, axis=1) > 1e-11
                generators = np.ascontiguousarray(generator_rows[keep].T)
                cache[key] = generators
            generator_counts[index] = generators.shape[1]
            if generators.shape[1] == 0:
                point = np.zeros(self.tangent_dimension, dtype=np.float64)
            else:
                coefficients, _ = nnls(
                    generators,
                    target,
                    maxiter=max(3 * generators.shape[1], 100),
                )
                point = generators @ coefficients
            projected_tangent[index] = point
            residuals[index] = float(np.linalg.norm(point - target))

        base_tangent = self.tangent_coordinates(base)
        base_norm = np.linalg.norm(base_tangent, axis=1)
        target_norm = np.linalg.norm(target_tangent, axis=1)
        if np.any(base_norm <= 1e-16):
            raise ValueError("base cost has a vanishing tangent component")
        # Use a comparable-magnitude positive base ray, rather than the
        # Euclidean ray projection scale.  The latter can hit its tiny lower
        # bound when target and base directions disagree, making the strict
        # optimizer anchor numerically invisible.
        ray_scales = np.maximum(target_norm / base_norm, minimum_scale)
        ray_tangent = ray_scales[:, None] * base_tangent
        blended_tangent = (
            1.0 - anchor_weight
        ) * projected_tangent + anchor_weight * ray_tangent
        costs = self.from_tangent(blended_tangent) + target_normal
        return np.ascontiguousarray(costs), {
            "wall_seconds": time.perf_counter() - started,
            "mean_projection_residual": float(np.mean(residuals)),
            "maximum_projection_residual": float(np.max(residuals, initial=0.0)),
            "mean_active_constraints": float(np.mean(active_counts)),
            "mean_nonzero_tangent_generators": float(np.mean(generator_counts)),
            "unique_active_sets": len(cache),
            "anchor_weight": float(anchor_weight),
            "mean_ray_scale": float(np.mean(ray_scales)),
        }


def _raw_features(
    split: CorrectionSplit, geometry: DecisionInvariantGeometry
) -> FloatArray:
    contexts = np.asarray(split.contexts, dtype=np.float64)
    tangent = geometry.tangent_coordinates(split.base_directions)
    norms = np.linalg.norm(tangent, axis=1)
    safe = np.maximum(norms, 1e-12)
    unit = tangent / safe[:, None]
    return np.ascontiguousarray(
        np.column_stack(
            [
                np.asarray(split.hidden_features, dtype=np.float64),
                contexts,
                unit,
                np.log(safe),
            ]
        )
    )


def _ridge_fit(features: FloatArray, targets: FloatArray, ridge: float) -> FloatArray:
    x = np.asarray(features, dtype=np.float64)
    y = np.asarray(targets, dtype=np.float64)
    slopes = x[:, :-1]
    centered_targets = y - y.mean(axis=0)
    if ridge > 0.0 and slopes.shape[1] > slopes.shape[0]:
        gram = slopes @ slopes.T + float(ridge) * np.eye(len(slopes))
        try:
            dual = np.linalg.solve(gram, centered_targets)
        except np.linalg.LinAlgError:
            dual = np.linalg.pinv(gram, rcond=1e-12) @ centered_targets
        coefficient = slopes.T @ dual
    else:
        gram = slopes.T @ slopes + float(ridge) * np.eye(slopes.shape[1])
        right = slopes.T @ centered_targets
        try:
            coefficient = np.linalg.solve(gram, right)
        except np.linalg.LinAlgError:
            coefficient = np.linalg.pinv(gram, rcond=1e-12) @ right
    intercept = y.mean(axis=0) - slopes.mean(axis=0) @ coefficient
    return np.asarray(np.vstack([coefficient, intercept]), dtype=np.float64)


def _fit_positive_scale_head(
    features: FloatArray,
    tangent_directions: FloatArray,
    tangent_targets: FloatArray,
    *,
    ridge: float,
    minimum_scale: float,
) -> FloatArray:
    weights = cp.Variable(features.shape[1])
    feature_expression = cp.Constant(features)
    tangent_expression = cp.Constant(tangent_directions)
    target_expression = cp.Constant(tangent_targets)
    scales = feature_expression @ weights
    scale_matrix = reshape(scales, (len(features), 1), order="C")
    residual = target_expression - multiply(scale_matrix, tangent_expression)
    penalty = sum_squares(weights[:-1])
    constraints: list[cp.Constraint] = [scales >= minimum_scale]
    problem = cp.Problem(
        cp.Minimize(sum_squares(residual) + ridge * penalty),
        constraints,
    )
    try:
        problem.solve(  # type: ignore[no-untyped-call]
            solver="OSQP",
            eps_abs=1e-6,
            eps_rel=1e-6,
            max_iter=100_000,
            polishing=True,
            verbose=False,
        )
    except cp.error.SolverError:
        problem.solve(  # type: ignore[no-untyped-call]
            solver="CLARABEL",
            tol_gap_abs=1e-7,
            tol_feas=1e-7,
            tol_gap_rel=1e-7,
            max_iter=500,
            verbose=False,
        )
    if problem.status not in {cp.OPTIMAL, cp.OPTIMAL_INACCURATE}:
        raise RuntimeError(f"positive scale head failed with status {problem.status}")
    if weights.value is None or not np.all(np.isfinite(weights.value)):
        raise RuntimeError("positive scale head omitted finite weights")
    return np.asarray(weights.value, dtype=np.float64)


def prediction_metrics(
    physical_costs: FloatArray,
    split: CorrectionSplit,
    geometry: DecisionInvariantGeometry,
) -> dict[str, float]:
    prediction = np.asarray(physical_costs, dtype=np.float64)
    conditional = np.asarray(split.conditional_mean_costs, dtype=np.float64)
    observed = np.asarray(split.observed_costs, dtype=np.float64)
    conditional_error = prediction - conditional
    observed_error = prediction - observed
    tangent_prediction = geometry.tangent_coordinates(prediction)
    tangent_conditional = geometry.tangent_coordinates(conditional)
    normal_prediction = geometry.normal_coordinates(prediction)
    normal_conditional = geometry.normal_coordinates(conditional)
    tangent_error = tangent_prediction - tangent_conditional
    normal_error = normal_prediction - normal_conditional
    denominator = np.linalg.norm(tangent_prediction, axis=1) * np.linalg.norm(
        tangent_conditional, axis=1
    )
    cosine = np.divide(
        np.sum(tangent_prediction * tangent_conditional, axis=1),
        denominator,
        out=np.zeros_like(denominator),
        where=denominator > 1e-14,
    )
    dimension = prediction.shape[1]
    return {
        "conditional_mse_per_coordinate": float(np.mean(conditional_error**2)),
        "conditional_mse_per_vector": float(
            np.mean(np.sum(conditional_error**2, axis=1))
        ),
        "scenario_mse_per_coordinate": float(np.mean(observed_error**2)),
        "scenario_mse_per_vector": float(np.mean(np.sum(observed_error**2, axis=1))),
        "conditional_mae_per_coordinate": float(np.mean(np.abs(conditional_error))),
        "tangent_conditional_mse_per_coordinate": float(np.mean(tangent_error**2)),
        "normal_conditional_mse_per_coordinate": (
            0.0 if normal_error.shape[1] == 0 else float(np.mean(normal_error**2))
        ),
        "mean_tangent_cosine": float(np.mean(cosine)),
        "physical_dimension": float(dimension),
    }


def _scenario_mse(costs: FloatArray, split: CorrectionSplit) -> float:
    return float(np.mean((np.asarray(costs) - split.observed_costs) ** 2))


def _cost_from_scale_and_gauge(
    geometry: DecisionInvariantGeometry,
    tangent_directions: FloatArray,
    scales: FloatArray,
    gauge_coordinates: FloatArray,
) -> FloatArray:
    tangent_norm = np.linalg.norm(tangent_directions, axis=1)
    gauge_norm = np.linalg.norm(gauge_coordinates, axis=1)
    numerical_floor = (
        1e-4 * np.maximum(gauge_norm, 1.0) / np.maximum(tangent_norm, 1e-14)
    )
    safe_scales = np.maximum(np.asarray(scales, dtype=np.float64), numerical_floor)
    return np.ascontiguousarray(
        geometry.from_tangent(safe_scales[:, None] * tangent_directions)
        + geometry.from_normal(gauge_coordinates)
    )


def fit_prediction_corrections(
    *,
    train: CorrectionSplit,
    validation: CorrectionSplit,
    test: CorrectionSplit,
    geometry: DecisionInvariantGeometry,
    mu: float,
    ridge_grid: tuple[float, ...] = (1e-8, 1e-5, 1e-3, 1e-1),
    minimum_scale: float = 1e-6,
    include_cone: bool = True,
) -> tuple[dict[str, CorrectionPrediction], dict[str, Any]]:
    """Fit the complete pair-only correction ladder and select on validation."""

    suite_started = time.perf_counter()
    if mu <= 0.0 or not np.isfinite(mu):
        raise ValueError("known barrier mu must be finite and positive")
    feature_started = time.perf_counter()
    raw_train = _raw_features(train, geometry)
    raw_validation = _raw_features(validation, geometry)
    raw_test = _raw_features(test, geometry)
    feature_map = _FeatureTransform.fit(raw_train)
    x_train = feature_map.apply(raw_train)
    x_validation = feature_map.apply(raw_validation)
    x_test = feature_map.apply(raw_test)
    tangent = {
        "train": geometry.tangent_coordinates(train.base_directions),
        "validation": geometry.tangent_coordinates(validation.base_directions),
        "test": geometry.tangent_coordinates(test.base_directions),
    }
    target_tangent = geometry.tangent_coordinates(train.observed_costs)
    target_gauge = geometry.normal_coordinates(train.observed_costs)
    denominator = np.sum(tangent["train"] ** 2, axis=1)
    if np.any(denominator <= 1e-16):
        raise ValueError("training base direction has zero tangent norm")
    oracle_scale_labels = np.maximum(
        np.sum(target_tangent * tangent["train"], axis=1) / denominator,
        minimum_scale,
    )
    feature_wall = time.perf_counter() - feature_started

    results: dict[str, CorrectionPrediction] = {}
    raw_test_cost = np.asarray(test.base_directions, dtype=np.float64)
    results["raw_direction"] = CorrectionPrediction(
        "raw_direction", raw_test_cost, 0.0, None, None, {"pair_only": True}
    )
    restored = geometry.from_tangent(mu * tangent["test"])
    results["restore_known_mu"] = CorrectionPrediction(
        "restore_known_mu",
        restored,
        0.0,
        None,
        None,
        {"mu": float(mu), "pair_only": True, "learned_parameters": 0},
    )

    privileged_started = time.perf_counter()
    oracle_ray, oracle_ray_scales = geometry.ray_project(
        test.conditional_mean_costs,
        test.base_directions,
        minimum_scale=minimum_scale,
    )
    results["oracle_conditional_ray_gauge"] = CorrectionPrediction(
        "oracle_conditional_ray_gauge",
        oracle_ray,
        0.0,
        None,
        None,
        {
            "privileged_conditional_mean_oracle": True,
            "mean_scale": float(np.mean(oracle_ray_scales)),
        },
    )

    cone_train_labels: FloatArray | None = None
    cone_label_receipt: dict[str, Any] | None = None
    cone_training_label_wall = 0.0
    if include_cone:
        cone_train_labels, cone_label_receipt = geometry.cone_project(
            train.observed_costs,
            train.base_decisions,
            train.base_directions,
            minimum_scale=minimum_scale,
        )
        cone_training_label_wall = float(cone_label_receipt["wall_seconds"])
        oracle_cone, oracle_cone_receipt = geometry.cone_project(
            test.conditional_mean_costs,
            test.base_decisions,
            test.base_directions,
            minimum_scale=minimum_scale,
        )
        results["oracle_conditional_full_cone"] = CorrectionPrediction(
            "oracle_conditional_full_cone",
            oracle_cone,
            oracle_cone_receipt["wall_seconds"],
            None,
            None,
            {
                **oracle_cone_receipt,
                "privileged_conditional_mean_oracle": True,
            },
        )
    privileged_wall = (
        time.perf_counter() - privileged_started - cone_training_label_wall
    )

    selected_receipts: dict[str, Any] = {}
    total_candidate_wall = 0.0

    def select_ridge_method(
        name: str,
        builder: Any,
    ) -> None:
        nonlocal total_candidate_wall
        best: tuple[float, float, FloatArray, float, dict[str, Any]] | None = None
        candidates: list[dict[str, Any]] = []
        for ridge in ridge_grid:
            started = time.perf_counter()
            validation_cost, test_cost, metadata = builder(float(ridge))
            wall = time.perf_counter() - started
            total_candidate_wall += wall
            score = _scenario_mse(validation_cost, validation)
            candidates.append(
                {
                    "ridge": float(ridge),
                    "validation_scenario_mse_per_coordinate": score,
                    "fitting_wall_seconds": wall,
                }
            )
            candidate = (score, float(ridge), test_cost, wall, metadata)
            if best is None or candidate[:2] < best[:2]:
                best = candidate
        if best is None:
            raise RuntimeError(f"no correction candidate was fitted for {name}")
        score, ridge, test_cost, wall, metadata = best
        results[name] = CorrectionPrediction(
            name,
            np.ascontiguousarray(test_cost),
            wall,
            ridge,
            score,
            metadata,
        )
        selected_receipts[name] = {
            "selected_ridge": ridge,
            "selection_metric": "validation scenario MSE per physical coordinate",
            "selected_candidate_fit_and_prediction_wall_seconds": wall,
            "all_candidate_fit_and_prediction_wall_seconds": float(
                sum(float(row["fitting_wall_seconds"]) for row in candidates)
            ),
            "candidates": candidates,
        }

    def gauge_weights(ridge: float) -> FloatArray:
        if geometry.normal_dimension == 0:
            return np.zeros((x_train.shape[1], 0), dtype=np.float64)
        return _ridge_fit(x_train, target_gauge, ridge)

    def restored_gauge_builder(
        ridge: float,
    ) -> tuple[FloatArray, FloatArray, dict[str, Any]]:
        gauge = gauge_weights(ridge)
        validation_cost = _cost_from_scale_and_gauge(
            geometry,
            tangent["validation"],
            np.full(len(validation.contexts), mu),
            x_validation @ gauge,
        )
        test_cost = _cost_from_scale_and_gauge(
            geometry, tangent["test"], np.full(len(test.contexts), mu), x_test @ gauge
        )
        return validation_cost, test_cost, {"mu": float(mu), "gauge_head": "ridge"}

    select_ridge_method("restore_mu_learned_gauge", restored_gauge_builder)

    global_numerator = float(np.sum(target_tangent * tangent["train"]))
    global_denominator = float(np.sum(tangent["train"] ** 2))
    global_scale = max(minimum_scale, global_numerator / global_denominator)

    def global_builder(ridge: float) -> tuple[FloatArray, FloatArray, dict[str, Any]]:
        gauge = gauge_weights(ridge)
        validation_cost = _cost_from_scale_and_gauge(
            geometry,
            tangent["validation"],
            np.full(len(validation.contexts), global_scale),
            x_validation @ gauge,
        )
        test_cost = _cost_from_scale_and_gauge(
            geometry,
            tangent["test"],
            np.full(len(test.contexts), global_scale),
            x_test @ gauge,
        )
        return validation_cost, test_cost, {"global_scale": global_scale}

    select_ridge_method("learned_global_scale_gauge", global_builder)

    def contextual_builder(
        ridge: float,
    ) -> tuple[FloatArray, FloatArray, dict[str, Any]]:
        scale_weights = _fit_positive_scale_head(
            x_train,
            tangent["train"],
            target_tangent,
            ridge=ridge,
            minimum_scale=minimum_scale,
        )
        gauge = gauge_weights(ridge)
        validation_scale = np.maximum(x_validation @ scale_weights, minimum_scale)
        test_scale = np.maximum(x_test @ scale_weights, minimum_scale)
        validation_cost = _cost_from_scale_and_gauge(
            geometry, tangent["validation"], validation_scale, x_validation @ gauge
        )
        test_cost = _cost_from_scale_and_gauge(
            geometry, tangent["test"], test_scale, x_test @ gauge
        )
        return (
            validation_cost,
            test_cost,
            {
                "scale_head": "direct constrained convex QP",
                "mean_test_scale": float(np.mean(test_scale)),
                "minimum_test_scale": float(np.min(test_scale)),
            },
        )

    select_ridge_method("direct_contextual_scale_gauge", contextual_builder)

    def label_builder(ridge: float) -> tuple[FloatArray, FloatArray, dict[str, Any]]:
        log_scale_labels = np.log(oracle_scale_labels)
        labels = np.column_stack([log_scale_labels, target_gauge])
        weights = _ridge_fit(x_train, labels, ridge)
        validation_label = x_validation @ weights
        test_label = x_test @ weights
        lower = max(-20.0, float(np.min(log_scale_labels)) - np.log(10.0))
        upper = min(20.0, float(np.max(log_scale_labels)) + np.log(10.0))
        validation_scale = np.exp(np.clip(validation_label[:, 0], lower, upper))
        test_scale = np.exp(np.clip(test_label[:, 0], lower, upper))
        validation_cost = _cost_from_scale_and_gauge(
            geometry,
            tangent["validation"],
            validation_scale,
            validation_label[:, 1:],
        )
        test_cost = _cost_from_scale_and_gauge(
            geometry, tangent["test"], test_scale, test_label[:, 1:]
        )
        return (
            validation_cost,
            test_cost,
            {
                "target": "per-scenario exact ray-plus-gauge projection label",
                "scale_parameterization": "log",
                "log_scale_prediction_bounds": [lower, upper],
                "mean_test_scale": float(np.mean(test_scale)),
            },
        )

    select_ridge_method("learn_exact_ray_labels", label_builder)

    def mse_weights(ridge: float) -> FloatArray:
        return _ridge_fit(x_train, train.observed_costs, ridge)

    def feature_mse_ray_builder(
        ridge: float,
    ) -> tuple[FloatArray, FloatArray, dict[str, Any]]:
        weights = mse_weights(ridge)
        validation_target = x_validation @ weights
        test_target = x_test @ weights
        validation_cost, validation_scale = geometry.ray_project(
            validation_target,
            validation.base_directions,
            minimum_scale=minimum_scale,
        )
        test_cost, test_scale = geometry.ray_project(
            test_target, test.base_directions, minimum_scale=minimum_scale
        )
        return (
            validation_cost,
            test_cost,
            {
                "target_predictor": "exact ridge MSE on frozen policy features",
                "correction": "closed-form ray-plus-gauge projection",
                "mean_test_scale": float(np.mean(test_scale)),
                "mean_validation_scale": float(np.mean(validation_scale)),
            },
        )

    select_ridge_method("project_feature_mse_to_ray_gauge", feature_mse_ray_builder)

    if include_cone:
        if cone_train_labels is None or cone_label_receipt is None:
            raise RuntimeError("cone labels were not prepared")

        def feature_mse_cone_builder(
            ridge: float,
        ) -> tuple[FloatArray, FloatArray, dict[str, Any]]:
            weights = mse_weights(ridge)
            validation_target = x_validation @ weights
            test_target = x_test @ weights
            validation_cost, validation_receipt = geometry.cone_project(
                validation_target,
                validation.base_decisions,
                validation.base_directions,
                minimum_scale=minimum_scale,
            )
            test_cost, test_receipt = geometry.cone_project(
                test_target,
                test.base_decisions,
                test.base_directions,
                minimum_scale=minimum_scale,
            )
            return (
                validation_cost,
                test_cost,
                {
                    "target_predictor": "exact ridge MSE on frozen policy features",
                    "correction": "full selected-decision normal-cone projection",
                    "validation_projection": validation_receipt,
                    "test_projection": test_receipt,
                },
            )

        select_ridge_method(
            "project_feature_mse_to_full_cone", feature_mse_cone_builder
        )

        def cone_label_builder(
            ridge: float,
        ) -> tuple[FloatArray, FloatArray, dict[str, Any]]:
            weights = _ridge_fit(x_train, cone_train_labels, ridge)
            validation_target = x_validation @ weights
            test_target = x_test @ weights
            validation_cost, validation_receipt = geometry.cone_project(
                validation_target,
                validation.base_decisions,
                validation.base_directions,
                minimum_scale=minimum_scale,
            )
            test_cost, test_receipt = geometry.cone_project(
                test_target,
                test.base_decisions,
                test.base_directions,
                minimum_scale=minimum_scale,
            )
            return (
                validation_cost,
                test_cost,
                {
                    "target": "per-scenario exact full-cone projection label",
                    "training_label_projection": cone_label_receipt,
                    "validation_projection": validation_receipt,
                    "test_projection": test_receipt,
                },
            )

        select_ridge_method("learn_exact_full_cone_labels", cone_label_builder)

    whole_suite_wall = time.perf_counter() - suite_started
    pair_only_wall = max(0.0, whole_suite_wall - privileged_wall)
    receipt = {
        "supervision": "ordinary context-scenario pairs only",
        "selection_metric": "validation scenario MSE per physical coordinate",
        "conditional_means_used_for_fitting_or_selection": False,
        "feature_dimension_with_intercept": int(x_train.shape[1]),
        "tangent_dimension": geometry.tangent_dimension,
        "normal_dimension": geometry.normal_dimension,
        "physical_dimension": geometry.variable_dimension,
        "ridge_grid": [float(value) for value in ridge_grid],
        "minimum_positive_scale": float(minimum_scale),
        "known_mu": float(mu),
        "selected_methods": selected_receipts,
        "timing": {
            "feature_preparation_wall_seconds": feature_wall,
            "training_label_projection_wall_seconds": cone_training_label_wall,
            "all_pair_only_candidate_fit_and_prediction_wall_seconds": (
                total_candidate_wall
            ),
            "pair_only_suite_wall_seconds": pair_only_wall,
            "privileged_diagnostic_wall_seconds": max(0.0, privileged_wall),
            "whole_exploratory_suite_wall_seconds": whole_suite_wall,
            "interpretation": (
                "Pair-only suite time includes the complete ridge search for every "
                "candidate method. Privileged diagnostic time is excluded from the "
                "practical correction cost."
            ),
        },
    }
    return results, receipt
